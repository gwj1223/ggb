function ok = collisionFreeSegment3D(q1, q2, scene, planner)
% Sample along the segment and require positive clearance above agent radius.

ok = true;
dist = norm(q2(1:3) - q1(1:3));
n = max(2, ceil(dist / planner.collisionCheckRes));
pts = [linspace(q1(1), q2(1), n)', ...
       linspace(q1(2), q2(2), n)', ...
       linspace(q1(3), q2(3), n)'];

for k = 1:size(pts,1)
    if pointClearance3D(pts(k,:), scene) <= planner.agentRadius
        ok = false;
        return;
    end
end
end
