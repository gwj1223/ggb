%% 3D Swarm Planner Demo (Simple City)
% BiRRT + biased sampling + Dubins-like steering + ORCA-inspired local avoidance
% Environment: flat urban ground + a few 3D buildings + air-risk regions

clear; clc; close all;
rng(11);

[scene, starts, goals, planner, orca, objective] = createDemoScene3D();
nAgents = size(starts, 1);

fprintf('========== 3D Global Planning on Simple City Map ==========' );
fprintf('\n');
paths = cell(nAgents, 1);
pathInfo = cell(nAgents, 1);

for i = 1:nAgents
    fprintf('Planning UAV %d/%d ...\n', i, nAgents);

    [path, info] = planAgentPath3D_multiobjective( ...
        starts(i,:), goals(i,:), scene, planner, objective);

    if isempty(path)
        error('UAV %d planning failed. Increase planner.maxIter or planner.numCandidates.', i);
    end

    paths{i} = path;
    pathInfo{i} = info;

    mLen    = getMetric(info.bestMetrics, {'length'}, NaN);
    mSmooth = getMetric(info.bestMetrics, {'smoothness','smooth'}, NaN);
    mMinClr = getMetric(info.bestMetrics, {'minClearance','minClr'}, NaN);
    mClimb  = getMetric(info.bestMetrics, {'altitudeChange','climb'}, NaN);
    mRisk   = getMetric(info.bestMetrics, {'riskPenalty','risk'}, NaN);

    fprintf(['  cand = %d/%d | feasible = %d | fallback = %d | viol = %.3f | ' ...
             'score = %.4f | len = %.2f | smooth = %.2f | climb = %.2f | ' ...
             'minClr = %.2f | risk = %.3f\n'], ...
        info.bestCandidateIndex, ...
        info.numValidCandidates, ...
        info.numFeasibleCandidates, ...
        info.usedFallback, ...
        info.bestViolation, ...
        info.bestScore, ...
        mLen, mSmooth, mClimb, mMinClr, mRisk);
end

fprintf('\n========== 3D Local ORCA-inspired Simulation ==========\n');
sim = simulateSwarmORCA3D(starts, goals, paths, scene, orca);
fprintf('Finished at step %d, sim time = %.2f s\n', sim.steps, sim.time(end));

plotResultsSingleFigure3D(scene, starts, goals, paths, sim);

fprintf('\n========== Execution Summary ==========\n');
for i = 1:nAgents
    execLen = sum(vecnorm(diff(sim.history{i}(:,1:3), 1, 1), 2, 2));
    fprintf('UAV %d | ExecLen = %.2f | Reached = %d\n', ...
        i, execLen, sim.reached(i));
end

function val = getMetric(S, candidates, defaultVal)
val = defaultVal;
if isempty(S) || ~isstruct(S)
    return;
end
for ii = 1:numel(candidates)
    name = candidates{ii};
    if isfield(S, name)
        tmp = S.(name);
        if ~isempty(tmp)
            val = tmp;
            return;
        end
    end
end
end
