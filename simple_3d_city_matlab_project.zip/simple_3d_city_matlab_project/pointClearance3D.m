function clr = pointClearance3D(p, scene)
% Signed clearance to nearest obstacle surface, terrain or boundary.
% Positive outside obstacles, negative inside.

clrObs = inf;

if isfield(scene, 'spheres') && ~isempty(scene.spheres)
    for k = 1:size(scene.spheres,1)
        s = scene.spheres(k,:);
        clrObs = min(clrObs, norm(p - s(1:3)) - s(4));
    end
end

if isfield(scene, 'cylinders') && ~isempty(scene.cylinders)
    for k = 1:size(scene.cylinders,1)
        clrObs = min(clrObs, signedDistanceToCylinderZ(p, scene.cylinders(k,:)));
    end
end

if isfield(scene, 'noFlyCylinders') && ~isempty(scene.noFlyCylinders)
    for k = 1:size(scene.noFlyCylinders,1)
        clrObs = min(clrObs, signedDistanceToCylinderZ(p, scene.noFlyCylinders(k,:)));
    end
end

if isfield(scene, 'boxes') && ~isempty(scene.boxes)
    for k = 1:size(scene.boxes,1)
        clrObs = min(clrObs, signedDistanceToAABB(p, scene.boxes(k,:)));
    end
end

clrTerrain = inf;
if isfield(scene, 'terrain') && isfield(scene.terrain, 'enabled') && scene.terrain.enabled && ...
   isfield(scene.terrain, 'heightAt') && isa(scene.terrain.heightAt, 'function_handle')
    zGround = scene.terrain.heightAt(p(1), p(2));
    clrTerrain = p(3) - zGround;
end

b = scene.bounds;
clrBound = min([p(1)-b(1), b(2)-p(1), p(2)-b(3), b(4)-p(2), p(3)-b(5), b(6)-p(3)]);
clr = min([clrObs, clrTerrain, clrBound]);
end

function d = signedDistanceToCylinderZ(p, cyl)
xc = cyl(1); yc = cyl(2); r = cyl(3); zMin = cyl(4); zMax = cyl(5);
radial = norm(p(1:2) - [xc yc]) - r;
if p(3) < zMin
    dz = zMin - p(3);
elseif p(3) > zMax
    dz = p(3) - zMax;
else
    dz = 0;
end

if radial > 0 && dz > 0
    d = hypot(radial, dz);
elseif radial > 0
    d = radial;
elseif dz > 0
    d = dz;
else
    d = max(radial, -min(p(3)-zMin, zMax-p(3)));
end
end

function d = signedDistanceToAABB(p, box)
center = [(box(1)+box(2))/2, (box(3)+box(4))/2, (box(5)+box(6))/2];
half = [(box(2)-box(1))/2, (box(4)-box(3))/2, (box(6)-box(5))/2];
q = abs(p - center) - half;
outside = norm(max(q, 0));
inside = min(max(q), 0);
d = outside + inside;
end
