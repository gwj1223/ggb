function densePath = densifyPath3D(path, ds)
% Linear densification in 3D with angle interpolation.

if size(path,1) <= 1
    densePath = path;
    return;
end

densePath = path(1,:);
for k = 1:size(path,1)-1
    p1 = path(k,:);
    p2 = path(k+1,:);
    segLen = norm(p2(1:3) - p1(1:3));
    n = max(1, ceil(segLen / ds));
    for i = 1:n
        t = i / n;
        pos = (1-t) * p1(1:3) + t * p2(1:3);
        yaw = p1(4) + t * angleDiff(p2(4), p1(4));
        pitch = (1-t) * p1(5) + t * p2(5);
        densePath(end+1,:) = [pos, yaw, pitch]; %#ok<AGROW>
    end
end
end
