function [bestPath, info] = planAgentPath3D_multiobjective(startState, goalState, scene, planner, objective)
% Generate multiple candidate paths and pick the best one using:
% 1) hard screening on min clearance / risk / climb / smoothness
% 2) minimum-violation fallback when no candidate fully passes

bestPath = [];
bestScore = inf;
bestMetrics = struct();
bestIdx = 0;

numValid = 0;
numFeasible = 0;

usedFallback = false;
bestViolation = inf;

% -------- thresholds --------
minClrHard = getObjectiveValue(objective, 'minClrHard', 4.3);
riskHard   = getObjectiveValue(objective, 'riskHard',   0.38);
climbHard  = getObjectiveValue(objective, 'climbHard',  inf);
smoothHard = getObjectiveValue(objective, 'smoothHard', inf);

% -------- fallback: choose minimum-violation candidate --------
fallbackPath = [];
fallbackScore = inf;
fallbackMetrics = struct();
fallbackIdx = 0;
fallbackViolation = inf;

for k = 1:planner.numCandidates
    plannerK = planner;

    % randomized diversity
    plannerK.stepLen = planner.stepLen * (0.92 + 0.16 * rand());

    plannerK.goalBias = min(max(planner.goalBias + 0.05 * randn(), 0.08), 0.35);
    plannerK.corridorBias = min(max(planner.corridorBias + 0.08 * randn(), 0.35), 0.85);
    plannerK.uniformBias = max(0.05, 1.0 - plannerK.goalBias - plannerK.corridorBias);

    % normalize sampling biases
    s = plannerK.goalBias + plannerK.corridorBias + plannerK.uniformBias;
    plannerK.goalBias = plannerK.goalBias / s;
    plannerK.corridorBias = plannerK.corridorBias / s;
    plannerK.uniformBias = plannerK.uniformBias / s;

    path = birrtDubinsPlan3D(startState, goalState, scene, plannerK);
    if isempty(path)
        continue;
    end

    numValid = numValid + 1;
    [score, metrics] = evaluatePathObjective3D(path, scene, objective);

    % ---- unified metric access ----
    mMinClr = getMetric(metrics, {'minClearance','minClr'}, inf);
    mRisk   = getMetric(metrics, {'riskPenalty','risk'}, inf);
    mClimb  = getMetric(metrics, {'altitudeChange','climb'}, inf);
    mSmooth = getMetric(metrics, {'smoothness','smooth'}, inf);

    % ---- hard screening ----
    passClr = (mMinClr >= minClrHard);
    passRisk = (mRisk <= riskHard);

    if isfinite(climbHard)
        passClimb = (mClimb <= climbHard);
    else
        passClimb = true;
    end

    if isfinite(smoothHard)
        passSmooth = (mSmooth <= smoothHard);
    else
        passSmooth = true;
    end

    if passClr && passRisk && passClimb && passSmooth
        numFeasible = numFeasible + 1;

        % among feasible candidates, choose lowest score
        if score < bestScore
            bestScore = score;
            bestMetrics = metrics;
            bestPath = path;
            bestIdx = k;
            bestViolation = 0.0;
        end
    else
        % minimum-violation fallback
        violation = candidateViolation(metrics, objective);

        if (violation < fallbackViolation) || ...
           (abs(violation - fallbackViolation) < 1e-12 && score < fallbackScore)

            fallbackViolation = violation;
            fallbackScore = score;
            fallbackMetrics = metrics;
            fallbackPath = path;
            fallbackIdx = k;
        end
    end
end

% if no feasible candidate exists, use minimum-violation fallback
if isempty(bestPath) && ~isempty(fallbackPath)
    bestPath = fallbackPath;
    bestScore = fallbackScore;
    bestMetrics = fallbackMetrics;
    bestIdx = fallbackIdx;
    bestViolation = fallbackViolation;
    usedFallback = true;
end

% diagnostics
info.bestScore = bestScore;
info.bestMetrics = bestMetrics;
info.bestCandidateIndex = bestIdx;
info.numValidCandidates = numValid;
info.numFeasibleCandidates = numFeasible;
info.usedFallback = usedFallback;
info.bestViolation = bestViolation;

info.minClrHard = minClrHard;
info.riskHard = riskHard;
info.climbHard = climbHard;
info.smoothHard = smoothHard;

end


function violation = candidateViolation(metrics, objective)
% normalized multi-violation; lower is better

minClrHard = getObjectiveValue(objective, 'minClrHard', 4.3);
riskHard   = getObjectiveValue(objective, 'riskHard',   0.38);
climbHard  = getObjectiveValue(objective, 'climbHard',  inf);
smoothHard = getObjectiveValue(objective, 'smoothHard', inf);

mMinClr = getMetric(metrics, {'minClearance','minClr'}, inf);
mRisk   = getMetric(metrics, {'riskPenalty','risk'}, inf);
mClimb  = getMetric(metrics, {'altitudeChange','climb'}, inf);
mSmooth = getMetric(metrics, {'smoothness','smooth'}, inf);

clrViol = max(0.0, minClrHard - mMinClr) / max(minClrHard, 1e-6);
riskViol = max(0.0, mRisk - riskHard) / max(riskHard, 1e-6);

if isfinite(climbHard)
    climbViol = max(0.0, mClimb - climbHard) / max(climbHard, 1e-6);
else
    climbViol = 0.0;
end

if isfinite(smoothHard)
    smoothViol = max(0.0, mSmooth - smoothHard) / max(smoothHard, 1e-6);
else
    smoothViol = 0.0;
end

violation = 1.0 * clrViol + ...
            1.0 * riskViol + ...
            0.8 * climbViol + ...
            0.6 * smoothViol;
end


function val = getMetric(S, names, defaultVal)
val = defaultVal;

if isempty(S) || ~isstruct(S)
    return;
end

for i = 1:numel(names)
    if isfield(S, names{i})
        tmp = S.(names{i});
        if ~isempty(tmp)
            val = tmp;
            return;
        end
    end
end
end


function val = getObjectiveValue(S, name, defaultVal)
if isstruct(S) && isfield(S, name) && ~isempty(S.(name))
    val = S.(name);
else
    val = defaultVal;
end
end