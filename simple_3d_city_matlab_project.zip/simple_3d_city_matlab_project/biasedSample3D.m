function q = biasedSample3D(scene, startState, goalState, planner)
% Goal-biased + corridor-biased + uniform sampling.

r = rand();
if r < planner.goalBias
    pos = goalState(1:3) + planner.goalSampleSigma * randn(1,3);
elseif r < planner.goalBias + planner.corridorBias
    s = rand();
    p0 = startState(1:3);
    p1 = goalState(1:3);
    base = p0 + s * (p1 - p0);
    dir = p1 - p0;
    dir = dir / max(norm(dir), 1e-9);
    tmp = [0 0 1];
    if abs(dot(dir, tmp)) > 0.9
        tmp = [0 1 0];
    end
    e2 = cross(dir, tmp);
    e2 = e2 / max(norm(e2), 1e-9);
    e3 = cross(dir, e2);
    pos = base + planner.corridorSigmaLat * randn() * e2 + ...
                 planner.corridorSigmaLat * randn() * e3 + ...
                 planner.corridorSigmaVert * randn() * [0 0 1];
else
    b = scene.bounds;
    pos = [b(1) + rand() * (b(2)-b(1)), ...
           b(3) + rand() * (b(4)-b(3)), ...
           b(5) + rand() * (b(6)-b(5))];
end

b = scene.bounds;
pos(1) = min(max(pos(1), b(1)), b(2));
pos(2) = min(max(pos(2), b(3)), b(4));
pos(3) = min(max(pos(3), b(5)), b(6));

vec = goalState(1:3) - pos;
[yaw, pitch] = vectorToYawPitch(vec);
yaw = yaw + deg2rad(15) * randn();
pitch = pitch + deg2rad(6) * randn();
pitch = min(max(pitch, planner.minPitch), planner.maxPitch);

q = [pos yaw pitch];
end

function [yaw, pitch] = vectorToYawPitch(v)
h = hypot(v(1), v(2));
yaw = atan2(v(2), v(1));
pitch = atan2(v(3), max(h, 1e-9));
end
