function plotResultsSingleFigure3D(scene, arg2, arg3, arg4, arg5)
% plotResultsSingleFigure3D
% Centered layout + legend at top-right.
% Compatible with both calling styles:
%   1) plotResultsSingleFigure3D(scene, starts, goals, paths, sim)
%   2) plotResultsSingleFigure3D(scene, paths, sim, starts, goals)

[starts, goals, globalPaths, executedTraj] = parseInputs(arg2, arg3, arg4, arg5);

fig = figure('Color', 'w', ...
    'Name', '3D swarm planning result', ...
    'NumberTitle', 'off', ...
    'Renderer', 'opengl', ...
    'Position', [90 70 1380 860]);

ax = axes('Parent', fig, 'Position', [0.08 0.10 0.84 0.80]);
hold(ax, 'on');

drawScene3D(scene, starts, goals);

title(ax, '3D global paths and executed trajectories', ...
    'FontWeight', 'bold', 'FontSize', 14);

pbaspect(ax, [1.22 1.10 0.50]);
view(ax, 35, 24);

colors = [...
    0.18 0.49 0.85;   % blue
    0.92 0.58 0.18;   % orange
    0.32 0.66 0.56;   % teal
    0.58 0.42 0.82;   % purple
    0.78 0.40 0.52;   % rose
    0.48 0.62 0.28];  % green

nAgents = max([numel(globalPaths), numel(executedTraj), sizeSafe(starts,1), sizeSafe(goals,1)]);
hExec = gobjects(nAgents,1);

for i = 1:nAgents
    c = colors(mod(i-1, size(colors,1)) + 1, :);

    if i <= numel(globalPaths)
        P = normalizePath(globalPaths{i});
        if ~isempty(P)
            plot3(ax, P(:,1), P(:,2), P(:,3), '--', ...
                'Color', c, ...
                'LineWidth', 1.6, ...
                'HandleVisibility', 'off');
        end
    end

    if i <= numel(executedTraj)
        T = normalizePath(executedTraj{i});
        if ~isempty(T)
            hExec(i) = plot3(ax, T(:,1), T(:,2), T(:,3), '-', ...
                'Color', c, ...
                'LineWidth', 2.6, ...
                'DisplayName', sprintf('UAV %d', i));

            scatter3(ax, T(1,1), T(1,2), T(1,3), 26, ...
                'MarkerFaceColor', c, ...
                'MarkerEdgeColor', 'w', ...
                'Marker', 'o', ...
                'LineWidth', 0.7, ...
                'HandleVisibility', 'off');

            scatter3(ax, T(end,1), T(end,2), T(end,3), 30, ...
                'MarkerFaceColor', c, ...
                'MarkerEdgeColor', [0.15 0.15 0.15], ...
                'Marker', 's', ...
                'LineWidth', 0.7, ...
                'HandleVisibility', 'off');
        end
    end
end

valid = isgraphics(hExec);
if any(valid)
    lgd = legend(ax, hExec(valid), compose("UAV %d", find(valid)), ...
        'Location', 'northeast', ...
        'Box', 'off', ...
        'FontSize', 11);
    lgd.NumColumns = 1;
end

axis(ax, 'vis3d');
grid(ax, 'on');

try
    rotate3d(fig, 'on');
catch
    rotate3d on;
end

end

function [starts, goals, globalPaths, executedTraj] = parseInputs(a2, a3, a4, a5)
starts = [];
goals = [];
globalPaths = {};
executedTraj = {};

if isNumericPoseArray(a2) && isNumericPoseArray(a3) && iscell(a4)
    starts = a2;
    goals = a3;
    globalPaths = a4;
    executedTraj = extractExecutedTraj(a5, numel(globalPaths));
    return;
end

if iscell(a2)
    globalPaths = a2;
    executedTraj = extractExecutedTraj(a3, numel(globalPaths));
    if isNumericPoseArray(a4), starts = a4; end
    if isNumericPoseArray(a5), goals = a5; end
    return;
end

if isNumericPoseArray(a2), starts = a2; end
if isNumericPoseArray(a3), goals = a3; end
if iscell(a4), globalPaths = a4; end
executedTraj = extractExecutedTraj(a5, numel(globalPaths));

end

function tf = isNumericPoseArray(x)
tf = isnumeric(x) && ~isempty(x) && ismatrix(x) && size(x,2) >= 3;
end

function n = sizeSafe(x, dim)
if isempty(x)
    n = 0;
else
    n = size(x, dim);
end
end

function traj = extractExecutedTraj(sim, nAgentsHint)
traj = {};

if isempty(sim)
    return;
end

if iscell(sim)
    traj = sim;
    return;
end

if isnumeric(sim) && ndims(sim) == 3 && size(sim,2) >= 3
    n = size(sim,3);
    traj = cell(1, n);
    for i = 1:n
        traj{i} = squeeze(sim(:,1:3,i));
    end
    return;
end

if isstruct(sim)
    if isfield(sim, 'traj') && iscell(sim.traj)
        traj = sim.traj; return;
    end
    if isfield(sim, 'trajectories') && iscell(sim.trajectories)
        traj = sim.trajectories; return;
    end
    if isfield(sim, 'paths') && iscell(sim.paths)
        traj = sim.paths; return;
    end
    if isfield(sim, 'history') && iscell(sim.history)
        traj = sim.history; return;
    end
    if isfield(sim, 'agents') && isstruct(sim.agents)
        n = numel(sim.agents);
        traj = cell(1, n);
        for i = 1:n
            a = sim.agents(i);
            if isfield(a, 'traj')
                traj{i} = a.traj;
            elseif isfield(a, 'path')
                traj{i} = a.path;
            elseif isfield(a, 'history')
                traj{i} = a.history;
            elseif isfield(a, 'posHist')
                traj{i} = a.posHist;
            end
        end
        return;
    end
    if isfield(sim, 'posHist')
        p = sim.posHist;
        if isnumeric(p) && ndims(p) == 3
            n = size(p,3);
            traj = cell(1, n);
            for i = 1:n
                traj{i} = squeeze(p(:,1:3,i));
            end
            return;
        end
    end
end

if nargin >= 2 && ~isempty(nAgentsHint)
    traj = cell(1, nAgentsHint);
end

end

function P = normalizePath(Pin)
P = [];
if isempty(Pin)
    return;
end

if iscell(Pin)
    if isempty(Pin)
        return;
    end
    Pin = Pin{1};
end

if isnumeric(Pin)
    if isvector(Pin) && numel(Pin) >= 3
        P = reshape(Pin(1:3), 1, 3);
        return;
    end

    if ismatrix(Pin)
        if size(Pin,2) >= 3
            P = Pin(:,1:3);
            return;
        elseif size(Pin,1) >= 3
            P = Pin(1:3,:).';
            return;
        end
    end
end
end
