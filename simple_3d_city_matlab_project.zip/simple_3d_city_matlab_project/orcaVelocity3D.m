function newVel = orcaVelocity3D(i, positions, velocities, prefVels, scene, orca)
% ORCA-inspired 3D half-space projection for agents and mixed obstacles.

pA = positions(i,:);
vA = velocities(i,:);
vPref = prefVels(i,:);

normals = zeros(0, 3);
bounds = zeros(0, 1);

for j = 1:size(positions,1)
    if j == i
        continue;
    end
    pB = positions(j,:);
    vB = velocities(j,:);
    relPos = pB - pA;
    dist = norm(relPos);
    if dist > orca.neighborDist || dist < 1e-9
        continue;
    end

    n = relPos / dist;
    R = 2 * orca.agentRadius + orca.separationMargin;
    safeGap = dist - R;

    if dist < R
        pushSpeed = (R - dist) / max(orca.dt, 1e-6);
        normals(end+1,:) = n; %#ok<AGROW>
        bounds(end+1,1) = dot(n, vB) - pushSpeed;
    else
        allowedClosing = max(safeGap / max(orca.timeHorizon, 1e-6), 0);
        closingRate = dot(n, vA - vB);
        if closingRate > allowedClosing
            normals(end+1,:) = n; %#ok<AGROW>
            bounds(end+1,1) = dot(n, vB) + allowedClosing;
        end
    end
end

if isfield(scene, 'spheres') && ~isempty(scene.spheres)
    for k = 1:size(scene.spheres,1)
        c = scene.spheres(k,1:3);
        rObs = scene.spheres(k,4);
        [normals, bounds] = addObstacleConstraint(pA, vA, c, rObs, normals, bounds, orca);
    end
end

if isfield(scene, 'cylinders') && ~isempty(scene.cylinders)
    for k = 1:size(scene.cylinders,1)
        cp = closestPointOnCylinderZ(pA, scene.cylinders(k,:));
        [normals, bounds] = addObstacleConstraint(pA, vA, cp, 0.0, normals, bounds, orca);
    end
end

if isfield(scene, 'noFlyCylinders') && ~isempty(scene.noFlyCylinders)
    for k = 1:size(scene.noFlyCylinders,1)
        cp = closestPointOnCylinderZ(pA, scene.noFlyCylinders(k,:));
        [normals, bounds] = addObstacleConstraint(pA, vA, cp, 0.0, normals, bounds, orca);
    end
end

if isfield(scene, 'boxes') && ~isempty(scene.boxes)
    for k = 1:size(scene.boxes,1)
        cp = closestPointOnAABB(pA, scene.boxes(k,:));
        [normals, bounds] = addObstacleConstraint(pA, vA, cp, 0.0, normals, bounds, orca);
    end
end

newVel = projectToHalfspaces3D(vPref, normals, bounds, orca.maxSpeed, orca.constraintPasses);
end

function [normals, bounds] = addObstacleConstraint(pA, vA, c, rObs, normals, bounds, orca)
rel = c - pA;
dist = norm(rel);
if dist < 1e-9
    return;
end
n = rel / dist;
R = rObs + orca.agentRadius + orca.separationMargin;
triggerDist = R + orca.obsTriggerMargin;
if dist > triggerDist
    return;
end
safeGap = dist - R;
if dist < R
    pushSpeed = orca.obsWeight * (R - dist) / max(orca.dt, 1e-6);
    normals(end+1,:) = n; %#ok<AGROW>
    bounds(end+1,1) = -pushSpeed;
else
    allowedClosing = orca.obsWeight * max(safeGap / max(orca.timeHorizon, 1e-6), 0);
    closingRate = dot(n, vA);
    if closingRate > allowedClosing
        normals(end+1,:) = n; %#ok<AGROW>
        bounds(end+1,1) = allowedClosing;
    end
end
end

function v = projectToHalfspaces3D(v0, normals, bounds, maxSpeed, passes)
v = v0;
for it = 1:passes
    for k = 1:size(normals,1)
        n = normals(k,:);
        rhs = bounds(k);
        val = dot(n, v);
        if val > rhs
            v = v - (val - rhs) * n;
        end
    end
    sp = norm(v);
    if sp > maxSpeed
        v = v * (maxSpeed / sp);
    end
end
end

function cp = closestPointOnCylinderZ(p, cyl)
xc = cyl(1); yc = cyl(2); r = cyl(3); zMin = cyl(4); zMax = cyl(5);
xy = p(1:2) - [xc yc];
rho = norm(xy);
if rho < 1e-9
    dir = [1 0];
else
    dir = xy / rho;
end
zClamped = min(max(p(3), zMin), zMax);
side = [xc yc] + r * dir;
cpSide = [side zClamped];

if p(3) < (zMin + zMax) / 2
    zCap = zMin;
else
    zCap = zMax;
end
if rho <= r
    capXY = p(1:2);
else
    capXY = [xc yc] + r * dir;
end
cpCap = [capXY zCap];

if norm(p - cpSide) <= norm(p - cpCap)
    cp = cpSide;
else
    cp = cpCap;
end
end

function cp = closestPointOnAABB(p, box)
cp = [min(max(p(1), box(1)), box(2)), ...
      min(max(p(2), box(3)), box(4)), ...
      min(max(p(3), box(5)), box(6))];

inside = p(1) >= box(1) && p(1) <= box(2) && ...
         p(2) >= box(3) && p(2) <= box(4) && ...
         p(3) >= box(5) && p(3) <= box(6);
if inside
    d = [p(1)-box(1), box(2)-p(1), p(2)-box(3), box(4)-p(2), p(3)-box(5), box(6)-p(3)];
    [~, idx] = min(d);
    switch idx
        case 1, cp = [box(1), p(2), p(3)];
        case 2, cp = [box(2), p(2), p(3)];
        case 3, cp = [p(1), box(3), p(3)];
        case 4, cp = [p(1), box(4), p(3)];
        case 5, cp = [p(1), p(2), box(5)];
        case 6, cp = [p(1), p(2), box(6)];
    end
end
end
