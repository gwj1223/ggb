function qNew = steerDubinsLike3D(qFrom, qTo, planner)
% Dubins-like local steering with bounded yaw/pitch change.

dir = qTo(1:3) - qFrom(1:3);
dist = norm(dir);
if dist < 1e-9
    qNew = qFrom;
    return;
end

[desYaw, desPitch] = vectorToYawPitch(dir);
newYaw = qFrom(4) + clamp(angleDiff(desYaw, qFrom(4)), -planner.maxYawPerStep, planner.maxYawPerStep);
newPitch = qFrom(5) + clamp(desPitch - qFrom(5), -planner.maxPitchPerStep, planner.maxPitchPerStep);
newPitch = min(max(newPitch, planner.minPitch), planner.maxPitch);

step = min(planner.stepLen, dist);
moveDir = [cos(newPitch) * cos(newYaw), ...
           cos(newPitch) * sin(newYaw), ...
           sin(newPitch)];
qNew = [qFrom(1:3) + step * moveDir, newYaw, newPitch];
end

function y = clamp(x, a, b)
y = min(max(x, a), b);
end

function [yaw, pitch] = vectorToYawPitch(v)
h = hypot(v(1), v(2));
yaw = atan2(v(2), v(1));
pitch = atan2(v(3), max(h, 1e-9));
end
