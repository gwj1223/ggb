function sim = simulateSwarmORCA3D(starts, goals, globalPaths, scene, orca)
% Follow global paths while doing ORCA-inspired local avoidance.

nAgents = size(starts, 1);
positions = starts(:,1:3);
orient = starts(:,4:5);
velocities = zeros(nAgents, 3);
reached = false(nAgents, 1);
wpIdx = 2 * ones(nAgents, 1);

history = cell(nAgents, 1);
for i = 1:nAgents
    history{i} = starts(i,:);
    if size(globalPaths{i},1) < 2
        wpIdx(i) = 1;
    end
end

time = 0;
for step = 1:orca.maxSteps
    pref = zeros(nAgents, 3);
    for i = 1:nAgents
        if reached(i)
            continue;
        end

        path = globalPaths{i};
        goalPos = goals(i,1:3);

        while wpIdx(i) < size(path,1) && norm(positions(i,:) - path(wpIdx(i),1:3)) < orca.waypointTol
            wpIdx(i) = wpIdx(i) + 1;
        end

        if wpIdx(i) > size(path,1)
            target = goalPos;
        else
            target = path(wpIdx(i),1:3);
        end

        toTarget = target - positions(i,:);
        d = norm(toTarget);
        if d < orca.finalGoalTol && norm(goalPos - positions(i,:)) < orca.finalGoalTol
            reached(i) = true;
            velocities(i,:) = [0 0 0];
            continue;
        end

        if d > 1e-9
            pref(i,:) = min(orca.maxSpeed, orca.goalGain * d) * toTarget / d;
        end
    end

    newVels = velocities;
    for i = 1:nAgents
        if reached(i)
            continue;
        end
        vCmd = orcaVelocity3D(i, positions, velocities, pref, scene, orca);
        dv = vCmd - velocities(i,:);
        maxDv = orca.maxAccel * orca.dt;
        ndv = norm(dv);
        if ndv > maxDv
            dv = dv * (maxDv / ndv);
        end
        vNew = velocities(i,:) + dv;
        sp = norm(vNew);
        if sp > orca.maxSpeed
            vNew = vNew * (orca.maxSpeed / sp);
        end
        newVels(i,:) = vNew;
    end

    for i = 1:nAgents
        if reached(i)
            history{i}(end+1,:) = [positions(i,:), orient(i,:)]; %#ok<AGROW>
            continue;
        end

        vTry = newVels(i,:);
        posNew = positions(i,:) + orca.dt * vTry;
        shrink = 1.0;
        while pointClearance3D(posNew, scene) <= orca.agentRadius && shrink > 0.05
            shrink = 0.6 * shrink;
            vTry = shrink * newVels(i,:);
            posNew = positions(i,:) + orca.dt * vTry;
        end
        if pointClearance3D(posNew, scene) <= orca.agentRadius
            vTry = [0 0 0];
            posNew = positions(i,:);
        end

        positions(i,:) = posNew;
        velocities(i,:) = vTry;
        if norm(vTry) > 1e-9
            orient(i,1) = atan2(vTry(2), vTry(1));
            orient(i,2) = atan2(vTry(3), max(hypot(vTry(1), vTry(2)), 1e-9));
        end
        history{i}(end+1,:) = [positions(i,:), orient(i,:)]; %#ok<AGROW>

        if norm(goals(i,1:3) - positions(i,:)) < orca.finalGoalTol
            reached(i) = true;
            velocities(i,:) = [0 0 0];
        end
    end

    time(end+1,1) = time(end) + orca.dt; %#ok<AGROW>
    if all(reached)
        break;
    end
end

sim.history = history;
sim.reached = reached;
sim.steps = numel(time) - 1;
sim.time = time;
end
