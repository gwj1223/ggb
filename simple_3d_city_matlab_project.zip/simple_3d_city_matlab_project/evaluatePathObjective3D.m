function [score, metrics] = evaluatePathObjective3D(path, scene, objective)
% Weighted multi-objective score for one UAV path.
% Lower is better.

metrics.length = sum(vecnorm(diff(path(:,1:3), 1, 1), 2, 2));
metrics.smoothness = sum(abs(angleDiff(path(2:end,4), path(1:end-1,4)))) + ...
                     0.6 * sum(abs(path(2:end,5) - path(1:end-1,5)));
metrics.altitudeChange = sum(abs(diff(path(:,3))));

samplePath = densifyPath3D(path, objective.sampleDs);
clearances = inf(size(samplePath,1), 1);
for i = 1:size(samplePath,1)
    clearances(i) = pointClearance3D(samplePath(i,1:3), scene);
end

metrics.minClearance = min(clearances);
metrics.clearancePenalty = max(0, objective.desiredClearance - metrics.minClearance) / max(objective.desiredClearance, 1e-9);
metrics.riskPenalty = mean(clearances < objective.desiredClearance);

w = objective.weights;
lengthTerm = metrics.length / max(objective.diagRef, 1e-9);
smoothTerm = metrics.smoothness / max(pi * max(size(path,1)-1, 1), 1e-9);
climbTerm = metrics.altitudeChange / max(objective.zRef, 1e-9);

score = w.length * lengthTerm + ...
        w.smoothness * smoothTerm + ...
        w.clearance * metrics.clearancePenalty + ...
        w.climb * climbTerm + ...
        w.risk * metrics.riskPenalty;
end
