function previewMap3D()
% previewMap3D
% Preview map: ground buildings + floating spheres.

[scene, starts, goals] = createDemoScene3D();

fig = figure('Color', 'w', ...
    'Name', 'Ground buildings + floating spheres', ...
    'NumberTitle', 'off', ...
    'Renderer', 'opengl', ...
    'Position', [90 70 1380 860]);

ax = axes('Parent', fig);
ax.Position = [0.05 0.08 0.82 0.84];
hold(ax, 'on');

drawScene3D(scene, starts, goals);
title(ax, 'Ground cuboids/cylinders + floating spheres (cool colors)', ...
    'FontWeight', 'bold', 'FontSize', 14);

try
    rotate3d(fig, 'on');
catch
    rotate3d on;
end

end
