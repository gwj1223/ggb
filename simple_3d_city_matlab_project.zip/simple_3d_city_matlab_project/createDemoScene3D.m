function [scene, starts, goals, planner, orca, objective] = createDemoScene3D()
% createDemoScene3D
% Full 5-UAV version:
%   - ground cuboid buildings
%   - ground cylindrical buildings
%   - floating spheres only
%   - 5 UAVs start from the same local area (not overlapping)
%   - 5 goals are intentionally spread out

scene.bounds = [0, 500, 0, 500, 0, 140];

%% ------------------------------------------------------------------------
% Flat ground
%% ------------------------------------------------------------------------
scene.terrain.enabled = false;
scene.terrain.res = 2.0;
scene.terrain.x = [];
scene.terrain.y = [];
scene.terrain.Z = [];
scene.terrain.heightAt = @(xq, yq) 0;

%% ------------------------------------------------------------------------
% Ground buildings / towers
%% ------------------------------------------------------------------------
% Format: [xmin xmax ymin ymax zmin zmax]
scene.boxes = [ ...
     70 135  85 155   0  34;   % lower-left small-medium
    170 255 285 365   0  58;   % upper-middle larger
    305 360 105 170   0  42;   % lower-middle compact
    105 205 215 295   0  48;   % left-middle wide block
    360 455 330 410   0  62;   % upper-right large block
    245 315 185 245   0  36;   % center medium low block
     55 115 355 430   0  44;   % upper-left narrow block
    385 455 185 255   0  40;   % right-middle block
    430 480  55 115   0  30;   % lower-right small edge block
    255 320 435 485   0  34;   % near top edge shallow block
     18  55 250 315   0  28];  % left edge slim block

% Format: [xc yc radius zmin zmax]
scene.cylinders = [ ...
    145 410 16   0  52;
    255  90 18   0  46;
    425 265 20   0  60;
    300 430 14   0  48;
    205 150 15   0  42;
     95 250 13   0  38;
    465 365 12   0  42;   % right edge tower
    340 470 11   0  36];  % top edge tower

%% ------------------------------------------------------------------------
% Air obstacles: floating spheres only
%% ------------------------------------------------------------------------
% Format: [xc yc zc radius]
scene.spheres = [ ...
    190 115 58 14;
    335 145 68 16;
    110 300 52 13;
    250 320 74 18;
    405 360 62 15;
    170 430 70 14;
    430 110 46 13;
    310 255 92 15;
     85 455 62 12;   % upper-left edge air sphere
    455 430 72 12;   % upper-right edge air sphere
    455 150 58 11];  % right-lower edge air sphere

scene.noFlyCylinders = [];

%% ------------------------------------------------------------------------
% Starts / goals
% 5 UAVs start from the same local area, but not exactly the same point.
% Goals are intentionally spread out.
%% ------------------------------------------------------------------------
starts = [ ...
    35  35  22  deg2rad(  5) deg2rad(0);
    43  35  22  deg2rad(  5) deg2rad(0);
    35  43  22  deg2rad(  5) deg2rad(0);
    43  43  22  deg2rad(  5) deg2rad(0);
    51  39  22  deg2rad(  5) deg2rad(0)];

goals = [ ...
    440 445 28  deg2rad(180) deg2rad(0);   % UAV 1: upper-right
    470 300 28  deg2rad(180) deg2rad(0);   % UAV 2: right-middle
    330 460 28  deg2rad(180) deg2rad(0);   % UAV 3: upper-middle
    390 145 28  deg2rad(180) deg2rad(0);   % UAV 4: lower-right
    120 465 28  deg2rad(  0) deg2rad(0)];  % UAV 5: upper-left

%% ------------------------------------------------------------------------
% Planner
%% ------------------------------------------------------------------------
planner.maxIter = 52000;
planner.stepLen = 5.5;
planner.maxYawPerStep = deg2rad(13);
planner.maxPitchPerStep = deg2rad(8);
planner.connectThreshold = 8.0;
planner.maxConnectSteps = 170;
planner.collisionCheckRes = 0.8;
planner.agentRadius = 2.5;

planner.goalBias = 0.22;
planner.corridorBias = 0.56;
planner.uniformBias = 0.22;

planner.corridorSigmaLat = 22.0;
planner.corridorSigmaVert = 12.0;
planner.goalSampleSigma = 10.0;

planner.smoothingPasses = 280;
planner.minPitch = deg2rad(-24);
planner.maxPitch = deg2rad(24);

planner.numCandidates = 42;
planner.densifyStep = 2.0;
planner.debug = false;

%% ------------------------------------------------------------------------
% ORCA
%% ------------------------------------------------------------------------
orca.dt = 0.20;
orca.maxSteps = 1200;
orca.maxSpeed = 7.0;
orca.goalGain = 1.25;
orca.waypointTol = 4.0;
orca.finalGoalTol = 5.0;

orca.neighborDist = 36.0;
orca.timeHorizon = 5.0;
orca.agentRadius = planner.agentRadius;
orca.maxAccel = 3.8;
orca.constraintPasses = 8;
orca.separationMargin = 1.4;
orca.obsTriggerMargin = 10.0;
orca.obsWeight = 1.10;

%% ------------------------------------------------------------------------
% Objective
%% ------------------------------------------------------------------------
objective.weights.length = 0.26;
objective.weights.smoothness = 0.22;
objective.weights.clearance = 0.30;
objective.weights.climb = 0.08;
objective.weights.risk = 0.14;

objective.desiredClearance = 10.0;
objective.sampleDs = 2.0;
objective.diagRef = norm([ ...
    scene.bounds(2)-scene.bounds(1), ...
    scene.bounds(4)-scene.bounds(3), ...
    scene.bounds(6)-scene.bounds(5)]);
objective.zRef = max(scene.bounds(6)-scene.bounds(5), 1e-6);

objective.minClrHard = 3.8;
objective.riskHard = 0.42;
objective.climbHard = 90.0;
objective.smoothHard = 2.30;

end
