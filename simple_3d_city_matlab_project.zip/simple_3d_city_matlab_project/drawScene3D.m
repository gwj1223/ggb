function drawScene3D(scene, starts, goals)
% drawScene3D
% Ground buildings + floating spheres renderer.
%
% Color separation:
%   cuboids   -> steel blue / slate
%   cylinders -> teal / cyan blue
%   spheres   -> lavender / violet-blue
%
% This keeps the three obstacle types visually distinct.

if nargin < 2, starts = []; end
if nargin < 3, goals  = []; end

ax = gca;
hold(ax, 'on');

set(ax, ...
    'Color', [1 1 1], ...
    'FontName', 'Times New Roman', ...
    'FontSize', 12, ...
    'LineWidth', 0.9, ...
    'GridAlpha', 0.08, ...
    'MinorGridAlpha', 0.05, ...
    'XColor', [0.15 0.15 0.15], ...
    'YColor', [0.15 0.15 0.15], ...
    'ZColor', [0.15 0.15 0.15]);

grid(ax, 'on');
box(ax, 'on');
axis(ax, 'vis3d');

xlim(ax, [scene.bounds(1), scene.bounds(2)]);
ylim(ax, [scene.bounds(3), scene.bounds(4)]);
zlim(ax, [scene.bounds(5), scene.bounds(6)]);

xlabel(ax, 'X (m)', 'FontWeight', 'bold');
ylabel(ax, 'Y (m)', 'FontWeight', 'bold');
zlabel(ax, 'Z (m)', 'FontWeight', 'bold');

pbaspect(ax, [1.28 1.10 0.46]);
view(ax, 36, 24);

drawGroundPlane(scene);
drawGuideBands(scene);

%% Ground cuboids: steel blue / slate
if isfield(scene, 'boxes') && ~isempty(scene.boxes)
    cuboidPalette = [...
        0.58 0.67 0.82;
        0.52 0.62 0.78;
        0.62 0.72 0.86;
        0.56 0.66 0.80;
        0.64 0.73 0.87;
        0.54 0.64 0.79];
    for k = 1:size(scene.boxes,1)
        c = cuboidPalette(mod(k-1, size(cuboidPalette,1)) + 1, :);
        drawCoolBox(scene.boxes(k,:), c, 0.82, 0.008, 0.020);
    end
end

%% Ground cylinders: teal / cyan blue
if isfield(scene, 'cylinders') && ~isempty(scene.cylinders)
    cylPalette = [...
        0.30 0.70 0.84;
        0.26 0.64 0.80;
        0.38 0.78 0.90;
        0.28 0.74 0.88];
    for k = 1:size(scene.cylinders,1)
        c = cylPalette(mod(k-1, size(cylPalette,1)) + 1, :);
        drawCoolCylinder(scene.cylinders(k,1), scene.cylinders(k,2), scene.cylinders(k,3), ...
            scene.cylinders(k,4), scene.cylinders(k,5), c, 0.95);
    end
end

%% Floating spheres: lavender / violet-blue
if isfield(scene, 'spheres') && ~isempty(scene.spheres)
    spherePalette = [...
        0.64 0.63 0.92;
        0.72 0.68 0.96;
        0.60 0.58 0.88;
        0.76 0.72 0.98;
        0.66 0.61 0.90;
        0.70 0.66 0.94];
    for k = 1:size(scene.spheres,1)
        s = scene.spheres(k,:);
        c = spherePalette(mod(k-1, size(spherePalette,1)) + 1, :);
        drawCoolSphere(s(1), s(2), s(3), s(4), c, 0.96);
    end
end

%% Start / goal markers
if isNumericPoseArray(starts)
    P = starts(:,1:3);
    scatter3(P(:,1), P(:,2), P(:,3), 52, ...
        'o', 'filled', ...
        'MarkerFaceColor', [0.12 0.44 0.84], ...
        'MarkerEdgeColor', [0.08 0.12 0.18], ...
        'LineWidth', 0.6, ...
        'DisplayName', 'Start');
end

if isNumericPoseArray(goals)
    P = goals(:,1:3);
    scatter3(P(:,1), P(:,2), P(:,3), 48, ...
        's', 'filled', ...
        'MarkerFaceColor', [0.22 0.74 0.94], ...
        'MarkerEdgeColor', [0.08 0.12 0.18], ...
        'LineWidth', 0.6, ...
        'DisplayName', 'Goal');
end

camproj(ax, 'perspective');
set(ax, 'AmbientLightColor', [0.95 0.96 0.99]);
lighting(ax, 'gouraud');
material(ax, 'dull');
camlight(ax, 'headlight', 'infinite');

fig = ancestor(ax, 'figure');
try
    rotate3d(fig, 'on');
catch
    rotate3d on;
end

end

function tf = isNumericPoseArray(x)
tf = isnumeric(x) && ~isempty(x) && ismatrix(x) && size(x,2) >= 3;
end

function drawGroundPlane(scene)
xmin = scene.bounds(1); xmax = scene.bounds(2);
ymin = scene.bounds(3); ymax = scene.bounds(4);
z0   = scene.bounds(5);

patch([xmin xmax xmax xmin], [ymin ymin ymax ymax], z0*ones(1,4), ...
    [0.975 0.978 0.985], ...
    'EdgeColor', 'none', ...
    'FaceAlpha', 1.0, ...
    'FaceLighting', 'none');
end

function drawGuideBands(scene)
xmin = scene.bounds(1); xmax = scene.bounds(2);
ymin = scene.bounds(3); ymax = scene.bounds(4);
z0   = scene.bounds(5) + 0.02;

bands = { ...
    [xmin xmax xmax xmin], [212 212 242 242]; ...
    [xmin xmax xmax xmin], [352 352 382 382]; ...
    [102 132 132 102], [ymin ymin ymax ymax]; ...
    [252 282 282 252], [ymin ymin ymax ymax]; ...
    [392 422 422 392], [ymin ymin ymax ymax]};

for i = 1:size(bands,1)
    patch(bands{i,1}, bands{i,2}, z0*ones(1,4), [0.91 0.93 0.97], ...
        'EdgeColor', 'none', ...
        'FaceAlpha', 1.0, ...
        'FaceLighting', 'none');
end
end

function drawCoolBox(b, baseColor, alphaVal, roofDelta, sideDelta)
xmin = b(1); xmax = b(2);
ymin = b(3); ymax = b(4);
zmin = b(5); zmax = b(6);

roofColor = min(baseColor + roofDelta, 1.0);
sideA     = max(baseColor - 0.010, 0);
sideB     = max(baseColor - sideDelta, 0);
edgeColor = max(baseColor - 0.25, 0);

V = [...
    xmin ymin zmin;
    xmax ymin zmin;
    xmax ymax zmin;
    xmin ymax zmin;
    xmin ymin zmax;
    xmax ymin zmax;
    xmax ymax zmax;
    xmin ymax zmax];

faces = { ...
    [1 2 6 5], sideA; ...
    [2 3 7 6], sideB; ...
    [3 4 8 7], sideA; ...
    [4 1 5 8], sideB; ...
    [5 6 7 8], roofColor};

for i = 1:size(faces,1)
    patch('Vertices', V, 'Faces', faces{i,1}, ...
        'FaceColor', faces{i,2}, ...
        'FaceAlpha', alphaVal, ...
        'EdgeColor', edgeColor, ...
        'LineWidth', 0.75, ...
        'AmbientStrength', 0.92, ...
        'DiffuseStrength', 0.10, ...
        'SpecularStrength', 0.00);
end
end

function drawCoolSphere(xc, yc, zc, r, colorVal, alphaVal)
[XS, YS, ZS] = sphere(42);
surf(r*XS + xc, r*YS + yc, r*ZS + zc, ...
    'FaceColor', colorVal, ...
    'FaceAlpha', alphaVal, ...
    'EdgeColor', 'none', ...
    'AmbientStrength', 0.92, ...
    'DiffuseStrength', 0.08, ...
    'SpecularStrength', 0.00);
end

function drawCoolCylinder(xc, yc, r, z0, z1, colorVal, alphaVal)
n = 60;
theta = linspace(0, 2*pi, n);
x = xc + r*cos(theta);
y = yc + r*sin(theta);

X = [x; x];
Y = [y; y];
Z = [z0*ones(1,n); z1*ones(1,n)];

surf(X, Y, Z, ...
    'FaceColor', colorVal, ...
    'FaceAlpha', alphaVal, ...
    'EdgeColor', 'none', ...
    'AmbientStrength', 0.92, ...
    'DiffuseStrength', 0.10, ...
    'SpecularStrength', 0.00);

patch(x, y, z1*ones(1,n), colorVal, ...
    'EdgeColor', 'none', ...
    'FaceAlpha', min(alphaVal, 1.0), ...
    'AmbientStrength', 0.92, ...
    'DiffuseStrength', 0.10, ...
    'SpecularStrength', 0.00);
end
