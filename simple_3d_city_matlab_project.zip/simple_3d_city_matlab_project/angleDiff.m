function d = angleDiff(a, b)
% Wrapped angle difference a-b in [-pi, pi].
d = atan2(sin(a - b), cos(a - b));
end
