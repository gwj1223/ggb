function path = birrtDubinsPlan3D(startState, goalState, scene, planner)
% 3D BiRRT with biased sampling and Dubins-like steering.

path = [];

treeA.q = startState;
treeA.parent = 0;
treeB.q = goalState;
treeB.parent = 0;

swapped = false;

for iter = 1:planner.maxIter
    qRand = biasedSample3D(scene, startState, goalState, planner);

    [treeA, idxA, added] = extendTree(treeA, qRand, scene, planner);
    if added
        qNew = treeA.q(idxA,:);
        [treeB, idxB, connected] = connectTree(treeB, qNew, scene, planner);
        if connected
            if ~swapped
                p1 = backtrackPath(treeA, idxA);
                p2 = backtrackPath(treeB, idxB);
                path = [p1; flipud(p2(1:end-1,:))];
            else
                p1 = backtrackPath(treeB, idxB);
                p2 = backtrackPath(treeA, idxA);
                path = [p1; flipud(p2(1:end-1,:))];
            end
            path = smoothPath3D(path, scene, planner);
            return;
        end
    end

    tmp = treeA;
    treeA = treeB;
    treeB = tmp;
    swapped = ~swapped;
end
end

function [tree, idxNew, added] = extendTree(tree, qTarget, scene, planner)
idxNew = size(tree.q, 1);
added = false;

idxNear = nearestNodeIndex(tree.q, qTarget);
qNear = tree.q(idxNear,:);
qNew = steerDubinsLike3D(qNear, qTarget, planner);
qNew(1:3) = clampPointToBounds(qNew(1:3), scene.bounds, planner.agentRadius);

if collisionFreeSegment3D(qNear, qNew, scene, planner)
    tree.q(end+1,:) = qNew;
    tree.parent(end+1,1) = idxNear;
    idxNew = size(tree.q, 1);
    added = true;
end
end

function [tree, idxNew, connected] = connectTree(tree, qTarget, scene, planner)
connected = false;
idxNew = size(tree.q, 1);

for s = 1:planner.maxConnectSteps
    [tree, idxNew, added] = extendTree(tree, qTarget, scene, planner);
    if ~added
        return;
    end
    if norm(tree.q(idxNew,1:3) - qTarget(1:3)) <= planner.connectThreshold
        connected = true;
        return;
    end
end
end

function idx = nearestNodeIndex(qList, qTarget)
dPos = vecnorm(qList(:,1:3) - qTarget(1:3), 2, 2);
dYaw = abs(angleDiff(qList(:,4), qTarget(4)));
dPitch = abs(qList(:,5) - qTarget(5));
score = dPos + 0.7 * dYaw + 0.5 * dPitch;
[~, idx] = min(score);
end

function path = backtrackPath(tree, idx)
path = tree.q(idx,:);
while tree.parent(idx) ~= 0
    idx = tree.parent(idx);
    path = [tree.q(idx,:); path]; %#ok<AGROW>
end
end

function path = smoothPath3D(path, scene, planner)
if size(path,1) <= 3
    return;
end

for it = 1:planner.smoothingPasses
    n = size(path,1);
    if n <= 3
        break;
    end
    i = randi([1, n-2]);
    j = randi([i+2, n]);
    if collisionFreeSegment3D(path(i,:), path(j,:), scene, planner)
        path = [path(1:i,:); path(j:end,:)];
    end
end

for k = 1:size(path,1)-1
    vec = path(k+1,1:3) - path(k,1:3);
    [yaw, pitch] = vectorToYawPitch(vec);
    path(k,4) = yaw;
    path(k,5) = pitch;
end
path(end,4:5) = path(end-1,4:5);
end

function p = clampPointToBounds(p, b, margin)
p(1) = min(max(p(1), b(1) + margin), b(2) - margin);
p(2) = min(max(p(2), b(3) + margin), b(4) - margin);
p(3) = min(max(p(3), b(5) + margin), b(6) - margin);
end

function [yaw, pitch] = vectorToYawPitch(v)
h = hypot(v(1), v(2));
yaw = atan2(v(2), v(1));
pitch = atan2(v(3), max(h, 1e-9));
end
