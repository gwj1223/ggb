function r = run_uav1_only_v723()
%RUN_UAV1_ONLY_V723 Focused v7.2.3 Dense-first decoder verification.
r=localRun(1);
end

function r=localRun(uavId)
projectRoot=fileparts(mfilename('fullpath'));
setupProject(projectRoot);
cfg=config.multiUAVShiyanConfig();
[problem,cfg]=realdata.buildShiyanG1Problem(projectRoot,cfg);
assignment=multiUAV.allocateTargetsObservabilityAware(problem,cfg);
[subProblem,subCfg]=multiUAV.buildSubProblem(problem,cfg,assignment,uavId);
config.validateConfig(subCfg,subProblem);
layout=core.structuredMonitoringLayout(subProblem,subCfg);
fprintf('\n=== v7.2.3 UAV-%d focused verification ===\n',uavId);
fprintf('seed=%d targets=%d waypoints=%d semantic=%dD phenotype=%dD\n', ...
    subCfg.randomSeed,size(subProblem.monitorTargets,1),subCfg.numWaypoints, ...
    layout.dimension,3*subCfg.numWaypoints);
fprintf('global targets=[%s]\n',num2str(assignment.groups{uavId}));
r=core.runGRAHMODE(subProblem,subCfg);
b=r.best(1);
localPrintFinal(r,b,subCfg,uavId);
end

function localPrintFinal(r,b,subCfg,uavId)
fprintf('\n--- UAV-%d final ---\n',uavId);
fprintf('FinalFeasible=%d | D=%.6f | staticCV=%.6g\n', ...
    r.bestSolutionSatisfiesFinalConstraints, ...
    evaluation.finalMonitoringDeficit(b,subCfg),b.staticCV);
fprintf('viol[col/clr/clm/trn/E]=[%.6g %.6g %.6g %.6g %.6g]\n', ...
    b.violation.collision,b.violation.clearance,b.violation.climb, ...
    b.violation.turn,b.violation.energy);
if isfield(b,'encodingInfo') && isstruct(b.encodingInfo)
    info=b.encodingInfo;
    if isfield(info,'connectorCount') && ~isempty(info.connectorCount)
        fprintf('connectorCount=[%s]\n',num2str(info.connectorCount(:)'));
    end
    if isfield(info,'primaryConnectorCount') && ~isempty(info.primaryConnectorCount)
        fprintf('primaryConnectorCount=[%s]\n',num2str(info.primaryConnectorCount(:)'));
    end
    if isfield(info,'topologyIndex')
        fprintf('topologyIndex=%d\n',info.topologyIndex);
    elseif isfield(info,'bestDenseTopologyIndex')
        fprintf('bestDenseTopologyIndex=%d\n',info.bestDenseTopologyIndex);
    end
    if isfield(info,'routeMode')
        fprintf('routeMode=%s',char(info.routeMode));
        if isfield(info,'tangentBlend') && isfinite(info.tangentBlend)
            fprintf(' blend=%.2f',info.tangentBlend);
        end
        fprintf('\n');
    elseif isfield(info,'bestDenseMode') && ~isempty(info.bestDenseMode)
        fprintf('bestDenseMode=%s',char(info.bestDenseMode));
        if isfield(info,'bestDenseBlend') && isfinite(info.bestDenseBlend)
            fprintf(' blend=%.2f',info.bestDenseBlend);
        end
        fprintf('\n');
    end
    if isfield(info,'reason') && isfield(info,'maxTurnDeg')
        fprintf('decode=%s | dense=%d | maxTurn=%.3f deg\n', ...
            char(info.reason),isfield(info,'denseSuccess') && info.denseSuccess,info.maxTurnDeg);
    end
    if isfield(info,'reachAttempts')
        fprintf('reachAttempts=%d\n',info.reachAttempts);
    end
    if isfield(info,'reachFailureSegments') && ~isempty(info.reachFailureSegments)
        seg=info.reachFailureSegments(:);
        counts=accumarray(seg,1,[max(seg) 1]);
        [sorted,idx]=sort(counts,'descend');
        fprintf('reachFailSeg:');
        shown=0;
        for q=1:numel(idx)
            if sorted(q)<=0, continue; end
            fprintf(' seg%d=%d',idx(q),sorted(q));
            shown=shown+1;
            if shown>=8, break; end
        end
        fprintf('\n');
    end
end
fprintf('Qmin=%.4f Qcritical=%.4f CriticalObs=%.2f CriticalLOS=%.4f\n', ...
    b.monitorStats.minimumQuality,b.monitorStats.criticalQuality, ...
    b.monitorStats.minimumCriticalObservationLength, ...
    b.monitorStats.minimumCriticalLOSRatio);
localPrintPerformanceAndEngineering(r);
end

function localPrintPerformanceAndEngineering(r)
if isfield(r,'reportedSolutionLabel')
    fprintf('Reported=%s level=%s strictEngineering=%d\n', ...
        char(r.reportedSolutionLabel),char(r.reportedSolutionSelectionLevel), ...
        isfield(r,'reportedStrictEngineeringLimitsSatisfied') && ...
        r.reportedStrictEngineeringLimitsSatisfied);
end
if isfield(r,'reportedStrictEngineeringDiagnostics') && ...
        ~isempty(r.reportedStrictEngineeringDiagnostics)
    d=r.reportedStrictEngineeringDiagnostics;
    failed=d(~reshape([d.passed],[],1));
    for ii=1:numel(failed)
        fprintf('  strict FAIL %-28s value=%.6g %s limit=%.6g\n', ...
            failed(ii).name,failed(ii).value,failed(ii).relation,failed(ii).limit);
    end
end
if isfield(r,'performance') && isstruct(r.performance) && ...
        isfield(r.performance,'structuredTrialDecoderTime_s')
    p=r.performance;
    fprintf(['Perf trialDecoder=%.1fs denseProjection=%.1fs terrainSampling=%.1fs ' ...
        'reach=%d cacheHitRate=%.1f%%\n'], ...
        p.structuredTrialDecoderTime_s,p.structuredTrialDenseProjectionTime_s, ...
        p.structuredTrialTerrainSamplingTime_s,p.structuredTrialReachAttempts, ...
        100*p.structuredTrialTerrainCacheHitRate);
end
end

