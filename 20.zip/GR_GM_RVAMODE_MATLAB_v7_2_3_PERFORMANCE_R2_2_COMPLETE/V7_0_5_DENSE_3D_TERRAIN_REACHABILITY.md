# GR-GM-RVAMODE-VI v7.0.5 — Dense-3D Terrain Reachability A3

## Why this version exists

The v7.0.4 Shiyan-G1 trace proved that the unified A3 repair can work: at
Generation 75 two screened trials became eligible replacements and the best
mission deficit fell from about 0.8845 to 0.8709. However, most subsequent A3
trials still failed the static gate because waypoint-level altitude projection
did not guarantee the straight waypoint-to-waypoint segments satisfied the
same dense DEM AGL contract used by formal evaluation.

The remaining failure was a sparse-to-dense feasibility gap:

1. A3 fixed XY geometry first and projected Z only at chromosome waypoints.
2. Formal AGL evaluation sampled the complete segment every ~15 m.
3. Narrow ridges/valleys between waypoints could therefore violate the
   60--320 m AGL envelope even when both endpoint waypoints were legal.
4. Fixed-count segment repair used a different terrain sampling contract.
5. Infeasible XY/Z combinations could still reach expensive full evaluation.

## v7.0.5 active A3 path

```
static-feasible current base
        |
        v
largest mission-bottleneck target
        |
        v
9 cheap radius/sector geometry candidates
        |
        v
adaptive 7/9 -> up to 13 waypoint local block
        |
        v
shared ~15 m DEM sampling on every straight segment
        |
        v
toolbox-free dense AGL + climb reachability projection
        |
        v
3D turn precheck
        |
        v
rank by vertical slack / detour
        |
        v
only top 3 screened candidates receive full evaluation
        |
        v
protected target-progress acceptance
        |
        v
base -> repaired trial replacement
```

## Dense straight-segment reachability

For every adaptive terrain sample on a segment between chromosome nodes i and
j, the actual straight-line altitude is

```
z(t) = (1-t) z_i + t z_j.
```

The candidate is screened against the same terrain envelope as formal
execution:

```
terrain(t) + 60 <= z(t) <= terrain(t) + 320
```

(with the existing repair margin on editable interior samples), while node
altitude transitions also satisfy the unchanged 22 degree climb limit.
`core.projectDenseTerrainReachableProfile` searches node altitudes with a
small toolbox-free dynamic program. Dense samples are constraints on the
straight segment; they are not virtual extra Z waypoints.

## No infeasible fallback

If a geometry has no dense AGL/climb solution, it is rejected before full
objective evaluation. v7.0.4's emergency flat-shelf fallback is not used by
the active v7.0.5 path.

## Shared hard-AGL sampling contract

The following now use `evaluation.sampleSegmentTerrainAdaptive`:

- `evaluation.evaluateLocalAGLEnvelope`
- `repair.repairSegmentClearance`
- `core.projectDenseTerrainReachableProfile`

Thus repair and formal evaluation see the same physical-distance DEM grid.

## Evaluation budget

The geometry pool is cheap screening only. The formal A3 budget is unchanged:

- up to 4 bases per checkpoint;
- top 3 screened candidates per base;
- at most 12 full evaluations per A3 event.

## Unchanged formal experiment contract

- 5 objectives;
- population 96;
- maximum 220 generations;
- Formation starts at Generation 25;
- Formal stage starts at Generation 100;
- Qmin = 0.33;
- Critical Q = 0.42;
- Critical observation length = 180 m;
- Critical LOS ratio = 0.45;
- AGL = 60--320 m;
- max climb = 22 degrees;
- max turn = 95 degrees;
- A1 remains search guidance;
- one Unified A3 remains the only population-level mission recovery operator;
- A6 remains final risk-balanced representative selection.

No Target Memory, Mission Carrier Restore, Persistent Repair, Emergency Repair,
or sixth objective is reintroduced.

## New A3 diagnostic

A3 logs now include:

```
geom / preOK / eval / replace / eligible
preRej[reach/turn/other]
slack / block
static[col/clr/clm/trn/E]
AGL[lo/hi]
```

This separates cheap geometry infeasibility from failures after full objective
evaluation.
