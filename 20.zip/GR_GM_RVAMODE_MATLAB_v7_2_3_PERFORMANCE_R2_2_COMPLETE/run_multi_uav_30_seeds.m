%RUN_MULTI_UAV_30_SEEDS v7.0.0 formal runner alias.
run_multi_uav_30_seeds_v700;
