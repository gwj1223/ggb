# v7.0.0 — Logic-Consolidated Mission-Feasibility Architecture

## 1. Why this release exists

The v6.5.x–v6.6.0 line progressively solved real failures, but the monitoring subsystem accumulated overlapping mechanisms: coverage preservation, target memory, Mission Carrier restoration, persistent repair, Critical corridor memory, emergency reinjection and cooldown logic. Each mechanism was locally reasonable, but together they created a repeated pattern:

`search -> monitoring structure damaged -> repair -> historical solution restored -> search damages it again`.

The v6.5.9 gate also showed that the flight envelope was no longer the main bottleneck: AGL and collision were 15/15, while mission success was 7/15 and seven of eight failures had Critical observation length below 180 m. v7.0.0 therefore does not add another repair layer. It consolidates mission feasibility into one explicit ranking quantity and one repair pathway.

## 2. Invariants kept unchanged

The paper structure remains A1 + A3 + A6.

- A1: monitoring-guided initialization.
- A3: mission-aware observation repair/preservation.
- A6: risk-balanced representative selection.

The five inner objectives remain exactly:

1. path-efficiency / detour objective;
2. geological risk (mean + tail/CVaR);
3. energy (propulsion + observation + equivalent hover);
4. smoothness (turn / vertical / curvature);
5. monitoring loss.

Formal thresholds are unchanged:

- `Qmin >= 0.33`;
- `Qcritical >= 0.42`;
- every Critical target observation length `>= 180 m`;
- every Critical target LOS `>= 0.45`;
- AGL `60–320 m`;
- max climb `22 deg`;
- fleet safe separation `80 m`.

Shiyan-G1 settings remain population 96, maximum generation 220, 30 targets, 6 Critical targets and 3 UAVs with exact 10/10/10 target and 2/2/2 Critical quotas.

## 3. Final v7.0.0 architecture

```text
Real DEM + risk proxy + monitoring targets
              |
              v
Static Monitoring Knowledge Base
(DEM/LOS score, best radius, best visible sector)
              |
              v
Observability/risk/route-aware cooperative allocation
              |
      +-------+-------+
      |       |       |
     UAV1    UAV2    UAV3
      |       |       |
      +-------+-------+
              |
              v
A1 monitoring-guided initialization
              |
              v
Five-objective GR-GM-RVAMODE search
              |
              v
Static-first + Unified Mission Deficit epsilon ranking
              |
              v
ONE A3: Unified Mission Repair
              |
              v
Formal feasible Pareto archive + A6 risk-balanced selection
              |
              v
Dense AGL validation + temporal launch scheduling
```

This is a hierarchical/decomposed multi-UAV planner, not a fully joint trajectory optimizer. The allocation is cooperative at the upper layer; each UAV path is optimized independently using the same physical/monitoring model; temporal deconfliction follows.

## 4. Static Monitoring Knowledge Base

`multiUAV.buildMonitoringKnowledgeBase` stores deterministic task-side information only:

- observability score/difficulty;
- visible and valid viewpoint fractions;
- longest visible arc;
- target-specific best radius scale;
- best contiguous visible-sector centre and half-width;
- Critical flag.

It never stores an evolutionary individual, genes, chromosome or historical path. The same knowledge is consumed by allocation, A1 initialization and A3 repair. Therefore "knowledge guidance" and "historical solution restoration" are completely separated.

## 5. Unified Mission Deficit D_M

Mission feasibility is represented by four normalized formal deficits:

```text
d_Q    : all-target Qmin requirement
d_C    : aggregate Critical-quality requirement
d_L    : all-Critical observation-length requirement
d_LOS  : all-Critical LOS requirement
```

For each target quality:

`d_qj = clamp((0.33 - Q_j)/0.33, 0, 1)`.

The all-target quality component uses a worst-dominant blend so one lost target cannot be hidden by many good targets.

Critical quality:

`d_C = clamp((0.42 - Qcritical)/0.42, 0, 1)`.

For every Critical target j:

`d_Lj = clamp((180 - L_j)/180, 0, 1)`

`d_LOSj = clamp((0.45 - LOS_j)/0.45, 0, 1)`.

Critical geometry components are also worst-dominant across Critical targets.

Let `d = [d_Q d_C d_L d_LOS]` and normalized weights `w=[0.40 0.15 0.30 0.15]`. The scalar is Chebyshev-dominant:

`D_M = (1-rho)*max(d) + rho*sum(w .* d)`, with `rho=0.15`.

Consequences:

- `D_M = 0` iff every formal monitoring requirement is satisfied;
- one catastrophic component cannot be compensated by three good components;
- `D_M` is a constraint-ranking quantity, not a sixth objective.

## 6. Strict selection hierarchy

The existing Deb/reference-vector selector is retained. v7.0.0 encodes three tiers through CV:

### Tier 1 — static feasible and inside current mission epsilon

`staticCV <= tol` and `D_M <= epsilon(g)`.

These individuals are feasible and compete using the original five-objective Pareto/reference-vector selection.

### Tier 2 — static feasible but mission-incomplete

`staticCV <= tol` and `D_M > epsilon(g)`.

Their CV is the mission excess `D_M - epsilon(g)`. Smaller mission deficit is preferred.

### Tier 3 — static infeasible

Their CV is `1 + staticCV`.

Because `D_M` is bounded by 1, a static-infeasible path cannot outrank a static-feasible mission-forming path merely because its monitoring values are attractive.

The intended ordering is therefore:

`flight feasibility > mission formation > five-objective Pareto quality`.

## 7. One synchronized mission schedule

v7.0.0 removes independent Q/Qcritical/Observation/LOS threshold advancement from the active multi-UAV path.

- Generation 1–24: **exploration**, epsilon = 1.
- Generation 25–99: **mission formation**, epsilon decreases linearly from 1 to 0.
- Generation 100+: **formal**, epsilon = 0 and all four formal thresholds are committed together.

Therefore the old late-run state such as

`[Qmin threshold=0, Qcritical=0.42, observation=180, LOS=0.45]`

cannot occur in the v7.0.0 default multi-UAV path.

The separate Final Archive always re-evaluates candidates with explicit `epsilon=0`, even during exploration/formation. An epsilon-feasible formation candidate is never mislabeled as final-formal feasible.

## 8. A1 — shared observability-guided initialization

A1 uses the same Monitoring Knowledge Base as the upper-layer allocator and A3. Critical targets may use five observation viewpoints; ordinary targets use the configured guided arc. Target-specific best radius and best visible-sector direction replace a one-radius/one-direction assumption.

A1 remains guidance only; physical feasibility is still enforced by the standard path repair/evaluation stack.

## 9. A3 — ONE Unified Mission Repair

`core.unifiedMissionRepair` is the only population-level complete observation-corridor repair in the active v7.0.0 path.

At each repair checkpoint:

1. consider only current **static-feasible** individuals;
2. rank bases by `D_M`;
3. identify the target with the largest formal mission urgency;
4. construct at most three DEM/LOS-guided local corridor variants;
5. apply ordinary flight/path repair and full evaluation;
6. hard-reject a static-infeasible trial;
7. require `D_M` improvement;
8. forbid breaking any formal component/target condition that the base already satisfied;
9. submit accepted trials to normal environmental selection rather than force-inserting them.

The repair is bounded to 12 full evaluations per checkpoint and aims to maintain up to three formal current-population carriers. It does not use historical chromosomes.

Full observation-arc jumps were removed from `operators.generateTrial`. Strategy 3 remains local differential monitoring-aware search; complete topological corridor edits belong exclusively to Unified Mission Repair.

Formal-stage local search starts only at generation 100 and is used for cost refinement of mission-feasible solutions, not as a second mission-recovery pathway.

## 10. Mechanisms removed from the final package

The following chromosome-restoration implementations and their tests are removed:

- Target Memory individual storage/restoration;
- Mission Carrier individual restoration;
- Critical Observation Corridor individual memory;
- population coverage-preservation reinjection;
- Persistent Target Repair escalation;
- emergency whole-population monitoring reinjection;
- independent DE full observation-arc jump.

There are no restoration/cooldown counters in the v7 batch/reporting schema. The only A3 workload counters are:

- `UnifiedMissionRepairEvents`;
- `UnifiedMissionRepairEvaluations`;
- `UnifiedMissionRepairAccepted`.

## 11. Upper-layer cooperative allocation

The v6.5.9 observability-aware allocation principle is retained because allocation-only evidence showed useful balancing with very small route cost. It still enforces exact target/Critical quotas and refines pair swaps using route, load, risk and observability balance. These quantities are upper-level allocation proxies, not extra inner objectives.

## 12. A6 and final engineering safety

A6 risk-balanced representative selection is unchanged. Dense final AGL repair/verification and temporal launch scheduling are also unchanged. Mission success requires:

- all UAV reported solutions final-feasible;
- fleet monitoring satisfied;
- collision free;
- sampled AGL envelope valid.

## 13. New clean experiment schema

`fleet_summary.csv` and batch summaries report:

- physical/safety metrics;
- Qavg, Qmin, Qcritical;
- `MissionDeficit` and its four components;
- Critical observation/LOS worst-target diagnostics;
- Unified Mission Repair workload;
- allocation balance diagnostics.

Legacy memory/persistent-repair fields are intentionally absent.

## 14. MATLAB validation order

From the project root:

```matlab
restoredefaultpath;
clear functions;
clear classes;
rehash toolboxcache;
setupProject(pwd);
run_all_tests
```

Then inspect geometry if desired:

```matlab
analyze_target_observability_v700
```

Only after the tests pass, run the fixed gate:

```matlab
run_multi_uav_gate15_v700
```

The gate uses the same 10 former difficult seeds plus 5 control seeds:

`[4 9 14 18 19 20 24 25 26 28 3 7 8 10 16]`.

Formal experiment after gate acceptance:

```matlab
run_multi_uav_30_seeds_v700
```

## 15. Freeze criterion

The final paper target remains:

- MissionSuccess >= 27/30;
- UAV1 ControllerFinal >= 27/30;
- UAV2 ControllerFinal >= 28/30;
- UAV3 ControllerFinal = 30/30;
- AllAGLOK = 30/30;
- CollisionFree = 30/30;
- no material route/risk/energy regression;
- Unified Mission Repair workload remains bounded rather than becoming a new hidden brute-force search.

If v7.0.0 fails this criterion, diagnose the remaining single bottleneck. Do not reintroduce the removed overlapping memory/repair layers.
