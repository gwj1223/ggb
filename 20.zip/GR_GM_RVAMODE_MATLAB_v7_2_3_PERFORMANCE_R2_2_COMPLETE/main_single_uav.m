clear; clc; close all;
projectRoot = fileparts(mfilename('fullpath'));
setupProject(projectRoot);
cfg = config.shiyanG1Config();
[problem,cfg,scene] = realdata.buildShiyanG1Problem(projectRoot,cfg); %#ok<NASGU>
result = core.runGRAHMODE(problem,cfg);
visualization.plotShiyanG1Result(problem,result,cfg);

b = result.best(1);
fprintf('\n=== GR-GM-RVAMODE-VI Shiyan-G1 optimized implementation ===\n');
fprintf('Scene                       : %s\n',problem.sceneId);
fprintf('DEM elevation range         : %.1f - %.1f m\n', ...
    min(problem.terrain(:)),max(problem.terrain(:)));
fprintf('ROI extent                  : %.2f x %.2f km\n', ...
    diff(problem.xBounds)/1000,diff(problem.yBounds)/1000);
if isfield(result,'reportedSolutionLabel')
    fprintf('Reported solution           : %s\n',result.reportedSolutionLabel);
end
if isfield(result,'reportedSolutionSelectionLevel')
    fprintf('Reported selection level    : %s\n',result.reportedSolutionSelectionLevel);
end
fprintf('Path length                 : %.3f km\n',b.pathMetrics.rawLength/1000);
fprintf('Detour ratio                : %.4f\n',b.pathMetrics.detourRatio);
fprintf('Risk objective              : %.4f\n',b.riskStats.objective);
fprintf('Mean / tail risk            : %.4f / %.4f\n', ...
    b.riskStats.meanRisk,b.riskStats.tailRisk);
fprintf('Energy score                : %.4f\n',b.energyStats.total);
fprintf('Smoothness                  : %.4f\n',b.objectives(4));
fprintf('Minimum target quality      : %.4f\n',b.monitorStats.minimumQuality);
fprintf('Critical target quality     : %.4f\n',b.monitorStats.criticalQuality);
fprintf('Critical min obs. length    : %.1f m\n', ...
    b.monitorStats.minimumCriticalObservationLength);
fprintf('Critical min LOS quality    : %.4f\n', ...
    b.monitorStats.minimumCriticalLOSRatio);
fprintf('Final monitoring deficit    : %.4f\n', ...
    evaluation.finalMonitoringDeficit(b,cfg));
fprintf('Final archive size          : %d\n',numel(result.finalArchive));
if isfield(result,'commonArchive')
    fprintf('Common archive size         : %d\n',numel(result.commonArchive));
end
fprintf('Optimization time           : %.2f s\n',result.totalOptimizationTime);

if cfg.saveResults
    out = exporter.saveRun(problem,result,cfg,projectRoot);
    realdata.exportGeographicPath(problem,result,out);
    realdata.exportSceneMetadata(problem,out);
    manifest = fullfile(projectRoot,'data_real','processed', ...
        'Shiyan_G1_source_manifest.json');
    if isfile(manifest)
        copyfile(manifest,fullfile(out,'Shiyan_G1_source_manifest.json'));
    else
        warning('main:MissingSourceManifest', ...
            'Source manifest was not found: %s',manifest);
    end
    fprintf('Results saved to            : %s\n',out);
end
