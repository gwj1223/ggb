clear; clc; close all;
projectRoot = fileparts(mfilename('fullpath'));
setupProject(projectRoot);
cfg = config.shiyanG1Config();
cfg.populationSize = 60;
cfg.maxGenerations = 90;
cfg.archiveSize = 90;
cfg.commonArchiveSize = 110;
cfg.hvSamples = 2500;
cfg.verboseEvery = 5;
cfg.saveFigures = true;
[problem,cfg] = realdata.buildShiyanG1Problem(projectRoot,cfg);
result = core.runGRAHMODE(problem,cfg);
visualization.plotShiyanG1Result(problem,result,cfg);
b=result.best(1);
fprintf('Shiyan-G1 FAST | L=%.2f km Risk=%.3f Tail=%.3f Qmin=%.3f Final=%d\n', ...
    b.pathMetrics.rawLength/1000,b.riskStats.objective,b.riskStats.tailRisk, ...
    b.monitorStats.minimumQuality,result.bestSolutionSatisfiesFinalConstraints);
if cfg.saveResults
    out=exporter.saveRun(problem,result,cfg,projectRoot);
    realdata.exportGeographicPath(problem,result,out);
    realdata.exportSceneMetadata(problem,out);
    manifest = fullfile(projectRoot,'data_real','processed', ...
        'Shiyan_G1_source_manifest.json');
    if isfile(manifest)
        copyfile(manifest,fullfile(out,'Shiyan_G1_source_manifest.json'));
    end
    fprintf('FAST results saved to: %s\n',out);
end
