function z = terrainHeight(problem,x,y)
%TERRAINHEIGHT Fast bilinear terrain interpolation on the problem grid.
%
% v7.2.3 Performance R2.1 keeps the historical INTERP2 contract as the
% fallback, while real Shiyan problems may reuse one cached GRIDDedInterpolant
% instead of rebuilding interpolation machinery for every dense segment.
%
% R2.1 hotfix: griddedInterpolant warns when pairwise LOS query matrices are
% presented in MESHGRID-looking form. For equal-sized X/Y arrays (or scalar
% expansion), evaluate the same query points as column vectors and reshape the
% result back to the caller's original size. This preserves pairwise semantics
% and avoids the MESHGRID/NDGRID warning flood without changing interpolation
% method, extrapolation policy, or terrain values.

[xGrid,yGrid] = localGridVectors(problem);
useCache = isfield(problem,'enableTerrainInterpolatorCache') && ...
    isscalar(problem.enableTerrainInterpolatorCache) && ...
    logical(problem.enableTerrainInterpolatorCache) && ...
    isfield(problem,'terrainInterpolationCacheId') && ...
    ~isempty(problem.terrainInterpolationCacheId) && ...
    all(diff(xGrid)>0) && all(diff(yGrid)>0);

if useCache
    z = localCachedInterpolant(problem,xGrid,yGrid,x,y);
else
    z = interp2(xGrid,yGrid,problem.terrain,x,y,'linear',NaN);
end

% Preserve the historical out-of-domain behaviour: an invalid terrain query
% is treated as the maximum terrain elevation, making it conservative for
% clearance/LOS calculations instead of silently creating free space.
invalid = isnan(z);
if any(invalid(:))
    z(invalid) = max(problem.terrain(:));
end
end

function z = localCachedInterpolant(problem,xGrid,yGrid,x,y)
persistent cachedId cachedInterpolant cachedMaximumTerrain
cacheId = char(string(problem.terrainInterpolationCacheId));
try
    if isempty(cachedId) || ~strcmp(cachedId,cacheId) || isempty(cachedInterpolant)
        % griddedInterpolant uses NDGRID ordering, hence {Y,X} for a terrain
        % matrix whose rows follow Y and columns follow X. Linear interpolation
        % with no extrapolation matches the historical bilinear INTERP2 contract.
        cachedInterpolant = griddedInterpolant( ...
            {reshape(yGrid,[],1),reshape(xGrid,[],1)},problem.terrain, ...
            'linear','none');
        cachedId = cacheId;
        cachedMaximumTerrain = max(problem.terrain(:));
    end

    [xq,yq,outSize,usePairwise] = localPairwiseQuery(x,y);
    if usePairwise
        % Column point lists cannot be mistaken for MESHGRID query matrices.
        % Each (xq(k),yq(k)) remains the same physical query point as before.
        z = cachedInterpolant(yq,xq);
        z = reshape(z,outSize);
    else
        % Preserve unusual INTERP2 broadcasting/grid-query semantics rather
        % than guessing how differently-shaped X/Y arrays should be paired.
        z = interp2(xGrid,yGrid,problem.terrain,x,y,'linear',NaN);
    end
catch
    % Conservative compatibility fallback if caching/interpolant construction
    % is unavailable in a particular MATLAB release or query shape.
    z = interp2(xGrid,yGrid,problem.terrain,x,y,'linear',NaN);
    cachedMaximumTerrain = max(problem.terrain(:));
end
invalid = isnan(z);
if any(invalid(:))
    z(invalid) = cachedMaximumTerrain;
end
end

function [xq,yq,outSize,usePairwise] = localPairwiseQuery(x,y)
%LOCALPAIRWISEQUERY Convert pointwise XY arrays to column query lists.
if isequal(size(x),size(y))
    outSize = size(x);
    xq = x(:);
    yq = y(:);
    usePairwise = true;
elseif isscalar(x) && ~isempty(y)
    outSize = size(y);
    xq = repmat(x,numel(y),1);
    yq = y(:);
    usePairwise = true;
elseif isscalar(y) && ~isempty(x)
    outSize = size(x);
    xq = x(:);
    yq = repmat(y,numel(x),1);
    usePairwise = true;
else
    outSize = size(x);
    xq = [];
    yq = [];
    usePairwise = false;
end
end

function [xGrid,yGrid] = localGridVectors(problem)
if isfield(problem,'gridXVector') && isfield(problem,'gridYVector') && ...
        ~isempty(problem.gridXVector) && ~isempty(problem.gridYVector)
    xGrid = problem.gridXVector;
    yGrid = problem.gridYVector;
elseif isvector(problem.gridX) && isvector(problem.gridY)
    xGrid = problem.gridX;
    yGrid = problem.gridY;
else
    xGrid = problem.gridX(1,:);
    yGrid = problem.gridY(:,1);
end
xGrid = reshape(xGrid,1,[]);
yGrid = reshape(yGrid,[],1);
end
