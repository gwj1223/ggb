function r = riskValue(problem,x,y)
%RISKVALUE Fast bilinear interpolation of the DEM-derived risk proxy.

[xGrid,yGrid] = localGridVectors(problem);
r = interp2(xGrid,yGrid,problem.risk,x,y,'linear',1);
r = min(max(r,0),1);
end

function [xGrid,yGrid] = localGridVectors(problem)
if isfield(problem,'gridXVector') && isfield(problem,'gridYVector') && ...
        ~isempty(problem.gridXVector) && ~isempty(problem.gridYVector)
    xGrid = problem.gridXVector;
    yGrid = problem.gridYVector;
elseif isvector(problem.gridX) && isvector(problem.gridY)
    xGrid = problem.gridX;
    yGrid = problem.gridY;
else
    xGrid = problem.gridX(1,:);
    yGrid = problem.gridY(:,1);
end
xGrid = reshape(xGrid,1,[]);
yGrid = reshape(yGrid,[],1);
end
