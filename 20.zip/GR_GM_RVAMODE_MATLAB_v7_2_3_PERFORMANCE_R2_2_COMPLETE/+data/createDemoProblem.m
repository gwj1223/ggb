function problem = createDemoProblem(cfg)
rng(cfg.randomSeed,'twister');
problem.name = 'Geological monitoring terrain with landslide targets';
problem.xBounds = [0 120]; problem.yBounds = [0 100];
problem.zBounds = [0 cfg.maxAltitude];
problem.start = [5 8 28]; problem.goal = [112 92 35];
[xg,yg] = meshgrid(linspace(0,120,121),linspace(0,100,101));
terrain = 7+12*exp(-((xg-35).^2+(yg-45).^2)/600)+ ...
    18*exp(-((xg-80).^2+(yg-60).^2)/420)+7*sin(xg/18).*cos(yg/22);
terrain = max(terrain,0);
risk = 0.08+0.75*exp(-((xg-58).^2+(yg-48).^2)/350)+ ...
    0.55*exp(-((xg-92).^2+(yg-78).^2)/260)+ ...
    0.35*exp(-((xg-30).^2+(yg-75).^2)/300);
risk = min(max(risk,0),1);
problem.gridX = xg; problem.gridY = yg;
problem.terrain = terrain; problem.risk = risk;
problem.obstacles = [45 30 9 45;72 42 8 58;88 70 7 62];
% [x y weight desiredRange desiredHeight]
problem.monitorTargets = [30 72 1.2 13 15;60 50 1.6 12 14; ...
    94 80 1.3 14 17;78 25 1.0 15 16];
problem.monitorTargetTerrain = data.terrainHeight(problem, ...
    problem.monitorTargets(:,1),problem.monitorTargets(:,2));
problem.wind = [0.8 0.2 0;-0.2 0.5 0];
problem.cfg = cfg;
problem.start(3) = max(problem.start(3), ...
    data.terrainHeight(problem,problem.start(1),problem.start(2))+cfg.safeClearance);
problem.goal(3) = max(problem.goal(3), ...
    data.terrainHeight(problem,problem.goal(1),problem.goal(2))+cfg.safeClearance);
end
