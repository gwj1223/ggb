# v7.2.2 Adaptive Connector Allocation

This patch responds to full-fleet evidence from v7.2.1.

## Runtime evidence that motivated the patch

- The focused UAV-2 seed=1051 run succeeded after v7.2.1 reserved one connector on the final target-to-goal leg.
- In the full `main` run, UAV-1 seed=42 stayed at `static=0/96` and `decodeOK=0/96` through Gen87 while minimum CV plateaued near 1.89.
- Direct inspection of the previous successful v7.2.0 UAV-1 solution showed connector counts
  `[2 1 1 1 1 1 0 0 0 0 1]` and maximum turn 94.33 deg. Therefore the v7.2.1 global cap of one connector per leg removed a connector that the successful UAV-1 geometry had actually used.

## Change

The phenotype remains exactly 42 internal waypoints and the semantic chromosome remains 51D.

- Boundary legs retain at least one connector.
- Boundary and internal legs may use at most two connectors.
- For every leg, the decoder predicts local 2-D maximum turn for 0, 1, and 2 connector nodes.
- The fixed eight-node connector budget is allocated greedily by marginal turn reduction, prioritizing removal of formal (>95 deg) and near-limit turn demand.
- Terrain/distance difficulty is only a tie-breaker.
- A second connector is therefore allowed where it helps (e.g. the former UAV-1 start leg) but discouraged where it worsens discrete turn geometry (the failure mode observed when blindly adding two boundary nodes).

## Unchanged

Population 96, generations 220, five objectives, Qmin 0.33, Qcritical 0.42, Critical observation 180 m, Critical LOS 0.45, AGL 60-320 m, climb 22 deg, turn 95 deg, Mission-Band, Mission Deficit, A3 protection, Dense-3D reachability, and 42-waypoint phenotype are unchanged.
