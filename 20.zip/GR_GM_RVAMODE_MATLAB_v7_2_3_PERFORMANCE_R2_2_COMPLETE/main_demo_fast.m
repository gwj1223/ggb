clear; clc; close all;
projectRoot = fileparts(mfilename('fullpath'));
setupProject(projectRoot);
cfg = config.fastConfig();
problem = data.createDemoProblem(cfg);
result = core.runGRAHMODE(problem,cfg);
visualization.plotResult(problem,result,cfg);
b = result.best;
commonHV = NaN;
if isfield(result,'bestCommonHypervolume')
    idx = find(isfinite(result.bestCommonHypervolume),1,'last');
    if ~isempty(idx), commonHV = result.bestCommonHypervolume(idx); end
elseif isfield(result,'commonHypervolume')
    idx = find(isfinite(result.commonHypervolume),1,'last');
    if ~isempty(idx), commonHV = result.commonHypervolume(idx); end
end
if isfield(result,'reportedSolutionLabel')
    fprintf('Reported solution: %s\n',result.reportedSolutionLabel);
end
if isfield(result,'reportedSolutionSelectionLevel')
    fprintf('Selection level: %s\n',result.reportedSolutionSelectionLevel);
end
riskScore = metrics.riskBalancedCostIndicator(b,cfg);
fprintf(['\nFast run: generation=%d, detour=%.4f, risk=%.4f, tail=%.4f, ' ...
    'smooth=%.4f, ' ...
    'Q=%.4f, Qmin=%.4f, missionDef=%.4f, LOS=%.4f, ' ...
    'riskScore=%.4f, finalArchive=%d, controllerFinal=%d, ' ...
    'commonHV=%.4f, time=%.2fs\n'], ...
    result.stopGeneration,b.pathMetrics.detourRatio,b.riskStats.objective, ...
    b.riskStats.tailRisk,b.objectives(4), ...
    b.monitorQuality,b.monitorStats.minimumQuality, ...
    evaluation.finalMonitoringDeficit(b,cfg), ...
    b.monitorStats.minimumCriticalLOSRatio,riskScore(1), ...
    numel(result.finalArchive), ...
    result.controllerReachedFinalThresholds,commonHV, ...
    result.totalOptimizationTime);
if cfg.saveResults
    out = exporter.saveRun(problem,result,cfg,projectRoot);
    fprintf('Results saved to: %s\n',out);
end
