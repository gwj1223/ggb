function r = run_uav2_only_v723()
%RUN_UAV2_ONLY_V723 Regression of the v7.2.1 UAV-2 turn/static fix under v7.2.3.
projectRoot=fileparts(mfilename('fullpath'));
setupProject(projectRoot);
cfg=config.multiUAVShiyanConfig();
[problem,cfg]=realdata.buildShiyanG1Problem(projectRoot,cfg);
assignment=multiUAV.allocateTargetsObservabilityAware(problem,cfg);
uavId=2;
[subProblem,subCfg]=multiUAV.buildSubProblem(problem,cfg,assignment,uavId);
config.validateConfig(subCfg,subProblem);
layout=core.structuredMonitoringLayout(subProblem,subCfg);
fprintf('\n=== v7.2.3 UAV-2 regression verification ===\n');
fprintf('seed=%d targets=%d waypoints=%d semantic=%dD phenotype=%dD\n', ...
    subCfg.randomSeed,size(subProblem.monitorTargets,1),subCfg.numWaypoints, ...
    layout.dimension,3*subCfg.numWaypoints);
fprintf('global targets=[%s]\n',num2str(assignment.groups{uavId}));
r=core.runGRAHMODE(subProblem,subCfg);
b=r.best(1);
fprintf('\n--- UAV-2 final ---\n');
fprintf('FinalFeasible=%d | D=%.6f | staticCV=%.6g\n', ...
    r.bestSolutionSatisfiesFinalConstraints, ...
    evaluation.finalMonitoringDeficit(b,subCfg),b.staticCV);
fprintf('viol[col/clr/clm/trn/E]=[%.6g %.6g %.6g %.6g %.6g]\n', ...
    b.violation.collision,b.violation.clearance,b.violation.climb, ...
    b.violation.turn,b.violation.energy);
if isfield(b,'encodingInfo') && isstruct(b.encodingInfo)
    info=b.encodingInfo;
    if isfield(info,'connectorCount') && ~isempty(info.connectorCount)
        fprintf('connectorCount=[%s] | last=%d\n', ...
            num2str(info.connectorCount(:)'),info.connectorCount(end));
    end
    if isfield(info,'topologyIndex'), fprintf('topologyIndex=%d\n',info.topologyIndex); end
    if isfield(info,'routeMode')
        fprintf('routeMode=%s',char(info.routeMode));
        if isfield(info,'tangentBlend') && isfinite(info.tangentBlend)
            fprintf(' blend=%.2f',info.tangentBlend);
        end
        fprintf('\n');
    end
    if isfield(info,'reason') && isfield(info,'maxTurnDeg')
        fprintf('decode=%s | dense=%d | maxTurn=%.3f deg\n', ...
            char(info.reason),isfield(info,'denseSuccess') && info.denseSuccess,info.maxTurnDeg);
    end
end
fprintf('Qmin=%.4f Qcritical=%.4f CriticalObs=%.2f CriticalLOS=%.4f\n', ...
    b.monitorStats.minimumQuality,b.monitorStats.criticalQuality, ...
    b.monitorStats.minimumCriticalObservationLength, ...
    b.monitorStats.minimumCriticalLOSRatio);
localPrintPerformanceAndEngineering(r);
end

function localPrintPerformanceAndEngineering(r)
if isfield(r,'reportedSolutionLabel')
    fprintf('Reported=%s level=%s strictEngineering=%d\n', ...
        char(r.reportedSolutionLabel),char(r.reportedSolutionSelectionLevel), ...
        isfield(r,'reportedStrictEngineeringLimitsSatisfied') && ...
        r.reportedStrictEngineeringLimitsSatisfied);
end
if isfield(r,'reportedStrictEngineeringDiagnostics') && ...
        ~isempty(r.reportedStrictEngineeringDiagnostics)
    d=r.reportedStrictEngineeringDiagnostics;
    failed=d(~reshape([d.passed],[],1));
    for ii=1:numel(failed)
        fprintf('  strict FAIL %-28s value=%.6g %s limit=%.6g\n', ...
            failed(ii).name,failed(ii).value,failed(ii).relation,failed(ii).limit);
    end
end
if isfield(r,'performance') && isstruct(r.performance) && ...
        isfield(r.performance,'structuredTrialDecoderTime_s')
    p=r.performance;
    fprintf(['Perf trialDecoder=%.1fs denseProjection=%.1fs terrainSampling=%.1fs ' ...
        'reach=%d cacheHitRate=%.1f%%\n'], ...
        p.structuredTrialDecoderTime_s,p.structuredTrialDenseProjectionTime_s, ...
        p.structuredTrialTerrainSamplingTime_s,p.structuredTrialReachAttempts, ...
        100*p.structuredTrialTerrainCacheHitRate);
end
end

