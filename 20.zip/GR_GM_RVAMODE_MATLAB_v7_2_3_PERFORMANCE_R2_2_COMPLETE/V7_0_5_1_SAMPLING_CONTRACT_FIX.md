# GR-GM-RVAMODE-VI v7.0.5.1 — Sampling Contract Fix

This is a minimal hotfix on top of v7.0.5 Dense-3D Terrain Reachability.

## Root cause
v7.0.5 changed `repairSegmentClearance` to always use the 15 m-class
adaptive terrain sampler. `evaluateIndividual`, however, intentionally retained
legacy fixed `cfg.segmentSamples` sampling unless
`enableDistanceAdaptiveAGLConstraintSampling=true`. In default/demo fixtures,
short segments could therefore be sampled only at their endpoints by repair
while the evaluator sampled eight points and found an interior terrain peak.

## Fix
- Added `evaluation.aglSamplingPolicy` as the single selector for hard AGL
  sampling mode.
- Default/demo: repair and evaluator both use `cfg.segmentSamples` fixed grid.
- Shiyan formal: repair and evaluator both use distance-adaptive 15 m-class grid.
- Dense-3D A3 logic and all formal mission/flight thresholds are unchanged.
- `segmentRepairSamples` remains in configuration for backward compatibility but
  is not a separate hard-clearance truth source.

## Regression protection
- Existing `test_segment_repair` is intentionally retained.
- `test_shared_agl_sampling_contract` protects the Shiyan adaptive contract.
- New `test_default_agl_sampling_contract` protects the default fixed contract.
