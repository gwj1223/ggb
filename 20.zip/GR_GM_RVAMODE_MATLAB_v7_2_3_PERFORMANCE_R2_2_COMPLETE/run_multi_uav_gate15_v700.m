%RUN_MULTI_UAV_GATE15_V700 Focused logic-freeze gate for v7.0.0.
seeds=[4 9 14 18 19 20 24 25 26 28 3 7 8 10 16]';
run_multi_uav_batch_v700(seeds,'gate15_v700');
