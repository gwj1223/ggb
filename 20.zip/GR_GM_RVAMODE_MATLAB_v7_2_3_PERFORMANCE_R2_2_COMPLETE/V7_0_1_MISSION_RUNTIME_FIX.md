# GR-GM-RVAMODE-VI v7.0.1 — Mission Runtime Fix

This release is a minimal runtime correction on top of the fully tested v7.0.0.2 package.
It does **not** reintroduce Target Memory, Mission Carrier restoration, persistent repair,
emergency reinjection, or independent monitoring-threshold controllers.

## Triggering evidence
In the first formal `main` run (UAV-1, seed 42), generation 25 had `epsD=1` and 96/96
runtime-feasible individuals while all four formal monitoring diagnostics were still violated.
At generation 26 `epsD` tightened to 0.987 and the population became 0/96 runtime-feasible.
By generation 100–130 no formal carrier existed, Common HV remained NaN and physical cost
remained Inf, yet the old stopping trackers could still reach their stagnation window.

## Fix 1 — formal-evidence stopping gate
Final-stage stagnation stopping now requires all of:
- non-empty formal `finalArchive`;
- finite best Common HV;
- finite best physical cost;
- the existing final-stage buffer and stagnation conditions.

Therefore a run with no formal solution cannot terminate merely because the trackers were
initialized when the formal stage began.

## Fix 2 — cumulative A3 mission progress
`missionRepairMinDeficitGain` is reduced from `0.002` to `1e-4`.
The hard A3 guards are unchanged: static feasibility is mandatory; already satisfied formal
components and target-level formal conditions cannot be destroyed; repaired candidates still
pass through normal environmental selection.

The lower deterministic gain floor allows one-target-at-a-time progress when another target
still controls the Chebyshev-dominant worst deficit. This is a threshold correction inside the
single Unified A3, not a new repair mechanism.

## Unchanged scientific contract
- 5 Pareto objectives unchanged.
- Mission Deficit definition and weights unchanged.
- Mission schedule G1–24 / G25–99 / G100+ unchanged.
- Formal monitoring thresholds unchanged: Qmin 0.33, Qcritical 0.42, critical observation
  180 m, critical LOS 0.45.
- AGL remains 60–320 m; climb/turn/energy and fleet separation unchanged.
- Population 96, max generations 220 unchanged.

## Added diagnostics
Every Unified A3 checkpoint now reports evaluations, selected repaired candidates, best
Mission Deficit before/after, formal-carrier counts, and repaired target indices.

## New regression tests
- `test_unified_mission_cumulative_gain`
- `test_final_stopping_formal_evidence_gate`

Run `run_all_tests`, then run `main` again before Gate15 or 30 seeds.
