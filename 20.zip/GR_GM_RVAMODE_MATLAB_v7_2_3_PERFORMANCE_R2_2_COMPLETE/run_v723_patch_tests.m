function run_v723_patch_tests()
%RUN_V723_PATCH_TESTS Run only the tests introduced by the v7.2.3 overlay.
projectRoot=fileparts(mfilename('fullpath'));
setupProject(projectRoot);
tests={@test_v723_topology_candidates,@test_v723_dense_first_source_contract};
failures={};
for k=1:numel(tests)
    try
        feval(tests{k});
    catch ME
        failures{end+1}=sprintf('%s: %s',func2str(tests{k}),ME.message); %#ok<AGROW>
        fprintf(2,'FAILED: %s\n',failures{end});
    end
end
fprintf('\nv7.2.3 patch tests: %d/%d passed.\n',numel(tests)-numel(failures),numel(tests));
if ~isempty(failures)
    error('run_v723_patch_tests:Failure','v7.2.3 patch tests failed.');
end
end
