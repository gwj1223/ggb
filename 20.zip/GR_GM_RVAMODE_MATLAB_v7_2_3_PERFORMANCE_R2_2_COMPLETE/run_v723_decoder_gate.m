function result = run_v723_decoder_gate(sampleCount,uavId)
%RUN_V723_DECODER_GATE Decoder-only gate before any evolutionary run.
%   result = run_v723_decoder_gate(192,1)
% Samples the same structured initialization families used by the population
% initializer and measures whether the v7.2.3 decoder opens a nonzero Dense-3D
% feasible set before spending time on 220 generations.
if nargin<1 || isempty(sampleCount), sampleCount=192; end
if nargin<2 || isempty(uavId), uavId=1; end
sampleCount=max(1,round(sampleCount));
uavId=max(1,round(uavId));

projectRoot=fileparts(mfilename('fullpath'));
setupProject(projectRoot);
cfg=config.multiUAVShiyanConfig();
[problem,cfg]=realdata.buildShiyanG1Problem(projectRoot,cfg);
assignment=multiUAV.allocateTargetsObservabilityAware(problem,cfg);
[subProblem,subCfg]=multiUAV.buildSubProblem(problem,cfg,assignment,uavId);
config.validateConfig(subCfg,subProblem);
layout=core.structuredMonitoringLayout(subProblem,subCfg);

rng(subCfg.randomSeed+723,'twister');
denseCount=0; okCount=0; turnOnlyCount=0; reachFailCount=0; otherFailCount=0;
bestDenseTurn=inf; bestInfo=struct(); failedSegments=zeros(0,1);
for k=1:sampleCount
    mode=mod(k-1,4)+1;
    variant=ceil(k/4);
    u=core.initializeStructuredMonitoringGenes(subProblem,subCfg,mode,variant);
    [~,info]=core.decodeStructuredMonitoringGenes(u,subProblem,subCfg);
    if isfield(info,'denseSuccess') && info.denseSuccess
        denseCount=denseCount+1;
        if isfield(info,'maxTurnDeg') && isfinite(info.maxTurnDeg) && info.maxTurnDeg<bestDenseTurn
            bestDenseTurn=info.maxTurnDeg;
            bestInfo=info;
        end
    end
    if isfield(info,'success') && info.success
        okCount=okCount+1;
        continue;
    end
    reason='';
    if isfield(info,'reason')
        reason=info.reason;
        if isstring(reason), reason=char(reason); end
    end
    if strcmp(reason,'turn')
        turnOnlyCount=turnOnlyCount+1;
    elseif contains(reason,'reach') || contains(reason,'terrain') || ...
            contains(reason,'altitude') || contains(reason,'climb') || ...
            contains(reason,'clearance') || contains(reason,'interval')
        reachFailCount=reachFailCount+1;
    else
        otherFailCount=otherFailCount+1;
    end
    if isfield(info,'reachFailureSegments') && ~isempty(info.reachFailureSegments)
        failedSegments=[failedSegments;info.reachFailureSegments(:)]; %#ok<AGROW>
    end
end

denseRate=denseCount/sampleCount;
okRate=okCount/sampleCount;
fprintf('\n=== v7.2.3 decoder gate | UAV-%d ===\n',uavId);
fprintf('seed=%d targets=%d waypoints=%d semantic=%dD phenotype=%dD samples=%d\n', ...
    subCfg.randomSeed,size(subProblem.monitorTargets,1),subCfg.numWaypoints, ...
    layout.dimension,3*subCfg.numWaypoints,sampleCount);
fprintf('DenseOK=%d/%d (%.2f%%) | DecodeOK=%d/%d (%.2f%%)\n', ...
    denseCount,sampleCount,100*denseRate,okCount,sampleCount,100*okRate);
fprintf('final failure class [reach/turn/other]=[%d %d %d]\n', ...
    reachFailCount,turnOnlyCount,otherFailCount);
if isfinite(bestDenseTurn)
    fprintf('best Dense-feasible maxTurn=%.3f deg\n',bestDenseTurn);
    if isfield(bestInfo,'connectorCount')
        fprintf('best connectorCount=[%s]\n',num2str(bestInfo.connectorCount(:)'));
    end
    if isfield(bestInfo,'routeMode')
        fprintf('best routeMode=%s',char(bestInfo.routeMode));
        if isfield(bestInfo,'tangentBlend') && isfinite(bestInfo.tangentBlend)
            fprintf(' blend=%.2f',bestInfo.tangentBlend);
        end
        fprintf('\n');
    end
end
if ~isempty(failedSegments)
    maxSeg=max(failedSegments);
    counts=accumarray(failedSegments,1,[maxSeg 1]);
    [sorted,idx]=sort(counts,'descend');
    fprintf('top reach-failure segments:');
    shown=0;
    for q=1:numel(idx)
        if sorted(q)<=0, continue; end
        fprintf(' seg%d=%d',idx(q),sorted(q));
        shown=shown+1;
        if shown>=8, break; end
    end
    fprintf('\n');
end
if denseCount==0
    fprintf(2,'GATE BLOCKED: DenseOK is still zero. Do not run 220 generations yet.\n');
else
    fprintf('GATE OPEN: nonzero Dense-3D carriers exist; proceed to focused evolution.\n');
end

result=struct('uavId',uavId,'sampleCount',sampleCount,'denseCount',denseCount, ...
    'decodeOKCount',okCount,'denseRate',denseRate,'decodeOKRate',okRate, ...
    'reachFailCount',reachFailCount,'turnOnlyCount',turnOnlyCount, ...
    'otherFailCount',otherFailCount,'bestDenseTurnDeg',bestDenseTurn, ...
    'failedSegments',failedSegments);
end
