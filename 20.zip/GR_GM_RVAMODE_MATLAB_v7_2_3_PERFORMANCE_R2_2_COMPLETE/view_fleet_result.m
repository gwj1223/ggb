clear; clc; close all;
%VIEW_FLEET_RESULT Redraw an existing multi-UAV fleet_result.mat.
% No optimization is run.

projectRoot = fileparts(mfilename('fullpath'));
setupProject(projectRoot);

[file,path] = uigetfile('*.mat','Select multi-UAV fleet_result.mat');
if isequal(file,0)
    error('view_fleet_result:NoFile','No fleet_result.mat was selected.');
end
S = load(fullfile(path,file));
if ~isfield(S,'problem') || ~isfield(S,'fleetResult') || ~isfield(S,'cfg')
    error('view_fleet_result:WrongFile', ...
        ['Selected MAT file is not a fleet result. It must contain ' ...
         'problem, fleetResult and cfg.']);
end
if ~isfield(S.cfg,'multiUAVCount') || S.cfg.multiUAVCount < 2
    error('view_fleet_result:NotMultiUAV', ...
        'Selected result is not a multi-UAV result.');
end

visualization.plotMultiUAVResult(S.problem,S.fleetResult,S.cfg);
visualization.plotFleetSeparation(S.fleetResult,S.cfg);
fprintf('Loaded %d-UAV fleet result from:\n%s\n', ...
    S.cfg.multiUAVCount,fullfile(path,file));
