clear; clc; close all;
projectRoot = fileparts(mfilename('fullpath'));
setupProject(projectRoot);
cfg = config.defaultConfig();
problem = data.createDemoProblem(cfg);
result = core.runGRAHMODE(problem,cfg);
visualization.plotResult(problem,result,cfg);

b = result.best;
fprintf('\n=== GR-GM-RVAMODE-VI v6.3.6 risk-balanced refinement result ===\n');
if isfield(result,'reportedSolutionLabel')
    fprintf('Reported solution           : %s\n', ...
        result.reportedSolutionLabel);
end
if isfield(result,'reportedSolutionSelectionLevel')
    fprintf('Reported selection level    : %s\n', ...
        result.reportedSolutionSelectionLevel);
end
reportedCost = metrics.finalStageCostIndicator(b,cfg);
riskBalancedCost = metrics.riskBalancedCostIndicator(b,cfg);
fprintf('Reported physical cost      : %.5f\n',reportedCost(1));
fprintf('Reported risk-balanced cost : %.5f\n',riskBalancedCost(1));
fprintf('Stop generation             : %d\n',result.stopGeneration);
if isfield(result,'stopReason')
    fprintf('Stop reason                 : %s\n',result.stopReason);
end
fprintf('Path length                 : %.4f\n',b.pathMetrics.rawLength);
fprintf('Detour ratio                : %.4f\n',b.pathMetrics.detourRatio);
fprintf('Risk objective              : %.4f\n',b.riskStats.objective);
fprintf('Mean / tail risk            : %.4f / %.4f\n', ...
    b.riskStats.meanRisk,b.riskStats.tailRisk);
[strictReportMask,~] = selection.engineeringLimitMask(b,cfg,'strict',b);
fprintf('Strict engineering limits   : %d\n',strictReportMask(1));
fprintf('Total energy                : %.4f\n',b.energyStats.total);
fprintf('Observation / hover energy  : %.4f / %.4f\n', ...
    b.energyStats.observation,b.energyStats.hoverEquivalent);
fprintf('Smoothness                  : %.4f\n',b.objectives(4));
fprintf('True monitoring quality     : %.4f\n',b.monitorQuality);
fprintf('Search proxy quality        : %.4f\n',b.searchMonitorQuality);
fprintf('Minimum target quality      : %.4f\n', ...
    b.monitorStats.minimumQuality);
fprintf('Critical target quality     : %.4f\n', ...
    b.monitorStats.criticalQuality);
fprintf('Monitoring dispersion       : %.4f\n', ...
    b.monitorStats.dispersionPenalty);
fprintf('Worst coverage deficit      : %.4f\n', ...
    b.monitorStats.worstCoverageDeficit);
fprintf('Worst observation deficit   : %.4f\n', ...
    b.monitorStats.worstObservationDeficit);
fprintf('Final monitoring deficit    : %.4f\n', ...
    evaluation.finalMonitoringDeficit(b,cfg));
fprintf('Per-target true quality     :');
fprintf(' %.3f',b.monitorPerTarget);
fprintf('\n');
fprintf('Critical min obs. length    : %.4f\n', ...
    b.monitorStats.minimumCriticalObservationLength);
fprintf('Critical min LOS quality    : %.4f\n', ...
    b.monitorStats.minimumCriticalLOSRatio);
fprintf('Constraint violation        : %.4g\n',b.cv);
fprintf('Best satisfies final limits : %d\n', ...
    result.bestSolutionSatisfiesFinalConstraints);
fprintf('Controller reached final    : %d\n', ...
    result.controllerReachedFinalThresholds);
fprintf('Final archive available     : %d\n', ...
    result.finalArchiveAvailable);
if ~result.bestSolutionSatisfiesFinalConstraints && ...
        isfield(result,'bestRelaxedProgress')
    fprintf('Best relaxed progress       : %.3f\n',result.bestRelaxedProgress);
end
fprintf('Reached quality thresholds  : %.3f / %.3f\n', ...
    result.thresholdState.minimum,result.thresholdState.critical);
fprintf('Reached geometry thresholds : %.2f / %.3f\n', ...
    result.thresholdState.observationLength,result.thresholdState.losRatio);
fprintf('Required quality thresholds : %.3f / %.3f\n', ...
    cfg.monitorMinTargetQuality,cfg.monitorCriticalMinQuality);
fprintf('Required geometry thresholds: %.2f / %.3f\n', ...
    cfg.monitorCriticalMinObservationLength,cfg.monitorCriticalMinLOSRatio);
fprintf('Final archive size          : %d\n',numel(result.finalArchive));
if isfield(result,'bestCommonHypervolume')
    idx = find(isfinite(result.bestCommonHypervolume),1,'last');
    if ~isempty(idx)
        fprintf('Best Common HV              : %.4f\n', ...
            result.bestCommonHypervolume(idx));
    end
elseif isfield(result,'commonHypervolume')
    idx = find(isfinite(result.commonHypervolume),1,'last');
    if ~isempty(idx)
        fprintf('Common final HV             : %.4f\n', ...
            result.commonHypervolume(idx));
    end
end
if isfield(result,'commonArchive')
    fprintf('Common archive size         : %d\n',numel(result.commonArchive));
end
if isfield(result,'bestFinalStageCostIndicator')
    fprintf('Best physical cost indicator: %.5f\n', ...
        result.bestFinalStageCostIndicator);
end
fprintf('Final-stage generations     : %d\n',result.finalStageGenerations);
fprintf('Snap-final activations      : %d\n', ...
    result.performance.snapFinalCount);
fprintf('Infeasible restarts         : %d\n',result.infeasibleRestarts);
fprintf('Threshold rollbacks         : %d\n', ...
    result.performance.thresholdRollbacks);
fprintf('Optimization time           : %.2f s\n', ...
    result.totalOptimizationTime);
fprintf('Full evaluations            : %d\n', ...
    result.performance.fullEvaluations);
fprintf('Dynamic-only updates        : %d\n', ...
    result.performance.dynamicConstraintUpdates);
fprintf('Optimization HV evaluations : %d\n', ...
    result.performance.hypervolumeEvaluations);
if isfield(result.performance,'commonHypervolumeEvaluations')
    fprintf('Common HV evaluations       : %d\n', ...
        result.performance.commonHypervolumeEvaluations);
end
if isfield(result.performance,'commonArchiveUpdates')
    fprintf('Common archive updates      : %d\n', ...
        result.performance.commonArchiveUpdates);
end
fprintf('Local-search evaluations    : %d\n', ...
    result.performance.localSearchEvaluations);
if isfield(result,'finalStageOperatorState')
    fprintf('Final operator probabilities:');
    fprintf(' %.3f',result.finalStageOperatorState.probabilities);
    fprintf('\n');
end
if cfg.saveResults
    out = exporter.saveRun(problem,result,cfg,projectRoot);
    fprintf('Results saved to: %s\n',out);
end
