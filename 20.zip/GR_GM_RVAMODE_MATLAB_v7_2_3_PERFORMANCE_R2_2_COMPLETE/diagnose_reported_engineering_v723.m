function diagnostics = diagnose_reported_engineering_v723(result,uavId)
%DIAGNOSE_REPORTED_ENGINEERING_V723 Explain strict report-filter failure.
% Usage after an existing run: diagnose_reported_engineering_v723(ans,2)
if nargin<2 || isempty(uavId), uavId=2; end
projectRoot=fileparts(mfilename('fullpath'));
setupProject(projectRoot);
cfg=config.multiUAVShiyanConfig();
[problem,cfg]=realdata.buildShiyanG1Problem(projectRoot,cfg);
assignment=multiUAV.allocateTargetsObservabilityAware(problem,cfg);
[~,subCfg]=multiUAV.buildSubProblem(problem,cfg,assignment,uavId);
if ~isfield(result,'best') || isempty(result.best)
    error('diagnose_reported_engineering_v723:MissingBest', ...
        'The supplied result has no best solution.');
end
reference=result.best;
if isfield(result,'commonArchive') && ~isempty(result.commonArchive)
    reference=result.commonArchive;
elseif isfield(result,'finalArchive') && ~isempty(result.finalArchive)
    reference=result.finalArchive;
end
[mask,details]=selection.engineeringLimitMask(result.best(1),subCfg,'strict',reference);
diagnostics=selection.engineeringLimitDiagnostics( ...
    details,1,subCfg.constraintTolerance);
fprintf('\n=== v7.2.3 strict-engineering diagnostic | UAV-%d ===\n',uavId);
fprintf('strictEngineering=%d\n',mask(1));
for i=1:numel(diagnostics)
    d=diagnostics(i);
    status='PASS'; if ~d.passed, status='FAIL'; end
    fprintf('%-4s %-30s value=%-12.6g %s limit=%.6g\n', ...
        status,d.name,d.value,d.relation,d.limit);
end
end
