function test_v723_dense_first_source_contract()
%TEST_V723_DENSE_FIRST_SOURCE_CONTRACT Static guard for the decoder ordering.
projectRoot=fileparts(fileparts(mfilename('fullpath')));
decoderPath=fullfile(projectRoot,'src','+core','decodeStructuredMonitoringGenes.m');
cfgPath=fullfile(projectRoot,'+config','multiUAVShiyanConfig.m');
s=fileread(decoderPath);
c=fileread(cfgPath);

assert(contains(s,'core.generateStructuredConnectorTopologies'), ...
    'v7.2.3 topology candidate layer is missing.');
assert(contains(s,'problem,cfg,0)'), ...
    'Dense-first chord call (tangentBlend=0) is missing.');
assert(contains(s,'tangentBlend'), ...
    'Reachability-preserving tangent blend is missing.');
assert(contains(s,'Stage 1: Dense-first reachability carrier'), ...
    'Dense-first stage marker is missing.');
assert(contains(s,'Stage 2: turn refinement'), ...
    'Turn-second stage marker is missing.');
assert(contains(c,'v7.2.3-3d-feasibility-first-decoder'));
assert(contains(c,'structuredTransitTopologyCandidateLimit'));
assert(contains(c,'structuredTransitTangentBlendSchedule'));

startIdx=strfind(s,'function cost=localConnectorTurnCostMatrix');
endIdx=strfind(s,'function maxTurn=localMax2DTurn');
assert(~isempty(startIdx) && ~isempty(endIdx) && endIdx(1)>startIdx(1));
turnCostBlock=s(startIdx(1):endIdx(1)-1);
assert(~contains(turnCostBlock,'localTangentTransit'), ...
    'Connector-count turn prediction must use reach-safe chord geometry.');
fprintf('test_v723_dense_first_source_contract passed.\n');
end
