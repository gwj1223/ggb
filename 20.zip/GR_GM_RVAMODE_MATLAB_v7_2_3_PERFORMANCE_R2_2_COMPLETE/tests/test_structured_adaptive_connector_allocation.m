function test_structured_adaptive_connector_allocation()
cfg=config.defaultConfig();
cfg.maxTurnAngleDeg=95;
cfg.structuredTransitMinimumBoundaryConnectors=1;
cfg.structuredTransitMaximumBoundaryConnectors=2;
cfg.structuredTransitMaximumConnectorsPerLeg=2;
cfg.structuredTransitMandatoryTurnFraction=0.90;
L=11;
budget=8;
score=ones(L,1);
% Columns are local max turn for [0,1,2] connectors.
turnCost=repmat([55 45 44],L,1);
% Start leg genuinely needs a second connector: 1->2 removes formal excess.
turnCost(1,:)=[150 112 82];
% Goal leg needs exactly one; a second connector would make it worse.
turnCost(end,:)=[132 84 104];
% Make five internal first-connectors useful but less important than start 1->2.
for k=2:6
    turnCost(k,:)=[82 58 57];
end
counts=core.allocateStructuredTransitConnectors(budget,score,turnCost,cfg);
assert(sum(counts)==budget);
assert(counts(1)==2,'Adaptive allocation must allow a beneficial second start connector.');
assert(counts(end)==1,'Adaptive allocation must avoid a harmful second goal connector.');
assert(all(counts>=0 & counts<=2));
fprintf('test_structured_adaptive_connector_allocation passed.\n');
end
