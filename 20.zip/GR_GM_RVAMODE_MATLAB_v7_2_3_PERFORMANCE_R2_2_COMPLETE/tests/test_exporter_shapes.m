function test_exporter_shapes()
%TEST_EXPORTER_SHAPES Export must work for row and column struct archives.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.fastConfig();
cfg.populationSize = 4;
cfg.saveFigures = false;
cfg.outputRoot = fullfile('output','test_exporter_shapes_v6');
problem = data.createDemoProblem(cfg);
pop = core.initializePopulation(problem,cfg);
pop = evaluation.evaluatePopulation(pop,problem,cfg,1);
archive = pop(1:3);
for k=1:numel(archive)
    archive(k).cv=0; archive(k).feasible=true;
end
result.archive = archive;
result.currentArchive = archive;
result.finalArchive = archive;
result.commonArchive = archive;
result.best = archive(1);
result.reportedSolutionLabel = 'CommonKneePoint';
result.history = zeros(1,86);
result.hypervolume = 0.25;
result.currentHypervolume = 0.24;
result.finalHypervolume = 0.25;
result.commonHypervolume = 0.23;
result.bestCommonHypervolume = 0.23;
result.bestFinalStageCostIndicator = 0.5;
result.stopReason = 'unit_test';
result.stopGeneration = 1;
result.infeasibleRestarts = 0;
result.totalOptimizationTime = 1;
result.finalThresholdSatisfied = true;
result.bestSolutionSatisfiesFinalConstraints = true;
result.controllerReachedFinalThresholds = true;
result.finalArchiveAvailable = true;
result.finalStageGenerations = 1;
result.thresholdState = evaluation.initializeMonitoringThresholdState(cfg);
result.thresholdState.minimum = cfg.monitorMinTargetQuality;
result.thresholdState.critical = cfg.monitorCriticalMinQuality;
result.thresholdState.observationLength = ...
    cfg.monitorCriticalMinObservationLength;
result.thresholdState.losRatio = cfg.monitorCriticalMinLOSRatio;
result.thresholdState.finalReached = true;
result.performance = struct('fullEvaluations',3, ...
    'dynamicConstraintUpdates',3,'hypervolumeEvaluations',1, ...
    'localSearchEvaluations',0,'thresholdChanges',1, ...
    'thresholdRollbacks',0,'snapFinalCount',1, ...
    'finalStageGenerations',1,'meanGenerationTime',1, ...
    'commonHypervolumeEvaluations',1,'commonArchiveUpdates',1);
out1 = exporter.saveRun(problem,result,cfg,root);
assert(exist(fullfile(out1,'pareto_archive.csv'),'file')==2);
assert(exist(fullfile(out1,'representative_solutions.csv'),'file')==2);
assert(exist(fullfile(out1,'common_pareto_archive.csv'),'file')==2);
assert(exist(fullfile(out1,'reported_solution.txt'),'file')==2);
T1 = readtable(fullfile(out1,'pareto_archive.csv'));
assert(height(T1)==3);
result.archive = archive.';
result.currentArchive = archive.';
result.finalArchive = archive.';
result.commonArchive = archive.';
out2 = exporter.saveRun(problem,result,cfg,root);
T2 = readtable(fullfile(out2,'pareto_archive.csv'));
assert(height(T2)==3);
fprintf('test_exporter_shapes passed.\n');
end
