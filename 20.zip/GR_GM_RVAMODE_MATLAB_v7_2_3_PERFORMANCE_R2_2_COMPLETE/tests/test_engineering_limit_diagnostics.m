function test_engineering_limit_diagnostics()
d=struct();
d.finalMask=true;
d.detour=1.2; d.detourLimit=1.5;
d.riskObjective=0.4; d.riskObjectiveLimit=0.5;
d.meanRisk=0.3; d.meanRiskLimit=0.4;
d.tailRisk=0.5; d.tailRiskLimit=0.6;
d.energy=120; d.energyLimit=100;
d.smoothness=0.2; d.smoothnessLimit=0.15;
d.minimumQuality=0.8; d.minimumQualityLimit=0.65;
d.criticalQuality=0.9; d.criticalQualityLimit=0.75;
d.observationLength=220; d.observationLengthLimit=180;
d.losRatio=0.8; d.losRatioLimit=0.45;
d.dispersion=0.1; d.dispersionLimit=0.22;
r=selection.engineeringLimitDiagnostics(d,1,1e-8);
failed={r(~[r.passed]).name};
assert(any(strcmp(failed,'energy')));
assert(any(strcmp(failed,'smoothness')));
assert(sum(~[r.passed])==2);
fprintf('test_engineering_limit_diagnostics passed.\n');
end
