function test_final_stage_operator_adaptation
cfg = config.defaultConfig();
state = operators.initializeFinalStageOperatorState(cfg);
p0 = state.probabilities;
state = operators.updateFinalStageOperatorState( ...
    state,[10 10 10 10 10],[8 1 1 1 1],[1.2 0.01 0.01 0.01 0.01],cfg);
assert(abs(sum(state.probabilities)-1)<1e-12);
assert(all(state.probabilities>=cfg.finalStageOperatorProbabilityMin-1e-12));
assert(all(state.probabilities<=cfg.finalStageOperatorProbabilityMax+1e-12));
assert(state.probabilities(1)>p0(1));
assert(state.totalUses(1)==10 && state.totalAccepted(1)==8);
fprintf('test_final_stage_operator_adaptation passed.\n');
end
