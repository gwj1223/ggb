function test_snap_final_threshold()
% Consecutive high final-feasibility rates must commit all final thresholds.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig(); cfg.snapFinalPatience=3;
state=evaluation.initializeMonitoringThresholdState(cfg);
template.staticCV=0;
template.monitorPerTarget=0.8*ones(4,1);
template.monitorStats.truePerTarget=template.monitorPerTarget;
template.monitorStats.criticalQuality=0.9;
template.monitorStats.trueCriticalQuality=0.9;
template.monitorStats.observationLength=20*ones(4,1);
template.monitorStats.losRatio=0.9*ones(4,1);
pop=repmat(template,12,1);
for k=0:2
    [state,changed,diag]=evaluation.updateMonitoringThresholdState( ...
        state,1.0,cfg.monitorConstraintStartGeneration+k,cfg,pop); %#ok<ASGLU>
end
assert(state.finalReached);
assert(strcmp(state.lastAction,'snap_final'));
assert(state.lastActionCode==4);
assert(abs(state.minimum-cfg.monitorMinTargetQuality)<1e-12);
assert(abs(state.critical-cfg.monitorCriticalMinQuality)<1e-12);
assert(diag.predictedFinalRate==1);
fprintf('test_snap_final_threshold passed.\n');
end
