function test_unified_mission_noncompensation()
%TEST_UNIFIED_MISSION_NONCOMPENSATION One severe deficit cannot be averaged away.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.defaultConfig();
cfg.enableUnifiedMissionDeficit = true;
cfg.criticalTargetIndices = [1 2];
cfg.monitorCriticalMinObservationLength = 180;
cfg.unifiedMissionDeficitWeights = [0.40 0.15 0.30 0.15];
cfg.missionDeficitAverageBlend = 0.15;
cfg.missionQualityWorstWeight = 0.85;
cfg.missionGeometryWorstWeight = 0.90;

% Only Qmin is catastrophically bad; other formal components are excellent.
a = localFixture([0.00 0.80 0.80],0.80,300,0.95);
ia = evaluation.missionDeficitComponents(a,cfg);
assert(ia.minimumQualityDeficit > 0.80);
assert(ia.total > 0.70); % Chebyshev-dominant: severe Q loss remains severe.

% Four modest deficits must not outrank the catastrophic one merely by sum.
b = localFixture([0.30 0.50 0.50],0.40,165,0.42);
ib = evaluation.missionDeficitComponents(b,cfg);
assert(ib.total < ia.total);
assert(~ia.formalSatisfied && ~ib.formalSatisfied);

fprintf('test_unified_mission_noncompensation passed.\n');
end

function ind = localFixture(q,criticalQ,obs,los)
ind.monitorPerTarget = q(:);
ind.monitorStats.truePerTarget = q(:);
ind.monitorStats.criticalQuality = criticalQ;
ind.monitorStats.trueCriticalQuality = criticalQ;
ind.monitorStats.observationLength = [obs;obs;300];
ind.monitorStats.losRatio = [los;los;0.9];
ind.monitorStats.minimumCriticalObservationLength = obs;
ind.monitorStats.minimumCriticalLOSRatio = los;
end
