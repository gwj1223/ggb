function test_shiyan_g1_data()
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
D=realdata.loadProcessedDEM(fullfile(root,'data_real','processed','Shiyan_G1_DEM.mat'));
assert(size(D.Z,1)>300 && size(D.Z,2)>300);
assert(min(D.Z(:))>300 && max(D.Z(:))>1600);
assert(all(D.risk(:)>=0 & D.risk(:)<=1));
assert(max(D.slopeDeg(:))>50);
assert(abs(diff(D.roiBoundsLonLat([1 3]))-0.10)<0.01);
fprintf('test_shiyan_g1_data passed.\n');
end
