function test_dense_final_agl_repair()
%TEST_DENSE_FINAL_AGL_REPAIR Dense final validation respects formal AGL.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.multiUAVShiyanConfig();
[problem,cfg] = realdata.buildShiyanG1Problem(root,cfg);
cfg.numWaypoints = 18;
q = linspace(0,1,cfg.numWaypoints+2)'; q = q(2:end-1);
xy = problem.start(1:2)+q.*(problem.goal(1:2)-problem.start(1:2));
h = data.terrainHeight(problem,xy(:,1),xy(:,2));
pts = [xy,h+cfg.realMaximumAGL+40];
pop = core.initializePopulation(problem,cfg);
ind = pop(1);
ind.genes = reshape(pts,1,[]);
ind = repair.repairPath(ind,problem,cfg);
ind = evaluation.evaluateIndividual(ind,problem,cfg,1);
[ind,stats] = repair.finalizeLocalAGL(ind,problem,cfg,1);
% v6.5.7 may skip the mutation/evaluation if the ordinary repair already
% produced a path that passes the dense FORMAL AGL validation.
assert(stats.evaluations==0 || stats.evaluations==1);
assert(stats.formalAGLOKAfter);
assert(stats.minAGLAfter >= cfg.safeClearance-1e-6);
assert(stats.maxAGLAfter <= cfg.realMaximumAGL+1e-6);
assert(all(isfinite(ind.objectives)));
fprintf('test_dense_final_agl_repair passed: AGL [%.3f, %.3f] m.\n', ...
    stats.minAGLAfter,stats.maxAGLAfter);
end
