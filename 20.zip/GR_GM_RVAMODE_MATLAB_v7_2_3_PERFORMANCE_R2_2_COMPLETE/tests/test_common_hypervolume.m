function test_common_hypervolume
cfg = config.defaultConfig();
cfg.hvSamples = 4000;
samples = metrics.createHVSamples(cfg);
a = localIndividual([1.20 0.30 170 0.15 0.40],0.70);
b = localIndividual([1.20 0.30 170 0.15 0.40],0.85);
hvA = metrics.approxCommonHypervolumeFixed(a,cfg,samples);
hvB = metrics.approxCommonHypervolumeFixed(b,cfg,samples);
assert(isfinite(hvA) && isfinite(hvB));
assert(hvB>=hvA-1e-12);
obj = metrics.commonObjectiveMatrix([a;b]);
assert(size(obj,2)==5);
assert(abs(obj(1,5)-0.30)<1e-12);
value = metrics.finalStageCostIndicator([a;b],cfg);
assert(numel(value)==2 && all(isfinite(value)));
fprintf('test_common_hypervolume passed.\n');
end

function ind = localIndividual(objectives,minQ)
ind.objectives = objectives;
ind.cv = 0;
ind.monitorStats.minimumQuality = minQ;
end
