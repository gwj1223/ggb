function test_trial_context_equivalence()
% Cached generation context must not change the stochastic trial operator.
root = fileparts(fileparts(mfilename('fullpath')));
setupProject(root);
cfg = config.fastConfig();
cfg.populationSize = 8;
cfg.numWaypoints = 6;
problem = data.createDemoProblem(cfg);
pop = core.initializePopulation(problem,cfg);
pop = evaluation.evaluatePopulation(pop,problem,cfg,1);
archive = selection.updateArchive([],pop,cfg.archiveSize,cfg);
ctx = operators.buildTrialContext(pop,archive,cfg);

muF = cfg.initialMuF;
muCR = cfg.initialMuCR;
strategyProb = core.normalizeStrategyProbabilities([0.40 0.35 0.25],cfg);
seed = 20260902;

rng(seed,'twister');
[a,Fa,CRa,sa] = operators.generateTrial(1,pop,archive, ...
    muF,muCR,strategyProb,problem,cfg,1,ctx);
rng(seed,'twister');
[b,Fb,CRb,sb] = operators.generateTrial(1,pop,archive, ...
    muF,muCR,strategyProb,problem,cfg,1);

assert(sa == sb);
assert(abs(Fa-Fb) < 1e-15);
assert(abs(CRa-CRb) < 1e-15);
assert(max(abs(a.genes-b.genes)) < 1e-12);
fprintf('test_trial_context_equivalence passed.\n');
end
