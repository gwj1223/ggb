function test_static_mission_pareto_hierarchy()
%TEST_STATIC_MISSION_PARETO_HIERARCHY Static feasibility is non-negotiable.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.defaultConfig();
cfg.enableUnifiedMissionDeficit = true;
cfg.criticalTargetIndices = [1 2];
cfg.monitorCriticalMinObservationLength = 180;
cfg.runtimeMissionDeficitEpsilon = 0;
cfg.runtimeMissionStage = 'formal';

badMission = localFixture([0.05 0.60 0.60],0.30,80,0.20);
badMission.staticCV = 0;
badMission = evaluation.updateDynamicConstraints(badMission,cfg,100);
assert(~badMission.feasible && badMission.selectionTier==2);
assert(badMission.cv>0 && badMission.cv<=1+1e-12);

goodMissionBadFlight = localFixture([0.50 0.60 0.60],0.55,220,0.70);
goodMissionBadFlight.staticCV = 1e-3;
goodMissionBadFlight = evaluation.updateDynamicConstraints( ...
    goodMissionBadFlight,cfg,100);
assert(~goodMissionBadFlight.feasible && goodMissionBadFlight.selectionTier==3);
assert(goodMissionBadFlight.cv>1);
assert(badMission.cv < goodMissionBadFlight.cv);

good = localFixture([0.50 0.60 0.60],0.55,220,0.70);
good.staticCV = 0;
good = evaluation.updateDynamicConstraints(good,cfg,100);
assert(good.feasible && good.selectionTier==1 && abs(good.cv)<1e-12);
fprintf('test_static_mission_pareto_hierarchy passed.\n');
end

function ind = localFixture(q,criticalQ,obs,los)
ind.monitorPerTarget = q(:);
ind.monitorStats.truePerTarget = q(:);
ind.monitorStats.criticalQuality = criticalQ;
ind.monitorStats.trueCriticalQuality = criticalQ;
ind.monitorStats.observationLength = [obs;obs;300];
ind.monitorStats.losRatio = [los;los;0.9];
ind.monitorStats.minimumCriticalObservationLength = obs;
ind.monitorStats.minimumCriticalLOSRatio = los;
ind.violation.collision = 0;
ind.violation.clearance = 0;
ind.violation.climb = 0;
ind.violation.turn = 0;
ind.violation.energy = 0;
end
