function test_unified_mission_deficit()
%TEST_UNIFIED_MISSION_DEFICIT Four formal constraints define one scalar.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.defaultConfig();
cfg.enableUnifiedMissionDeficit = true;
cfg.criticalTargetIndices = [1 2];
cfg.monitorCriticalMinObservationLength = 180;

ind.monitorPerTarget = [0.20;0.50;0.60];
ind.monitorStats.truePerTarget = ind.monitorPerTarget;
ind.monitorStats.criticalQuality = 0.35;
ind.monitorStats.trueCriticalQuality = 0.35;
ind.monitorStats.observationLength = [90;220;300];
ind.monitorStats.losRatio = [0.30;0.70;0.90];
ind.monitorStats.minimumCriticalObservationLength = 90;
ind.monitorStats.minimumCriticalLOSRatio = 0.30;
info = evaluation.missionDeficitComponents(ind,cfg);
assert(all(info.components>0));
assert(info.total>0 && info.total<=1);

ok = ind;
ok.monitorPerTarget = [0.40;0.50;0.60];
ok.monitorStats.truePerTarget = ok.monitorPerTarget;
ok.monitorStats.criticalQuality = 0.45;
ok.monitorStats.trueCriticalQuality = 0.45;
ok.monitorStats.observationLength = [200;220;300];
ok.monitorStats.losRatio = [0.55;0.70;0.90];
ok.monitorStats.minimumCriticalObservationLength = 200;
ok.monitorStats.minimumCriticalLOSRatio = 0.55;
okInfo = evaluation.missionDeficitComponents(ok,cfg);
assert(okInfo.total<=1e-12);
assert(okInfo.formalSatisfied);
assert(evaluation.finalMonitoringDeficit(ok,cfg) < ...
    evaluation.finalMonitoringDeficit(ind,cfg));
fprintf('test_unified_mission_deficit passed.\n');
end
