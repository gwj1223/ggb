function test_structured_monitoring_layout()
cfg=config.defaultConfig();
cfg.enableStructuredMonitoringEncoding=true;
cfg.numWaypoints=20;
problem=data.createDemoProblem(cfg);
layout=core.structuredMonitoringLayout(problem,cfg);
assert(layout.targetCount==4);
assert(layout.dimension==21);
assert(isequal(size(layout.targetDims),[4 4]));
assert(numel(layout.transitDims)==5);
assert(numel(unique([layout.targetDims(:);layout.transitDims(:)]))==21);
config.validateConfig(cfg,problem);
fprintf('test_structured_monitoring_layout passed.\n');
end
