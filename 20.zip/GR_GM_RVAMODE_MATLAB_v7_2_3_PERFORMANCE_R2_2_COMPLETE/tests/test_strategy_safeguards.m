function test_strategy_safeguards()
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig();
p=core.normalizeStrategyProbabilities([0 0 100],cfg);
assert(abs(sum(p)-1)<1e-12);
assert(all(p>=cfg.strategyProbabilityMin-1e-12));
assert(p(3)<=cfg.monitorStrategyMaxProbability+1e-12);
t1=evaluation.currentMonitoringThresholds(1,cfg);
t2=evaluation.currentMonitoringThresholds( ...
    cfg.monitorConstraintStartGeneration+cfg.monitorConstraintRampGenerations,cfg);
assert(t1.minimum==0 && t1.observationLength==0 && t1.losRatio==0);
assert(abs(t2.minimum-cfg.monitorMinTargetQuality)<1e-12);
assert(abs(t2.critical-cfg.monitorCriticalMinQuality)<1e-12);
assert(abs(t2.observationLength- ...
    cfg.monitorCriticalMinObservationLength)<1e-12);
assert(abs(t2.losRatio-cfg.monitorCriticalMinLOSRatio)<1e-12);
% v7.1.0 architectural guard: scheduled mission=0 must not force mutation
% credit into the physical-infeasibility branch while static-feasible paths exist.
runText=fileread(fullfile(root,'src','+core','runGRAHMODE.m'));
assert(contains(runText,'strategyCreditCount = staticFeasibleCount'), ...
    'Mission-Band strategy credit must use static feasibility, not scheduled feasibility.');
disp('test_strategy_safeguards passed.');
end
