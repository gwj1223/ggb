function test_feedback_threshold_controller()
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.defaultConfig();
state = evaluation.initializeMonitoringThresholdState(cfg);
[state,changed] = evaluation.updateMonitoringThresholdState( ...
    state,1.0,cfg.monitorConstraintStartGeneration-1,cfg);
assert(~changed && state.minimum==0 && state.critical==0);

% A weak noncritical target must no longer freeze critical and geometry
% thresholds. The minimum threshold may take a slow step when the population
% supports that smaller threshold, while the full step remains unsupported.
template.staticCV = 0;
template.monitorPerTarget = 0.002*ones(4,1);
template.monitorStats.criticalQuality = 0.9;
template.monitorStats.observationLength = 20*ones(4,1);
template.monitorStats.losRatio = ones(4,1);
pop = repmat(template,12,1);
[state,changed] = evaluation.updateMonitoringThresholdState( ...
    state,1.0,cfg.monitorConstraintStartGeneration,cfg,pop);
assert(changed && state.lastActionCode==2);
slowMinimum = cfg.monitorThresholdSlowFactor * cfg.monitorThresholdStepMinimum;
assert(abs(state.minimum-slowMinimum)<1e-12);
assert(state.minimum < cfg.monitorThresholdStepMinimum);
assert(state.critical>0 && state.observationLength>0 && state.losRatio>0);
assert(strcmp(state.lastAction,'component_increase'));

% Once the population supports the full minimum-quality step, that component
% advances by one full step from the current value.
for i=1:numel(pop)
    pop(i).monitorPerTarget = 0.5*ones(4,1);
end
oldMinimum = state.minimum;
[state,changed] = evaluation.updateMonitoringThresholdState( ...
    state,1.0,cfg.monitorConstraintStartGeneration+1,cfg,pop);
assert(changed && state.lastActionCode==2);
assert(abs(state.minimum-(oldMinimum+cfg.monitorThresholdStepMinimum))<1e-12);
assert(state.observationLength>=cfg.monitorThresholdStepObservationLength);

runtimeCfg = evaluation.applyMonitoringThresholdState(cfg,state);
th = evaluation.currentMonitoringThresholds(999,runtimeCfg);
assert(abs(th.minimum-state.minimum)<1e-12);
assert(abs(th.observationLength-state.observationLength)<1e-12);
assert(abs(th.losRatio-state.losRatio)<1e-12);
fprintf('test_feedback_threshold_controller passed.\n');
end
