function test_engineering_report_filter
% Attractive short routes must not bypass risk-aware report limits.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.defaultConfig();
unsafeSmooth = localIndividual(cfg,1.394,0.20,0.16,0.30,190,0.191,0.90);
unsafeRisk = localIndividual(cfg,1.250,0.39,0.29,0.64,172,0.080,0.74);
safeCost = localIndividual(cfg,1.300,0.31,0.23,0.53,178,0.100,0.72);
safeKnee = localIndividual(cfg,1.330,0.28,0.21,0.50,182,0.130,0.75);
archive = [unsafeSmooth;unsafeRisk;safeCost;safeKnee];

[strictMask,details] = selection.engineeringLimitMask( ...
    archive,cfg,'strict',archive);
assert(~strictMask(1));
assert(~strictMask(2));
assert(strictMask(3) && strictMask(4));
assert(details.smoothnessLimit==cfg.finalReportedSmoothnessLimit);
assert(details.riskObjectiveLimit==cfg.finalReportedMaximumRiskObjective);
assert(details.tailRiskLimit==cfg.finalReportedMaximumTailRisk);

[knee,kneeIndex,~,kneeDetails] = ...
    selection.selectCommonKneeSolution(archive,cfg);
assert(kneeIndex>=3);
assert(knee.objectives(4)<=cfg.finalReportedSmoothnessLimit+eps);
assert(knee.riskStats.objective<=cfg.finalReportedMaximumRiskObjective+eps);
assert(strcmp(kneeDetails.level,'strict_engineering'));

[minCost,minIndex,~,costDetails] = ...
    selection.selectMinimumPhysicalCostSolution(archive,cfg);
assert(minIndex>=3);
assert(minCost.riskStats.tailRisk<=cfg.finalReportedMaximumTailRisk+eps);
assert(strcmp(costDetails.level,'strict_engineering'));

[riskBalanced,riskIndex,~,riskDetails] = ...
    selection.selectRiskBalancedSolution(archive,cfg);
assert(riskIndex>=3);
assert(riskBalanced.riskStats.objective<= ...
    cfg.finalReportedMaximumRiskObjective+eps);
assert(strcmp(riskDetails.level,'strict_engineering'));

reps.labels = {'CommonKneePoint';'MinimumPhysicalCost';'RiskBalanced'};
reps.solutions = [unsafeSmooth;minCost;riskBalanced];
[reported,label,~,level] = ...
    selection.selectReportedSolution(reps,archive,cfg);
assert(strcmp(label,'RiskBalanced'));
assert(reported.riskStats.tailRisk<=cfg.finalReportedMaximumTailRisk+eps);
assert(strcmp(level,'strict_engineering'));
fprintf('test_engineering_report_filter passed.\n');
end

function ind = localIndividual(cfg,detour,risk,meanRisk,tailRisk,energy,smooth,qmin)
ind.objectives = [detour risk energy smooth 1-qmin];
ind.cv = 0;
ind.staticCV = 0;
ind.feasible = true;
ind.pathMetrics = struct('rawLength',detour*100, ...
    'directDistance',100,'detourRatio',detour);
ind.riskStats = struct('objective',risk,'meanRisk',meanRisk, ...
    'tailRisk',tailRisk);
ind.energyStats = struct('total',energy);
ind.monitorPerTarget = [qmin;0.90;0.88;0.92];
ind.monitorStats.truePerTarget = ind.monitorPerTarget;
ind.monitorStats.minimumQuality = qmin;
ind.monitorStats.criticalQuality = 0.89;
ind.monitorStats.trueCriticalQuality = 0.89;
ind.monitorStats.observationLength = ...
    (cfg.monitorCriticalMinObservationLength+4)*ones(4,1);
ind.monitorStats.losRatio = ...
    (cfg.monitorCriticalMinLOSRatio+0.2)*ones(4,1);
ind.monitorStats.minimumCriticalObservationLength = ...
    cfg.monitorCriticalMinObservationLength+4;
ind.monitorStats.minimumCriticalLOSRatio = ...
    cfg.monitorCriticalMinLOSRatio+0.2;
ind.monitorStats.dispersionPenalty = 0.08;
end
