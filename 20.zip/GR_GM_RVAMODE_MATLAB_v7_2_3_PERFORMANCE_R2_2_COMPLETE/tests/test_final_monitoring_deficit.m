function test_final_monitoring_deficit()
% Improving the weakest target must reduce the mission-oriented deficit.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig();
base.monitorPerTarget=[0;0.8;0.8;0.8];
base.monitorStats.truePerTarget=base.monitorPerTarget;
base.monitorStats.criticalQuality=0.8;
base.monitorStats.trueCriticalQuality=0.8;
base.monitorStats.minimumCriticalObservationLength=12;
base.monitorStats.minimumCriticalLOSRatio=0.9;
base.monitorStats.worstCoverageDeficit=0.9;
better=base;
better.monitorPerTarget(1)=0.4;
better.monitorStats.truePerTarget=better.monitorPerTarget;
better.monitorStats.worstCoverageDeficit=0.1;
assert(evaluation.finalMonitoringDeficit(better,cfg)< ...
    evaluation.finalMonitoringDeficit(base,cfg));
fprintf('test_final_monitoring_deficit passed.\n');
end
