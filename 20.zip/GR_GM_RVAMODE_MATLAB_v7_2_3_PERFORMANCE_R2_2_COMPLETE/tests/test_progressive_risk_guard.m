function test_progressive_risk_guard
cfg = config.defaultConfig();
cfg.runtimeFinalStageGeneration = cfg.finalStageRiskTighteningGenerations;
best = localIndividual(cfg,0.35,0.58);
safer = localIndividual(cfg,0.33,0.54);
riskier = localIndividual(cfg,0.36,0.60);
[acceptedSafe,diagSafe] = ...
    operators.isFinalStageCostImprovement(safer,best,cfg);
[acceptedRisky,diagRisky] = ...
    operators.isFinalStageCostImprovement(riskier,best,cfg);
assert(diagSafe.progressiveRiskGuard);
assert(diagSafe.progressiveTailRiskGuard);
assert(acceptedSafe);
assert(~acceptedRisky);
assert(~diagRisky.progressiveRiskGuard || ...
    ~diagRisky.progressiveTailRiskGuard || ~diagRisky.riskGuard);
fprintf('test_progressive_risk_guard passed.\n');
end

function ind = localIndividual(cfg,risk,tailRisk)
ind.objectives = [1.30 risk 180 0.10 0.20];
ind.cv = 0;
ind.staticCV = 0;
ind.feasible = true;
ind.riskStats = struct('objective',risk,'meanRisk',0.75*risk, ...
    'tailRisk',tailRisk);
ind.monitorPerTarget = [0.75;0.85;0.86;0.78];
ind.monitorStats.truePerTarget = ind.monitorPerTarget;
ind.monitorStats.minimumQuality = 0.75;
ind.monitorStats.criticalQuality = 0.85;
ind.monitorStats.trueCriticalQuality = 0.85;
ind.monitorStats.minimumCriticalObservationLength = 12;
ind.monitorStats.minimumCriticalLOSRatio = 0.75;
ind.monitorStats.dispersionPenalty = 0.08;
ind.monitorStats.observationLength = 12*ones(4,1);
ind.monitorStats.losRatio = 0.75*ones(4,1);
end
