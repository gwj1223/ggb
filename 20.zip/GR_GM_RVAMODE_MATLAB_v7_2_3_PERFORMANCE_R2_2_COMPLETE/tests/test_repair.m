function test_repair
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig(); problem=data.createDemoProblem(cfg);
ind=struct('genes',200*randn(1,3*cfg.numWaypoints),'path',[],'objectives',[],'cv',inf,'feasible',false,'rank',inf,'crowding',0);
ind=repair.repairPath(ind,problem,cfg); pts=reshape(ind.genes,[],3);
assert(all(pts(:,1)>=problem.xBounds(1) & pts(:,1)<=problem.xBounds(2)));
assert(all(pts(:,2)>=problem.yBounds(1) & pts(:,2)<=problem.yBounds(2)));
fprintf('test_repair passed.\n');
end
