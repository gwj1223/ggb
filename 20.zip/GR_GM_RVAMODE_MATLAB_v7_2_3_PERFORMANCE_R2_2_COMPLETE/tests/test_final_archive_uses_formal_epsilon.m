function test_final_archive_uses_formal_epsilon()
%TEST_FINAL_ARCHIVE_USES_FORMAL_EPSILON Explicit final thresholds override runtime epsilon.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.defaultConfig();
cfg.enableUnifiedMissionDeficit = true;
cfg.criticalTargetIndices = [1 2];
cfg.monitorCriticalMinObservationLength = 180;
cfg.runtimeMissionDeficitEpsilon = 0.80; % relaxed live formation state
cfg.runtimeMissionStage = 'formation';

ind = localFixture([0.20 0.60 0.60],0.50,220,0.80);
ind.staticCV = 0;
% Under live epsilon this candidate is intentionally admissible.
live = evaluation.updateDynamicConstraints(ind,cfg,50);
assert(live.feasible);

% Final-archive evaluation must force epsilon=0 and reject it.
formal.minimum = cfg.monitorMinTargetQuality;
formal.critical = cfg.monitorCriticalMinQuality;
formal.observationLength = cfg.monitorCriticalMinObservationLength;
formal.losRatio = cfg.monitorCriticalMinLOSRatio;
formal.progress = 1;
formal.missionDeficitEpsilon = 0;
formal.missionStage = 'formal';
final = evaluation.updateDynamicConstraints(ind,cfg,50,formal);
assert(~final.feasible);
assert(final.selectionTier==2);
assert(final.missionDeficit>0);

fprintf('test_final_archive_uses_formal_epsilon passed.\n');
end

function ind = localFixture(q,criticalQ,obs,los)
ind.monitorPerTarget = q(:);
ind.monitorStats.truePerTarget = q(:);
ind.monitorStats.criticalQuality = criticalQ;
ind.monitorStats.trueCriticalQuality = criticalQ;
ind.monitorStats.observationLength = [obs;obs;300];
ind.monitorStats.losRatio = [los;los;0.9];
ind.monitorStats.minimumCriticalObservationLength = obs;
ind.monitorStats.minimumCriticalLOSRatio = los;
ind.violation.collision = 0;
ind.violation.clearance = 0;
ind.violation.climb = 0;
ind.violation.turn = 0;
ind.violation.energy = 0;
end
