function test_waypoint_block_crossover()
%TEST_WAYPOINT_BLOCK_CROSSOVER X/Y/Z of a waypoint change together.
root = fileparts(fileparts(mfilename('fullpath')));
setupProject(root);
cfg = config.defaultConfig();
cfg.numWaypoints = 3;
cfg.maxGenerations = 1;
cfg.Fmin = 0.5;
cfg.Fmax = 0.5;
cfg.CRmin = 0;
cfg.CRmax = 0;
cfg.waypointBlockCrossover = true;
cfg.useCauchyF = false;

template = struct('genes',zeros(1,9),'feasible',true,'cv',0, ...
    'objectives',zeros(1,5),'monitorStats',struct('worstTargetIndex',1), ...
    'monitorPerTarget',1,'path',zeros(5,3));
pop = repmat(template,5,1);
for i = 1:numel(pop)
    pop(i).genes = i^2+(1:9);
    pop(i).objectives = [i i i i i];
end
problem.monitorTargets = [0 0 0 1 1];
[trial,~,~,sid] = operators.generateTrial(1,pop,[], ...
    [0.5 0.5 0.5],[0 0 0],[1 0 0],problem,cfg,1);
assert(sid==1);
changed = find(abs(trial.genes-pop(1).genes)>1e-12);
assert(numel(changed)==3);
k = mod(changed(1)-1,cfg.numWaypoints)+1;
assert(isequal(sort(changed),sort([k k+cfg.numWaypoints ...
    k+2*cfg.numWaypoints])));
disp('test_waypoint_block_crossover passed.');
end
