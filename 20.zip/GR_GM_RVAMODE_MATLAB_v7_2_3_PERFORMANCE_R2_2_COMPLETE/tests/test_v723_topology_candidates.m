function test_v723_topology_candidates()
%TEST_V723_TOPOLOGY_CANDIDATES Budget/limit invariants for topology alternatives.
cfg=struct();
cfg.structuredTransitTopologyCandidateLimit=6;
cfg.structuredTransitMinimumBoundaryConnectors=1;
cfg.structuredTransitMaximumBoundaryConnectors=2;
cfg.structuredTransitMaximumConnectorsPerLeg=2;
cfg.maxTurnAngleDeg=95;

primary=[2 1 1 1 1 1 0 0 0 0 1];
budget=8;
score=ones(11,1);
score(7)=100; % force a terrain-oriented alternative to cover leg 7
turnCost=repmat([70 55 50],11,1);
turnCost(1,:)=[145 110 84];
turnCost(end,:)=[132 84 103];

C=core.generateStructuredConnectorTopologies(primary,budget,score,turnCost,cfg);
assert(~isempty(C));
assert(isequal(C(1,:),primary),'Primary connector topology must remain candidate 1.');
assert(size(C,1)<=cfg.structuredTransitTopologyCandidateLimit);
assert(all(sum(C,2)==budget),'Every topology must preserve the fixed connector budget.');
assert(all(C(:)>=0 & C(:)<=2),'Every leg must retain the 0/1/2 connector contract.');
assert(all(C(:,1)>=1) && all(C(:,end)>=1),'Boundary connector minima must be preserved.');
assert(size(unique(C,'rows'),1)==size(C,1),'Topology candidates must be unique.');
assert(size(C,1)>=2,'The generator must expose at least one alternative topology.');
assert(any(C(:,7)>0),'Terrain-oriented alternatives should be able to cover a hard uncovered leg.');
fprintf('test_v723_topology_candidates passed. candidates=%d\n',size(C,1));
end
