function test_structured_legacy_xyz_local_search_disabled()
cfg=config.defaultConfig();
cfg.enableStructuredMonitoringEncoding=true;
cfg.structuredDisableLegacyXYZLocalSearch=true;
cfg.populationSize=8;
cfg.numWaypoints=20;
cfg.maxClimbAngleDeg=89;
cfg.maxTurnAngleDeg=179;
cfg.segmentRepairMargin=0;
cfg.enableLocalAGLConstraint=false;
problem=data.createDemoProblem(cfg);
problem.structuredMonitoringTargetOrder=core.structuredMonitoringTargetOrder(problem,cfg);
pop=core.initializePopulation(problem,cfg);
beforeGenes={pop.genes};
beforeStructured={pop.structuredGenes};
state=operators.initializeFinalStageOperatorState(cfg);
[next,stats,~]=operators.eliteLocalSearch(pop,problem,cfg,100,state);
assert(stats.evaluations==0 && stats.accepted==0);
for i=1:numel(pop)
    assert(isequaln(next(i).genes,beforeGenes{i}));
    assert(isequaln(next(i).structuredGenes,beforeStructured{i}));
end
fprintf('test_structured_legacy_xyz_local_search_disabled passed.\n');
end
