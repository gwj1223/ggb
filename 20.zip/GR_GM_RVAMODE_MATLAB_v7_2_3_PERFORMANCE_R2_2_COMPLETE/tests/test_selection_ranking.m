function test_selection_ranking()
%TEST_SELECTION_RANKING Check vectorized Deb/NSGA-II ranking.
template = struct('objectives',[0 0],'cv',0,'feasible',true, ...
    'rank',inf,'crowding',0);
pop = repmat(template,4,1);
pop(1).objectives = [1 2];
pop(2).objectives = [2 1];
pop(3).objectives = [2 2];
pop(4).objectives = [0 0]; pop(4).feasible = false; pop(4).cv = 0.1;
pop = selection.assignRankCrowding(pop);
assert(pop(1).rank==1 && pop(2).rank==1);
assert(pop(3).rank==2);
assert(pop(4).rank>pop(3).rank);
fprintf('test_selection_ranking passed.\n');
end
