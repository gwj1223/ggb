function test_segment_repair()
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig(); problem=data.createDemoProblem(cfg);
pts=repmat((problem.start+problem.goal)/2,cfg.numWaypoints,1);
pts(:,1)=linspace(problem.start(1),problem.goal(1),cfg.numWaypoints)';
pts(:,2)=linspace(problem.start(2),problem.goal(2),cfg.numWaypoints)';
pts(:,3)=0;
ind.genes=pts(:)'; ind=repair.repairPath(ind,problem,cfg);
ind=evaluation.evaluateIndividual(ind,problem,cfg);
assert(ind.violation.clearance<1e-5,'Segment repair left terrain-clearance violations.');
fprintf('test_segment_repair passed.\n');
end
