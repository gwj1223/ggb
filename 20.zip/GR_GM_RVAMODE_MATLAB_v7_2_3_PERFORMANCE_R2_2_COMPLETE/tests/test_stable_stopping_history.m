function test_stable_stopping_history
best = -inf; anchor = NaN; last = NaN;
[best,anchor,last,flag] = core.updateImprovementTracker( ...
    0.300,best,anchor,last,20,0.002,'maximize',false);
assert(flag && best==0.300 && last==20);
[best,anchor,last,flag] = core.updateImprovementTracker( ...
    0.301,best,anchor,last,25,0.002,'maximize',false);
assert(~flag && best==0.301 && anchor==0.300 && last==20);
[best,anchor,last,flag] = core.updateImprovementTracker( ...
    0.3025,best,anchor,last,30,0.002,'maximize',false);
assert(flag && best==0.3025 && anchor==0.3025 && last==30);

bestCost = inf; costAnchor = NaN; lastCost = NaN;
[bestCost,costAnchor,lastCost] = core.updateImprovementTracker( ...
    0.60,bestCost,costAnchor,lastCost,20,0.003,'minimize',true);
[bestCost,costAnchor,lastCost,flag] = core.updateImprovementTracker( ...
    0.599,bestCost,costAnchor,lastCost,25,0.003,'minimize',true);
assert(~flag && bestCost==0.599 && costAnchor==0.60 && lastCost==20);
[bestCost,costAnchor,lastCost,flag] = core.updateImprovementTracker( ...
    0.597,bestCost,costAnchor,lastCost,30,0.003,'minimize',true);
assert(flag && bestCost==0.597 && costAnchor==0.597 && lastCost==30);
fprintf('test_stable_stopping_history passed.\n');
end
