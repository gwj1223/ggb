function test_a3_static_safe_corridor_contract()
%TEST_A3_STATIC_SAFE_CORRIDOR_CONTRACT v7.0.3 geometry/diagnostic guard.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.multiUAVShiyanConfig();
assert(cfg.missionRepairTransitionPointsPerSide>=2);

arcText = fileread(fullfile(root,'src','+core','injectTargetObservationArc.m'));
assert(contains(arcText,'localBezierConnector'));
assert(contains(arcText,'routeIn'));
assert(contains(arcText,'routeOut'));
assert(contains(arcText,'arcStartTangent'));
assert(contains(arcText,'arcEndTangent'));

repairText = fileread(fullfile(root,'src','+core','unifiedMissionRepair.m'));
assert(contains(repairText,'staticCollision'));
assert(contains(repairText,'staticClearance'));
assert(contains(repairText,'staticClimb'));
assert(contains(repairText,'staticTurn'));
assert(contains(repairText,'staticEnergy'));
fprintf('test_a3_static_safe_corridor_contract passed.\n');
end
