function test_mission_band_reference_vector_selection()
%TEST_MISSION_BAND_REFERENCE_VECTOR_SELECTION Mission quota + objective diversity.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig();
cfg.enableUnifiedMissionDeficit=true;
cfg.enableMissionBandSelection=true;
cfg.missionBandMinFraction=0.50; % N=4 -> two protected mission leaders
cfg.missionBandTolerance=1e-10;
cfg.runtimeMissionDeficitEpsilon=0.14;
cfg.populationSize=4;
cfg.maxGenerations=20;
cfg.referenceVectorDivisions=2;
cfg.useReferenceVectorEnvironmentalSelection=true;

T=struct('objectives',zeros(1,5),'cv',0.5,'feasible',false, ...
    'rank',inf,'crowding',0,'staticCV',0,'staticFeasible',true, ...
    'missionScheduleFeasible',false,'formalMissionSatisfied',false, ...
    'missionDeficit',0.5,'missionDeficitEpsilon',0.14,'genes',zeros(1,2));
pop=repmat(T,8,1);
for i=1:8
    pop(i).genes=[i i];
    pop(i).missionDeficit=0.10+0.05*(i-1);
    pop(i).cv=max(0,pop(i).missionDeficit-0.14);
    pop(i).feasible=pop(i).missionDeficit<=0.14;
    pop(i).missionScheduleFeasible=pop(i).feasible;
end
% Candidate 1 is scheduled-admissible and must survive despite poor objectives.
pop(1).objectives=100*ones(1,5);
% Candidate 2 completes the protected mission-leader quota.
pop(2).objectives=90*ones(1,5);
% Low-D candidates 3:6 are deliberately poor in objective space.
for i=3:6, pop(i).objectives=(20+i)*ones(1,5); end
% Higher-D candidates 7 and 8 are the two objective-space leaders.
pop(7).objectives=ones(1,5);
pop(8).objectives=2*ones(1,5);

[~,idx]=selection.environmentalSelection(pop,4,cfg,10);
assert(ismember(1,idx),'Scheduled-mission candidate must be protected.');
assert(ismember(2,idx),'Mission-band quota candidate must be protected.');
assert(ismember(7,idx) && ismember(8,idx), ...
    'Remaining slots must recover five-objective selection, not exact D ranking.');
assert(~isequal(sort(idx(:))',(1:4)), ...
    'Mission-band selection must not collapse to the four smallest D values.');
fprintf('test_mission_band_reference_vector_selection passed.\n');
end
