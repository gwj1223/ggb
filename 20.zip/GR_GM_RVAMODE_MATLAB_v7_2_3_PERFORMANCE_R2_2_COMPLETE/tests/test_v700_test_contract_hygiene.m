function test_v700_test_contract_hygiene()
%TEST_V700_TEST_CONTRACT_HYGIENE Prevent stale pre-v7 test coupling.
% This test scans the registered test suite for assertions that hard-bind the
% current v7 multi-UAV workflow to retired interfaces or inactive controller
% tuning. Shared component tests are retained; only v7 integration-contract
% coupling is rejected.
root = fileparts(fileparts(mfilename('fullpath')));
runFile = fullfile(root,'run_all_tests.m');
runText = fileread(runFile);

% The suite banner itself must describe the current algorithm architecture.
assert(isempty(regexp(runText, ...
    'All\s+GR-GM-RVAMODE-VI\s+v6\.', 'once')), ...
    'run_all_tests still reports a pre-v7 suite banner.');

files = dir(fullfile(root,'tests','test_*.m'));
issues = {};
for k = 1:numel(files)
    name = files(k).name;
    if strcmp(name,'test_v700_test_contract_hygiene.m')
        continue;
    end
    p = fullfile(files(k).folder,name);
    raw = fileread(p);
    code = localStripCommentLines(raw);

    % Exact old allocator method label: implementation-label coupling.
    if contains(code,'''risk_observability_3d_route_balanced_exclusive''')
        issues{end+1} = sprintf('%s: exact pre-v7 allocation method label',name); %#ok<AGROW>
    end

    % Any assertion of a pre-v7 version literal is stale in the v7 suite.
    lines = regexp(code,'\r\n|\n|\r','split');
    for j = 1:numel(lines)
        s = strtrim(lines{j});
        if contains(s,'assert') && ~isempty(regexp(s,'''v6\.[0-9]', 'once'))
            issues{end+1} = sprintf('%s:%d: assertion hard-codes pre-v7 version', ...
                name,j); %#ok<AGROW>
        end
        if contains(s,'assert') && contains(s,'implementationVersion') && ...
                contains(s,'strcmp')
            issues{end+1} = sprintf('%s:%d: assertion hard-codes exact implementation version', ...
                name,j); %#ok<AGROW>
        end
    end

    % In a multi-UAV integration test, snapFinalFeasibleRate belongs to the
    % retired feedback controller and must not be an architecture invariant.
    if contains(code,'config.multiUAVShiyanConfig')
        for j = 1:numel(lines)
            s = strtrim(lines{j});
            if contains(s,'assert') && contains(s,'snapFinalFeasibleRate')
                issues{end+1} = sprintf('%s:%d: legacy snap-final tuning asserted', ...
                    name,j); %#ok<AGROW>
            end
        end
    end

    % Removed historical restoration functions must never be called by tests.
    % test_v700_logic_consolidation is allowed to mention their names only to
    % verify that the production files/calls are absent.
    if ~strcmp(name,'test_v700_logic_consolidation.m')
        removedCalls = {'initializeTargetMemory','updateTargetMemory', ...
            'restoreTargetMemoryElites','preserveMonitoringCoverage'};
        for r = 1:numel(removedCalls)
            pat = ['core\.' removedCalls{r} '\s*\('];
            if ~isempty(regexp(code,pat,'once'))
                issues{end+1} = sprintf('%s: calls removed legacy function %s', ...
                    name,removedCalls{r}); %#ok<AGROW>
            end
        end
    end
end

if ~isempty(issues)
    msg = sprintf('Historical test coupling detected:\n - %s', ...
        strjoin(issues,'\n - '));
    error('test_v700_test_contract_hygiene:StaleCoupling','%s',msg);
end
fprintf('test_v700_test_contract_hygiene passed.\n');
end

function out = localStripCommentLines(text)
% Remove MATLAB %-comments conservatively. This is a hygiene scanner, not a
% parser; quoted strings containing percent signs are not used by the patterns
% checked above.
lines = regexp(text,'\r\n|\n|\r','split');
for i = 1:numel(lines)
    p = strfind(lines{i},'%');
    if ~isempty(p)
        lines{i} = lines{i}(1:p(1)-1);
    end
end
out = strjoin(lines,newline);
end
