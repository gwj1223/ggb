function test_progressive_smoothness_guard
cfg = config.defaultConfig();
cfg.runtimeFinalStageGeneration = cfg.finalStageSmoothnessTighteningGenerations;

best = localIndividual([1.30 0.30 175 0.140],cfg);
betterSmooth = localIndividual([1.29 0.30 174 0.139],cfg);
assert(operators.isFinalStageCostImprovement(betterSmooth,best,cfg));

worseAboveLimit = localIndividual([1.28 0.29 173 0.145],cfg);
[accepted,diag] = operators.isFinalStageCostImprovement( ...
    worseAboveLimit,best,cfg);
assert(~accepted && ~diag.progressiveSmoothnessGuard);

bestBelow = localIndividual([1.30 0.30 175 0.130],cfg);
aboveTarget = localIndividual([1.28 0.29 173 0.136],cfg);
assert(~operators.isFinalStageCostImprovement(aboveTarget,bestBelow,cfg));
fprintf('test_progressive_smoothness_guard passed.\n');
end

function ind = localIndividual(obj,cfg)
ind.objectives = [obj 0.2];
ind.feasible = true;
ind.staticCV = 0;
ind.cv = 0;
ind.monitorPerTarget = [0.70;0.82;0.84;0.72];
ind.monitorStats.truePerTarget = ind.monitorPerTarget;
ind.monitorStats.minimumQuality = min(ind.monitorPerTarget);
ind.monitorStats.criticalQuality = mean(ind.monitorPerTarget([2 3]));
ind.monitorStats.trueCriticalQuality = ind.monitorStats.criticalQuality;
ind.monitorStats.dispersionPenalty = 0.08;
ind.monitorStats.observationLength = 12*ones(4,1);
ind.monitorStats.losRatio = 0.8*ones(4,1);
ind.monitorStats.minimumCriticalObservationLength = 12;
ind.monitorStats.minimumCriticalLOSRatio = 0.8;
ind.violation = struct('collision',0,'clearance',0,'climb',0, ...
    'turn',0,'energy',0);
end
