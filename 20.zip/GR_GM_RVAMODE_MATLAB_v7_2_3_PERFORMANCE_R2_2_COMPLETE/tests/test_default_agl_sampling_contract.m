function test_default_agl_sampling_contract()
%TEST_DEFAULT_AGL_SAMPLING_CONTRACT Default repair/evaluator share fixed grid.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig();
policy=evaluation.aglSamplingPolicy(cfg);
assert(~policy.isAdaptive);
assert(strcmp(policy.mode,'fixed'));
assert(policy.fixedSamples==cfg.segmentSamples);

repairText=fileread(fullfile(root,'src','+repair','repairSegmentClearance.m'));
evaluatorText=fileread(fullfile(root,'src','+evaluation','evaluateIndividual.m'));
assert(contains(repairText,'aglSamplingPolicy'));
assert(contains(repairText,'buildPathSampleCache'));
assert(contains(repairText,'policy.fixedSamples'));
assert(contains(evaluatorText,'aglSamplingPolicy'));

% Numerical guard: the legacy segment-repair fixture must be accepted by
% the evaluator after repair on the same fixed terrain grid.
problem=data.createDemoProblem(cfg);
pts=repmat((problem.start+problem.goal)/2,cfg.numWaypoints,1);
pts(:,1)=linspace(problem.start(1),problem.goal(1),cfg.numWaypoints)';
pts(:,2)=linspace(problem.start(2),problem.goal(2),cfg.numWaypoints)';
pts(:,3)=0;
ind.genes=pts(:)';
ind=repair.repairPath(ind,problem,cfg);
ind=evaluation.evaluateIndividual(ind,problem,cfg);
assert(ind.violation.clearance<1e-5, ...
    'Default fixed-grid repair/evaluator sampling contract diverged.');
fprintf('test_default_agl_sampling_contract passed.\n');
end
