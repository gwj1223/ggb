function test_multi_uav_subproblem()
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.multiUAVShiyanConfig();
[problem,cfg]=realdata.buildShiyanG1Problem(root,cfg);
a=multiUAV.allocateTargetsRiskAware(problem,cfg);
for k=1:cfg.multiUAVCount
    [p,c]=multiUAV.buildSubProblem(problem,cfg,a,k);
    idx=a.groups{k};
    assert(size(p.monitorTargets,1)==numel(idx));
    assert(isequal(p.monitorTargets,problem.monitorTargets(idx,:)));
    assert(isequal(p.globalTargetIndices(:),idx(:)));
    globalCritical=cfg.criticalTargetIndices(:);
    expected=find(ismember(idx(:),globalCritical))';
    assert(isequal(c.criticalTargetIndices,expected));
    assert(c.numWaypoints>=c.multiUAVMinWaypoints && ...
        c.numWaypoints<=c.multiUAVMaxWaypoints);
end
fprintf('test_multi_uav_subproblem passed.\n');
end
