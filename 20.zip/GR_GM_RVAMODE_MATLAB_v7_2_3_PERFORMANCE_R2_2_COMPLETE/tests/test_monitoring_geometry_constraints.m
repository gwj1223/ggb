function test_monitoring_geometry_constraints()
%TEST_MONITORING_GEOMETRY_CONSTRAINTS Check duration and LOS hard CV terms.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig(); cfg.populationSize=4;
problem=data.createDemoProblem(cfg);
pop=core.initializePopulation(problem,cfg);
ind=evaluation.evaluateIndividual(pop(1),problem,cfg,1);
th=struct('minimum',0,'critical',0, ...
    'observationLength',max(ind.monitorStats.observationLength)+1, ...
    'losRatio',1,'progress',1);
out=evaluation.updateDynamicConstraints(ind,cfg,1,th);
assert(out.violation.monitorObservationLength>=0);
assert(out.violation.monitorLOSRatio>=0);
assert(out.cv>=ind.staticCV-cfg.constraintTolerance);
fprintf('test_monitoring_geometry_constraints passed.\n');
end
