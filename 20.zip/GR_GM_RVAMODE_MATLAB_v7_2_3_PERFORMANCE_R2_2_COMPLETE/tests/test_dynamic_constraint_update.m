function test_dynamic_constraint_update()
% Cheap threshold update must match a complete re-evaluation.
root = fileparts(fileparts(mfilename('fullpath')));
setupProject(root);
cfg = config.fastConfig(); cfg.populationSize = 4;
problem = data.createDemoProblem(cfg);
pop = core.initializePopulation(problem,cfg);
base = evaluation.evaluateIndividual(pop(1),problem,cfg,1);
fast = evaluation.updateDynamicConstraints(base,cfg,70);
full = evaluation.evaluateIndividual(base,problem,cfg,70);
assert(max(abs(fast.objectives-full.objectives))<1e-12);
assert(abs(fast.cv-full.cv)<1e-12);
assert(fast.feasible==full.feasible);
fprintf('test_dynamic_constraint_update passed.\n');
end
