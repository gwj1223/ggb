function test_v723_dense_vectorized_dp_source_contract()
root=fileparts(fileparts(mfilename('fullpath')));
text=fileread(fullfile(root,'src','+core','projectDenseTerrainReachableProfile.m'));
assert(contains(text,'enableDenseProjectionVectorizedDP'));
assert(contains(text,'localVectorizedTransition'));
assert(contains(text,'localScalarTransition'));
assert(contains(text,'bsxfun'));
fprintf('test_v723_dense_vectorized_dp_source_contract passed.\n');
end
