function test_shared_agl_sampling_contract()
%TEST_SHARED_AGL_SAMPLING_CONTRACT Shiyan repair/evaluator share adaptive grid.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.multiUAVShiyanConfig();
policy=evaluation.aglSamplingPolicy(cfg);
assert(policy.isAdaptive);
assert(strcmp(policy.mode,'adaptive'));
assert(abs(policy.step_m-15)<1e-12);

samplerText=fileread(fullfile(root,'src','+evaluation', ...
    'sampleSegmentTerrainAdaptive.m'));
evaluatorText=fileread(fullfile(root,'src','+evaluation','evaluateIndividual.m'));
evalText=fileread(fullfile(root,'src','+evaluation', ...
    'evaluateLocalAGLEnvelope.m'));
repairText=fileread(fullfile(root,'src','+repair','repairSegmentClearance.m'));
denseText=fileread(fullfile(root,'src','+core', ...
    'projectDenseTerrainReachableProfile.m'));
assert(contains(samplerText,'aglConstraintSampleStep_m'));
assert(contains(evaluatorText,'aglSamplingPolicy'));
assert(contains(evalText,'sampleSegmentTerrainAdaptive'));
assert(contains(repairText,'aglSamplingPolicy'));
assert(contains(repairText,'sampleSegmentTerrainAdaptive'));
assert(~contains(repairText,'segmentRepairSamples'));
assert(contains(denseText,'sampleSegmentTerrainAdaptive'));

% Simple numeric spacing check.
[xg,yg]=meshgrid(0:1:100,0:1:5);
problem.gridX=xg; problem.gridY=yg;
problem.terrain=zeros(size(xg)); problem.risk=zeros(size(xg));
s=evaluation.sampleSegmentTerrainAdaptive([0 2 50],[100 2 50],problem,cfg);
assert(s.maximumSpacing_m<=policy.step_m+1e-12);
assert(size(s.points,1)==s.numSamples);
fprintf('test_shared_agl_sampling_contract passed.\n');
end
