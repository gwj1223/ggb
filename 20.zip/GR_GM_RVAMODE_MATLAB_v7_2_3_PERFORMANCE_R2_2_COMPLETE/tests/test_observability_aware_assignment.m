function test_observability_aware_assignment()
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.multiUAVShiyanConfig();
[problem,cfg] = realdata.buildShiyanG1Problem(root,cfg);

a = multiUAV.allocateTargetsObservabilityAware(problem,cfg);
b = multiUAV.allocateTargetsRiskAware(problem,cfg);
M = size(problem.monitorTargets,1);
K = cfg.multiUAVCount;

% Check v7 allocation semantics rather than an exact historical method label.
assert(contains(char(a.method),'knowledge_risk_observability_route_balanced_exclusive'));
assert(isfield(a,'monitoringKnowledge') && isstruct(a.monitoringKnowledge));
assert(strcmp(a.monitoringKnowledge.version,'v7.0.0-static-dem-los-knowledge'));
assert(isequal(a.targetToUAV,b.targetToUAV));
assert(sum(a.targetCount)==M);
assert(max(a.targetCount)-min(a.targetCount)<=1);
assert(sum(a.criticalCount)==numel(cfg.criticalTargetIndices));
assert(max(a.criticalCount)-min(a.criticalCount)<=1);
assert(numel(unique(vertcat(a.groups{:})))==M);
assert(numel(a.routeProxy_m)==K && all(isfinite(a.routeProxy_m)));
assert(numel(a.observabilityLoad)==K && all(isfinite(a.observabilityLoad)));
assert(numel(a.worstObservabilityDifficulty)==K && ...
    all(a.worstObservabilityDifficulty>=0 & a.worstObservabilityDifficulty<=1));
assert(all(isfinite(a.targetObservabilityScore)));
assert(isfinite(a.allocationScore));
assert(isfinite(a.transitMakespanProxy_s) && a.transitMakespanProxy_s>0);
assert(a.loadCV>=0 && a.riskLoadCV>=0 && a.observabilityLoadCV>=0);

% Ablation-compatible switch: disabling the observability term must still
% return a valid exact-quota allocation without changing the inner problem.
cfg0 = cfg;
cfg0.enableObservabilityAwareAllocation = false;
cfg0.multiUAVObservabilityDifficultyWeight = 0;
cfg0.multiUAVAllocationRiskBalanceWeight = 0;
cfg0.multiUAVAllocationObservabilityBalanceWeight = 0;
cfg0.multiUAVAllocationCriticalObservabilityBalanceWeight = 0;
cfg0.multiUAVAllocationWorstObservabilitySpreadWeight = 0;
a0 = multiUAV.allocateTargetsObservabilityAware(problem,cfg0);
assert(sum(a0.targetCount)==M);
assert(max(a0.targetCount)-min(a0.targetCount)<=1);
assert(sum(a0.criticalCount)==numel(cfg.criticalTargetIndices));
assert(max(a0.criticalCount)-min(a0.criticalCount)<=1);
fprintf('test_observability_aware_assignment passed.\n');
end
