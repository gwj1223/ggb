function test_monitoring_quality()
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root); cfg=config.defaultConfig(); cfg.populationSize=12; cfg.maxGenerations=2; p=data.createDemoProblem(cfg); pop=core.initializePopulation(p,cfg); pop=evaluation.evaluatePopulation(pop,p,cfg); assert(all(arrayfun(@(x) x.monitorQuality>=0 && x.monitorQuality<=1,pop))); assert(size(vertcat(pop.objectives),2)==5); disp('test_monitoring_quality passed.');
end
