function test_mission_band_preserves_formal_semantics()
%TEST_MISSION_BAND_PRESERVES_FORMAL_SEMANTICS Search admission is not feasibility.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig();
cfg.enableUnifiedMissionDeficit=true;
cfg.enableMissionBandSelection=true;
cfg.missionBandMinFraction=0.50;
cfg.runtimeMissionDeficitEpsilon=0;
cfg.populationSize=4;

pop=repmat(struct('objectives',ones(1,5),'cv',0.4,'feasible',false, ...
    'rank',inf,'crowding',0,'staticCV',0,'staticFeasible',true, ...
    'missionScheduleFeasible',false,'formalMissionSatisfied',false, ...
    'missionDeficit',0.4,'missionDeficitEpsilon',0,'genes',zeros(1,2)),4,1);
for i=1:4
    pop(i).missionDeficit=0.30+0.05*i;
    pop(i).genes=[i i];
end
state=selection.missionBandState(pop,cfg,100,4);
assert(any(state.searchAdmissible));
idx=find(state.searchAdmissible,1,'first');
assert(~pop(idx).feasible);
assert(~pop(idx).missionScheduleFeasible);
assert(~pop(idx).formalMissionSatisfied);
assert(state.formalCount==0 && state.scheduledCount==0);

% Search-band tolerance must never widen the scheduled/formal epsilon contract.
cfg.runtimeMissionDeficitEpsilon=0.20;
cfg.missionDeficitScheduleTolerance=1e-12;
cfg.missionBandTolerance=1e-6;
pop(1).missionDeficit=0.20+5e-11;
pop(2).missionDeficit=0.21;
pop(3).missionDeficit=0.30;
pop(4).missionDeficit=0.40;
state=selection.missionBandState(pop,cfg,50,4);
assert(~state.scheduledAdmissible(1), ...
    'Mission-band tolerance must not relax scheduled mission feasibility.');
assert(state.searchAdmissible(1), ...
    'The same candidate may still be search-admissible inside the leader band.');
fprintf('test_mission_band_preserves_formal_semantics passed.\n');
end
