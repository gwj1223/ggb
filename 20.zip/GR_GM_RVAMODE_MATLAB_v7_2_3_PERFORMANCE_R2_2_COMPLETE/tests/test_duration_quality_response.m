function test_duration_quality_response()
% Longer required observation duration must not improve monitoring quality.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.fastConfig(); problem=data.createDemoProblem(cfg);
path=[problem.start; ...
    linspace(problem.start(1),problem.goal(1),cfg.numWaypoints)' ...
    linspace(problem.start(2),problem.goal(2),cfg.numWaypoints)' ...
    linspace(problem.start(3),problem.goal(3),cfg.numWaypoints)'; ...
    problem.goal];
cfg1=cfg; cfg1.monitorRequiredObservationLength=4;
cfg2=cfg; cfg2.monitorRequiredObservationLength=30;
[q1,~,s1]=evaluation.monitoringQuality(path,problem,cfg1);
[q2,~,s2]=evaluation.monitoringQuality(path,problem,cfg2);
assert(q2<=q1+1e-12);
assert(all(s2.durationQuality<=s1.durationQuality+1e-12));
fprintf('test_duration_quality_response passed.\n');
end
