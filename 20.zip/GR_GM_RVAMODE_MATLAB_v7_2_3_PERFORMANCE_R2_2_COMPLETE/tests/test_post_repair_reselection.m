function test_post_repair_reselection()
%TEST_POST_REPAIR_RESELECTION Representatives are validated before select.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.multiUAVShiyanConfig();
[problem,cfg] = realdata.buildShiyanG1Problem(root,cfg);
cfg.numWaypoints = 12;
pop = core.initializePopulation(problem,cfg);
pop = evaluation.evaluatePopulation(pop(1:8),problem,cfg,1);
reps.labels = {'RiskBalanced';'MinimumPhysicalCost';'Balanced'};
reps.solutions = reshape(pop(1:3),[],1);
reps.engineeringSatisfied = false(3,1);
reps.relaxedEngineeringSatisfied = false(3,1);
reps.finalConstraintsSatisfied = false(3,1);
reps.physicalCost = zeros(3,1);
reps.selectionLevels = {'test';'test';'test'};
[polished,stats] = repair.finalizeRepresentativeSetAGL(reps,problem,cfg,1);
assert(stats.candidateCount==3);
% v6.5.7 deliberately skips dense repair/evaluation when formal AGL is
% already valid, so evaluations may be lower than the candidate count.
assert(stats.totalEvaluations>=0 && stats.totalEvaluations<=3);
assert(stats.skippedFormalValidCount + stats.acceptedRepairCount + ...
    stats.rollbackCount <= 3);
assert(numel(polished.solutions)==3);
for i = 1:3
    assert(all(isfinite(polished.solutions(i).objectives)));
    assert(isfield(polished.solutions(i),'aglStats'));
end
[best,~,idx,~] = selection.selectReportedSolution( ...
    polished,polished.solutions,cfg);
matched = false;
for i = 1:numel(polished.solutions)
    if numel(best.genes)==numel(polished.solutions(i).genes) && ...
            max(abs(best.genes(:)-polished.solutions(i).genes(:)))<1e-10
        matched = true;
        break;
    end
end
assert(matched);
if ~isempty(idx) && isfinite(idx)
    assert(max(abs(best.genes(:)-polished.solutions(idx).genes(:)))<1e-10);
end
fprintf('test_post_repair_reselection passed.\n');
end
