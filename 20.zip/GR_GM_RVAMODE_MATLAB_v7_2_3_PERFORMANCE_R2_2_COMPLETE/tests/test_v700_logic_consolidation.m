function test_v700_logic_consolidation()
%TEST_V700_LOGIC_CONSOLIDATION Enforce one mission-feasibility pathway.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.multiUAVShiyanConfig();
assert(isfield(cfg,'implementationVersion') && strncmp(cfg.implementationVersion,'v7.',3));

assert(cfg.numObjectives==5);
assert(cfg.enableUnifiedMissionDeficit && cfg.enableUnifiedMissionRepair);
assert(cfg.enableMissionBandSelection && abs(cfg.missionBandMinFraction-0.25)<1e-12);
assert(cfg.missionRepairDiversifyBases && cfg.missionRepairDistinctTargetsFirst);
assert(cfg.unifiedMissionRepairOwnsMissionRecovery);
assert(~cfg.enableDEObservationArcJump);
assert(cfg.monitorEmergencyStrategyBlend==0);
assert(~cfg.enableFeasibilityFeedbackThreshold);
assert(~cfg.monitorComponentwiseThresholdUpdate);
assert(cfg.localSearchStartGeneration>=cfg.missionFormalStartGeneration);
assert(cfg.missionRepairMinTargetDeficitGain>=1e-3-eps);
assert(cfg.missionRepairGlobalNonRegressionTolerance<=1e-9);
assert(cfg.missionRepairTransitionPointsPerSide>=2);

% Formal thresholds are unchanged.
assert(abs(cfg.monitorMinTargetQuality-0.33)<1e-12);
assert(abs(cfg.monitorCriticalMinQuality-0.42)<1e-12);
assert(abs(cfg.monitorCriticalMinObservationLength-180)<1e-12);
assert(abs(cfg.monitorCriticalMinLOSRatio-0.45)<1e-12);
assert(abs(cfg.safeClearance-60)<1e-12);
assert(abs(cfg.realMaximumAGL-320)<1e-12);

% Removed legacy restoration implementations must not exist in the package.
legacy = {'initializeTargetMemory.m','updateTargetMemory.m', ...
    'restoreTargetMemoryElites.m','preserveMonitoringCoverage.m'};
for i=1:numel(legacy)
    assert(exist(fullfile(root,'src','+core',legacy{i}),'file')==0);
end

runText = fileread(fullfile(root,'src','+core','runGRAHMODE.m'));
assert(contains(runText,'core.unifiedMissionRepair'));
assert(~contains(runText,'restoreTargetMemoryElites'));
assert(~contains(runText,'preserveMonitoringCoverage'));
assert(~contains(runText,'updateTargetMemory'));
trialText = fileread(fullfile(root,'src','+operators','generateTrial.m'));
assert(~contains(trialText,'injectTargetObservationArc'));

% The three-stage synchronized schedule is mandatory.
th0 = evaluation.currentMonitoringThresholds(1,cfg);
thF = evaluation.currentMonitoringThresholds(cfg.missionFormalStartGeneration,cfg);
assert(th0.missionStage=="exploration" && abs(th0.missionDeficitEpsilon-1)<1e-12);
assert(thF.missionStage=="formal" && abs(thF.missionDeficitEpsilon)<1e-12);
fprintf('test_v700_logic_consolidation passed.\n');
end
