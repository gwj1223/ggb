function test_optimized_selection()
%TEST_OPTIMIZED_SELECTION Check reference-vector selection and returned IDs.
root = fileparts(fileparts(mfilename('fullpath')));
setupProject(root);
cfg = config.defaultConfig();
cfg.populationSize = 4;
cfg.maxGenerations = 10;
cfg.referenceVectorDivisions = 2;

template = struct('objectives',zeros(1,5),'cv',0,'feasible',true, ...
    'rank',inf,'crowding',0);
pop = repmat(template,8,1);
values = [ ...
    1.00 0.80 420 0.80 0.80; ...
    1.10 0.20 420 0.70 0.70; ...
    1.20 0.70 180 0.60 0.65; ...
    1.25 0.65 360 0.15 0.60; ...
    1.30 0.60 350 0.55 0.10; ...
    1.15 0.45 300 0.45 0.45; ...
    1.35 0.55 330 0.50 0.50; ...
    1.45 0.75 440 0.90 0.90];
for i = 1:numel(pop)
    pop(i).objectives = values(i,:);
end
[next,idx] = selection.environmentalSelection(pop,4,cfg,5);
assert(numel(next)==4);
assert(numel(idx)==4);
assert(numel(unique(idx))==4);
assert(all(idx>=1 & idx<=numel(pop)));
disp('test_optimized_selection passed.');
end
