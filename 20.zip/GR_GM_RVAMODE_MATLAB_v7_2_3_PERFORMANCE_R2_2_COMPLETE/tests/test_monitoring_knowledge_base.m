function test_monitoring_knowledge_base()
%TEST_MONITORING_KNOWLEDGE_BASE Static DEM/LOS knowledge contains no solution memory.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.multiUAVShiyanConfig();
[problem,cfg] = realdata.buildShiyanG1Problem(root,cfg);
kb = multiUAV.buildMonitoringKnowledgeBase(problem,cfg);
M = size(problem.monitorTargets,1);
assert(numel(kb.score)==M && numel(kb.bestRadiusScale)==M);
assert(numel(kb.bestSectorCenterRad)==M && numel(kb.bestSectorHalfWidthRad)==M);
assert(all(isfinite(kb.score)) && all(kb.score>=0 & kb.score<=1));
assert(all(isfinite(kb.bestRadiusScale)) && all(kb.bestRadiusScale>0));
assert(strcmp(kb.version,'v7.0.0-static-dem-los-knowledge'));
% Knowledge may contain observability geometry, but never an evolutionary carrier.
for forbidden = ["individual","individuals","genes","chromosome","missionIndividual"]
    assert(~isfield(kb,char(forbidden)));
end
fprintf('test_monitoring_knowledge_base passed.\n');
end
