function test_dense_segment_cache_equivalence()
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig();
cfg.safeClearance=20; cfg.maxAltitude=200;
cfg.enableLocalAGLConstraint=true; cfg.realMaximumAGL=100;
cfg.maxClimbAngleDeg=45; cfg.segmentRepairMargin=0;
cfg.aglConstraintSampleStep_m=10; cfg.aglConstraintMaxSamplesPerSegment=64;
cfg.missionRepairDenseAltitudeGridStep_m=2;
[xg,yg]=meshgrid(0:1:100,0:1:10);
terrain=zeros(size(xg)); terrain(:,51)=50;
problem.gridX=xg; problem.gridY=yg; problem.terrain=terrain;
problem.risk=zeros(size(terrain)); problem.obstacles=zeros(0,4);
xy=[0 5;50 5;100 5];
[z0,i0]=core.projectDenseTerrainReachableProfile(xy,55,55,75,problem,cfg);
cache=containers.Map('KeyType','char','ValueType','any');
[z1,i1]=core.projectDenseTerrainReachableProfile(xy,55,55,75,problem,cfg,cache);
[z2,i2]=core.projectDenseTerrainReachableProfile(xy,55,55,75,problem,cfg,cache);
assert(isequal(i0.success,i1.success) && isequal(i1.success,i2.success));
assert(max(abs(z0(:)-z1(:)))<=1e-10 && max(abs(z1(:)-z2(:)))<=1e-10);
assert(i1.terrainSampleCacheMisses==size(xy,1)-1);
assert(i2.terrainSampleCacheHits==size(xy,1)-1);
fprintf('test_dense_segment_cache_equivalence passed.\n');
end
