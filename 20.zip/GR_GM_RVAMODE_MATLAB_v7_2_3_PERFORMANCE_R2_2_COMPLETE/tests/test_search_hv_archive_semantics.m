function test_search_hv_archive_semantics()
%TEST_SEARCH_HV_ARCHIVE_SEMANTICS Search HV may include curated band leaders.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig();
samples=metrics.createHVSamples(cfg);
a=struct('objectives',[1.20 0.30 180 0.2 0.3],'cv',0.2);
assert(isnan(metrics.approxHypervolumeFixed(a,cfg,samples)), ...
    'Historical/formal HV must still reject CV-infeasible points by default.');
h=metrics.approxHypervolumeFixed(a,cfg,samples,false);
assert(isfinite(h) && h>0, ...
    'Search Archive HV must be computable for curated mission-band leaders.');

runText=fileread(fullfile(root,'src','+core','runGRAHMODE.m'));
assert(contains(runText,'archive,cfg,hvSamples,false'), ...
    'runGRAHMODE Search Archive HV must use the search-set semantics.');

fprintf('test_search_hv_archive_semantics passed.\n');
end
