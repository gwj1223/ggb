function test_a3_mission_progress_policy()
%TEST_A3_MISSION_PROGRESS_POLICY Behavioral contract for unified A3.
% The test intentionally avoids binding correctness to source whitespace,
% variable names, or one particular assignment statement.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.multiUAVShiyanConfig();
assert(cfg.missionRepairMinTargetDeficitGain>0);
assert(cfg.missionRepairGlobalNonRegressionTolerance>=0);

%% Selection and acceptance must share one target-deficit definition.
base = localFixture([repmat(0.80,1,6) 0.00 0.00 0.80 0.80]);
trial = localFixture([repmat(0.80,1,6) 0.03 0.00 0.80 0.80]);
baseInfo = evaluation.missionRepairTargetDeficits(base,cfg);
trialInfo = evaluation.missionRepairTargetDeficits(trial,cfg);
selected = evaluation.selectMonitoringRepairTarget(base.monitorStats,cfg);
assert(selected==7 || selected==8, ...
    'One of the tied severe ordinary Qmin deficits must be selected.');
assessment = evaluation.assessMissionRepairCandidate(trial,base,7,cfg);
assert(assessment.eligible);
assert(abs(assessment.baseTargetDeficit-baseInfo.total(7))<1e-12);
assert(abs(assessment.trialTargetDeficit-trialInfo.total(7))<1e-12);
assert(abs(assessment.targetGain- ...
    (baseInfo.total(7)-trialInfo.total(7)))<1e-12);

%% No real target progress must be rejected.
noOp = evaluation.assessMissionRepairCandidate(base,base,7,cfg);
assert(~noOp.eligible && strcmp(noOp.reason,'target_no_gain'));

%% Static regression must be rejected before mission acceptance.
staticBad = trial;
staticBad.staticCV = 0.1;
staticCheck = evaluation.assessMissionRepairCandidate(staticBad,base,7,cfg);
assert(~staticCheck.eligible && strcmp(staticCheck.reason,'static'));

%% Protected already-formal targets may not be broken.
protectCfg = cfg;
protectCfg.missionRepairGlobalNonRegressionTolerance = 1.0;
protectedTrial = trial;
protectedTrial.monitorStats.truePerTarget(1) = cfg.monitorMinTargetQuality-0.01;
protectedTrial.monitorPerTarget = protectedTrial.monitorStats.truePerTarget;
protectedCheck = evaluation.assessMissionRepairCandidate( ...
    protectedTrial,base,7,protectCfg);
assert(~protectedCheck.eligible && strcmp(protectedCheck.reason,'protected_q'));

%% Canonical A3 write-back replaces only requested bases and preserves size.
smallCfg = config.fastConfig();
smallCfg.populationSize = 4;
smallCfg.numWaypoints = 5;
problem = data.createDemoProblem(smallCfg);
pop = core.initializePopulation(problem,smallCfg);
pop = evaluation.evaluatePopulation(pop,problem,smallCfg,1);
before = pop;
replacementIdx = [1;2];
replacements = before([3;4]);
after = core.applyUnifiedMissionRepairReplacements( ...
    before,replacementIdx,replacements);
assert(numel(after)==numel(before));
assert(isequaln(after(1).path,before(3).path));
assert(isequaln(after(2).path,before(4).path));
assert(isequaln(after(3).path,before(3).path));
assert(isequaln(after(4).path,before(4).path));
assert(isfield(after,'rank') && isfield(after,'crowding'));

%% Lightweight architecture guard: canonical interfaces, not implementation text.
repairText = fileread(fullfile(root,'src','+core','unifiedMissionRepair.m'));
selectorText = fileread(fullfile(root,'src','+evaluation', ...
    'selectMonitoringRepairTarget.m'));
assessorText = fileread(fullfile(root,'src','+evaluation', ...
    'assessMissionRepairCandidate.m'));
assert(contains(repairText,'core.applyUnifiedMissionRepairReplacements'));
assert(~contains(repairText,'selection.environmentalSelection([pop'));
assert(contains(selectorText,'evaluation.missionRepairTargetDeficits'));
assert(contains(assessorText,'evaluation.missionRepairTargetDeficits'));
assert(contains(assessorText,'evaluation.assessMissionProtection'));
assert(~isempty(which('evaluation.assessMissionProtection')));

fprintf('test_a3_mission_progress_policy passed.\n');
end

function ind = localFixture(q)
q = q(:);
M = numel(q);
ind.staticCV = 0;
ind.cv = 0;
ind.feasible = true;
ind.monitorPerTarget = q;
ind.monitorStats.truePerTarget = q;
ind.monitorStats.searchPerTarget = q;
ind.monitorStats.criticalQuality = mean(q(1:6));
ind.monitorStats.trueCriticalQuality = mean(q(1:6));
ind.monitorStats.observationLength = 300*ones(M,1);
ind.monitorStats.losRatio = 0.90*ones(M,1);
ind.monitorStats.minimumCriticalObservationLength = 300;
ind.monitorStats.minimumCriticalLOSRatio = 0.90;
end
