function test_structured_a3_semantic_repair()
cfg=config.defaultConfig();
cfg.enableStructuredMonitoringEncoding=true;
cfg.numWaypoints=20;
cfg.maxClimbAngleDeg=89;
cfg.maxTurnAngleDeg=179;
cfg.segmentRepairMargin=0;
cfg.enableLocalAGLConstraint=false;
problem=data.createDemoProblem(cfg);
problem.structuredMonitoringTargetOrder=core.structuredMonitoringTargetOrder(problem,cfg);
layout=core.structuredMonitoringLayout(problem,cfg);
base=struct();
base.structuredGenes=zeros(1,layout.dimension);
[base.genes,base.encodingInfo]=core.decodeStructuredMonitoringGenes( ...
    base.structuredGenes,problem,cfg);
[candidate,pre]=core.injectStructuredMonitoringParameters(base,1,problem,cfg,1);
dims=layout.targetDims(1,:);
outside=setdiff(1:layout.dimension,dims);
assert(all(candidate.structuredGenes(outside)==base.structuredGenes(outside)));
assert(any(abs(candidate.structuredGenes(dims)-base.structuredGenes(dims))>1e-12));
assert(candidate.structuredGenes(dims(3))>base.structuredGenes(dims(3)));
assert(numel(candidate.genes)==3*cfg.numWaypoints);
assert(isstruct(pre) && isfield(pre,'success') && isfield(pre,'reason'));
fprintf('test_structured_a3_semantic_repair passed.\n');
end
