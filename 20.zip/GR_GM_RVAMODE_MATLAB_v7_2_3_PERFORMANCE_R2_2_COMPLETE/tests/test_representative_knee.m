function test_representative_knee()
% Representative selection includes internal and common-space knee points.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig();
base=localBaseIndividual(cfg);
archive=repmat(base,7,1);
F=[1.00 .80 .90 .60 .90;1.08 .60 .82 .55 .75; ...
   1.15 .48 .76 .48 .58;1.24 .40 .72 .42 .44; ...
   1.34 .34 .70 .38 .35;1.48 .30 .69 .36 .30; ...
   1.65 .28 .68 .35 .28];
for i=1:numel(archive)
    archive(i).objectives=F(i,:);
    q=max(0.55,0.92-0.04*i);
    archive(i).monitorPerTarget=[q;0.85;0.88;q];
    archive(i).monitorStats.truePerTarget=archive(i).monitorPerTarget;
    archive(i).monitorStats.minimumQuality=q;
end
[knee,idx,score]=selection.selectKneeSolution(archive,cfg); %#ok<ASGLU>
assert(isscalar(knee) && isscalar(idx));
assert(all(isfinite(score)));
reps=selection.selectRepresentativeSolutions(archive,cfg);
assert(numel(reps.solutions)==8);
assert(any(strcmp(reps.labels,'KneePoint')));
assert(any(strcmp(reps.labels,'MinimumPhysicalCost')));
assert(any(strcmp(reps.labels,'CommonKneePoint')));
assert(any(strcmp(reps.labels,'RiskBalanced')));
fprintf('test_representative_knee passed.\n');
end

function ind=localBaseIndividual(cfg)
ind.cv=0;
ind.staticCV=0;
ind.feasible=true;
ind.objectives=ones(1,5);
ind.monitorPerTarget=[0.75;0.85;0.88;0.75];
ind.monitorStats.truePerTarget=ind.monitorPerTarget;
ind.monitorStats.minimumQuality=0.75;
ind.monitorStats.criticalQuality=0.865;
ind.monitorStats.trueCriticalQuality=0.865;
ind.monitorStats.observationLength=12*ones(4,1);
ind.monitorStats.losRatio=0.8*ones(4,1);
ind.monitorStats.minimumCriticalObservationLength=12;
ind.monitorStats.minimumCriticalLOSRatio=0.8;
ind.monitorStats.dispersionPenalty=0.05;
ind.violation=struct('collision',0,'clearance',0,'climb',0, ...
    'turn',0,'energy',0);
end
