function test_tail_risk()
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
r=[0.1 0.2 0.3 0.9]'; w=ones(4,1);
t=evaluation.weightedTailRisk(r,w,0.75);
assert(abs(t-0.9)<1e-12);
t2=evaluation.weightedTailRisk(r,w,0.50);
assert(t2>=mean(r)-1e-12 && t2<=max(r)+1e-12);
fprintf('test_tail_risk passed.\n');
end
