function test_utm49n_projection()
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root); %#ok<NASGU>
[E,N]=realdata.lonLatToUTM49N(110.75,32.445);
% Reference generated independently with EPSG:32649 / PROJ.
assert(abs(E-476488.6)<40);
assert(abs(N-3589800)<80);
fprintf('test_utm49n_projection passed.\n');
end
