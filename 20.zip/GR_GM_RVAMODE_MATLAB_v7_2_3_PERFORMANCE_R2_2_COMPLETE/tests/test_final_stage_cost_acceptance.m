function test_final_stage_cost_acceptance
cfg = config.defaultConfig();
best = localIndividual([1.35 0.32 187 0.12],0.75,0.82,10.0,0.60,0.10,cfg);
cand = localIndividual([1.30 0.31 179 0.11],0.70,0.80,9.5,0.55,0.12,cfg);
[accepted,diag] = operators.isFinalStageCostImprovement(cand,best,cfg);
assert(accepted);
assert(diag.finalFeasible && diag.monitoringMarginSatisfied);
assert(diag.smoothnessGuard && diag.riskGuard && diag.energyGuard);

badQuality = cand;
badQuality.monitorStats.minimumQuality = 0.50;
badQuality.monitorStats.truePerTarget(:) = 0.50;
badQuality.monitorPerTarget(:) = 0.50;
assert(~operators.isFinalStageCostImprovement(badQuality,best,cfg));

badSmooth = cand;
badSmooth.objectives(4) = 0.20;
assert(~operators.isFinalStageCostImprovement(badSmooth,best,cfg));
fprintf('test_final_stage_cost_acceptance passed.\n');
end

function ind = localIndividual(obj,minQ,criticalQ,obs,los,dispersion,cfg)
ind.objectives = [obj 0.2];
ind.feasible = true;
ind.staticCV = 0;
ind.monitorPerTarget = [minQ;criticalQ;criticalQ;minQ];
ind.monitorStats.truePerTarget = ind.monitorPerTarget;
ind.monitorStats.minimumQuality = minQ;
ind.monitorStats.criticalQuality = criticalQ;
ind.monitorStats.trueCriticalQuality = criticalQ;
ind.monitorStats.dispersionPenalty = dispersion;
ind.monitorStats.observationLength = obs*ones(4,1);
ind.monitorStats.losRatio = los*ones(4,1);
ind.monitorStats.minimumCriticalObservationLength = obs;
ind.monitorStats.minimumCriticalLOSRatio = los;
ind.cv = 0;
ind.violation = struct('collision',0,'clearance',0,'climb',0, ...
    'turn',0,'energy',0);
end
