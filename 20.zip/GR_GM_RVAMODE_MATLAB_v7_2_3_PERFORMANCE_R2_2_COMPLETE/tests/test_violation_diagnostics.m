function test_violation_diagnostics()
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig(); cfg.populationSize=6;
problem=data.createDemoProblem(cfg);
pop=core.initializePopulation(problem,cfg);
pop=evaluation.evaluatePopulation(pop,problem,cfg,1);
v=diagnostics.summarizeViolations(pop,cfg.constraintTolerance);
required={'totalMin','totalMedian','monitorMinimumMin', ...
    'monitorMinimumCount','monitorObservationLengthCount', ...
    'monitorLOSRatioCount'};
for k=1:numel(required), assert(isfield(v,required{k})); end
assert(isfinite(v.totalMin));
disp('test_violation_diagnostics passed.');
end
