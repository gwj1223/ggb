function test_unified_mission_cumulative_gain()
%TEST_UNIFIED_MISSION_CUMULATIVE_GAIN A3 retains tied-D target progress.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.multiUAVShiyanConfig();

% Critical targets 1:6 are already healthy. Ordinary targets 7 and 8 are
% both severe Qmin bottlenecks. Improving target 7 cannot remove the global
% worst-target tie because target 8 remains at zero, but it is valid
% cumulative mission progress and must be eligible for A3 retention.
base = localFixture([repmat(0.80,1,6) 0.00 0.00 0.80 0.80]);
trial = localFixture([repmat(0.80,1,6) 0.03 0.00 0.80 0.80]);
assessment = evaluation.assessMissionRepairCandidate(trial,base,7,cfg);
assert(assessment.eligible, ...
    'Tied-D one-target progress must be eligible under the v7.0.2+ A3 contract.');
assert(assessment.targetGain>=cfg.missionRepairMinTargetDeficitGain);
assert(assessment.trialTotalDeficit<=assessment.baseTotalDeficit+ ...
    cfg.missionRepairGlobalNonRegressionTolerance+eps);

% A no-op edit is not mission progress.
noOp = evaluation.assessMissionRepairCandidate(base,base,7,cfg);
assert(~noOp.eligible && strcmp(noOp.reason,'target_no_gain'));

% A repair that breaks static feasibility is rejected before mission logic.
staticBad = trial;
staticBad.staticCV = 0.1;
staticCheck = evaluation.assessMissionRepairCandidate(staticBad,base,7,cfg);
assert(~staticCheck.eligible && strcmp(staticCheck.reason,'static'));

fprintf(['test_unified_mission_cumulative_gain passed: targetGain=%.6g, ' ...
    'D=%.6g->%.6g.\n'],assessment.targetGain, ...
    assessment.baseTotalDeficit,assessment.trialTotalDeficit);
end

function ind = localFixture(q)
q = q(:);
M = numel(q);
ind.staticCV = 0;
ind.cv = 0;
ind.feasible = true;
ind.monitorPerTarget = q;
ind.monitorStats.truePerTarget = q;
ind.monitorStats.searchPerTarget = q;
ind.monitorStats.criticalQuality = mean(q(1:6));
ind.monitorStats.trueCriticalQuality = mean(q(1:6));
ind.monitorStats.observationLength = 300*ones(M,1);
ind.monitorStats.losRatio = 0.90*ones(M,1);
ind.monitorStats.minimumCriticalObservationLength = 300;
ind.monitorStats.minimumCriticalLOSRatio = 0.90;
end
