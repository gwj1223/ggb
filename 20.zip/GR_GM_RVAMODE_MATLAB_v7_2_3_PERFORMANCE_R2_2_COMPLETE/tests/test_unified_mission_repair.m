function test_unified_mission_repair()
%TEST_UNIFIED_MISSION_REPAIR Bounded A3 repair with no historical restore.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.defaultConfig();
cfg.populationSize = 8;
cfg.numWaypoints = 10;
cfg.maxGenerations = 20;
cfg.enableUnifiedMissionDeficit = true;
cfg.enableUnifiedMissionRepair = true;
cfg.missionRepairStartGeneration = 1;
cfg.missionRepairBaseCount = 2;
cfg.missionRepairVariants = 2;
cfg.missionRepairMaxEvaluationsPerEvent = 4;
cfg.missionRepairStopWhenFormalCarrierExists = false;
cfg.runtimeMissionDeficitEpsilon = 0.5;
cfg.runtimeMissionStage = 'formation';
problem = data.createDemoProblem(cfg);
pop = core.initializePopulation(problem,cfg);
pop = evaluation.evaluatePopulation(pop,problem,cfg,5);
[repaired,stats] = core.unifiedMissionRepair(pop,problem,cfg,5);
assert(numel(repaired)==numel(pop));
assert(stats.evaluations<=cfg.missionRepairMaxEvaluationsPerEvent);
assert(stats.accepted<=stats.attemptedBases);
assert(stats.accepted<=stats.eligibleTrials);
classified = stats.eligibleTrials+stats.rejectStatic+stats.rejectInvalid+ ...
    stats.rejectGlobalRegression+stats.rejectProtection+stats.rejectTargetNoGain;
assert(classified==stats.evaluations);
assert(stats.staticCollision<=stats.rejectStatic);
assert(stats.staticClearance<=stats.rejectStatic);
assert(stats.staticClimb<=stats.rejectStatic);
assert(stats.staticTurn<=stats.rejectStatic);
assert(stats.staticEnergy<=stats.rejectStatic);
assert(stats.staticLowerAGL<=stats.rejectStatic);
assert(stats.staticUpperAGL<=stats.rejectStatic);
assert(~isfield(stats,'restorations'));
% Any selected static-feasible member must still use the unified CV tiering.
for i=1:numel(repaired)
    if repaired(i).staticCV<=cfg.constraintTolerance
        assert(repaired(i).cv<=1+1e-12);
    end
end
fprintf('test_unified_mission_repair passed.\n');
end
