function test_scale_free_deb()
%TEST_SCALE_FREE_DEB Ensure energy units do not dominate a tie-break.
template = struct('objectives',zeros(1,5),'cv',0,'feasible',true);
a = template;
b = template;
a.objectives = [1.00 0.20 300 0.20 0.20];
b.objectives = [1.10 0.30 250 0.30 0.30];
% A is better in four objectives and moderately worse in energy. A raw
% objective sum would incorrectly prefer B because energy is measured in a
% much larger numerical unit.
assert(selection.isBetterDeb(a,b));
assert(~selection.isBetterDeb(b,a));
disp('test_scale_free_deb passed.');
end
