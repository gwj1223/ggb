function test_multi_uav_separation()
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.multiUAVShiyanConfig();
cfg.multiUAVCount=2;
cfg.multiUAVCruiseSpeed=10;
cfg.multiUAVSafeSeparation=20;
cfg.multiUAVNearSeparation=30;
cfg.multiUAVSeparationTimeStep=0.5;
cfg.multiUAVMinimumLaunchSpacing=5;
cfg.multiUAVLaunchDelayStep=5;
cfg.multiUAVMaxLaunchDelay=40;
paths={ [0 0 100;100 0 100], [0 0 100;100 0 100] };
sep0=multiUAV.evaluateFleetSeparation(paths,[0;0],cfg);
assert(~sep0.collisionFree);
[d,sep]=multiUAV.scheduleLaunchDelays(paths,cfg);
assert(d(2)>0);
assert(sep.collisionFree);
assert(sep.minimumSeparation>=cfg.multiUAVSafeSeparation-1e-9);
fprintf('test_multi_uav_separation passed.\n');
end
