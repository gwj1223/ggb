function test_final_stage_neighbourhoods
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.fastConfig();
cfg.populationSize = 4;
cfg.numWaypoints = 8;
problem = data.createDemoProblem(cfg);
pop = core.initializePopulation(problem,cfg);
pop = evaluation.evaluatePopulation(pop,problem,cfg,1);
ind = pop(1);
functions = {@operators.finalStageSmoothWindow, ...
    @operators.finalStageShortcut,@operators.finalStageArcShrink, ...
    @operators.finalStageArcRotation,@operators.finalStageAltitudeSmoothing};
for k = 1:numel(functions)
    genes = functions{k}(ind,problem,cfg);
    assert(isrow(genes));
    assert(numel(genes)==numel(ind.genes));
    assert(all(isfinite(genes)));
end
state = operators.initializeFinalStageOperatorState(cfg);
for operatorId = 1:5
    forced = state;
    forced.probabilities = zeros(1,5);
    forced.probabilities(operatorId) = 1;
    [cand,id] = operators.finalStageCostRefinement( ...
        ind,problem,cfg,1,forced);
    assert(id==operatorId);
    assert(numel(cand.genes)==numel(ind.genes));
    assert(all(isfinite(cand.objectives)));
end
fprintf('test_final_stage_neighbourhoods passed.\n');
end
