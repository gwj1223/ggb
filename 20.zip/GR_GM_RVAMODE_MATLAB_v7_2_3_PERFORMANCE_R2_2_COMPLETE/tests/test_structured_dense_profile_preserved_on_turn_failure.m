function test_structured_dense_profile_preserved_on_turn_failure()
cfg=config.defaultConfig();
cfg.enableStructuredMonitoringEncoding=true;
cfg.numWaypoints=20;
cfg.maxClimbAngleDeg=89;
cfg.maxTurnAngleDeg=0.01; % force a turn-only precheck failure
cfg.segmentRepairMargin=0;
cfg.enableLocalAGLConstraint=false;
cfg.structuredTransitMinimumBoundaryConnectors=1;
cfg.structuredTransitMaximumBoundaryConnectors=2;
cfg.structuredTransitMaximumConnectorsPerLeg=2;
cfg.structuredTransitTurnWeight=3.0;
cfg.structuredTransitMandatoryTurnFraction=0.90;
cfg.structuredTransitSevereTurnExtraConnectors=0;
cfg.structuredUseTangentAwareTransit=true;
cfg.structuredEncodingPrecheckTurn=true;
problem=data.createDemoProblem(cfg);
problem.structuredMonitoringTargetOrder=core.structuredMonitoringTargetOrder(problem,cfg);
layout=core.structuredMonitoringLayout(problem,cfg);
[genes,info]=core.decodeStructuredMonitoringGenes(zeros(1,layout.dimension),problem,cfg);
assert(~info.success && strcmp(info.reason,'turn'));
assert(info.denseSuccess && ~info.turnSuccess);
assert(numel(genes)==3*cfg.numWaypoints && all(isfinite(genes)));
ind=struct('genes',genes);
ind=evaluation.evaluateIndividual(ind,problem,cfg,1);
tol=max(cfg.constraintTolerance,1e-8);
assert(ind.violation.clearance<=tol, ...
    'Dense-feasible Z must not be replaced after a turn-only failure.');
assert(ind.violation.climb<=tol, ...
    'Dense-feasible Z must preserve the climb contract after turn failure.');
fprintf('test_structured_dense_profile_preserved_on_turn_failure passed.\n');
end
