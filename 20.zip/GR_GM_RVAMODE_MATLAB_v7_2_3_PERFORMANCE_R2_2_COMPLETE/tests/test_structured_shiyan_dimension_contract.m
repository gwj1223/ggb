function test_structured_shiyan_dimension_contract()
cfg=config.multiUAVShiyanConfig();
assert(cfg.enableStructuredMonitoringEncoding);
assert(cfg.structuredTransitMinimumBoundaryConnectors==1);
assert(cfg.structuredTransitMaximumBoundaryConnectors==2);
assert(cfg.structuredTransitMaximumConnectorsPerLeg==2);
assert(cfg.structuredUseTangentAwareTransit);
assert(cfg.structuredDisableLegacyXYZLocalSearch);
subCfg=cfg;
subCfg.numWaypoints=42;
subCfg.criticalTargetIndices=[1 2];
problem=struct();
problem.monitorTargets=zeros(10,5);
layout=core.structuredMonitoringLayout(problem,subCfg);
assert(layout.dimension==51);
assert(4*10+11==layout.dimension);
assert(subCfg.monitorMinTargetQuality==0.33);
assert(subCfg.monitorCriticalMinQuality==0.42);
assert(subCfg.monitorCriticalMinObservationLength==180);
assert(subCfg.monitorCriticalMinLOSRatio==0.45);
assert(subCfg.safeClearance==60);
assert(subCfg.realMaximumAGL==320);
assert(subCfg.maxClimbAngleDeg==22);
assert(subCfg.maxTurnAngleDeg==95);
fprintf('test_structured_shiyan_dimension_contract passed.\n');
end
