function test_critical_observation_repair_target()
%TEST_CRITICAL_OBSERVATION_REPAIR_TARGET Geometry deficit can outrank Qmin.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.multiUAVShiyanConfig();
cfg.criticalTargetIndices = 2;

stats.truePerTarget = [0.24 0.60 0.58];
stats.searchPerTarget = stats.truePerTarget;
stats.observationLength = [300 85 300];
stats.losRatio = [0.90 0.30 0.90];
idx = evaluation.selectMonitoringRepairTarget(stats,cfg);
assert(idx==2, ['Critical observation/LOS deficit should be selected even ' ...
    'when an ordinary target has lower quality.']);

stats.observationLength(2) = 230;
stats.losRatio(2) = 0.70;
idx2 = evaluation.selectMonitoringRepairTarget(stats,cfg);
assert(idx2==1, 'After Critical geometry is healthy, the low-Q target should lead.');
fprintf('test_critical_observation_repair_target passed.\n');
end
