function test_v723_performance_config_contract()
cfg=config.multiUAVShiyanConfig();
assert(cfg.populationSize==96);
assert(cfg.maxGenerations==220);
assert(cfg.numObjectives==5);
assert(cfg.monitorMinTargetQuality==0.33);
assert(cfg.monitorCriticalMinQuality==0.42);
assert(cfg.monitorCriticalMinObservationLength==180);
assert(cfg.monitorCriticalMinLOSRatio==0.45);
assert(cfg.realMaximumAGL==320);
assert(cfg.maxClimbAngleDeg==22);
assert(cfg.maxTurnAngleDeg==95);
assert(cfg.enableStructuredSegmentTerrainCache);
assert(cfg.enableTerrainInterpolatorCache);
assert(cfg.enableStructuredPerformanceProfiling);
assert(cfg.enableDenseProjectionVectorizedDP);
assert(contains(cfg.implementationVersion,'performance-r2.2'));
fprintf('test_v723_performance_config_contract passed.\n');
end
