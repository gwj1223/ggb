function test_multi_uav_assignment()
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);

% createDemoProblem requires a configuration input. Reuse the multi-UAV
% configuration here so the synthetic assignment test exercises the same
% validation fields as the Shiyan-G1 multi-UAV workflow.
cfg=config.multiUAVShiyanConfig();
cfg.multiUAVCount=3;
problem=data.createDemoProblem(cfg);

% Build a deterministic 12-target synthetic allocation-only problem.
xy=[10 10;20 15;15 30;30 25;70 15;80 20;75 35;65 30; ...
    35 70;45 80;60 75;80 85];
M=size(xy,1);
problem.monitorTargets=[xy,ones(M,1),30*ones(M,1),80*ones(M,1)];
problem.monitorTargetMeta=repmat(struct('risk',0.3,'slopeDeg',20),M,1);
cfg.criticalTargetIndices=1:6;

a=multiUAV.allocateTargetsRiskAware(problem,cfg);
assert(all(a.targetToUAV>=1 & a.targetToUAV<=3));
assert(sum(a.targetCount)==M);
assert(max(a.targetCount)-min(a.targetCount)<=1);
assert(sum(a.criticalCount)==6);
assert(max(a.criticalCount)-min(a.criticalCount)<=1);
assert(numel(unique(vertcat(a.groups{:})))==M);
% Check allocation semantics rather than an exact historical method label.
assert(contains(char(a.method),'knowledge_risk_observability_route_balanced_exclusive'));
assert(isfield(a,'monitoringKnowledge') && isstruct(a.monitoringKnowledge));
assert(strcmp(a.monitoringKnowledge.version,'v7.0.0-static-dem-los-knowledge'));
assert(numel(a.targetObservabilityScore)==M);
assert(all(isfinite(a.targetObservabilityScore)));
assert(numel(a.observabilityLoad)==cfg.multiUAVCount);
assert(numel(a.routeProxy_m)==cfg.multiUAVCount);
assert(all(isfinite(a.routeProxy_m) & a.routeProxy_m>0));
fprintf('test_multi_uav_assignment passed.\n');
end
