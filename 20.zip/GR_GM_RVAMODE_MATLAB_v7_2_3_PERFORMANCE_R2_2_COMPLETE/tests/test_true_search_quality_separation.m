function test_true_search_quality_separation()
% Search quality may be smooth and positive while physical quality remains 0.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.fastConfig(); problem=data.createDemoProblem(cfg);
if isfield(problem,'monitorTargetTerrain')
    problem=rmfield(problem,'monitorTargetTerrain');
end
problem.monitorTargets(1,1:2)=[95 5];
problem.monitorTargets(1,4:5)=[10 15];
z1=data.terrainHeight(problem,5,95)+20;
z2=data.terrainHeight(problem,15,95)+20;
path=[5 95 z1;15 95 z2];
[qTrue,perTrue,stats]=evaluation.monitoringQuality(path,problem,cfg);
assert(all(stats.searchPerTarget>=perTrue-1e-12));
assert(stats.searchAverageQuality>=qTrue-1e-12);
assert(any(stats.searchPerTarget>perTrue+1e-8));
assert(all(stats.truePerTarget==perTrue));
fprintf('test_true_search_quality_separation passed.\n');
end
