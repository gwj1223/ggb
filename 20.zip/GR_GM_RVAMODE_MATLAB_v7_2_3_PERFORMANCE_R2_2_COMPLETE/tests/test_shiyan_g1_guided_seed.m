function test_shiyan_g1_guided_seed()
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.shiyanG1Config();
[problem,cfg]=realdata.buildShiyanG1Problem(root,cfg);
ind.genes=core.initializeGenes(problem,cfg,3,1);
ind=repair.repairPath(ind,problem,cfg);
ind=evaluation.evaluateIndividual(ind,problem,cfg,1);
assert(all(isfinite(ind.objectives)));
assert(ind.violation.collision==0);
assert(all(ind.monitorStats.annulusGap<500));
assert(ind.pathMetrics.rawLength>5000);
fprintf('test_shiyan_g1_guided_seed passed.\n');
end
