function test_a3_diverse_base_selection()
%TEST_A3_DIVERSE_BASE_SELECTION A3 should not spend all bases on one bottleneck.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig();
cfg.criticalTargetIndices=[];
cfg.missionRepairBaseCount=4;
cfg.missionRepairDiversifyBases=true;
cfg.missionRepairDistinctTargetsFirst=true;
cfg.missionRepairTargetWeights=[1.00 0.35 1.30 0.80];

M=10;
T=struct('monitorStats',struct(),'objectives',zeros(1,5));
pop=repmat(T,6,1);
worst=[5 5 8 4 9 10];
for i=1:6
    q=0.80*ones(M,1);
    q(worst(i))=0.01;
    s.truePerTarget=q;
    s.searchPerTarget=q;
    s.criticalQuality=0.80;
    s.trueCriticalQuality=0.80;
    s.observationLength=300*ones(M,1);
    s.losRatio=0.90*ones(M,1);
    pop(i).monitorStats=s;
    pop(i).objectives=[i 7-i i 7-i 0.5*i];
end
candidateIdx=(1:6)';
D=[0.10 0.11 0.12 0.13 0.14 0.15]';
[selected,targets]=core.selectMissionRepairBases(pop,candidateIdx,D,cfg);
assert(numel(selected)==4);
assert(selected(1)==1,'The global best-D base must remain first.');
assert(numel(unique(targets(isfinite(targets))))>=3, ...
    'Distinct bottleneck targets must be preferred before duplicate targets.');
fprintf('test_a3_diverse_base_selection passed.\n');
end
