function test_final_stage_monitoring_saturation
cfg = config.defaultConfig();
stats.searchAverageQuality = 0.90;
stats.searchMinimumQuality = 0.82;
stats.searchCriticalQuality = 0.88;
stats.searchDispersionPenalty = 0.08;
stats.worstCoverageDeficit = 0;
stats.worstObservationDeficit = 0;

cfg.runtimeMonitoringFinalReached = false;
[preLoss,pre] = evaluation.monitoringObjectiveLoss(stats,cfg);
cfg.runtimeMonitoringFinalReached = true;
[finalLoss,final] = evaluation.monitoringObjectiveLoss(stats,cfg);
assert(final.saturationActive);
assert(final.averageQuality == cfg.finalStageAverageQualityCap);
assert(final.minimumQuality == cfg.finalStageMinimumQualityCap);
assert(final.criticalQuality == cfg.finalStageCriticalQualityCap);
assert(abs(pre.averageQuality-stats.searchAverageQuality)<1e-12);

stats.searchAverageQuality = 0.99;
stats.searchMinimumQuality = 0.99;
stats.searchCriticalQuality = 0.99;
[moreLoss,~] = evaluation.monitoringObjectiveLoss(stats,cfg);
assert(abs(moreLoss-finalLoss)<1e-12);
assert(preLoss < 1);
fprintf('test_final_stage_monitoring_saturation passed.\n');
end
