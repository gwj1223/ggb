function test_infeasible_monitoring_tiebreak()
% Equal-CV infeasible solutions should prefer better weakest-target quality.
a.feasible=false; b.feasible=false;
a.cv=0.03; b.cv=0.03;
a.objectives=[1 1 1 1 0.5]; b.objectives=[1 1 1 1 0.6];
a.monitorStats.minimumQuality=0.10;
b.monitorStats.minimumQuality=0.02;
a.monitorStats.criticalQuality=0.5;
b.monitorStats.criticalQuality=0.5;
a.monitorStats.minimumCriticalObservationLength=5;
b.monitorStats.minimumCriticalObservationLength=5;
a.monitorStats.minimumCriticalLOSRatio=0.5;
b.monitorStats.minimumCriticalLOSRatio=0.5;
assert(selection.isBetterDeb(a,b));
assert(~selection.isBetterDeb(b,a));
fprintf('test_infeasible_monitoring_tiebreak passed.\n');
end
