function test_population_schema_compatibility()
% New diagnostic fields must not make population assignment fail.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.fastConfig();
cfg.populationSize=6;
cfg.numWaypoints=5;
problem=data.createDemoProblem(cfg);

pop=core.initializePopulation(problem,cfg);
assert(isfield(pop,'searchMonitorQuality'));
assert(isfield(pop,'searchMonitorPerTarget'));
pop=evaluation.evaluatePopulation(pop,problem,cfg,1);
assert(all(arrayfun(@(x)numel(x.objectives)==5,pop)));
assert(all(arrayfun(@(x)isfield(x.monitorStats,'searchPerTarget'),pop)));

% Simulate a population produced by the old v6.2 template.  The evaluator
% must remain compatible instead of using dissimilar-structure assignment.
legacy=rmfield(pop,{'searchMonitorQuality','searchMonitorPerTarget'});
legacy=evaluation.evaluatePopulation(legacy,problem,cfg,1);
assert(isfield(legacy,'searchMonitorQuality'));
assert(isfield(legacy,'searchMonitorPerTarget'));
assert(all(isfinite([legacy.searchMonitorQuality])));
fprintf('test_population_schema_compatibility passed.\n');
end
