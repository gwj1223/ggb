function test_a3_dense_3d_contract()
%TEST_A3_DENSE_3D_CONTRACT v7.0.5 active-path source/config guard.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.multiUAVShiyanConfig();
assert(isfield(cfg,'implementationVersion') && strncmp(cfg.implementationVersion,'v7.',3));

assert(cfg.missionRepairUseDenseTerrainReachability);
assert(cfg.missionRepairGeometryPoolSize>cfg.missionRepairVariants);
assert(cfg.missionRepairMaxBlockPoints>=9);
assert(numel(cfg.missionRepairRadiusFactors)>=3);
assert(cfg.missionRepairMaxEvaluationsPerEvent==12);

arcText=fileread(fullfile(root,'src','+core','injectTargetObservationArc.m'));
repairText=fileread(fullfile(root,'src','+core','unifiedMissionRepair.m'));
assert(contains(arcText,'projectDenseTerrainReachableProfile'));
assert(contains(arcText,'maximumBlock'));
assert(~contains(arcText,'Safe fallback'));
assert(contains(repairText,'missionRepairGeometryPoolSize'));
assert(contains(repairText,'precheckPassed'));
assert(contains(repairText,'screenedTrials'));
assert(contains(repairText,'missionRepairMaxEvaluationsPerEvent'));
fprintf('test_a3_dense_3d_contract passed.\n');
end
