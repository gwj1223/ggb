function test_monitoring_floor_and_guided_init()
% Search quality must avoid exact-zero plateaus without changing true quality.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.fastConfig();
problem = data.createDemoProblem(cfg);
genes = core.initializeGenes(problem,cfg,3);
ind.genes = genes;
ind = repair.repairPath(ind,problem,cfg);
ind = evaluation.evaluateIndividual(ind,problem,cfg,1);
assert(all(ind.searchMonitorPerTarget>0));
assert(ind.monitorStats.searchMinimumQuality>0);
assert(all(ind.searchMonitorPerTarget>=ind.monitorPerTarget-1e-12));
assert(any(ind.monitorStats.observationLength>0));
fprintf('test_monitoring_floor_and_guided_init passed.\n');
end
