function test_observability_guided_arc_geometry()
%TEST_OBSERVABILITY_GUIDED_ARC_GEOMETRY A1/A3 geometry uses DEM/LOS hints.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.multiUAVShiyanConfig();
[problem,cfg] = realdata.buildShiyanG1Problem(root,cfg);
obs = multiUAV.estimateTargetObservability(problem,cfg);
problem.monitorTargetBestRadiusScale = obs.bestRadiusScale;
problem.monitorTargetBestSectorCenterRad = obs.bestSectorCenterRad;
problem.monitorTargetBestSectorHalfWidthRad = obs.bestSectorHalfWidthRad;

m = 2; % R02 is Critical and was the hardest Critical target in v6.5.9.
geom = core.observationArcGeometry(m,problem,cfg,[1 0],1,46,1);
expectedR = problem.monitorTargets(m,4)*obs.bestRadiusScale(m);
assert(abs(geom.radius-expectedR)<=1e-9*max(expectedR,1));
assert(geom.usedObservabilityHint);
assert(geom.isCritical);
sector = [cos(obs.bestSectorCenterRad(m)) sin(obs.bestSectorCenterRad(m))];
assert(dot(geom.direction,sector)>0.70, ...
    'Critical geometry should remain strongly aligned with the visible sector.');

geom2 = core.observationArcGeometry(m,problem,cfg,[1 0],2,46,1);
assert(all(isfinite(geom2.direction)) && isfinite(geom2.radius));
assert(geom2.radius==geom.radius);
fprintf('test_observability_guided_arc_geometry passed.\n');
end
