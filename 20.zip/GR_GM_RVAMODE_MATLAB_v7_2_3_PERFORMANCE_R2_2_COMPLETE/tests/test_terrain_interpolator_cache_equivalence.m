function test_terrain_interpolator_cache_equivalence()
[xg,yg]=meshgrid(0:2:20,0:3:18);
terrain=0.2*xg+0.3*yg+sin(xg/4).*cos(yg/5);
problem.gridX=xg; problem.gridY=yg;
problem.gridXVector=xg(1,:); problem.gridYVector=yg(:,1);
problem.terrain=terrain;
problem.enableTerrainInterpolatorCache=true;
problem.terrainInterpolationCacheId='unit-cache-equivalence-r21';

% Point-list contract.
x=[0;1.5;7.2;19.9;21]; y=[0;4.4;9.7;17.8;3];
expected=interp2(problem.gridXVector,problem.gridYVector,terrain,x,y,'linear',NaN);
expected(isnan(expected))=max(terrain(:));
actual=data.terrainHeight(problem,x,y);
assert(max(abs(actual(:)-expected(:)))<=1e-10);

% Matrix/LOS contract: equal-sized query matrices are pairwise coordinates,
% must preserve INTERP2 values and must not emit the MESHGRID warning flood.
[xm,ym]=meshgrid(linspace(1,19,9),linspace(1,17,7));
expectedM=interp2(problem.gridXVector,problem.gridYVector,terrain,xm,ym,'linear',NaN);
lastwarn('');
actualM=data.terrainHeight(problem,xm,ym);
[msg,~]=lastwarn;
assert(max(abs(actualM(:)-expectedM(:)))<=1e-10);
assert(isempty(msg),sprintf('Cached terrain matrix query emitted warning: %s',msg));

% Scalar expansion contract.
ys=linspace(1,17,11)'; xs=7.5;
expectedS=interp2(problem.gridXVector,problem.gridYVector,terrain, ...
    repmat(xs,size(ys)),ys,'linear',NaN);
actualS=data.terrainHeight(problem,xs,ys);
assert(isequal(size(actualS),size(ys)));
assert(max(abs(actualS(:)-expectedS(:)))<=1e-10);

problem.enableTerrainInterpolatorCache=false;
base=data.terrainHeight(problem,x,y);
assert(max(abs(actual(:)-base(:)))<=1e-10);
fprintf('test_terrain_interpolator_cache_equivalence passed.\n');
end
