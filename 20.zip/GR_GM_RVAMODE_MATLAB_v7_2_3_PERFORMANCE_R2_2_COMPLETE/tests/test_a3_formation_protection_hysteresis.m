function test_a3_formation_protection_hysteresis()
%TEST_A3_FORMATION_PROTECTION_HYSTERESIS Formation stays plastic near thresholds.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.multiUAVShiyanConfig();
gen=40;
assert(cfg.enableFormationMissionProtectionHysteresis);
assert(gen<cfg.missionFormalStartGeneration);

% A just-satisfied Q condition is not frozen during formation. The selected
% target can improve while that marginal condition slips slightly below the
% formal line, provided the external global-D gate still does not regress.
base=localFixture([0.331 repmat(0.80,1,5) 0.00 0.00 0.80 0.80]);
trial=localFixture([0.327 repmat(0.80,1,5) 0.08 0.00 0.80 0.80]);
p=evaluation.assessMissionProtection(base,trial,cfg,gen);
assert(p.allowed && strcmp(p.stage,'formation'));
a=evaluation.assessMissionRepairCandidate(trial,base,7,cfg,gen);
assert(a.eligible, ...
    'Formation hysteresis should permit near-threshold plasticity when D does not regress.');

% A zero quality component alone must not re-freeze a just-satisfied target
% during formation; raw-metric hysteresis owns the protection decision here.
componentBase=localFixture([0.331 repmat(0.80,1,9)]);
componentTrial=localFixture([0.329 repmat(0.80,1,9)]);
p=evaluation.assessMissionProtection(componentBase,componentTrial,cfg,gen);
assert(p.allowed, ...
    'Formation must not duplicate hysteretic Q protection with strict component freezing.');

% Once the base has cleared the Q entry margin, crossing the formal line is
% again forbidden.
hardBase=base; hardTrial=trial;
hardBase.monitorStats.truePerTarget(1)=0.36;
hardBase.monitorPerTarget=hardBase.monitorStats.truePerTarget;
hardBase=localRefreshCritical(hardBase);
hardTrial.monitorStats.truePerTarget(1)=0.327;
hardTrial.monitorPerTarget=hardTrial.monitorStats.truePerTarget;
hardTrial=localRefreshCritical(hardTrial);
p=evaluation.assessMissionProtection(hardBase,hardTrial,cfg,gen);
assert(~p.allowed && strcmp(p.reason,'protected_q'));
assert(p.targetIndex==1 && abs(p.formalThreshold-cfg.monitorMinTargetQuality)<1e-12);
assert(abs(p.entryThreshold-(cfg.monitorMinTargetQuality+cfg.missionProtectionQMargin))<1e-12);

% Observation hysteresis: 185 m is formal but not stable enough to freeze;
% 205 m is stable and must not be allowed to fall below 180 m.
obsBase=localFixture(0.80*ones(1,10));
obsTrial=obsBase;
obsBase.monitorStats.observationLength(1)=185;
obsTrial.monitorStats.observationLength(1)=175;
p=evaluation.assessMissionProtection(obsBase,obsTrial,cfg,gen);
assert(p.allowed);
obsBase.monitorStats.observationLength(1)=205;
p=evaluation.assessMissionProtection(obsBase,obsTrial,cfg,gen);
assert(~p.allowed && strcmp(p.reason,'protected_observation'));

% LOS hysteresis follows the same entry/floor contract.
losBase=localFixture(0.80*ones(1,10));
losTrial=losBase;
losBase.monitorStats.losRatio(1)=0.47;
losTrial.monitorStats.losRatio(1)=0.44;
p=evaluation.assessMissionProtection(losBase,losTrial,cfg,gen);
assert(p.allowed);
losBase.monitorStats.losRatio(1)=0.52;
p=evaluation.assessMissionProtection(losBase,losTrial,cfg,gen);
assert(~p.allowed && strcmp(p.reason,'protected_los'));

% Aggregate Critical Q also has an independent hysteresis entry margin.
cqBase=localFixture([repmat(0.43,1,6) repmat(0.80,1,4)]);
cqTrial=localFixture([repmat(0.415,1,6) repmat(0.80,1,4)]);
p=evaluation.assessMissionProtection(cqBase,cqTrial,cfg,gen);
assert(p.allowed);
cqBase=localFixture([repmat(0.45,1,6) repmat(0.80,1,4)]);
p=evaluation.assessMissionProtection(cqBase,cqTrial,cfg,gen);
assert(~p.allowed && strcmp(p.reason,'protected_critical_q'));

fprintf('test_a3_formation_protection_hysteresis passed.\n');
end

function ind=localFixture(q)
q=q(:); M=numel(q);
ind.staticCV=0; ind.cv=0; ind.feasible=true;
ind.monitorPerTarget=q;
ind.monitorStats.truePerTarget=q;
ind.monitorStats.searchPerTarget=q;
ind.monitorStats.observationLength=300*ones(M,1);
ind.monitorStats.losRatio=0.90*ones(M,1);
ind=localRefreshCritical(ind);
end

function ind=localRefreshCritical(ind)
q=ind.monitorStats.truePerTarget(:);
critical=1:min(6,numel(q));
value=mean(q(critical));
ind.monitorStats.criticalQuality=value;
ind.monitorStats.trueCriticalQuality=value;
ind.monitorStats.minimumCriticalObservationLength= ...
    min(ind.monitorStats.observationLength(critical));
ind.monitorStats.minimumCriticalLOSRatio=min(ind.monitorStats.losRatio(critical));
end
