function test_observation_arc_insertion()
% A direct arc insertion must reduce annulus distance to an uncovered target.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.fastConfig(); cfg.numWaypoints=14;
problem=data.createDemoProblem(cfg);
ind.genes=core.initializeGenes(problem,cfg,1,1);
ind=repair.repairPath(ind,problem,cfg);
ind=evaluation.evaluateIndividual(ind,problem,cfg,1);
targetIndex=4;
beforeGap=ind.monitorStats.annulusGap(targetIndex);
newGenes=operators.insertTargetObservationArc( ...
    ind.genes,targetIndex,problem,cfg,1);
cand=ind; cand.genes=newGenes;
cand=repair.repairPath(cand,problem,cfg);
cand=evaluation.evaluateIndividual(cand,problem,cfg,1);
assert(norm(cand.genes-ind.genes)>1e-8);
assert(cand.monitorStats.annulusGap(targetIndex)<beforeGap-1e-6 || ...
    cand.monitorStats.observationLength(targetIndex)>0);
assert(cand.monitorStats.coverageDeficit(targetIndex)<= ...
    ind.monitorStats.coverageDeficit(targetIndex)+1e-9);
fprintf('test_observation_arc_insertion passed.\n');
end
