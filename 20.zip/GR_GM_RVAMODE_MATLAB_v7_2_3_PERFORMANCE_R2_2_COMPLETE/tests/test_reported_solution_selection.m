function test_reported_solution_selection
cfg = config.defaultConfig();
cfg.finalReportedSmoothnessLimit = 10;
cfg.finalReportedMaximumDetour = 10;
cfg.finalReportedMaximumEnergyRatioToBest = 10;
cfg.finalReportedMaximumRiskObjective = 10;
cfg.finalReportedMaximumMeanRisk = 10;
cfg.finalReportedMaximumTailRisk = 10;
cfg.finalReportedRelaxedSmoothnessLimit = 10;
cfg.finalReportedRelaxedMaximumDetour = 10;
cfg.finalReportedRelaxedMaximumEnergyRatioToBest = 10;
cfg.finalReportedRelaxedMaximumRiskObjective = 10;
cfg.finalReportedRelaxedMaximumMeanRisk = 10;
cfg.finalReportedRelaxedMaximumTailRisk = 10;
a = localIndividual(1);
b = localIndividual(2);
c = localIndividual(3);
d = localIndividual(4);
reps.labels = {'Balanced';'MinimumPhysicalCost'; ...
    'CommonKneePoint';'RiskBalanced'};
reps.solutions = [a;b;c;d];
[best,label,index,level] = ...
    selection.selectReportedSolution(reps,[a;b;c;d],cfg);
assert(strcmp(label,'RiskBalanced'));
assert(index==4 && best.objectives(1)==4);
assert(strcmp(level,'strict_engineering'));

cfg.finalReportedSolution = 'MissingLabel';
[best,label,index] = selection.selectReportedSolution(reps,[a;b;c;d],cfg);
assert(strcmp(label,'MinimumPhysicalCost'));
assert(index==2 && best.objectives(1)==2);
fprintf('test_reported_solution_selection passed.\n');
end

function ind = localIndividual(value)
ind.objectives = [value value value value value];
ind.cv = 0;
ind.feasible = true;
ind.riskStats = struct('objective',value,'meanRisk',value, ...
    'tailRisk',value);
end
