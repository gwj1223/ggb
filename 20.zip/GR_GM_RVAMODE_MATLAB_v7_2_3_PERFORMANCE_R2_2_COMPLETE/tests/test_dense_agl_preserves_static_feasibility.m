function test_dense_agl_preserves_static_feasibility()
%TEST_DENSE_AGL_PRESERVES_STATIC_FEASIBILITY Do not polish valid AGL paths.
%
% Deterministic regression for the v6.5.6 failure mode where a
% representative already inside the formal dense AGL envelope was moved to
% create internal margin and subsequently violated the hard climb-angle
% constraint.  The fixture intentionally removes unrelated obstacle/energy/
% turn limits so the test isolates the AGL-vs-climb preservation invariant.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.multiUAVShiyanConfig();
[problem,cfg] = realdata.buildShiyanG1Problem(root,cfg);

% Use a dense deterministic terrain-following carrier rather than relying on
% a random initialized population to happen to contain a static-feasible path.
cfg.numWaypoints = 72;
cfg.enableDenseFinalAGLRepair = true;
cfg.enableLocalAGLConstraint = true;
cfg.denseFinalAGLRepairOnlyIfFormalViolation = true;
cfg.maxTurnAngleDeg = 180;
cfg.maxEnergy = inf;
problem.obstacles = zeros(0,4);

q = linspace(0,1,cfg.numWaypoints+2)';
q = q(2:end-1);
xy = problem.start(1:2)+q.*(problem.goal(1:2)-problem.start(1:2));
h = data.terrainHeight(problem,xy(:,1),xy(:,2));
midAGL = 0.5*(cfg.safeClearance+cfg.realMaximumAGL);
pts = [xy,h+midAGL];

seed = core.initializePopulation(problem,cfg);
original = seed(1);
original.genes = reshape(pts,1,[]);
original = repair.repairPath(original,problem,cfg);
original = evaluation.evaluateIndividual(original,problem,cfg,1);

assert(original.staticCV <= cfg.constraintTolerance, ...
    'Deterministic test carrier is not static feasible.');
assert(original.violation.climb <= cfg.constraintTolerance, ...
    'Deterministic test carrier violates the climb constraint.');

[candidate,stats] = repair.finalizeLocalAGL(original,problem,cfg,1);
assert(stats.formalAGLOKBefore, ...
    'Deterministic test carrier is not dense-formal-AGL valid.');
assert(stats.skippedFormalValid);
assert(~stats.applied);
assert(stats.evaluations==0);
assert(stats.formalAGLOKAfter);
assert(candidate.staticCV <= cfg.constraintTolerance);
assert(candidate.violation.climb <= cfg.constraintTolerance);
assert(max(abs(candidate.genes(:)-original.genes(:)))<1e-12);
fprintf('test_dense_agl_preserves_static_feasibility passed: AGL [%.3f, %.3f] m.\n', ...
    stats.minAGLAfter,stats.maxAGLAfter);
end
