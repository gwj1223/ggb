function test_shiyan_g1_problem()
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.shiyanG1Config();
[problem,cfg,scene]=realdata.buildShiyanG1Problem(root,cfg);
assert(scene.validation.ok);
assert(size(problem.monitorTargets,1)==30);
assert(isempty(problem.obstacles));
assert(problem.start(3)-data.terrainHeight(problem,problem.start(1),problem.start(2))>=cfg.safeClearance);
assert(problem.goal(3)-data.terrainHeight(problem,problem.goal(1),problem.goal(2))>=cfg.safeClearance);
assert(all(problem.monitorTargetTerrain>300));
assert(all(problem.monitorTargets(:,4)>200));
assert(max(problem.risk(:))<0.65);
assert(isequal(cfg.criticalTargetIndices(:)',1:6));
xy=problem.monitorTargets(:,1:2);
minSep=inf;
for i=1:size(xy,1)-1
    minSep=min(minSep,min(vecnorm(xy(i+1:end,:)-xy(i,:),2,2)));
end
assert(minSep>750);
fprintf('test_shiyan_g1_problem passed.\n');
end
