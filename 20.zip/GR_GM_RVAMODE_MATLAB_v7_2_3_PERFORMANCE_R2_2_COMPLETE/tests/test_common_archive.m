function test_common_archive
cfg = config.defaultConfig();
a = localIndividual([1.20 0.30 150 0.10 0.20],0.80,cfg);
b = localIndividual([1.25 0.35 160 0.12 0.25],0.70,cfg); % dominated by a
c = localIndividual([1.10 0.40 145 0.09 0.30],0.65,cfg); % trade-off
archive = selection.updateCommonArchive([], [a;b;c],10,cfg);
assert(numel(archive)==2);
F = metrics.commonObjectiveMatrix(archive);
dominates12 = all(F(1,:)<=F(2,:)) && any(F(1,:)<F(2,:));
dominates21 = all(F(2,:)<=F(1,:)) && any(F(2,:)<F(1,:));
assert(~dominates12 && ~dominates21);
assert(all(arrayfun(@(x)evaluation.checkFinalMonitoringFeasibility(x,cfg), ...
    archive)));
fprintf('test_common_archive passed.\n');
end

function ind = localIndividual(obj,minQ,cfg)
ind.objectives = obj;
ind.feasible = true;
ind.staticCV = 0;
ind.cv = 0;
ind.rank = 1;
ind.crowding = 0;
ind.monitorPerTarget = [minQ;0.85;0.88;minQ];
ind.monitorStats.truePerTarget = ind.monitorPerTarget;
ind.monitorStats.minimumQuality = minQ;
ind.monitorStats.criticalQuality = 0.85;
ind.monitorStats.trueCriticalQuality = 0.85;
ind.monitorStats.observationLength = 12*ones(4,1);
ind.monitorStats.losRatio = 0.8*ones(4,1);
ind.monitorStats.minimumCriticalObservationLength = 12;
ind.monitorStats.minimumCriticalLOSRatio = 0.8;
ind.monitorStats.dispersionPenalty = 0.05;
ind.violation = struct('collision',0,'clearance',0,'climb',0, ...
    'turn',0,'energy',0);
end
