function test_local_agl_envelope()
%TEST_LOCAL_AGL_ENVELOPE Verify the formal Shiyan-G1 local AGL envelope.
% v7.0.0 test contract: validate active mission/AGL semantics, not legacy
% snap-final feedback-controller tuning constants.
root = fileparts(fileparts(mfilename('fullpath')));
setupProject(root);
cfg = config.multiUAVShiyanConfig();
[problem,cfg] = realdata.buildShiyanG1Problem(root,cfg);

assert(isfield(cfg,'enableLocalAGLConstraint') && cfg.enableLocalAGLConstraint);
% v7 uses the unified Mission Deficit schedule in the multi-UAV path.
assert(cfg.enableUnifiedMissionDeficit);
assert(~cfg.enableFeasibilityFeedbackThreshold);
assert(~cfg.monitorComponentwiseThresholdUpdate);

cfg.numWaypoints = 18;
q = linspace(0,1,cfg.numWaypoints+2)'; q = q(2:end-1);
xy = problem.start(1:2)+q.*(problem.goal(1:2)-problem.start(1:2));
h = data.terrainHeight(problem,xy(:,1),xy(:,2));
pts = [xy,h+cfg.realMaximumAGL+80];
ind.genes = reshape(pts,1,[]);
ind = repair.repairPath(ind,problem,cfg);
path = [problem.start;reshape(ind.genes,[],3);problem.goal];
cache = evaluation.buildPathSampleCache(path,problem, ...
    max(cfg.segmentRepairSamples,20),false);
sampleZ = reshape(cache.points(:,3),cache.numSamples,cache.numSegments);
agl = sampleZ-cache.terrain;
assert(min(agl(:)) >= cfg.safeClearance-1e-6);
assert(max(agl(:)) <= cfg.realMaximumAGL+1e-6);
fprintf('test_local_agl_envelope passed: AGL [%.3f, %.3f] m.\n', ...
    min(agl(:)),max(agl(:)));
end
