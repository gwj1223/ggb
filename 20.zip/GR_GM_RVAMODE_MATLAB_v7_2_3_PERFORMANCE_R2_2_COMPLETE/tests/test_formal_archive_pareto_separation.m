function test_formal_archive_pareto_separation()
%TEST_FORMAL_ARCHIVE_PARETO_SEPARATION Search-band safeguards never enter final archive.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig();
cfg.archiveSize=20;
cfg.enableMissionBandSelection=true; %#ok<STRNU>

T=struct('objectives',ones(1,5),'cv',0,'feasible',true, ...
    'rank',inf,'crowding',0,'genes',zeros(1,2));
a=T; b=T; c=T;
a.objectives=[1 1 1 1 1]; a.genes=[1 1];
b.objectives=[2 2 2 2 2]; b.genes=[2 2]; % dominated by a
c.objectives=[0.5 3 0.5 3 0.5]; c.genes=[3 3]; % nondominated with a

archive=selection.updateFormalArchive([], [a;b;c], cfg.archiveSize,cfg);
assert(numel(archive)==2, ...
    'Formal archive must contain only the five-objective nondominated front.');
genes=vertcat(archive.genes);
assert(any(all(abs(genes-[1 1])<=1e-12,2)));
assert(any(all(abs(genes-[3 3])<=1e-12,2)));
assert(~any(all(abs(genes-[2 2])<=1e-12,2)), ...
    'Objective-dominated formal candidate must not be retained.');

runText=fileread(fullfile(root,'src','+core','runGRAHMODE.m'));
assert(contains(runText,'selection.updateFormalArchive'), ...
    'runGRAHMODE final archive path must use the dedicated formal archive helper.');
fprintf('test_formal_archive_pareto_separation passed.\n');
end
