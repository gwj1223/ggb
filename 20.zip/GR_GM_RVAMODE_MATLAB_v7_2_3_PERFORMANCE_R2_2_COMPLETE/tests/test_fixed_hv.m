function test_fixed_hv()
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig(); samples=metrics.createHVSamples(cfg);
a=struct('objectives',[1.20 0.30 180 .2 .3],'cv',0);
h1=metrics.approxHypervolumeFixed(a,cfg,samples);
h2=metrics.approxHypervolumeFixed(a,cfg,samples);
assert(isfinite(h1) && h1>0 && abs(h1-h2)<eps, ...
    'Fixed HV must be positive and deterministic.');
a.cv=1; h3=metrics.approxHypervolumeFixed(a,cfg,samples);
assert(isnan(h3),'HV must be NaN without feasible points.');
fprintf('test_fixed_hv passed.\n');
end
