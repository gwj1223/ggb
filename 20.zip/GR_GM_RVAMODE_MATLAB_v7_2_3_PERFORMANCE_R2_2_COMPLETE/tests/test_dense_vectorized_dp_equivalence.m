function test_dense_vectorized_dp_equivalence()
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig();
cfg.safeClearance=20; cfg.maxAltitude=220;
cfg.enableLocalAGLConstraint=true; cfg.realMaximumAGL=120;
cfg.maxClimbAngleDeg=35; cfg.segmentRepairMargin=0;
cfg.aglConstraintSampleStep_m=7; cfg.aglConstraintMaxSamplesPerSegment=96;
cfg.missionRepairDenseAltitudeGridStep_m=2;
[xg,yg]=meshgrid(0:2:160,0:2:80);
terrain=8*sin(xg/31)+5*cos(yg/19)+0.035*xg;
problem.gridX=xg; problem.gridY=yg; problem.terrain=terrain;
problem.risk=zeros(size(terrain)); problem.obstacles=zeros(0,4);
xy=[0 20;25 25;55 18;80 35;110 30;135 48;160 45];
startZ=data.terrainHeight(problem,xy(1,1),xy(1,2))+70;
endZ=data.terrainHeight(problem,xy(end,1),xy(end,2))+75;
preferred=data.terrainHeight(problem,xy(:,1),xy(:,2))+78;
cache0=containers.Map('KeyType','char','ValueType','any');
cache1=containers.Map('KeyType','char','ValueType','any');
cfg.enableDenseProjectionVectorizedDP=false;
[z0,i0]=core.projectDenseTerrainReachableProfile(xy,startZ,endZ,preferred,problem,cfg,cache0);
cfg.enableDenseProjectionVectorizedDP=true;
[z1,i1]=core.projectDenseTerrainReachableProfile(xy,startZ,endZ,preferred,problem,cfg,cache1);
assert(isequal(i0.success,i1.success));
assert(strcmp(i0.reason,i1.reason));
assert(isequal(i0.failedSegment,i1.failedSegment));
assert(numel(z0)==numel(z1));
if ~isempty(z0)
    assert(max(abs(z0(:)-z1(:)))<=1e-10);
end
if isfinite(i0.cost) || isfinite(i1.cost)
    assert(abs(i0.cost-i1.cost)<=1e-10);
end
assert(i0.terrainSampleCacheMisses==i1.terrainSampleCacheMisses);
fprintf('test_dense_vectorized_dp_equivalence passed.\n');
end
