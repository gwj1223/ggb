function test_mission_band_trial_context()
%TEST_MISSION_BAND_TRIAL_CONTEXT P-best donors come from mission leaders.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig();
cfg.enableUnifiedMissionDeficit=true;
cfg.enableMissionBandSelection=true;
cfg.missionBandMinFraction=0.25;
cfg.missionBandTolerance=1e-10;
cfg.runtimeMissionDeficitEpsilon=0.10;
cfg.populationSize=8;
cfg.pbestRate=0.20;

T=struct('objectives',zeros(1,5),'cv',0.5,'feasible',false, ...
    'rank',inf,'crowding',0,'staticCV',0,'staticFeasible',true, ...
    'missionScheduleFeasible',false,'formalMissionSatisfied',false, ...
    'missionDeficit',0.5,'missionDeficitEpsilon',0.1,'genes',zeros(1,3));
pop=repmat(T,8,1);
for i=1:8
    pop(i).missionDeficit=0.30+0.01*(i-1);
    pop(i).objectives=[i 9-i i 9-i i];
    pop(i).genes=[i i i];
end
ctx=operators.buildTrialContext(pop,pop(1:2),cfg,50);
state=selection.missionBandState(pop,cfg,50,8);
leaders=find(state.searchAdmissible);
assert(~isempty(ctx.pbestOrder));
assert(all(ismember(ctx.pbestOrder,leaders)), ...
    'Mission-band p-best order must stay inside the protected leader set.');
assert(ctx.missionBandCount==state.bandCount);
assert(abs(ctx.missionBandEffectiveEpsilon-state.effectiveEpsilon)<1e-12);
fprintf('test_mission_band_trial_context passed.\n');
end
