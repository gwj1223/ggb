function test_final_stopping_formal_evidence_gate()
%TEST_FINAL_STOPPING_FORMAL_EVIDENCE_GATE No false formal-stage stagnation stop.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
emptyArchive = struct([]);
formalArchive = struct('objectives',[1 2 3 4 5]);
assert(~core.finalStageStoppingEvidenceAvailable(emptyArchive,0.2,0.5));
assert(~core.finalStageStoppingEvidenceAvailable(formalArchive,NaN,0.5));
assert(~core.finalStageStoppingEvidenceAvailable(formalArchive,0.2,Inf));
assert(core.finalStageStoppingEvidenceAvailable(formalArchive,0.2,0.5));

runText = fileread(fullfile(root,'src','+core','runGRAHMODE.m'));
assert(contains(runText,'commonHVEvaluated && formalStoppingEvidence'));
fprintf('test_final_stopping_formal_evidence_gate passed.\n');
end
