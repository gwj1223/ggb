function test_a3_vertical_profile_contract()
%TEST_A3_VERTICAL_PROFILE_CONTRACT v7.0.5 vertical-feasibility guard.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.multiUAVShiyanConfig();
assert(isfield(cfg,'implementationVersion') && strncmp(cfg.implementationVersion,'v7.',3));

assert(cfg.missionRepairUseStaticSafeAltitudeProfile);
assert(cfg.missionRepairUseDenseTerrainReachability);
arcText=fileread(fullfile(root,'src','+core','injectTargetObservationArc.m'));
assert(contains(arcText,'projectDenseTerrainReachableProfile'));
assert(~contains(arcText,'rawZ = repmat(preferredCruiseZ'));
projectText=fileread(fullfile(root,'src','+core', ...
    'projectDenseTerrainReachableProfile.m'));
assert(contains(projectText,'denseLower'));
assert(contains(projectText,'nextPred'));
assert(contains(projectText,'maxClimbAngleDeg'));
repairText=fileread(fullfile(root,'src','+core','unifiedMissionRepair.m'));
assert(contains(repairText,'precheckRejectReach'));
assert(contains(repairText,'staticLowerAGL'));
assert(contains(repairText,'worstMaxClimbDeg'));
fprintf('test_a3_vertical_profile_contract passed.\n');
end
