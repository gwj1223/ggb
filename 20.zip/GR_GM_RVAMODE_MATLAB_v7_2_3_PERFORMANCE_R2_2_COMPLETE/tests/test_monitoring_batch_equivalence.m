function test_monitoring_batch_equivalence()
% Optimized batched LOS must reproduce the original target-by-target formula.
root = fileparts(fileparts(mfilename('fullpath')));
setupProject(root);
cfg = config.fastConfig();
cfg.monitorCoverageSamples = 7;
cfg.monitorLineOfSightSamples = 7;
problem = data.createDemoProblem(cfg);

K = 10;
t = linspace(0,1,K+2)';
t = t(2:end-1);
mid = problem.start+t.*(problem.goal-problem.start);
mid(:,1) = mid(:,1)+3*sin(2*pi*t);
mid(:,2) = mid(:,2)+2*cos(2*pi*t);
ground = data.terrainHeight(problem,mid(:,1),mid(:,2));
mid(:,3) = max(mid(:,3),ground(:)+cfg.safeClearance+3);
path = [problem.start;mid;problem.goal];
cache = evaluation.buildPathSampleCache( ...
    path,problem,cfg.monitorCoverageSamples,false);

[qNew,pNew,sNew] = evaluation.monitoringQuality(path,problem,cfg,cache);
[qRef,pRef,sRef] = localReference(path,problem,cfg,cache);

tol = 1e-10;
assert(abs(qNew-qRef) < tol);
assert(max(abs(pNew-pRef)) < tol);
fields = {'minimumQuality','criticalQuality','dispersionPenalty', ...
    'searchAverageQuality','searchMinimumQuality','searchCriticalQuality', ...
    'unionObservationLength','minimumCriticalObservationLength', ...
    'minimumCriticalLOSRatio'};
for k = 1:numel(fields)
    assert(abs(sNew.(fields{k})-sRef.(fields{k})) < tol);
end
vectorFields = {'observationLength','losRatio','rawLOSRatio','rangeQuality', ...
    'heightQuality','durationQuality','instantQuality','annulusGap', ...
    'coverageDeficit','observationDeficit','searchPerTarget'};
for k = 1:numel(vectorFields)
    assert(max(abs(sNew.(vectorFields{k})-sRef.(vectorFields{k}))) < tol);
end
fprintf('test_monitoring_batch_equivalence passed.\n');
end

function [quality,perTarget,stats] = localReference(path,problem,cfg,sampleCache)
% Original v6.4.0 target-by-target implementation retained only as a test oracle.
T = problem.monitorTargets;
M = size(T,1);
truePerTarget = zeros(M,1);
searchPerTarget = zeros(M,1);
obsLength = zeros(M,1);
losQuality = zeros(M,1);
rawLOSRatio = zeros(M,1);
rangeQuality = zeros(M,1);
heightQuality = zeros(M,1);
durationQuality = zeros(M,1);
instantQuality = zeros(M,1);
annulusGap = zeros(M,1);
coverageDeficit = zeros(M,1);
observationDeficit = zeros(M,1);
points = sampleCache.points;
ground = sampleCache.terrain(:);
numSamples = sampleCache.numSamples;
numSegments = sampleCache.numSegments;
segmentLengths = sampleCache.segmentLengths;
visibleValidMatrix = false(size(points,1),M);

exponents = [cfg.monitorRangeExponent cfg.monitorHeightExponent ...
    cfg.monitorLOSExponent cfg.monitorDurationExponent];
exponents = max(exponents,0);
exponents = exponents/max(sum(exponents),eps);
if isfield(cfg,'monitorSearchComponentFloor')
    searchFloor = cfg.monitorSearchComponentFloor;
elseif isfield(cfg,'monitorComponentFloor')
    searchFloor = cfg.monitorComponentFloor;
else
    searchFloor = 0.01;
end
searchFloor = min(max(searchFloor,eps),0.20);

for m = 1:M
    tx = T(m,1); ty = T(m,2);
    desiredR = T(m,4); desiredH = T(m,5);
    horiz = hypot(points(:,1)-tx,points(:,2)-ty);
    relH = points(:,3)-ground;
    qRangeAll = exp(-0.5*((horiz-desiredR)/cfg.monitorRangeSigma).^2);
    qHeightAll = exp(-0.5*((relH-desiredH)/cfg.monitorHeightSigma).^2);
    lowerRange = cfg.monitorObservationRangeFactor(1)*desiredR;
    upperRange = cfg.monitorObservationRangeFactor(2)*desiredR;
    pointGap = max(lowerRange-horiz,0)+max(horiz-upperRange,0);
    closestGap = min(pointGap);
    approachScale = localCfg(cfg,'monitorCoverageDeficitScale',desiredR);
    qApproach = exp(-closestGap/max(approachScale,eps));

    blocked = false(size(points,1),1);
    if cfg.enableLineOfSight && cfg.monitorLineOfSightSamples > 2
        if isfield(problem,'monitorTargetTerrain') && ...
                numel(problem.monitorTargetTerrain) >= m
            terrainTarget = problem.monitorTargetTerrain(m);
        else
            terrainTarget = data.terrainHeight(problem,tx,ty);
        end
        alpha = linspace(0,1,cfg.monitorLineOfSightSamples);
        lineX = bsxfun(@plus,points(:,1), ...
            bsxfun(@times,tx-points(:,1),alpha));
        lineY = bsxfun(@plus,points(:,2), ...
            bsxfun(@times,ty-points(:,2),alpha));
        lineZ = bsxfun(@plus,points(:,3), ...
            bsxfun(@times,(terrainTarget+1)-points(:,3),alpha));
        terrainLOS = data.terrainHeight(problem,lineX,lineY);
        blocked = any(terrainLOS(:,2:end-1) > lineZ(:,2:end-1),2);
    end
    visible = ~blocked;

    spatialMerit = qRangeAll.*qHeightAll;
    visibilitySearch = searchFloor+(1-searchFloor)*double(visible);
    coherentMerit = spatialMerit.*visibilitySearch;
    [bestCoherentMerit,bestIndex] = max(coherentMerit);
    if isempty(bestIndex) || bestCoherentMerit <= 0
        qR = 0; qH = 0;
    else
        qR = qRangeAll(bestIndex); qH = qHeightAll(bestIndex);
    end

    qLOS = sum(spatialMerit.*double(visible))/max(sum(spatialMerit),eps);
    qLOS = min(max(qLOS,0),1);
    useful = horiz >= lowerRange & horiz <= upperRange & ...
        qHeightAll >= exp(-0.5);
    visibleUseful = useful & visible;
    visibleValidMatrix(:,m) = visibleUseful;
    validBySegment = reshape(visibleUseful,numSamples,numSegments);
    visibleLength = sum(segmentLengths.*mean(validBySegment,1)');
    qDuration = 1-exp(-visibleLength/max(cfg.monitorRequiredObservationLength,eps));

    rawComponents = min(max([qR qH qLOS qDuration],0),1);
    active = exponents > 0;
    if any(active), trueTarget = prod(rawComponents(active).^exponents(active));
    else, trueTarget = 1; end
    searchComponents = searchFloor+(1-searchFloor)*rawComponents;
    searchTarget = prod(searchComponents(active).^exponents(active));

    truePerTarget(m) = min(max(trueTarget,0),1);
    searchPerTarget(m) = min(max(searchTarget,0),1);
    obsLength(m) = visibleLength;
    losQuality(m) = qLOS;
    rawLOSRatio(m) = mean(visible);
    rangeQuality(m) = qR;
    heightQuality(m) = qH;
    durationQuality(m) = qDuration;
    instantQuality(m) = max(spatialMerit.*double(visible));
    annulusGap(m) = closestGap;
    coverageDeficit(m) = 1-qApproach;
    observationDeficit(m) = max(0, ...
        cfg.monitorRequiredObservationLength-visibleLength)/ ...
        max(cfg.monitorRequiredObservationLength,eps);
end

weights = T(:,3);
quality = sum(weights.*truePerTarget)/max(sum(weights),eps);
searchQuality = sum(weights.*searchPerTarget)/max(sum(weights),eps);
critical = cfg.criticalTargetIndices(:);
critical = critical(critical>=1 & critical<=M);
if isempty(critical)
    criticalQuality = quality;
    searchCriticalQuality = searchQuality;
    minimumCriticalObservationLength = min(obsLength);
    minimumCriticalLOSRatio = min(losQuality);
else
    criticalQuality = sum(weights(critical).*truePerTarget(critical))/ ...
        max(sum(weights(critical)),eps);
    searchCriticalQuality = sum(weights(critical).*searchPerTarget(critical))/ ...
        max(sum(weights(critical)),eps);
    minimumCriticalObservationLength = min(obsLength(critical));
    minimumCriticalLOSRatio = min(losQuality(critical));
end

trueDispersion = min(std(truePerTarget,0)/max(quality,eps),1);
searchDispersion = min(std(searchPerTarget,0)/max(searchQuality,eps),1);
unionVisible = any(visibleValidMatrix,2);
unionBySegment = reshape(unionVisible,numSamples,numSegments);
unionObservationLength = sum(segmentLengths.*mean(unionBySegment,1)');

perTarget = truePerTarget;
stats.minimumQuality = min(truePerTarget);
stats.criticalQuality = criticalQuality;
stats.dispersionPenalty = trueDispersion;
stats.searchPerTarget = searchPerTarget;
stats.searchAverageQuality = searchQuality;
stats.searchMinimumQuality = min(searchPerTarget);
stats.searchCriticalQuality = searchCriticalQuality;
stats.searchDispersionPenalty = searchDispersion;
stats.observationLength = obsLength;
stats.losRatio = losQuality;
stats.rawLOSRatio = rawLOSRatio;
stats.rangeQuality = rangeQuality;
stats.heightQuality = heightQuality;
stats.durationQuality = durationQuality;
stats.instantQuality = instantQuality;
stats.annulusGap = annulusGap;
stats.coverageDeficit = coverageDeficit;
stats.observationDeficit = observationDeficit;
stats.unionObservationLength = unionObservationLength;
stats.minimumCriticalObservationLength = minimumCriticalObservationLength;
stats.minimumCriticalLOSRatio = minimumCriticalLOSRatio;
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
