function test_risk_balanced_selection
cfg = config.defaultConfig();
shortRisky = localIndividual(1.24,0.39,0.29,0.64,174,0.07);
longSafe = localIndividual(1.33,0.28,0.21,0.50,181,0.10);
balanced = localIndividual(1.29,0.32,0.24,0.54,178,0.09);
archive = [shortRisky;longSafe;balanced];
[solution,index,score,details] = ...
    selection.selectRiskBalancedSolution(archive,cfg);
assert(index~=1);
assert(solution.riskStats.objective<=cfg.finalReportedMaximumRiskObjective+eps);
assert(solution.riskStats.tailRisk<=cfg.finalReportedMaximumTailRisk+eps);
assert(isfinite(score));
assert(strcmp(details.level,'strict_engineering'));
values = metrics.riskBalancedCostIndicator(archive,cfg);
assert(isinf(values(1))==false); % Score itself is independent of report mask.
fprintf('test_risk_balanced_selection passed.\n');
end

function ind = localIndividual(detour,risk,meanRisk,tailRisk,energy,smooth)
ind.objectives = [detour risk energy smooth 0.25];
ind.cv = 0;
ind.staticCV = 0;
ind.feasible = true;
ind.pathMetrics = struct('rawLength',100*detour, ...
    'directDistance',100,'detourRatio',detour);
ind.riskStats = struct('objective',risk,'meanRisk',meanRisk, ...
    'tailRisk',tailRisk);
ind.energyStats = struct('total',energy);
ind.monitorPerTarget = [0.75;0.85;0.86;0.78];
ind.monitorStats.truePerTarget = ind.monitorPerTarget;
ind.monitorStats.minimumQuality = 0.75;
ind.monitorStats.criticalQuality = 0.85;
ind.monitorStats.trueCriticalQuality = 0.85;
ind.monitorStats.minimumCriticalObservationLength = 12;
ind.monitorStats.minimumCriticalLOSRatio = 0.75;
ind.monitorStats.dispersionPenalty = 0.08;
ind.monitorStats.observationLength = 12*ones(4,1);
ind.monitorStats.losRatio = 0.75*ones(4,1);
end
