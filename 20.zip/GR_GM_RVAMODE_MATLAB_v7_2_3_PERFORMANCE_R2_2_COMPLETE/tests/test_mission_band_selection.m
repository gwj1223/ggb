function test_mission_band_selection()
%TEST_MISSION_BAND_SELECTION Scheduled epsilon remains formal; search band is relative.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig();
cfg.enableUnifiedMissionDeficit=true;
cfg.enableMissionBandSelection=true;
cfg.missionBandMinFraction=0.25;
cfg.missionBandTolerance=1e-10;
cfg.runtimeMissionDeficitEpsilon=0.20;
cfg.populationSize=8;

pop=localPopulation(8);
D=(0.40:0.01:0.47)';
for i=1:8
    pop(i).missionDeficit=D(i);
end
state=selection.missionBandState(pop,cfg,50,8);
assert(state.enabled);
assert(state.staticCount==8);
assert(state.scheduledCount==0);
assert(state.minimumLeaderCount==2);
assert(state.bandCount==2);
assert(all(find(state.searchAdmissible)==[1;2]));
assert(abs(state.scheduledEpsilon-0.20)<1e-12);
assert(abs(state.effectiveEpsilon-0.41)<1e-12);
fprintf('test_mission_band_selection passed.\n');
end

function pop=localPopulation(N)
template=struct('objectives',ones(1,5),'cv',0.5,'feasible',false, ...
    'rank',inf,'crowding',0,'staticCV',0,'staticFeasible',true, ...
    'missionScheduleFeasible',false,'formalMissionSatisfied',false, ...
    'missionDeficit',0.5,'missionDeficitEpsilon',0.2,'genes',zeros(1,3));
pop=repmat(template,N,1);
for i=1:N
    pop(i).genes=[i i i];
    pop(i).objectives=(i+1)*ones(1,5);
end
end
