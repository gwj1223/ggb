function test_a3_vertical_profile_projection()
%TEST_A3_VERTICAL_PROFILE_PROJECTION No-toolbox AGL/climb projection contract.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig();
problem=data.createDemoProblem(cfg);
N=9;
t=linspace(0,1,N)';
xy=problem.start(1:2)+t.*(problem.goal(1:2)-problem.start(1:2));
terrain=data.terrainHeight(problem,xy(:,1),xy(:,2));
margin=cfg.segmentRepairMargin;
lower=terrain+cfg.safeClearance+margin;
upper=cfg.maxAltitude*ones(size(lower));
startZ=min(max(lower(1)+5,lower(1)),upper(1));
endZ=min(max(lower(end)+5,lower(end)),upper(end));
preferred=median(lower+15);
[z,info]=core.projectStaticSafeAltitudeProfile( ...
    xy,startZ,endZ,preferred,problem,cfg);
assert(info.success);
assert(numel(z)==N);
agl=z-terrain;
assert(all(agl>=cfg.safeClearance+margin-1e-8));
seg=diff([xy z],1,1);
climb=atan2d(abs(seg(:,3)),max(hypot(seg(:,1),seg(:,2)),eps));
assert(all(climb<=cfg.maxClimbAngleDeg+1e-8));
fprintf('test_a3_vertical_profile_projection passed.\n');
end
