function test_final_threshold_archive()
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.fastConfig(); cfg.populationSize = 4;
problem = data.createDemoProblem(cfg);
state = evaluation.initializeMonitoringThresholdState(cfg);
runtimeCfg = evaluation.applyMonitoringThresholdState(cfg,state);
pop = core.initializePopulation(problem,runtimeCfg);
ind = evaluation.evaluateIndividual(pop(1),problem,runtimeCfg,1);
finalTh = struct('minimum',cfg.monitorMinTargetQuality, ...
    'critical',cfg.monitorCriticalMinQuality, ...
    'observationLength',cfg.monitorCriticalMinObservationLength, ...
    'losRatio',cfg.monitorCriticalMinLOSRatio,'progress',1);
finalInd = evaluation.updateDynamicConstraints(ind,cfg,1,finalTh);
assert(max(abs(ind.objectives-finalInd.objectives))<1e-12);
assert(finalInd.cv>=ind.cv-cfg.constraintTolerance);
assert(abs(finalInd.monitorThresholds.observationLength- ...
    cfg.monitorCriticalMinObservationLength)<1e-12);
fprintf('test_final_threshold_archive passed.\n');
end
