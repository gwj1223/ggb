function test_structured_monitoring_decode()
cfg=config.defaultConfig();
cfg.enableStructuredMonitoringEncoding=true;
cfg.numWaypoints=20;
cfg.maxClimbAngleDeg=89;
cfg.maxTurnAngleDeg=179;
cfg.structuredEncodingPrecheckTurn=false;
cfg.segmentRepairMargin=0;
cfg.enableLocalAGLConstraint=false;
problem=data.createDemoProblem(cfg);
problem.structuredMonitoringTargetOrder=core.structuredMonitoringTargetOrder(problem,cfg);
layout=core.structuredMonitoringLayout(problem,cfg);
[genes,info]=core.decodeStructuredMonitoringGenes(zeros(1,layout.dimension),problem,cfg);
assert(numel(genes)==3*cfg.numWaypoints);
assert(all(isfinite(genes)));
assert(info.arcPointCount==16);
assert(info.connectorBudget==4);
assert(sum(info.connectorCount)==4);
assert(numel(info.targetOrder)==4);
assert(info.success,'Zero semantic seed should decode on the permissive demo fixture.');
pts=reshape(genes,[],3);
assert(size(pts,1)==cfg.numWaypoints);
fprintf('test_structured_monitoring_decode passed.\n');
end
