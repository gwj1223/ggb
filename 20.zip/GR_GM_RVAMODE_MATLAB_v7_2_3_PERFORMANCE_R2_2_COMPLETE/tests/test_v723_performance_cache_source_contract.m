function test_v723_performance_cache_source_contract()
projectRoot=fileparts(fileparts(mfilename('fullpath')));
decoder=fileread(fullfile(projectRoot,'src','+core','decodeStructuredMonitoringGenes.m'));
projector=fileread(fullfile(projectRoot,'src','+core','projectDenseTerrainReachableProfile.m'));
terrain=fileread(fullfile(projectRoot,'+data','terrainHeight.m'));
assert(contains(decoder,'enableStructuredSegmentTerrainCache'));
assert(contains(decoder,'terrainSampleCacheHits'));
assert(contains(decoder,'denseProjectionTime_s'));
assert(contains(projector,'sampleCache'));
assert(contains(projector,'localSegmentSample'));
assert(contains(terrain,'griddedInterpolant'));
assert(contains(terrain,'terrainInterpolationCacheId'));
fprintf('test_v723_performance_cache_source_contract passed.\n');
end
