function test_structured_restart_preserves_semantic_contract()
cfg=config.defaultConfig();
cfg.enableStructuredMonitoringEncoding=true;
cfg.populationSize=8;
cfg.numWaypoints=20;
cfg.maxClimbAngleDeg=89;
cfg.maxTurnAngleDeg=179;
cfg.segmentRepairMargin=0;
cfg.enableLocalAGLConstraint=false;
cfg.structuredEncodingPrecheckTurn=false;
cfg.infeasibleRestartFraction=0.5;
problem=data.createDemoProblem(cfg);
problem.structuredMonitoringTargetOrder=core.structuredMonitoringTargetOrder(problem,cfg);
pop=core.initializePopulation(problem,cfg);
pop=evaluation.evaluatePopulation(pop,problem,cfg,1);
pop=core.restartInfeasiblePopulation(pop,problem,cfg,2);
for i=1:numel(pop)
    assert(~isempty(pop(i).structuredGenes));
    [decoded,~]=core.decodeStructuredMonitoringGenes(pop(i).structuredGenes,problem,cfg);
    assert(max(abs(decoded-pop(i).genes))<=1e-9, ...
        'Restarted structured individual must equal its deterministic decode.');
end
fprintf('test_structured_restart_preserves_semantic_contract passed.\n');
end
