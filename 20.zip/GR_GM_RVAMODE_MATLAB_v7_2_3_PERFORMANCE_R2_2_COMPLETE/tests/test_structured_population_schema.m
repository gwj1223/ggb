function test_structured_population_schema()
cfg=config.defaultConfig();
cfg.enableStructuredMonitoringEncoding=true;
cfg.populationSize=8;
cfg.numWaypoints=20;
cfg.maxClimbAngleDeg=89;
cfg.maxTurnAngleDeg=179;
cfg.segmentRepairMargin=0;
cfg.enableLocalAGLConstraint=false;
problem=data.createDemoProblem(cfg);
problem.structuredMonitoringTargetOrder=core.structuredMonitoringTargetOrder(problem,cfg);
pop=core.initializePopulation(problem,cfg);
layout=core.structuredMonitoringLayout(problem,cfg);
assert(numel(pop)==cfg.populationSize);
assert(isfield(pop,'structuredGenes') && isfield(pop,'encodingInfo'));
for i=1:numel(pop)
    assert(numel(pop(i).structuredGenes)==layout.dimension);
    assert(all(pop(i).structuredGenes>=-1-1e-12 & pop(i).structuredGenes<=1+1e-12));
    assert(numel(pop(i).genes)==3*cfg.numWaypoints);
end
fprintf('test_structured_population_schema passed.\n');
end
