function test_adaptive_agl_constraint_sampling()
%TEST_ADAPTIVE_AGL_CONSTRAINT_SAMPLING Physical sampling catches narrow ridge.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.defaultConfig();
cfg.safeClearance = 20;
cfg.enableLocalAGLConstraint = true;
cfg.enableDistanceAdaptiveAGLConstraintSampling = true;
cfg.realMaximumAGL = 100;
cfg.segmentSamples = 10;
cfg.aglConstraintSampleStep_m = 10;
cfg.aglConstraintMaxSamplesPerSegment = 64;
[xg,yg] = meshgrid(0:1:100,0:1:10);
terrain = zeros(size(xg));
terrain(:,51) = 50; % narrow ridge at x=50 m
problem.gridX = xg; problem.gridY = yg;
problem.terrain = terrain; problem.risk = zeros(size(terrain));
problem.obstacles = zeros(0,4);
path = [0 5 55;100 5 55];
% Historical fixed 10-point sampling misses x=50 exactly.
coarse = evaluation.buildPathSampleCache(path,problem,10,false);
coarseZ = reshape(coarse.points(:,3),coarse.numSamples,coarse.numSegments);
tmp = max(0,coarse.terrain+cfg.safeClearance-coarseZ);
coarseViolation = sum(tmp(:));
assert(coarseViolation==0);
stats = evaluation.evaluateLocalAGLEnvelope(path,problem,cfg);
assert(stats.lowerViolation>0);
assert(stats.minimumAGL < cfg.safeClearance);
assert(stats.maximumSpacing_m <= cfg.aglConstraintSampleStep_m+1e-12);
fprintf('test_adaptive_agl_constraint_sampling passed.\n');
end
