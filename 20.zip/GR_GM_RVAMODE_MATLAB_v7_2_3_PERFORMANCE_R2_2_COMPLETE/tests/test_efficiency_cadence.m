function test_efficiency_cadence
cfg = config.defaultConfig();
assert(cfg.commonArchiveUpdateInterval>=1);
assert(cfg.commonHVEvaluationInterval>=cfg.commonArchiveUpdateInterval);
assert(cfg.finalStageOperatorSelectionPressure>1);
assert(strcmp(cfg.finalReportedSolution,'RiskBalanced'));
fprintf('test_efficiency_cadence passed.\n');
end
