function test_unified_mission_schedule()
%TEST_UNIFIED_MISSION_SCHEDULE No independently stalled threshold components.
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.multiUAVShiyanConfig();
assert(cfg.enableUnifiedMissionDeficit);

th1 = evaluation.currentMonitoringThresholds(1,cfg);
assert(th1.missionStage=="exploration");
assert(abs(th1.missionDeficitEpsilon-1)<1e-12);
assert(all([th1.minimum th1.critical th1.observationLength th1.losRatio]==0));

midGen = round((cfg.missionFormationStartGeneration+ ...
    cfg.missionFormalStartGeneration)/2);
thMid = evaluation.currentMonitoringThresholds(midGen,cfg);
assert(thMid.missionStage=="formation");
assert(thMid.missionDeficitEpsilon>0 && thMid.missionDeficitEpsilon<1);
assert(all([thMid.minimum thMid.critical thMid.observationLength thMid.losRatio]==0));

thFinal = evaluation.currentMonitoringThresholds( ...
    cfg.missionFormalStartGeneration,cfg);
assert(thFinal.missionStage=="formal");
assert(abs(thFinal.missionDeficitEpsilon)<1e-12);
assert(abs(thFinal.minimum-cfg.monitorMinTargetQuality)<1e-12);
assert(abs(thFinal.critical-cfg.monitorCriticalMinQuality)<1e-12);
assert(abs(thFinal.observationLength-cfg.monitorCriticalMinObservationLength)<1e-12);
assert(abs(thFinal.losRatio-cfg.monitorCriticalMinLOSRatio)<1e-12);
fprintf('test_unified_mission_schedule passed.\n');
end
