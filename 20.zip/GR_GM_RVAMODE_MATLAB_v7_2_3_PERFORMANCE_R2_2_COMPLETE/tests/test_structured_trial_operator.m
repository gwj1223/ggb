function test_structured_trial_operator()
rng(12,'twister');
cfg=config.defaultConfig();
cfg.enableStructuredMonitoringEncoding=true;
cfg.populationSize=8;
cfg.numWaypoints=20;
cfg.maxGenerations=5;
cfg.maxClimbAngleDeg=89;
cfg.maxTurnAngleDeg=179;
cfg.segmentRepairMargin=0;
cfg.enableLocalAGLConstraint=false;
problem=data.createDemoProblem(cfg);
problem.structuredMonitoringTargetOrder=core.structuredMonitoringTargetOrder(problem,cfg);
pop=core.initializePopulation(problem,cfg);
pop=evaluation.evaluatePopulation(pop,problem,cfg,1);
context=operators.buildTrialContext(pop,[],cfg,1);
[trial,~,~,~]=operators.generateTrial(1,pop,[],[0.5 0.5 0.5], ...
    [0.8 0.8 0.8],[1 0 0],problem,cfg,1,context);
layout=core.structuredMonitoringLayout(problem,cfg);
assert(numel(trial.structuredGenes)==layout.dimension);
assert(all(trial.structuredGenes>=-1-1e-12 & trial.structuredGenes<=1+1e-12));
assert(numel(trial.genes)==3*cfg.numWaypoints);
assert(isfield(trial,'encodingInfo'));
fprintf('test_structured_trial_operator passed.\n');
end
