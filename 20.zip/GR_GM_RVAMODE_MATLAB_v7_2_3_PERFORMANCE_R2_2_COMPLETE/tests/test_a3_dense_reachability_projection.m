function test_a3_dense_reachability_projection()
%TEST_A3_DENSE_REACHABILITY_PROJECTION Dense ridge must affect A3 feasibility.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig();
cfg.safeClearance=20;
cfg.maxAltitude=200;
cfg.enableLocalAGLConstraint=true;
cfg.realMaximumAGL=100;
cfg.maxClimbAngleDeg=45;
cfg.segmentRepairMargin=0;
cfg.enableDistanceAdaptiveAGLConstraintSampling=true;
cfg.aglConstraintSampleStep_m=10;
cfg.aglConstraintMaxSamplesPerSegment=64;
cfg.missionRepairDenseAltitudeGridStep_m=2;
[xg,yg]=meshgrid(0:1:100,0:1:10);
terrain=zeros(size(xg));
terrain(:,51)=50; % narrow ridge at x=50
problem.gridX=xg; problem.gridY=yg;
problem.terrain=terrain; problem.risk=zeros(size(terrain));
problem.obstacles=zeros(0,4);

% With no interior waypoint the straight Z segment is fixed at 55 m and the
% dense ridge leaves only 5 m AGL. A sparse endpoint-only projector would miss it.
xy=[0 5;100 5];
[zBad,infoBad]=core.projectDenseTerrainReachableProfile( ...
    xy,55,55,75,problem,cfg);
assert(isempty(zBad) && ~infoBad.success);

% An explicit node at the terrain bottleneck gives the chromosome enough
% vertical freedom to clear the ridge while respecting the climb cone.
xy2=[0 5;50 5;100 5];
[z,info]=core.projectDenseTerrainReachableProfile( ...
    xy2,55,55,75,problem,cfg);
assert(info.success && numel(z)==3);
path=[xy2 z];
stats=evaluation.evaluateLocalAGLEnvelope(path,problem,cfg);
assert(stats.lowerViolation<=1e-8 && stats.upperViolation<=1e-8);
seg=diff(path,1,1);
climb=atan2d(abs(seg(:,3)),max(hypot(seg(:,1),seg(:,2)),eps));
assert(all(climb<=cfg.maxClimbAngleDeg+1e-8));
fprintf('test_a3_dense_reachability_projection passed.\n');
end
