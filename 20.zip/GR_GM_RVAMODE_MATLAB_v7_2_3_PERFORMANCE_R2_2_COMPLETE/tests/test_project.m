function test_project
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig(); cfg.populationSize=12; cfg.maxGenerations=3;
cfg.numWaypoints=6; cfg.verboseEvery=1; cfg.saveResults=false;
problem=data.createDemoProblem(cfg); result=core.runGRAHMODE(problem,cfg);
assert(~isempty(result.archive));
assert(numel(result.best.objectives)==5);
assert(size(result.best.path,2)==3);
assert(isfield(result.best,'pathMetrics'));
assert(isfield(result.best,'riskStats'));
assert(isfield(result.best,'energyStats'));
assert(size(result.history,2)==86);
assert(isfield(result.best,'searchMonitorQuality'));
assert(isfield(result,'controllerReachedFinalThresholds'));
assert(isfield(result,'commonHypervolume'));
assert(isfield(result,'bestCommonHypervolume'));
assert(isfield(result,'commonArchive'));
assert(isfield(result,'finalStageOperatorState'));
assert(isfield(result,'reportedSolutionLabel'));
assert(isfield(result,'reportedSolutionSelectionLevel'));
assert(isfield(result.performance,'commonArchiveUpdates'));
assert(isfield(result.performance,'commonHypervolumeEvaluations'));
fprintf('test_project passed.\n');
end
