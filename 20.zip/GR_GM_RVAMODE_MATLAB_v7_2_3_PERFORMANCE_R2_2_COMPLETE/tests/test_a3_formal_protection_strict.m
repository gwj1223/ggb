function test_a3_formal_protection_strict()
%TEST_A3_FORMAL_PROTECTION_STRICT Gen100+ restores strict formal protection.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.multiUAVShiyanConfig();
gen=cfg.missionFormalStartGeneration;

base=localFixture([0.331 repmat(0.80,1,9)]);
trial=localFixture([0.329 repmat(0.80,1,9)]);
p=evaluation.assessMissionProtection(base,trial,cfg,gen);
assert(~p.allowed && strcmp(p.stage,'formal') && strcmp(p.reason,'protected_q'));

base=localFixture(0.80*ones(1,10)); trial=base;
base.monitorStats.observationLength(1)=185;
trial.monitorStats.observationLength(1)=175;
p=evaluation.assessMissionProtection(base,trial,cfg,gen);
assert(~p.allowed && strcmp(p.reason,'protected_observation'));

base=localFixture(0.80*ones(1,10)); trial=base;
base.monitorStats.losRatio(1)=0.46;
trial.monitorStats.losRatio(1)=0.44;
p=evaluation.assessMissionProtection(base,trial,cfg,gen);
assert(~p.allowed && strcmp(p.reason,'protected_los'));

base=localFixture([repmat(0.43,1,6) repmat(0.80,1,4)]);
trial=localFixture([repmat(0.415,1,6) repmat(0.80,1,4)]);
p=evaluation.assessMissionProtection(base,trial,cfg,gen);
assert(~p.allowed && strcmp(p.reason,'protected_critical_q'));

% Omitting generation deliberately retains backward-compatible strict behavior.
p=evaluation.assessMissionProtection( ...
    localFixture([0.331 repmat(0.80,1,9)]), ...
    localFixture([0.329 repmat(0.80,1,9)]),cfg);
assert(~p.allowed && strcmp(p.stage,'formal'));

fprintf('test_a3_formal_protection_strict passed.\n');
end

function ind=localFixture(q)
q=q(:); M=numel(q);
ind.staticCV=0; ind.cv=0; ind.feasible=true;
ind.monitorPerTarget=q;
ind.monitorStats.truePerTarget=q;
ind.monitorStats.searchPerTarget=q;
ind.monitorStats.observationLength=300*ones(M,1);
ind.monitorStats.losRatio=0.90*ones(M,1);
critical=1:min(6,M);
value=mean(q(critical));
ind.monitorStats.criticalQuality=value;
ind.monitorStats.trueCriticalQuality=value;
ind.monitorStats.minimumCriticalObservationLength=300;
ind.monitorStats.minimumCriticalLOSRatio=0.90;
end
