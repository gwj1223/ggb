function test_target_observability_estimator()
root = fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg = config.multiUAVShiyanConfig();
[problem,cfg] = realdata.buildShiyanG1Problem(root,cfg);

obs1 = multiUAV.estimateTargetObservability(problem,cfg);
obs2 = multiUAV.estimateTargetObservability(problem,cfg);
M = size(problem.monitorTargets,1);

assert(numel(obs1.score)==M);
assert(numel(obs1.difficulty)==M);
assert(all(isfinite(obs1.score)) && all(obs1.score>=0 & obs1.score<=1));
assert(all(isfinite(obs1.difficulty)) && ...
    all(obs1.difficulty>=0 & obs1.difficulty<=1));
assert(all(abs(obs1.score+obs1.difficulty-1)<1e-12));
assert(all(obs1.visibleFraction>=0 & obs1.visibleFraction<=1));
assert(all(obs1.validViewFraction>=0 & obs1.validViewFraction<=1));
assert(all(obs1.maxVisibleArcLength_m>=0));
assert(all(obs1.candidateCount== ...
    cfg.multiUAVObservabilityAzimuthSamples* ...
    numel(cfg.multiUAVObservabilityRadiusScales)));
assert(max(abs(obs1.score-obs2.score))<1e-12);
assert(numel(obs1.bestSectorCenterRad)==M);
assert(numel(obs1.bestSectorHalfWidthRad)==M);
assert(numel(obs1.bestVisibleRunCount)==M);
assert(all(isfinite(obs1.bestSectorCenterRad)));
assert(all(obs1.bestSectorHalfWidthRad>=0 & obs1.bestSectorHalfWidthRad<=pi));
assert(all(obs1.bestVisibleRunCount>=0));
assert(strcmp(obs1.method,'dem_los_contiguous_arc_sector_proxy'));
fprintf('test_target_observability_estimator passed.\n');
end
