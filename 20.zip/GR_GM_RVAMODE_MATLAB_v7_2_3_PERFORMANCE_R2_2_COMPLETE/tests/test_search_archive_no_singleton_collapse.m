function test_search_archive_no_singleton_collapse()
%TEST_SEARCH_ARCHIVE_NO_SINGLETON_COLLAPSE No scheduled-feasible path != archive size one.
root=fileparts(fileparts(mfilename('fullpath'))); setupProject(root);
cfg=config.defaultConfig();
cfg.enableUnifiedMissionDeficit=true;
cfg.enableMissionBandSelection=true;
cfg.missionBandMinFraction=0.50;
cfg.missionBandTolerance=1e-10;
cfg.runtimeMissionDeficitEpsilon=0.20;
cfg.populationSize=8;
cfg.archiveSize=20;

T=struct('objectives',zeros(1,5),'cv',0.3,'feasible',false, ...
    'rank',inf,'crowding',0,'staticCV',0,'staticFeasible',true, ...
    'missionScheduleFeasible',false,'formalMissionSatisfied',false, ...
    'missionDeficit',0.5,'missionDeficitEpsilon',0.2,'genes',zeros(1,2));
pop=repmat(T,8,1);
for i=1:8
    pop(i).missionDeficit=0.40+0.01*(i-1);
    pop(i).genes=[i i];
    pop(i).objectives=10*ones(1,5);
end
% Four leader-band members (K=4) with mutually nondominated tradeoffs.
pop(1).objectives=[1 4 4 4 4];
pop(2).objectives=[4 1 4 4 4];
pop(3).objectives=[4 4 1 4 4];
pop(4).objectives=[4 4 4 1 4];
archive=selection.updateArchive([],pop,cfg.archiveSize,cfg,50);
assert(numel(archive)>=2, ...
    'Search archive must preserve multiple mission-band objective leaders.');
assert(all([archive.staticCV]<=cfg.constraintTolerance));
fprintf('test_search_archive_no_singleton_collapse passed.\n');
end
