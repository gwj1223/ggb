function test_structured_boundary_turn_allocation()
cfg=config.defaultConfig();
cfg.enableStructuredMonitoringEncoding=true;
cfg.numWaypoints=20; % demo fixture: 16 arc points + 4 connectors
cfg.maxClimbAngleDeg=89;
cfg.maxTurnAngleDeg=95;
cfg.segmentRepairMargin=0;
cfg.enableLocalAGLConstraint=false;
cfg.structuredTransitMinimumBoundaryConnectors=1;
cfg.structuredTransitMaximumBoundaryConnectors=2;
cfg.structuredTransitMaximumConnectorsPerLeg=2;
cfg.structuredTransitTurnWeight=3.0;
cfg.structuredTransitMandatoryTurnFraction=0.90;
cfg.structuredTransitSevereTurnExtraConnectors=0;
cfg.structuredUseTangentAwareTransit=true;
problem=data.createDemoProblem(cfg);
problem.structuredMonitoringTargetOrder=core.structuredMonitoringTargetOrder(problem,cfg);
layout=core.structuredMonitoringLayout(problem,cfg);
[genes,info]=core.decodeStructuredMonitoringGenes(zeros(1,layout.dimension),problem,cfg);
assert(numel(genes)==3*cfg.numWaypoints,'Decoded phenotype dimension changed unexpectedly.');
assert(info.connectorBudget==4,'Demo fixture connector budget must remain 4.');
assert(sum(info.connectorCount)==4,'Selected connector topology must spend the exact fixed budget.');
assert(info.connectorCount(1)>=1,'Start boundary transit must keep at least one connector.');
assert(info.connectorCount(end)>=1,'Goal boundary transit must keep at least one connector.');
assert(numel(info.legTurnDemandDeg)==layout.targetCount+1,'legTurnDemandDeg diagnostics schema must contain one value per transit leg.');
assert(all(isfinite(info.legTurnDemandDeg)),'legTurnDemandDeg diagnostics must be finite.');
fprintf('test_structured_boundary_turn_allocation passed.\n');
end
