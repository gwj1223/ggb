# GR-GM-RVAMODE-VI v7.0.5.4 — Dense Reachability Verification Fix

## Root cause

`core.projectDenseTerrainReachableProfile` used `maxAGL` for two different
concepts:

1. the configured formal upper AGL bound (`cfg.realMaximumAGL`), and
2. the observed maximum AGL statistic during exact verification.

The verification block executed `maxAGL=-Inf` before constructing the upper
AGL limit. Consequently `upperLimit=maxAGL-margin` became `-Inf`, and every
finite AGL sample was rejected even when the dynamic-programming projection
had found a physically feasible profile.

This exactly explains the v7.0.5.3 regression where the no-interior-node ridge
case was correctly rejected, but the same ridge with an explicit waypoint at
the bottleneck was also incorrectly rejected at line 34 of
`test_a3_dense_reachability_projection`.

## Fix

The projector now keeps two independent variables:

- `allowedMaxAGL` — immutable configured upper AGL bound used by all feasibility
  inequalities and final verification;
- `observedMaxAGL` — diagnostic accumulator used only for `info.maximumAGL`.

`observedMinAGL` is used analogously for the lower diagnostic.

## Unchanged formal contract

- five objectives;
- population 96;
- 220 generations;
- Qmin 0.33;
- Qcritical 0.42;
- critical observation 180 m;
- critical LOS 0.45;
- Shiyan AGL 60–320 m;
- max climb 22 degrees;
- max turn 95 degrees;
- mission formation starts at Gen25;
- formal stage starts at Gen100.

No A1, A6, allocation, Mission Deficit, sampling-policy, A3 geometry-pool,
acceptance, or replacement semantics are changed.
