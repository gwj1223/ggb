# GR-GM-RVAMODE-VI v7.0.2 — A3 Mission-Progress Fix

This release is a focused runtime correction built on v7.0.1.

## What the v7.0.1 real-G1 log proved

- the formal-evidence early-stopping gate works: UAV-1 continued beyond Gen 130;
- Unified A3 was invoked at every configured checkpoint and consumed its bounded 12 evaluations;
- nevertheless every checkpoint reported `selected=0` / no retained repair;
- ordinary GR-GM-RVAMODE search slowly reduced D_M, while A3 itself contributed no retained mission carrier.

The root cause was structural: A3 still required the population-wide Chebyshev-dominant Mission Deficit to decrease immediately. When another target remained the worst bottleneck, a useful repair of the selected target could be rejected even though it was genuine cumulative mission progress. If appended for Pareto environmental selection, tied-D progress could also be discarded before it accumulated.

## v7.0.2 A3 contract

A3 remains the only mission-recovery mechanism. No Target Memory, Mission Carrier Restore, Persistent Repair, Emergency Repair, or sixth objective is reintroduced.

A trial may replace its own mission-infeasible base only when all of the following hold:

1. static flight feasibility is preserved;
2. global Mission Deficit D_M does not regress (numerical tolerance only);
3. every already-formal mission component remains formal;
4. every target already above Qmin remains above Qmin;
5. every already-satisfied Critical observation/LOS condition remains satisfied;
6. the selected target's normalized mission-urgency score improves by at least `missionRepairMinTargetDeficitGain`.

This makes A3 a protected deterministic repair of a current individual rather than an external candidate that must immediately win a five-objective Pareto competition. The next normal generation still uses the standard GR-GM-RVAMODE environmental selection.

## Diagnostics

Each A3 checkpoint now prints:

```text
A3 eval=12 replace=R eligible=E | D=before->after | formal=a->b |
gain=... | rej[s/i/g/p/n]=[static invalid global protection noGain] | targets=[...]
```

This distinguishes geometry/static failures from global-regression rejection, protection rejection, and no-target-gain rejection.

## Unchanged formal experiment settings

- five objectives;
- population = 96;
- max generations = 220;
- Qmin = 0.33;
- Qcritical = 0.42;
- Critical observation length = 180 m;
- Critical LOS = 0.45;
- AGL = 60–320 m;
- mission formation starts at Gen 25;
- formal mission stage starts at Gen 100;
- A1 and A6 unchanged;
- observability-aware allocation unchanged;
- temporal collision scheduling unchanged.

## Validation sequence

1. `run_all_tests`
2. `main`
3. Inspect the first A3 checkpoints (Gen 25, 30, 35...).
4. Do not run Gate15/30-seed batches until at least some checkpoints show `eligible>0` and preferably `replace>0`, or the rejection histogram clearly identifies the remaining bottleneck.
