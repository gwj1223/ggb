function setupProject(projectRoot)
if nargin < 1 || isempty(projectRoot)
    projectRoot = fileparts(mfilename('fullpath'));
end
addpath(projectRoot);
addpath(fullfile(projectRoot,'src'));
addpath(fullfile(projectRoot,'examples'));
addpath(fullfile(projectRoot,'tests'));
end
