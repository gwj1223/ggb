Shiyan-G1 raw-data note

The project is self-contained through data_real/processed/Shiyan_G1_DEM.mat and the cropped GeoTIFF.
The original user-supplied tile was ASTGTMV003_N32E110_dem.tif inside ASTGTMV003_N32E110.zip.
To regenerate the processed file from the full tile, place that GeoTIFF in this folder and run prepare_shiyan_g1_data.m.

Scientific interpretation:
- The DEM is real GDEMV3 terrain data.
- The topographic susceptibility/risk layer is derived from DEM slope, roughness and curvature.
- The four monitoring targets are reproducible scenario-defined terrain-feature targets. They are not claimed to be surveyed landslide or rockfall coordinates.
