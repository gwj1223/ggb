clear; clc; close all;
%MAIN Default entry point: 3-UAV cooperative Shiyan-G1 monitoring.
%
% v7.0.0 uses the cooperative Shiyan-G1 experiment as the DEFAULT entry.
% The original single-UAV entry
% is preserved as main_single_uav.m.

projectRoot = fileparts(mfilename('fullpath'));
setupProject(projectRoot);

cfg = config.multiUAVShiyanConfig();
[problem,cfg] = realdata.buildShiyanG1Problem(projectRoot,cfg);

fprintf('\n============================================================\n');
fprintf(' DEFAULT ENTRY: %d-UAV COOPERATIVE MONITORING\n',cfg.multiUAVCount);
fprintf(' Scene: %s | Targets: %d | Critical: %d\n', ...
    problem.sceneId,size(problem.monitorTargets,1), ...
    numel(cfg.criticalTargetIndices));
fprintf('============================================================\n');

fleetResult = multiUAV.runCooperativeMonitoring(problem,cfg);
visualization.plotMultiUAVResult(problem,fleetResult,cfg);
visualization.plotFleetSeparation(fleetResult,cfg);

if cfg.saveResults
    out = multiUAV.saveFleetRun(problem,fleetResult,cfg,projectRoot);
    fprintf('Multi-UAV results saved to   : %s\n',out);
    fprintf('Fleet MAT file                : %s\n', ...
        fullfile(out,'fleet_result.mat'));
end
