# v7.1.1 Protection Diagnostics + Formation Hysteresis

## 1. Why this version exists

The first real v7.1.0 Shiyan UAV-1 run showed that Mission-Band selection and
Dense-3D A3 were behaving as intended:

- static feasibility reached 96/96;
- the Search Archive remained multi-member when scheduled mission feasibility was zero;
- A3 Dense-3D precheck repeatedly passed many geometries;
- full A3 evaluations had zero static clearance/climb/turn rejection;
- A3 base target diversity increased from one to multiple bottlenecks.

The remaining rejection pattern was dominated by A3 protection:

`rej[s/i/g/p/n] = [0 0 0 9 0]`, later `[0 0 3 6 0]`.

This means the candidate was physically flyable and often mission-useful, but
was rejected because some previously satisfied mission condition crossed its
formal line. In a coupled multi-target waypoint problem, treating a condition
that has only barely crossed a threshold as permanently frozen can block useful
rearrangements.

## 2. What is NOT changed

v7.1.1 does not change:

- Mission-Band hierarchical selection;
- Search Archive / Formal Archive semantics;
- Dense-3D reachability or A3 geometry generation;
- Mission Deficit formula or weights;
- global A3 Mission Deficit non-regression;
- target-gain requirement;
- A1, A6, five objectives, task allocation, or temporal deconfliction;
- any formal monitoring or physical threshold.

Formal Shiyan requirements remain:

- Qmin = 0.33;
- Critical aggregate Q = 0.42;
- Critical observation length = 180 m;
- Critical LOS = 0.45;
- AGL = 60--320 m;
- climb <= 22 deg;
- turn <= 95 deg;
- formation starts Gen25;
- formal stage starts Gen100.

## 3. Stage-aware mission protection

A new canonical helper is introduced:

`evaluation.assessMissionProtection(base, trial, cfg, generation)`.

### Formation stage (Gen25--99)

A metric becomes hard-protected only after the base clears the formal line by
an entry margin. Once protected, the trial may consume that margin but may not
cross the original formal threshold.

Shiyan entry margins are:

- per-target Q: +0.02, so protection entry is 0.35 and floor remains 0.33;
- Critical aggregate Q: +0.02, entry 0.44 and floor 0.42;
- Critical observation: +20 m, entry 200 m and floor 180 m;
- Critical LOS: +0.05, entry 0.50 and floor 0.45.

These margins are NOT alternative mission thresholds. They only determine
when a currently achieved condition is stable enough to freeze during local A3
repair.

The historical strict zero-component protection is disabled during formation,
because otherwise it would immediately re-freeze the same just-satisfied raw
metrics and nullify hysteresis.

### Formal stage (Gen100+)

The historical strict policy is restored:

- any base Q condition already at or above 0.33 cannot cross below 0.33;
- any base Critical aggregate Q already at or above 0.42 cannot cross below 0.42;
- any base Critical observation already at or above 180 m cannot cross below 180 m;
- any base Critical LOS already at or above 0.45 cannot cross below 0.45;
- the strict zero-component guard is active as a final consistency backstop.

## 4. Global Mission Deficit remains externally monotone

The acceptance sequence remains:

1. static feasible;
2. valid mission evaluation;
3. `D_trial <= D_base + 1e-10`;
4. stage-aware mission protection;
5. selected-target gain >= 1e-3;
6. protected base-to-trial replacement.

Therefore v7.1.1 is not a non-monotone A3. It only adds formation-stage
plasticity inside the existing global-D safety envelope.

## 5. Protection diagnostics

The aggregate rejection counter `rejectProtection` is preserved for backward
compatibility and is split into:

- `rejectProtectionComponent`;
- `rejectProtectionQ`;
- `rejectProtectionCriticalQ`;
- `rejectProtectionObservation`;
- `rejectProtectionLOS`.

A3 also records the worst protection violation:

- stage;
- condition;
- target/component index;
- base value;
- trial value;
- formal threshold;
- protection-entry threshold;
- violation gap.

Runtime logging now prints, for example:

`protect[comp/Q/cQ/obs/LOS]=[0 4 0 2 0]`

and one `protectWorst` line when protection rejections occur.

## 6. Diagnostic-only cleanup

Two misleading diagnostics are corrected without changing search behavior:

- Search Archive HV is computed on the curated Search Archive directly, so
  mission-band leaders with scheduled `cv>0` no longer make Search HV NaN.
  Formal HV still uses strict feasibility filtering.
- If an A3 event has no static rejection, AGL rejection diagnostics display
  `AGLrej=[n/a]` instead of the neutral initialization `[Inf -Inf]`.

## 7. Tests added

Three new tests are registered:

- `test_a3_formation_protection_hysteresis`;
- `test_a3_formal_protection_strict`;
- `test_search_hv_archive_semantics`.

The canonical A3 stats-schema test is extended for the protection split.
Total registered tests: 91.

## 8. What to inspect in the next real run

The key questions are now:

1. Does `protect[...]` fall substantially below the v7.1.0 aggregate `p` rate?
2. Do `eligible` and `replace` recur after Gen25 rather than appearing only once?
3. Does `D[min]` break below the previous 0.90477 plateau?
4. If protection falls but `g` becomes dominant, is the next bottleneck global
   D non-regression? Only then should a later compound/internal-nonmonotone A3
   be considered.

Do not change formal thresholds based on this experiment.
