# GR-GM-RVAMODE-VI v7.2.3 — 3D-Feasibility-First Structured Decoder

Complete Shiyan-G1 multi-UAV geological-monitoring project upgraded from the canonical v7.2.2 adaptive-connector package.

## Why v7.2.3 exists

The v7.2.2 UAV-1 focused run showed a structural decoder barrier: for many generations every individual reported `decode[dense/ok]=[0/0]/96` and `fail[reach/turn/other]=[96 0 0]`. The optimizer was reducing static CV, but tangent-aware XY connector placement never opened a Dense-3D feasible carrier.

v7.2.3 therefore changes the decoder priority rather than relaxing constraints or changing the optimizer.

```text
51D semantic genes
  -> observation arcs
  -> adaptive connector topology candidates (fixed total budget)
  -> chord + semantic-bias XY
  -> Dense-3D reachability screening
  -> Dense-feasible carrier
  -> progressive tangent turn refinement
  -> 42 internal XYZ waypoints / 126D phenotype
```

Priority: `3D reachability > turn feasibility > turn margin > path quality`.

## Scientific contract kept unchanged

- 51D semantic genotype for the normal 10-target subproblem.
- 42 internal XYZ waypoints / 126D phenotype.
- Population 96; maximum generations 220; five objectives.
- Qmin 0.33; Critical Q 0.42; Critical observation 180 m; Critical LOS 0.45.
- AGL 60–320 m; max climb 22 deg; max turn 95 deg.
- Mission formation starts Gen25; formal stage starts Gen100.
- Mission Deficit remains a feasibility/ranking quantity, not a sixth objective.
- A1, Mission Band, ONE A3 mission repair, A6, allocation semantics and final Dense verification remain unchanged.

## 1. Run the full test suite

```matlab
restoredefaultpath;
clear functions;
clear classes;
rehash toolboxcache;
clc;
close all;
setupProject(pwd);
run_all_tests
```

This release registers **104 tests**, including the two v7.2.3 topology/source-contract tests. This build environment does not contain MATLAB/Octave, so runtime execution must be completed locally.

## 2. Run the decoder gate before evolution

```matlab
r = run_v723_decoder_gate(192,1);
```

First acceptance condition:

```text
DenseOK > 0
```

Do **not** spend 220 generations on UAV-1 while this gate remains zero. The gate prints the dominant failed Dense segments so the next correction can be leg-aware rather than parameter guessing.

## 3. Focused verification

```matlab
run_uav1_only_v723
run_v723_decoder_gate(192,2);
run_uav2_only_v723
```

Expected progression for UAV-1 is:

```text
DenseOK > 0
  -> DecodeOK > 0
  -> static > 0
  -> finite Mission Deficit
  -> D_M -> 0
  -> formal > 0
```

UAV-2 is the regression case: the former final-leg turn fix must remain valid.

## 4. Only then run the complete 3-UAV experiment

```matlab
main
```

For the algorithm rationale and paper-facing organization, see `ALGORITHM_OVERVIEW_V7_2_3_CN.md`. For this release change set, see `RELEASE_NOTES_V7_2_3_CN.md`.


## Performance R2.1 hotfix
If using the performance-cached build, see `PERFORMANCE_R2_1_HOTFIX_CN.md`. R2.1 removes the MATLAB MESHGRID/NDGRID warning flood for paired LOS terrain queries while preserving the interpolation and feasibility contracts.
