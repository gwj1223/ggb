%RUN_MULTI_UAV_30_SEEDS_V700 Formal paired 30-seed v7.0.0 experiment.
run_multi_uav_batch_v700((1:30)','30seeds_v700');
