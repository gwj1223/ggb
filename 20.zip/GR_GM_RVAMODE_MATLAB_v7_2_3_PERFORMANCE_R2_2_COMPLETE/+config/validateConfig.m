function validateConfig(cfg,problem)
%VALIDATECONFIG Defensive validation for experiment-critical configuration.
%
% This function does not tune or modify any parameter.  It only fails early
% on inconsistent settings that would otherwise produce partially initialized
% populations, invalid donor selection, or misleading monitoring results.

requiredScalarPositive = { ...
    'populationSize','maxGenerations','numWaypoints','archiveSize', ...
    'segmentSamples','monitorCoverageSamples','monitorRequiredObservationLength', ...
    'safeClearance','maxAltitude','maxEnergy'};
for k = 1:numel(requiredScalarPositive)
    name = requiredScalarPositive{k};
    if ~isfield(cfg,name) || ~isscalar(cfg.(name)) || ...
            ~isfinite(cfg.(name)) || cfg.(name) <= 0
        error('config:InvalidValue','cfg.%s must be a finite positive scalar.',name);
    end
end

if cfg.populationSize < 4
    error('config:PopulationTooSmall', ...
        'populationSize must be at least 4 for distinct DE donors.');
end
if cfg.segmentSamples < 2 || cfg.monitorCoverageSamples < 2
    error('config:SamplingTooSmall', ...
        'segmentSamples and monitorCoverageSamples must be at least 2.');
end
if isfield(cfg,'monitorLineOfSightSamples') && ...
        cfg.enableLineOfSight && cfg.monitorLineOfSightSamples < 3
    error('config:LOSSamplingTooSmall', ...
        'monitorLineOfSightSamples must be at least 3 when LOS is enabled.');
end

fractions = [cfg.goalBiasInitFraction cfg.corridorInitFraction ...
    cfg.monitorGuidedInitFraction cfg.randomInitFraction];
if any(~isfinite(fractions)) || any(fractions < 0) || ...
        abs(sum(fractions)-1) > 1e-10
    error('config:InitializationFractions', ...
        'The four initialization fractions must be nonnegative and sum to 1.');
end

if numel(cfg.monitorObservationRangeFactor) ~= 2 || ...
        any(~isfinite(cfg.monitorObservationRangeFactor)) || ...
        cfg.monitorObservationRangeFactor(1) <= 0 || ...
        cfg.monitorObservationRangeFactor(2) <= cfg.monitorObservationRangeFactor(1)
    error('config:ObservationRangeFactor', ...
        'monitorObservationRangeFactor must be [lower upper] with 0<lower<upper.');
end

objectiveWeights = [cfg.riskMeanWeight cfg.riskTailWeight];
if any(objectiveWeights < 0) || sum(objectiveWeights) <= 0
    error('config:RiskWeights','Risk objective weights must be nonnegative with positive sum.');
end
monitorExponents = [cfg.monitorRangeExponent cfg.monitorHeightExponent ...
    cfg.monitorLOSExponent cfg.monitorDurationExponent];
if any(monitorExponents < 0) || sum(monitorExponents) <= 0
    error('config:MonitoringExponents', ...
        'Monitoring component exponents must be nonnegative with positive sum.');
end

if nargin < 2 || isempty(problem)
    return;
end
if ~isfield(problem,'monitorTargets') || size(problem.monitorTargets,2) < 5
    error('config:MonitoringTargets', ...
        'problem.monitorTargets must be an M-by-5 (or wider) matrix.');
end
M = size(problem.monitorTargets,1);
critical = cfg.criticalTargetIndices(:);
if any(critical < 1) || any(critical > M) || any(critical ~= round(critical))
    error('config:CriticalTargetIndices', ...
        'criticalTargetIndices must reference existing monitoring targets.');
end
if numel(unique(critical)) ~= numel(critical)
    error('config:CriticalTargetIndices', ...
        'criticalTargetIndices must not contain duplicates.');
end

if isfield(cfg,'enableStructuredMonitoringEncoding') && ...
        cfg.enableStructuredMonitoringEncoding
    ordinaryCount=max(2,round(localCfg(cfg,'monitorGuidedArcPoints',3)));
    criticalCount=max(3,round(localCfg(cfg,'multiUAVCriticalMonitorGuidedArcPoints',5)));
    arcPoints=(M-numel(critical))*ordinaryCount+numel(critical)*criticalCount;
    if arcPoints>cfg.numWaypoints
        error('config:StructuredWaypointBudget', ...
            'Structured observation arcs require %d waypoints but cfg.numWaypoints=%d.', ...
            arcPoints,cfg.numWaypoints);
    end
    connectorBudget=cfg.numWaypoints-arcPoints;
    boundaryMin=max(0,round(localCfg(cfg,'structuredTransitMinimumBoundaryConnectors',0)));
    boundaryMax=localCfg(cfg,'structuredTransitMaximumBoundaryConnectors',inf);
    perLegMax=localCfg(cfg,'structuredTransitMaximumConnectorsPerLeg',inf);
    if connectorBudget < 2*boundaryMin
        error('config:StructuredConnectorBudget', ...
            'Structured boundary connectors require %d nodes but only %d are available.', ...
            2*boundaryMin,connectorBudget);
    end
    if isfinite(boundaryMax) && boundaryMax<boundaryMin
        error('config:StructuredBoundaryConnectorLimit', ...
            'structuredTransitMaximumBoundaryConnectors must be >= the boundary minimum.');
    end
    if isfinite(perLegMax)
        if perLegMax<1 || abs(perLegMax-round(perLegMax))>eps
            error('config:StructuredConnectorLimit', ...
                'structuredTransitMaximumConnectorsPerLeg must be a positive integer or Inf.');
        end
        if connectorBudget>(M+1)*round(perLegMax)
            error('config:StructuredConnectorCapacity', ...
                'Connector budget %d exceeds the per-leg capacity %d.', ...
                connectorBudget,(M+1)*round(perLegMax));
        end
    end
    topologyLimit=localCfg(cfg,'structuredTransitTopologyCandidateLimit',6);
    if ~isscalar(topologyLimit) || ~isfinite(topologyLimit) || topologyLimit<1 || ...
            abs(topologyLimit-round(topologyLimit))>eps
        error('config:StructuredTopologyCandidateLimit', ...
            'structuredTransitTopologyCandidateLimit must be a positive integer.');
    end
    blendSchedule=localCfg(cfg,'structuredTransitTangentBlendSchedule',[0.25 0.50 0.75 1.00]);
    if isempty(blendSchedule) || any(~isfinite(blendSchedule(:))) || ...
            any(blendSchedule(:)<=0) || any(blendSchedule(:)>1)
        error('config:StructuredTangentBlendSchedule', ...
            'structuredTransitTangentBlendSchedule must contain finite values in (0,1].');
    end
    boolNames={'enableStructuredSegmentTerrainCache', ...
        'enableTerrainInterpolatorCache','enableStructuredPerformanceProfiling', ...
        'enableDenseProjectionVectorizedDP'};
    for bb=1:numel(boolNames)
        vv=localCfg(cfg,boolNames{bb},true);
        if ~isscalar(vv) || ~(islogical(vv) || (isnumeric(vv) && isfinite(vv)))
            error('config:StructuredPerformanceSwitch', ...
                '%s must be a scalar logical/numeric flag.',boolNames{bb});
        end
    end
    bounds=localCfg(cfg,'structuredObservationLengthFactorBounds',[0.65 1.50]);
    if numel(bounds)~=2 || any(~isfinite(bounds)) || bounds(1)<=0 || bounds(2)<bounds(1)
        error('config:StructuredObservationLengthBounds', ...
            'structuredObservationLengthFactorBounds must be finite [low high].');
    end
end

if ~isfield(problem,'terrain') || isempty(problem.terrain) || ...
        any(~isfinite(problem.terrain(:)))
    error('config:Terrain','problem.terrain must contain finite DEM elevations.');
end
if cfg.maxAltitude <= min(problem.terrain(:))
    error('config:AltitudeCeiling', ...
        'maxAltitude must exceed the minimum terrain elevation.');
end
end

function value=localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value=cfg.(name); else, value=defaultValue; end
end
