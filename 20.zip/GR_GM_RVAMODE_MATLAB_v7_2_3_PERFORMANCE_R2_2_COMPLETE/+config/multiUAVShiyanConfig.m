function cfg = multiUAVShiyanConfig()
%MULTIUAVSHIYANCONFIG v7.2.2 Shiyan-G1 structured-monitoring settings.
%
% v7.2.2 keeps the validated v7.1.1 Mission-Band/protection core and all
% formal thresholds, but replaces direct 126D XYZ evolution with a 51D
% structured monitoring genotype for the normal 10-target UAV subproblem.
% The execution path is:
%   static DEM/LOS knowledge -> cooperative allocation -> A1 guided init ->
%   static-first + unified mission-deficit search -> one bounded A3 repair ->
%   A6 representative selection -> dense AGL verification -> fleet schedule.
%
% No historical chromosome is stored/restored. Formal mission thresholds and
% all physical constraints are unchanged.

cfg = config.shiyanG1Config();

cfg.implementationVersion = 'v7.2.3-3d-feasibility-first-decoder-performance-r2.2';
cfg.multiUAVEnabled = true;
cfg.multiUAVCount = 3;
cfg.outputRoot = 'output_shiyan_g1_30r_3uav_v723';

%% Upper layer: observability-aware cooperative allocation
cfg.multiUAVAllocationDistanceWeight = 0.85;
cfg.multiUAVAllocationLoadWeight = 0.45;
cfg.multiUAVAllocationCountWeight = 0.15;
cfg.multiUAVAllocationIterations = 30;
cfg.multiUAVAllocationCompactnessWeight = 0.25;
cfg.multiUAVAllocationRouteWeight = 0.85;
cfg.multiUAVAllocationMaxRouteWeight = 1.20;
cfg.multiUAVAllocationRouteSpreadWeight = 0.35;
cfg.multiUAVAllocationLoadBalanceWeight = 0.25;
cfg.multiUAVAllocationVerticalWeight = 2.50;
cfg.multiUAVAllocationGoalBias = 0.08;
cfg.multiUAVAllocationTwoOptPasses = 2;
cfg.multiUAVAllocationSwapPasses = 35;

% Static Monitoring Knowledge Base (DEM/LOS only; never an individual memory).
cfg.enableObservabilityAwareAllocation = true;
cfg.multiUAVObservabilityAzimuthSamples = 16;
cfg.multiUAVObservabilityRadiusScales = [0.85 1.00 1.15];
cfg.multiUAVObservabilityLOSRaySamples = 12;
cfg.multiUAVObservabilityVisibleWeight = 0.60;
cfg.multiUAVObservabilityArcWeight = 0.40;
cfg.multiUAVObservabilityDifficultyWeight = 0.55;
cfg.multiUAVAllocationRiskBalanceWeight = 0.20;
cfg.multiUAVAllocationObservabilityBalanceWeight = 0.45;
cfg.multiUAVAllocationCriticalObservabilityBalanceWeight = 0.35;
cfg.multiUAVAllocationWorstObservabilitySpreadWeight = 0.25;

%% Shared geometry used by A1 and the single A3 repair
cfg.enableObservabilityGuidedMonitoringArcs = true;
cfg.monitoringArcObservabilityBlendOrdinary = 0.55;
cfg.monitoringArcObservabilityBlendCritical = 0.90;
cfg.monitoringArcVariantSpanFraction = 0.70;
cfg.monitoringArcVariantMaxOffsetDeg = 65;
cfg.monitoringArcSectorUseFraction = 0.82;
cfg.monitoringArcMinimumHalfAngleDeg = 22;
cfg.monitoringArcRadiusScaleBounds = [0.75 1.25];

%% Per-UAV search dimensionality and A1 initialization
cfg.multiUAVWaypointsPerTarget = 3;
cfg.multiUAVWaypointBuffer = 12;
cfg.multiUAVMinWaypoints = 30;
cfg.multiUAVMaxWaypoints = 72;
cfg.multiUAVMonitorGuidedArcPoints = 3;
cfg.multiUAVCriticalMonitorGuidedArcPoints = 5;
cfg.multiUAVCriticalMonitorGuidedViewAngleDeg = 46;
cfg.monitorGuidedExactOrderMaxTargets = 6;

%% v7.2.3 structured monitoring chromosome
% The evolutionary genotype is 5*M+1 normalized semantic variables. For the
% 10-target UAV subproblem this is 51D instead of 126 free XYZ coordinates.
% The decoder still emits exactly cfg.numWaypoints XYZ points, so all formal
% evaluators, constraints, objectives, archives and fleet reporting are unchanged.
cfg.enableStructuredMonitoringEncoding = true;
cfg.structuredObservationLengthFactorBounds = [0.65 1.50];
cfg.structuredVisibleArcUseFraction = 0.90;
cfg.structuredVisibleSectorUseFraction = 0.92;
cfg.structuredObservationMaxHalfAngleDeg = 80;
cfg.structuredObservationHeightSigmaFraction = 0.60;
cfg.structuredObservationAGLMargin_m = 2;
cfg.structuredTransitMaxOffsetFraction = 0.18;
cfg.structuredTransitMaxOffset_m = 300;
cfg.structuredTransitDifficultySamples = 7;
cfg.structuredTransitReliefWeight = 1.5;
cfg.structuredTransitBiasFallbackScales = [1.0 0.5 0.0];
% v7.2.3 keeps the 42-waypoint phenotype and fixed eight-node connector
% budget. The v7.2.2 0/1/2 adaptive connector allocation remains the primary
% topology, while a small set of budget-preserving alternatives is screened
% by Dense-3D reachability before tangent turn refinement. Boundary legs retain
% at least one connector.
cfg.structuredTransitMinimumBoundaryConnectors = 1;
cfg.structuredTransitMaximumBoundaryConnectors = 2;
cfg.structuredTransitMaximumConnectorsPerLeg = 2;
cfg.structuredTransitTurnWeight = 3.0;
cfg.structuredTransitMandatoryTurnFraction = 0.90;
cfg.structuredTransitSevereTurnExtraConnectors = 0;
cfg.structuredTransitTangentHandleFraction = 0.32;
cfg.structuredTransitTangentHandleMaxFraction = 0.495;
cfg.structuredUseTangentAwareTransit = true;
% v7.2.3: Dense feasibility is evaluated before tangent smoothing.
cfg.structuredTransitTopologyCandidateLimit = 6;
cfg.structuredTransitTangentBlendSchedule = [0.25 0.50 0.75 1.00];
% Performance R2 reuses identical dense segment samples and the immutable
% Shiyan DEM interpolator. These switches do not change any formal threshold.
cfg.enableStructuredSegmentTerrainCache = true;
cfg.enableTerrainInterpolatorCache = true;
cfg.enableStructuredPerformanceProfiling = true;
cfg.enableDenseProjectionVectorizedDP = true;
% Legacy final-stage XYZ neighbourhoods would desynchronise structuredGenes
% from the decoded phenotype. Keep all evolutionary writes in semantic space.
cfg.structuredDisableLegacyXYZLocalSearch = true;
cfg.structuredEncodingPrecheckTurn = true;
cfg.structuredGeneNoiseScale = 0.05;
% Semantic A3 moves only the selected target's four genes.
cfg.structuredA3RadiusGeneStep = 0.28;
cfg.structuredA3SectorGeneStep = 0.38;
cfg.structuredA3ArcGeneStep = 0.32;
cfg.structuredA3HeightBlendToDesired = 0.50;

%% Unified mission feasibility: one epsilon schedule, not four independent ramps
cfg.enableUnifiedMissionDeficit = true;
cfg.enableFeasibilityFeedbackThreshold = false;
cfg.enableSnapFinalThreshold = false;
cfg.monitorComponentwiseThresholdUpdate = false;

% G1-24 exploration; G25-99 mission formation; G100+ formal feasibility.
cfg.missionFormationStartGeneration = 25;
cfg.missionFormalStartGeneration = 100;
cfg.missionDeficitInitialEpsilon = 1.00;
cfg.missionDeficitScheduleTolerance = 1e-12;
cfg.missionDeficitComponentTolerance = 1e-12;
cfg.missionStaticViolationTierOffset = 1.0;

% D_M components: [Qmin, Qcritical, Critical observation, Critical LOS].
% The worst component dominates; weights only break/shape near ties.
cfg.unifiedMissionDeficitWeights = [0.40 0.15 0.30 0.15];
cfg.missionDeficitAverageBlend = 0.15;
cfg.missionQualityWorstWeight = 0.85;
cfg.missionGeometryWorstWeight = 0.90;

%% v7.1.0 mission-band hierarchical search selection
% Formal/scheduled epsilon is NOT changed. When it contains too few paths,
% keep at least 25% of NP among the best static-feasible D_M values active for
% five-objective Pareto/reference-vector search.
cfg.enableMissionBandSelection = true;
cfg.missionBandMinFraction = 0.25;
cfg.missionBandTolerance = 1e-10;

%% A3: exactly one bounded mission-aware corridor repair
cfg.enableUnifiedMissionRepair = true;
cfg.unifiedMissionRepairOwnsMissionRecovery = true;
cfg.missionRepairStartGeneration = cfg.missionFormationStartGeneration;
cfg.missionRepairInterval = 5;
cfg.missionRepairBaseCount = 4;
cfg.missionRepairVariants = 3; % full evaluations per base after cheap screening
cfg.missionRepairGeometryPoolSize = 9;
cfg.missionRepairDirectionVariants = 3;
cfg.missionRepairRadiusFactors = [0.85 1.00 1.15];
cfg.missionRepairMaxEvaluationsPerEvent = 12;
% v7.0.2+ target-progress contract. Global D_M is non-regressing, but a
% local repair may be retained when the selected target improves even if a
% different target/component still ties the global Chebyshev bottleneck.
cfg.missionRepairMinTargetDeficitGain = 1e-3;
cfg.missionRepairGlobalNonRegressionTolerance = 1e-10;
cfg.missionRepairDesiredFormalCarriers = 3;
cfg.missionRepairTargetWeights = [1.00 0.35 1.30 0.80];
% v7.1.0: diversify A3 bases before geometry generation. This does not relax
% any A3 acceptance guard and does not introduce target/chromosome memory.
cfg.missionRepairDiversifyBases = true;
cfg.missionRepairDistinctTargetsFirst = true;

% v7.1.1: formation-stage mission protection hysteresis. These are NOT
% relaxed formal thresholds. A metric is frozen only after the base clears
% its formal threshold by the entry margin; once frozen, the trial may consume
% the margin but may not cross the original formal threshold. Gen100+ restores
% strict historical protection.
cfg.enableFormationMissionProtectionHysteresis = true;
cfg.missionProtectionQMargin = 0.02;
cfg.missionProtectionCriticalQMargin = 0.02;
cfg.missionProtectionObservationMargin_m = 20;
cfg.missionProtectionLOSMargin = 0.05;

% Local geometry of the single repair. These are not separate repair modules.
cfg.missionRepairOrdinaryArcPoints = 3;
cfg.missionRepairCriticalArcPoints = 5;
cfg.missionRepairOrdinaryHalfAngleDeg = 32;
cfg.missionRepairCriticalHalfAngleDeg = 46;
cfg.missionRepairRadiusMultiplier = 1.00;
% v7.0.3: preserve the central observation arc but use two C1-like
% Bezier transition shoulders on each side. This reduces sharp route-to-arc
% junctions without relaxing any static flight constraint.
cfg.missionRepairTransitionPointsPerSide = 2;
% v7.0.5: adaptive local block and dense straight-segment terrain reachability.
% Geometry is screened before full objective evaluation; no infeasible Z fallback.
cfg.missionRepairMaxBlockPoints = 13;
cfg.missionRepairUseStaticSafeAltitudeProfile = true; % retained compatibility flag
cfg.missionRepairUseDenseTerrainReachability = true;
cfg.missionRepairDenseAltitudeGridStep_m = 2.0;
cfg.missionRepairPrecheckTurn = true;

% Strategy-3 DE remains local differential search only. Full observation-arc
% topological changes are owned exclusively by unifiedMissionRepair.
cfg.enableDEObservationArcJump = false;
cfg.monitorEmergencyStrategyBlend = 0;

% Pre-formal local search is disabled. From the formal stage onward local
% search is used only for mission-feasible cost refinement.
cfg.localSearchStartGeneration = cfg.missionFormalStartGeneration;

%% Hard terrain-envelope consistency
cfg.enableDistanceAdaptiveAGLConstraintSampling = true;
cfg.aglConstraintSampleStep_m = 15.0;
cfg.aglConstraintMaxSamplesPerSegment = 96;

%% Reproducible fleet decomposition
cfg.multiUAVSeedStride = 1009;

%% Temporal coordination / separation
cfg.multiUAVCruiseSpeed = 12.0;
cfg.multiUAVSeparationTimeStep = 2.0;
cfg.multiUAVSafeSeparation = 80.0;
cfg.multiUAVNearSeparation = 120.0;
cfg.multiUAVMinimumLaunchSpacing = 10.0;
cfg.multiUAVLaunchDelayStep = 10.0;
cfg.multiUAVMaxLaunchDelay = 900.0;

%% Fleet reporting and final AGL verification
cfg.multiUAVFleetRiskMaxWeight = 0.35;
cfg.localAGLValidationStep_m = 10.0;
cfg.enableLocalAGLConstraint = true;
cfg.enableDenseFinalAGLRepair = true;
cfg.denseFinalAGLRepairOnlyIfFormalViolation = true;
cfg.denseFinalAGLPreserveStaticFeasibility = true;
cfg.denseFinalAGLPreserveOverallFeasibility = true;
cfg.denseFinalAGLPreserveFinalMonitoring = true;
cfg.denseFinalAGLRepairStep_m = 8.0;
cfg.denseFinalAGLLowerMargin_m = 4.0;
cfg.denseFinalAGLUpperMargin_m = 2.0;
cfg.denseFinalAGLRepairPasses = 5;

end
