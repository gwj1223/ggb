function cfg = shiyanG1Config()
%SHIYANG1CONFIG Configuration for the Shiyan-G1 real-DEM experiment.
% The search engine remains v6.3.6 Risk-Balanced Refinement. Only the
% problem scale, flight limits and monitoring geometry are adapted to the
% approximately 10 km real-terrain ROI.
cfg = config.defaultConfig();

cfg.sceneId = 'Shiyan-G1-30R';
% Reproducibility metadata: the search logic remains the validated v6.3.6
% core; v6.4.1 only improves implementation efficiency, validation and maps.
cfg.algorithmVersion = 'GR-GM-RVAMODE-VI-v6.3.6';
cfg.implementationVersion = 'v6.4.1-compute-map-optimized';
cfg.realDataMode = true;
cfg.realProcessedDEM = fullfile('data_real','processed','Shiyan_G1_DEM.mat');
cfg.populationSize = 96;
cfg.maxGenerations = 220;
cfg.outputRoot = 'output_shiyan_g1_30r';
cfg.figureResolution = 600;

% Route discretization and initialization, now in metres.
cfg.numWaypoints = 72;
cfg.initNoiseXY = 320;
cfg.initNoiseZ = 55;
cfg.goalBiasInitFraction = 0.15;
cfg.corridorInitFraction = 0.20;
cfg.monitorGuidedInitFraction = 0.50;
cfg.randomInitFraction = 0.15;
cfg.corridorInitSideScale = 650;
cfg.monitorGuidedViewAngleDeg = 28;
cfg.monitorGuidedArcPoints = 2;
cfg.monitorGuidedSeedNoiseScale = 0.04;

% Real mountainous terrain flight envelope. MAXALTITUDE is converted to an
% absolute elevation after the DEM has been loaded by buildShiyanG1Problem.
cfg.safeClearance = 60;
cfg.realStartGoalAGL = 110;
cfg.realMaximumAGL = 320;
cfg.maxClimbAngleDeg = 22;
cfg.maxTurnAngleDeg = 95;
cfg.segmentSamples = 10;
cfg.segmentRepairSamples = 16;
cfg.segmentRepairMargin = 6;
cfg.segmentRepairRelaxation = 0.72;

% Energy-score scaling for a 10-15 km mountain route. The existing energy
% model is an engineering score, not a calibrated battery Wh model.
cfg.energyHorizontalCoeff = 0.018;
cfg.energyClimbCoeff = 0.35;
cfg.energyDescentCoeff = 0.05;
cfg.energyTurnCoeff = 0.80;
cfg.energyWindCoeff = 0.004;
cfg.energyObservationPower = 0.05;
cfg.energyHoverPower = 0.08;
cfg.maxEnergy = 3200;
cfg.realAssumedWind = [2.5 0.8 0];

% Monitoring geometry is scaled from tens of metres in the synthetic demo
% to hundreds of metres on the 30 m DEM.
cfg.monitorRangeSigma = 90;
cfg.monitorHeightSigma = 55;
cfg.monitorCoverageSamples = 10;
cfg.monitorLineOfSightSamples = 12;
cfg.monitorRequiredObservationLength = 300;
cfg.monitorObservationRangeFactor = [0.65 1.45];
cfg.monitorObservationSpeed = 12;
cfg.monitorHoverEquivalentSpeed = 5;
cfg.monitorCoverageDeficitScale = 250;
cfg.monitorCriticalMinObservationLength = 180;
cfg.monitorCriticalMinLOSRatio = 0.45;
cfg.monitorThresholdStepMinimum = 0.010;
cfg.monitorThresholdStepCritical = 0.015;
cfg.monitorThresholdStepObservationLength = 12;
cfg.monitorThresholdStepLOSRatio = 0.020;
cfg.finalStageSafeObservationLength = 220;
cfg.finalStageMonitoringSafetyMargin = [0.03 0.04 25 0.03];
cfg.cvScaleObservationLength = 180;

% The real terrain-derived flight-risk proxy has a median around 0.25 in
% this ROI. These limits are calibrated to keep monitoring possible near
% steep targets while penalizing prolonged exposure to high-risk terrain.
cfg.finalStageRiskRelaxedLimit = 0.56;
cfg.finalStageRiskTargetLimit = 0.50;
cfg.finalStageTailRiskRelaxedLimit = 0.70;
cfg.finalStageTailRiskTargetLimit = 0.62;
cfg.finalReportedMaximumRiskObjective = 0.52;
cfg.finalReportedMaximumMeanRisk = 0.46;
cfg.finalReportedMaximumTailRisk = 0.64;
cfg.finalReportedRelaxedMaximumRiskObjective = 0.58;
cfg.finalReportedRelaxedMaximumMeanRisk = 0.52;
cfg.finalReportedRelaxedMaximumTailRisk = 0.72;
cfg.finalReportedMaximumDetour = 5.20;
cfg.finalReportedRelaxedMaximumDetour = 5.80;

% Real-scene energy/HV scales. buildShiyanG1Problem also sets MAXALTITUDE
% after inspecting the actual elevation range.
cfg.hvIdealPoint = [1.00 0.00 900 0 0];
cfg.hvReferencePoint = [6.50 1.00 3600 1.50 1.00];
cfg.commonHVIdealPoint = cfg.hvIdealPoint;
cfg.commonHVReferencePoint = cfg.hvReferencePoint;
cfg.finalStageCostIndicatorIdeal = [1.00 0.00 900 0.00];
cfg.finalStageCostIndicatorScale = [4.50 0.70 2400 0.25];
cfg.riskBalancedIndicatorIdeal = [1.00 0.00 0.00 900 0.00];
cfg.riskBalancedIndicatorScale = [4.50 0.70 0.80 2400 0.25];
cfg.finalStageCostScaleFloor = [0.10 0.05 80 0.05];
cfg.cvScaleClearance = 60;
cfg.cvScaleEnergy = 600;
cfg.finalStageMaxEnergyAbsoluteIncrease = 4.0;

% Thirty DEM-derived risk targets are used; the six highest-risk local
% maxima are critical monitoring targets.
cfg.criticalTargetIndices = 1:6;
end
