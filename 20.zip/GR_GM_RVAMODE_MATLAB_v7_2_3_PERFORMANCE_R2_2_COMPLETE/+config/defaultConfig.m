function cfg = defaultConfig()
% GR-GM-RVAMODE-VI v6.4.0 real-DEM-compatible risk-balanced configuration.
%
% Objectives:
%   1) detour ratio (path length / straight-line distance),
%   2) mean geological risk + tail-risk CVaR,
%   3) propulsion + observation + equivalent-hover energy,
%   4) turn/climb/curvature smoothness,
%   5) monitoring loss with average, minimum, critical and balance terms.

cfg.randomSeed = 42;
cfg.populationSize = 72;
cfg.maxGenerations = 160;
cfg.numWaypoints = 14;

% v7.2.0 structured monitoring encoding is opt-in. Legacy/default problems
% continue to evolve the established XYZ waypoint chromosome.
cfg.enableStructuredMonitoringEncoding = false;
cfg.structuredObservationLengthFactorBounds = [0.65 1.50];
cfg.structuredVisibleArcUseFraction = 0.90;
cfg.structuredVisibleSectorUseFraction = 0.92;
cfg.structuredObservationMaxHalfAngleDeg = 80;
cfg.structuredObservationHeightSigmaFraction = 0.60;
cfg.structuredObservationAGLMargin_m = 2;
cfg.structuredTransitMaxOffsetFraction = 0.18;
cfg.structuredTransitMaxOffset_m = 300;
cfg.structuredTransitDifficultySamples = 7;
cfg.structuredTransitReliefWeight = 1.5;
cfg.structuredTransitBiasFallbackScales = [1.0 0.5 0.0];
% v7.2.1 static-feasibility controls. Defaults are inert for legacy/demo
% problems; Shiyan structured monitoring explicitly opts in below.
cfg.structuredTransitMinimumBoundaryConnectors = 0;
cfg.structuredTransitMaximumBoundaryConnectors = inf;
cfg.structuredTransitMaximumConnectorsPerLeg = inf;
cfg.structuredTransitTurnWeight = 0;
cfg.structuredTransitMandatoryTurnFraction = 1.0;
cfg.structuredTransitSevereTurnExtraConnectors = 0;
cfg.structuredTransitTangentHandleFraction = 0.32;
cfg.structuredTransitTangentHandleMaxFraction = 0.495;
cfg.structuredUseTangentAwareTransit = false;
% v7.2.3 Dense-first decoder controls. Inert while structured encoding is off.
cfg.structuredTransitTopologyCandidateLimit = 6;
cfg.structuredTransitTangentBlendSchedule = [0.25 0.50 0.75 1.00];
% v7.2.3 Performance R2: computation-only acceleration/profiling.
cfg.enableStructuredSegmentTerrainCache = true;
cfg.enableTerrainInterpolatorCache = true;
cfg.enableStructuredPerformanceProfiling = true;
cfg.enableDenseProjectionVectorizedDP = true;
cfg.structuredDisableLegacyXYZLocalSearch = true;
cfg.structuredRestartNoiseScale = 0.18;
cfg.structuredEncodingPrecheckTurn = true;
cfg.structuredGeneNoiseScale = 0.05;
cfg.structuredA3RadiusGeneStep = 0.28;
cfg.structuredA3SectorGeneStep = 0.38;
cfg.structuredA3ArcGeneStep = 0.32;
cfg.structuredA3HeightBlendToDesired = 0.50;

cfg.numObjectives = 5;
cfg.archiveSize = 120;
cfg.verboseEvery = 10;

% Multi-strategy differential evolution.
cfg.Fmin = 0.20; cfg.Fmax = 0.90;
cfg.CRmin = 0.20; cfg.CRmax = 0.90;
cfg.successLearningRate = 0.10;
cfg.strategyProbabilityMin = 0.15;
cfg.strategyProbabilityMax = 0.70;
cfg.monitorStrategyMaxProbability = 0.55;
cfg.strategyUpdateRate = 0.20;
cfg.strategyScoreEpsilon = 1e-8;
cfg.initialMuF = [0.65 0.50 0.40];
cfg.initialMuCR = [0.55 0.75 0.85];
% Optimized DE controls.
cfg.useCauchyF = true;
cfg.FcauchyScale = 0.10;
cfg.CRnormalScale = 0.08;
cfg.pbestRate = 0.20;
cfg.useArchiveDifference = true;
cfg.waypointBlockCrossover = true;

% Geological-monitoring-aware initialization.
cfg.goalBiasInitFraction = 0.20;
cfg.corridorInitFraction = 0.35;
cfg.monitorGuidedInitFraction = 0.30;
cfg.randomInitFraction = 0.15;
cfg.initNoiseXY = 7.0;
cfg.initNoiseZ = 4.0;
cfg.corridorInitSideScale = 18; % metres in the demo coordinate scale
% Monitoring-guided individuals use a multi-point annulus arc per target.
cfg.monitorGuidedViewAngleDeg = 25;
cfg.monitorGuidedRadiusScale = 1.00;
% Three viewpoints form a real observation arc. The first guided seed is
% deterministic and preserves all target arcs exactly.
cfg.monitorGuidedArcPoints = 3;
cfg.monitorGuidedSeedEliteCount = 2;
cfg.monitorGuidedSeedNoiseScale = 0.08;
cfg.monitorGuidedObstacleOrderPenalty = 25;
cfg.monitorGuidedObstacleOrderMargin = 3;
cfg.initialRepairPasses = 0;

% Flight constraints and vectorized path sampling.
cfg.safeClearance = 8.0;
cfg.maxAltitude = 95.0;
cfg.maxClimbAngleDeg = 25;
cfg.maxTurnAngleDeg = 90;
cfg.maxEnergy = 460;
cfg.segmentSamples = 8;
cfg.constraintTolerance = 1e-8;

% Segment-level clearance repair.
cfg.segmentRepairSamples = 12;
cfg.segmentRepairPasses = 3;
cfg.maxRepairPasses = 4;
cfg.segmentRepairMargin = 0.75;
cfg.segmentRepairRelaxation = 0.65;
cfg.repairChangeTolerance = 1e-5;
% Preserve the chromosome waypoint order. The old projection sort can
% destroy valid local monitoring arcs and is disabled by default.
cfg.enableGlobalProgressSorting = false;

% Objective 1: normalized route length.
cfg.useDetourRatioObjective = true;

% Objective 2: mean geological risk and upper-tail risk.
cfg.riskMeanWeight = 0.70;
cfg.riskTailWeight = 0.30;
cfg.riskCVaRAlpha = 0.90;

% Objective 3: propulsion, observation and equivalent-hover energy.
cfg.energyHorizontalCoeff = 0.72;
cfg.energyClimbCoeff = 2.8;
cfg.energyDescentCoeff = 0.30;
cfg.energyTurnCoeff = 0.18;
cfg.energyWindCoeff = 0.25;
cfg.energyObservationPower = 1.10;
cfg.energyHoverPower = 1.55;
cfg.monitorObservationSpeed = 4.0;
cfg.monitorHoverEquivalentSpeed = 2.0;

% Objective 4: normalized turn, climb-change and curvature-change costs.
cfg.smoothTurnWeight = 0.50;
cfg.smoothVerticalWeight = 0.30;
cfg.smoothCurvatureWeight = 0.20;
cfg.smoothCurvatureScale = 0.08;

% Objective 5: physically interpretable geological monitoring model.
cfg.monitorRangeSigma = 8;
cfg.monitorHeightSigma = 9;
cfg.enableLineOfSight = true;
cfg.monitorCoverageSamples = 8;
cfg.monitorLineOfSightSamples = 6;
cfg.monitorRequiredObservationLength = 12;
cfg.monitorObservationRangeFactor = [0.55 1.55];

% A small differentiable floor prevents exact-zero quality plateaus while
% final thresholds still require genuine LOS and observation duration.
cfg.monitorSearchComponentFloor = 0.01;
% Backward-compatible alias used by older scripts.
cfg.monitorComponentFloor = cfg.monitorSearchComponentFloor;

% Weighted geometric quality exponents. They sum to one.
cfg.monitorRangeExponent = 0.25;
cfg.monitorHeightExponent = 0.20;
cfg.monitorLOSExponent = 0.25;
cfg.monitorDurationExponent = 0.30;

% Monitoring-loss composition. The added coverage and observation-deficit
% terms provide a continuous incentive before true duration becomes positive.
cfg.monitorAverageWeight = 0.15;
cfg.monitorMinimumWeight = 0.35;
cfg.monitorCriticalWeight = 0.15;
cfg.monitorDispersionWeight = 0.05;
cfg.monitorCoverageDeficitWeight = 0.20;
cfg.monitorObservationDeficitWeight = 0.10;
cfg.monitorCoverageDeficitScale = 15.0;

% Once the complete final constraints are active, monitoring qualities above
% robust safety caps no longer receive extra objective reward. Hard final
% constraints still use the uncapped physical qualities.
cfg.enableFinalStageMonitoringSaturation = true;
cfg.finalStageAverageQualityCap = 0.82;
cfg.finalStageMinimumQualityCap = 0.72;
cfg.finalStageCriticalQualityCap = 0.80;
cfg.finalStageDispersionWeightScale = 0.50;
cfg.criticalTargetIndices = [2 3];
cfg.enableMonitoringConstraint = true;
cfg.enableMonitoringGeometryConstraints = true;

% Final monitoring requirements. The feedback controller gradually raises
% all four requirements to these values.
cfg.monitorMinTargetQuality = 0.33;
cfg.monitorCriticalMinQuality = 0.42;
cfg.monitorCriticalMinObservationLength = 8.0;
cfg.monitorCriticalMinLOSRatio = 0.45;

% Feasibility-rate feedback threshold controller.
cfg.enableMonitoringConstraintRamp = true; % legacy fallback switch
cfg.enableFeasibilityFeedbackThreshold = true;
cfg.monitorConstraintStartGeneration = 15;
cfg.monitorThresholdStepMinimum = 0.006;
cfg.monitorThresholdStepCritical = 0.009;
cfg.monitorThresholdStepObservationLength = 0.25;
cfg.monitorThresholdStepLOSRatio = 0.010;
cfg.monitorThresholdUpdateInterval = 1;
cfg.monitorRampMinFeasibleRate = 0.65;
cfg.monitorRampSlowFeasibleRate = 0.35;
cfg.monitorRampRecoveryRate = 0.10;
cfg.monitorThresholdSlowFactor = 0.25;
cfg.monitorThresholdRollbackFactor = 0.50;
% A proposed threshold is committed only when the existing population is
% predicted to retain enough feasible solutions under that threshold.
cfg.monitorPredictiveMinFeasibleRate = 0.55;
cfg.monitorPredictiveSlowFeasibleRate = 0.35;
cfg.monitorRollbackPatience = 3;
% When most of the population already satisfies the complete final
% requirements for several generations, commit all thresholds at once.
cfg.enableSnapFinalThreshold = true;
cfg.snapFinalFeasibleRate = 0.85;
cfg.snapFinalPatience = 3;
cfg.monitorThresholdTolerance = 1e-12;
% Update independently supportable threshold components. This prevents a
% single uncovered noncritical target from freezing all four thresholds.
cfg.monitorComponentwiseThresholdUpdate = true;
cfg.monitorConstraintRampGenerations = 60; % legacy fallback

% Periodic monitoring-aware local search.
cfg.localSearchStartGeneration = 5;
cfg.localSearchInterval = 5;
cfg.localSearchMinFraction = 0.03;
cfg.localSearchMaxFraction = 0.12;
cfg.localSearchTrials = 2;
cfg.riskGradientStep = 2.0;
cfg.monitorAttractionStep = 2.2; % retained for backward compatibility
cfg.monitorLocalMinGain = 1e-5;
% Mission-recovery observation-arc insertion.
cfg.monitorArcInsertionWaypoints = 5;
cfg.monitorArcInsertionProbability = 0.40;
cfg.monitorArcInsertionProbabilityZero = 0.80;
cfg.monitorArcInsertionTriggerQuality = 0.05;
cfg.monitorArcInsertionStrength = 0.75;
cfg.monitorArcInsertionStrengthZero = 1.00;
cfg.monitorLocalMaxDetourIncrease = 0.55;
cfg.monitorLocalMaxRiskIncrease = 0.15;
cfg.monitorLocalMaxEnergyFactor = 1.80;
cfg.monitorLocalMaxSmoothnessIncrease = 0.75;
cfg.monitorMissionMinGain = 1e-4;
cfg.monitorEmergencyStrategyBlend = 0.25;
cfg.monitorEmergencyMinimumQuality = 0.05;

% Final-stage strategy transition and route-cost local refinement.
cfg.enableFinalStageStrategyBlend = true;
cfg.finalStageStrategyTarget = [0.25 0.55 0.20];
cfg.finalStageStrategyBlend = 0.60;
cfg.finalStageArcInsertionOnlyIfDeficit = true;
cfg.finalStageArcInsertionProbability = 0.02;

% Smooth multi-neighbourhood cost refinement. The five operators are:
%   1) curvature-window smoothing,
%   2) soft shortcut,
%   3) observation-arc radius contraction,
%   4) observation-arc rotation,
%   5) altitude-only smoothing.
cfg.enableFinalStageCostRefinement = true;
cfg.finalStageCostRefinementProbability = 0.90;
cfg.finalStageOperatorInitialProbabilities = [0.28 0.24 0.16 0.14 0.18];
cfg.finalStageOperatorUpdateRate = 0.30;
cfg.finalStageOperatorProbabilityMin = 0.07;
cfg.finalStageOperatorProbabilityMax = 0.45;
cfg.finalStageOperatorRewardEpsilon = 1e-6;
% Reward learning uses decayed attempts, accepted moves and accepted gain.
cfg.finalStageOperatorCreditDecay = 0.85;
cfg.finalStageOperatorRewardFloor = 1e-4;
cfg.finalStageOperatorScoreWeights = [0.40 0.55 0.05];
% Power greater than one amplifies persistent score differences without
% removing the minimum exploration probability.
cfg.finalStageOperatorSelectionPressure = 1.50;
cfg.finalStageTrustRegionRatio = 0.22;
cfg.finalStageSmoothWindowSize = 5;
cfg.finalStageShortcutMinSpan = 2;
cfg.finalStageShortcutMaxSpan = 6;
cfg.finalStageArcShrinkFraction = [0.03 0.12];
cfg.finalStageArcRotationAnglesDeg = [-20 -10 10 20];
cfg.finalStageAltitudeSmoothingStrength = [0.25 0.55];

% Cost acceptance uses both a weighted gain and hard safety guards. The
% smoothness weight is intentionally large because v6.3.2 shortened routes
% at the expense of pronounced local corners.
cfg.finalStageCostWeights = [0.27 0.31 0.22 0.20];
cfg.finalStageCostScaleFloor = [0.05 0.05 20.0 0.05];
cfg.finalStageCostMinRelativeGain = 5e-5;
cfg.finalStageCostMaxRelativeDeterioration = [0.02 0.015 0.01 0.03];
cfg.finalStageMaxSmoothnessRatio = 1.05;
cfg.finalStageMaxSmoothnessAbsoluteIncrease = 0.005;
cfg.finalStageMaxRiskRatio = 1.02;
cfg.finalStageMaxRiskAbsoluteIncrease = 0.006;
cfg.finalStageMaxTailRiskRatio = 1.02;
cfg.finalStageMaxTailRiskAbsoluteIncrease = 0.012;
cfg.finalStageMaxEnergyRatio = 1.01;
cfg.finalStageMaxEnergyAbsoluteIncrease = 1.0;
% A generation-dependent absolute smoothness ceiling prevents many small
% locally acceptable changes from accumulating into a globally jagged path.
cfg.finalStageSmoothnessRelaxedLimit = 0.170;
cfg.finalStageSmoothnessTargetLimit = 0.135;
cfg.finalStageSmoothnessTighteningGenerations = 80;
cfg.finalStageSmoothnessAboveLimitTolerance = 1e-6;

% Risk is the remaining weak point after the route became short and smooth.
% The final-stage local search therefore uses progressively tightened
% absolute limits in addition to parent-relative risk guards.
cfg.finalStageRiskRelaxedLimit = 0.38;
cfg.finalStageRiskTargetLimit = 0.34;
cfg.finalStageTailRiskRelaxedLimit = 0.62;
cfg.finalStageTailRiskTargetLimit = 0.56;
cfg.finalStageRiskTighteningGenerations = 80;
cfg.finalStageRiskAboveLimitTolerance = 1e-6;

% Monitoring is an epsilon constraint in the final stage. These robust
% safety lines are stricter than the formal mission limits, preventing one
% noncritical target from being sacrificed during route compression.
cfg.finalStageSafeMinimumQuality = 0.65;
cfg.finalStageSafeCriticalQuality = 0.75;
cfg.finalStageSafeObservationLength = 9.0;
cfg.finalStageSafeLOSRatio = 0.50;
cfg.finalStageMaxMonitoringDispersion = 0.22;
cfg.finalStageMonitoringSafetyMargin = [0.02 0.03 0.50 0.03];

% Constraint-violation scales.
cfg.cvCollisionWeight = 200;
cfg.cvClearanceWeight = 20;
cfg.cvClimbWeight = 10;
cfg.cvTurnWeight = 5;
cfg.cvEnergyWeight = 2;
cfg.cvMonitoringWeight = 80;
cfg.cvScaleCollision = 1;
cfg.cvScaleClearance = 10;
cfg.cvScaleClimb = 10;
cfg.cvScaleTurn = 20;
cfg.cvScaleEnergy = 50;
cfg.cvScaleMonitoring = 0.20;
cfg.cvScaleObservationLength = 8.0;
cfg.cvScaleLOSRatio = 0.45;
cfg.nearFeasibleCV = 0.05;
cfg.infeasibleTieTolerance = 1e-10;

% Strategy credit in infeasible and feasible stages.
cfg.infeasibleCVWeight = 0.60;
cfg.infeasibleNearFeasibleWeight = 0.25;
cfg.infeasibleDiversityWeight = 0.15;
cfg.feasibleSuccessWeight = 0.45;
cfg.feasibleMonitoringWeight = 0.30;
cfg.feasibleDiversityWeight = 0.25;

% Structured restart while the whole population remains infeasible.
cfg.enableInfeasibleRestart = true;
cfg.infeasibleRestartWindow = 8;
cfg.infeasibleRestartFraction = 0.30;
cfg.infeasibleDiversityThreshold = 0.60;

% Archive and final solution selection.
cfg.referenceWeights = [0.12 0.22 0.12 0.08 0.46];
% Weights for the separate balanced representative; the monitoring-priority
% selector above remains available for mission-focused reporting.
cfg.balancedRepresentativeWeights = [0.22 0.25 0.20 0.13 0.20];
cfg.kneeRepresentativeWeights = [0.20 0.22 0.20 0.13 0.25];
cfg.kneeAugmentation = 0.05;
cfg.monitoringQualityThresholds = [0.80 0.75 0.70 0.65 0.00];
% The reported best path is selected primarily by flight cost after it has
% cleared final monitoring limits with a small robustness margin.
cfg.finalRepresentativeCostWeights = [0.30 0.22 0.22 0.26];
cfg.finalRepresentativeMinimumMargin = 0.03;
cfg.finalRepresentativeCriticalMargin = 0.03;
cfg.finalRepresentativeObservationMargin = 0.50;
cfg.finalRepresentativeLOSMargin = 0.02;
cfg.finalRepresentativeMonitoringTieWeight = 0.03;
cfg.finalRepresentativePreferSmoothnessTarget = true;
% The principal reported path is selected from the interpretable
% representatives after report-level engineering filtering. The optimizer
% still preserves the complete Common Pareto set; only the displayed and
% exported best path is filtered.
cfg.finalReportedSolution = 'RiskBalanced';
cfg.finalReportedFallback = 'MinimumPhysicalCost';
cfg.finalReportedSmoothnessLimit = 0.145;
cfg.finalReportedMaximumDetour = 1.34;
cfg.finalReportedMaximumEnergyRatioToBest = 1.10;
cfg.finalReportedMaximumEnergy = inf;
cfg.finalReportedMaximumMonitoringDispersion = 0.22;
cfg.finalReportedMaximumRiskObjective = 0.34;
cfg.finalReportedMaximumMeanRisk = 0.25;
cfg.finalReportedMaximumTailRisk = 0.56;
% A relaxed filter prevents empty-report failures when the strict limits are
% temporarily unattainable. Final mission feasibility is still mandatory.
cfg.finalReportedRelaxedSmoothnessLimit = 0.180;
cfg.finalReportedRelaxedMaximumDetour = 1.42;
cfg.finalReportedRelaxedMaximumEnergyRatioToBest = 1.18;
cfg.finalReportedRelaxedMaximumMonitoringDispersion = 0.28;
cfg.finalReportedRelaxedMaximumRiskObjective = 0.38;
cfg.finalReportedRelaxedMaximumMeanRisk = 0.29;
cfg.finalReportedRelaxedMaximumTailRisk = 0.62;
cfg.archiveObjectiveTolerance = 1e-5;
% Five objectives with H=4 produce 70 reference vectors, matching the
% population size (72) much better than H=5, which produces 126 vectors.
cfg.referenceVectorDivisions = 4;
cfg.useReferenceVectorEnvironmentalSelection = true;
cfg.referenceVectorAlpha = 2.0;

% Fixed-scale five-dimensional Monte-Carlo hypervolume.
cfg.enableHVStopping = true;
cfg.hvIdealPoint = [1.00 0.00 90 0 0];
cfg.hvReferencePoint = [1.80 1.00 550 1.50 1.00];
cfg.hvSamples = 10000;
cfg.hvSeed = 20260730;
cfg.hvEvaluationInterval = 5;
cfg.hvStallWindow = 15;
cfg.hvTolerance = 1e-3;
cfg.hvRequiredStallWindows = 1;
cfg.minGenerations = 100;
% The optimizer must spend this many generations under the complete final
% constraints before HV stagnation is allowed to stop the run.
cfg.minimumFinalStageGenerations = 25;
cfg.hvStoppingPostFinalThresholdBuffer = 10; % legacy lower bound
cfg.hvStoppingPostRampBuffer = 5; % legacy name


% Version-independent physical evaluation. The fifth common objective is
% one minus the true minimum target quality, so results remain comparable
% even when the internal monitoring search loss changes between versions.
cfg.enableCommonEvaluation = true;
cfg.commonHVIdealPoint = [1.00 0.00 90 0 0];
cfg.commonHVReferencePoint = [1.80 1.00 550 1.50 1.00];
cfg.commonArchiveSize = 150;
% Final-feasible candidates are buffered every generation, while the
% quadratic Common Archive update and Monte-Carlo Common HV evaluation
% run at separate cadences. Buffering prevents transient good solutions
% from being lost between archive updates.
cfg.commonArchiveUpdateInterval = 2;
cfg.commonHVEvaluationInterval = 10;
cfg.commonCandidateBufferMax = 2500;
cfg.commonArchiveObjectiveTolerance = 1e-5;
cfg.commonKneeWeights = [0.20 0.25 0.18 0.17 0.20];
cfg.commonKneeAugmentation = 0.05;

% Final-stage dual stagnation stopping: both final-archive HV and the best
% physical cost indicator must remain stagnant before termination.
cfg.enableFinalStageCostStopping = true;
cfg.finalStageStagnationWindow = 25;
cfg.finalStageCommonHVImprovementTolerance = 0.002;
cfg.finalStageCostImprovementTolerance = 0.003;
cfg.finalStageStagnationRequiredWindows = 1;
cfg.finalStageCostIndicatorWeights = [0.25 0.35 0.20 0.20];
cfg.finalStageCostIndicatorIdeal = [1.00 0.00 90 0.00];
cfg.finalStageCostIndicatorScale = [0.50 0.50 200 0.20];

% Fixed-scale engineering score for the default reported solution. Risk
% objective and tail risk jointly receive 48 percent of the score, while
% monitoring remains an epsilon constraint rather than a reward.
cfg.riskBalancedIndicatorWeights = [0.22 0.26 0.22 0.15 0.15];
cfg.riskBalancedIndicatorIdeal = [1.00 0.00 0.00 90 0.00];
cfg.riskBalancedIndicatorScale = [0.50 0.50 0.80 200 0.20];
cfg.riskBalancedIndicatorAugmentation = 0.05;

cfg.saveResults = true;
cfg.saveFigures = true;
cfg.outputRoot = 'output';
cfg.figureResolution = 300;
end
