function cfg = fastConfig()
%FASTCONFIG Small configuration for debugging and parameter sweeps.
cfg = config.defaultConfig();
cfg.populationSize = 48;
cfg.maxGenerations = 100;
cfg.numWaypoints = 12;
cfg.archiveSize = 80;
cfg.segmentSamples = 6;
cfg.monitorCoverageSamples = 6;
cfg.monitorLineOfSightSamples = 4;
cfg.segmentRepairSamples = 8;
cfg.segmentRepairPasses = 2;
cfg.maxRepairPasses = 3;
cfg.localSearchInterval = 8;
cfg.localSearchMaxFraction = 0.08;
cfg.localSearchTrials = 1;
cfg.hvSamples = 3000;
cfg.hvEvaluationInterval = 10;
cfg.commonArchiveUpdateInterval = 2;
cfg.commonHVEvaluationInterval = 20;
cfg.verboseEvery = 5;
cfg.minGenerations = 60;
cfg.minimumFinalStageGenerations = 12;
cfg.snapFinalPatience = 2;
% Reach all final feedback thresholds within the shorter debug run.
cfg.monitorThresholdStepMinimum = 0.008;
cfg.monitorThresholdStepCritical = 0.012;
cfg.monitorThresholdStepObservationLength = 0.35;
cfg.monitorThresholdStepLOSRatio = 0.014;
cfg.hvStoppingPostFinalThresholdBuffer = 5;
end
