clear; clc;
projectRoot = fileparts(mfilename('fullpath'));
setupProject(projectRoot);
rawTif = fullfile(projectRoot,'data_real','raw','ASTGTMV003_N32E110_dem.tif');
outFile = fullfile(projectRoot,'data_real','processed','Shiyan_G1_DEM_regenerated.mat');
realdata.prepareShiyanG1Data(rawTif,outFile);
fprintf('Processed Shiyan-G1 DEM saved to: %s\n',outFile);
