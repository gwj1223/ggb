# v7.0.0.2 Test-Only Historical Coupling Cleanup

This patch changes **tests only**. It does not modify the five objectives, A1,
Unified Mission Deficit / A3, A6, allocation weights, population/generation
settings, formal monitoring thresholds, AGL limits, risk, energy, or collision
logic.

## Cleaned couplings

1. `test_multi_uav_assignment.m`
   - removes exact pre-v7 allocator method-name equality;
   - verifies v7 knowledge-aware allocation semantics instead.

2. `test_observability_aware_assignment.m`
   - same interface-label cleanup;
   - keeps wrapper/direct-allocation equivalence and quota/load checks.

3. `test_local_agl_envelope.m`
   - removes `snapFinalFeasibleRate == 0.05` as a v7 integration invariant;
   - checks active v7 Mission Deficit/controller semantics plus the actual AGL
     hard envelope.

4. `test_v700_test_contract_hygiene.m` (new)
   - prevents exact pre-v7 allocator label assertions;
   - prevents assertions hard-coding pre-v7 version literals;
   - prevents multi-UAV integration tests from asserting legacy
     `snapFinalFeasibleRate` tuning;
   - prevents calls to removed TargetMemory/Coverage restoration functions;
   - rejects a pre-v7 `run_all_tests` success banner.

## Intentionally retained tests

Generic component tests such as `test_feedback_threshold_controller` and
`test_snap_final_threshold` are not deleted. They test reusable controller
components, even though the v7 multi-UAV path disables the legacy independent
feedback controller.

## Apply

In MATLAB, add this patch folder to the path or `cd` into it and run:

```matlab
apply_v7002_test_cleanup('C:\path\to\GR_GM_RVAMODE_MATLAB_v7_0_0_LOGIC_CONSOLIDATED')
```

Then run the full suite from the project root:

```matlab
restoredefaultpath;
clear functions;
clear classes;
rehash toolboxcache;
clc;
close all;
setupProject(pwd);
run_all_tests
```

The patch creates a timestamped backup of the replaced tests and
`run_all_tests.m` before editing.
