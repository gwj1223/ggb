# v7.2.3 发布说明

## 本版目标

解决 v7.2.2 UAV-1 中持续 `DenseOK=0/96`、全部失败为 `dense_reach` 的 structured-decoder 可行域断裂问题。

## 新增

- 多 connector-topology 小候选集；
- chord/bias Dense-first 解码；
- tangent blend 仅作为 Dense-feasible carrier 的二阶段 turn refinement；
- 每一级 tangent blend 都重新运行正式 Dense-3D projector；
- decoder-only gate；
- UAV-1 / UAV-2 focused scripts；
- topology 与 source-contract tests；
- reach failure segment diagnostics。

## 不变

- 51D semantic genotype；
- 42 internal waypoints / 126D phenotype；
- 五目标；
- Mission Band / Mission Deficit；
- A1 / A3 / A6 语义；
- 所有正式监测阈值与飞行约束。

## 当前科学验收指标

第一道门不是最终 MissionSuccess，而是：

```text
DenseOK > 0
```

如果 decoder-only Gate 仍为 0，则下一步应根据 failed-segment histogram 做 leg-aware reachability repair，而不是增加世代数或放宽约束。


## 完整工程收口

- 基线完整包 SHA-256：`c2a690a73365dca370f528070de0b812f8633f3900961eea8bbec99b353a057a`；
- `run_all_tests` 已纳入 2 个 v7.2.3 新测试，总计 104 个；
- 根 `README.md`、decoder 头注释、Shiyan structured config 已更新至 v7.2.3；
- 默认 structured config 增加 topology candidate limit 与 tangent blend schedule；
- config validation 增加上述两项的合法性检查；
- MATLAB/Octave runtime 不在构建环境中，因此数值运行状态明确标记为“待本地验证”。

## Runtime-test hotfix: structured diagnostics schema

After the first MATLAB `run_all_tests` execution, 103/104 tests passed and
`test_structured_boundary_turn_allocation` exposed a diagnostic-schema
regression: v7.2.3 still computed `legTurnDemand` and `connectorTurnCost`, but
the decoder no longer copied them into `info.legTurnDemandDeg` and
`info.connectorTurnCostDeg`. This hotfix restores those two v7.2.2 contract
fields. It does **not** change connector allocation, topology candidates,
Dense-first decoding, objectives, mission semantics, or formal thresholds.
