clear;
clc;
close all;

%RUN_30_SEEDS Reproducible serial 30-seed Shiyan-G1 experiment runner.
%
% The optimizer/problem definition is unchanged. Figures are disabled during
% the batch to reduce I/O overhead; each seed still exports result.mat, CSV
% diagnostics, geographic path and scene metadata.  The aggregate summary is
% checkpointed after every seed so a long experiment leaves usable progress.

projectRoot = fileparts(mfilename('fullpath'));
setupProject(projectRoot);

seeds = 1:30;
cfgBase = config.shiyanG1Config();
cfgBase.saveFigures = false;
cfgBase.outputRoot = 'output_shiyan_g1_30r_30seeds';

[problem,cfgBase] = realdata.buildShiyanG1Problem(projectRoot,cfgBase);
config.validateConfig(cfgBase,problem);

batchRoot = fullfile(projectRoot,cfgBase.outputRoot);
if ~exist(batchRoot,'dir'), mkdir(batchRoot); end
summaryFile = fullfile(batchRoot,'batch_summary_30seeds.csv');

N = numel(seeds);
Seed = seeds(:);
Status = repmat("pending",N,1);
ErrorMessage = strings(N,1);
StopGeneration = nan(N,1);
FinalFeasible = false(N,1);
PathLength_km = nan(N,1);
DetourRatio = nan(N,1);
RiskObjective = nan(N,1);
MeanRisk = nan(N,1);
TailRisk = nan(N,1);
Energy = nan(N,1);
Smoothness = nan(N,1);
Qmin = nan(N,1);
Qcritical = nan(N,1);
CriticalObservationLength_m = nan(N,1);
CriticalLOS = nan(N,1);
ConstraintViolation = nan(N,1);
CommonHV = nan(N,1);
Runtime_s = nan(N,1);
OutputDirectory = strings(N,1);

for k = 1:N
    cfg = cfgBase;
    cfg.randomSeed = seeds(k);
    problem.cfg = cfg;

    fprintf('\n============================================================\n');
    fprintf('Shiyan-G1 batch seed %d (%d/%d)\n',cfg.randomSeed,k,N);
    fprintf('============================================================\n');

    try
        result = core.runGRAHMODE(problem,cfg);
        b = result.best(1);

        out = exporter.saveRun(problem,result,cfg,projectRoot);
        realdata.exportGeographicPath(problem,result,out);
        realdata.exportSceneMetadata(problem,out);
        manifest = fullfile(projectRoot,'data_real','processed', ...
            'Shiyan_G1_source_manifest.json');
        if isfile(manifest)
            copyfile(manifest,fullfile(out,'Shiyan_G1_source_manifest.json'));
        end

        Status(k) = "ok";
        StopGeneration(k) = result.stopGeneration;
        FinalFeasible(k) = result.bestSolutionSatisfiesFinalConstraints;
        PathLength_km(k) = b.pathMetrics.rawLength/1000;
        DetourRatio(k) = b.pathMetrics.detourRatio;
        RiskObjective(k) = b.riskStats.objective;
        MeanRisk(k) = b.riskStats.meanRisk;
        TailRisk(k) = b.riskStats.tailRisk;
        Energy(k) = b.energyStats.total;
        Smoothness(k) = b.objectives(4);
        Qmin(k) = b.monitorStats.minimumQuality;
        Qcritical(k) = b.monitorStats.criticalQuality;
        CriticalObservationLength_m(k) = ...
            b.monitorStats.minimumCriticalObservationLength;
        CriticalLOS(k) = b.monitorStats.minimumCriticalLOSRatio;
        ConstraintViolation(k) = b.cv;
        Runtime_s(k) = result.totalOptimizationTime;
        OutputDirectory(k) = string(out);
        if isfield(result,'bestCommonHypervolume')
            values = result.bestCommonHypervolume;
            idx = find(isfinite(values),1,'last');
            if ~isempty(idx), CommonHV(k) = values(idx); end
        end
    catch ME
        Status(k) = "failed";
        ErrorMessage(k) = string(ME.identifier)+": "+string(ME.message);
        warning('run_30_seeds:SeedFailed', ...
            'Seed %d failed: %s',cfg.randomSeed,ME.message);
    end

    T = table(Seed,Status,ErrorMessage,StopGeneration,FinalFeasible, ...
        PathLength_km,DetourRatio,RiskObjective,MeanRisk,TailRisk,Energy, ...
        Smoothness,Qmin,Qcritical,CriticalObservationLength_m,CriticalLOS, ...
        ConstraintViolation,CommonHV,Runtime_s,OutputDirectory);
    writetable(T,summaryFile);
end

fprintf('\nBatch complete. Summary: %s\n',summaryFile);
