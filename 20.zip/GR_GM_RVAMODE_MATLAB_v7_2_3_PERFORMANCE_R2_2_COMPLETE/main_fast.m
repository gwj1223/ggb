clear; clc; close all;
%MAIN_FAST Fast 3-UAV architecture/visualization smoke test.
% This is not the formal paper experiment. Use main.m for the formal run.
% The legacy single-UAV fast entry is preserved as main_single_uav_fast.m.

projectRoot = fileparts(mfilename('fullpath'));
setupProject(projectRoot);

cfg = config.multiUAVShiyanConfig();
cfg.populationSize = 60;
cfg.maxGenerations = 90;
cfg.archiveSize = 90;
cfg.commonArchiveSize = 110;
cfg.hvSamples = 2500;
cfg.verboseEvery = 10;
cfg.saveFigures = false;

[problem,cfg] = realdata.buildShiyanG1Problem(projectRoot,cfg);

fprintf('\n============================================================\n');
fprintf(' FAST ENTRY: %d-UAV COOPERATIVE MONITORING\n',cfg.multiUAVCount);
fprintf(' Smoke test only: pop=%d, generations=%d\n', ...
    cfg.populationSize,cfg.maxGenerations);
fprintf('============================================================\n');

fleetResult = multiUAV.runCooperativeMonitoring(problem,cfg);
visualization.plotMultiUAVResult(problem,fleetResult,cfg);
visualization.plotFleetSeparation(fleetResult,cfg);

fprintf(['FAST multi-UAV | success=%d | Qmin=%.3f | ' ...
    'dmin=%.1f m | makespan=%.1f min\n'], ...
    fleetResult.metrics.missionSuccess, ...
    fleetResult.metrics.Qmin, ...
    fleetResult.metrics.minimumSeparation_m, ...
    fleetResult.metrics.makespan_s/60);
