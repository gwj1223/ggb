# v7.2.3 Performance R2

本版本**不改变算法数学语义与正式阈值**，基于已通过 UAV-1/UAV-2 focused verification 的 v7.2.3 R1。

## 冻结不变
- Population = 96, Max generations = 220, objectives = 5
- 51D structured semantic genotype -> 42 waypoint / 126D XYZ phenotype
- Qmin=0.33, Critical Q=0.42, CriticalObs=180 m, CriticalLOS=0.45
- AGL 60--320 m, climb <=22 deg, turn <=95 deg
- Mission Deficit is ranking/feasibility signal, not a sixth objective
- Mission Band, A3, A6 semantics unchanged

## 性能工程
1. Decoder-local dense segment terrain cache: identical directed XY segment + identical sampling policy reuses the same `sampleSegmentTerrainAdaptive` result.
2. Shiyan immutable DEM uses a cached `griddedInterpolant`; unsupported cases automatically fall back to the historical `interp2` path.
3. Structured trial profiling records decoder, dense projection, terrain sampling, reach attempts, cache hits/misses.
4. `run_v723_performance_probe(uavId,samples)` compares cache OFF/ON on identical semantic genes and aborts if phenotype/decoder contract differs beyond 1e-8.

## Strict-engineering reporting diagnostics
- Formal feasibility and strict engineering reporting remain separate.
- Result now exposes `reportedStrictEngineeringDetails`, `reportedStrictEngineeringDiagnostics`, and `reportedStrictEngineeringFailedCriteria`.
- `diagnose_reported_engineering_v723(result,uavId)` prints each strict criterion with value and limit without rerunning optimization.

## Tests
R1 had 104 tests. Performance R2 registers 109 tests by adding cache source/config/equivalence and engineering-diagnostic contracts.

## R2.1 MESHGRID/NDGRID warning hotfix

MATLAB runtime validation of the first R2 package exposed a warning flood from
`griddedInterpolant` during observability/LOS matrix queries:
`Query data is in MESHGRID format, NDGRID format will yield better performance.`

R2.1 changes only the cached terrain-query adapter:
- equal-sized X/Y query arrays are flattened into paired column point lists;
- interpolation is evaluated with the same cached `griddedInterpolant`;
- output is reshaped to the caller's original dimensions;
- unusual differently-shaped grid/broadcast queries keep the historical
  `interp2` fallback.

No objective, constraint, decoder topology rule, Mission Band, A3, A6, DEM
resolution, or formal threshold is changed. The existing terrain cache
regression test now also covers matrix/LOS queries, scalar expansion, numerical
equivalence to `interp2`, and absence of emitted warnings.
