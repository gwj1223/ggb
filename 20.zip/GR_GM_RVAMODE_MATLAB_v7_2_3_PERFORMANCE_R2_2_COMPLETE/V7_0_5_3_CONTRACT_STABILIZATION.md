# GR-GM-RVAMODE-VI v7.0.5.3 — Contract Stabilization

This release does not change the formal monitoring thresholds, five objectives,
population size, generation budget, A1, A6, Dense-3D corridor screening, or the
Unified Mission Deficit hierarchy.

It removes two remaining duplicated A3 contracts and hardens the test harness.

## 1. Canonical target repair urgency

`evaluation.missionRepairTargetDeficits` is now the single source of truth for
per-target repair urgency. Both `selectMonitoringRepairTarget` and
`assessMissionRepairCandidate` call it, preventing selector/acceptor formula drift.

## 2. Canonical protected population write-back

`core.applyUnifiedMissionRepairReplacements` owns the base-to-trial A3 write-back.
Unified A3 remains a protected repair operator and does not reintroduce a second
environmental selection or any historical mission-memory mechanism.

## 3. Behavior-based A3 policy test

`test_a3_mission_progress_policy` now verifies target-gain semantics, static and
protection rejection, and actual replacement behavior. It no longer requires a
particular whitespace-sensitive assignment statement in source text.

## 4. Full-suite failure aggregation

`run_all_tests` now executes every registered test, records all failures, prints a
single summary, and raises one final error only after the suite has completed.
This prevents serial one-error-per-run debugging.

## Invariants retained

- 5 objectives
- population 96
- max generations 220
- Qmin 0.33
- Critical quality 0.42
- Critical observation length 180 m
- Critical LOS 0.45
- AGL 60–320 m
- max climb 22 deg
- max turn 95 deg
- mission formation Gen25
- formal mission stage Gen100
- one Unified A3 only
