# GR-GM-RVAMODE-VI v7.0.0 Logic Consolidated — TestFix v7.0.0.2 COMPLETE

This is a complete project package built from the uploaded `10.3.zip` baseline.

## Scope
- Production algorithm/config/source MATLAB files are byte-for-byte unchanged.
- v7.0.0.1 allocator test semantics are retained.
- v7.0.0.2 removes the stale `snapFinalFeasibleRate == 0.05` integration assertion from `test_local_agl_envelope`.
- Adds `test_v700_test_contract_hygiene` to prevent future pre-v7 integration-contract coupling.
- `run_all_tests.m` registers 70 tests.

## Active v7 contract checked
- Unified Mission Deficit enabled.
- Legacy feasibility-feedback threshold controller disabled in the v7 multi-UAV path.
- Componentwise legacy threshold updates disabled.
- Formal Shiyan-G1 AGL envelope remains 60–320 m.

## Run
```matlab
restoredefaultpath;
clear functions;
clear classes;
rehash toolboxcache;
clc;
close all;
setupProject(pwd);
run_all_tests
```

## Validation note
Static package/hygiene/hash validation was completed in the build environment. MATLAB/Octave numerical execution was not available here, so the full runtime suite must still be run in MATLAB.
