# GR-GM-RVAMODE-VI v7.2.3 算法主线梳理

## 1. 研究问题

面向真实 DEM 上的多无人机地质监测路径规划，将“飞行可行性、地质目标观测质量、多目标搜索和多机执行安全”统一到同一个多阶段优化框架中。

当前正式 Shiyan-G1 设置中，3 架 UAV 先进行协同目标分配，每个典型 UAV 子问题包含 10 个监测目标。进化变量不再直接优化 42 个内部 XYZ 航点的 126 个自由坐标，而是优化 51 维结构化语义基因；decoder 再把语义基因确定性映射回完全相同的 42 航点 / 126D phenotype，因此下游正式评价器、物理约束和五目标定义保持不变。

## 2. 整体执行链

```text
真实 DEM / LOS 静态知识
        -> 可观测性驱动的多 UAV 协同目标分配
        -> A1 Monitoring-Guided Initialization
        -> 51D Structured Monitoring Evolution
        -> 3D-Feasibility-First Structured Decoder (v7.2.3)
        -> 五目标 GR-GM-RVAMODE 搜索
        -> Unified Mission Deficit + Mission Band
        -> ONE A3 Unified Mission Repair
        -> Formal Archive (D_M = 0)
        -> A6 Risk-Balanced Representative Selection
        -> Dense final AGL verification
        -> Fleet scheduling / temporal deconfliction
```

可以把你的方法概括成三个逻辑层：

```text
Search  ->  Mission  ->  Safety
```

- **Search**：GR-GM-RVAMODE + reference-vector / archive / structured representation 负责找到多目标高质量路径。
- **Mission**：Mission Deficit、Mission Band 与唯一 A3 修复确保监测任务真正完成，而不是仅靠路径代价间接“希望”覆盖目标。
- **Safety**：静态 3D 物理约束、A6 代表解选择、最终 Dense AGL 验证和多机时序消冲突保证最终方案可执行。

## 3. A1 / A3 / A6 三个核心贡献

### A1 — Monitoring-Guided Initialization

初始化不再完全随机地搜索 3D 航点，而是使用监测目标、可观测扇区、LOS 与地形知识构造更接近地质监测任务的初始个体。作用是给搜索提供“任务相关”的初始结构，而不是直接保证最终任务完成。

### A3 — Unified Mission Repair

A3 是唯一的任务修复模块。它由 Unified Mission Deficit 驱动，只在已有静态可行载体上针对监测缺口进行受限修复。历史上的 TargetMemory、PersistentRepair、MissionCarrier、EmergencyRepair 等重叠机制已经被逻辑合并，不再并行抢同一职责。

A3 的职责必须保持：

```text
static-feasible carrier -> repair monitoring deficit
```

而不是：

```text
repair decoder / terrain reachability failure
```

### A6 — Risk-Balanced Selection

从满足正式任务约束的 Pareto / reference-vector 候选中选择最终代表解，在路径质量与风险之间做有约束的代表性折中。A6 不重新定义优化问题，而是负责“最终选哪一个可执行方案”。

## 4. 五目标与 Mission Deficit 的关系

你的正式优化仍然是 **五目标**。Mission Deficit `D_M` 是任务可行性 / 排序量，不是第六目标。

这一区分很重要：

- 五目标负责 Pareto trade-off；
- `D_M` 负责回答“监测任务是否完成、差多少”；
- Mission Band 防止在任务形成阶段所有候选被压缩为单一 `D_M` 标量排序，从而保护多目标搜索能力。

## 5. v7.2.x 的关键科学升级：结构化监测编码

### v7.1.1 以前

直接优化：

```text
42 internal XYZ waypoints = 126D free coordinates
```

这种编码自由度高，但进化操作不知道哪些变量对应“观测目标”“观测弧”“过渡段”“高度偏好”，因此大量搜索预算浪费在任务结构不合理的几何上。

### v7.2.0 起

正常 10-target 子问题改为：

```text
5*M + 1 = 51D semantic genotype
          |
          v
structured decoder
          |
          v
42 XYZ waypoints = 126D phenotype
```

核心科学假设变成：

> 对三维地质监测路径规划，优先优化“任务与监测结构参数”，比直接优化 126 个自由 XYZ 坐标更符合问题结构。

这也是未来正式消融中 `v7.1.1 126D` 对 `v7.2.x 51D` 的核心比较。

## 6. structured decoder 的职责

51D 基因主要描述每个监测目标附近的观测弧结构与各 transit leg 的语义偏置；decoder 必须在固定 42-waypoint 预算下完成两件事：

1. 保留监测目标附近的 observation geometry；
2. 使用剩余 connector nodes 把 Start、各 observation arc 和 Goal 连成满足 3D 飞行约束的连续路径。

因此 decoder 不是普通的坐标变换，而是 semantic search space 与 physical feasible space 之间的关键映射层。

## 7. v7.2.0 -> v7.2.1 -> v7.2.2 暴露的问题

### v7.2.0

语义编码能够形成监测任务，完整三机实验曾出现三个 UAV 都达到 `D_M=0`。但 UAV-2 最终 static infeasible：固定 connector 分配把最后 target -> Goal 分到了 0 个 connector，导致 turn > 95 deg；同时 turn-only failure 还错误丢弃了已经成功的 Dense-3D Z profile。

### v7.2.1

修复了边界 connector 与 Dense Z preservation，并成功解决 UAV-2；但把每个 leg 的 connector 上限压成 1，反而禁止了 UAV-1 已知需要的首段 2-connector 拓扑，导致 decoder 过于刚性。

### v7.2.2

引入 Adaptive Connector Allocation：每个 transit leg 允许 0/1/2 connector，总 connector budget 固定为 8，按局部转角边际收益进行分配。这恢复了 UAV-1 已知的 `[2 1 1 1 1 1 0 0 0 0 1]` 型拓扑。

但最新 UAV-1 focused run 出现更深层瓶颈：连续大量世代 `DenseOK=0/96` 且 `fail[reach/turn/other]=[96 0 0]`。说明 connector **数量**已经更合理，但 tangent-aware connector **位置**会为了二维 turn 把 XY 拉到无法满足 22 deg climb + 60--320 m AGL 的三维可达区域之外。

## 8. v7.2.3 — 3D-Feasibility-First Structured Decoder

v7.2.3 的原则不是“再调 tangent 参数”，而是修改 decoder 的优先级：

```text
3D reachability > turn feasibility > turn margin > path quality
```

### 8.1 Connector topology candidates

保留 v7.2.2 的 primary adaptive allocation，但不再把它当成唯一拓扑。构造一个很小的、固定 budget 的候选集合：

- primary turn-aware allocation；
- terrain/distance-first；
- spread-first；
- chord-turn + terrain hybrid；
- 少量围绕 primary 的 one-node budget-preserving transfers。

约束仍保持：

```text
sum(connectors) = 8
0 <= connector_i <= 2
boundary legs retain configured protection
```

### 8.2 Stage 1 — Dense-first carrier

对每个 topology，先使用：

```text
straight chord geometry + semantic lateral bias
```

并依次尝试 bias scale：

```text
1.0 -> 0.5 -> 0.0
```

每一个 XY candidate 都立刻调用同一个正式 Dense-3D terrain reachable projector。若 Dense 失败，不允许 tangent “救 turn”，而是直接尝试下一个 bias / topology。

### 8.3 Stage 2 — Reachability-preserving turn refinement

只有已经存在：

```text
DenseOK = 1
```

但：

```text
maxTurn > 95 deg
```

时，才尝试 tangent smoothing。使用渐进 blend：

```text
0.25 -> 0.50 -> 0.75 -> 1.00
```

每一级都重新执行 Dense-3D projector；任何会破坏 AGL / climb / reachability 的 smoothing 立即拒绝。

因此 turn 永远不能通过牺牲 3D feasibility 来换取。

## 9. 当前正式冻结参数

```text
Population                 96
Max generations            220
Objectives                 5
Qmin                       0.33
Critical Q                 0.42
Critical observation       180 m
Critical LOS               0.45
AGL                        60--320 m
Max climb                  22 deg
Max turn                   95 deg
Mission formation start    Gen25
Formal stage start          Gen100
```

在 v7.2.3 decoder 验证阶段，不应通过放宽 22 deg / 95 deg / AGL 范围来制造“成功”。

## 10. 当前验证顺序

不要先跑 30 seeds，也不要直接跑完整 main。

```text
Gate 0  decoder-only UAV-1
        DenseOK must become > 0
          |
Gate 1  UAV-1 focused evolution
        DenseOK -> DecodeOK -> static -> finite D -> D=0 -> formal
          |
Gate 2  UAV-2 regression
        keep Dense/static feasible, D=0, turn<=95, FinalFeasible=1
          |
Gate 3  full 3-UAV main
          |
Gate 4  10-seed preliminary robustness
          |
Gate 5  30-seed formal robustness + baselines + ablations
```

## 11. 论文层面的算法故事

你的工作不应该写成“不断给 MODE 加补丁”。更清晰的论文逻辑是：

1. **问题结构**：真实 DEM 上的多 UAV 地质监测同时包含多目标路径质量、任务观测和严格飞行约束。
2. **表示层贡献**：用 monitoring-structured semantic genotype 替代自由 XYZ 进化，使搜索变量对应真实监测结构。
3. **可行性映射贡献**：用 3D-feasibility-first decoder 将结构化任务变量可靠映射到物理可飞 phenotype。
4. **任务层贡献**：Mission Deficit + Mission Band + 单一 A3 处理“监测任务是否完整”，而不污染五目标定义。
5. **决策与执行层贡献**：A6 + Dense final verification + fleet scheduling 输出最终风险平衡且可执行的多机方案。

可以压缩成一句话：

> 你的方法不是单纯优化 3D 航点，而是在“监测语义空间”中搜索，再通过可行性优先的结构化解码器映射到真实 DEM 上的可执行多 UAV 航迹，并用显式任务缺口与风险平衡机制完成从搜索到任务再到安全的闭环。
