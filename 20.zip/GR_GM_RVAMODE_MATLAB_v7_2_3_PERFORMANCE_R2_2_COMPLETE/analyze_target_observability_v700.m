clear; clc; close all;
%ANALYZE_TARGET_OBSERVABILITY_V700 Rank targets and visible-sector geometry.
projectRoot = fileparts(mfilename('fullpath'));
setupProject(projectRoot);
cfg = config.multiUAVShiyanConfig();
[problem,cfg] = realdata.buildShiyanG1Problem(projectRoot,cfg);
kb = multiUAV.buildMonitoringKnowledgeBase(problem,cfg);
obs = kb.observability;
M = size(problem.monitorTargets,1);

Target = (1:M)';
Label = string(problem.monitorTargetLabels(:));
Critical = false(M,1); Critical(cfg.criticalTargetIndices(:)) = true;
RiskProxy = reshape([problem.monitorTargetMeta.risk],[],1);
Slope_deg = reshape([problem.monitorTargetMeta.slopeDeg],[],1);
ObservabilityScore = obs.score(:);
ObservabilityDifficulty = obs.difficulty(:);
VisibleViewFraction = obs.visibleFraction(:);
ValidViewFraction = obs.validViewFraction(:);
MaxVisibleArcLength_m = obs.maxVisibleArcLength_m(:);
BestRadiusScale = obs.bestRadiusScale(:);
BestSectorCenter_deg = obs.bestSectorCenterDeg(:);
BestSectorHalfWidth_deg = obs.bestSectorHalfWidthDeg(:);
BestVisibleRunCount = obs.bestVisibleRunCount(:);
T = table(Target,Label,Critical,RiskProxy,Slope_deg,ObservabilityScore, ...
    ObservabilityDifficulty,VisibleViewFraction,ValidViewFraction, ...
    MaxVisibleArcLength_m,BestRadiusScale,BestSectorCenter_deg, ...
    BestSectorHalfWidth_deg,BestVisibleRunCount);
T = sortrows(T,'ObservabilityDifficulty','descend');

disp(T(1:min(15,height(T)),:));
outFile = fullfile(projectRoot,'target_observability_v700.csv');
writetable(T,outFile);
fprintf('Saved: %s\n',outFile);
