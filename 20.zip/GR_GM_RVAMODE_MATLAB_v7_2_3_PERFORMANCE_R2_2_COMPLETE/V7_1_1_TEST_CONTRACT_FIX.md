# v7.1.1 Test Contract Fix

This package is algorithmically identical to v7.1.1 Protection Hysteresis.

## Runtime evidence
The MATLAB suite reached 90/91. The only failure was:

`test_a3_mission_progress_policy` line 75

The failing assertion used:

```matlab
exist('evaluation.assessMissionProtection','file')==2
```

That is not a reliable existence test for a function inside a MATLAB `+package` namespace. The production helper was already proven callable by the passing formation and formal protection tests.

## Fix
The assertion is replaced by MATLAB package-function resolution:

```matlab
~isempty(which('evaluation.assessMissionProtection'))
```

No production MATLAB file under `src/` or `+config/` is changed. No threshold, selection rule, Mission Deficit rule, A3 acceptance rule, Dense-3D logic, or archive behavior is changed.

Re-run `run_all_tests`; expected registered count remains 91.
