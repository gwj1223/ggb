function [pop,stats] = unifiedMissionRepair(pop,problem,cfg,generation)
%UNIFIEDMISSIONREPAIR Single bounded mission-aware A3 repair in v7.2.0.
%
% The active A3 path is:
%   current static-feasible base
%     -> selected mission-bottleneck target
%     -> cheap radius/sector geometry pool
%     -> dense DEM AGL+climb reachability + 3D turn precheck
%     -> full repair/evaluation of only the best screened variants
%     -> global-D monotone + stage-aware protection acceptance
%     -> protected base-to-trial replacement.
%
% Geometry screening consumes no objective-evaluation budget. The formal full
% evaluation cap remains missionRepairMaxEvaluationsPerEvent. No historical
% chromosome, mission carrier memory, persistent repair, or sixth objective is
% introduced.

stats=core.emptyUnifiedMissionRepairStats();
if isempty(pop) || ~localCfg(cfg,'enableUnifiedMissionRepair',false), return; end
if generation<round(localCfg(cfg,'missionRepairStartGeneration',25)), return; end

N=numel(pop);
staticOK=arrayfun(@(x)localStaticFeasible(x,cfg),pop(:));
if ~any(staticOK), return; end
D=inf(N,1);
for i=find(staticOK(:))'
    D(i)=evaluation.finalMonitoringDeficit(pop(i),cfg);
end
stats.bestDeficitBefore=min(D);
formalMask=localFormalStaticMask(pop,staticOK,cfg);
stats.formalCarrierCountBefore=sum(formalMask);
desiredFormal=max(1,round(localCfg(cfg,'missionRepairDesiredFormalCarriers',3)));
if stats.formalCarrierCountBefore>=desiredFormal
    stats.bestDeficitAfter=stats.bestDeficitBefore;
    stats.formalCarrierCountAfter=stats.formalCarrierCountBefore;
    return;
end

componentTol=localCfg(cfg,'missionDeficitComponentTolerance',1e-12);
candidateIdx=find(staticOK(:) & isfinite(D) & D>componentTol);
% v7.1.0 keeps A3 exploitation inside the mission leader band when that
% search contract is active. Base diversification then spreads the limited A3
% budget across different bottleneck targets within those leaders.
if localCfg(cfg,'enableMissionBandSelection',false)
    bandState=selection.missionBandState(pop,cfg,generation,N);
    bandCandidates=find(bandState.searchAdmissible & isfinite(D) & D>componentTol);
    if ~isempty(bandCandidates)
        candidateIdx=bandCandidates;
    end
end
if isempty(candidateIdx)
    stats.bestDeficitAfter=stats.bestDeficitBefore;
    stats.formalCarrierCountAfter=stats.formalCarrierCountBefore;
    return;
end
[candidateIdx,candidateTargets]=core.selectMissionRepairBases( ...
    pop,candidateIdx,D,cfg);
baseCount=numel(candidateIdx);
fullVariants=max(1,round(localCfg(cfg,'missionRepairVariants',3)));
geometryPool=max(fullVariants,round(localCfg(cfg,'missionRepairGeometryPoolSize',9)));
maxEvaluations=max(1,round(localCfg(cfg, ...
    'missionRepairMaxEvaluationsPerEvent',12)));

replacementIdx=zeros(baseCount,1);
replacements=pop([]);
replacementCount=0;

for q=1:baseCount
    if stats.evaluations>=maxEvaluations, break; end
    baseIndex=candidateIdx(q);
    base=pop(baseIndex);
    if ~isfield(base,'monitorStats') || isempty(base.monitorStats), continue; end

    targetIndex=candidateTargets(q);
    if ~isscalar(targetIndex) || ~isfinite(targetIndex), continue; end
    stats.attemptedBases=stats.attemptedBases+1;
    stats.targets(end+1)=targetIndex; %#ok<AGROW>
    stats.baseDeficits(end+1)=D(baseIndex); %#ok<AGROW>
    stats.uniqueTargetCount=numel(unique(stats.targets));

    % Cheap geometry pool. Only candidates with a real dense straight-segment
    % altitude solution are allowed to consume a full objective evaluation.
    screenedTrials=cell(geometryPool,1);
    screenedScore=-inf(geometryPool,1);
    screenedCount=0;
    for geometryVariant=1:geometryPool
        if localCfg(cfg,'enableStructuredMonitoringEncoding',false) && ...
                isfield(base,'structuredGenes') && ~isempty(base.structuredGenes)
            [candidate,pre]=core.injectStructuredMonitoringParameters( ...
                base,targetIndex,problem,cfg,geometryVariant);
        else
            [candidate,pre]=core.injectTargetObservationArc( ...
                base,targetIndex,problem,cfg,geometryVariant);
        end
        stats.geometryCandidates=stats.geometryCandidates+1;
        if ~pre.success
            stats=localCountPrecheck(stats,pre);
            continue;
        end
        screenedCount=screenedCount+1;
        screenedTrials{screenedCount}=candidate;
        screenedScore(screenedCount)=pre.score;
        stats.precheckPassed=stats.precheckPassed+1;
        if isfield(pre,'blockCount') && isfinite(pre.blockCount)
            stats.maximumScreenedBlock=max(stats.maximumScreenedBlock,pre.blockCount);
        end
        if isfield(pre,'profileInfo') && isstruct(pre.profileInfo) && ...
                isfield(pre.profileInfo,'minimumSlack') && ...
                isfinite(pre.profileInfo.minimumSlack)
            stats.bestPrecheckSlack=max(stats.bestPrecheckSlack, ...
                pre.profileInfo.minimumSlack);
        end
    end
    if screenedCount==0, continue; end
    [~,screenOrder]=sort(screenedScore(1:screenedCount),'descend');
    fullCount=min(fullVariants,screenedCount);

    bestTrial=[];
    bestTargetGain=-inf;
    bestTrialDeficit=inf;
    for s=1:fullCount
        if stats.evaluations>=maxEvaluations, break; end
        trial=screenedTrials{screenOrder(s)};
        structuredMode=localCfg(cfg,'enableStructuredMonitoringEncoding',false) && ...
            isfield(trial,'structuredGenes') && ~isempty(trial.structuredGenes);
        if ~structuredMode
            trial=repair.repairPath(trial,problem,cfg);
        end
        trial=evaluation.evaluateIndividual(trial,problem,cfg,generation);
        stats.evaluations=stats.evaluations+1;

        assessment=evaluation.assessMissionRepairCandidate( ...
            trial,base,targetIndex,cfg,generation);
        stats=localCountAssessment(stats,assessment,trial,cfg);
        if ~assessment.eligible, continue; end
        stats.eligibleTrials=stats.eligibleTrials+1;
        if assessment.targetGain>bestTargetGain+1e-12 || ...
                (abs(assessment.targetGain-bestTargetGain)<=1e-12 && ...
                assessment.trialTotalDeficit<bestTrialDeficit-1e-12)
            bestTrial=trial;
            bestTargetGain=assessment.targetGain;
            bestTrialDeficit=assessment.trialTotalDeficit;
        end
    end

    if ~isempty(bestTrial)
        replacementCount=replacementCount+1;
        replacementIdx(replacementCount)=baseIndex;
        replacements(replacementCount,1)=bestTrial; %#ok<AGROW>
        stats.bestTargetGain=max(stats.bestTargetGain,bestTargetGain);
        stats.targetGainSum=stats.targetGainSum+bestTargetGain;
    end
end

if replacementCount>0
    replacementIdx=replacementIdx(1:replacementCount);
    replacements=replacements(1:replacementCount);
    pop=core.applyUnifiedMissionRepairReplacements( ...
        pop,replacementIdx,replacements);
    stats.accepted=replacementCount;
    stats.event=true;
end

Dafter=inf(numel(pop),1);
staticAfter=arrayfun(@(x)localStaticFeasible(x,cfg),pop(:));
for i=find(staticAfter(:))'
    Dafter(i)=evaluation.finalMonitoringDeficit(pop(i),cfg);
end
stats.bestDeficitAfter=min(Dafter);
stats.formalCarrierCountAfter=sum(localFormalStaticMask(pop,staticAfter,cfg));
end


function stats=localCountPrecheck(stats,pre)
reason='other';
if isstruct(pre) && isfield(pre,'reason'), reason=char(pre.reason); end
if strcmp(reason,'turn')
    stats.precheckRejectTurn=stats.precheckRejectTurn+1;
elseif contains(reason,'reach') || contains(reason,'agl') || ...
        contains(reason,'climb') || contains(reason,'terrain')
    stats.precheckRejectReach=stats.precheckRejectReach+1;
else
    stats.precheckRejectOther=stats.precheckRejectOther+1;
end
end

function stats=localCountAssessment(stats,assessment,trial,cfg)
if assessment.eligible, return; end
switch char(assessment.reason)
    case 'static'
        stats.rejectStatic=stats.rejectStatic+1;
        tol=localCfg(cfg,'constraintTolerance',1e-8);
        stats.staticCollision=stats.staticCollision+ ...
            localViolationFlag(trial,'collision',tol);
        stats.staticClearance=stats.staticClearance+ ...
            localViolationFlag(trial,'clearance',tol);
        stats.staticClimb=stats.staticClimb+ ...
            localViolationFlag(trial,'climb',tol);
        stats.staticTurn=stats.staticTurn+ ...
            localViolationFlag(trial,'turn',tol);
        stats.staticEnergy=stats.staticEnergy+ ...
            localViolationFlag(trial,'energy',tol);
        if isfield(trial,'aglStats') && isstruct(trial.aglStats)
            if isfield(trial.aglStats,'lowerViolation') && ...
                    isfinite(trial.aglStats.lowerViolation) && ...
                    trial.aglStats.lowerViolation>tol
                stats.staticLowerAGL=stats.staticLowerAGL+1;
            end
            if isfield(trial.aglStats,'upperViolation') && ...
                    isfinite(trial.aglStats.upperViolation) && ...
                    trial.aglStats.upperViolation>tol
                stats.staticUpperAGL=stats.staticUpperAGL+1;
            end
            if isfield(trial.aglStats,'minimumAGL') && ...
                    isfinite(trial.aglStats.minimumAGL)
                stats.worstMinimumAGL=min(stats.worstMinimumAGL, ...
                    trial.aglStats.minimumAGL);
            end
            if isfield(trial.aglStats,'maximumAGL') && ...
                    isfinite(trial.aglStats.maximumAGL)
                stats.worstMaximumAGL=max(stats.worstMaximumAGL, ...
                    trial.aglStats.maximumAGL);
            end
        end
        stats.worstMaxClimbDeg=max(stats.worstMaxClimbDeg,localMaxClimbDeg(trial));
    case 'global_regression'
        stats.rejectGlobalRegression=stats.rejectGlobalRegression+1;
    case {'protected_component','protected_q','protected_critical_q', ...
            'protected_observation','protected_los','protected_target'}
        stats.rejectProtection=stats.rejectProtection+1;
        stats=localCountProtection(stats,assessment);
    case 'target_no_gain'
        stats.rejectTargetNoGain=stats.rejectTargetNoGain+1;
    otherwise
        stats.rejectInvalid=stats.rejectInvalid+1;
end
end


function stats=localCountProtection(stats,assessment)
reason=char(assessment.reason);
switch reason
    case 'protected_component'
        stats.rejectProtectionComponent=stats.rejectProtectionComponent+1;
    case {'protected_q','protected_target'}
        stats.rejectProtectionQ=stats.rejectProtectionQ+1;
    case 'protected_critical_q'
        stats.rejectProtectionCriticalQ=stats.rejectProtectionCriticalQ+1;
    case 'protected_observation'
        stats.rejectProtectionObservation=stats.rejectProtectionObservation+1;
    case 'protected_los'
        stats.rejectProtectionLOS=stats.rejectProtectionLOS+1;
end

if ~isfield(assessment,'protection') || ~isstruct(assessment.protection)
    return;
end
p=assessment.protection;
gap=0;
if isfield(p,'violationGap') && isscalar(p.violationGap) && isfinite(p.violationGap)
    gap=max(0,p.violationGap);
end
if gap < stats.protectionWorstGap-1e-15
    return;
end
stats.protectionWorstGap=gap;
if isfield(p,'targetIndex'), stats.protectionWorstTarget=p.targetIndex; end
if isfield(p,'componentIndex'), stats.protectionWorstComponent=p.componentIndex; end
if isfield(p,'reason'), stats.protectionWorstCondition=char(p.reason); end
if isfield(p,'stage'), stats.protectionWorstStage=char(p.stage); end
if isfield(p,'baseValue'), stats.protectionWorstBaseValue=p.baseValue; end
if isfield(p,'trialValue'), stats.protectionWorstTrialValue=p.trialValue; end
if isfield(p,'formalThreshold'), stats.protectionWorstThreshold=p.formalThreshold; end
if isfield(p,'entryThreshold'), stats.protectionWorstEntryThreshold=p.entryThreshold; end
end

function flag=localViolationFlag(ind,name,tol)
flag=0;
if isfield(ind,'violation') && isstruct(ind.violation) && ...
        isfield(ind.violation,name)
    value=ind.violation.(name);
    if isscalar(value) && isfinite(value) && value>tol, flag=1; end
end
end

function value=localMaxClimbDeg(ind)
value=0;
if ~isfield(ind,'path') || size(ind.path,1)<2, return; end
seg=diff(ind.path,1,1);
h=hypot(seg(:,1),seg(:,2));
a=atan2d(abs(seg(:,3)),max(h,eps));
if ~isempty(a) && all(isfinite(a)), value=max(a); end
end

function mask=localFormalStaticMask(pop,staticOK,cfg)
mask=false(numel(pop),1);
try
    formal=evaluation.checkFinalMonitoringFeasibility(pop,cfg);
    mask=reshape(formal,[],1) & reshape(staticOK,[],1);
catch
end
end

function tf=localStaticFeasible(ind,cfg)
tol=localCfg(cfg,'constraintTolerance',1e-8);
tf=isfield(ind,'staticCV') && isfinite(ind.staticCV) && ind.staticCV<=tol;
end

function value=localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value=cfg.(name); else, value=defaultValue; end
end
