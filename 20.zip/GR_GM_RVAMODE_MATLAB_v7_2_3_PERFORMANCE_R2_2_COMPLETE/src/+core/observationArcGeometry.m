function geom = observationArcGeometry(targetIndex,problem,cfg,routeDirection, ...
    variant,baseHalfAngleDeg,radiusMultiplier)
%OBSERVATIONARCGEOMETRY Shared v7.0.0 DEM/LOS knowledge geometry.
%
% The function does not evaluate mission feasibility. It only converts the
% deterministic target observability proxy into a preferred radius/direction
% for A1 initialization and A3 local repair. Formal LOS/quality/observation
% length are still evaluated by evaluation.monitoringQuality.

if nargin < 4 || isempty(routeDirection), routeDirection = [1 0]; end
if nargin < 5 || isempty(variant), variant = 1; end
if nargin < 6 || isempty(baseHalfAngleDeg)
    baseHalfAngleDeg = localCfg(cfg,'monitorGuidedViewAngleDeg',28);
end
if nargin < 7 || isempty(radiusMultiplier), radiusMultiplier = 1; end

T = problem.monitorTargets;
if targetIndex < 1 || targetIndex > size(T,1)
    error('core:InvalidObservationTarget','Invalid target index %d.',targetIndex);
end
isCritical = ismember(targetIndex,cfg.criticalTargetIndices(:)');
routeDirection = localUnit(routeDirection,[1 0]);

preferredScale = 1;
preferredDirection = routeDirection;
sectorHalfWidth = pi;
hasHint = localCfg(cfg,'enableObservabilityGuidedMonitoringArcs',false) && ...
    isfield(problem,'monitorTargetBestRadiusScale') && ...
    numel(problem.monitorTargetBestRadiusScale)>=targetIndex && ...
    isfield(problem,'monitorTargetBestSectorCenterRad') && ...
    numel(problem.monitorTargetBestSectorCenterRad)>=targetIndex;
if hasHint
    preferredScale = problem.monitorTargetBestRadiusScale(targetIndex);
    if ~isfinite(preferredScale) || preferredScale<=0, preferredScale = 1; end
    theta = problem.monitorTargetBestSectorCenterRad(targetIndex);
    if isfinite(theta)
        preferredDirection = [cos(theta) sin(theta)];
    end
    if isfield(problem,'monitorTargetBestSectorHalfWidthRad') && ...
            numel(problem.monitorTargetBestSectorHalfWidthRad)>=targetIndex
        sectorHalfWidth = problem.monitorTargetBestSectorHalfWidthRad(targetIndex);
        if ~isfinite(sectorHalfWidth) || sectorHalfWidth<=0
            sectorHalfWidth = pi;
        end
    end

    if isCritical
        blend = localCfg(cfg,'monitoringArcObservabilityBlendCritical',0.90);
    else
        blend = localCfg(cfg,'monitoringArcObservabilityBlendOrdinary',0.55);
    end
    blend = min(max(blend,0),1);
    combined = (1-blend)*routeDirection + blend*preferredDirection;
    preferredDirection = localUnit(combined,preferredDirection);
end

scaleBounds = localCfg(cfg,'monitoringArcRadiusScaleBounds',[0.75 1.25]);
if numel(scaleBounds)~=2 || any(~isfinite(scaleBounds))
    scaleBounds = [0.75 1.25];
end
scaleBounds = sort(scaleBounds(:)');
preferredScale = min(max(preferredScale,scaleBounds(1)),scaleBounds(2));
radius = max(T(targetIndex,4),eps)*radiusMultiplier*preferredScale;

% Repair variants stay inside/near the best visible sector rather than
% enumerating the full 360 degrees. Variant 1 always uses the sector centre.
if hasHint && variant>1
    variants = max(1,round(localCfg(cfg,'missionRepairVariants',3)));
    spanFraction = min(max(localCfg(cfg,'monitoringArcVariantSpanFraction',0.70),0),1);
    maxOffset = spanFraction*sectorHalfWidth;
    maxOffset = min(maxOffset,deg2rad(localCfg(cfg, ...
        'monitoringArcVariantMaxOffsetDeg',65)));
    signed = localVariantCoordinate(variant,variants);
    preferredDirection = localRotate(preferredDirection,signed*maxOffset);
end

baseHalf = deg2rad(max(baseHalfAngleDeg,1));
halfAngle = baseHalf;
if hasHint && sectorHalfWidth < pi-1e-9
    minimumHalf = deg2rad(localCfg(cfg,'monitoringArcMinimumHalfAngleDeg',22));
    sectorCap = max(minimumHalf, ...
        localCfg(cfg,'monitoringArcSectorUseFraction',0.82)*sectorHalfWidth);
    halfAngle = min(baseHalf,sectorCap);
end

geom.radius = radius;
geom.direction = localUnit(preferredDirection,routeDirection);
geom.halfAngleRad = halfAngle;
geom.preferredRadiusScale = preferredScale;
geom.sectorHalfWidthRad = sectorHalfWidth;
geom.usedObservabilityHint = hasHint;
geom.isCritical = isCritical;
end

function x = localVariantCoordinate(variant,variants)
% Sequence: 0, +0.5, -0.5, +1, -1, then evenly wrapped values.
seq = [0 0.5 -0.5 1 -1];
if variant<=numel(seq)
    x = seq(variant);
    return;
end
q = max(variant-1,1);
span = max(variants-1,1);
x = -1+2*mod(q,span)/span;
end

function v = localUnit(v,fallback)
if numel(v)~=2 || any(~isfinite(v)) || norm(v)<1e-10
    v = fallback;
end
if numel(v)~=2 || any(~isfinite(v)) || norm(v)<1e-10
    v = [1 0];
end
v = reshape(v,1,2)/(norm(v)+eps);
end

function v = localRotate(v,a)
R = [cos(a) -sin(a);sin(a) cos(a)];
v = (R*v(:))';
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
