function [z,info] = projectDenseTerrainReachableProfile( ...
    xy,startZ,endZ,preferredZ,problem,cfg,sampleCache)
%PROJECTDENSETERRAINREACHABLEPROFILE Dense AGL/climb projection for A3.
%
% v7.0.5 solves the actual straight-segment contract used by the chromosome.
% Every candidate waypoint altitude is propagated through the SAME adaptive
% DEM samples used by formal local-AGL evaluation. For a fixed previous node
% altitude, every dense sample on the straight segment yields an admissible
% interval for the next-node altitude. A small altitude grid performs a
% toolbox-free dynamic-programming search through these intervals.
%
% This differs critically from v7.0.4: the dense samples are constraints on
% the LINEAR waypoint-to-waypoint segment, not extra virtual Z waypoints.
%
% v7.2.3 Performance R2 optionally accepts a decoder-local containers.Map.
% Performance R2.2 additionally vectorizes the altitude-grid DP transition
% while retaining the scalar reference path behind a configuration switch.
% Reusing a cached sample is safe because the cache key includes both XY
% endpoints and the formal sampling policy; terrain values are not altered.

if nargin < 7
    sampleCache = [];
end
profileEnabled = localCfg(cfg,'enableStructuredPerformanceProfiling',true);

N = size(xy,1);
info = localEmptyInfo();
z = zeros(0,1);
if N<2 || size(xy,2)~=2 || any(~isfinite(xy(:))) || ...
        ~isscalar(startZ) || ~isscalar(endZ) || ...
        ~isfinite(startZ) || ~isfinite(endZ)
    info.reason = 'invalid';
    return;
end

nodeTerrain = data.terrainHeight(problem,xy(:,1),xy(:,2));
nodeTerrain = nodeTerrain(:);
if any(~isfinite(nodeTerrain))
    info.reason = 'terrain';
    return;
end

margin = max(0,localCfg(cfg,'segmentRepairMargin',0));
safe = localCfg(cfg,'safeClearance',0);
maxAltitude = localCfg(cfg,'maxAltitude',inf);
useUpper = localCfg(cfg,'enableLocalAGLConstraint',false) && ...
    isfield(cfg,'realMaximumAGL') && isfinite(cfg.realMaximumAGL);
% Keep the configured upper bound separate from observed AGL diagnostics.
% Reusing one variable for both caused v7.0.5.3 to turn the bound into -Inf
% during final verification and reject every otherwise feasible profile.
if useUpper
    allowedMaxAGL = cfg.realMaximumAGL;
else
    allowedMaxAGL = inf;
end

% Interior nodes keep the repair margin. The untouched boundary nodes obey
% the formal envelope so a valid base is not rejected merely for lacking the
% optional polishing margin.
nodeLower = nodeTerrain + safe + margin;
nodeUpper = maxAltitude*ones(N,1);
if useUpper
    nodeUpper = min(nodeUpper,nodeTerrain+allowedMaxAGL-margin);
end
formalLower = nodeTerrain + safe;
formalUpper = maxAltitude*ones(N,1);
if useUpper
    formalUpper = min(formalUpper,nodeTerrain+allowedMaxAGL);
end
tol = max(localCfg(cfg,'constraintTolerance',1e-8),1e-8);
if startZ<formalLower(1)-tol || startZ>formalUpper(1)+tol || ...
        endZ<formalLower(end)-tol || endZ>formalUpper(end)+tol
    info.reason='boundary_agl';
    return;
end
nodeLower(1)=startZ; nodeUpper(1)=startZ;
nodeLower(end)=endZ; nodeUpper(end)=endZ;
if any(nodeLower>nodeUpper+tol)
    info.reason='node_agl_interval';
    return;
end

if isscalar(preferredZ)
    preferred = repmat(preferredZ,N,1);
else
    preferred = preferredZ(:);
    if numel(preferred)~=N || any(~isfinite(preferred))
        preferred = 0.5*(nodeLower+nodeUpper);
    end
end
preferred = min(max(preferred,nodeLower),nodeUpper);

% Altitude discretization is only over chromosome nodes. Dense DEM samples
% remain exact inequalities for each candidate node-to-node straight line.
gridStep = max(0.5,localCfg(cfg,'missionRepairDenseAltitudeGridStep_m',2.0));
grids = cell(N,1);
for i=1:N
    if i==1
        grids{i}=startZ;
    elseif i==N
        grids{i}=endZ;
    else
        lo=nodeLower(i); hi=nodeUpper(i);
        if hi<lo-tol
            info.reason='node_agl_interval'; return;
        end
        firstGrid=ceil(lo/gridStep)*gridStep;
        lastGrid=floor(hi/gridStep)*gridStep;
        if firstGrid<=lastGrid
            g=(firstGrid:gridStep:lastGrid)';
        else
            g=zeros(0,1);
        end
        g=[g;lo;hi;preferred(i)]; %#ok<AGROW>
        grids{i}=unique(round(g*1e9)/1e9);
    end
end

cost = cell(N,1);
pred = cell(N,1);
cost{1}=0;
pred{1}=0;
maxClimb = localCfg(cfg,'maxClimbAngleDeg',90);
preferenceScale=max(20,0.25*max(1,allowedMaxAGL-safe));
if ~isfinite(preferenceScale), preferenceScale=50; end

segmentSamples = cell(N-1,1);
cacheHits=0; cacheMisses=0;
samplingTimer=tic;
for i=1:N-1
    [segmentSamples{i},wasHit]=localSegmentSample( ...
        xy(i,:),xy(i+1,:),problem,cfg,sampleCache);
    if wasHit, cacheHits=cacheHits+1; else, cacheMisses=cacheMisses+1; end
end
if profileEnabled
    info.terrainSamplingTime_s=toc(samplingTimer);
end
info.terrainSampleCacheHits=cacheHits;
info.terrainSampleCacheMisses=cacheMisses;

for i=1:N-1
    prevGrid=grids{i}; nextGrid=grids{i+1};
    prevCost=cost{i};
    if isempty(prevGrid) || isempty(nextGrid) || isempty(prevCost) || ...
            ~any(isfinite(prevCost))
        info.reason='dense_reach'; return;
    end
    nextCost=inf(numel(nextGrid),1);
    nextPred=zeros(numel(nextGrid),1);
    sample=segmentSamples{i};
    t=sample.t;
    terrain=sample.terrain;
    denseLower=terrain+safe+margin;
    denseUpper=maxAltitude*ones(size(terrain));
    if useUpper
        denseUpper=min(denseUpper,terrain+allowedMaxAGL-margin);
    end
    % At original local-corridor nodes use their node contract. This preserves
    % formal boundary feasibility while keeping margin at every true interior.
    denseLower(1)=nodeLower(i); denseUpper(1)=nodeUpper(i);
    denseLower(end)=nodeLower(i+1); denseUpper(end)=nodeUpper(i+1);
    if any(denseLower>denseUpper+tol)
        info.reason='dense_agl_interval'; return;
    end
    maxDz=tand(maxClimb)*max(sample.horizontalLength,eps);

    reachablePrev=find(isfinite(prevCost));
    if localCfg(cfg,'enableDenseProjectionVectorizedDP',true)
        [nextCost,nextPred]=localVectorizedTransition( ...
            prevGrid,nextGrid,prevCost,reachablePrev,denseLower,denseUpper, ...
            t,maxDz,nodeLower(i+1),nodeUpper(i+1),preferred(i+1), ...
            preferenceScale,tol);
    else
        [nextCost,nextPred]=localScalarTransition( ...
            prevGrid,nextGrid,prevCost,reachablePrev,denseLower,denseUpper, ...
            t,maxDz,nodeLower(i+1),nodeUpper(i+1),preferred(i+1), ...
            preferenceScale,tol);
    end
    if ~any(isfinite(nextCost))
        info.reason='dense_reach';
        info.failedSegment=i;
        return;
    end
    cost{i+1}=nextCost;
    pred{i+1}=nextPred;
end

[bestCost,lastIdx]=min(cost{N});
if ~isfinite(bestCost)
    info.reason='end_reach'; return;
end
z=zeros(N,1);
idx=lastIdx;
for i=N:-1:1
    z(i)=grids{i}(idx);
    if i>1
        idx=pred{i}(idx);
        if idx<1
            z=zeros(0,1); info.reason='backtrack'; return;
        end
    end
end

% Exact verification with the shared sampler. This tests the actual straight
% segments produced by the chromosome, including dense ridge/valley samples.
observedMinAGL=inf; observedMaxAGL=-inf; minSlack=inf; sampleCount=0; maxSpacing=0;
for i=1:N-1
    sample=segmentSamples{i};
    zDense=z(i)+sample.t.*(z(i+1)-z(i));
    agl=zDense-sample.terrain;
    lowerLimit=(safe+margin)*ones(size(agl));
    upperLimit=allowedMaxAGL-margin;
    if i==1, lowerLimit(1)=safe; end
    if i==N-1 && useUpper
        % endpoint formal upper is handled below
    end
    if i==N-1, lowerLimit(end)=safe; end
    if useUpper
        upperVec=upperLimit*ones(size(agl));
        if i==1, upperVec(1)=allowedMaxAGL; end
        if i==N-1, upperVec(end)=allowedMaxAGL; end
    else
        upperVec=inf(size(agl));
    end
    if any(agl<lowerLimit-tol) || any(agl>upperVec+tol)
        z=zeros(0,1); info.reason='verify_dense_agl'; info.failedSegment=i; return;
    end
    observedMinAGL=min(observedMinAGL,min(agl));
    observedMaxAGL=max(observedMaxAGL,max(agl));
    minSlack=min(minSlack,min([agl-lowerLimit;upperVec-agl]));
    sampleCount=sampleCount+sample.numSamples;
    maxSpacing=max(maxSpacing,sample.maximumSpacing_m);
end
horizontal=hypot(diff(xy(:,1)),diff(xy(:,2)));
climb=atan2d(abs(diff(z)),max(horizontal,eps));
maxClimbDeg=max([0;climb(:)]);
if maxClimbDeg>maxClimb+1e-8
    z=zeros(0,1); info.reason='verify_climb'; return;
end

info.success=true;
info.reason='ok';
info.minimumSlack=minSlack;
info.maxClimbDeg=maxClimbDeg;
info.minimumAGL=observedMinAGL;
info.maximumAGL=observedMaxAGL;
info.sampleCount=sampleCount;
info.maximumSpacing_m=maxSpacing;
info.cost=bestCost;
end


function [nextCost,nextPred]=localScalarTransition( ...
    prevGrid,nextGrid,prevCost,reachablePrev,denseLower,denseUpper,t, ...
    maxDz,nextNodeLower,nextNodeUpper,nextPreferred,preferenceScale,tol)
% Reference implementation retained for exact OFF/ON equivalence testing.
nextCost=inf(numel(nextGrid),1);
nextPred=zeros(numel(nextGrid),1);
for rp=1:numel(reachablePrev)
    pidx=reachablePrev(rp);
    pz=prevGrid(pidx);
    if pz<denseLower(1)-tol || pz>denseUpper(1)+tol
        continue;
    end
    mask=t>1e-12;
    tt=t(mask);
    loReq=(denseLower(mask)-(1-tt)*pz)./tt;
    hiReq=(denseUpper(mask)-(1-tt)*pz)./tt;
    lo=max([loReq(:);pz-maxDz;nextNodeLower]);
    hi=min([hiReq(:);pz+maxDz;nextNodeUpper]);
    if lo>hi+tol, continue; end
    ok=find(nextGrid>=lo-tol & nextGrid<=hi+tol);
    if isempty(ok), continue; end
    dz=nextGrid(ok)-pz;
    prefPenalty=((nextGrid(ok)-nextPreferred)/preferenceScale).^2;
    if maxDz>1e-9
        slopePenalty=0.02*(dz/maxDz).^2;
    else
        slopePenalty=zeros(size(dz));
    end
    candidateCost=prevCost(pidx)+prefPenalty+slopePenalty;
    better=candidateCost<nextCost(ok);
    if any(better)
        chosen=ok(better);
        nextCost(chosen)=candidateCost(better);
        nextPred(chosen)=pidx;
    end
end
end

function [nextCost,nextPred]=localVectorizedTransition( ...
    prevGrid,nextGrid,prevCost,reachablePrev,denseLower,denseUpper,t, ...
    maxDz,nextNodeLower,nextNodeUpper,nextPreferred,preferenceScale,tol)
% Numerically equivalent vectorized DP transition.
% The scalar reference visits predecessor indices in ascending order and only
% replaces a state on strict cost improvement. MATLAB min() also returns the
% first occurrence of an exact tie, preserving that predecessor tie-break.
nextCost=inf(numel(nextGrid),1);
nextPred=zeros(numel(nextGrid),1);
if isempty(reachablePrev) || isempty(nextGrid)
    return;
end
pz=prevGrid(reachablePrev);
pc=prevCost(reachablePrev);
validStart=pz>=denseLower(1)-tol & pz<=denseUpper(1)+tol;
reachablePrev=reachablePrev(validStart);
pz=pz(validStart);
pc=pc(validStart);
if isempty(reachablePrev)
    return;
end
mask=t>1e-12;
tt=t(mask);
if isempty(tt)
    return;
end
alpha=(1-tt)./tt;
loBase=denseLower(mask)./tt;
hiBase=denseUpper(mask)./tt;
% Each column corresponds to one predecessor altitude and exactly reproduces
% loReq/hiReq from the scalar loop.
loReq=bsxfun(@minus,loBase,alpha*pz(:).');
hiReq=bsxfun(@minus,hiBase,alpha*pz(:).');
lo=max(loReq,[],1).';
hi=min(hiReq,[],1).';
lo=max(lo,pz(:)-maxDz);
lo=max(lo,nextNodeLower);
hi=min(hi,pz(:)+maxDz);
hi=min(hi,nextNodeUpper);
validInterval=lo<=hi+tol;
if ~any(validInterval)
    return;
end
reachablePrev=reachablePrev(validInterval);
pz=pz(validInterval);
pc=pc(validInterval);
lo=lo(validInterval);
hi=hi(validInterval);
nextRow=nextGrid(:).';
feasible=bsxfun(@ge,nextRow,lo(:)-tol) & ...
    bsxfun(@le,nextRow,hi(:)+tol);
if ~any(feasible(:))
    return;
end
dz=bsxfun(@minus,nextRow,pz(:));
prefPenalty=((nextRow-nextPreferred)/preferenceScale).^2;
if maxDz>1e-9
    slopePenalty=0.02*(dz/maxDz).^2;
else
    slopePenalty=zeros(size(dz));
end
candidateCost=bsxfun(@plus,pc(:),bsxfun(@plus,slopePenalty,prefPenalty));
candidateCost(~feasible)=inf;
[minCost,predLocal]=min(candidateCost,[],1);
nextCost=minCost(:);
finiteNext=isfinite(nextCost);
if any(finiteNext)
    predLocal=predLocal(:);
    nextPred(finiteNext)=reachablePrev(predLocal(finiteNext));
end
end

function info=localEmptyInfo()
info=struct('success',false,'reason','invalid','minimumSlack',-inf, ...
    'maxClimbDeg',inf,'minimumAGL',-inf,'maximumAGL',inf, ...
    'sampleCount',0,'maximumSpacing_m',inf,'failedSegment',0,'cost',inf, ...
    'terrainSampleCacheHits',0,'terrainSampleCacheMisses',0, ...
    'terrainSamplingTime_s',0);
end

function [sample,wasHit]=localSegmentSample(a,b,problem,cfg,sampleCache)
wasHit=false;
cacheEnabled=isa(sampleCache,'containers.Map');
if ~cacheEnabled
    sample=evaluation.sampleSegmentTerrainAdaptive(a,b,problem,cfg);
    return;
end
step=max(1,localCfg(cfg,'aglConstraintSampleStep_m',15));
maxSamples=max(3,round(localCfg(cfg,'aglConstraintMaxSamplesPerSegment',96)));
key=sprintf('%.17g,%.17g>%.17g,%.17g|%.17g|%d', ...
    a(1),a(2),b(1),b(2),step,maxSamples);
if isKey(sampleCache,key)
    sample=sampleCache(key);
    wasHit=true;
else
    sample=evaluation.sampleSegmentTerrainAdaptive(a,b,problem,cfg);
    sampleCache(key)=sample;
end
end

function value=localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value=cfg.(name); else, value=defaultValue; end
end
