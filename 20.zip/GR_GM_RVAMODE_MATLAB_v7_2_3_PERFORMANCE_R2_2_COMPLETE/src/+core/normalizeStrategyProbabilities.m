function probabilities = normalizeStrategyProbabilities(rawScores,cfg)
%NORMALIZESTRATEGYPROBABILITIES Convert scores to bounded probabilities.
rawScores = double(rawScores(:)');
K = numel(rawScores);
if K==0, probabilities=[]; return; end
rawScores(~isfinite(rawScores))=0;
rawScores=max(rawScores,0);
pMin=cfg.strategyProbabilityMin;
if K*pMin>=1, error('strategyProbabilityMin is too large.'); end
if sum(rawScores)<=eps
    normalized=ones(1,K)/K;
else
    normalized=rawScores/sum(rawScores);
end
probabilities=pMin+(1-K*pMin)*normalized;
if isfield(cfg,'strategyProbabilityMax')
    pMax=cfg.strategyProbabilityMax;
    for pass=1:20
        above=probabilities>pMax+1e-12;
        if ~any(above), break; end
        excess=sum(probabilities(above)-pMax);
        probabilities(above)=pMax;
        below=~above & probabilities<pMax-1e-12;
        if ~any(below), break; end
        room=pMax-probabilities(below);
        probabilities(below)=probabilities(below)+excess*room/max(sum(room),eps);
    end
end
if numel(probabilities)>=3 && isfield(cfg,'monitorStrategyMaxProbability')
    probabilities(3)=min(probabilities(3),cfg.monitorStrategyMaxProbability);
    remaining=1-probabilities(3);
    first=probabilities(1:2);
    if sum(first)<=eps, first=[0.5 0.5]; else, first=first/sum(first); end
    probabilities(1:2)=remaining*first;
end
probabilities=max(probabilities,pMin);
probabilities=probabilities/sum(probabilities);
end
