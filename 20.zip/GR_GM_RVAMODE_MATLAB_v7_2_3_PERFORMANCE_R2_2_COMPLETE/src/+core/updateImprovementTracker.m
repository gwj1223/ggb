function [bestValue,anchorValue,lastImprovementGeneration,significant] = ...
    updateImprovementTracker(value,bestValue,anchorValue, ...
    lastImprovementGeneration,generation,tolerance,direction,useRelative)
%UPDATEIMPROVEMENTTRACKER Track best value and cumulative significant gains.
if nargin < 8, useRelative = false; end
if nargin < 7 || isempty(direction), direction = 'maximize'; end
significant = false;
if ~isfinite(value), return; end

if strcmpi(direction,'maximize')
    if ~isfinite(bestValue) || value>bestValue
        bestValue = value;
    end
    if ~isfinite(anchorValue)
        anchorValue = value;
        lastImprovementGeneration = generation;
        significant = true;
        return;
    end
    gain = value-anchorValue;
else
    if ~isfinite(bestValue) || value<bestValue
        bestValue = value;
    end
    if ~isfinite(anchorValue)
        anchorValue = value;
        lastImprovementGeneration = generation;
        significant = true;
        return;
    end
    gain = anchorValue-value;
end
if useRelative
    gain = gain/(abs(anchorValue)+eps);
end
if gain>tolerance
    anchorValue = value;
    lastImprovementGeneration = generation;
    significant = true;
end
end
