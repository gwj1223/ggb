function d = populationDiversity(pop)
if numel(pop)<2, d=0; return; end
X = vertcat(pop.genes);
scale = sqrt(size(X,2));
center = mean(X,1);
d = mean(sqrt(sum((X-center).^2,2)))/max(scale,eps);
end
