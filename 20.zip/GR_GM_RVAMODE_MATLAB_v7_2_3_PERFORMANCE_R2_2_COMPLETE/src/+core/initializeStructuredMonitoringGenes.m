function genes = initializeStructuredMonitoringGenes(problem,cfg,mode,variant)
%INITIALIZESTRUCTUREDMONITORINGGENES Initialize normalized semantic genes.
if nargin < 4, variant = 1; end
layout = core.structuredMonitoringLayout(problem,cfg);
D = layout.dimension;
genes = zeros(1,D);

switch mode
    case 1
        genes = 0.18*randn(1,D);
    case 2
        genes = 0.12*randn(1,D);
        genes(layout.transitDims) = 0.45*randn(1,numel(layout.transitDims));
    case 3
        eliteCount = localCfg(cfg,'monitorGuidedSeedEliteCount',2);
        if variant > eliteCount
            genes = 0.06*randn(1,D);
        end
    otherwise
        genes = 2*rand(1,D)-1;
end

genes = min(max(genes,-1),1);
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
