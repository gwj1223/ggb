function [selectedIdx,selectedTargets] = selectMissionRepairBases( ...
    pop,candidateIdx,D,cfg)
%SELECTMISSIONREPAIRBASES Diversified A3 base selection for v7.1.0.
%
% Priority:
%   1) always keep the globally best-D candidate;
%   2) prefer different current worst/repair targets;
%   3) fill remaining slots by five-objective max-min diversity;
% while candidate eligibility and all A3 acceptance guards remain unchanged.

candidateIdx = candidateIdx(:);
if isempty(candidateIdx)
    selectedIdx = zeros(0,1);
    selectedTargets = zeros(0,1);
    return;
end

[~,ord] = sort(D(candidateIdx),'ascend');
candidateIdx = candidateIdx(ord);
baseCount = min(numel(candidateIdx),max(1,round(localCfg(cfg, ...
    'missionRepairBaseCount',4))));

targets = nan(numel(candidateIdx),1);
for k = 1:numel(candidateIdx)
    ind = pop(candidateIdx(k));
    if isfield(ind,'monitorStats') && ~isempty(ind.monitorStats)
        t = evaluation.selectMonitoringRepairTarget(ind.monitorStats,cfg);
        if isscalar(t) && isfinite(t)
            targets(k) = t;
        end
    end
end

if ~localCfg(cfg,'missionRepairDiversifyBases',false) || baseCount<=1
    selectedLocal = (1:baseCount)';
    selectedIdx = candidateIdx(selectedLocal);
    selectedTargets = targets(selectedLocal);
    return;
end

selectedLocal = 1;
usedTargets = targets(1);
usedTargets = usedTargets(isfinite(usedTargets));

if localCfg(cfg,'missionRepairDistinctTargetsFirst',true)
    for k = 2:numel(candidateIdx)
        if numel(selectedLocal)>=baseCount, break; end
        tk = targets(k);
        if isfinite(tk) && ~ismember(tk,usedTargets)
            selectedLocal(end+1,1) = k; %#ok<AGROW>
            usedTargets(end+1,1) = tk; %#ok<AGROW>
        end
    end
end

% Objective-space fill: choose the candidate farthest from the already
% selected set in normalized five-objective space. D-order is the deterministic
% tie-break because candidateIdx is already sorted by D.
if numel(selectedLocal)<baseCount
    obj = vertcat(pop(candidateIdx).objectives);
    finiteObj = all(isfinite(obj),2);
    if any(finiteObj)
        mn = min(obj(finiteObj,:),[],1);
        mx = max(obj(finiteObj,:),[],1);
        z = bsxfun(@rdivide,bsxfun(@minus,obj,mn),mx-mn+eps);
        z(~isfinite(z)) = 0;
    else
        z = zeros(numel(candidateIdx),size(obj,2));
    end

    while numel(selectedLocal)<baseCount
        remaining = setdiff((1:numel(candidateIdx))',selectedLocal,'stable');
        if isempty(remaining), break; end
        dist = zeros(numel(remaining),1);
        for r = 1:numel(remaining)
            delta = bsxfun(@minus,z(selectedLocal,:),z(remaining(r),:));
            dist(r) = min(sqrt(sum(delta.^2,2)));
        end
        best = max(dist);
        q = find(abs(dist-best)<=1e-12,1,'first');
        selectedLocal(end+1,1) = remaining(q); %#ok<AGROW>
    end
end

selectedIdx = candidateIdx(selectedLocal(1:min(baseCount,numel(selectedLocal))));
selectedTargets = targets(selectedLocal(1:min(baseCount,numel(selectedLocal))));
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
