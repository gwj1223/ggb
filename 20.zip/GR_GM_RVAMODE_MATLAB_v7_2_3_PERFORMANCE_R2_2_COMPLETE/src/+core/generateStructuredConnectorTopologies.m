function candidates = generateStructuredConnectorTopologies(primary,budget,score,turnCost,cfg)
%GENERATESTRUCTUREDCONNECTORTOPOLOGIES Small reachability-oriented topology set.
%
% v7.2.3 keeps the fixed connector budget and the 0/1/2 per-leg contract, but
% does not let one turn-optimal count vector become a hard decoder barrier.
% The returned rows are deterministic budget-preserving alternatives:
%   1) the existing turn-aware primary allocation;
%   2) terrain/distance-first allocation;
%   3) spread-first allocation;
%   4) a hybrid turn/terrain allocation;
%   5+) the best one-node transfers around the primary allocation.
%
% No formal flight or mission threshold is changed here. Dense-3D evaluation
% remains the authority that decides whether any candidate is physically usable.

primary = round(reshape(primary,1,[]));
L = numel(primary);
score = reshape(score,1,[]);
if numel(score)~=L || any(~isfinite(score))
    score = ones(1,L);
end
score = max(score,eps);

if nargin<4 || isempty(turnCost) || size(turnCost,1)~=L
    turnCost = inf(L,3);
end

limit = max(1,round(localCfg(cfg,'structuredTransitTopologyCandidateLimit',6)));
boundaryMin = max(0,round(localCfg(cfg,'structuredTransitMinimumBoundaryConnectors',0)));
boundaryMax = localCfg(cfg,'structuredTransitMaximumBoundaryConnectors',inf);
perLegMax = localCfg(cfg,'structuredTransitMaximumConnectorsPerLeg',2);
if ~isfinite(perLegMax), perLegMax=max(2,budget); end
perLegMax=max(1,round(perLegMax));
if ~isfinite(boundaryMax), boundaryMax=perLegMax; end
boundaryMax=max(boundaryMin,round(boundaryMax));

capacity=perLegMax*ones(1,L);
if L>=1, capacity(1)=min(capacity(1),boundaryMax); end
if L>=2, capacity(end)=min(capacity(end),boundaryMax); end
minimum=zeros(1,L);
if L>=1, minimum(1)=min(boundaryMin,capacity(1)); end
if L>=2, minimum(end)=min(boundaryMin,capacity(end)); end

primary=min(max(primary,minimum),capacity);
primary=localRepairBudget(primary,budget,minimum,capacity,score);
C=primary;

% Candidate 2: terrain/distance-first. This deliberately gives the Dense
% projector a topology that is not dominated by 2-D turn demand.
terrainAlloc=localGreedyAllocate(minimum,budget,capacity, ...
    @(counts,leg)localTerrainUtility(counts,leg,score));
C=localAddUnique(C,terrainAlloc);

% Candidate 3: spread-first. Prefer giving a first connector to uncovered legs
% before spending second connectors, then use terrain/distance as the tie break.
spreadAlloc=localGreedyAllocate(minimum,budget,capacity, ...
    @(counts,leg)localSpreadUtility(counts,leg,score));
C=localAddUnique(C,spreadAlloc);

% Candidate 4: hybrid turn/terrain allocation using reach-safe chord turn cost.
hybridAlloc=localGreedyAllocate(minimum,budget,capacity, ...
    @(counts,leg)localHybridUtility(counts,leg,score,turnCost,cfg));
C=localAddUnique(C,hybridAlloc);

% Remaining candidates: one-node transfers around the primary topology.
% Rank transfers by how strongly they improve terrain coverage while avoiding
% large formal turn regressions according to the chord-based turn-cost matrix.
transfers=zeros(0,L);
transferScore=zeros(0,1);
for donor=1:L
    if primary(donor)<=minimum(donor), continue; end
    for receiver=1:L
        if receiver==donor || primary(receiver)>=capacity(receiver), continue; end
        trial=primary;
        trial(donor)=trial(donor)-1;
        trial(receiver)=trial(receiver)+1;
        if sum(trial)~=budget, continue; end
        transfers(end+1,:)=trial; %#ok<AGROW>
        transferScore(end+1,1)=localTransferUtility( ...
            primary,trial,donor,receiver,score,turnCost,cfg); %#ok<AGROW>
    end
end
if ~isempty(transfers)
    [~,order]=sort(transferScore,'descend');
    for k=1:numel(order)
        C=localAddUnique(C,transfers(order(k),:));
        if size(C,1)>=limit, break; end
    end
end

if size(C,1)>limit
    C=C(1:limit,:);
end
candidates=C;
end

function counts=localGreedyAllocate(minimum,budget,capacity,utilityFcn)
counts=minimum;
while sum(counts)<budget
    bestLeg=0; bestValue=-inf;
    for leg=1:numel(counts)
        if counts(leg)>=capacity(leg), continue; end
        value=utilityFcn(counts,leg);
        if value>bestValue+1e-12
            bestValue=value;
            bestLeg=leg;
        end
    end
    if bestLeg==0, break; end
    counts(bestLeg)=counts(bestLeg)+1;
end
end

function value=localTerrainUtility(counts,leg,score)
scoreNorm=score/max(max(score),eps);
value=scoreNorm(leg)/(1+counts(leg));
end

function value=localSpreadUtility(counts,leg,score)
scoreNorm=score/max(max(score),eps);
firstBonus=100*(counts(leg)==0);
value=firstBonus+scoreNorm(leg)/(1+counts(leg));
end

function value=localHybridUtility(counts,leg,score,turnCost,cfg)
scoreNorm=score/max(max(score),eps);
n0=counts(leg); n1=n0+1;
maxTurn=max(localCfg(cfg,'maxTurnAngleDeg',180),eps);
turnGain=0; excessGain=0;
if size(turnCost,2)>=n1+1
    before=turnCost(leg,n0+1);
    after=turnCost(leg,n1+1);
    if isfinite(before) && isfinite(after)
        turnGain=before-after;
        excessGain=max(0,before-maxTurn)-max(0,after-maxTurn);
    end
end
value=500*excessGain+turnGain+8*scoreNorm(leg)/(1+n0);
end

function value=localTransferUtility(primary,trial,donor,receiver,score,turnCost,cfg)
scoreNorm=score/max(max(score),eps);
terrainGain=scoreNorm(receiver)/(1+primary(receiver))- ...
    0.35*scoreNorm(donor)/(1+trial(donor));
maxTurn=max(localCfg(cfg,'maxTurnAngleDeg',180),eps);
turnPenalty=0;
for leg=[donor receiver]
    oldN=primary(leg); newN=trial(leg);
    if size(turnCost,2)>=max(oldN,newN)+1
        oldTurn=turnCost(leg,oldN+1);
        newTurn=turnCost(leg,newN+1);
        if isfinite(oldTurn) && isfinite(newTurn)
            oldExcess=max(0,oldTurn-maxTurn);
            newExcess=max(0,newTurn-maxTurn);
            turnPenalty=turnPenalty+20*(newExcess-oldExcess)+0.05*(newTurn-oldTurn);
        end
    end
end
value=10*terrainGain-turnPenalty;
end

function counts=localRepairBudget(counts,budget,minimum,capacity,score)
counts=min(max(counts,minimum),capacity);
while sum(counts)>budget
    eligible=find(counts>minimum);
    if isempty(eligible), break; end
    [~,q]=min(score(eligible)./(1+counts(eligible)));
    counts(eligible(q))=counts(eligible(q))-1;
end
while sum(counts)<budget
    eligible=find(counts<capacity);
    if isempty(eligible), break; end
    [~,q]=max(score(eligible)./(1+counts(eligible)));
    counts(eligible(q))=counts(eligible(q))+1;
end
end

function C=localAddUnique(C,row)
row=reshape(row,1,[]);
if isempty(C)
    C=row;
    return;
end
if ~any(all(C==row,2))
    C(end+1,:)=row; %#ok<AGROW>
end
end

function value=localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value=cfg.(name); else, value=defaultValue; end
end
