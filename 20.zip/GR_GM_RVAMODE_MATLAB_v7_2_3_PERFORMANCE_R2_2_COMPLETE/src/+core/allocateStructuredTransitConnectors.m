function counts = allocateStructuredTransitConnectors(budget,score,turnCost,cfg)
%ALLOCATESTRUCTUREDTRANSITCONNECTORS Allocate a fixed connector budget adaptively.
%
% v7.2.2 keeps the 42-waypoint phenotype but removes the v7.2.1 global
% one-connector-per-leg cap.  Boundary legs keep at least one connector.
% Remaining nodes are assigned by the marginal reduction in local heading
% demand obtained by adding the next connector (0->1 or 1->2).  Terrain/
% distance score is only a tie-breaker.  This lets a difficult leg receive a
% second node when it genuinely reduces turn demand, without blindly adding a
% second node to a leg where discretisation would make the turn worse.

L = numel(score);
counts = zeros(L,1);
if budget<=0 || L==0, return; end
score = reshape(score,[],1);
if numel(score)~=L || any(~isfinite(score))
    score = ones(L,1);
end
score = max(score,eps);
if isempty(turnCost) || size(turnCost,1)~=L
    turnCost = inf(L,3);
end

boundaryMin = max(0,round(localCfg(cfg,'structuredTransitMinimumBoundaryConnectors',0)));
boundaryMax = localCfg(cfg,'structuredTransitMaximumBoundaryConnectors',inf);
perLegMax = localCfg(cfg,'structuredTransitMaximumConnectorsPerLeg',inf);
if ~isfinite(perLegMax)
    perLegMax = max(2,budget);
else
    perLegMax = max(1,round(perLegMax));
end
if ~isfinite(boundaryMax)
    boundaryMax = perLegMax;
else
    boundaryMax = max(boundaryMin,round(boundaryMax));
end
capacity = perLegMax*ones(L,1);
capacity(1) = min(capacity(1),boundaryMax);
if L>=2, capacity(end) = min(capacity(end),boundaryMax); end

% Protect start and goal transitions first.
counts(1) = min([boundaryMin,budget,capacity(1)]);
if L>=2
    remaining = budget-sum(counts);
    counts(end) = min([boundaryMin,max(remaining,0),capacity(end)]);
end

maxTurn = max(localCfg(cfg,'maxTurnAngleDeg',180),eps);
nearFraction = min(max(localCfg(cfg,'structuredTransitMandatoryTurnFraction',0.90),0),1);
nearTurn = nearFraction*maxTurn;
scoreNorm = score/max(max(score),eps);

while sum(counts) < budget
    bestLeg = 0;
    bestUtility = -inf;
    for leg = 1:L
        if counts(leg) >= capacity(leg), continue; end
        n0 = counts(leg);
        n1 = n0+1;
        if size(turnCost,2) < n1+1, continue; end
        before = turnCost(leg,n0+1);
        after = turnCost(leg,n1+1);
        if ~isfinite(before) || ~isfinite(after), continue; end

        rawGain = before-after;
        excessGain = max(0,before-maxTurn)-max(0,after-maxTurn);
        nearGain = max(0,before-nearTurn)-max(0,after-nearTurn);

        % Lexicographic behaviour encoded as separated scales:
        % 1) remove formal turn excess, 2) create near-limit margin,
        % 3) reduce raw local turn, 4) use terrain/distance as tie-breaker.
        utility = 1000*excessGain + 50*nearGain + rawGain + ...
            0.05*scoreNorm(leg)/(1+n0);

        if utility > bestUtility + 1e-12
            bestUtility = utility;
            bestLeg = leg;
        elseif abs(utility-bestUtility)<=1e-12 && bestLeg>0 && ...
                scoreNorm(leg)>scoreNorm(bestLeg)
            bestLeg = leg;
        end
    end

    if bestLeg==0
        % Defensive exact-budget fallback: spend the node where it causes the
        % least geometric harm among still-capable legs.
        eligible = find(counts<capacity);
        if isempty(eligible), break; end
        [~,q] = max(scoreNorm(eligible)./(1+counts(eligible)));
        bestLeg = eligible(q);
    end
    counts(bestLeg) = counts(bestLeg)+1;
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value=cfg.(name); else, value=defaultValue; end
end
