function [genes,info] = decodeStructuredMonitoringGenes(structuredGenes,problem,cfg)
%DECODESTRUCTUREDMONITORINGGENES Decode semantic genes to the legacy XYZ phenotype.
%
% v7.2.3 Performance R2 changes computation only: identical dense segment
% terrain samples are reused within one semantic decode and lightweight
% timing counters are exposed through encodingInfo.
%
% v7.2.3 keeps the 51D semantic genotype and the established 42-waypoint
% Shiyan phenotype, but makes the semantic-to-physical mapping explicitly
% 3D-feasibility-first. A small fixed-budget connector-topology candidate set
% is screened with chord/bias Dense-3D reachability before tangent geometry is
% allowed to refine turn. Every tangent blend is re-projected through the same
% Dense-3D contract, so turn improvement cannot sacrifice AGL/climb reachability.

decoderTimer=tic;
projectionTime_s=0; terrainSamplingTime_s=0;
terrainCacheHits=0; terrainCacheMisses=0;
cacheEnabled=localCfg(cfg,'enableStructuredSegmentTerrainCache',true);
if cacheEnabled
    segmentSampleCache=containers.Map('KeyType','char','ValueType','any');
else
    segmentSampleCache=[];
end
layout = core.structuredMonitoringLayout(problem,cfg);
info = localEmptyInfo(layout);
info.segmentTerrainCacheEnabled=cacheEnabled;
genes = zeros(1,3*cfg.numWaypoints);
if numel(structuredGenes) ~= layout.dimension || any(~isfinite(structuredGenes))
    info.reason = 'dimension';
    info=localFinalizePerformanceInfo(info,decoderTimer,projectionTime_s, ...
            terrainSamplingTime_s,terrainCacheHits,terrainCacheMisses,cacheEnabled);
    return;
end
u = min(max(reshape(structuredGenes,1,[]),-1),1);
M = layout.targetCount;
K = cfg.numWaypoints;
if M < 1
    info.reason = 'targets';
    info=localFinalizePerformanceInfo(info,decoderTimer,projectionTime_s, ...
            terrainSamplingTime_s,terrainCacheHits,terrainCacheMisses,cacheEnabled);
    return;
end

if isfield(problem,'structuredMonitoringTargetOrder') && ...
        numel(problem.structuredMonitoringTargetOrder)==M
    order = reshape(problem.structuredMonitoringTargetOrder,1,[]);
else
    order = core.structuredMonitoringTargetOrder(problem,cfg);
end
info.targetOrder = order;

arcXY = cell(M,1);
arcAGL = cell(M,1);
arcCount = zeros(M,1);
arcLength = zeros(M,1);
radiusScale = zeros(M,1);
sectorOffset = zeros(M,1);
preferredAGL = zeros(M,1);

for pos = 1:M
    m = order(pos);
    dims = layout.targetDims(m,:);
    if pos==1, previousXY=problem.start(1:2); else, previousXY=problem.monitorTargets(order(pos-1),1:2); end
    if pos==M, nextXY=problem.goal(1:2); else, nextXY=problem.monitorTargets(order(pos+1),1:2); end
    [arcXY{m},arcAGL{m},meta] = localTargetArc(m,u(dims),previousXY,nextXY,problem,cfg);
    arcCount(m)=size(arcXY{m},1);
    arcLength(m)=meta.arcLength_m;
    radiusScale(m)=meta.radiusScale;
    sectorOffset(m)=meta.sectorOffsetRad;
    preferredAGL(m)=meta.preferredAGL_m;
end

totalArcPoints = sum(arcCount);
connectorBudget = K-totalArcPoints;
minimumConnectorBudget = localMinimumConnectorBudget(M,cfg);
info.arcPointCount = totalArcPoints;
info.connectorBudget = connectorBudget;
info.minimumConnectorBudget = minimumConnectorBudget;
if connectorBudget < 0
    info.reason = 'waypoint_budget';
    info=localFinalizePerformanceInfo(info,decoderTimer,projectionTime_s, ...
            terrainSamplingTime_s,terrainCacheHits,terrainCacheMisses,cacheEnabled);
    return;
end
if connectorBudget < minimumConnectorBudget
    info.reason = 'connector_budget';
    info=localFinalizePerformanceInfo(info,decoderTimer,projectionTime_s, ...
            terrainSamplingTime_s,terrainCacheHits,terrainCacheMisses,cacheEnabled);
    return;
end

% Build transit endpoint arrays after arc orientation has been chosen.
legStart = zeros(M+1,2);
legEnd = zeros(M+1,2);
legStartAGL = zeros(M+1,1);
legEndAGL = zeros(M+1,1);
startTerrain = data.terrainHeight(problem,problem.start(1),problem.start(2));
goalTerrain = data.terrainHeight(problem,problem.goal(1),problem.goal(2));
startAGL = problem.start(3)-startTerrain;
goalAGL = problem.goal(3)-goalTerrain;
for leg=1:M+1
    if leg==1
        legStart(leg,:)=problem.start(1:2);
        legStartAGL(leg)=startAGL;
    else
        prevTarget=order(leg-1);
        legStart(leg,:)=arcXY{prevTarget}(end,:);
        legStartAGL(leg)=arcAGL{prevTarget}(end);
    end
    if leg==M+1
        legEnd(leg,:)=problem.goal(1:2);
        legEndAGL(leg)=goalAGL;
    else
        nextTarget=order(leg);
        legEnd(leg,:)=arcXY{nextTarget}(1,:);
        legEndAGL(leg)=arcAGL{nextTarget}(1);
    end
end

legScore = zeros(M+1,1);
legTurnDemand = zeros(M+1,1);
maxTurn = max(localCfg(cfg,'maxTurnAngleDeg',180),eps);
turnWeight = max(0,localCfg(cfg,'structuredTransitTurnWeight',0));
for leg=1:M+1
    baseScore=localTransitDifficulty(legStart(leg,:),legEnd(leg,:),problem,cfg);
    legTurnDemand(leg)=localTransitTurnDemand( ...
        leg,order,arcXY,legStart(leg,:),legEnd(leg,:));
    turnSeverity=legTurnDemand(leg)/maxTurn;
    legScore(leg)=baseScore*(1+turnWeight*turnSeverity^2);
end
connectorTurnCost = localConnectorTurnCostMatrix( ...
    order,arcXY,legStart,legEnd,cfg);
% v7.2.3: allocate the primary topology with reach-safe chord geometry.
% Tangent placement is no longer allowed to influence connector counts before
% the vertical reachability contract has been satisfied.
connectorTurnCost(:,1)=legTurnDemand;
% Preserve the established v7.2.2 structured-decoder diagnostics contract.
% These fields are consumed by boundary-allocation tests and downstream
% diagnostics; v7.2.3 changes candidate topology selection, not this schema.
info.legTurnDemandDeg = legTurnDemand;
info.connectorTurnCostDeg = connectorTurnCost;
primaryConnectorCount = core.allocateStructuredTransitConnectors( ...
    connectorBudget,legScore,connectorTurnCost,cfg);
info.primaryConnectorCount = primaryConnectorCount;
if sum(primaryConnectorCount)~=connectorBudget
    info.connectorCount=primaryConnectorCount;
    info.reason='connector_allocation';
    info=localFinalizePerformanceInfo(info,decoderTimer,projectionTime_s, ...
            terrainSamplingTime_s,terrainCacheHits,terrainCacheMisses,cacheEnabled);
    return;
end

% v7.2.3: keep a very small set of budget-preserving topology alternatives.
% This prevents one turn-optimal connector allocation from becoming a hard
% structural barrier when another allocation is vertically reachable.
topologyCandidates = core.generateStructuredConnectorTopologies( ...
    primaryConnectorCount,connectorBudget,legScore,connectorTurnCost,cfg);
if isempty(topologyCandidates)
    topologyCandidates=reshape(primaryConnectorCount,1,[]);
end
info.topologyCandidates=topologyCandidates;

bias = u(layout.transitDims(:)');
scales = localCfg(cfg,'structuredTransitBiasFallbackScales',[1.0 0.5 0.0]);
scales = reshape(scales,1,[]);
blendSchedule = localCfg(cfg,'structuredTransitTangentBlendSchedule',[0.25 0.50 0.75 1.00]);
blendSchedule = reshape(blendSchedule,1,[]);
blendSchedule = unique(min(max(blendSchedule,0),1),'stable');
blendSchedule = blendSchedule(blendSchedule>0);
useTangent = localCfg(cfg,'structuredUseTangentAwareTransit',false);

lastXY=[]; lastPreferred=[]; lastProjection=struct();
bestDensePath=[]; bestDenseProjection=struct(); bestDenseTurn=inf; bestDenseScale=NaN;
bestDenseBlend=NaN; bestDenseMode=''; bestDenseTopologyIndex=0;
bestDenseConnectorCount=[];
bestFailedProgress=-inf; bestFailedXY=[]; bestFailedPreferred=[];
bestFailedProjection=struct(); bestFailedConnectorCount=[];
reachAttempts=0; reachFailureSegments=zeros(0,1); reachFailureReasons=cell(0,1);
maxTurnLimit=localCfg(cfg,'maxTurnAngleDeg',180);

for topologyIndex=1:size(topologyCandidates,1)
    connectorCount=reshape(topologyCandidates(topologyIndex,:),[],1);
    if sum(connectorCount)~=connectorBudget
        continue;
    end
    info.connectorCount=connectorCount;

    for attempt=1:numel(scales)
        scale=scales(attempt);

        % Stage 1: Dense-first reachability carrier. Always begin from chord
        % geometry plus semantic lateral bias. This is deliberately independent
        % of the tangent smoother.
        [fullXY,preferredZ] = localBuildRoute(scale,bias,connectorCount, ...
            order,arcXY,arcAGL,legStart,legEnd,legStartAGL,legEndAGL,problem,cfg,0);
        lastXY=fullXY;
        lastPreferred=preferredZ;
        projectionTimer=tic;
        [z,projection] = core.projectDenseTerrainReachableProfile( ...
            fullXY,problem.start(3),problem.goal(3),preferredZ,problem,cfg, ...
            segmentSampleCache);
        projectionTime_s=projectionTime_s+toc(projectionTimer);
        [terrainSamplingTime_s,terrainCacheHits,terrainCacheMisses]= ...
            localAccumulateProjectionPerformance(projection, ...
            terrainSamplingTime_s,terrainCacheHits,terrainCacheMisses);
        reachAttempts=reachAttempts+1;
        lastProjection=projection;

        if ~projection.success
            failProgress=0;
            if isfield(projection,'failedSegment') && isfinite(projection.failedSegment) && ...
                    projection.failedSegment>0
                failProgress=projection.failedSegment;
                reachFailureSegments(end+1,1)=projection.failedSegment; %#ok<AGROW>
            end
            if failProgress>bestFailedProgress
                bestFailedProgress=failProgress;
                bestFailedXY=fullXY;
                bestFailedPreferred=preferredZ;
                bestFailedProjection=projection;
                bestFailedConnectorCount=connectorCount;
            end
            if isfield(projection,'reason')
                rr=projection.reason;
                if isstring(rr), rr=char(rr); end
                if ischar(rr), reachFailureReasons{end+1,1}=rr; end %#ok<AGROW>
            end
            if isfield(projection,'reason') && (ischar(projection.reason) || isstring(projection.reason))
                info.reason=char(projection.reason);
            else
                info.reason='dense_reach';
            end
            continue;
        end

        fullPath=[fullXY z];
        [turnOK,candidateTurn]=localTurnCheck(fullPath,cfg);
        info.denseSuccess=true;
        if candidateTurn<bestDenseTurn
            bestDensePath=fullPath;
            bestDenseProjection=projection;
            bestDenseTurn=candidateTurn;
            bestDenseScale=scale;
            bestDenseBlend=0;
            bestDenseMode='chord';
            bestDenseTopologyIndex=topologyIndex;
            bestDenseConnectorCount=connectorCount;
        end
        if turnOK || ~localCfg(cfg,'structuredEncodingPrecheckTurn',true)
            genes=reshape(fullPath(2:end-1,:),1,[]);
            info.success=true;
            info.reason='ok';
            info.projection=projection;
            info.biasScale=scale;
            info.maxTurnDeg=candidateTurn;
            info.turnSuccess=turnOK;
            info.topologyIndex=topologyIndex;
            info.connectorCount=connectorCount;
            info.tangentBlend=0;
            info.routeMode='chord';
            info.reachAttempts=reachAttempts;
            info.reachFailureSegments=reachFailureSegments;
            info.reachFailureReasons=reachFailureReasons;
            info.arcLength_m=arcLength;
            info.radiusScale=radiusScale;
            info.sectorOffsetRad=sectorOffset;
            info.preferredAGL_m=preferredAGL;
            info=localFinalizePerformanceInfo(info,decoderTimer,projectionTime_s, ...
                terrainSamplingTime_s,terrainCacheHits,terrainCacheMisses,cacheEnabled);
            return;
        end

        % Stage 2: turn refinement is permitted only after a Dense-feasible
        % carrier exists. Every tangent blend is re-projected through the same
        % Dense-3D contract. A turn improvement is never allowed to buy itself
        % by breaking AGL/climb reachability.
        if useTangent && candidateTurn>maxTurnLimit
            for blendIndex=1:numel(blendSchedule)
                blend=blendSchedule(blendIndex);
                [smoothXY,smoothPreferred] = localBuildRoute(scale,bias,connectorCount, ...
                    order,arcXY,arcAGL,legStart,legEnd,legStartAGL,legEndAGL,problem,cfg,blend);
                lastXY=smoothXY;
                lastPreferred=smoothPreferred;
                projectionTimer=tic;
                [zs,pSmooth] = core.projectDenseTerrainReachableProfile( ...
                    smoothXY,problem.start(3),problem.goal(3),smoothPreferred,problem,cfg, ...
                    segmentSampleCache);
                projectionTime_s=projectionTime_s+toc(projectionTimer);
                [terrainSamplingTime_s,terrainCacheHits,terrainCacheMisses]= ...
                    localAccumulateProjectionPerformance(pSmooth, ...
                    terrainSamplingTime_s,terrainCacheHits,terrainCacheMisses);
                reachAttempts=reachAttempts+1;
                lastProjection=pSmooth;

                if ~pSmooth.success
                    if isfield(pSmooth,'failedSegment') && isfinite(pSmooth.failedSegment) && ...
                            pSmooth.failedSegment>0
                        reachFailureSegments(end+1,1)=pSmooth.failedSegment; %#ok<AGROW>
                    end
                    if isfield(pSmooth,'reason')
                        rr=pSmooth.reason;
                        if isstring(rr), rr=char(rr); end
                        if ischar(rr), reachFailureReasons{end+1,1}=rr; end %#ok<AGROW>
                    end
                    continue;
                end

                smoothPath=[smoothXY zs];
                [smoothTurnOK,smoothTurn]=localTurnCheck(smoothPath,cfg);
                info.denseSuccess=true;
                if smoothTurn<bestDenseTurn
                    bestDensePath=smoothPath;
                    bestDenseProjection=pSmooth;
                    bestDenseTurn=smoothTurn;
                    bestDenseScale=scale;
                    bestDenseBlend=blend;
                    bestDenseMode='tangent_blend';
                    bestDenseTopologyIndex=topologyIndex;
                    bestDenseConnectorCount=connectorCount;
                end
                if smoothTurnOK || ~localCfg(cfg,'structuredEncodingPrecheckTurn',true)
                    genes=reshape(smoothPath(2:end-1,:),1,[]);
                    info.success=true;
                    info.reason='ok';
                    info.projection=pSmooth;
                    info.biasScale=scale;
                    info.maxTurnDeg=smoothTurn;
                    info.turnSuccess=smoothTurnOK;
                    info.topologyIndex=topologyIndex;
                    info.connectorCount=connectorCount;
                    info.tangentBlend=blend;
                    info.routeMode='tangent_blend';
                    info.reachAttempts=reachAttempts;
                    info.reachFailureSegments=reachFailureSegments;
                    info.reachFailureReasons=reachFailureReasons;
                    info.arcLength_m=arcLength;
                    info.radiusScale=radiusScale;
                    info.sectorOffsetRad=sectorOffset;
                    info.preferredAGL_m=preferredAGL;
                    info=localFinalizePerformanceInfo(info,decoderTimer,projectionTime_s, ...
                        terrainSamplingTime_s,terrainCacheHits,terrainCacheMisses,cacheEnabled);
                    return;
                end
            end
        end
    end
end

info.reachAttempts=reachAttempts;
info.reachFailureSegments=reachFailureSegments;
info.reachFailureReasons=reachFailureReasons;
info.bestDenseTopologyIndex=bestDenseTopologyIndex;
info.bestDenseBlend=bestDenseBlend;
info.bestDenseMode=bestDenseMode;
if ~isempty(bestDenseConnectorCount)
    info.connectorCount=bestDenseConnectorCount;
elseif ~isempty(bestFailedXY)
    % When no Dense carrier exists, return the candidate that propagated
    % furthest through the Dense DP rather than the arbitrary last attempt.
    lastXY=bestFailedXY;
    lastPreferred=bestFailedPreferred;
    lastProjection=bestFailedProjection;
    info.connectorCount=bestFailedConnectorCount;
    info.bestFailedProgress=bestFailedProgress;
end

% v7.2.1: when Dense-3D already found a physically valid altitude profile
% but the turn precheck still fails, preserve that dense-feasible Z profile.
% The v7.2.0 fallback incorrectly replaced it with the weaker node-only static
% projection, creating avoidable clearance/climb violations in the evaluator.
if ~isempty(bestDensePath)
    genes=reshape(bestDensePath(2:end-1,:),1,[]);
    info.success=false;
    info.reason='turn';
    info.denseSuccess=true;
    info.turnSuccess=false;
    info.maxTurnDeg=bestDenseTurn;
    info.projection=bestDenseProjection;
    info.biasScale=bestDenseScale;
    info.arcLength_m=arcLength;
    info.radiusScale=radiusScale;
    info.sectorOffsetRad=sectorOffset;
    info.preferredAGL_m=preferredAGL;
    info=localFinalizePerformanceInfo(info,decoderTimer,projectionTime_s, ...
        terrainSamplingTime_s,terrainCacheHits,terrainCacheMisses,cacheEnabled);
    return;
end

% If Dense-3D itself fails, return a deterministic finite phenotype so the
% formal evaluator can rank the static violation. No legacy XY repair is used.
if isempty(lastXY)
    info.reason='decode';
    info=localFinalizePerformanceInfo(info,decoderTimer,projectionTime_s, ...
        terrainSamplingTime_s,terrainCacheHits,terrainCacheMisses,cacheEnabled);
    return;
end
[zFallback,staticInfo]=core.projectStaticSafeAltitudeProfile( ...
    lastXY,problem.start(3),problem.goal(3),lastPreferred,problem,cfg);
if isempty(zFallback)
    terrain=data.terrainHeight(problem,lastXY(:,1),lastXY(:,2));
    terrain=terrain(:);
    lower=terrain+localCfg(cfg,'safeClearance',0);
    upper=localCfg(cfg,'maxAltitude',inf)*ones(size(lower));
    if localCfg(cfg,'enableLocalAGLConstraint',false) && ...
            isfield(cfg,'realMaximumAGL') && isfinite(cfg.realMaximumAGL)
        upper=min(upper,terrain+cfg.realMaximumAGL);
    end
    zFallback=min(max(lastPreferred(:),lower),upper);
    zFallback(1)=problem.start(3);
    zFallback(end)=problem.goal(3);
else
    info.staticProjection=staticInfo;
end
fullPath=[lastXY zFallback];
genes=reshape(fullPath(2:end-1,:),1,[]);
info.projection=lastProjection;
info.arcLength_m=arcLength;
info.radiusScale=radiusScale;
info.sectorOffsetRad=sectorOffset;
info.preferredAGL_m=preferredAGL;
info=localFinalizePerformanceInfo(info,decoderTimer,projectionTime_s, ...
    terrainSamplingTime_s,terrainCacheHits,terrainCacheMisses,cacheEnabled);
end

function [xy,agl,meta]=localTargetArc(m,u,previousXY,nextXY,problem,cfg)
target=problem.monitorTargets(m,:);
targetXY=target(1:2);
isCritical=ismember(m,cfg.criticalTargetIndices(:)');
if isCritical
    n=max(3,round(localCfg(cfg,'multiUAVCriticalMonitorGuidedArcPoints',5)));
else
    n=max(2,round(localCfg(cfg,'monitorGuidedArcPoints',3)));
end
incoming=previousXY-targetXY;
outgoing=nextXY-targetXY;
if norm(incoming)>eps, incoming=incoming/norm(incoming); end
if norm(outgoing)>eps, outgoing=outgoing/norm(outgoing); end
routeDirection=incoming+outgoing;
if norm(routeDirection)<1e-8
    route=nextXY-previousXY;
    routeDirection=[-route(2) route(1)];
end
if norm(routeDirection)<1e-8, routeDirection=[1 0]; end
routeDirection=routeDirection/(norm(routeDirection)+eps);
geom=core.observationArcGeometry(m,problem,cfg,routeDirection,1, ...
    localCfg(cfg,'monitorGuidedViewAngleDeg',28),1);

bounds=localCfg(cfg,'monitoringArcRadiusScaleBounds',[0.75 1.25]);
bounds=sort(bounds(:)');
preferred=geom.preferredRadiusScale;
scale=localPiecewiseMap(u(1),preferred,bounds(1),bounds(2));
radius=max(target(4)*scale,eps);

maxOffset=min(localCfg(cfg,'monitoringArcVariantSpanFraction',0.70)* ...
    geom.sectorHalfWidthRad,deg2rad(localCfg(cfg,'monitoringArcVariantMaxOffsetDeg',65)));
if ~isfinite(maxOffset) || maxOffset<=0, maxOffset=pi; end
sectorOffset=u(2)*maxOffset;
direction=localRotate(geom.direction,sectorOffset);

required=localCfg(cfg,'monitorRequiredObservationLength',300);
lengthFactors=localCfg(cfg,'structuredObservationLengthFactorBounds',[0.65 1.50]);
lengthFactors=sort(lengthFactors(:)');
lo=lengthFactors(1)*required;
hi=lengthFactors(2)*required;
if isCritical
    lo=max(lo,localCfg(cfg,'monitorCriticalMinObservationLength',0));
end
if isfield(problem,'monitoringKnowledge') && ...
        isfield(problem.monitoringKnowledge,'maxVisibleArcLength_m') && ...
        numel(problem.monitoringKnowledge.maxVisibleArcLength_m)>=m
    visibleMax=problem.monitoringKnowledge.maxVisibleArcLength_m(m);
    if isfinite(visibleMax) && visibleMax>0
        hi=min(hi,localCfg(cfg,'structuredVisibleArcUseFraction',0.90)*visibleMax);
    end
end
hi=max(hi,lo);
centre=min(max(required,lo),hi);
arcLength=localPiecewiseMap(u(3),centre,lo,hi);
halfAngle=arcLength/(2*radius);
maxHalf=deg2rad(localCfg(cfg,'structuredObservationMaxHalfAngleDeg',80));
if isfinite(geom.sectorHalfWidthRad) && geom.sectorHalfWidthRad<pi
    maxHalf=min(maxHalf,max(deg2rad(localCfg(cfg,'monitoringArcMinimumHalfAngleDeg',22)), ...
        localCfg(cfg,'structuredVisibleSectorUseFraction',0.92)*geom.sectorHalfWidthRad));
end
halfAngle=min(max(halfAngle,deg2rad(5)),maxHalf);
arcLength=2*radius*halfAngle;

offsets=linspace(-halfAngle,halfAngle,n);
xy=zeros(n,2);
for j=1:n
    xy(j,:)=targetXY+radius*localRotate(direction,offsets(j));
end
reverseXY=flipud(xy);
costForward=norm(previousXY-xy(1,:))+sum(vecnorm(diff(xy,1,1),2,2))+norm(xy(end,:)-nextXY);
costReverse=norm(previousXY-reverseXY(1,:))+sum(vecnorm(diff(reverseXY,1,1),2,2))+norm(reverseXY(end,:)-nextXY);
if costReverse<costForward, xy=reverseXY; end

heightDelta=localCfg(cfg,'structuredObservationHeightSigmaFraction',0.60)* ...
    localCfg(cfg,'monitorHeightSigma',55);
baseAGL=target(5);
aglValue=baseAGL+u(4)*heightDelta;
aglLo=localCfg(cfg,'safeClearance',0)+localCfg(cfg,'structuredObservationAGLMargin_m',2);
aglHi=inf;
if localCfg(cfg,'enableLocalAGLConstraint',false) && ...
        isfield(cfg,'realMaximumAGL') && isfinite(cfg.realMaximumAGL)
    aglHi=cfg.realMaximumAGL-localCfg(cfg,'structuredObservationAGLMargin_m',2);
end
aglValue=min(max(aglValue,aglLo),aglHi);
agl=repmat(aglValue,n,1);
meta=struct('arcLength_m',arcLength,'radiusScale',scale, ...
    'sectorOffsetRad',sectorOffset,'preferredAGL_m',aglValue);
end

function [fullXY,preferredZ]=localBuildRoute(biasScale,bias,connectorCount, ...
    order,arcXY,arcAGL,legStart,legEnd,legStartAGL,legEndAGL,problem,cfg,tangentBlend)
M=numel(order);
xy=problem.start(1:2);
pref=problem.start(3);
useTangent=localCfg(cfg,'structuredUseTangentAwareTransit',false);
tangentBlend=min(max(tangentBlend,0),1);
for leg=1:M+1
    n=connectorCount(leg);
    if n>0
        t=(1:n)'/(n+1);
        a=legStart(leg,:); b=legEnd(leg,:); v=b-a;
        distance=norm(v);
        if distance>eps
            normal=[-v(2) v(1)]/distance;
        else
            normal=[0 0];
        end
        chordXY=a+t.*v;
        if useTangent && distance>eps && tangentBlend>0
            startDir=localLegStartDirection(leg,order,arcXY,a,b);
            endDir=localLegEndDirection(leg,order,arcXY,a,b);
            tangentXY=localTangentTransit(a,b,startDir,endDir,t,cfg);
            cxy=(1-tangentBlend).*chordXY+tangentBlend.*tangentXY;
        else
            cxy=chordXY;
        end
        maxOffset=min(localCfg(cfg,'structuredTransitMaxOffset_m',300), ...
            localCfg(cfg,'structuredTransitMaxOffsetFraction',0.18)*distance);
        offset=biasScale*bias(leg)*maxOffset*sin(pi*t);
        cxy=cxy+offset.*normal;
        cxy(:,1)=min(max(cxy(:,1),problem.xBounds(1)),problem.xBounds(2));
        cxy(:,2)=min(max(cxy(:,2),problem.yBounds(1)),problem.yBounds(2));
        terrain=data.terrainHeight(problem,cxy(:,1),cxy(:,2));
        cAGL=legStartAGL(leg)+t.*(legEndAGL(leg)-legStartAGL(leg));
        cpref=terrain(:)+cAGL;
        xy=[xy;cxy]; %#ok<AGROW>
        pref=[pref;cpref]; %#ok<AGROW>
    end
    if leg<=M
        m=order(leg);
        terrain=data.terrainHeight(problem,arcXY{m}(:,1),arcXY{m}(:,2));
        apref=terrain(:)+arcAGL{m};
        xy=[xy;arcXY{m}]; %#ok<AGROW>
        pref=[pref;apref]; %#ok<AGROW>
    end
end
xy=[xy;problem.goal(1:2)];
pref=[pref;problem.goal(3)];
fullXY=xy;
preferredZ=pref;
end

function direction=localLegStartDirection(leg,order,arcXY,a,b)
if leg==1
    direction=b-a;
else
    m=order(leg-1);
    arc=arcXY{m};
    if size(arc,1)>=2
        direction=arc(end,:)-arc(end-1,:);
    else
        direction=b-a;
    end
end
direction=localUnitDirection(direction,b-a);
end

function direction=localLegEndDirection(leg,order,arcXY,a,b)
M=numel(order);
if leg==M+1
    direction=b-a;
else
    m=order(leg);
    arc=arcXY{m};
    if size(arc,1)>=2
        direction=arc(2,:)-arc(1,:);
    else
        direction=b-a;
    end
end
direction=localUnitDirection(direction,b-a);
end

function cxy=localTangentTransit(a,b,startDir,endDir,t,cfg)
v=b-a;
distance=norm(v);
if distance<=eps
    cxy=repmat(a,numel(t),1);
    return;
end
baseHandle=min(max(localCfg(cfg,'structuredTransitTangentHandleFraction',0.32),0),0.495);
maxHandle=min(max(localCfg(cfg,'structuredTransitTangentHandleMaxFraction',0.495), ...
    baseHandle),0.495);
startMismatch=localDirectionAngle(startDir,v);
endMismatch=localDirectionAngle(v,endDir);
turnScale=max(localCfg(cfg,'maxTurnAngleDeg',180),eps);
severity=min(1,max(startMismatch,endMismatch)/turnScale);
handleFraction=baseHandle+(maxHandle-baseHandle)*severity;
handle=handleFraction*distance;
p0=a;
p1=a+handle*localUnitDirection(startDir,v);
p2=b-handle*localUnitDirection(endDir,v);
p3=b;
one=1-t;
cxy=(one.^3).*p0 + 3*(one.^2).*t.*p1 + ...
    3*one.*(t.^2).*p2 + (t.^3).*p3;
end

function direction=localUnitDirection(direction,fallback)
if numel(direction)~=2 || any(~isfinite(direction)) || norm(direction)<1e-10
    direction=fallback;
end
if numel(direction)~=2 || any(~isfinite(direction)) || norm(direction)<1e-10
    direction=[1 0];
end
direction=reshape(direction,1,2)/(norm(direction)+eps);
end

function score=localTransitDifficulty(a,b,problem,cfg)
v=b-a;
d=norm(v);
if d<eps, score=eps; return; end
n=max(3,round(localCfg(cfg,'structuredTransitDifficultySamples',7)));
t=linspace(0,1,n)';
xy=a+t.*v;
terrain=data.terrainHeight(problem,xy(:,1),xy(:,2));
relief=max(terrain)-min(terrain);
score=d*(1+localCfg(cfg,'structuredTransitReliefWeight',1.5)* ...
    relief/max(d,1));
end

function demand=localTransitTurnDemand(leg,order,arcXY,a,b)
% Maximum 2-D heading mismatch if this transit leg had no connector node.
% It is used only to allocate the fixed connector budget; the formal turn
% constraint remains the existing 3-D evaluator check.
M=numel(order);
chord=b-a;
if norm(chord)<1e-10
    demand=0;
    return;
end
startDemand=0;
endDemand=0;
if leg>1
    m=order(leg-1);
    arc=arcXY{m};
    if size(arc,1)>=2
        startDemand=localDirectionAngle(arc(end,:)-arc(end-1,:),chord);
    end
end
if leg<=M
    m=order(leg);
    arc=arcXY{m};
    if size(arc,1)>=2
        endDemand=localDirectionAngle(chord,arc(2,:)-arc(1,:));
    end
end
demand=max(startDemand,endDemand);
end

function angleDeg=localDirectionAngle(a,b)
a=reshape(a,1,[]); b=reshape(b,1,[]);
if numel(a)~=2 || numel(b)~=2 || any(~isfinite(a)) || ...
        any(~isfinite(b)) || norm(a)<1e-10 || norm(b)<1e-10
    angleDeg=0;
    return;
end
c=dot(a,b)/(norm(a)*norm(b)+eps);
angleDeg=acosd(max(-1,min(1,c)));
end

function cost=localConnectorTurnCostMatrix(order,arcXY,legStart,legEnd,cfg)
% Predict the local 2-D turn produced by 0/1/2 connector nodes on each leg.
% Bias is intentionally omitted here; allocation should reflect topology rather
% than a stochastic lateral offset. The actual decoder still tests the configured
% bias scales after the count vector has been chosen.
M=numel(order);
L=M+1;
maxCount=localCfg(cfg,'structuredTransitMaximumConnectorsPerLeg',2);
if ~isfinite(maxCount), maxCount=2; end
maxCount=max(2,round(maxCount));
cost=inf(L,maxCount+1);
for leg=1:L
    a=legStart(leg,:); b=legEnd(leg,:); v=b-a; distance=norm(v);
    for n=0:maxCount
        pts=[];
        if leg>1
            m=order(leg-1); arc=arcXY{m};
            if size(arc,1)>=2, pts=[pts;arc(end-1,:)]; end %#ok<AGROW>
        end
        pts=[pts;a]; %#ok<AGROW>
        if n>0
            t=(1:n)'/(n+1);
            cxy=a+t.*v;
            pts=[pts;cxy]; %#ok<AGROW>
        end
        pts=[pts;b]; %#ok<AGROW>
        if leg<=M
            m=order(leg); arc=arcXY{m};
            if size(arc,1)>=2, pts=[pts;arc(2,:)]; end %#ok<AGROW>
        end
        cost(leg,n+1)=localMax2DTurn(pts);
    end
end
end

function maxTurn=localMax2DTurn(xy)
seg=diff(xy,1,1);
if size(seg,1)<2, maxTurn=0; return; end
d=sqrt(sum(seg.^2,2));
cosine=sum(seg(1:end-1,:).*seg(2:end,:),2)./(d(1:end-1).*d(2:end)+eps);
turn=acosd(max(-1,min(1,cosine)));
maxTurn=max([0;turn(:)]);
end

function budget=localMinimumConnectorBudget(M,cfg)
boundaryMin=max(0,round(localCfg(cfg,'structuredTransitMinimumBoundaryConnectors',0)));
budget=2*boundaryMin;
if M<1, budget=0; end
end

function [ok,maxTurn]=localTurnCheck(path,cfg)
seg=diff(path,1,1);
d=sqrt(sum(seg.^2,2));
if size(seg,1)<2, maxTurn=0; ok=true; return; end
cosine=sum(seg(1:end-1,:).*seg(2:end,:),2)./(d(1:end-1).*d(2:end)+eps);
turn=acosd(max(-1,min(1,cosine)));
maxTurn=max([0;turn(:)]);
ok=maxTurn<=localCfg(cfg,'maxTurnAngleDeg',180)+1e-8;
end

function y=localPiecewiseMap(u,centre,lo,hi)
u=min(max(u,-1),1);
if u<0
    y=centre+(-u)*(lo-centre);
else
    y=centre+u*(hi-centre);
end
end

function v=localRotate(v,a)
R=[cos(a) -sin(a);sin(a) cos(a)];
v=(R*v(:))';
end

function info=localEmptyInfo(layout)
info=struct('success',false,'reason','invalid','targetOrder',[], ...
    'dimension',layout.dimension,'arcPointCount',0,'connectorBudget',0, ...
    'minimumConnectorBudget',0,'connectorCount',[],'legTurnDemandDeg',[], ...
    'connectorTurnCostDeg',[], ...
    'biasScale',NaN,'denseSuccess',false,'turnSuccess',false,'projection',struct(), ...
    'staticProjection',struct(),'maxTurnDeg',inf,'arcLength_m',[], ...
    'radiusScale',[],'sectorOffsetRad',[],'preferredAGL_m',[], ...
    'segmentTerrainCacheEnabled',false,'decoderTime_s',0, ...
    'denseProjectionTime_s',0,'terrainSamplingTime_s',0, ...
    'terrainSampleCacheHits',0,'terrainSampleCacheMisses',0, ...
    'denseProjectionNonSamplingTime_s',0);
end

function [terrainTime,hits,misses]=localAccumulateProjectionPerformance( ...
    projection,terrainTime,hits,misses)
if ~isstruct(projection), return; end
if isfield(projection,'terrainSamplingTime_s') && ...
        isfinite(projection.terrainSamplingTime_s)
    terrainTime=terrainTime+projection.terrainSamplingTime_s;
end
if isfield(projection,'terrainSampleCacheHits') && ...
        isfinite(projection.terrainSampleCacheHits)
    hits=hits+projection.terrainSampleCacheHits;
end
if isfield(projection,'terrainSampleCacheMisses') && ...
        isfinite(projection.terrainSampleCacheMisses)
    misses=misses+projection.terrainSampleCacheMisses;
end
end

function info=localFinalizePerformanceInfo(info,decoderTimer,projectionTime, ...
    terrainSamplingTime,hits,misses,cacheEnabled)
info.segmentTerrainCacheEnabled=logical(cacheEnabled);
info.decoderTime_s=toc(decoderTimer);
info.denseProjectionTime_s=projectionTime;
info.terrainSamplingTime_s=terrainSamplingTime;
info.terrainSampleCacheHits=hits;
info.terrainSampleCacheMisses=misses;
info.denseProjectionNonSamplingTime_s=max(0,projectionTime-terrainSamplingTime);
end

function value=localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value=cfg.(name); else, value=defaultValue; end
end
