function genes = initializeGenes(problem,cfg,mode,variant)
%INITIALIZEGENES Create goal-, corridor-, monitoring- or random-biased genes.
% VARIANT selects a deterministic high-quality monitoring route for the first
% guided seeds and diversified near-shortest target orders afterwards.
if nargin < 4, variant = 1; end
K = cfg.numWaypoints;
s = problem.start;
g = problem.goal;
t = linspace(0,1,K+2)';
t = t(2:end-1);
base = s+t.*(g-s);

switch mode
    case 1
        pts = base+[cfg.initNoiseXY*randn(K,2), ...
            cfg.initNoiseZ*randn(K,1)];

    case 2
        bend = sin(pi*t);
        normal = [-(g(2)-s(2)),g(1)-s(1)];
        normal = normal/(norm(normal)+eps);
        side = (2*rand-1)*localCfg(cfg,'corridorInitSideScale',18);
        pts = base;
        pts(:,1:2) = pts(:,1:2)+side*bend.*normal+ ...
            0.35*cfg.initNoiseXY*randn(K,2);

    case 3
        % Preserve a genuine multi-point observation arc at every target.
        % The former pchip resampling could smooth an expensive off-route
        % target out of the chromosome before evolution even started.
        T = problem.monitorTargets;
        order = localTargetOrder(s,g,T,variant,cfg,problem);
        anchors = s;
        previousXY = s(1:2);
        for ii = 1:numel(order)
            m = order(ii);
            if ii < numel(order)
                nextXY = T(order(ii+1),1:2);
            else
                nextXY = g(1:2);
            end
            arc = localObservationArc(T(m,:),m,previousXY,nextXY,problem,cfg);
            anchors = [anchors;arc]; %#ok<AGROW>
            previousXY = arc(end,1:2);
        end
        anchors = [anchors;g];
        anchors = localFitAnchorCount(anchors,K+2,problem,cfg);
        pts = anchors(2:end-1,:);

        eliteCount = localCfg(cfg,'monitorGuidedSeedEliteCount',2);
        if variant > eliteCount
            noiseScale = localCfg(cfg,'monitorGuidedSeedNoiseScale',0.08);
            pts(:,1:2) = pts(:,1:2)+ ...
                noiseScale*cfg.initNoiseXY*randn(K,2);
            pts(:,3) = pts(:,3)+ ...
                noiseScale*cfg.initNoiseZ*randn(K,1);
        end

    otherwise
        pts = [problem.xBounds(1)+diff(problem.xBounds)*rand(K,1), ...
            problem.yBounds(1)+diff(problem.yBounds)*rand(K,1), ...
            zeros(K,1)];
end

% Query all waypoint terrain heights in one interpolation batch.  This is
% equivalent to the former K scalar calls and is important for the 72-point
% Shiyan chromosome.
h = data.terrainHeight(problem,pts(:,1),pts(:,2));
h = h(:);
if mode==4
    pts(:,3) = h+cfg.safeClearance+5+25*rand(K,1);
else
    pts(:,3) = max(pts(:,3),h+cfg.safeClearance+2);
end
pts(:,3) = min(pts(:,3),cfg.maxAltitude);
genes = pts(:)';
end

function order = localTargetOrder(s,g,T,variant,cfg,problem)
M = size(T,1);
if M <= 1
    order = 1:M;
    return;
end
exactOrderLimit = max(1,round(localCfg(cfg,'monitorGuidedExactOrderMaxTargets',8)));
if M <= exactOrderLimit
    routes = perms(1:M);
    score = zeros(size(routes,1),1);
    for r = 1:size(routes,1)
        xy = [s(1:2);T(routes(r,:),1:2);g(1:2)];
        score(r) = sum(vecnorm(diff(xy,1,1),2,2))+ ...
            localObstacleOrderPenalty(xy,problem,cfg);
    end
    [~,ranked] = sort(score,'ascend');
    routes = routes(ranked,:);
    eliteCount = min(size(routes,1), ...
        max(2,localCfg(cfg,'monitorGuidedSeedEliteCount',2)));
    if variant <= eliteCount
        q = variant;
    else
        q = randi(min(size(routes,1),max(6,eliteCount)));
    end
    order = routes(q,:);
else
    % Large monitoring missions: goal-aware nearest-neighbour seed followed
    % by a small deterministic 2-opt pass. This avoids the long zig-zag
    % routes produced by sorting many targets only along the Start-Goal axis.
    remaining = 1:M;
    order = zeros(1,M);
    current = s(1:2);
    eliteCount = max(2,localCfg(cfg,'monitorGuidedSeedEliteCount',2));
    if variant <= eliteCount
        neighbourRank = 1;
    else
        neighbourRank = 1+mod(variant-eliteCount-1,3);
    end
    for k = 1:M
        dCurrent = vecnorm(T(remaining,1:2)-current,2,2);
        dGoal = vecnorm(T(remaining,1:2)-g(1:2),2,2);
        greedyScore = dCurrent+0.10*dGoal;
        [~,ranked] = sort(greedyScore,'ascend');
        q = ranked(min(neighbourRank,numel(ranked)));
        order(k) = remaining(q);
        current = T(order(k),1:2);
        remaining(q) = [];
    end
    order = localTwoOptOrder(order,s,g,T,problem,cfg);
end
end

function order = localTwoOptOrder(order,s,g,T,problem,cfg)
maxPasses = max(1,round(localCfg(cfg,'monitorGuidedTwoOptPasses',4)));
bestScore = localOrderScore(order,s,g,T,problem,cfg);
for pass = 1:maxPasses
    improved = false;
    for i = 1:numel(order)-1
        for j = i+1:numel(order)
            candidate = order;
            candidate(i:j) = order(j:-1:i);
            candidateScore = localOrderScore(candidate,s,g,T,problem,cfg);
            if candidateScore < bestScore-1e-9
                order = candidate;
                bestScore = candidateScore;
                improved = true;
            end
        end
    end
    if ~improved, break; end
end
end

function score = localOrderScore(order,s,g,T,problem,cfg)
xy = [s(1:2);T(order,1:2);g(1:2)];
score = sum(vecnorm(diff(xy,1,1),2,2))+ ...
    localObstacleOrderPenalty(xy,problem,cfg);
end

function penalty = localObstacleOrderPenalty(xy,problem,cfg)
penalty = 0;
if ~isfield(problem,'obstacles') || isempty(problem.obstacles), return; end
weight = localCfg(cfg,'monitorGuidedObstacleOrderPenalty',25);
margin = localCfg(cfg,'monitorGuidedObstacleOrderMargin',3);
for k = 1:size(xy,1)-1
    a = xy(k,:);
    b = xy(k+1,:);
    v = b-a;
    for j = 1:size(problem.obstacles,1)
        centre = problem.obstacles(j,1:2);
        tau = dot(centre-a,v)/(dot(v,v)+eps);
        tau = min(max(tau,0),1);
        distance = norm(a+tau*v-centre);
        deficit = max(0,problem.obstacles(j,3)+margin-distance);
        penalty = penalty+weight*deficit;
    end
end
end

function arc = localObservationArc(target,targetIndex,previousXY,nextXY,problem,cfg)
isCritical = ismember(targetIndex,cfg.criticalTargetIndices(:)');
if isCritical
    numArc = max(3,round(localCfg(cfg,'multiUAVCriticalMonitorGuidedArcPoints',5)));
    baseAngleDeg = localCfg(cfg,'multiUAVCriticalMonitorGuidedViewAngleDeg',46);
else
    numArc = max(2,round(localCfg(cfg,'monitorGuidedArcPoints',3)));
    baseAngleDeg = localCfg(cfg,'monitorGuidedViewAngleDeg',28);
end
targetXY = target(1:2);

incoming = previousXY-targetXY;
outgoing = nextXY-targetXY;
if norm(incoming)>eps, incoming = incoming/norm(incoming); end
if norm(outgoing)>eps, outgoing = outgoing/norm(outgoing); end
baseDirection = incoming+outgoing;
if norm(baseDirection)<1e-8
    route = nextXY-previousXY;
    baseDirection = [-route(2) route(1)];
end
if norm(baseDirection)<1e-8, baseDirection = [1 0]; end
baseDirection = baseDirection/(norm(baseDirection)+eps);
geom = core.observationArcGeometry(targetIndex,problem,cfg,baseDirection,1, ...
    baseAngleDeg,localCfg(cfg,'monitorGuidedRadiusScale',1));
radius = geom.radius;
baseDirection = geom.direction;
angle = geom.halfAngleRad;

offsets = linspace(-angle,angle,numArc);
arcXY = zeros(numArc,2);
for j = 1:numArc
    R = [cos(offsets(j)) -sin(offsets(j)); ...
        sin(offsets(j)) cos(offsets(j))];
    arcXY(j,:) = targetXY+radius*(R*baseDirection')';
end
reverseXY = flipud(arcXY);
costForward = norm(previousXY-arcXY(1,:))+ ...
    sum(vecnorm(diff(arcXY,1,1),2,2))+norm(arcXY(end,:)-nextXY);
costReverse = norm(previousXY-reverseXY(1,:))+ ...
    sum(vecnorm(diff(reverseXY,1,1),2,2))+norm(reverseXY(end,:)-nextXY);
if costReverse < costForward, arcXY = reverseXY; end
terrain = data.terrainHeight(problem,arcXY(:,1),arcXY(:,2));
arcZ = terrain(:)+target(5);
arc = [arcXY arcZ];
end

function anchors = localFitAnchorCount(anchors,required,problem,cfg)
% Add connector points on the longest gaps without moving target arcs.
while size(anchors,1) < required
    gap = vecnorm(diff(anchors(:,1:2),1,1),2,2);
    [~,k] = max(gap);
    xy = 0.5*(anchors(k,1:2)+anchors(k+1,1:2));
    interpolatedZ = 0.5*(anchors(k,3)+anchors(k+1,3));
    terrain = data.terrainHeight(problem,xy(1),xy(2));
    z = max(interpolatedZ,terrain+cfg.safeClearance+2);
    anchors = [anchors(1:k,:);xy z;anchors(k+1:end,:)]; %#ok<AGROW>
end
if size(anchors,1) > required
    cumulative = [0;cumsum(vecnorm(diff(anchors,1,1),2,2))];
    q = cumulative/max(cumulative(end),eps);
    tq = linspace(0,1,required)';
    fitted = zeros(required,3);
    for dim = 1:3
        fitted(:,dim) = interp1(q,anchors(:,dim),tq,'linear');
    end
    fitted(1,:) = anchors(1,:);
    fitted(end,:) = anchors(end,:);
    anchors = fitted;
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
