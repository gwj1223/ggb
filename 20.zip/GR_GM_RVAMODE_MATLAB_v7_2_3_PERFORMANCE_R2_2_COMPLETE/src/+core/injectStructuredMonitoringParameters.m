function [candidate,pre] = injectStructuredMonitoringParameters( ...
    base,targetIndex,problem,cfg,variant)
%INJECTSTRUCTUREDMONITORINGPARAMETERS Semantic A3 candidate for v7.2.0.
%
% Only the selected target's [radius,sector,arc,height] genes are changed.
% Transit and all other target genes remain untouched. The candidate is then
% decoded through the same structured decoder used by DE offspring.

candidate=base;
pre=struct('success',false,'reason','invalid','score',-inf, ...
    'blockCount',0,'profileInfo',struct());
if ~isfield(base,'structuredGenes') || isempty(base.structuredGenes)
    pre.reason='structured_genes';
    return;
end
layout=core.structuredMonitoringLayout(problem,cfg);
if targetIndex<1 || targetIndex>layout.targetCount
    pre.reason='target';
    return;
end
u=reshape(base.structuredGenes,1,[]);
if numel(u)~=layout.dimension
    pre.reason='dimension';
    return;
end

dims=layout.targetDims(targetIndex,:);
% Nine deterministic semantic variants: radius x sector. Every variant also
% increases observation-arc capacity and nudges height toward the physical
% desired AGL. Variant 1 is the conservative centre move.
radiusStep=localCfg(cfg,'structuredA3RadiusGeneStep',0.28);
sectorStep=localCfg(cfg,'structuredA3SectorGeneStep',0.38);
arcStep=localCfg(cfg,'structuredA3ArcGeneStep',0.32);
heightBlend=localCfg(cfg,'structuredA3HeightBlendToDesired',0.50);
grid=[0 0; -1 0; 1 0; 0 -1; 0 1; -1 -1; -1 1; 1 -1; 1 1];
q=1+mod(max(1,round(variant))-1,size(grid,1));
move=grid(q,:);

% Pull the centre candidate toward the KB-preferred radius/sector (gene 0).
% Other variants explore bounded offsets around that improved centre.
baseRadius=0.65*u(dims(1));
baseSector=0.65*u(dims(2));
u(dims(1))=baseRadius+radiusStep*move(1);
u(dims(2))=baseSector+sectorStep*move(2);
u(dims(3))=max(u(dims(3)),min(1,u(dims(3))+arcStep));
u(dims(4))=(1-heightBlend)*u(dims(4));
u=min(max(u,-1),1);

candidate.structuredGenes=u;
[phenotype,decodeInfo]=core.decodeStructuredMonitoringGenes(u,problem,cfg);
candidate.genes=phenotype;
candidate.encodingInfo=decodeInfo;
if ~decodeInfo.success
    pre.reason=decodeInfo.reason;
    if isfield(decodeInfo,'projection'), pre.profileInfo=decodeInfo.projection; end
    return;
end
pre.success=true;
pre.reason='ok';
pre.profileInfo=decodeInfo.projection;
pre.blockCount=sum(ismember(1:layout.dimension,dims));
% Prefer dense slack, lower turn, and longer selected-target observation arc.
slack=0;
if isfield(decodeInfo.projection,'minimumSlack') && ...
        isfinite(decodeInfo.projection.minimumSlack)
    slack=decodeInfo.projection.minimumSlack;
end
turnPenalty=max(0,decodeInfo.maxTurnDeg/localCfg(cfg,'maxTurnAngleDeg',95));
arcBonus=0;
if numel(decodeInfo.arcLength_m)>=targetIndex && ...
        isfinite(decodeInfo.arcLength_m(targetIndex))
    arcBonus=decodeInfo.arcLength_m(targetIndex)/ ...
        max(localCfg(cfg,'monitorRequiredObservationLength',300),eps);
end
pre.score=0.01*slack+0.35*arcBonus-0.20*turnPenalty;
end

function value=localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value=cfg.(name); else, value=defaultValue; end
end
