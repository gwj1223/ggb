function layout = structuredMonitoringLayout(problem,cfg)
%STRUCTUREDMONITORINGLAYOUT Canonical v7.2.0 semantic chromosome layout.
%
% Each local monitoring target owns four normalized genes:
%   [radius, sectorOffset, arcLength, observationHeight]
% Each transit leg (start->T1, ..., TM->goal) owns one normalized lateral
% bias gene. All semantic genes are bounded to [-1,1].

M = size(problem.monitorTargets,1);
layout.targetCount = M;
layout.targetDims = zeros(M,4);
for m = 1:M
    layout.targetDims(m,:) = 4*(m-1)+(1:4);
end
layout.transitDims = 4*M+(1:(M+1));
layout.dimension = 5*M+1;
layout.radiusColumn = 1;
layout.sectorColumn = 2;
layout.arcLengthColumn = 3;
layout.heightColumn = 4;
layout.lowerBound = -ones(1,layout.dimension);
layout.upperBound = ones(1,layout.dimension);
layout.numWaypoints = cfg.numWaypoints;
end
