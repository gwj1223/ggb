function tf = finalStageStoppingEvidenceAvailable(finalArchive,bestCommonHV,bestFinalCost)
%FINALSTAGESTOPPINGEVIDENCEAVAILABLE True only after real formal evidence exists.
% Stagnation clocks alone are not evidence of convergence. At least one formal
% archive member and finite Common-HV / physical-cost anchors are required.
tf = ~isempty(finalArchive) && isscalar(bestCommonHV) && ...
    isfinite(bestCommonHV) && isscalar(bestFinalCost) && isfinite(bestFinalCost);
end
