function pop = restartInfeasiblePopulation(pop,problem,cfg,generation)
%RESTARTINFEASIBLEPOPULATION Replace worst infeasible solutions structurally.
% v7.2.1 keeps restart writes in the same representation as evolution.
N=numel(pop); n=max(1,ceil(cfg.infeasibleRestartFraction*N));
[~,ord]=sort([pop.cv],'descend'); replace=ord(1:n);
[~,bestIdx]=min([pop.cv]);
structuredMode=localCfg(cfg,'enableStructuredMonitoringEncoding',false) && ...
    isfield(pop,'structuredGenes') && ...
    any(arrayfun(@(x)~isempty(x.structuredGenes),pop));

if structuredMode
    bestStructured=reshape(pop(bestIdx).structuredGenes,1,[]);
    for k=1:n
        if k/n<=0.40
            semantic=core.initializeStructuredMonitoringGenes(problem,cfg,2,k);
        elseif k/n<=0.70
            semantic=core.initializeStructuredMonitoringGenes(problem,cfg,3,k);
        else
            semantic=bestStructured+ ...
                localCfg(cfg,'structuredRestartNoiseScale',0.18)* ...
                randn(size(bestStructured));
        end
        semantic=min(max(semantic,-1),1);
        ind=pop(replace(k));
        ind.structuredGenes=semantic;
        [ind.genes,ind.encodingInfo]= ...
            core.decodeStructuredMonitoringGenes(semantic,problem,cfg);
        ind=evaluation.evaluateIndividual(ind,problem,cfg,generation);
        pop(replace(k))=ind;
    end
    return;
end

bestGenes=pop(bestIdx).genes;
for k=1:n
    if k/n<=0.40
        mode=2; genes=core.initializeGenes(problem,cfg,mode);
    elseif k/n<=0.70
        mode=3; genes=core.initializeGenes(problem,cfg,mode);
    else
        scale=[diff(problem.xBounds)*ones(1,cfg.numWaypoints), ...
            diff(problem.yBounds)*ones(1,cfg.numWaypoints), ...
            cfg.maxAltitude*ones(1,cfg.numWaypoints)];
        genes=bestGenes+0.12*randn(size(bestGenes)).*scale;
    end
    ind=pop(replace(k)); ind.genes=genes;
    ind=repair.repairPath(ind,problem,cfg);
    ind=evaluation.evaluateIndividual(ind,problem,cfg,generation);
    pop(replace(k))=ind;
end
end

function value=localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value=cfg.(name); else, value=defaultValue; end
end
