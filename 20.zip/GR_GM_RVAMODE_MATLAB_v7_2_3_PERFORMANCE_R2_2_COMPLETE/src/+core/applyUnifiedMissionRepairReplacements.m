function pop = applyUnifiedMissionRepairReplacements(pop,replacementIdx,replacements)
%APPLYUNIFIEDMISSIONREPAIRREPLACEMENTS Canonical protected A3 write-back.
%
% Unified A3 is a repair operator, not a second environmental selection.
% Candidates that already passed static feasibility, global mission
% non-regression, formal-condition protection and selected-target progress
% replace only their originating bases. Rank/crowding metadata is refreshed
% afterward for subsequent evolutionary search.

if isempty(replacementIdx)
    return;
end
replacementIdx = replacementIdx(:);
replacements = replacements(:);
if numel(replacementIdx)~=numel(replacements)
    error('core:UnifiedMissionRepairReplacementCountMismatch', ...
        'replacementIdx and replacements must have the same number of elements.');
end
if any(~isfinite(replacementIdx)) || any(replacementIdx<1) || ...
        any(replacementIdx>numel(pop)) || any(replacementIdx~=round(replacementIdx))
    error('core:UnifiedMissionRepairReplacementIndex', ...
        'Replacement indices must be valid integer population indices.');
end
if numel(unique(replacementIdx))~=numel(replacementIdx)
    error('core:UnifiedMissionRepairReplacementDuplicate', ...
        'Each A3 base may be replaced at most once per repair event.');
end

pop(replacementIdx) = replacements;
pop = selection.assignRankCrowding(pop);
end
