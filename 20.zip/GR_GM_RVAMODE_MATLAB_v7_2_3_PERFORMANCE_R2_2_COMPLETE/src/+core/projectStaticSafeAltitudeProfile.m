function [z,info] = projectStaticSafeAltitudeProfile(xy,startZ,endZ,preferredZ,problem,cfg)
%PROJECTSTATICSAFEALTITUDEPROFILE Project a local XY corridor into a feasible Z profile.
%
% v7.0.4 A3 helper. XY is fixed. The first/last altitude are fixed to the
% surrounding route while interior altitudes are projected into the local
% terrain-relative AGL envelope and the hard climb-angle cone. The algorithm
% uses forward reachable altitude intervals followed by a backward choice
% closest to the preferred observation shelf. It requires no Optimization
% Toolbox and never relaxes the formal AGL or climb limits.
%
% Inputs
%   xy         : N-by-2 local corridor including the two fixed boundary nodes
%   startZ     : fixed altitude at xy(1,:)
%   endZ       : fixed altitude at xy(end,:)
%   preferredZ : scalar or N-vector preferred absolute altitude
%   problem,cfg: ordinary project problem/config
%
% Outputs
%   z          : N-by-1 altitude profile (empty when infeasible)
%   info       : diagnostic structure

N = size(xy,1);
info = struct('success',false,'reason','invalid','minimumSlack',-inf, ...
    'maxClimbDeg',inf,'minimumAGL',-inf,'maximumAGL',inf);
z = zeros(0,1);
if N < 2 || size(xy,2) ~= 2 || any(~isfinite(xy(:))) || ...
        ~isscalar(startZ) || ~isscalar(endZ) || ...
        ~isfinite(startZ) || ~isfinite(endZ)
    return;
end

terrain = data.terrainHeight(problem,xy(:,1),xy(:,2));
terrain = terrain(:);
if any(~isfinite(terrain))
    info.reason = 'terrain';
    return;
end
margin = localCfg(cfg,'segmentRepairMargin',0);
lower = terrain + localCfg(cfg,'safeClearance',0) + margin;
upper = localCfg(cfg,'maxAltitude',inf)*ones(N,1);
if localCfg(cfg,'enableLocalAGLConstraint',false) && ...
        isfield(cfg,'realMaximumAGL') && isfinite(cfg.realMaximumAGL)
    upper = min(upper,terrain + cfg.realMaximumAGL - margin);
end
if any(lower>upper)
    info.reason = 'agl_interval';
    return;
end

% Fixed surrounding-route endpoints come from an already static-feasible
% base. Do not require the extra repair margin at those untouched nodes: the
% formal 60--320 m envelope is the correct boundary contract. Interior nodes
% retain the repair margin to leave room for dense segment polishing.
tol = max(localCfg(cfg,'constraintTolerance',1e-8),1e-8);
formalLower = terrain + localCfg(cfg,'safeClearance',0);
formalUpper = localCfg(cfg,'maxAltitude',inf)*ones(N,1);
if localCfg(cfg,'enableLocalAGLConstraint',false) && ...
        isfield(cfg,'realMaximumAGL') && isfinite(cfg.realMaximumAGL)
    formalUpper=min(formalUpper,terrain+cfg.realMaximumAGL);
end
if startZ < formalLower(1)-tol || startZ > formalUpper(1)+tol || ...
        endZ < formalLower(end)-tol || endZ > formalUpper(end)+tol
    info.reason = 'boundary_agl';
    return;
end
lower(1)=startZ; upper(1)=startZ;
lower(end)=endZ; upper(end)=endZ;

horizontal = hypot(diff(xy(:,1)),diff(xy(:,2)));
maxDz = tand(localCfg(cfg,'maxClimbAngleDeg',90)).*max(horizontal,eps);

% Forward reachable intervals under |dz|<=maxDz.
reachLow = zeros(N,1);
reachHigh = zeros(N,1);
reachLow(1)=startZ;
reachHigh(1)=startZ;
for k=2:N
    reachLow(k)=max(lower(k),reachLow(k-1)-maxDz(k-1));
    reachHigh(k)=min(upper(k),reachHigh(k-1)+maxDz(k-1));
    if reachLow(k)>reachHigh(k)+tol
        info.reason='climb_reach';
        return;
    end
end
if endZ < reachLow(end)-tol || endZ > reachHigh(end)+tol
    info.reason='end_reach';
    return;
end

if isscalar(preferredZ)
    preferred = repmat(preferredZ,N,1);
else
    preferred = preferredZ(:);
    if numel(preferred)~=N || any(~isfinite(preferred))
        preferred = 0.5*(lower+upper);
    end
end

% Backward choose one member of every forward-reachable interval while
% remaining reachable from the fixed right endpoint.
z = zeros(N,1);
z(end)=endZ;
for k=N-1:-1:2
    lo=max(reachLow(k),z(k+1)-maxDz(k));
    hi=min(reachHigh(k),z(k+1)+maxDz(k));
    if lo>hi+tol
        z=zeros(0,1);
        info.reason='backward_reach';
        return;
    end
    z(k)=min(max(preferred(k),lo),hi);
end
z(1)=startZ;

agl=z-terrain;
segDz=diff(z);
climb=atan2d(abs(segDz),max(horizontal,eps));
info.success=true;
info.reason='ok';
info.minimumSlack=min([z-lower;upper-z]);
info.maxClimbDeg=max([0;climb(:)]);
info.minimumAGL=min(agl);
info.maximumAGL=max(agl);
end

function value=localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value=cfg.(name); else, value=defaultValue; end
end
