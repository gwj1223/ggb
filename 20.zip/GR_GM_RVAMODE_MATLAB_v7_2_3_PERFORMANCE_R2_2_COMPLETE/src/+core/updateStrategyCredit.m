function [strategyProb,diag] = updateStrategyCredit(strategyProb,stats,feasibleCount,cfg)
%UPDATESTRATEGYCREDIT Stage-dependent mutation-strategy credit assignment.
use=max(stats.useCount,1);
if feasibleCount==0
    a=localNormalize(stats.cvReduction./use);
    b=localNormalize(stats.nearFeasibleCount./use);
    c=localNormalize(stats.diversityContribution./use);
    score=cfg.infeasibleCVWeight*a+cfg.infeasibleNearFeasibleWeight*b+cfg.infeasibleDiversityWeight*c;
else
    a=localNormalize(stats.acceptedCount./use);
    b=localNormalize(stats.monitoringGain./use);
    c=localNormalize(stats.diversityContribution./use);
    score=cfg.feasibleSuccessWeight*a+cfg.feasibleMonitoringWeight*b+cfg.feasibleDiversityWeight*c;
end
score=score+cfg.strategyScoreEpsilon;
target=core.normalizeStrategyProbabilities(score,cfg);
eta=cfg.strategyUpdateRate;
strategyProb=(1-eta)*strategyProb+eta*target;
strategyProb=core.normalizeStrategyProbabilities(strategyProb,cfg);
diag.score=score; diag.targetProbability=target; diag.probability=strategyProb;
end
function x=localNormalize(x)
x=double(x(:)'); x(~isfinite(x))=0; x=max(x,0); m=max(x);
if m<=eps, x=zeros(size(x)); else, x=x/m; end
end
