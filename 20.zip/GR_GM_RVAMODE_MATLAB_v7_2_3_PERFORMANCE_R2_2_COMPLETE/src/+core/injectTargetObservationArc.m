function [ind,diag] = injectTargetObservationArc(ind,targetIndex,problem,cfg,variant)
%INJECTTARGETOBSERVATIONARC Dense-3D-screened A3 observation corridor edit.
%
% v7.0.5 keeps the same Monitoring Knowledge Base and observation semantics,
% but changes the order of operations:
%   geometry candidate -> adaptive block -> dense DEM AGL/climb reachability
%   -> 3D turn precheck -> only then return a trial for full evaluation.
%
% There is intentionally NO infeasible altitude fallback. If a candidate XY
% corridor has no admissible straight-segment Z profile under the formal DEM
% envelope and climb limit, diag.success=false and A3 tries another geometry.
% No historical chromosome is stored or restored.

if nargin < 5 || isempty(variant), variant = 1; end
diag = localEmptyDiag();
T = problem.monitorTargets;
if targetIndex < 1 || targetIndex > size(T,1)
    error('core:InvalidCoverageTarget','Invalid target index %d.',targetIndex);
end

original = ind;
pts = reshape(ind.genes,[],3);
K = size(pts,1);
target = T(targetIndex,:);
isCritical = ismember(targetIndex,cfg.criticalTargetIndices(:)');
if isCritical
    arcCount = max(3,round(localCfg(cfg,'missionRepairCriticalArcPoints',5)));
    halfAngleDeg = localCfg(cfg,'missionRepairCriticalHalfAngleDeg',46);
else
    arcCount = max(2,round(localCfg(cfg,'missionRepairOrdinaryArcPoints',3)));
    halfAngleDeg = localCfg(cfg,'missionRepairOrdinaryHalfAngleDeg',32);
end
arcCount = min(arcCount,K);
transitionEach = max(0,round(localCfg(cfg, ...
    'missionRepairTransitionPointsPerSide',2)));
minimumBlock = min(K,arcCount+2*transitionEach);
maximumBlock = min(K,max(minimumBlock,round(localCfg(cfg, ...
    'missionRepairMaxBlockPoints',13))));
targetXY = target(1:2);

% Geometry-pool mapping. A scalar variant enumerates direction and radius
% alternatives without increasing the full objective-evaluation budget.
directionVariants=max(1,round(localCfg(cfg,'missionRepairDirectionVariants',3)));
radiusFactors=localCfg(cfg,'missionRepairRadiusFactors',[0.85 1.00 1.15]);
radiusFactors=radiusFactors(:)';
radiusFactors=radiusFactors(isfinite(radiusFactors) & radiusFactors>0);
if isempty(radiusFactors), radiusFactors=1; end
directionVariant=mod(max(variant,1)-1,directionVariants)+1;
radiusIndex=mod(floor((max(variant,1)-1)/directionVariants), ...
    numel(radiusFactors))+1;
radiusFactor=radiusFactors(radiusIndex);

% Existing route segment nearest the target anchors the adaptive edit block.
pathXY = [problem.start(1:2);pts(:,1:2);problem.goal(1:2)];
segMid = 0.5*(pathXY(1:end-1,:)+pathXY(2:end,:));
[~,seg] = min(vecnorm(segMid-targetXY,2,2));
routeDirection = segMid(seg,:)-targetXY;
if norm(routeDirection)<1e-8, routeDirection=[1 0]; end

baseRadiusMultiplier=localCfg(cfg,'missionRepairRadiusMultiplier',1);
geom=core.observationArcGeometry(targetIndex,problem,cfg,routeDirection, ...
    directionVariant,halfAngleDeg,baseRadiusMultiplier*radiusFactor);
% Keep the final radius inside the established monitoring-arc scale contract.
scaleBounds=localCfg(cfg,'monitoringArcRadiusScaleBounds',[0.75 1.25]);
if numel(scaleBounds)~=2 || any(~isfinite(scaleBounds))
    scaleBounds=[0.75 1.25];
end
scaleBounds=sort(scaleBounds(:)');
radiusScale=min(max(geom.radius/max(target(4),eps),scaleBounds(1)),scaleBounds(2));
radius=max(target(4),eps)*radiusScale;
baseDirection=geom.direction;
halfAngle=geom.halfAngleRad;

offsets=linspace(-halfAngle,halfAngle,arcCount);
arcXY=zeros(arcCount,2);
for q=1:arcCount
    R=[cos(offsets(q)) -sin(offsets(q));sin(offsets(q)) cos(offsets(q))];
    arcXY(q,:)=targetXY+radius*(R*baseDirection')';
end
arcXY=localClampXY(arcXY,problem);

% Try progressively larger local blocks. More horizontal transition distance
% can make a steep target vertically reachable without adding decision
% variables; the chromosome length remains unchanged.
bestScore=-inf;
bestPts=[];
bestDiag=diag;
blockValues=minimumBlock:2:maximumBlock;
if isempty(blockValues) || blockValues(end)~=maximumBlock
    blockValues=unique([blockValues maximumBlock]);
end
for blockCount=blockValues
    extra=blockCount-arcCount;
    preCount=floor(extra/2);
    postCount=extra-preCount;
    oldArcFirst=min(max(seg,1),K-arcCount+1);
    first=oldArcFirst-preCount;
    first=min(max(first,1),K-blockCount+1);
    last=first+blockCount-1;

    before=problem.start; after=problem.goal;
    beforePrev=problem.start; afterNext=problem.goal;
    if first>1
        before=pts(first-1,:);
        if first>2, beforePrev=pts(first-2,:); end
    end
    if last<K
        after=pts(last+1,:);
        if last<K-1, afterNext=pts(last+2,:); end
    end

    orientedArc=arcXY;
    reverseXY=flipud(orientedArc);
    forwardCost=norm(before(1:2)-orientedArc(1,:))+ ...
        sum(vecnorm(diff(orientedArc,1,1),2,2))+ ...
        norm(orientedArc(end,:)-after(1:2));
    reverseCost=norm(before(1:2)-reverseXY(1,:))+ ...
        sum(vecnorm(diff(reverseXY,1,1),2,2))+ ...
        norm(reverseXY(end,:)-after(1:2));
    if reverseCost<forwardCost, orientedArc=reverseXY; end

    preXY=zeros(preCount,2); postXY=zeros(postCount,2);
    if arcCount>1
        arcStartTangent=orientedArc(2,:)-orientedArc(1,:);
        arcEndTangent=orientedArc(end,:)-orientedArc(end-1,:);
    else
        arcStartTangent=orientedArc(1,:)-before(1:2);
        arcEndTangent=after(1:2)-orientedArc(end,:);
    end
    if preCount>0
        routeIn=before(1:2)-beforePrev(1:2);
        if norm(routeIn)<1e-9, routeIn=orientedArc(1,:)-before(1:2); end
        preXY=localBezierConnector(before(1:2),orientedArc(1,:), ...
            routeIn,arcStartTangent,preCount);
    end
    if postCount>0
        routeOut=afterNext(1:2)-after(1:2);
        if norm(routeOut)<1e-9, routeOut=after(1:2)-orientedArc(end,:); end
        postXY=localBezierConnector(orientedArc(end,:),after(1:2), ...
            arcEndTangent,routeOut,postCount);
    end
    idealXY=localClampXY([preXY;orientedArc;postXY],problem);
    localXY=[before(1:2);idealXY;after(1:2)];

    if isfield(problem,'monitorTargetTerrain') && ...
            numel(problem.monitorTargetTerrain)>=targetIndex
        centreTerrain=problem.monitorTargetTerrain(targetIndex);
    else
        centreTerrain=data.terrainHeight(problem,targetXY(1),targetXY(2));
    end
    preferredCruiseZ=centreTerrain+target(5);
    if localCfg(cfg,'missionRepairUseDenseTerrainReachability',false)
        [localZ,profileInfo]=core.projectDenseTerrainReachableProfile( ...
            localXY,before(3),after(3),preferredCruiseZ,problem,cfg);
    else
        [localZ,profileInfo]=core.projectStaticSafeAltitudeProfile( ...
            localXY,before(3),after(3),preferredCruiseZ,problem,cfg);
    end
    if ~profileInfo.success
        bestDiag.reason=char(profileInfo.reason);
        bestDiag.profileInfo=profileInfo;
        continue;
    end
    idealZ=localZ(2:end-1);

    candidatePts=pts;
    candidatePts(first:last,:)=[idealXY idealZ];

    % 3D turn precheck includes one untouched segment on each side when
    % available. The formal static evaluator remains authoritative afterwards.
    local3D=[before;[idealXY idealZ];after];
    if first>1, local3D=[beforePrev;local3D]; end %#ok<AGROW>
    if last<K, local3D=[local3D;afterNext]; end %#ok<AGROW>
    maxTurn=localMaxTurnDeg(local3D);
    if localCfg(cfg,'missionRepairPrecheckTurn',true) && ...
            maxTurn>localCfg(cfg,'maxTurnAngleDeg',180)+1e-8
        tmp=localEmptyDiag();
        tmp.reason='turn'; tmp.maxTurnDeg=maxTurn; tmp.blockCount=blockCount;
        tmp.profileInfo=profileInfo;
        bestDiag=tmp;
        continue;
    end

    detour=localPolylineLength(local3D(:,1:2));
    slack=profileInfo.minimumSlack;
    if ~isfinite(slack), slack=-1e6; end
    score=slack-0.001*detour-0.15*blockCount- ...
        0.02*max(0,maxTurn-localCfg(cfg,'maxTurnAngleDeg',180));
    if score>bestScore
        bestScore=score;
        bestPts=candidatePts;
        tmp=localEmptyDiag();
        tmp.success=true;
        tmp.reason='ok';
        tmp.score=score;
        tmp.blockCount=blockCount;
        tmp.first=first; tmp.last=last;
        tmp.directionVariant=directionVariant;
        tmp.radiusFactor=radiusFactor;
        tmp.radiusScale=radiusScale;
        tmp.maxTurnDeg=maxTurn;
        tmp.profileInfo=profileInfo;
        bestDiag=tmp;
    end
end

if isempty(bestPts)
    ind=original;
    diag=bestDiag;
    return;
end
ind.genes=reshape(bestPts,1,[]);
diag=bestDiag;
end

function xy = localBezierConnector(P0,P3,tangent0,tangent3,count)
if count<=0, xy=zeros(0,2); return; end
d0=localUnit(tangent0,P3-P0);
d3=localUnit(tangent3,P3-P0);
chord=norm(P3-P0);
handle=min(0.40*chord,max(0.18*chord,chord/(count+2)));
P1=P0+handle*d0;
P2=P3-handle*d3;
xy=zeros(count,2);
for j=1:count
    t=j/(count+1); u=1-t;
    xy(j,:)=u^3*P0+3*u^2*t*P1+3*u*t^2*P2+t^3*P3;
end
end

function u = localUnit(v,fallback)
if norm(v)<1e-12, v=fallback; end
if norm(v)<1e-12, v=[1 0]; end
u=v/max(norm(v),eps);
end

function xy = localClampXY(xy,problem)
xy(:,1)=min(max(xy(:,1),problem.xBounds(1)),problem.xBounds(2));
xy(:,2)=min(max(xy(:,2),problem.yBounds(1)),problem.yBounds(2));
end

function value=localPolylineLength(xy)
if size(xy,1)<2, value=0; else, value=sum(vecnorm(diff(xy,1,1),2,2)); end
end

function value=localMaxTurnDeg(path)
value=0;
if size(path,1)<3, return; end
seg=diff(path,1,1);
d=sqrt(sum(seg.^2,2));
num=sum(seg(1:end-1,:).*seg(2:end,:),2);
den=d(1:end-1).*d(2:end)+eps;
a=acosd(max(-1,min(1,num./den)));
if ~isempty(a) && all(isfinite(a)), value=max(a); end
end

function diag=localEmptyDiag()
diag=struct('success',false,'reason','invalid','score',-inf, ...
    'blockCount',0,'first',0,'last',0,'directionVariant',0, ...
    'radiusFactor',NaN,'radiusScale',NaN,'maxTurnDeg',inf, ...
    'profileInfo',struct());
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
