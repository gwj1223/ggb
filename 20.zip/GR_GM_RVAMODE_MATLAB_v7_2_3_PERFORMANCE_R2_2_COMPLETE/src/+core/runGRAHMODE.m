function result = runGRAHMODE(problem,cfg)
%RUNGRAHMODE GR-GM-RVAMODE-VI v7.1.0 mission-band hierarchical search.
config.validateConfig(cfg,problem);
rng(cfg.randomSeed,'twister');
totalTimer = tic;

thresholdState = evaluation.initializeMonitoringThresholdState(cfg);
runtimeCfg = evaluation.applyMonitoringThresholdState(cfg,thresholdState);
finalThresholds = struct('minimum',cfg.monitorMinTargetQuality, ...
    'critical',cfg.monitorCriticalMinQuality, ...
    'observationLength',cfg.monitorCriticalMinObservationLength, ...
    'losRatio',cfg.monitorCriticalMinLOSRatio,'progress',1, ...
    'missionDeficitEpsilon',0,'missionStage','formal');

pop = core.initializePopulation(problem,runtimeCfg);
pop = evaluation.evaluatePopulation(pop,problem,runtimeCfg,1);
% v7.0.0: no historical chromosome is restored into the population.
% Mission feasibility is handled by one epsilon hierarchy plus one bounded
% DEM/LOS knowledge-guided corridor repair on current static-feasible carriers.
archive = selection.updateArchive([],pop,cfg.archiveSize,runtimeCfg,1);
[finalArchive,initialFinalCandidates] = localUpdateFinalArchive( ...
    [],pop,cfg,1,finalThresholds);
commonArchive = selection.updateCommonArchive([], ...
    initialFinalCandidates,localCfg(cfg,'commonArchiveSize',150),cfg);
commonCandidateBuffer = pop([]);
commonArchiveUpdateCount = 1;
commonHVEvaluationCount = 0;
bestCommonArchive = commonArchive;
bestRelaxedArchive = archive([archive.feasible]);
bestRelaxedProgress = thresholdState.progress;
bestRelaxedThresholds = [thresholdState.minimum thresholdState.critical ...
    thresholdState.observationLength thresholdState.losRatio];

muF = cfg.initialMuF;
muCR = cfg.initialMuCR;
strategyProb = core.normalizeStrategyProbabilities([0.40 0.35 0.25],cfg);
operatorState = operators.initializeFinalStageOperatorState(cfg);

% History columns are documented in exporter.saveRun.
history = nan(cfg.maxGenerations,86);
currentHVHist = nan(cfg.maxGenerations,1);
finalHVHist = nan(cfg.maxGenerations,1);
commonHVHist = nan(cfg.maxGenerations,1);
bestCommonHVHist = nan(cfg.maxGenerations,1);
bestCostHist = nan(cfg.maxGenerations,1);
hvSamples = metrics.createHVSamples(cfg);
lastCurrentHV = NaN;
lastFinalHV = NaN;
lastCommonHV = NaN;
bestCommonHV = -inf;
commonHVImprovementAnchor = NaN;
lastCommonHVImprovementGen = NaN;
bestFinalCost = inf;
costImprovementAnchor = NaN;
lastFinalCostImprovementGen = NaN;
currentBestFinalCost = NaN;
bestPhysicalSolution = [];
stopGen = cfg.maxGenerations;
stopReason = 'max_generations';
noFeasibleGenerations = 0;
restartCount = 0;
thresholdChangeCount = 0;
% v7.0.0 has exactly one active population-level A3 pathway.
unifiedMissionRepairEvents = 0;
unifiedMissionRepairEvaluations = 0;
unifiedMissionRepairAccepted = 0;
unifiedMissionRepairEligibleTrials = 0;
unifiedMissionRepairGeometryCandidates = 0;
unifiedMissionRepairPrecheckPassed = 0;
unifiedMissionRepairPrecheckRejectReach = 0;
unifiedMissionRepairPrecheckRejectTurn = 0;
unifiedMissionRepairPrecheckRejectOther = 0;
unifiedMissionRepairRejectStatic = 0;
unifiedMissionRepairRejectInvalid = 0;
unifiedMissionRepairRejectGlobalRegression = 0;
unifiedMissionRepairRejectProtection = 0;
unifiedMissionRepairRejectProtectionComponent = 0;
unifiedMissionRepairRejectProtectionQ = 0;
unifiedMissionRepairRejectProtectionCriticalQ = 0;
unifiedMissionRepairRejectProtectionObservation = 0;
unifiedMissionRepairRejectProtectionLOS = 0;
unifiedMissionRepairRejectTargetNoGain = 0;
unifiedMissionRepairTargetGainSum = 0;
unifiedMissionRepairBestTargetGain = 0;
unifiedMissionRepairTargetCounts = zeros(1,size(problem.monitorTargets,1));
finalStageObjectiveReevaluations = 0;
% v7.2.3 Performance R2: profiling only; no selection/evaluation semantics.
structuredTrialDecoderTime_s = 0;
structuredTrialDenseProjectionTime_s = 0;
structuredTrialTerrainSamplingTime_s = 0;
structuredTrialReachAttempts = 0;
structuredTrialTerrainCacheHits = 0;
structuredTrialTerrainCacheMisses = 0;
prevFeasibleRate = sum([pop.feasible])/max(numel(pop),1);

for gen = 1:cfg.maxGenerations
    generationTimer = tic;
    commonArchiveUpdated = false;
    commonHVEvaluated = false;

    thresholdChanged = false;
    previousFinalReached = thresholdState.finalReached;
    thresholdDiag = struct('currentRate',prevFeasibleRate, ...
        'predictedFullRate',NaN,'predictedSlowRate',NaN, ...
        'predictedFinalRate',NaN,'committedRate',prevFeasibleRate);
    if gen > 1
        [thresholdState,thresholdChanged,thresholdDiag] = ...
            evaluation.updateMonitoringThresholdState( ...
            thresholdState,prevFeasibleRate,gen,cfg,pop);
    end
    runtimeCfg = evaluation.applyMonitoringThresholdState(cfg,thresholdState);
    if thresholdState.finalReached && isfinite(thresholdState.finalReachedGeneration)
        runtimeCfg.runtimeFinalStageGeneration = ...
            gen-thresholdState.finalReachedGeneration+1;
    else
        runtimeCfg.runtimeFinalStageGeneration = 0;
    end
    enteredFinalStage = thresholdState.finalReached && ~previousFinalReached;
    if enteredFinalStage
        operatorState = operators.initializeFinalStageOperatorState(cfg);
        bestFinalCost = inf;
        costImprovementAnchor = NaN;
        lastFinalCostImprovementGen = gen;
        commonHVImprovementAnchor = NaN;
        lastCommonHVImprovementGen = gen;
    end

    % Normally only dynamic constraints change. The final-stage monitoring
    % objective, however, activates quality saturation, so all cached
    % objective-five values are recomputed once at the transition.
    dynamicUpdates = 0;
    stageReevaluations = 0;
    if enteredFinalStage && localCfg(cfg, ...
            'enableFinalStageMonitoringSaturation',true)
        pop = evaluation.evaluatePopulation(pop,problem,runtimeCfg,gen);
        stageReevaluations = stageReevaluations+numel(pop);
        if ~isempty(archive)
            archive = evaluation.evaluatePopulation( ...
                archive,problem,runtimeCfg,gen);
            stageReevaluations = stageReevaluations+numel(archive);
        end
        if ~isempty(finalArchive)
            finalArchive = evaluation.evaluatePopulation( ...
                finalArchive,problem,runtimeCfg,gen);
            stageReevaluations = stageReevaluations+numel(finalArchive);
        end
        if ~isempty(commonArchive)
            commonArchive = evaluation.evaluatePopulation( ...
                commonArchive,problem,runtimeCfg,gen);
            stageReevaluations = stageReevaluations+numel(commonArchive);
        end
        archive = selection.updateArchive([], ...
            [archive(:);pop(:)],cfg.archiveSize,runtimeCfg,gen);
        [finalArchive,stageFinalCandidates] = localUpdateFinalArchive([], ...
            [finalArchive(:);archive(:);pop(:)],cfg,gen,finalThresholds);
        if ~isempty(commonCandidateBuffer)
            commonCandidateBuffer = evaluation.evaluatePopulation( ...
                commonCandidateBuffer,problem,runtimeCfg,gen);
            stageReevaluations = stageReevaluations+ ...
                numel(commonCandidateBuffer);
        end
        commonCandidateBuffer = [commonCandidateBuffer(:); ...
            stageFinalCandidates(:);finalArchive(:)];
        finalStageObjectiveReevaluations = ...
            finalStageObjectiveReevaluations+stageReevaluations;
        thresholdChangeCount = thresholdChangeCount+1;
    elseif thresholdChanged
        dynamicUpdates = numel(pop)+numel(archive);
        pop = evaluation.updatePopulationDynamicConstraints( ...
            pop,runtimeCfg,gen);
        if ~isempty(archive)
            archive = evaluation.updatePopulationDynamicConstraints( ...
                archive,runtimeCfg,gen);
        end
        archive = selection.updateArchive([], ...
            [archive(:);pop(:)],cfg.archiveSize,runtimeCfg,gen);
        thresholdChangeCount = thresholdChangeCount+1;
    end

    offspring = repmat(pop(1),cfg.populationSize,1);
    genTrialDecoderTime_s=0;
    genTrialDenseProjectionTime_s=0;
    genTrialTerrainSamplingTime_s=0;
    genTrialReachAttempts=0;
    genTrialTerrainCacheHits=0;
    genTrialTerrainCacheMisses=0;
    successF = cell(1,3);
    successCR = cell(1,3);
    offspringF = zeros(cfg.populationSize,1);
    offspringCR = zeros(cfg.populationSize,1);
    offspringStrategy = zeros(cfg.populationSize,1);
    candidateCVReduction = zeros(cfg.populationSize,1);
    candidateNearFeasible = false(cfg.populationSize,1);
    candidateDiversity = zeros(cfg.populationSize,1);
    candidateMonitoringGain = zeros(cfg.populationSize,1);
    stats = struct('useCount',zeros(1,3), ...
        'acceptedCount',zeros(1,3),'cvReduction',zeros(1,3), ...
        'nearFeasibleCount',zeros(1,3), ...
        'diversityContribution',zeros(1,3), ...
        'monitoringGain',zeros(1,3));

    % Population/archive rankings used by mutation are constant during the
    % offspring loop. Precompute them once instead of re-sorting for every
    % individual (important for NP=96 and 220 generations).
    trialContext = operators.buildTrialContext(pop,archive,runtimeCfg,gen);
    for i = 1:cfg.populationSize
        [trial,F,CR,sid] = operators.generateTrial(i,pop,archive, ...
            muF,muCR,strategyProb,problem,runtimeCfg,gen,trialContext);
        if localCfg(runtimeCfg,'enableStructuredPerformanceProfiling',true) && ...
                isfield(trial,'encodingInfo') && isstruct(trial.encodingInfo)
            [genTrialDecoderTime_s,genTrialDenseProjectionTime_s, ...
                genTrialTerrainSamplingTime_s,genTrialReachAttempts, ...
                genTrialTerrainCacheHits,genTrialTerrainCacheMisses] = ...
                localAccumulateStructuredDecodePerformance(trial.encodingInfo, ...
                genTrialDecoderTime_s,genTrialDenseProjectionTime_s, ...
                genTrialTerrainSamplingTime_s,genTrialReachAttempts, ...
                genTrialTerrainCacheHits,genTrialTerrainCacheMisses);
        end
        stats.useCount(sid) = stats.useCount(sid)+1;
        structuredMode = localCfg(runtimeCfg,'enableStructuredMonitoringEncoding',false) && ...
            isfield(trial,'structuredGenes') && ~isempty(trial.structuredGenes);
        if ~structuredMode
            trial = repair.repairPath(trial,problem,runtimeCfg);
        end
        trial = evaluation.evaluateIndividual( ...
            trial,problem,runtimeCfg,gen);
        offspring(i) = trial;
        offspringF(i) = F;
        offspringCR(i) = CR;
        offspringStrategy(i) = sid;
        parent = pop(i);
        candidateCVReduction(i) = max(0,parent.cv-trial.cv);
        candidateNearFeasible(i) = trial.cv <= cfg.nearFeasibleCV;
        if localCfg(runtimeCfg,'enableStructuredMonitoringEncoding',false) && ...
                isfield(parent,'structuredGenes') && ~isempty(parent.structuredGenes) && ...
                isfield(trial,'structuredGenes') && ~isempty(trial.structuredGenes)
            candidateDiversity(i) = norm(trial.structuredGenes-parent.structuredGenes)/ ...
                sqrt(numel(parent.structuredGenes));
        else
            candidateDiversity(i) = norm(trial.genes-parent.genes)/ ...
                sqrt(numel(parent.genes));
        end
        candidateMonitoringGain(i) = max(0, ...
            evaluation.finalMonitoringDeficit(parent,cfg)- ...
            evaluation.finalMonitoringDeficit(trial,cfg));
    end

    structuredTrialDecoderTime_s=structuredTrialDecoderTime_s+genTrialDecoderTime_s;
    structuredTrialDenseProjectionTime_s=structuredTrialDenseProjectionTime_s+ ...
        genTrialDenseProjectionTime_s;
    structuredTrialTerrainSamplingTime_s=structuredTrialTerrainSamplingTime_s+ ...
        genTrialTerrainSamplingTime_s;
    structuredTrialReachAttempts=structuredTrialReachAttempts+genTrialReachAttempts;
    structuredTrialTerrainCacheHits=structuredTrialTerrainCacheHits+ ...
        genTrialTerrainCacheHits;
    structuredTrialTerrainCacheMisses=structuredTrialTerrainCacheMisses+ ...
        genTrialTerrainCacheMisses;

    % A parameter/strategy receives credit only when its offspring survives
    % the actual 2N environmental selection. This aligns learning with the
    % many-objective selection mechanism rather than a parent-only scalar tie.
    [pop,selectedIdx] = selection.environmentalSelection( ...
        [pop;offspring],cfg.populationSize,runtimeCfg,gen);
    survivingOffspring = selectedIdx(selectedIdx>cfg.populationSize)- ...
        cfg.populationSize;
    for q = 1:numel(survivingOffspring)
        i = survivingOffspring(q);
        sid = offspringStrategy(i);
        successF{sid}(end+1) = offspringF(i); %#ok<AGROW>
        successCR{sid}(end+1) = offspringCR(i); %#ok<AGROW>
        stats.acceptedCount(sid) = stats.acceptedCount(sid)+1;
        stats.cvReduction(sid) = stats.cvReduction(sid)+ ...
            candidateCVReduction(i);
        stats.nearFeasibleCount(sid) = stats.nearFeasibleCount(sid)+ ...
            double(candidateNearFeasible(i));
        stats.diversityContribution(sid) = ...
            stats.diversityContribution(sid)+candidateDiversity(i);
        stats.monitoringGain(sid) = stats.monitoringGain(sid)+ ...
            candidateMonitoringGain(i);
    end
    localSearchApplied = gen >= cfg.localSearchStartGeneration && ...
        mod(gen,cfg.localSearchInterval)==0;
    lsStats = struct('evaluations',0,'accepted',0, ...
        'costEvaluations',0,'costAccepted',0, ...
        'operatorUses',zeros(1,5),'operatorAccepted',zeros(1,5), ...
        'operatorReward',zeros(1,5));
    if localSearchApplied
        [pop,lsStats,operatorState] = operators.eliteLocalSearch( ...
            pop,problem,runtimeCfg,gen,operatorState);
    end

    % v7.0.0 single population-level A3 repair. There is no Target Memory,
    % Mission Carrier, persistent repair or emergency reinjection path.
    % Canonical A3 stats schema is shared with unifiedMissionRepair. This
    % prevents pre-A3 / disabled-A3 generations from exposing an older field
    % set than active A3 events and keeps logging safe before Gen25.
    missionRepairStats = core.emptyUnifiedMissionRepairStats();
    missionRepairEnabled = localCfg(cfg,'enableUnifiedMissionRepair',false);
    missionRepairStart = max(1,round(localCfg(cfg, ...
        'missionRepairStartGeneration',25)));
    missionRepairInterval = max(1,round(localCfg(cfg,'missionRepairInterval',5)));
    if missionRepairEnabled && gen>=missionRepairStart && ...
            mod(gen-missionRepairStart,missionRepairInterval)==0
        [pop,missionRepairStats] = core.unifiedMissionRepair( ...
            pop,problem,runtimeCfg,gen);
        unifiedMissionRepairEvents = unifiedMissionRepairEvents + ...
            double(missionRepairStats.event);
        unifiedMissionRepairEvaluations = unifiedMissionRepairEvaluations + ...
            missionRepairStats.evaluations;
        unifiedMissionRepairAccepted = unifiedMissionRepairAccepted + ...
            missionRepairStats.accepted;
        unifiedMissionRepairEligibleTrials = unifiedMissionRepairEligibleTrials + ...
            missionRepairStats.eligibleTrials;
        unifiedMissionRepairGeometryCandidates = unifiedMissionRepairGeometryCandidates + ...
            missionRepairStats.geometryCandidates;
        unifiedMissionRepairPrecheckPassed = unifiedMissionRepairPrecheckPassed + ...
            missionRepairStats.precheckPassed;
        unifiedMissionRepairPrecheckRejectReach = unifiedMissionRepairPrecheckRejectReach + ...
            missionRepairStats.precheckRejectReach;
        unifiedMissionRepairPrecheckRejectTurn = unifiedMissionRepairPrecheckRejectTurn + ...
            missionRepairStats.precheckRejectTurn;
        unifiedMissionRepairPrecheckRejectOther = unifiedMissionRepairPrecheckRejectOther + ...
            missionRepairStats.precheckRejectOther;
        unifiedMissionRepairRejectStatic = unifiedMissionRepairRejectStatic + ...
            missionRepairStats.rejectStatic;
        unifiedMissionRepairRejectInvalid = unifiedMissionRepairRejectInvalid + ...
            missionRepairStats.rejectInvalid;
        unifiedMissionRepairRejectGlobalRegression = ...
            unifiedMissionRepairRejectGlobalRegression + ...
            missionRepairStats.rejectGlobalRegression;
        unifiedMissionRepairRejectProtection = ...
            unifiedMissionRepairRejectProtection + missionRepairStats.rejectProtection;
        unifiedMissionRepairRejectProtectionComponent = ...
            unifiedMissionRepairRejectProtectionComponent + ...
            missionRepairStats.rejectProtectionComponent;
        unifiedMissionRepairRejectProtectionQ = ...
            unifiedMissionRepairRejectProtectionQ + missionRepairStats.rejectProtectionQ;
        unifiedMissionRepairRejectProtectionCriticalQ = ...
            unifiedMissionRepairRejectProtectionCriticalQ + ...
            missionRepairStats.rejectProtectionCriticalQ;
        unifiedMissionRepairRejectProtectionObservation = ...
            unifiedMissionRepairRejectProtectionObservation + ...
            missionRepairStats.rejectProtectionObservation;
        unifiedMissionRepairRejectProtectionLOS = ...
            unifiedMissionRepairRejectProtectionLOS + missionRepairStats.rejectProtectionLOS;
        unifiedMissionRepairRejectTargetNoGain = ...
            unifiedMissionRepairRejectTargetNoGain + missionRepairStats.rejectTargetNoGain;
        unifiedMissionRepairTargetGainSum = unifiedMissionRepairTargetGainSum + ...
            missionRepairStats.targetGainSum;
        unifiedMissionRepairBestTargetGain = max(unifiedMissionRepairBestTargetGain, ...
            missionRepairStats.bestTargetGain);
        for rr = 1:numel(missionRepairStats.targets)
            tt = missionRepairStats.targets(rr);
            if tt>=1 && tt<=numel(unifiedMissionRepairTargetCounts)
                unifiedMissionRepairTargetCounts(tt) = ...
                    unifiedMissionRepairTargetCounts(tt)+1;
            end
        end
    end

    archive = selection.updateArchive(archive,pop,cfg.archiveSize,runtimeCfg,gen);
    feasibleArchiveNow = archive([archive.feasible]);
    if ~isempty(feasibleArchiveNow) && ...
            thresholdState.progress >= bestRelaxedProgress- ...
            cfg.monitorThresholdTolerance
        if thresholdState.progress > bestRelaxedProgress+ ...
                cfg.monitorThresholdTolerance || ...
                numel(feasibleArchiveNow)>=numel(bestRelaxedArchive)
            bestRelaxedArchive = feasibleArchiveNow(:);
            bestRelaxedProgress = thresholdState.progress;
            bestRelaxedThresholds = [thresholdState.minimum ...
                thresholdState.critical thresholdState.observationLength ...
                thresholdState.losRatio];
        end
    end

    for s = 1:3
        if ~isempty(successF{s})
            muF(s) = (1-cfg.successLearningRate)*muF(s)+ ...
                cfg.successLearningRate* ...
                (sum(successF{s}.^2)/max(sum(successF{s}),eps));
            muCR(s) = (1-cfg.successLearningRate)*muCR(s)+ ...
                cfg.successLearningRate*mean(successCR{s});
        end
    end

    feasibleMask = [pop.cv] <= cfg.constraintTolerance;
    feasibleCount = sum(feasibleMask);
    % In unified Mission-Band runs, scheduled mission infeasibility is not
    % physical infeasibility. Strategy credit therefore uses the normal
    % survival/monitoring/diversity branch whenever static-feasible paths exist;
    % the CV-recovery branch is reserved for true flight-infeasible populations.
    if localCfg(cfg,'enableUnifiedMissionDeficit',false) && ...
            localCfg(cfg,'enableMissionBandSelection',false)
        staticFeasibleCount = sum(arrayfun(@(x)isfield(x,'staticCV') && ...
            isfinite(x.staticCV) && x.staticCV<=cfg.constraintTolerance,pop));
        strategyCreditCount = staticFeasibleCount;
    else
        staticFeasibleCount = feasibleCount;
        strategyCreditCount = feasibleCount;
    end
    [finalPopMask,finalPopRate] = ...
        evaluation.checkFinalMonitoringFeasibility(pop,cfg);
    finalFeasibleCount = sum(finalPopMask);
    [strategyProb,~] = core.updateStrategyCredit( ...
        strategyProb,stats,strategyCreditCount,cfg);
    if thresholdState.finalReached && ...
            localCfg(cfg,'enableFinalStageStrategyBlend',true)
        finalTarget = core.normalizeStrategyProbabilities( ...
            localCfg(cfg,'finalStageStrategyTarget',[0.30 0.50 0.20]),cfg);
        finalBlend = localCfg(cfg,'finalStageStrategyBlend',0.25);
        strategyProb = core.normalizeStrategyProbabilities( ...
            (1-finalBlend)*strategyProb+finalBlend*finalTarget,cfg);
    end
    diversity = core.populationDiversity(pop);
    % v7.0.0 restart has one responsibility: recover flight feasibility.
    % Mission-ineligible but static-feasible populations are not restarted;
    % they are handled by the unified mission deficit and A3 corridor repair.
    if localCfg(cfg,'enableUnifiedMissionDeficit',false)
        % Restart remains a flight-feasibility mechanism only.
        restartFeasibleCount = sum(arrayfun(@(x)isfield(x,'staticCV') && ...
            isfinite(x.staticCV) && x.staticCV<=cfg.constraintTolerance,pop));
    else
        restartFeasibleCount = feasibleCount;
    end
    if restartFeasibleCount==0
        noFeasibleGenerations = noFeasibleGenerations+1;
    else
        noFeasibleGenerations = 0;
    end

    restartEvaluations = 0;
    shouldRestart = cfg.enableInfeasibleRestart && restartFeasibleCount==0 && ...
        noFeasibleGenerations>=cfg.infeasibleRestartWindow && ...
        diversity<cfg.infeasibleDiversityThreshold;
    if shouldRestart
        restartEvaluations = max(1,ceil( ...
            cfg.infeasibleRestartFraction*numel(pop)));
        pop = core.restartInfeasiblePopulation( ...
            pop,problem,runtimeCfg,gen);
        archive = selection.updateArchive(archive,pop,cfg.archiveSize,runtimeCfg,gen);
        strategyProb = core.normalizeStrategyProbabilities( ...
            [0.40 0.35 0.25],cfg);
        noFeasibleGenerations = 0;
        restartCount = restartCount+1;
        diversity = core.populationDiversity(pop);
        feasibleMask = [pop.cv] <= cfg.constraintTolerance;
        feasibleCount = sum(feasibleMask);
        [finalPopMask,finalPopRate] = ...
            evaluation.checkFinalMonitoringFeasibility(pop,cfg);
        finalFeasibleCount = sum(finalPopMask);
        fprintf('  Infeasible restart applied at generation %d (restart %d).\n', ...
            gen,restartCount);
    end

    % v7.1.0 population-relative search-band diagnostics.  This never changes
    % formal/scheduled feasibility; it only reports the bounded Pareto-active
    % leader set used by environmental selection and mutation.
    missionBandState = selection.missionBandState( ...
        pop,runtimeCfg,gen,cfg.populationSize);

    % Maintain a second archive satisfying all final monitoring geometry
    % and quality requirements while runtime thresholds are still relaxed.
    finalPool = [offspring(:);pop(:);archive(:)];
    finalThresholdUpdates = numel(finalPool);
    [finalArchive,finalCandidates] = localUpdateFinalArchive( ...
        finalArchive,finalPool,cfg,gen,finalThresholds);
    commonCandidateBuffer = [commonCandidateBuffer(:);finalCandidates(:)];
    commonHVEvaluationDue = localCommonHVEvaluationDue( ...
        gen,cfg,enteredFinalStage);
    commonUpdateInterval = max(1,round(localCfg(cfg, ...
        'commonArchiveUpdateInterval',1)));
    commonArchiveUpdateDue = commonHVEvaluationDue || ...
        mod(gen,commonUpdateInterval)==0 || gen==cfg.maxGenerations || ...
        numel(commonCandidateBuffer)>=localCfg(cfg, ...
        'commonCandidateBufferMax',2500);
    if commonArchiveUpdateDue
        commonArchive = selection.updateCommonArchive(commonArchive, ...
            [commonCandidateBuffer(:);finalArchive(:)], ...
            localCfg(cfg,'commonArchiveSize',150),cfg);
        commonCandidateBuffer = pop([]);
        commonArchiveUpdated = true;
        commonArchiveUpdateCount = commonArchiveUpdateCount+1;
    end

    % Track a cheap, version-independent physical cost indicator every
    % generation. This complements the stochastic hypervolume criterion.
    currentBestFinalCost = NaN;
    if ~isempty(commonArchive)
        costValues = metrics.finalStageCostIndicator(commonArchive,cfg);
        finiteCost = costValues(isfinite(costValues));
        if ~isempty(finiteCost)
            [currentBestFinalCost,finiteIndex] = min(finiteCost);
            finiteArchiveIndex = find(isfinite(costValues));
            currentPhysicalSolution = commonArchive( ...
                finiteArchiveIndex(finiteIndex));
            previousBestFinalCost = bestFinalCost;
            [bestFinalCost,costImprovementAnchor, ...
                lastFinalCostImprovementGen] = ...
                core.updateImprovementTracker(currentBestFinalCost, ...
                bestFinalCost,costImprovementAnchor, ...
                lastFinalCostImprovementGen,gen,localCfg(cfg, ...
                'finalStageCostImprovementTolerance',0.003), ...
                'minimize',true);
            if bestFinalCost<previousBestFinalCost || isempty(bestPhysicalSolution)
                bestPhysicalSolution = currentPhysicalSolution;
            end
        end
    end

    feasiblePop = pop(feasibleMask);
    history(gen,1) = gen;
    history(gen,2) = feasibleCount;
    if ~isempty(feasiblePop)
        obj = vertcat(feasiblePop.objectives);
        history(gen,3:7) = min(obj,[],1);
    end

    % Use a fixed cadence. Threshold changes do not force extra expensive
    % HV calls because values under different runtime constraints are not
    % directly comparable.
    hvEvaluated = gen==1 || mod(gen,cfg.hvEvaluationInterval)==0 || ...
        gen==cfg.maxGenerations || ...
        (thresholdChanged && thresholdState.finalReached);
    if hvEvaluated
        lastCurrentHV = metrics.approxHypervolumeFixed( ...
            archive,cfg,hvSamples,false);
        lastFinalHV = metrics.approxHypervolumeFixed( ...
            finalArchive,cfg,hvSamples);
    end
    commonHVEvaluated = commonHVEvaluationDue && ...
        localCfg(cfg,'enableCommonEvaluation',true);
    if commonHVEvaluated
        lastCommonHV = metrics.approxCommonHypervolumeFixed( ...
            commonArchive,cfg,hvSamples);
        commonHVEvaluationCount = commonHVEvaluationCount+1;
        if thresholdState.finalReached && isfinite(lastCommonHV)
            previousBestCommonHV = bestCommonHV;
            [bestCommonHV,commonHVImprovementAnchor, ...
                lastCommonHVImprovementGen] = ...
                core.updateImprovementTracker(lastCommonHV,bestCommonHV, ...
                commonHVImprovementAnchor,lastCommonHVImprovementGen,gen, ...
                localCfg(cfg,'finalStageCommonHVImprovementTolerance',0.002), ...
                'maximize',false);
            if bestCommonHV>previousBestCommonHV || isempty(bestCommonArchive)
                bestCommonArchive = commonArchive;
            end
        end
    end
    currentHVHist(gen) = lastCurrentHV;
    finalHVHist(gen) = lastFinalHV;
    commonHVHist(gen) = lastCommonHV;
    if isfinite(bestCommonHV)
        bestCommonHVHist(gen) = bestCommonHV;
    end
    if isfinite(bestFinalCost)
        bestCostHist(gen) = bestFinalCost;
    end
    history(gen,8) = currentHVHist(gen);
    history(gen,9) = finalHVHist(gen);
    history(gen,10) = numel(archive);
    history(gen,11) = numel(finalArchive);
    history(gen,12) = diversity;
    if ~isempty(feasiblePop)
        history(gen,13) = max([feasiblePop.monitorQuality]);
        history(gen,14) = max(arrayfun( ...
            @(x)x.monitorStats.minimumQuality,feasiblePop));
        history(gen,15) = max(arrayfun( ...
            @(x)x.monitorStats.criticalQuality,feasiblePop));
        history(gen,39) = min(arrayfun( ...
            @(x)x.monitorStats.dispersionPenalty,feasiblePop));
        history(gen,40) = max(arrayfun( ...
            @(x)x.monitorStats.minimumCriticalObservationLength,feasiblePop));
        history(gen,41) = max(arrayfun( ...
            @(x)x.monitorStats.minimumCriticalLOSRatio,feasiblePop));
        history(gen,46) = min(arrayfun(@(x)x.pathMetrics.rawLength,feasiblePop));
        history(gen,47) = min(arrayfun(@(x)x.riskStats.meanRisk,feasiblePop));
        history(gen,48) = min(arrayfun(@(x)x.riskStats.tailRisk,feasiblePop));
        history(gen,49) = min(arrayfun( ...
            @(x)x.energyStats.observation,feasiblePop));
        history(gen,50) = min(arrayfun( ...
            @(x)x.energyStats.hoverEquivalent,feasiblePop));
        history(gen,51) = max(arrayfun( ...
            @(x)x.monitorStats.searchAverageQuality,feasiblePop));
        history(gen,52) = max(arrayfun( ...
            @(x)x.monitorStats.searchMinimumQuality,feasiblePop));
    end
    history(gen,16) = sum(stats.acceptedCount);
    history(gen,17:19) = strategyProb;
    history(gen,20) = restartCount;

    v = diagnostics.summarizeViolations(pop,cfg.constraintTolerance);
    history(gen,21) = v.totalMin;
    history(gen,22) = v.totalMedian;
    history(gen,23) = v.clearanceMin;
    history(gen,24) = v.climbMin;
    history(gen,25) = v.monitorMinimumMin;
    history(gen,26) = v.monitorCriticalMin;
    history(gen,27) = v.monitorMinimumCount;
    history(gen,28) = v.monitorCriticalCount;
    history(gen,29) = thresholdState.minimum;
    history(gen,30) = thresholdState.critical;
    history(gen,31) = thresholdState.lastActionCode;
    history(gen,32) = toc(generationTimer);
    history(gen,33) = double(hvEvaluated);
    history(gen,34) = lsStats.evaluations;
    history(gen,35) = lsStats.accepted;
    history(gen,36) = dynamicUpdates+finalThresholdUpdates;
    history(gen,37) = thresholdChangeCount;
    history(gen,38) = cfg.populationSize+ ...
        lsStats.evaluations+restartEvaluations+stageReevaluations+ ...
        missionRepairStats.evaluations;
    history(gen,42) = thresholdState.observationLength;
    history(gen,43) = thresholdState.losRatio;
    history(gen,44) = v.monitorObservationLengthCount;
    history(gen,45) = v.monitorLOSRatioCount;
    history(gen,53) = feasibleCount/max(cfg.populationSize,1);
    history(gen,54) = thresholdDiag.predictedFullRate;
    history(gen,55) = thresholdDiag.predictedSlowRate;
    history(gen,56) = thresholdDiag.predictedFinalRate;
    history(gen,57) = double(thresholdState.finalReached);
    if thresholdState.finalReached && ...
            isfinite(thresholdState.finalReachedGeneration)
        history(gen,58) = gen-thresholdState.finalReachedGeneration+1;
    else
        history(gen,58) = 0;
    end
    history(gen,59) = finalFeasibleCount;
    history(gen,60) = commonHVHist(gen);
    history(gen,61) = currentBestFinalCost;
    history(gen,62:66) = operatorState.probabilities;
    history(gen,67) = bestCommonHVHist(gen);
    history(gen,68) = bestCostHist(gen);
    history(gen,69) = localProgressiveSmoothnessLimit(runtimeCfg);
    history(gen,70:74) = lsStats.operatorUses;
    history(gen,75:79) = lsStats.operatorAccepted;
    history(gen,80:84) = lsStats.operatorReward./ ...
        max(lsStats.operatorAccepted,1);
    history(gen,85) = double(commonArchiveUpdated);
    history(gen,86) = double(commonHVEvaluated);

    feasibleRate = feasibleCount/max(cfg.populationSize,1);
    prevFeasibleRate = feasibleRate;

    if mod(gen,cfg.verboseEvery)==0 || gen==1 || thresholdChanged
        if missionBandState.enabled
            fprintf(['Gen %03d | static=%3d/%3d mission=%3d band=%3d formal=%3d | ' ...
                'archive=%3d/%3d | HVsearch/formal=%.4f/%.4f | div=%.3f\n'], ...
                gen,missionBandState.staticCount,cfg.populationSize, ...
                missionBandState.scheduledCount,missionBandState.bandCount, ...
                missionBandState.formalCount,numel(archive),numel(finalArchive), ...
                currentHVHist(gen),finalHVHist(gen),diversity);
            fprintf(['         eps[sched/search]=[%.3f %.3f] ' ...
                'D[min/edge/med]=[%.4f %.4f %.4f] | ' ...
                'p=[%.2f %.2f %.2f] | CV=%.3g/%.3g | ' ...
                'viol=%d/%d/%d/%d | time=%.2fs eval=%d LS=%d\n'], ...
                missionBandState.scheduledEpsilon, ...
                missionBandState.effectiveEpsilon, ...
                missionBandState.minimumDeficit, ...
                missionBandState.bandEdgeDeficit, ...
                missionBandState.medianDeficit, ...
                strategyProb(1),strategyProb(2),strategyProb(3), ...
                v.totalMin,v.totalMedian,v.monitorMinimumCount, ...
                v.monitorCriticalCount,v.monitorObservationLengthCount, ...
                v.monitorLOSRatioCount,history(gen,32),history(gen,38), ...
                lsStats.evaluations);
            if localCfg(runtimeCfg,'enableStructuredMonitoringEncoding',false)
                encOK=sum(arrayfun(@(x)isfield(x,'encodingInfo') && ...
                    isstruct(x.encodingInfo) && isfield(x.encodingInfo,'success') && ...
                    x.encodingInfo.success,pop));
                semanticDim=0; phenotypeDim=0;
                if ~isempty(pop)
                    semanticDim=numel(pop(1).structuredGenes);
                    phenotypeDim=numel(pop(1).genes);
                end
                [encDense,encTurnFail,encReachFail,encOtherFail] = ...
                    localStructuredDecodeDiagnostics(pop);
                fprintf(['         enc[semantic/XYZ]=[%dD/%dD] ' ...
                    'decode[dense/ok]=[%d/%d]/%d fail[reach/turn/other]=[%d %d %d]\n'], ...
                    semanticDim,phenotypeDim,encDense,encOK,numel(pop), ...
                    encReachFail,encTurnFail,encOtherFail);
                if localCfg(runtimeCfg,'enableStructuredPerformanceProfiling',true)
                    fprintf(['         perf[trialDec/proj/sample]=[%.2f %.2f %.2f]s ' ...
                        'reach=%d cache[h/m]=[%d/%d]\n'], ...
                        genTrialDecoderTime_s,genTrialDenseProjectionTime_s, ...
                        genTrialTerrainSamplingTime_s,genTrialReachAttempts, ...
                        genTrialTerrainCacheHits,genTrialTerrainCacheMisses);
                end
            end
        else
            fprintf(['Gen %03d | feasible=%3d/%3d | archive=%3d/%3d | ' ...
                'HV=%.4f/%.4f | Qavg=%.3f | Qmin=%.3f | div=%.3f\n'], ...
                gen,feasibleCount,cfg.populationSize,numel(archive), ...
                numel(finalArchive),currentHVHist(gen),finalHVHist(gen), ...
                history(gen,13),history(gen,14),diversity);
            fprintf(['         th=[%.3f %.3f %.2f %.3f] %s epsD=%.3f | ' ...
                'p=[%.2f %.2f %.2f] | CV=%.3g/%.3g | ' ...
                'viol=%d/%d/%d/%d | rate=%.2f full=%.2f slow=%.2f ' ...
                'final=%.2f | time=%.2fs eval=%d LS=%d\n'], ...
                thresholdState.minimum,thresholdState.critical, ...
                thresholdState.observationLength,thresholdState.losRatio, ...
                thresholdState.lastAction,thresholdState.missionDeficitEpsilon, ...
                strategyProb(1),strategyProb(2), ...
                strategyProb(3),v.totalMin,v.totalMedian, ...
                v.monitorMinimumCount,v.monitorCriticalCount, ...
                v.monitorObservationLengthCount,v.monitorLOSRatioCount, ...
                feasibleRate,thresholdDiag.predictedFullRate, ...
                thresholdDiag.predictedSlowRate,thresholdDiag.predictedFinalRate, ...
                history(gen,32),history(gen,38),lsStats.evaluations);
        end
        if thresholdState.finalReached
            fprintf(['         commonHV=%.4f cost=%.5f | ' ...
                'op=[%.2f %.2f %.2f %.2f %.2f]\n'], ...
                bestCommonHVHist(gen),bestFinalCost, ...
                operatorState.probabilities(1), ...
                operatorState.probabilities(2), ...
                operatorState.probabilities(3), ...
                operatorState.probabilities(4), ...
                operatorState.probabilities(5));
        end
    end
    if missionRepairStats.geometryCandidates>0 || missionRepairStats.evaluations>0
        fprintf(['         A3 geom=%d preOK=%d eval=%d replace=%d eligible=%d | ' ...
            'preRej[reach/turn/other]=[%d %d %d] slack=%.2f block=%d | ' ...
            'D=%.5f->%.5f formal=%d->%d gain=%.4g | ' ...
            'rej[s/i/g/p/n]=[%d %d %d %d %d] | ' ...
            'protect[comp/Q/cQ/obs/LOS]=[%d %d %d %d %d] | ' ...
            'targets=%s unique=%d baseD=%s\n'], ...
            missionRepairStats.geometryCandidates,missionRepairStats.precheckPassed, ...
            missionRepairStats.evaluations,missionRepairStats.accepted, ...
            missionRepairStats.eligibleTrials,missionRepairStats.precheckRejectReach, ...
            missionRepairStats.precheckRejectTurn,missionRepairStats.precheckRejectOther, ...
            missionRepairStats.bestPrecheckSlack,missionRepairStats.maximumScreenedBlock, ...
            missionRepairStats.bestDeficitBefore,missionRepairStats.bestDeficitAfter, ...
            missionRepairStats.formalCarrierCountBefore,missionRepairStats.formalCarrierCountAfter, ...
            missionRepairStats.bestTargetGain,missionRepairStats.rejectStatic, ...
            missionRepairStats.rejectInvalid,missionRepairStats.rejectGlobalRegression, ...
            missionRepairStats.rejectProtection,missionRepairStats.rejectTargetNoGain, ...
            missionRepairStats.rejectProtectionComponent,missionRepairStats.rejectProtectionQ, ...
            missionRepairStats.rejectProtectionCriticalQ, ...
            missionRepairStats.rejectProtectionObservation,missionRepairStats.rejectProtectionLOS, ...
            mat2str(missionRepairStats.targets),missionRepairStats.uniqueTargetCount, ...
            mat2str(missionRepairStats.baseDeficits,4));
        if missionRepairStats.rejectProtection>0
            fprintf(['         A3 protectWorst stage=%s condition=%s target=%d comp=%d ' ...
                'base=%.4g trial=%.4g req=%.4g enter=%.4g gap=%.4g\n'], ...
                missionRepairStats.protectionWorstStage, ...
                missionRepairStats.protectionWorstCondition, ...
                missionRepairStats.protectionWorstTarget, ...
                missionRepairStats.protectionWorstComponent, ...
                missionRepairStats.protectionWorstBaseValue, ...
                missionRepairStats.protectionWorstTrialValue, ...
                missionRepairStats.protectionWorstThreshold, ...
                missionRepairStats.protectionWorstEntryThreshold, ...
                missionRepairStats.protectionWorstGap);
        end
        if missionRepairStats.rejectStatic>0
            fprintf(['         A3 static[col/clr/clm/trn/E]=[%d %d %d %d %d] | ' ...
                'AGLrej[lo/hi]=[%d %d] range=[%.1f %.1f] maxClm=%.1f\n'], ...
                missionRepairStats.staticCollision,missionRepairStats.staticClearance, ...
                missionRepairStats.staticClimb,missionRepairStats.staticTurn, ...
                missionRepairStats.staticEnergy,missionRepairStats.staticLowerAGL, ...
                missionRepairStats.staticUpperAGL,missionRepairStats.worstMinimumAGL, ...
                missionRepairStats.worstMaximumAGL,missionRepairStats.worstMaxClimbDeg);
        else
            fprintf(['         A3 static[col/clr/clm/trn/E]=[0 0 0 0 0] | ' ...
                'AGLrej=[n/a]\n']);
        end
    end

    % Stable stopping uses best-so-far Common HV and physical cost anchors.
    requiredStall = localCfg(cfg,'finalStageStagnationWindow',25)* ...
        localCfg(cfg,'finalStageStagnationRequiredWindows',1);
    requiredFinalStage = max(cfg.minimumFinalStageGenerations, ...
        cfg.hvStoppingPostFinalThresholdBuffer);
    finalBufferSatisfied = thresholdState.finalReached && ...
        isfinite(thresholdState.finalReachedGeneration) && ...
        gen-thresholdState.finalReachedGeneration+1 >= requiredFinalStage;
    commonHVStagnant = isfinite(lastCommonHVImprovementGen) && ...
        gen-lastCommonHVImprovementGen>=requiredStall;
    costStoppingEnabled = localCfg(cfg, ...
        'enableFinalStageCostStopping',true);
    costStagnant = ~costStoppingEnabled || ...
        (isfinite(lastFinalCostImprovementGen) && ...
        gen-lastFinalCostImprovementGen>=requiredStall);
    % v7.0.1: stagnation is meaningful only after at least one formally
    % mission-feasible solution has produced finite Common-HV and physical-cost
    % evidence. Entering the formal stage with an empty final archive must never
    % start a false stagnation countdown (the v7.0.0 UAV-1 seed-42 failure).
    formalStoppingEvidence = core.finalStageStoppingEvidenceAvailable( ...
        finalArchive,bestCommonHV,bestFinalCost);
    if cfg.enableHVStopping && commonHVEvaluated && formalStoppingEvidence && ...
            gen>=cfg.minGenerations && finalBufferSatisfied && ...
            commonHVStagnant && costStagnant
        stopGen = gen;
        stopReason = 'common_hv_and_physical_cost_stagnation';
        break;
    end
end

history = history(1:stopGen,:);
currentHVHist = currentHVHist(1:stopGen);
finalHVHist = finalHVHist(1:stopGen);
commonHVHist = commonHVHist(1:stopGen);
bestCommonHVHist = bestCommonHVHist(1:stopGen);
bestCostHist = bestCostHist(1:stopGen);
finalArchiveAvailable = ~isempty(finalArchive);
if finalArchiveAvailable
    outputArchive = finalArchive(:);
elseif ~isempty(bestRelaxedArchive)
    outputArchive = bestRelaxedArchive(:);
else
    outputArchive = archive(:);
end
if isempty(bestCommonArchive), bestCommonArchive = commonArchive; end
representatives = selection.selectRepresentativeSolutions( ...
    outputArchive,cfg,bestCommonArchive,bestPhysicalSolution);
reportSelectionArchive = bestCommonArchive;
if isempty(reportSelectionArchive), reportSelectionArchive = outputArchive; end

% v6.5.7 retains post-repair reselection and adds feasibility-preserving
% dense AGL validation/repair BEFORE engineering filtering and final
% reported-solution selection. Formal-AGL-valid representatives are kept
% unchanged; required repairs are accepted only if prior feasibility survives.
denseSetStats = struct('totalEvaluations',0,'candidateCount',0, ...
    'candidateStats',[]);
if localCfg(cfg,'enableDenseFinalAGLRepair',false)
    [representatives,denseSetStats] = repair.finalizeRepresentativeSetAGL( ...
        representatives,problem,runtimeCfg,stopGen);
    reportSelectionArchive = representatives.solutions(:);
end
[best,reportedSolutionLabel,reportedSolutionIndex,reportedSelectionLevel] = ...
    selection.selectReportedSolution( ...
    representatives,reportSelectionArchive,cfg);
denseAGLStats = localSelectedDenseAGLStats( ...
    best,reportedSolutionIndex,representatives,denseSetStats);
bestSolutionSatisfiesFinal = localFinalSatisfied(best,cfg);

result.population = pop(:);
result.archive = outputArchive;
% v7.1.0 explicit semantics: currentArchive/searchArchive is the mission-band
% search-diversity archive; finalArchive remains strict formal D_M=0.
result.currentArchive = archive(:);
result.searchArchive = archive(:);
result.finalArchive = finalArchive(:);
result.missionBandSelectionEnabled = localCfg(cfg,'enableMissionBandSelection',false);
result.missionBandMinFraction = localCfg(cfg,'missionBandMinFraction',NaN);
result.commonArchive = bestCommonArchive(:);
result.currentCommonArchive = commonArchive(:);
result.bestPhysicalSolution = bestPhysicalSolution;
result.best = best;
result.reportedSolutionLabel = reportedSolutionLabel;
result.reportedSolutionSelectionLevel = reportedSelectionLevel;
reportedRiskBalancedCost = metrics.riskBalancedCostIndicator(best,cfg);
result.reportedRiskBalancedCostIndicator = reportedRiskBalancedCost(1);
[strictReportedMask,strictReportedDetails] = selection.engineeringLimitMask( ...
    best,cfg,'strict',reportSelectionArchive);
result.reportedStrictEngineeringLimitsSatisfied = strictReportedMask(1);
result.reportedStrictEngineeringDetails = strictReportedDetails;
strictDiagnostics = selection.engineeringLimitDiagnostics( ...
    strictReportedDetails,1,localCfg(cfg,'constraintTolerance',1e-8));
result.reportedStrictEngineeringDiagnostics = strictDiagnostics;
if isempty(strictDiagnostics)
    result.reportedStrictEngineeringFailedCriteria = cell(0,1);
else
    failed = strictDiagnostics(~reshape([strictDiagnostics.passed],[],1));
    result.reportedStrictEngineeringFailedCriteria = reshape({failed.name},[],1);
end
result.representatives = representatives;
result.history = history;
result.hypervolume = finalHVHist;
result.currentHypervolume = currentHVHist;
result.finalHypervolume = finalHVHist;
result.commonHypervolume = commonHVHist;
result.bestCommonHypervolume = bestCommonHVHist;
result.bestPhysicalCostHistory = bestCostHist;
result.stopGeneration = stopGen;
result.stopReason = stopReason;
result.muF = muF;
result.muCR = muCR;
result.strategyProb = strategyProb;
result.finalStageOperatorState = operatorState;
result.bestFinalStageCostIndicator = bestFinalCost;
result.infeasibleRestarts = restartCount;
result.thresholdState = thresholdState;
result.finalArchiveAvailable = finalArchiveAvailable;
result.bestSolutionSatisfiesFinalConstraints = bestSolutionSatisfiesFinal;
result.controllerReachedFinalThresholds = thresholdState.finalReached;
% Backward-compatible field: this now describes the selected physical path.
result.finalThresholdSatisfied = bestSolutionSatisfiesFinal;
result.bestRelaxedProgress = bestRelaxedProgress;
result.bestRelaxedThresholds = bestRelaxedThresholds;
result.totalOptimizationTime = toc(totalTimer);
result.performance.fullEvaluations = cfg.populationSize+sum(history(:,38))+ ...
    denseAGLStats.evaluations;
result.performance.dynamicConstraintUpdates = sum(history(:,36));
result.performance.hypervolumeEvaluations = sum(history(:,33));
result.performance.localSearchEvaluations = sum(history(:,34));
result.performance.unifiedMissionRepairEvents = unifiedMissionRepairEvents;
result.performance.unifiedMissionRepairEvaluations = ...
    unifiedMissionRepairEvaluations;
result.performance.unifiedMissionRepairAccepted = unifiedMissionRepairAccepted;
result.performance.unifiedMissionRepairEligibleTrials = unifiedMissionRepairEligibleTrials;
result.performance.unifiedMissionRepairGeometryCandidates = unifiedMissionRepairGeometryCandidates;
result.performance.unifiedMissionRepairPrecheckPassed = unifiedMissionRepairPrecheckPassed;
result.performance.unifiedMissionRepairPrecheckRejectReach = unifiedMissionRepairPrecheckRejectReach;
result.performance.unifiedMissionRepairPrecheckRejectTurn = unifiedMissionRepairPrecheckRejectTurn;
result.performance.unifiedMissionRepairPrecheckRejectOther = unifiedMissionRepairPrecheckRejectOther;
result.performance.unifiedMissionRepairRejectStatic = unifiedMissionRepairRejectStatic;
result.performance.unifiedMissionRepairRejectInvalid = unifiedMissionRepairRejectInvalid;
result.performance.unifiedMissionRepairRejectGlobalRegression = ...
    unifiedMissionRepairRejectGlobalRegression;
result.performance.unifiedMissionRepairRejectProtection = ...
    unifiedMissionRepairRejectProtection;
result.performance.unifiedMissionRepairRejectProtectionComponent = ...
    unifiedMissionRepairRejectProtectionComponent;
result.performance.unifiedMissionRepairRejectProtectionQ = ...
    unifiedMissionRepairRejectProtectionQ;
result.performance.unifiedMissionRepairRejectProtectionCriticalQ = ...
    unifiedMissionRepairRejectProtectionCriticalQ;
result.performance.unifiedMissionRepairRejectProtectionObservation = ...
    unifiedMissionRepairRejectProtectionObservation;
result.performance.unifiedMissionRepairRejectProtectionLOS = ...
    unifiedMissionRepairRejectProtectionLOS;
result.performance.unifiedMissionRepairRejectTargetNoGain = ...
    unifiedMissionRepairRejectTargetNoGain;
result.performance.unifiedMissionRepairTargetGainSum = ...
    unifiedMissionRepairTargetGainSum;
result.performance.unifiedMissionRepairBestTargetGain = ...
    unifiedMissionRepairBestTargetGain;
result.performance.unifiedMissionRepairTargetCounts = ...
    unifiedMissionRepairTargetCounts;
result.performance.denseFinalAGLRepairApplied = denseAGLStats.applied;
result.performance.denseFinalAGLRepairPasses = denseAGLStats.passes;
result.performance.denseFinalAGLRepairEvaluations = denseAGLStats.evaluations;
result.performance.denseFinalAGLCandidateCount = denseSetStats.candidateCount;
result.performance.denseFinalAGLSelectedCandidateEvaluations = ...
    denseAGLStats.selectedCandidateEvaluations;
result.performance.denseFinalAGLMinBefore_m = denseAGLStats.minAGLBefore;
result.performance.denseFinalAGLMaxBefore_m = denseAGLStats.maxAGLBefore;
result.performance.denseFinalAGLMinAfter_m = denseAGLStats.minAGLAfter;
result.performance.denseFinalAGLMaxAfter_m = denseAGLStats.maxAGLAfter;
result.performance.thresholdChanges = thresholdChangeCount;
result.performance.thresholdRollbacks = thresholdState.rollbackCount;
result.performance.snapFinalCount = thresholdState.snapFinalCount;
result.performance.finalStageObjectiveReevaluations = ...
    finalStageObjectiveReevaluations;
if thresholdState.finalReached && isfinite(thresholdState.finalReachedGeneration)
    result.finalStageGenerations = stopGen-thresholdState.finalReachedGeneration+1;
else
    result.finalStageGenerations = 0;
end
result.performance.finalStageGenerations = result.finalStageGenerations;
result.performance.meanGenerationTime = mean(history(:,32));
result.performance.structuredTrialDecoderTime_s = structuredTrialDecoderTime_s;
result.performance.structuredTrialDenseProjectionTime_s = ...
    structuredTrialDenseProjectionTime_s;
result.performance.structuredTrialTerrainSamplingTime_s = ...
    structuredTrialTerrainSamplingTime_s;
result.performance.structuredTrialReachAttempts = structuredTrialReachAttempts;
result.performance.structuredTrialTerrainCacheHits = structuredTrialTerrainCacheHits;
result.performance.structuredTrialTerrainCacheMisses = structuredTrialTerrainCacheMisses;
cacheDenominator=structuredTrialTerrainCacheHits+structuredTrialTerrainCacheMisses;
if cacheDenominator>0
    result.performance.structuredTrialTerrainCacheHitRate = ...
        structuredTrialTerrainCacheHits/cacheDenominator;
else
    result.performance.structuredTrialTerrainCacheHitRate = NaN;
end
result.performance.commonHypervolumeEvaluations = commonHVEvaluationCount;
result.performance.commonArchiveUpdates = commonArchiveUpdateCount;
result.performance.commonArchiveSize = numel(bestCommonArchive);
for operatorIndex = 1:numel(operatorState.names)
    useName = sprintf('finalOperator%dUses',operatorIndex);
    acceptName = sprintf('finalOperator%dAccepted',operatorIndex);
    rewardName = sprintf('finalOperator%dReward',operatorIndex);
    result.performance.(useName) = operatorState.totalUses(operatorIndex);
    result.performance.(acceptName) = ...
        operatorState.totalAccepted(operatorIndex);
    result.performance.(rewardName) = ...
        operatorState.totalReward(operatorIndex);
end
end

function stats = localSelectedDenseAGLStats(best,index,reps,setStats)
base = struct('applied',false,'passes',0,'evaluations',0, ...
    'selectedCandidateEvaluations',0,'minAGLBefore',NaN,'maxAGLBefore',NaN, ...
    'minAGLAfter',NaN,'maxAGLAfter',NaN);
stats = base;
if isempty(setStats) || ~isfield(setStats,'candidateStats') || ...
        isempty(setStats.candidateStats)
    return;
end
candidateStats = setStats.candidateStats;
chosen = index;
if isempty(chosen) || ~isscalar(chosen) || ~isfinite(chosen) || chosen<1 || ...
        chosen>numel(candidateStats)
    chosen = [];
    if isfield(best,'genes') && isfield(reps,'solutions')
        for i = 1:numel(reps.solutions)
            if numel(reps.solutions(i).genes)==numel(best.genes) && ...
                    max(abs(reps.solutions(i).genes(:)-best.genes(:)))<=1e-10
                chosen = i;
                break;
            end
        end
    end
end
if ~isempty(chosen)
    selected = candidateStats(chosen);
    stats.applied = selected.applied;
    stats.passes = selected.passes;
    stats.minAGLBefore = selected.minAGLBefore;
    stats.maxAGLBefore = selected.maxAGLBefore;
    stats.minAGLAfter = selected.minAGLAfter;
    stats.maxAGLAfter = selected.maxAGLAfter;
    stats.selectedCandidateEvaluations = selected.evaluations;
end
% Count every representative re-evaluation as optimization/reporting work.
stats.evaluations = setStats.totalEvaluations;
end

function [archive,feasibleCandidates] = localUpdateFinalArchive( ...
    archive,candidates,cfg,generation,finalThresholds)
candidates = candidates(:);
feasibleCandidates = candidates;
if isempty(candidates), return; end
candidates = evaluation.updatePopulationDynamicConstraints( ...
    candidates,cfg,generation,finalThresholds);
feasibleCandidates = candidates( ...
    [candidates.cv] <= cfg.constraintTolerance);
if isempty(feasibleCandidates), return; end
% Final archive semantics are deliberately stricter than the search archive.
% Candidates have already been re-evaluated at epsilon_D=0 above; use the
% dedicated formal archive so search-only mission-band leader preservation can
% never insert an objective-dominated formal candidate.
archive = selection.updateFormalArchive( ...
    archive,feasibleCandidates,cfg.archiveSize,cfg);
end

function due = localCommonHVEvaluationDue(gen,cfg,enteredFinalStage)
interval = max(1,round(localCfg(cfg,'commonHVEvaluationInterval', ...
    localCfg(cfg,'hvEvaluationInterval',5))));
due = gen==1 || mod(gen,interval)==0 || ...
    gen==cfg.maxGenerations || enteredFinalStage;
end



function [decoderTime,projectionTime,samplingTime,reachAttempts,cacheHits,cacheMisses] = ...
    localAccumulateStructuredDecodePerformance(info,decoderTime,projectionTime, ...
    samplingTime,reachAttempts,cacheHits,cacheMisses)
if ~isstruct(info), return; end
if isfield(info,'decoderTime_s') && isfinite(info.decoderTime_s)
    decoderTime=decoderTime+info.decoderTime_s;
end
if isfield(info,'denseProjectionTime_s') && isfinite(info.denseProjectionTime_s)
    projectionTime=projectionTime+info.denseProjectionTime_s;
end
if isfield(info,'terrainSamplingTime_s') && isfinite(info.terrainSamplingTime_s)
    samplingTime=samplingTime+info.terrainSamplingTime_s;
end
if isfield(info,'reachAttempts') && isfinite(info.reachAttempts)
    reachAttempts=reachAttempts+info.reachAttempts;
end
if isfield(info,'terrainSampleCacheHits') && isfinite(info.terrainSampleCacheHits)
    cacheHits=cacheHits+info.terrainSampleCacheHits;
end
if isfield(info,'terrainSampleCacheMisses') && isfinite(info.terrainSampleCacheMisses)
    cacheMisses=cacheMisses+info.terrainSampleCacheMisses;
end
end

function [denseCount,turnFail,reachFail,otherFail] = localStructuredDecodeDiagnostics(pop)
denseCount=0; turnFail=0; reachFail=0; otherFail=0;
for i=1:numel(pop)
    if ~isfield(pop(i),'encodingInfo') || ~isstruct(pop(i).encodingInfo)
        otherFail=otherFail+1;
        continue;
    end
    info=pop(i).encodingInfo;
    if isfield(info,'denseSuccess') && info.denseSuccess, denseCount=denseCount+1; end
    if isfield(info,'success') && info.success, continue; end
    reason='';
    if isfield(info,'reason') && (ischar(info.reason) || isstring(info.reason))
        reason=char(info.reason);
    end
    if strcmp(reason,'turn')
        turnFail=turnFail+1;
    elseif contains(reason,'reach') || contains(reason,'terrain') || ...
            contains(reason,'altitude') || contains(reason,'climb') || ...
            contains(reason,'clearance') || contains(reason,'interval')
        reachFail=reachFail+1;
    else
        otherFail=otherFail+1;
    end
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end


function value = localProgressiveSmoothnessLimit(cfg)
finalStageGeneration = max(1,localCfg(cfg,'runtimeFinalStageGeneration',1));
tighteningGenerations = max(1,localCfg(cfg, ...
    'finalStageSmoothnessTighteningGenerations',80));
progress = min(1,max(0,(finalStageGeneration-1)/ ...
    max(tighteningGenerations-1,1)));
relaxed = localCfg(cfg,'finalStageSmoothnessRelaxedLimit',0.170);
target = localCfg(cfg,'finalStageSmoothnessTargetLimit',0.135);
value = relaxed+progress*(target-relaxed);
end

function tf = localFinalSatisfied(ind,cfg)
if isempty(ind)
    tf = false;
    return;
end
[mask,~,~] = evaluation.checkFinalMonitoringFeasibility(ind,cfg);
tf = isscalar(mask) && mask;
end
