function order = structuredMonitoringTargetOrder(problem,cfg)
%STRUCTUREDMONITORINGTARGETORDER Fixed A1-compatible target order for v7.2.0.
%
% The structured prototype intentionally freezes target order so the effect
% of semantic encoding can be isolated from sequencing. For missions larger
% than the exact-order limit this reproduces the A1 nearest-neighbour + 2-opt
% route used by guided seed variant 1.

T = problem.monitorTargets;
s = problem.start;
g = problem.goal;
M = size(T,1);
if M <= 1
    order = 1:M;
    return;
end
exactOrderLimit = max(1,round(localCfg(cfg,'monitorGuidedExactOrderMaxTargets',8)));
if M <= exactOrderLimit
    routes = perms(1:M);
    score = zeros(size(routes,1),1);
    for r = 1:size(routes,1)
        score(r) = localOrderScore(routes(r,:),s,g,T,problem,cfg);
    end
    [~,ranked] = sort(score,'ascend');
    order = routes(ranked(1),:);
    return;
end

remaining = 1:M;
order = zeros(1,M);
current = s(1:2);
for k = 1:M
    dCurrent = vecnorm(T(remaining,1:2)-current,2,2);
    dGoal = vecnorm(T(remaining,1:2)-g(1:2),2,2);
    greedyScore = dCurrent+0.10*dGoal;
    [~,q] = min(greedyScore);
    order(k) = remaining(q);
    current = T(order(k),1:2);
    remaining(q) = [];
end
order = localTwoOptOrder(order,s,g,T,problem,cfg);
end

function order = localTwoOptOrder(order,s,g,T,problem,cfg)
maxPasses = max(1,round(localCfg(cfg,'monitorGuidedTwoOptPasses',4)));
bestScore = localOrderScore(order,s,g,T,problem,cfg);
for pass = 1:maxPasses
    improved = false;
    for i = 1:numel(order)-1
        for j = i+1:numel(order)
            candidate = order;
            candidate(i:j) = order(j:-1:i);
            candidateScore = localOrderScore(candidate,s,g,T,problem,cfg);
            if candidateScore < bestScore-1e-9
                order = candidate;
                bestScore = candidateScore;
                improved = true;
            end
        end
    end
    if ~improved, break; end
end
end

function score = localOrderScore(order,s,g,T,problem,cfg)
xy = [s(1:2);T(order,1:2);g(1:2)];
score = sum(vecnorm(diff(xy,1,1),2,2))+ ...
    localObstacleOrderPenalty(xy,problem,cfg);
end

function penalty = localObstacleOrderPenalty(xy,problem,cfg)
penalty = 0;
if ~isfield(problem,'obstacles') || isempty(problem.obstacles), return; end
weight = localCfg(cfg,'monitorGuidedObstacleOrderPenalty',25);
margin = localCfg(cfg,'monitorGuidedObstacleOrderMargin',3);
for k = 1:size(xy,1)-1
    a = xy(k,:);
    b = xy(k+1,:);
    v = b-a;
    for j = 1:size(problem.obstacles,1)
        centre = problem.obstacles(j,1:2);
        tau = dot(centre-a,v)/(dot(v,v)+eps);
        tau = min(max(tau,0),1);
        distance = norm(a+tau*v-centre);
        deficit = max(0,problem.obstacles(j,3)+margin-distance);
        penalty = penalty+weight*deficit;
    end
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
