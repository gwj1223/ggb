function policy = aglSamplingPolicy(cfg)
%AGLSAMPLINGPOLICY Single source of truth for hard terrain-envelope sampling.
%
% v7.0.5.1 preserves both historical contracts deliberately:
%   fixed    - default/demo evaluation uses cfg.segmentSamples per segment;
%   adaptive - Shiyan formal evaluation uses physical-distance sampling.
% Repair and evaluation must select the same policy for a given cfg.

policy = struct();
policy.isAdaptive = localCfg(cfg,'enableDistanceAdaptiveAGLConstraintSampling',false);
policy.fixedSamples = max(2,round(localCfg(cfg,'segmentSamples',10)));
policy.step_m = max(1,localCfg(cfg,'aglConstraintSampleStep_m',15));
policy.maxSamplesPerSegment = max(3,round( ...
    localCfg(cfg,'aglConstraintMaxSamplesPerSegment',96)));
if policy.isAdaptive
    policy.mode = 'adaptive';
else
    policy.mode = 'fixed';
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
