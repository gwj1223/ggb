function state = initializeMonitoringThresholdState(cfg)
%INITIALIZEMONITORINGTHRESHOLDSTATE Runtime monitoring schedule state.
state.minimum = 0;
state.critical = 0;
state.observationLength = 0;
state.losRatio = 0;
state.stableMinimum = 0;
state.stableCritical = 0;
state.stableObservationLength = 0;
state.stableLOSRatio = 0;
state.finalMinimum = cfg.monitorMinTargetQuality;
state.finalCritical = cfg.monitorCriticalMinQuality;
if cfg.enableMonitoringGeometryConstraints
    state.finalObservationLength = cfg.monitorCriticalMinObservationLength;
    state.finalLOSRatio = cfg.monitorCriticalMinLOSRatio;
else
    state.finalObservationLength = 0;
    state.finalLOSRatio = 0;
end
state.progress = 0;
state.lastActionCode = 0;
state.lastAction = 'initial';
state.lastUpdateGeneration = 0;
state.updateCount = 0;
state.rollbackCount = 0;
state.finalReached = ~cfg.enableMonitoringConstraint;
state.finalReachedGeneration = NaN;
state.previousFeasibleRate = NaN;
state.lowFeasibleStreak = 0;
state.lastPredictedFeasibleRate = NaN;
state.finalFeasibleRate = 0;
state.finalFeasibleStreak = 0;
state.snapFinalCount = 0;
state.missionDeficitEpsilon = 1;
state.missionStage = 'initial';
if localCfg(cfg,'enableUnifiedMissionDeficit',false)
    th = evaluation.currentMonitoringThresholds(1,cfg);
    state.minimum = th.minimum;
    state.critical = th.critical;
    state.observationLength = th.observationLength;
    state.losRatio = th.losRatio;
    state.progress = th.progress;
    state.missionDeficitEpsilon = th.missionDeficitEpsilon;
    state.missionStage = char(th.missionStage);
    state.finalReached = strcmp(state.missionStage,'formal');
    if state.finalReached, state.finalReachedGeneration = 1; end
elseif state.finalReached
    state.progress = 1;
    state.finalReachedGeneration = 1;
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
