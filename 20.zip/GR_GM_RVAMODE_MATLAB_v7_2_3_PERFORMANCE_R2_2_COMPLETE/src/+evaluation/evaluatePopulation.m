function pop = evaluatePopulation(pop,problem,cfg,generation)
%EVALUATEPOPULATION Evaluate every individual with a schema-aware fast path.
%
% Current v6.4.x populations already carry the complete top-level schema, so
% direct structure assignment is substantially cheaper than copying every
% field one by one.  Legacy populations are still supported: when the first
% evaluated individual contains new top-level fields, the function falls back
% to schema-safe field copying for the whole population.

if nargin < 4, generation = cfg.maxGenerations; end
if isempty(pop), return; end

first = evaluation.evaluateIndividual(pop(1),problem,cfg,generation);
currentFields = sort(fieldnames(pop));
evaluatedFields = sort(fieldnames(first));
fastAssignment = isequal(currentFields,evaluatedFields);

if fastAssignment
    pop(1) = first;
    for i = 2:numel(pop)
        pop(i) = evaluation.evaluateIndividual( ...
            pop(i),problem,cfg,generation);
    end
else
    pop = localCopyFields(pop,1,first);
    for i = 2:numel(pop)
        evaluated = evaluation.evaluateIndividual( ...
            pop(i),problem,cfg,generation);
        pop = localCopyFields(pop,i,evaluated);
    end
end
end

function pop = localCopyFields(pop,index,evaluated)
names = fieldnames(evaluated);
for k = 1:numel(names)
    pop(index).(names{k}) = evaluated.(names{k});
end
end
