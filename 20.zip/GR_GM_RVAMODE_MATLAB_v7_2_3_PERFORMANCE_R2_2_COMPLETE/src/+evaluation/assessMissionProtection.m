function protection = assessMissionProtection(base,trial,cfg,generation)
%ASSESSMISSIONPROTECTION Stage-aware mission-preservation gate for unified A3.
%
% v7.1.1 separates formal satisfaction from stable-enough-to-freeze evidence.
% During mission formation, a condition becomes hard-protected only after the
% base clears the formal threshold by a configured hysteresis margin. Once it
% is protected, the trial may consume that margin but may not cross the formal
% threshold. In the formal stage, the original strict protection is restored.
%
% This helper does not change any formal monitoring threshold and does not
% relax the global Mission Deficit non-regression gate. It only determines
% which already-achieved mission conditions are frozen during local A3 repair.

if nargin < 4 || isempty(generation) || ~isscalar(generation) || ...
        ~isfinite(generation)
    generation = localCfg(cfg,'missionFormalStartGeneration',100);
end

protection = localEmpty();
formalStart = max(1,round(localCfg(cfg,'missionFormalStartGeneration',100)));
useHysteresis = localCfg(cfg,'enableFormationMissionProtectionHysteresis',false) && ...
    generation < formalStart;
if useHysteresis
    protection.stage = 'formation';
else
    protection.stage = 'formal';
end

if isempty(base) || isempty(trial) || ~isstruct(base) || ~isstruct(trial)
    protection.reason = 'invalid';
    return;
end

baseQ = localQ(base);
trialQ = localQ(trial);
if isempty(baseQ) || numel(baseQ)~=numel(trialQ)
    protection.reason = 'invalid';
    return;
end
M = numel(baseQ);
componentTol = max(0,localCfg(cfg,'missionDeficitComponentTolerance',1e-12));

qReq = localCfg(cfg,'monitorMinTargetQuality',0.33);
criticalReq = localCfg(cfg,'monitorCriticalMinQuality',0.42);
obsReq = localCfg(cfg,'monitorCriticalMinObservationLength',180);
losReq = localCfg(cfg,'monitorCriticalMinLOSRatio',0.45);

if useHysteresis
    qEntry = qReq + max(0,localCfg(cfg,'missionProtectionQMargin',0.02));
    criticalEntry = criticalReq + max(0,localCfg(cfg, ...
        'missionProtectionCriticalQMargin',0.02));
    obsEntry = obsReq + max(0,localCfg(cfg, ...
        'missionProtectionObservationMargin_m',20));
    losEntry = losReq + max(0,localCfg(cfg,'missionProtectionLOSMargin',0.05));
else
    qEntry = qReq;
    criticalEntry = criticalReq;
    obsEntry = obsReq;
    losEntry = losReq;
end

% Per-target minimum-quality protection.
protectedQ = baseQ >= qEntry-componentTol;
brokenQ = find(protectedQ & trialQ < qReq-componentTol,1,'first');
if ~isempty(brokenQ)
    protection = localReject(protection,'protected_q',brokenQ,0, ...
        baseQ(brokenQ),trialQ(brokenQ),qReq,qEntry);
    return;
end

% Aggregate Critical-quality protection is a separate formal condition.
critical = localCriticalIndices(cfg,M);
baseCriticalQ = localCriticalQuality(base,critical,baseQ);
trialCriticalQ = localCriticalQuality(trial,critical,trialQ);
if isfinite(baseCriticalQ) && isfinite(trialCriticalQ) && ...
        baseCriticalQ >= criticalEntry-componentTol && ...
        trialCriticalQ < criticalReq-componentTol
    protection = localReject(protection,'protected_critical_q',0,2, ...
        baseCriticalQ,trialCriticalQ,criticalReq,criticalEntry);
    return;
end

if ~isempty(critical) && localCfg(cfg,'enableMonitoringGeometryConstraints',true)
    baseObs = localMonitorVector(base,'observationLength',M);
    trialObs = localMonitorVector(trial,'observationLength',M);
    protectedObs = baseObs(critical) >= obsEntry-componentTol;
    obsLocal = find(protectedObs & ...
        trialObs(critical) < obsReq-componentTol,1,'first');
    if ~isempty(obsLocal)
        t = critical(obsLocal);
        protection = localReject(protection,'protected_observation',t,3, ...
            baseObs(t),trialObs(t),obsReq,obsEntry);
        return;
    end

    baseLOS = localMonitorVector(base,'losRatio',M);
    trialLOS = localMonitorVector(trial,'losRatio',M);
    protectedLOS = baseLOS(critical) >= losEntry-componentTol;
    losLocal = find(protectedLOS & ...
        trialLOS(critical) < losReq-componentTol,1,'first');
    if ~isempty(losLocal)
        t = critical(losLocal);
        protection = localReject(protection,'protected_los',t,4, ...
            baseLOS(t),trialLOS(t),losReq,losEntry);
        return;
    end
end

% During formation, the raw-metric hysteresis rules above are the protection
% contract. Do not immediately re-freeze the same conditions through a zero
% component check. In the formal stage, keep the historical component guard
% as a final consistency backstop.
if ~useHysteresis
    baseInfo = evaluation.missionDeficitComponents(base,cfg);
    trialInfo = evaluation.missionDeficitComponents(trial,cfg);
    if ~isfinite(baseInfo.total) || ~isfinite(trialInfo.total)
        protection.reason = 'invalid';
        return;
    end
    satisfied = baseInfo.components<=componentTol;
    broken = find(satisfied & trialInfo.components>componentTol,1,'first');
    if ~isempty(broken)
        protection = localReject(protection,'protected_component',0,broken, ...
            baseInfo.components(broken),trialInfo.components(broken),0,0);
        return;
    end
end

protection.allowed = true;
protection.reason = 'accepted';
end

function protection = localEmpty()
protection = struct( ...
    'allowed',false, ...
    'reason','invalid', ...
    'stage','formal', ...
    'targetIndex',0, ...
    'componentIndex',0, ...
    'baseValue',NaN, ...
    'trialValue',NaN, ...
    'formalThreshold',NaN, ...
    'entryThreshold',NaN, ...
    'violationGap',0);
end

function protection = localReject(protection,reason,targetIndex,componentIndex, ...
        baseValue,trialValue,formalThreshold,entryThreshold)
protection.allowed = false;
protection.reason = reason;
protection.targetIndex = targetIndex;
protection.componentIndex = componentIndex;
protection.baseValue = baseValue;
protection.trialValue = trialValue;
protection.formalThreshold = formalThreshold;
protection.entryThreshold = entryThreshold;
if isfinite(trialValue) && isfinite(formalThreshold)
    if strcmp(reason,'protected_component')
        protection.violationGap = max(0,trialValue-formalThreshold);
    else
        protection.violationGap = max(0,formalThreshold-trialValue);
    end
else
    protection.violationGap = inf;
end
end

function critical = localCriticalIndices(cfg,M)
critical = [];
if isfield(cfg,'criticalTargetIndices')
    critical = cfg.criticalTargetIndices(:);
    critical = critical(critical>=1 & critical<=M);
end
end

function value = localCriticalQuality(ind,critical,Q)
value = NaN;
if isfield(ind,'monitorStats')
    if isfield(ind.monitorStats,'trueCriticalQuality') && ...
            isscalar(ind.monitorStats.trueCriticalQuality) && ...
            isfinite(ind.monitorStats.trueCriticalQuality)
        value = ind.monitorStats.trueCriticalQuality;
        return;
    elseif isfield(ind.monitorStats,'criticalQuality') && ...
            isscalar(ind.monitorStats.criticalQuality) && ...
            isfinite(ind.monitorStats.criticalQuality)
        value = ind.monitorStats.criticalQuality;
        return;
    end
end
if ~isempty(critical)
    value = mean(Q(critical));
end
end

function Q = localQ(ind)
if isfield(ind,'monitorStats') && isfield(ind.monitorStats,'truePerTarget') && ...
        ~isempty(ind.monitorStats.truePerTarget)
    Q = ind.monitorStats.truePerTarget(:);
elseif isfield(ind,'monitorPerTarget') && ~isempty(ind.monitorPerTarget)
    Q = ind.monitorPerTarget(:);
else
    Q = [];
end
Q(~isfinite(Q)) = 0;
end

function values = localMonitorVector(ind,name,M)
values = zeros(M,1);
if isfield(ind,'monitorStats') && isfield(ind.monitorStats,name)
    raw = ind.monitorStats.(name);
    raw = raw(:);
    n = min(M,numel(raw));
    values(1:n) = raw(1:n);
end
values(~isfinite(values)) = 0;
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
