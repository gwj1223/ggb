function [loss,diag] = monitoringObjectiveLoss(stats,cfg)
%MONITORINGOBJECTIVELOSS Search loss with final-stage epsilon-quality saturation.
%
% True physical monitoring values are never modified here. Only the fifth
% optimization objective is saturated after the complete final constraints
% have been activated, preventing unnecessary quality over-optimization.

qAverage = stats.searchAverageQuality;
qMinimum = stats.searchMinimumQuality;
qCritical = stats.searchCriticalQuality;
dispersionWeight = cfg.monitorDispersionWeight;

finalStage = localCfg(cfg,'runtimeMonitoringFinalReached',false);
saturationActive = finalStage && ...
    localCfg(cfg,'enableFinalStageMonitoringSaturation',true);
if saturationActive
    qAverage = min(qAverage,localCfg(cfg, ...
        'finalStageAverageQualityCap',0.82));
    qMinimum = min(qMinimum,localCfg(cfg, ...
        'finalStageMinimumQualityCap',0.72));
    qCritical = min(qCritical,localCfg(cfg, ...
        'finalStageCriticalQualityCap',0.80));
    dispersionWeight = dispersionWeight*localCfg(cfg, ...
        'finalStageDispersionWeightScale',0.50);
end

loss = cfg.monitorAverageWeight*(1-qAverage)+ ...
    cfg.monitorMinimumWeight*(1-qMinimum)+ ...
    cfg.monitorCriticalWeight*(1-qCritical)+ ...
    dispersionWeight*stats.searchDispersionPenalty+ ...
    localCfg(cfg,'monitorCoverageDeficitWeight',0)* ...
        stats.worstCoverageDeficit+ ...
    localCfg(cfg,'monitorObservationDeficitWeight',0)* ...
        stats.worstObservationDeficit;

diag.averageQuality = qAverage;
diag.minimumQuality = qMinimum;
diag.criticalQuality = qCritical;
diag.dispersionWeight = dispersionWeight;
diag.saturationActive = saturationActive;
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
