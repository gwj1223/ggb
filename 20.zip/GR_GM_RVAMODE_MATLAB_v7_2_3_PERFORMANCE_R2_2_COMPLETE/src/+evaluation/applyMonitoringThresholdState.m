function runtimeCfg = applyMonitoringThresholdState(cfg,state)
%APPLYMONITORINGTHRESHOLDSTATE Add runtime monitoring schedule to a config.
runtimeCfg = cfg;
runtimeCfg.runtimeMonitoringMinimumThreshold = state.minimum;
runtimeCfg.runtimeMonitoringCriticalThreshold = state.critical;
runtimeCfg.runtimeMonitoringObservationLengthThreshold = ...
    state.observationLength;
runtimeCfg.runtimeMonitoringLOSRatioThreshold = state.losRatio;
runtimeCfg.runtimeMonitoringThresholdProgress = state.progress;
runtimeCfg.runtimeMonitoringFinalReached = state.finalReached;
if isfield(state,'missionDeficitEpsilon')
    runtimeCfg.runtimeMissionDeficitEpsilon = state.missionDeficitEpsilon;
end
if isfield(state,'missionStage')
    runtimeCfg.runtimeMissionStage = state.missionStage;
end
end
