function info = missionRepairTargetDeficits(source,cfg)
%MISSIONREPAIRTARGETDEFICITS Canonical per-target urgency used by unified A3.
%
% This is the single source of truth for both:
%   - selecting which monitoring target A3 should repair; and
%   - measuring whether the selected target actually improved.
%
% SOURCE may be either an evaluated individual or its monitorStats struct.
% The returned score is a mission-repair urgency only. It is not an objective
% and does not replace the population-wide Unified Mission Deficit D_M.

stats = localStats(source);
Q = localQuality(source,stats);
M = numel(Q);
Q(~isfinite(Q)) = 0;

info = struct( ...
    'total',zeros(M,1), ...
    'qDeficit',zeros(M,1), ...
    'criticalQualityDeficit',zeros(M,1), ...
    'observationDeficit',zeros(M,1), ...
    'losDeficit',zeros(M,1), ...
    'trueQuality',Q, ...
    'searchQuality',zeros(M,1), ...
    'criticalIndices',zeros(0,1), ...
    'weights',localWeights(cfg));
if M==0, return; end

info.searchQuality = localVector(stats,'searchPerTarget',M,Q);
qReq = max(localCfg(cfg,'monitorMinTargetQuality',0.33),eps);
info.qDeficit = min(max((qReq-Q)/qReq,0),1);
info.total = info.weights(1)*info.qDeficit;

critical = localCriticalIndices(cfg,M);
info.criticalIndices = critical;
if isempty(critical), return; end

criticalReq = max(localCfg(cfg,'monitorCriticalMinQuality',0.42),eps);
aggregateCritical = localCriticalQuality(stats,Q,critical);
if aggregateCritical < criticalReq
    info.criticalQualityDeficit(critical) = min(max( ...
        (criticalReq-Q(critical))/criticalReq,0),1);
end

if localCfg(cfg,'enableMonitoringGeometryConstraints',true)
    obsReq = max(localCfg(cfg,'monitorCriticalMinObservationLength',180),eps);
    losReq = max(localCfg(cfg,'monitorCriticalMinLOSRatio',0.45),eps);
    obs = localVector(stats,'observationLength',M,zeros(M,1));
    los = localVector(stats,'losRatio',M,zeros(M,1));
    info.observationDeficit(critical) = min(max( ...
        (obsReq-obs(critical))/obsReq,0),1);
    info.losDeficit(critical) = min(max( ...
        (losReq-los(critical))/losReq,0),1);
end

info.total(critical) = ...
    info.weights(1)*info.qDeficit(critical) + ...
    info.weights(2)*info.criticalQualityDeficit(critical) + ...
    info.weights(3)*info.observationDeficit(critical) + ...
    info.weights(4)*info.losDeficit(critical);
end

function stats = localStats(source)
stats = struct();
if isstruct(source) && isfield(source,'monitorStats') && ...
        isstruct(source.monitorStats)
    stats = source.monitorStats;
elseif isstruct(source)
    stats = source;
end
end

function Q = localQuality(source,stats)
Q = [];
if isfield(stats,'truePerTarget') && ~isempty(stats.truePerTarget)
    Q = stats.truePerTarget(:);
elseif isstruct(source) && isfield(source,'monitorPerTarget') && ...
        ~isempty(source.monitorPerTarget)
    Q = source.monitorPerTarget(:);
end
end

function value = localCriticalQuality(stats,Q,critical)
if isfield(stats,'trueCriticalQuality') && ...
        isscalar(stats.trueCriticalQuality) && isfinite(stats.trueCriticalQuality)
    value = stats.trueCriticalQuality;
elseif isfield(stats,'criticalQuality') && ...
        isscalar(stats.criticalQuality) && isfinite(stats.criticalQuality)
    value = stats.criticalQuality;
else
    value = mean(Q(critical));
end
end

function critical = localCriticalIndices(cfg,M)
critical = zeros(0,1);
if isfield(cfg,'criticalTargetIndices')
    critical = cfg.criticalTargetIndices(:);
    critical = critical(critical>=1 & critical<=M);
end
end

function values = localVector(stats,name,M,defaultValues)
values = reshape(defaultValues,[],1);
if numel(values)~=M, values = zeros(M,1); end
if isfield(stats,name) && ~isempty(stats.(name))
    raw = stats.(name);
    raw = raw(:);
    n = min(M,numel(raw));
    values(1:n) = raw(1:n);
end
values(~isfinite(values)) = 0;
end

function weights = localWeights(cfg)
weights = localCfg(cfg,'missionRepairTargetWeights',[1.00 0.35 1.30 0.80]);
weights = reshape(weights,1,[]);
if numel(weights)~=4 || any(~isfinite(weights)) || any(weights<0)
    weights = [1.00 0.35 1.30 0.80];
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
