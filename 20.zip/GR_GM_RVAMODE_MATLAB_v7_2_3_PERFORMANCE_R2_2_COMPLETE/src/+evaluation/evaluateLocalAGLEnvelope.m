function stats = evaluateLocalAGLEnvelope(path,problem,cfg)
%EVALUATELOCALAGLENVELOPE Distance-adaptive hard local-AGL evaluation.
%
% v7.0.5 uses evaluation.sampleSegmentTerrainAdaptive as the shared sampling
% contract also used by A3 dense reachability and segment repair. Violation
% magnitudes remain normalized to approximately cfg.segmentSamples samples per
% segment so denser safety checking does not silently reweight Deb CV.

stats = struct('lowerViolation',0,'upperViolation',0, ...
    'minimumAGL',inf,'maximumAGL',-inf,'sampleCount',0, ...
    'maximumSpacing_m',0);
if isempty(path) || size(path,1)<2
    return;
end
baseSamples = max(2,round(localCfg(cfg,'segmentSamples',10)));
enableUpper = localCfg(cfg,'enableLocalAGLConstraint',false) && ...
    isfield(cfg,'realMaximumAGL') && isfinite(cfg.realMaximumAGL);

for k = 1:size(path,1)-1
    sample = evaluation.sampleSegmentTerrainAdaptive( ...
        path(k,:),path(k+1,:),problem,cfg);
    agl = sample.z-sample.terrain;
    lower = max(0,cfg.safeClearance-agl);
    if enableUpper
        upper = max(0,agl-cfg.realMaximumAGL);
    else
        upper = zeros(size(lower));
    end
    normalization = baseSamples/max(sample.numSamples,1);
    stats.lowerViolation = stats.lowerViolation+sum(lower)*normalization;
    stats.upperViolation = stats.upperViolation+sum(upper)*normalization;
    stats.minimumAGL = min(stats.minimumAGL,min(agl));
    stats.maximumAGL = max(stats.maximumAGL,max(agl));
    stats.sampleCount = stats.sampleCount+sample.numSamples;
    stats.maximumSpacing_m = max(stats.maximumSpacing_m, ...
        sample.maximumSpacing_m);
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
