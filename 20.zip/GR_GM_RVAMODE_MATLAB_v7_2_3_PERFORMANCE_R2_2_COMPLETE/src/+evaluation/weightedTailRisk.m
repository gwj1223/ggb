function value = weightedTailRisk(riskValues,sampleWeights,alpha)
%WEIGHTEDTAILRISK Weighted CVaR of the upper risk tail.
% alpha=0.90 returns the distance-weighted mean of the highest-risk 10%%.

riskValues = reshape(double(riskValues),[],1);
sampleWeights = reshape(double(sampleWeights),[],1);
valid = isfinite(riskValues) & isfinite(sampleWeights) & sampleWeights>0;
riskValues = riskValues(valid);
sampleWeights = sampleWeights(valid);
if isempty(riskValues)
    value = 0;
    return;
end
alpha = min(max(double(alpha),0),1-eps);
tailWeight = (1-alpha)*sum(sampleWeights);
if tailWeight <= eps
    value = max(riskValues);
    return;
end
[riskValues,order] = sort(riskValues,'descend');
sampleWeights = sampleWeights(order);
remaining = tailWeight;
weightedSum = 0;
for k = 1:numel(riskValues)
    used = min(sampleWeights(k),remaining);
    weightedSum = weightedSum+used*riskValues(k);
    remaining = remaining-used;
    if remaining <= eps
        break;
    end
end
value = weightedSum/max(tailWeight,eps);
end
