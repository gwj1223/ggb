function [rate,mask,cv] = predictMonitoringFeasibleRate(pop,thresholds,cfg)
%PREDICTMONITORINGFEASIBLERATE Feasibility under explicit true thresholds.
%
% This lightweight routine reads cached physical monitoring metrics only;
% it never recomputes terrain, LOS or path objectives.
if isempty(pop)
    rate = NaN;
    mask = false(0,1);
    cv = zeros(0,1);
    return;
end
pop = pop(:);
N = numel(pop);
mask = false(N,1);
cv = inf(N,1);
for i = 1:N
    ind = pop(i);
    minViolation = sum(max(0,thresholds.minimum- ...
        localTruePerTarget(ind)));
    criticalViolation = max(0,thresholds.critical- ...
        localTrueCriticalQuality(ind));
    observationViolation = 0;
    losViolation = 0;
    if cfg.enableMonitoringGeometryConstraints
        critical = cfg.criticalTargetIndices(:);
        critical = critical(critical>=1 & ...
            critical<=numel(ind.monitorPerTarget));
        if ~isempty(critical)
            observationViolation = sum(max(0, ...
                thresholds.observationLength- ...
                ind.monitorStats.observationLength(critical)));
            losViolation = sum(max(0,thresholds.losRatio- ...
                ind.monitorStats.losRatio(critical)));
        end
    end
    staticCV = ind.staticCV;
    cv(i) = staticCV+ ...
        minViolation/max(cfg.cvScaleMonitoring,eps)+ ...
        criticalViolation/max(cfg.cvScaleMonitoring,eps)+ ...
        observationViolation/max(cfg.cvScaleObservationLength,eps)+ ...
        losViolation/max(cfg.cvScaleLOSRatio,eps);
    mask(i) = cv(i)<=cfg.constraintTolerance;
end
rate = sum(mask)/max(N,1);
end

function values = localTruePerTarget(ind)
if isfield(ind,'monitorStats') && ...
        isfield(ind.monitorStats,'truePerTarget')
    values = ind.monitorStats.truePerTarget;
else
    values = ind.monitorPerTarget;
end
values = values(:);
end

function value = localTrueCriticalQuality(ind)
if isfield(ind,'monitorStats') && ...
        isfield(ind.monitorStats,'trueCriticalQuality')
    value = ind.monitorStats.trueCriticalQuality;
else
    value = ind.monitorStats.criticalQuality;
end
end
