function ind = evaluateIndividual(ind,problem,cfg,generation)
%EVALUATEINDIVIDUAL Evaluate v6.3.6 objectives and constraints.
if nargin < 4, generation = cfg.maxGenerations; end
pts = reshape(ind.genes,[],3);
path = [problem.start;pts;problem.goal];
ind.path = path;
seg = diff(path,1,1);
horizontal = hypot(seg(:,1),seg(:,2));

% One vectorized interpolation batch supplies risk and clearance samples.
sampleCache = evaluation.buildPathSampleCache( ...
    path,problem,cfg.segmentSamples,true);
d = sampleCache.segmentLengths;
rawLength = sum(d);
directDistance = norm(problem.goal-problem.start);
detourRatio = rawLength/max(directDistance,eps);
if cfg.useDetourRatioObjective
    lengthObjective = detourRatio;
else
    lengthObjective = rawLength;
end

% Distance-weighted mean risk and upper-tail CVaR risk.
numSamples = sampleCache.numSamples;
riskValues = sampleCache.risk(:);
sampleWeights = repmat((d(:)'/max(numSamples,1)),numSamples,1);
sampleWeights = sampleWeights(:);
meanRisk = sum(riskValues.*sampleWeights)/max(sum(sampleWeights),eps);
tailRisk = evaluation.weightedTailRisk( ...
    riskValues,sampleWeights,cfg.riskCVaRAlpha);
riskObjective = cfg.riskMeanWeight*meanRisk+ ...
    cfg.riskTailWeight*tailRisk;

% Shiyan multi-UAV hard terrain envelopes can use a physical-distance
% adaptive sampling grid. Legacy/demo configurations retain their historical
% fixed sample count so baseline problem definitions are not silently changed.
aglPolicy = evaluation.aglSamplingPolicy(cfg);
if aglPolicy.isAdaptive
    aglStats = evaluation.evaluateLocalAGLEnvelope(path,problem,cfg);
    lowerClearanceViolation = aglStats.lowerViolation;
    upperAGLViolation = aglStats.upperViolation;
else
    sampleZ = reshape(sampleCache.points(:,3), ...
        sampleCache.numSamples,sampleCache.numSegments);
    lowerMatrix = max(0,sampleCache.terrain+cfg.safeClearance-sampleZ);
    lowerClearanceViolation = sum(lowerMatrix(:));
    upperAGLViolation = 0;
    if localCfg(cfg,'enableLocalAGLConstraint',false) && ...
            isfield(cfg,'realMaximumAGL') && isfinite(cfg.realMaximumAGL)
        upperMatrix = max(0,sampleZ-(sampleCache.terrain+cfg.realMaximumAGL));
        upperAGLViolation = sum(upperMatrix(:));
    end
    agl = sampleZ-sampleCache.terrain;
    aglStats = struct('lowerViolation',lowerClearanceViolation, ...
        'upperViolation',upperAGLViolation,'minimumAGL',min(agl(:)), ...
        'maximumAGL',max(agl(:)),'sampleCount',numel(agl), ...
        'maximumSpacing_m',NaN);
end
% Keep the established CV schema: the clearance channel represents the
% complete terrain-relative flight envelope (lower + upper).
clearanceViolation = lowerClearanceViolation+upperAGLViolation;
collisionCount = evaluation.obstacleHits(problem,sampleCache.points);

climbAngles = atan2d(abs(seg(:,3)),max(horizontal,eps));
climbViolation = sum(max(0,climbAngles-cfg.maxClimbAngleDeg));
if size(seg,1)>1
    numerator = sum(seg(1:end-1,:).*seg(2:end,:),2);
    denominator = d(1:end-1).*d(2:end)+eps;
    cosine = max(-1,min(1,numerator./denominator));
    turnAngles = acosd(cosine);
else
    turnAngles = zeros(0,1);
end
turnViolation = sum(max(0,turnAngles-cfg.maxTurnAngleDeg));

% Monitoring metrics are evaluated before energy because the energy model
% includes slow observation flight and equivalent hover compensation.
if cfg.monitorCoverageSamples == cfg.segmentSamples
    monitorCache = sampleCache;
else
    monitorCache = [];
end
[monitorQuality,perTarget,monitorStats] = ...
    evaluation.monitoringQuality(path,problem,cfg,monitorCache);
% Choose the truly weakest target; when several targets have identical true
% quality, the smooth search quality supplies a deterministic gradient.
trueMinimum = min(perTarget);
worstCandidates = find(abs(perTarget-trueMinimum)<=1e-12);
if numel(worstCandidates)>1
    [~,localWorst] = min(monitorStats.searchPerTarget(worstCandidates));
    worstIdx = worstCandidates(localWorst);
else
    worstIdx = worstCandidates(1);
end
monitorStats.worstTargetIndex = worstIdx;
% v7.0.0: task-specific repair follows final-mission urgency, not only Qmin.
monitorStats.repairTargetIndex = evaluation.selectMonitoringRepairTarget( ...
    monitorStats,cfg);
% The fifth objective uses the smooth search surrogate. During the final
% stage, robustly excessive quality is saturated so that route length, risk,
% energy and smoothness can continue improving. Physical constraints and
% reports always use the uncapped true qualities.
[monitorLoss,monitorObjectiveStats] = ...
    evaluation.monitoringObjectiveLoss(monitorStats,cfg);
monitorStats.objectiveAverageQuality = ...
    monitorObjectiveStats.averageQuality;
monitorStats.objectiveMinimumQuality = ...
    monitorObjectiveStats.minimumQuality;
monitorStats.objectiveCriticalQuality = ...
    monitorObjectiveStats.criticalQuality;
monitorStats.objectiveSaturationActive = ...
    monitorObjectiveStats.saturationActive;

% Propulsion and monitoring energy.
climb = sum(max(seg(:,3),0));
descent = sum(max(-seg(:,3),0));
heading = atan2(seg(:,2),seg(:,1));
dHead = diff(heading);
dHead = atan2(sin(dHead),cos(dHead));
turnRad = sum(abs(dHead));
wind = problem.wind(1,:);
unitDirection = bsxfun(@rdivide,seg,d+eps);
headwind = max(0,-unitDirection*wind');
windPenalty = sum(headwind.*d);

horizontalEnergy = cfg.energyHorizontalCoeff*sum(horizontal);
climbEnergy = cfg.energyClimbCoeff*climb;
descentEnergy = cfg.energyDescentCoeff*descent;
turnEnergy = cfg.energyTurnCoeff*turnRad;
windEnergy = cfg.energyWindCoeff*windPenalty;
observationTime = monitorStats.unionObservationLength/ ...
    max(cfg.monitorObservationSpeed,eps);
observationEnergy = cfg.energyObservationPower*observationTime;
critical = cfg.criticalTargetIndices(:);
critical = critical(critical>=1 & critical<=numel(perTarget));
if isempty(critical)
    observationDeficit = 0;
else
    observationDeficit = sum(max(0, ...
        cfg.monitorRequiredObservationLength- ...
        monitorStats.observationLength(critical)));
end
hoverEquivalentTime = observationDeficit/ ...
    max(cfg.monitorHoverEquivalentSpeed,eps);
hoverEnergy = cfg.energyHoverPower*hoverEquivalentTime;
energy = horizontalEnergy+climbEnergy+descentEnergy+turnEnergy+ ...
    windEnergy+observationEnergy+hoverEnergy;
energyViolation = max(0,energy-cfg.maxEnergy);

% Turn, vertical-angle variation and curvature variation.
if isempty(turnAngles)
    turnCost = 0;
    curvature = zeros(0,1);
else
    turnCost = mean((turnAngles/max(cfg.maxTurnAngleDeg,eps)).^2);
    localArc = 0.5*(d(1:end-1)+d(2:end));
    curvature = deg2rad(turnAngles)./max(localArc,eps);
end
if size(seg,1)>1
    gamma = atan2d(seg(:,3),max(horizontal,eps));
    verticalCost = mean((diff(gamma)/max(cfg.maxClimbAngleDeg,eps)).^2);
else
    gamma = zeros(size(seg,1),1);
    verticalCost = 0;
end
if numel(curvature)>1
    curvatureCost = mean((diff(curvature)/ ...
        max(cfg.smoothCurvatureScale,eps)).^2);
else
    curvatureCost = 0;
end
smooth = cfg.smoothTurnWeight*turnCost+ ...
    cfg.smoothVerticalWeight*verticalCost+ ...
    cfg.smoothCurvatureWeight*curvatureCost;

ind.objectives = [lengthObjective riskObjective energy smooth monitorLoss];
ind.pathMetrics.rawLength = rawLength;
ind.pathMetrics.directDistance = directDistance;
ind.pathMetrics.detourRatio = detourRatio;
ind.riskStats.meanRisk = meanRisk;
ind.riskStats.tailRisk = tailRisk;
ind.riskStats.objective = riskObjective;
ind.energyStats.horizontal = horizontalEnergy;
ind.energyStats.climb = climbEnergy;
ind.energyStats.descent = descentEnergy;
ind.energyStats.turn = turnEnergy;
ind.energyStats.wind = windEnergy;
ind.energyStats.observation = observationEnergy;
ind.energyStats.hoverEquivalent = hoverEnergy;
ind.energyStats.observationTime = observationTime;
ind.energyStats.hoverEquivalentTime = hoverEquivalentTime;
ind.energyStats.total = energy;
ind.smoothStats.turn = turnCost;
ind.smoothStats.vertical = verticalCost;
ind.smoothStats.curvature = curvatureCost;
ind.monitorQuality = monitorQuality;
ind.monitorPerTarget = perTarget;
ind.searchMonitorQuality = monitorStats.searchAverageQuality;
ind.searchMonitorPerTarget = monitorStats.searchPerTarget;
ind.monitorStats = monitorStats;
ind.violation.collision = collisionCount;
ind.violation.clearance = clearanceViolation;
ind.violation.climb = climbViolation;
ind.violation.turn = turnViolation;
ind.violation.energy = energyViolation;
ind.aglStats = aglStats;
ind.staticCV = collisionCount/max(cfg.cvScaleCollision,eps)+ ...
    clearanceViolation/max(cfg.cvScaleClearance,eps)+ ...
    climbViolation/max(cfg.cvScaleClimb,eps)+ ...
    turnViolation/max(cfg.cvScaleTurn,eps)+ ...
    energyViolation/max(cfg.cvScaleEnergy,eps);
ind = evaluation.updateDynamicConstraints(ind,cfg,generation);
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
