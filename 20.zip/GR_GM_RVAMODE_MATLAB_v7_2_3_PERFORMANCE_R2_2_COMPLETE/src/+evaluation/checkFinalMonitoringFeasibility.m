function [mask,rate,cv] = checkFinalMonitoringFeasibility(pop,cfg)
%CHECKFINALMONITORINGFEASIBILITY Test cached paths against final requirements.
thresholds.minimum = cfg.monitorMinTargetQuality;
thresholds.critical = cfg.monitorCriticalMinQuality;
thresholds.observationLength = cfg.monitorCriticalMinObservationLength;
thresholds.losRatio = cfg.monitorCriticalMinLOSRatio;
[rate,mask,cv] = evaluation.predictMonitoringFeasibleRate( ...
    pop,thresholds,cfg);
end
