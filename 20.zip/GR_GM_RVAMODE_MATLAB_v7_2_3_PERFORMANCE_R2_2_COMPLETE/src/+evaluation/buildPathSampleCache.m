function cache = buildPathSampleCache(path,problem,nSamples,includeRisk)
%BUILDPATHSAMPLECACHE Vectorized samples for every path segment.
if nargin < 4, includeRisk = false; end
nSamples = max(2,round(nSamples));
starts = path(1:end-1,:);
delta = diff(path,1,1);
numSegments = size(delta,1);
q = linspace(0,1,nSamples)';
pointCube = bsxfun(@plus,reshape(starts,1,numSegments,3), ...
    bsxfun(@times,reshape(q,nSamples,1,1),reshape(delta,1,numSegments,3)));
points = reshape(pointCube,[],3);
terrain = data.terrainHeight(problem,points(:,1),points(:,2));
cache.points = points;
cache.pointCube = pointCube;
cache.terrain = reshape(terrain,nSamples,numSegments);
cache.segmentLengths = sqrt(sum(delta.^2,2));
cache.numSamples = nSamples;
cache.numSegments = numSegments;
if includeRisk
    risk = data.riskValue(problem,points(:,1),points(:,2));
    cache.risk = reshape(risk,nSamples,numSegments);
else
    cache.risk = [];
end
end
