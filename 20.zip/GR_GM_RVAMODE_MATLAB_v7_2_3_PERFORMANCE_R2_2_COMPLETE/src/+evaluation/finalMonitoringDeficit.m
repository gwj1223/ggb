function score = finalMonitoringDeficit(ind,cfg)
%FINALMONITORINGDEFICIT Unified v7.0.0 mission-deficit scalar.
%
% The score is an auxiliary constraint-ranking quantity, not a Pareto
% objective. See evaluation.missionDeficitComponents for the four formal
% mission components and normalization.
info = evaluation.missionDeficitComponents(ind,cfg);
score = info.total;
end
