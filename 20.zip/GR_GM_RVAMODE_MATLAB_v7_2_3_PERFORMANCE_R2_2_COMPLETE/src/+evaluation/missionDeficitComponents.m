function info = missionDeficitComponents(ind,cfg)
%MISSIONDEFICITCOMPONENTS Unified non-compensating mission deficit.
%
% v7.0.0 uses the four formal monitoring requirements already present in the
% problem definition. The scalar deficit is an epsilon-constraint ranking
% quantity, NOT a sixth Pareto objective.
%
% Components are normalized to [0,1]:
%   d1 : all-target minimum-quality requirement;
%   d2 : aggregate Critical-quality requirement;
%   d3 : all-Critical continuous-observation requirement;
%   d4 : all-Critical LOS requirement.
%
% The total uses a Chebyshev-dominant aggregation. Therefore one badly
% violated component cannot be hidden by three good components. A small
% weighted-average term preserves smooth ranking when the worst deficits tie.

if isempty(ind) || ~isstruct(ind) || ~isfield(ind,'monitorStats')
    info = localEmpty();
    return;
end

Q = localTruePerTarget(ind);
if isempty(Q)
    info = localEmpty();
    return;
end
Q(~isfinite(Q)) = 0;

qReq = max(localCfg(cfg,'monitorMinTargetQuality',0.33),eps);
qPer = min(max((qReq-Q)/qReq,0),1);
qWorst = max(qPer);
qMean = mean(qPer);
qualityBlend = min(max(localCfg(cfg,'missionQualityWorstWeight',0.85),0),1);
qDef = qualityBlend*qWorst + (1-qualityBlend)*qMean;

criticalQ = localCriticalQuality(ind);
criticalReq = max(localCfg(cfg,'monitorCriticalMinQuality',0.42),eps);
criticalDef = min(max((criticalReq-criticalQ)/criticalReq,0),1);

obsDef = 0;
losDef = 0;
obs = inf;
los = inf;
critical = localCriticalIndices(cfg,numel(Q));
if localCfg(cfg,'enableMonitoringGeometryConstraints',true)
    obsReq = max(localCfg(cfg,'monitorCriticalMinObservationLength',180),eps);
    losReq = max(localCfg(cfg,'monitorCriticalMinLOSRatio',0.45),eps);
    obsVec = localObservationVector(ind,numel(Q));
    losVec = localLOSVector(ind,numel(Q));
    if isempty(critical)
        obsCritical = obsVec;
        losCritical = losVec;
    else
        obsCritical = obsVec(critical);
        losCritical = losVec(critical);
    end
    if isempty(obsCritical), obsCritical = 0; end
    if isempty(losCritical), losCritical = 0; end
    obs = min(obsCritical);
    los = min(losCritical);
    obsPer = min(max((obsReq-obsCritical)/obsReq,0),1);
    losPer = min(max((losReq-losCritical)/losReq,0),1);
    geometryBlend = min(max(localCfg(cfg,'missionGeometryWorstWeight',0.90),0),1);
    obsDef = geometryBlend*max(obsPer) + (1-geometryBlend)*mean(obsPer);
    losDef = geometryBlend*max(losPer) + (1-geometryBlend)*mean(losPer);
end

weights = localCfg(cfg,'unifiedMissionDeficitWeights',[0.40 0.15 0.30 0.15]);
weights = reshape(weights,1,[]);
if numel(weights)~=4 || any(~isfinite(weights)) || sum(max(weights,0))<=0
    weights = [0.40 0.15 0.30 0.15];
end
weights = max(weights,0);
weights = weights/max(sum(weights),eps);
components = min(max([qDef criticalDef obsDef losDef],0),1);

rho = min(max(localCfg(cfg,'missionDeficitAverageBlend',0.15),0),1);
worst = max(components);
average = sum(weights.*components);
total = (1-rho)*worst + rho*average;

info.total = min(max(total,0),1);
info.components = components;
info.weights = weights;
info.chebyshev = worst;
info.weightedAverage = average;
info.minimumQualityDeficit = qDef;
info.criticalQualityDeficit = criticalDef;
info.criticalObservationDeficit = obsDef;
info.criticalLOSDeficit = losDef;
info.minimumQuality = min(Q);
info.criticalQuality = criticalQ;
info.minimumCriticalObservationLength = obs;
info.minimumCriticalLOSRatio = los;
info.formalSatisfied = all(components <= ...
    localCfg(cfg,'missionDeficitComponentTolerance',1e-12));
end

function info = localEmpty()
info.total = inf;
info.components = [1 1 1 1];
info.weights = [0.40 0.15 0.30 0.15];
info.chebyshev = 1;
info.weightedAverage = 1;
info.minimumQualityDeficit = 1;
info.criticalQualityDeficit = 1;
info.criticalObservationDeficit = 1;
info.criticalLOSDeficit = 1;
info.minimumQuality = 0;
info.criticalQuality = 0;
info.minimumCriticalObservationLength = 0;
info.minimumCriticalLOSRatio = 0;
info.formalSatisfied = false;
end

function Q = localTruePerTarget(ind)
if isfield(ind,'monitorStats') && isfield(ind.monitorStats,'truePerTarget') && ...
        ~isempty(ind.monitorStats.truePerTarget)
    Q = ind.monitorStats.truePerTarget(:);
elseif isfield(ind,'monitorPerTarget') && ~isempty(ind.monitorPerTarget)
    Q = ind.monitorPerTarget(:);
else
    Q = [];
end
end

function value = localCriticalQuality(ind)
value = 0;
if isfield(ind,'monitorStats')
    if isfield(ind.monitorStats,'trueCriticalQuality') && ...
            isfinite(ind.monitorStats.trueCriticalQuality)
        value = ind.monitorStats.trueCriticalQuality;
    elseif isfield(ind.monitorStats,'criticalQuality') && ...
            isfinite(ind.monitorStats.criticalQuality)
        value = ind.monitorStats.criticalQuality;
    end
end
end

function obs = localObservationVector(ind,M)
obs = zeros(M,1);
if isfield(ind,'monitorStats') && isfield(ind.monitorStats,'observationLength')
    values = ind.monitorStats.observationLength(:);
    n = min(M,numel(values));
    obs(1:n) = values(1:n);
end
obs(~isfinite(obs)) = 0;
end

function los = localLOSVector(ind,M)
los = zeros(M,1);
if isfield(ind,'monitorStats') && isfield(ind.monitorStats,'losRatio')
    values = ind.monitorStats.losRatio(:);
    n = min(M,numel(values));
    los(1:n) = values(1:n);
end
los(~isfinite(los)) = 0;
end

function critical = localCriticalIndices(cfg,M)
critical = [];
if isfield(cfg,'criticalTargetIndices')
    critical = cfg.criticalTargetIndices(:);
    critical = critical(critical>=1 & critical<=M);
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
