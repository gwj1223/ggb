function [quality,perTarget,stats] = monitoringQuality(path,problem,cfg,sampleCache)
%MONITORINGQUALITY True monitoring quality plus a smooth search surrogate.
%
% The returned QUALITY and PERTARGET values are the physical (unfloored)
% monitoring values used by constraints, final archives and reports.
% STATS also contains smooth search qualities that use a small component
% floor only inside the objective function. This preserves selection
% gradients without artificially inflating final monitoring performance.
%
% v6.4.1 performance refinement:
%   * range/height/annulus geometry is evaluated for all targets in one
%     vectorized batch;
%   * all line-of-sight rays are queried from the DEM in one interpolation
%     batch per individual instead of one INTERP2 call per target;
%   * physical definitions and reported metrics are unchanged.

if nargin < 4 || isempty(sampleCache) || ...
        sampleCache.numSamples ~= cfg.monitorCoverageSamples
    sampleCache = evaluation.buildPathSampleCache( ...
        path,problem,cfg.monitorCoverageSamples,false);
end

T = problem.monitorTargets;
M = size(T,1);
points = sampleCache.points;
ground = sampleCache.terrain(:);
numSamples = sampleCache.numSamples;
numSegments = sampleCache.numSegments;
segmentLengths = sampleCache.segmentLengths;
numPoints = size(points,1);

truePerTarget = zeros(M,1);
searchPerTarget = zeros(M,1);
obsLength = zeros(M,1);
losQuality = zeros(M,1);
rawLOSRatio = zeros(M,1);
rangeQuality = zeros(M,1);
heightQuality = zeros(M,1);
durationQuality = zeros(M,1);
instantQuality = zeros(M,1);
annulusGap = zeros(M,1);
coverageDeficit = zeros(M,1);
observationDeficit = zeros(M,1);
visibleValidMatrix = false(numPoints,M);

%% ========================================================================
%  Component exponents and search floor
% =========================================================================
exponents = [cfg.monitorRangeExponent cfg.monitorHeightExponent ...
    cfg.monitorLOSExponent cfg.monitorDurationExponent];
exponents = max(exponents,0);
exponents = exponents/max(sum(exponents),eps);

if isfield(cfg,'monitorSearchComponentFloor')
    searchFloor = cfg.monitorSearchComponentFloor;
elseif isfield(cfg,'monitorComponentFloor')
    searchFloor = cfg.monitorComponentFloor;
else
    searchFloor = 0.01;
end
searchFloor = min(max(searchFloor,eps),0.20);

%% ========================================================================
%  Vectorized target geometry
% =========================================================================
targetX = reshape(T(:,1),1,M);
targetY = reshape(T(:,2),1,M);
desiredR = reshape(T(:,4),1,M);
desiredH = reshape(T(:,5),1,M);

horiz = hypot(points(:,1)-targetX,points(:,2)-targetY);
relH = points(:,3)-ground;

qRangeMatrix = exp(-0.5*((horiz-desiredR)/cfg.monitorRangeSigma).^2);
qHeightMatrix = exp(-0.5*((relH-desiredH)/cfg.monitorHeightSigma).^2);
spatialMeritMatrix = qRangeMatrix.*qHeightMatrix;

lowerRange = cfg.monitorObservationRangeFactor(1)*desiredR;
upperRange = cfg.monitorObservationRangeFactor(2)*desiredR;
pointGap = max(lowerRange-horiz,0)+max(horiz-upperRange,0);
closestGap = min(pointGap,[],1)';

approachScale = localCfg(cfg,'monitorCoverageDeficitScale',desiredR(:));
if isscalar(approachScale)
    approachScale = repmat(approachScale,M,1);
else
    approachScale = reshape(approachScale,[],1);
    if numel(approachScale) ~= M
        approachScale = desiredR(:);
    end
end
qApproach = exp(-closestGap./max(approachScale,eps));

%% ========================================================================
%  Batched line-of-sight evaluation
% =========================================================================
visibleMatrix = true(numPoints,M);
if cfg.enableLineOfSight && cfg.monitorLineOfSightSamples > 2 && M > 0
    if isfield(problem,'monitorTargetTerrain') && ...
            numel(problem.monitorTargetTerrain) >= M
        targetTerrain = reshape(problem.monitorTargetTerrain(1:M),[],1);
    else
        targetTerrain = data.terrainHeight(problem,T(:,1),T(:,2));
        targetTerrain = targetTerrain(:);
    end

    % End points were excluded by the original LOS test, so only build and
    % interpolate the interior ray samples. This is exactly equivalent while
    % reducing DEM queries by 2/L for L line samples.
    alpha = linspace(0,1,cfg.monitorLineOfSightSamples);
    alpha = alpha(2:end-1);

    startX = repmat(points(:,1),M,1);
    startY = repmat(points(:,2),M,1);
    startZ = repmat(points(:,3),M,1);
    endX = repelem(T(:,1),numPoints,1);
    endY = repelem(T(:,2),numPoints,1);
    endZ = repelem(targetTerrain+1,numPoints,1);

    lineX = startX+(endX-startX).*alpha;
    lineY = startY+(endY-startY).*alpha;
    lineZ = startZ+(endZ-startZ).*alpha;

    terrainLOS = data.terrainHeight(problem,lineX,lineY);
    blockedFlat = any(terrainLOS > lineZ,2);
    blockedMatrix = reshape(blockedFlat,numPoints,M);
    visibleMatrix = ~blockedMatrix;
end

%% ========================================================================
%  Per-target physical/search quality summaries
% =========================================================================
for m = 1:M
    qRangeAll = qRangeMatrix(:,m);
    qHeightAll = qHeightMatrix(:,m);
    spatialMerit = spatialMeritMatrix(:,m);
    visible = visibleMatrix(:,m);

    % Select a geometrically useful viewpoint. The floor is used only for
    % this search surrogate; true quality still becomes zero when LOS or
    % duration is genuinely zero.
    visibilitySearch = searchFloor+ ...
        (1-searchFloor)*double(visible);
    coherentMerit = spatialMerit.*visibilitySearch;
    [bestCoherentMerit,bestIndex] = max(coherentMerit);
    if isempty(bestIndex) || bestCoherentMerit <= 0
        qR = 0;
        qH = 0;
    else
        qR = qRangeAll(bestIndex);
        qH = qHeightAll(bestIndex);
    end

    qLOS = sum(spatialMerit.*double(visible))/max(sum(spatialMerit),eps);
    qLOS = min(max(qLOS,0),1);

    useful = horiz(:,m) >= lowerRange(m) & ...
        horiz(:,m) <= upperRange(m) & ...
        qHeightAll >= exp(-0.5);
    visibleUseful = useful & visible;
    visibleValidMatrix(:,m) = visibleUseful;

    validBySegment = reshape(visibleUseful,numSamples,numSegments);
    visibleLength = sum(segmentLengths.*mean(validBySegment,1)');
    qDuration = 1-exp(-visibleLength/ ...
        max(cfg.monitorRequiredObservationLength,eps));

    rawComponents = min(max([qR qH qLOS qDuration],0),1);
    active = exponents > 0;
    if any(active)
        trueTarget = prod(rawComponents(active).^exponents(active));
    else
        trueTarget = 1;
    end

    searchComponents = searchFloor+ ...
        (1-searchFloor)*rawComponents;
    if any(active)
        searchTarget = prod(searchComponents(active).^exponents(active));
    else
        searchTarget = 1;
    end

    truePerTarget(m) = min(max(trueTarget,0),1);
    searchPerTarget(m) = min(max(searchTarget,0),1);
    obsLength(m) = visibleLength;
    losQuality(m) = qLOS;
    rawLOSRatio(m) = mean(visible);
    rangeQuality(m) = qR;
    heightQuality(m) = qH;
    durationQuality(m) = qDuration;
    instantQuality(m) = max(spatialMerit.*double(visible));
    annulusGap(m) = closestGap(m);
    coverageDeficit(m) = 1-qApproach(m);
    observationDeficit(m) = max(0, ...
        cfg.monitorRequiredObservationLength-visibleLength)/ ...
        max(cfg.monitorRequiredObservationLength,eps);
end

%% ========================================================================
%  Aggregate monitoring statistics
% =========================================================================
weights = T(:,3);
quality = sum(weights.*truePerTarget)/max(sum(weights),eps);
searchQuality = sum(weights.*searchPerTarget)/max(sum(weights),eps);

critical = cfg.criticalTargetIndices(:);
critical = critical(critical>=1 & critical<=M);
if isempty(critical)
    criticalQuality = quality;
    searchCriticalQuality = searchQuality;
    if M > 0
        minimumCriticalObservationLength = min(obsLength);
        minimumCriticalLOSRatio = min(losQuality);
    else
        minimumCriticalObservationLength = 0;
        minimumCriticalLOSRatio = 0;
    end
else
    criticalQuality = sum(weights(critical).*truePerTarget(critical))/ ...
        max(sum(weights(critical)),eps);
    searchCriticalQuality = sum(weights(critical).* ...
        searchPerTarget(critical))/max(sum(weights(critical)),eps);
    minimumCriticalObservationLength = min(obsLength(critical));
    minimumCriticalLOSRatio = min(losQuality(critical));
end

if M > 0
    trueDispersion = min(std(truePerTarget,0)/max(quality,eps),1);
    searchDispersion = min(std(searchPerTarget,0)/max(searchQuality,eps),1);
    unionVisible = any(visibleValidMatrix,2);
    unionBySegment = reshape(unionVisible,numSamples,numSegments);
    unionObservationLength = sum(segmentLengths.*mean(unionBySegment,1)');
else
    trueDispersion = 0;
    searchDispersion = 0;
    unionObservationLength = 0;
end

perTarget = truePerTarget;
stats.averageQuality = quality;
stats.minimumQuality = localMinOrZero(truePerTarget);
stats.criticalQuality = criticalQuality;
stats.dispersionPenalty = trueDispersion;
stats.truePerTarget = truePerTarget;
stats.trueAverageQuality = quality;
stats.trueMinimumQuality = localMinOrZero(truePerTarget);
stats.trueCriticalQuality = criticalQuality;
stats.trueDispersionPenalty = trueDispersion;
stats.searchPerTarget = searchPerTarget;
stats.searchAverageQuality = searchQuality;
stats.searchMinimumQuality = localMinOrZero(searchPerTarget);
stats.searchCriticalQuality = searchCriticalQuality;
stats.searchDispersionPenalty = searchDispersion;
stats.observationLength = obsLength;
stats.losRatio = losQuality;
stats.rawLOSRatio = rawLOSRatio;
stats.rangeQuality = rangeQuality;
stats.heightQuality = heightQuality;
stats.durationQuality = durationQuality;
stats.instantQuality = instantQuality;
stats.annulusGap = annulusGap;
stats.coverageDeficit = coverageDeficit;
stats.observationDeficit = observationDeficit;
stats.worstCoverageDeficit = localMaxOrZero(coverageDeficit);
stats.worstObservationDeficit = localMaxOrZero(observationDeficit);
stats.unionObservationLength = unionObservationLength;
stats.totalTargetObservationLength = sum(obsLength);
stats.minimumCriticalObservationLength = minimumCriticalObservationLength;
stats.minimumCriticalLOSRatio = minimumCriticalLOSRatio;
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end

function value = localMinOrZero(x)
if isempty(x), value = 0; else, value = min(x); end
end

function value = localMaxOrZero(x)
if isempty(x), value = 0; else, value = max(x); end
end
