function sample = sampleSegmentTerrainAdaptive(a,b,problem,cfg)
%SAMPLESEGMENTTERRAINADAPTIVE Shared physical-distance terrain sampler.
%
% v7.0.5 single source of truth for hard local-AGL sampling. A3 dense
% reachability, segment clearance repair, and final constraint evaluation use
% the same horizontal spacing and per-segment sample cap.
%
% a,b may be 1-by-2 XY points or 1-by-3 XYZ points. The returned t and
% terrain arrays always include both endpoints.

a = reshape(a,1,[]);
b = reshape(b,1,[]);
if numel(a) < 2 || numel(b) < 2 || any(~isfinite(a(1:2))) || ...
        any(~isfinite(b(1:2)))
    error('evaluation:InvalidTerrainSampleSegment', ...
        'Segment endpoints must contain finite XY coordinates.');
end
step = max(1,localCfg(cfg,'aglConstraintSampleStep_m',15));
maxSamples = max(3,round(localCfg(cfg,'aglConstraintMaxSamplesPerSegment',96)));
horizontal = norm(b(1:2)-a(1:2));
n = min(maxSamples,max(2,ceil(horizontal/step)+1));
t = linspace(0,1,n)';
xy = a(1:2)+t.*(b(1:2)-a(1:2));
terrain = data.terrainHeight(problem,xy(:,1),xy(:,2));

sample.t = t;
sample.xy = xy;
sample.terrain = terrain(:);
sample.horizontalLength = horizontal;
sample.numSamples = n;
if n>1
    sample.maximumSpacing_m = horizontal/(n-1);
else
    sample.maximumSpacing_m = 0;
end
if numel(a)>=3 && numel(b)>=3 && isfinite(a(3)) && isfinite(b(3))
    sample.z = a(3)+t.*(b(3)-a(3));
    sample.points = [xy sample.z];
else
    sample.z = [];
    sample.points = xy;
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
