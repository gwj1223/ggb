function thresholds = currentMonitoringThresholds(generation,cfg)
%CURRENTMONITORINGTHRESHOLDS Runtime monitoring schedule.
%
% v7.0.0 multi-UAV runs use a synchronized three-stage mission schedule:
%   exploration : static feasibility + five objectives only;
%   formation   : unified mission-deficit epsilon shrinks monotonically;
%   formal      : epsilon=0 and all four formal monitoring requirements are
%                 committed together.
% Legacy configurations retain the historical component-threshold ramp.

if isfield(cfg,'runtimeMonitoringMinimumThreshold') && ...
        isfield(cfg,'runtimeMonitoringCriticalThreshold')
    thresholds.minimum = cfg.runtimeMonitoringMinimumThreshold;
    thresholds.critical = cfg.runtimeMonitoringCriticalThreshold;
    thresholds.observationLength = ...
        localField(cfg,'runtimeMonitoringObservationLengthThreshold',0);
    thresholds.losRatio = ...
        localField(cfg,'runtimeMonitoringLOSRatioThreshold',0);
    thresholds.progress = ...
        localField(cfg,'runtimeMonitoringThresholdProgress',0);
    thresholds.missionDeficitEpsilon = ...
        localField(cfg,'runtimeMissionDeficitEpsilon',1);
    thresholds.missionStage = ...
        string(localField(cfg,'runtimeMissionStage','legacy'));
    return;
end

if localField(cfg,'enableUnifiedMissionDeficit',false)
    thresholds = localUnifiedSchedule(generation,cfg);
    return;
end

% Legacy schedule retained for synthetic/single-UAV regression tests.
if ~cfg.enableMonitoringConstraint
    progress = 0;
elseif ~isfield(cfg,'enableMonitoringConstraintRamp') || ...
        ~cfg.enableMonitoringConstraintRamp
    progress = 1;
elseif generation < cfg.monitorConstraintStartGeneration
    progress = 0;
else
    progress = (generation-cfg.monitorConstraintStartGeneration+1)/ ...
        max(cfg.monitorConstraintRampGenerations,1);
    progress = min(max(progress,0),1)^2;
end
thresholds.minimum = progress*cfg.monitorMinTargetQuality;
thresholds.critical = progress*cfg.monitorCriticalMinQuality;
if cfg.enableMonitoringGeometryConstraints
    thresholds.observationLength = ...
        progress*cfg.monitorCriticalMinObservationLength;
    thresholds.losRatio = progress*cfg.monitorCriticalMinLOSRatio;
else
    thresholds.observationLength = 0;
    thresholds.losRatio = 0;
end
thresholds.progress = progress;
thresholds.missionDeficitEpsilon = NaN;
thresholds.missionStage = "legacy";
end

function thresholds = localUnifiedSchedule(generation,cfg)
startGen = max(1,round(localField(cfg,'missionFormationStartGeneration',30)));
formalGen = max(startGen+1,round(localField(cfg,'missionFormalStartGeneration',90)));
initialEpsilon = min(max(localField(cfg,'missionDeficitInitialEpsilon',1.0),0),1);

if ~localField(cfg,'enableMonitoringConstraint',true)
    stage = "formal";
    progress = 1;
    epsilonD = 0;
elseif generation < startGen
    stage = "exploration";
    progress = 0;
    epsilonD = 1;
elseif generation < formalGen
    stage = "formation";
    progress = (generation-startGen)/max(formalGen-startGen,1);
    progress = min(max(progress,0),1);
    epsilonD = initialEpsilon*(1-progress);
else
    stage = "formal";
    progress = 1;
    epsilonD = 0;
end

% Before the formal stage the component thresholds are deliberately zero.
% Mission pressure is applied only through the unified epsilon deficit. This
% prevents one component from reaching its final value while another remains
% disabled for tens of generations.
if stage=="formal"
    thresholds.minimum = cfg.monitorMinTargetQuality;
    thresholds.critical = cfg.monitorCriticalMinQuality;
    if cfg.enableMonitoringGeometryConstraints
        thresholds.observationLength = cfg.monitorCriticalMinObservationLength;
        thresholds.losRatio = cfg.monitorCriticalMinLOSRatio;
    else
        thresholds.observationLength = 0;
        thresholds.losRatio = 0;
    end
else
    thresholds.minimum = 0;
    thresholds.critical = 0;
    thresholds.observationLength = 0;
    thresholds.losRatio = 0;
end
thresholds.progress = progress;
thresholds.missionDeficitEpsilon = epsilonD;
thresholds.missionStage = stage;
end

function value = localField(s,name,defaultValue)
if isfield(s,name), value = s.(name); else, value = defaultValue; end
end
