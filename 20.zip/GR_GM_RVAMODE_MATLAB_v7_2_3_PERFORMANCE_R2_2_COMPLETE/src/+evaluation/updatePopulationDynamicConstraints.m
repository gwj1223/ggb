function pop = updatePopulationDynamicConstraints(pop,cfg,generation,thresholds)
%UPDATEPOPULATIONDYNAMICCONSTRAINTS Cheap threshold-only population update.
if nargin < 4, thresholds = []; end
for i = 1:numel(pop)
    pop(i) = evaluation.updateDynamicConstraints( ...
        pop(i),cfg,generation,thresholds);
end
end
