function [state,changed,diag] = updateMonitoringThresholdState( ...
    state,feasibleRate,generation,cfg,pop)
%UPDATEMONITORINGTHRESHOLDSTATE Predictive feedback with final-stage snap.
%
% Proposed thresholds are checked against cached true monitoring metrics
% before commitment. When most of the population already satisfies all
% final requirements for several consecutive generations, the controller
% commits the complete final threshold vector in one step.
%
% Action codes: -1 rollback, 0 hold, 1 slow increase, 2 increase,
%               3 final, 4 snap final.

if nargin < 5
    pop = [];
end
old = [state.minimum state.critical ...
    state.observationLength state.losRatio];
state.previousFeasibleRate = feasibleRate;
state.lastActionCode = 0;
state.lastAction = 'hold';
state.lastPredictedFeasibleRate = feasibleRate;
diag.currentRate = feasibleRate;
diag.predictedFullRate = NaN;
diag.predictedSlowRate = NaN;
diag.predictedFinalRate = NaN;
diag.committedRate = feasibleRate;

if feasibleRate < cfg.monitorRampRecoveryRate
    state.lowFeasibleStreak = state.lowFeasibleStreak+1;
else
    state.lowFeasibleStreak = 0;
end

if ~cfg.enableMonitoringConstraint
    state.finalReached = true;
    state.progress = 1;
    changed = false;
    return;
end

if ~isfield(cfg,'enableFeasibilityFeedbackThreshold') || ...
        ~cfg.enableFeasibilityFeedbackThreshold
    oldEpsilon = localStateField(state,'missionDeficitEpsilon',NaN);
    oldStage = string(localStateField(state,'missionStage','legacy'));
    th = evaluation.currentMonitoringThresholds(generation,cfg);
    state.minimum = th.minimum;
    state.critical = th.critical;
    state.observationLength = th.observationLength;
    state.losRatio = th.losRatio;
    state.progress = th.progress;
    if isfield(th,'missionDeficitEpsilon')
        state.missionDeficitEpsilon = th.missionDeficitEpsilon;
    end
    if isfield(th,'missionStage')
        state.missionStage = char(th.missionStage);
    end
    state.finalReached = th.progress >= 1-cfg.monitorThresholdTolerance;
    if localCfg(cfg,'enableUnifiedMissionDeficit',false)
        if ~isempty(pop)
            finalThresholds = localThresholdStruct([state.finalMinimum ...
                state.finalCritical state.finalObservationLength state.finalLOSRatio]);
            [finalRate,~,~] = evaluation.predictMonitoringFeasibleRate( ...
                pop,finalThresholds,cfg);
            state.finalFeasibleRate = finalRate;
            diag.predictedFinalRate = finalRate;
        end
        switch string(state.missionStage)
            case "exploration"
                state.lastActionCode = 5;
                state.lastAction = 'mission_exploration';
            case "formation"
                state.lastActionCode = 6;
                state.lastAction = 'mission_formation';
            otherwise
                state.lastActionCode = 3;
                state.lastAction = 'formal';
        end
    end
    if state.finalReached && ~isfinite(state.finalReachedGeneration)
        state.finalReachedGeneration = generation;
    end
    changed = localChanged(old,state,cfg) || ...
        abs(state.missionDeficitEpsilon-oldEpsilon)> ...
            localCfg(cfg,'missionDeficitScheduleTolerance',1e-12) || ...
        string(state.missionStage)~=oldStage;
    if changed
        state.updateCount = state.updateCount+1;
        state.lastUpdateGeneration = generation;
    end
    return;
end

finals = [state.finalMinimum state.finalCritical ...
    state.finalObservationLength state.finalLOSRatio];
finalThresholds = localThresholdStruct(finals);
if ~isempty(pop)
    [finalRate,~,~] = evaluation.predictMonitoringFeasibleRate( ...
        pop,finalThresholds,cfg);
else
    finalRate = NaN;
end
diag.predictedFinalRate = finalRate;
state.finalFeasibleRate = finalRate;
if isfinite(finalRate) && finalRate >= cfg.snapFinalFeasibleRate
    state.finalFeasibleStreak = state.finalFeasibleStreak+1;
else
    state.finalFeasibleStreak = 0;
end

if generation < cfg.monitorConstraintStartGeneration
    changed = false;
    return;
end

% Fast commitment is checked every generation, not only on the ordinary
% threshold-update cadence.
if isfield(cfg,'enableSnapFinalThreshold') && ...
        cfg.enableSnapFinalThreshold && ~state.finalReached && ...
        state.finalFeasibleStreak >= cfg.snapFinalPatience
    state.minimum = state.finalMinimum;
    state.critical = state.finalCritical;
    state.observationLength = state.finalObservationLength;
    state.losRatio = state.finalLOSRatio;
    state.stableMinimum = state.minimum;
    state.stableCritical = state.critical;
    state.stableObservationLength = state.observationLength;
    state.stableLOSRatio = state.losRatio;
    state.progress = 1;
    state.finalReached = true;
    state.finalReachedGeneration = generation;
    state.lastActionCode = 4;
    state.lastAction = 'snap_final';
    state.lastPredictedFeasibleRate = finalRate;
    state.snapFinalCount = state.snapFinalCount+1;
    state.updateCount = state.updateCount+1;
    state.lastUpdateGeneration = generation;
    diag.committedRate = finalRate;
    changed = localChanged(old,state,cfg);
    return;
end

interval = max(1,round(cfg.monitorThresholdUpdateInterval));
if mod(generation-cfg.monitorConstraintStartGeneration,interval) ~= 0
    changed = false;
    return;
end
if state.finalReached
    state.lastActionCode = 3;
    state.lastAction = 'final';
    changed = false;
    return;
end

steps = [cfg.monitorThresholdStepMinimum, ...
    cfg.monitorThresholdStepCritical, ...
    cfg.monitorThresholdStepObservationLength, ...
    cfg.monitorThresholdStepLOSRatio];
values = [state.minimum state.critical ...
    state.observationLength state.losRatio];
stable = [state.stableMinimum state.stableCritical ...
    state.stableObservationLength state.stableLOSRatio];

if feasibleRate >= cfg.monitorRampMinFeasibleRate
    stable = values;
end

useComponentwise = isfield(cfg,'monitorComponentwiseThresholdUpdate') && ...
    cfg.monitorComponentwiseThresholdUpdate && ~isempty(pop);
if useComponentwise
    [proposal,proposalCode,proposalRate,fullRate,slowRate] = ...
        localComponentwiseProposal(values,finals,steps,pop,cfg);
    diag.predictedFullRate = fullRate;
    diag.predictedSlowRate = slowRate;
    if proposalCode>0 && feasibleRate >= cfg.monitorRampSlowFeasibleRate
        values = proposal;
        state.lastActionCode = proposalCode;
        if proposalCode==2
            state.lastAction = 'component_increase';
        else
            state.lastAction = 'component_slow_increase';
        end
        diag.committedRate = proposalRate;
    elseif feasibleRate < cfg.monitorRampRecoveryRate && ...
            state.lowFeasibleStreak >= cfg.monitorRollbackPatience && ...
            any(values > stable+cfg.monitorThresholdTolerance)
        values = max(stable,values-cfg.monitorThresholdRollbackFactor*steps);
        state.rollbackCount = state.rollbackCount+1;
        state.lowFeasibleStreak = 0;
        state.lastActionCode = -1;
        state.lastAction = 'rollback';
        diag.committedRate = evaluation.predictMonitoringFeasibleRate( ...
            pop,localThresholdStruct(values),cfg);
    else
        state.lastAction = 'predict_hold';
    end
else
    fullCandidate = min(finals,values+steps);
    slowCandidate = min(finals,values+ ...
        cfg.monitorThresholdSlowFactor*steps);
    if isempty(pop)
        predictedFull = feasibleRate;
        predictedSlow = feasibleRate;
    else
        predictedFull = evaluation.predictMonitoringFeasibleRate( ...
            pop,localThresholdStruct(fullCandidate),cfg);
        predictedSlow = evaluation.predictMonitoringFeasibleRate( ...
            pop,localThresholdStruct(slowCandidate),cfg);
    end
    diag.predictedFullRate = predictedFull;
    diag.predictedSlowRate = predictedSlow;

    if feasibleRate >= cfg.monitorRampMinFeasibleRate
        if predictedFull >= cfg.monitorPredictiveMinFeasibleRate
            values = fullCandidate;
            state.lastActionCode = 2;
            state.lastAction = 'increase';
            diag.committedRate = predictedFull;
        elseif predictedSlow >= cfg.monitorPredictiveSlowFeasibleRate
            values = slowCandidate;
            state.lastActionCode = 1;
            state.lastAction = 'slow_increase';
            diag.committedRate = predictedSlow;
        else
            state.lastAction = 'predict_hold';
        end
    elseif feasibleRate >= cfg.monitorRampSlowFeasibleRate
        if predictedSlow >= cfg.monitorPredictiveSlowFeasibleRate
            values = slowCandidate;
            state.lastActionCode = 1;
            state.lastAction = 'slow_increase';
            diag.committedRate = predictedSlow;
        else
            state.lastAction = 'predict_hold';
        end
    elseif feasibleRate < cfg.monitorRampRecoveryRate && ...
            state.lowFeasibleStreak >= cfg.monitorRollbackPatience && ...
            any(values > stable+cfg.monitorThresholdTolerance)
        values = max(stable,values-cfg.monitorThresholdRollbackFactor*steps);
        state.rollbackCount = state.rollbackCount+1;
        state.lowFeasibleStreak = 0;
        state.lastActionCode = -1;
        state.lastAction = 'rollback';
        if ~isempty(pop)
            diag.committedRate = evaluation.predictMonitoringFeasibleRate( ...
                pop,localThresholdStruct(values),cfg);
        end
    end
end
values = max(values,0);

state.minimum = values(1);
state.critical = values(2);
state.observationLength = values(3);
state.losRatio = values(4);
state.stableMinimum = stable(1);
state.stableCritical = stable(2);
state.stableObservationLength = stable(3);
state.stableLOSRatio = stable(4);
state.lastPredictedFeasibleRate = diag.committedRate;
progress = arrayfun(@localProgress,values,finals);
state.progress = mean(progress);
state.finalReached = all(values >= finals-cfg.monitorThresholdTolerance);
if state.finalReached
    state.minimum = state.finalMinimum;
    state.critical = state.finalCritical;
    state.observationLength = state.finalObservationLength;
    state.losRatio = state.finalLOSRatio;
    state.progress = 1;
    state.lastActionCode = 3;
    state.lastAction = 'final';
    if ~isfinite(state.finalReachedGeneration)
        state.finalReachedGeneration = generation;
    end
end
changed = localChanged(old,state,cfg);
if changed
    state.updateCount = state.updateCount+1;
    state.lastUpdateGeneration = generation;
end
end

function [candidate,code,rate,fullRate,slowRate] = ...
    localComponentwiseProposal(values,finals,steps,pop,cfg)
% Greedily commit only dimensions supported by the current population.
% Geometry and critical-quality thresholds can therefore progress while an
% uncovered noncritical target temporarily blocks the minimum-quality step.
candidate = values;
code = 0;
rate = evaluation.predictMonitoringFeasibleRate( ...
    pop,localThresholdStruct(candidate),cfg);
fullRate = NaN;
slowRate = NaN;
priority = [3 4 2 1];
for j = priority
    if candidate(j) >= finals(j)-cfg.monitorThresholdTolerance
        continue;
    end
    full = candidate;
    full(j) = min(finals(j),candidate(j)+steps(j));
    trialRate = evaluation.predictMonitoringFeasibleRate( ...
        pop,localThresholdStruct(full),cfg);
    fullRate = trialRate;
    if trialRate >= cfg.monitorPredictiveMinFeasibleRate
        candidate = full;
        rate = trialRate;
        code = 2;
        continue;
    end
    slow = candidate;
    slow(j) = min(finals(j),candidate(j)+ ...
        cfg.monitorThresholdSlowFactor*steps(j));
    trialRate = evaluation.predictMonitoringFeasibleRate( ...
        pop,localThresholdStruct(slow),cfg);
    slowRate = trialRate;
    if trialRate >= cfg.monitorPredictiveSlowFeasibleRate
        candidate = slow;
        rate = trialRate;
        if code==0, code = 1; end
    end
end
if ~isfinite(fullRate), fullRate = rate; end
if ~isfinite(slowRate), slowRate = rate; end
end

function thresholds = localThresholdStruct(values)
thresholds.minimum = values(1);
thresholds.critical = values(2);
thresholds.observationLength = values(3);
thresholds.losRatio = values(4);
end

function tf = localChanged(old,state,cfg)
new = [state.minimum state.critical ...
    state.observationLength state.losRatio];
tf = any(abs(new-old)>cfg.monitorThresholdTolerance);
end

function p = localProgress(value,finalValue)
if finalValue <= eps
    p = 1;
else
    p = min(max(value/finalValue,0),1);
end
end

function value = localStateField(state,name,defaultValue)
if isfield(state,name), value = state.(name); else, value = defaultValue; end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
