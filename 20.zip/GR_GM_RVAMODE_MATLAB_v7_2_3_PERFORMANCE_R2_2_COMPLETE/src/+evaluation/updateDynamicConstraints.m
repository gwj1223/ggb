function ind = updateDynamicConstraints(ind,cfg,generation,thresholds)
%UPDATEDYNAMICCONSTRAINTS Update monitoring-dependent constraint values.
%
% v7.1.0 keeps the formal three-tier constraint semantics encoded in CV,
% while search-time mission-band selection is handled separately by
% selection.missionBandState/environmentalSelection.  The formal meaning of
% ind.feasible is therefore unchanged.
%
% Legacy configurations retain the historical component-wise CV logic.
if nargin < 3 || isempty(generation), generation = cfg.maxGenerations; end
if nargin < 4 || isempty(thresholds)
    thresholds = evaluation.currentMonitoringThresholds(generation,cfg);
end

if localCfg(cfg,'enableUnifiedMissionDeficit',false)
    ind = localUnifiedUpdate(ind,cfg,thresholds);
    return;
end

% -------------------------------------------------------------------------
% Legacy component-wise monitoring CV.
monitorMinViolation = 0;
monitorCriticalViolation = 0;
monitorObservationViolation = 0;
monitorLOSViolation = 0;
if cfg.enableMonitoringConstraint
    truePerTarget = ind.monitorPerTarget;
    trueCritical = ind.monitorStats.criticalQuality;
    if isfield(ind.monitorStats,'truePerTarget')
        truePerTarget = ind.monitorStats.truePerTarget;
    end
    if isfield(ind.monitorStats,'trueCriticalQuality')
        trueCritical = ind.monitorStats.trueCriticalQuality;
    end
    monitorMinViolation = sum(max(0, ...
        thresholds.minimum-truePerTarget));
    monitorCriticalViolation = max(0, ...
        thresholds.critical-trueCritical);
    if cfg.enableMonitoringGeometryConstraints
        critical = cfg.criticalTargetIndices(:);
        critical = critical(critical>=1 & ...
            critical<=numel(ind.monitorPerTarget));
        if ~isempty(critical)
            monitorObservationViolation = sum(max(0, ...
                thresholds.observationLength- ...
                ind.monitorStats.observationLength(critical)));
            monitorLOSViolation = sum(max(0, ...
                thresholds.losRatio-ind.monitorStats.losRatio(critical)));
        end
    end
end

ind.violation.monitorMinimum = monitorMinViolation;
ind.violation.monitorCritical = monitorCriticalViolation;
ind.violation.monitorObservationLength = monitorObservationViolation;
ind.violation.monitorLOSRatio = monitorLOSViolation;
ind.violation.monitoring = monitorMinViolation+monitorCriticalViolation+ ...
    monitorObservationViolation+monitorLOSViolation;
if ~isfield(ind,'staticCV') || ~isfinite(ind.staticCV)
    ind.staticCV = ind.violation.collision/max(cfg.cvScaleCollision,eps)+ ...
        ind.violation.clearance/max(cfg.cvScaleClearance,eps)+ ...
        ind.violation.climb/max(cfg.cvScaleClimb,eps)+ ...
        ind.violation.turn/max(cfg.cvScaleTurn,eps)+ ...
        ind.violation.energy/max(cfg.cvScaleEnergy,eps);
end
ind.cv = ind.staticCV+ ...
    monitorMinViolation/max(cfg.cvScaleMonitoring,eps)+ ...
    monitorCriticalViolation/max(cfg.cvScaleMonitoring,eps)+ ...
    monitorObservationViolation/max(cfg.cvScaleObservationLength,eps)+ ...
    monitorLOSViolation/max(cfg.cvScaleLOSRatio,eps);
tol = localCfg(cfg,'constraintTolerance',1e-8);
ind.feasible = ind.cv<=tol;
ind.staticFeasible = ind.staticCV<=tol;
ind.missionScheduleFeasible = ind.feasible;
if ~isfield(ind,'formalMissionSatisfied')
    ind.formalMissionSatisfied = false;
end
ind.monitorThresholds = thresholds;
end

function ind = localUnifiedUpdate(ind,cfg,thresholds)
info = evaluation.missionDeficitComponents(ind,cfg);
if ~isfield(ind,'staticCV') || ~isfinite(ind.staticCV)
    ind.staticCV = ind.violation.collision/max(cfg.cvScaleCollision,eps)+ ...
        ind.violation.clearance/max(cfg.cvScaleClearance,eps)+ ...
        ind.violation.climb/max(cfg.cvScaleClimb,eps)+ ...
        ind.violation.turn/max(cfg.cvScaleTurn,eps)+ ...
        ind.violation.energy/max(cfg.cvScaleEnergy,eps);
end

% An explicit threshold argument has precedence. This is essential for the
% separate final archive: it must always be evaluated at epsilon=0 even while
% the live population is still in exploration/formation.
if isfield(thresholds,'missionDeficitEpsilon') && ...
        isfinite(thresholds.missionDeficitEpsilon)
    epsilonD = thresholds.missionDeficitEpsilon;
else
    epsilonD = localCfg(cfg,'runtimeMissionDeficitEpsilon',1);
end
epsilonD = min(max(epsilonD,0),1);
missionExcess = max(0,info.total-epsilonD);
tol = localCfg(cfg,'constraintTolerance',1e-8);
staticOK = ind.staticCV<=tol;
missionOK = missionExcess<=localCfg(cfg,'missionDeficitScheduleTolerance',1e-12);

% Preserve physically interpretable raw formal deficits for diagnostics.
Q = localTruePerTarget(ind);
qReq = localCfg(cfg,'monitorMinTargetQuality',0.33);
monitorMinViolation = sum(max(0,qReq-Q));
criticalQ = localTrueCriticalQuality(ind);
monitorCriticalViolation = max(0, ...
    localCfg(cfg,'monitorCriticalMinQuality',0.42)-criticalQ);
monitorObservationViolation = 0;
monitorLOSViolation = 0;
critical = cfg.criticalTargetIndices(:);
critical = critical(critical>=1 & critical<=numel(Q));
if localCfg(cfg,'enableMonitoringGeometryConstraints',true) && ~isempty(critical)
    monitorObservationViolation = sum(max(0, ...
        localCfg(cfg,'monitorCriticalMinObservationLength',180)- ...
        ind.monitorStats.observationLength(critical)));
    monitorLOSViolation = sum(max(0, ...
        localCfg(cfg,'monitorCriticalMinLOSRatio',0.45)- ...
        ind.monitorStats.losRatio(critical)));
end
ind.violation.monitorMinimum = monitorMinViolation;
ind.violation.monitorCritical = monitorCriticalViolation;
ind.violation.monitorObservationLength = monitorObservationViolation;
ind.violation.monitorLOSRatio = monitorLOSViolation;
ind.violation.monitoring = missionExcess;

% Encode the strict hierarchy without changing Deb/reference-vector code.
% Unified mission deficit is bounded by 1. Any static violation receives an
% offset >1, so a flight-infeasible path can never outrank a static-feasible
% mission-forming path merely because its mission metrics look good.
staticTierOffset = max(1,localCfg(cfg,'missionStaticViolationTierOffset',1));
if ~staticOK
    ind.cv = staticTierOffset+max(ind.staticCV,0);
    ind.feasible = false;
    ind.selectionTier = 3;
elseif ~missionOK
    ind.cv = missionExcess;
    ind.feasible = false;
    ind.selectionTier = 2;
else
    ind.cv = 0;
    ind.feasible = true;
    ind.selectionTier = 1;
end

% v7.1.0 exposes the physical, scheduled-mission, and formal semantics as
% separate fields.  searchAdmissible is deliberately NOT stored here because
% it is population-relative and is computed by selection.missionBandState.
ind.staticFeasible = staticOK;
ind.missionScheduleFeasible = staticOK && missionOK;
ind.missionDeficit = info.total;
ind.missionDeficitComponents = info.components;
ind.missionDeficitEpsilon = epsilonD;
ind.missionExcess = missionExcess;
ind.formalMissionSatisfied = info.formalSatisfied;
ind.monitorThresholds = thresholds;
end

function Q = localTruePerTarget(ind)
if isfield(ind,'monitorStats') && isfield(ind.monitorStats,'truePerTarget')
    Q = ind.monitorStats.truePerTarget(:);
else
    Q = ind.monitorPerTarget(:);
end
Q(~isfinite(Q)) = 0;
end

function value = localTrueCriticalQuality(ind)
if isfield(ind,'monitorStats') && ...
        isfield(ind.monitorStats,'trueCriticalQuality') && ...
        isfinite(ind.monitorStats.trueCriticalQuality)
    value = ind.monitorStats.trueCriticalQuality;
else
    value = ind.monitorStats.criticalQuality;
end
if ~isfinite(value), value = 0; end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
