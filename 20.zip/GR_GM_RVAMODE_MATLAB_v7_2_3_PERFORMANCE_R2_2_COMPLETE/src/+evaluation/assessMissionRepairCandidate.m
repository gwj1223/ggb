function assessment = assessMissionRepairCandidate(trial,base,targetIndex,cfg,generation)
%ASSESSMISSIONREPAIRCANDIDATE Stage-aware target-progress gate for unified A3.
%
% v7.1.1 keeps the external A3 contract monotone in global Mission Deficit,
% but replaces the all-stage "just crossed the line = permanently frozen"
% rule with stage-aware mission protection:
%   - formation: hysteretic Q/Critical-Q/Obs/LOS protection;
%   - formal: the historical strict formal protection.
%
% Formal mission thresholds are unchanged. Mission Deficit remains a
% constraint-ranking quantity, not a sixth Pareto objective.

if nargin < 5 || isempty(generation)
    % Backward-compatible direct callers retain the historical strict policy.
    generation = localCfg(cfg,'missionFormalStartGeneration',100);
end

assessment = struct( ...
    'eligible',false, ...
    'reason','invalid', ...
    'targetGain',-inf, ...
    'baseTargetDeficit',inf, ...
    'trialTargetDeficit',inf, ...
    'baseTotalDeficit',inf, ...
    'trialTotalDeficit',inf, ...
    'protection',evaluation.assessMissionProtection([],[],cfg,generation));

if isempty(trial) || isempty(base) || ~isstruct(trial) || ~isstruct(base)
    return;
end
if ~localStaticFeasible(trial,cfg)
    assessment.reason = 'static';
    return;
end

baseInfo = evaluation.missionDeficitComponents(base,cfg);
trialInfo = evaluation.missionDeficitComponents(trial,cfg);
assessment.baseTotalDeficit = baseInfo.total;
assessment.trialTotalDeficit = trialInfo.total;
if ~isfinite(baseInfo.total) || ~isfinite(trialInfo.total)
    assessment.reason = 'invalid';
    return;
end

% External A3 write-back remains globally monotone. v7.1.1 changes only the
% local protection policy, not this global Mission Deficit guard.
nonRegressionTol = max(0,localCfg(cfg, ...
    'missionRepairGlobalNonRegressionTolerance',1e-10));
if trialInfo.total > baseInfo.total + nonRegressionTol
    assessment.reason = 'global_regression';
    return;
end

protection = evaluation.assessMissionProtection(base,trial,cfg,generation);
assessment.protection = protection;
if ~protection.allowed
    assessment.reason = protection.reason;
    return;
end

baseTargetInfo = evaluation.missionRepairTargetDeficits(base,cfg);
trialTargetInfo = evaluation.missionRepairTargetDeficits(trial,cfg);
if targetIndex<1 || targetIndex>numel(baseTargetInfo.total) || ...
        targetIndex>numel(trialTargetInfo.total)
    assessment.reason = 'invalid';
    return;
end
assessment.baseTargetDeficit = baseTargetInfo.total(targetIndex);
assessment.trialTargetDeficit = trialTargetInfo.total(targetIndex);
assessment.targetGain = assessment.baseTargetDeficit- ...
    assessment.trialTargetDeficit;
minTargetGain = max(0,localCfg(cfg,'missionRepairMinTargetDeficitGain',1e-3));
if ~isfinite(assessment.targetGain) || assessment.targetGain < minTargetGain
    assessment.reason = 'target_no_gain';
    return;
end

assessment.eligible = true;
assessment.reason = 'accepted';
end

function tf = localStaticFeasible(ind,cfg)
tol = localCfg(cfg,'constraintTolerance',1e-8);
tf = isfield(ind,'staticCV') && isfinite(ind.staticCV) && ind.staticCV<=tol;
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
