function n = obstacleHits(problem,samples)
n=0;
for j=1:size(problem.obstacles,1)
    o=problem.obstacles(j,:);
    inside=(samples(:,1)-o(1)).^2+(samples(:,2)-o(2)).^2<=o(3)^2 & samples(:,3)<=o(4);
    n=n+sum(inside);
end
end
