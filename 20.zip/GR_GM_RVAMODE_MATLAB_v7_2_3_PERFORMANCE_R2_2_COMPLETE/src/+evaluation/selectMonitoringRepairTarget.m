function targetIndex = selectMonitoringRepairTarget(monitorStats,cfg)
%SELECTMONITORINGREPAIRTARGET Target with largest canonical A3 urgency.
%
% Urgency is computed exclusively by missionRepairTargetDeficits so target
% selection and repair acceptance cannot drift into different formulas.

info = evaluation.missionRepairTargetDeficits(monitorStats,cfg);
score = info.total(:);
Q = info.trueQuality(:);
M = numel(score);
if M==0
    targetIndex = 1;
    return;
end

best = max(score);
candidates = find(abs(score-best)<=1e-12);
if numel(candidates)>1
    [~,q] = min(Q(candidates));
    candidates = candidates(Q(candidates)<=Q(candidates(q))+1e-12);
end
if numel(candidates)>1 && numel(info.searchQuality)>=M
    searchQ = info.searchQuality(:);
    [~,q] = min(searchQ(candidates));
    targetIndex = candidates(q);
else
    targetIndex = candidates(1);
end
end
