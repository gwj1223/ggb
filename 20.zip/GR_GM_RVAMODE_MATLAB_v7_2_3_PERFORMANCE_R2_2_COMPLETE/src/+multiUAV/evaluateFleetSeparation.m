function separation = evaluateFleetSeparation(paths,launchDelays,cfg)
%EVALUATEFLEETSEPARATION Time-synchronize paths and measure 3-D separation.
%
% Vehicles are considered active only from launch until arrival. This avoids
% treating parked vehicles at the common base as airborne collisions.

K = numel(paths);
launchDelays = launchDelays(:);
if numel(launchDelays) ~= K
    error('multiUAV:LaunchDelaySize', ...
        'Expected one launch delay per UAV.');
end
speed = cfg.multiUAVCruiseSpeed;
dt = cfg.multiUAVSeparationTimeStep;

pathLength = zeros(K,1);
duration = zeros(K,1);
waypointTimes = cell(K,1);
for k = 1:K
    p = paths{k};
    if isempty(p) || size(p,2) ~= 3
        error('multiUAV:InvalidPath','UAV %d path must be N-by-3.',k);
    end
    seg = vecnorm(diff(p,1,1),2,2);
    cumulative = [0;cumsum(seg)];
    pathLength(k) = cumulative(end);
    duration(k) = pathLength(k)/max(speed,eps);
    waypointTimes{k} = launchDelays(k)+cumulative/max(speed,eps);
end
endTimes = launchDelays+duration;
missionEnd = max(endTimes);
time = (0:dt:missionEnd)';
if isempty(time) || time(end) < missionEnd
    time(end+1,1) = missionEnd;
end
Nt = numel(time);
positions = nan(Nt,3,K);
active = false(Nt,K);

for k = 1:K
    tWay = waypointTimes{k};
    p = paths{k};
    [tUnique,ia] = unique(tWay,'stable');
    pUnique = p(ia,:);
    mask = time >= tUnique(1)-eps & time <= tUnique(end)+eps;
    active(mask,k) = true;
    if numel(tUnique) == 1
        positions(mask,:,k) = repmat(pUnique(1,:),sum(mask),1);
    else
        for d = 1:3
            positions(mask,d,k) = interp1(tUnique,pUnique(:,d), ...
                time(mask),'linear');
        end
    end
end

pairCount = K*(K-1)/2;
UAV1 = zeros(pairCount,1);
UAV2 = zeros(pairCount,1);
MinimumDistance_m = nan(pairCount,1);
TimeAtMinimum_s = nan(pairCount,1);
ConflictSamples = zeros(pairCount,1);
NearConflictSamples = zeros(pairCount,1);
ConflictDuration_s = zeros(pairCount,1);
NearConflictDuration_s = zeros(pairCount,1);

pair = 0;
allMin = inf;
allMinTime = NaN;
for i = 1:K-1
    for j = i+1:K
        pair = pair+1;
        both = active(:,i) & active(:,j);
        if any(both)
            delta = positions(both,:,i)-positions(both,:,j);
            dist = sqrt(sum(delta.^2,2));
            tBoth = time(both);
            [minDist,q] = min(dist);
            minTime = tBoth(q);
            conflict = dist < cfg.multiUAVSafeSeparation;
            nearConflict = dist < cfg.multiUAVNearSeparation;
        else
            minDist = inf;
            minTime = NaN;
            conflict = false(0,1);
            nearConflict = false(0,1);
        end
        UAV1(pair) = i;
        UAV2(pair) = j;
        MinimumDistance_m(pair) = minDist;
        TimeAtMinimum_s(pair) = minTime;
        ConflictSamples(pair) = sum(conflict);
        NearConflictSamples(pair) = sum(nearConflict);
        ConflictDuration_s(pair) = sum(conflict)*dt;
        NearConflictDuration_s(pair) = sum(nearConflict)*dt;
        if minDist < allMin
            allMin = minDist;
            allMinTime = minTime;
        end
    end
end

pairTable = table(UAV1,UAV2,MinimumDistance_m,TimeAtMinimum_s, ...
    ConflictSamples,NearConflictSamples,ConflictDuration_s, ...
    NearConflictDuration_s);

separation.time = time;
separation.positions = positions;
separation.active = active;
separation.pathLength = pathLength;
separation.duration = duration;
separation.launchDelays = launchDelays;
separation.endTimes = endTimes;
separation.missionEndTime = missionEnd;
separation.minimumSeparation = allMin;
separation.timeAtMinimum = allMinTime;
separation.conflictPairCount = sum(ConflictSamples>0);
separation.nearConflictPairCount = sum(NearConflictSamples>0);
separation.conflictSampleCount = sum(ConflictSamples);
separation.nearConflictSampleCount = sum(NearConflictSamples);
separation.conflictDuration = sum(ConflictDuration_s);
separation.nearConflictDuration = sum(NearConflictDuration_s);
separation.collisionFree = separation.conflictPairCount == 0;
separation.pairTable = pairTable;
end
