function knowledge = buildMonitoringKnowledgeBase(problem,cfg)
%BUILDMONITORINGKNOWLEDGEBASE Static DEM/LOS monitoring knowledge for v7.0.0.
%
% This structure contains task-side information only. It never stores an
% evolutionary individual/chromosome and therefore cannot restore historical
% solutions into the population. The same deterministic knowledge is shared by
% upper-layer allocation, A1 initialization and the single A3 corridor repair.

T = problem.monitorTargets;
M = size(T,1);
if localCfg(cfg,'enableObservabilityAwareAllocation',true) || ...
        localCfg(cfg,'enableObservabilityGuidedMonitoringArcs',true)
    obs = multiUAV.estimateTargetObservability(problem,cfg);
else
    obs = localNeutralObservability(M);
end

criticalMask = false(M,1);
if isfield(cfg,'criticalTargetIndices')
    critical = cfg.criticalTargetIndices(:);
    critical = critical(critical>=1 & critical<=M);
    criticalMask(critical) = true;
end

knowledge.version = 'v7.0.0-static-dem-los-knowledge';
knowledge.method = obs.method;
knowledge.targetIndex = (1:M)';
knowledge.criticalMask = criticalMask;
knowledge.score = obs.score(:);
knowledge.difficulty = obs.difficulty(:);
knowledge.visibleViewFraction = obs.visibleFraction(:);
knowledge.validViewFraction = obs.validViewFraction(:);
knowledge.maxVisibleArcLength_m = obs.maxVisibleArcLength_m(:);
knowledge.bestRadiusScale = obs.bestRadiusScale(:);
knowledge.bestSectorCenterRad = obs.bestSectorCenterRad(:);
knowledge.bestSectorCenterDeg = obs.bestSectorCenterDeg(:);
knowledge.bestSectorHalfWidthRad = obs.bestSectorHalfWidthRad(:);
knowledge.bestSectorHalfWidthDeg = obs.bestSectorHalfWidthDeg(:);
knowledge.bestVisibleRunCount = obs.bestVisibleRunCount(:);
knowledge.candidateCount = obs.candidateCount(:);
knowledge.azimuthSamples = obs.azimuthSamples;
knowledge.radiusScales = obs.radiusScales;
knowledge.raySamples = obs.raySamples;
knowledge.observability = obs;
end

function obs = localNeutralObservability(M)
obs.score = ones(M,1);
obs.difficulty = zeros(M,1);
obs.visibleFraction = ones(M,1);
obs.validViewFraction = ones(M,1);
obs.maxVisibleArcLength_m = zeros(M,1);
obs.bestRadiusScale = ones(M,1);
obs.bestSectorCenterRad = zeros(M,1);
obs.bestSectorCenterDeg = zeros(M,1);
obs.bestSectorHalfWidthRad = pi*ones(M,1);
obs.bestSectorHalfWidthDeg = 180*ones(M,1);
obs.bestVisibleRunCount = zeros(M,1);
obs.candidateCount = zeros(M,1);
obs.azimuthSamples = 0;
obs.radiusScales = 1;
obs.raySamples = 0;
obs.method = 'disabled_neutral_knowledge';
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
