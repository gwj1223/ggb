function assignment = allocateTargetsObservabilityAware(problem,cfg)
%ALLOCATETARGETSOBSERVABILITYAWARE Deterministic terrain/LOS-aware allocation.
%
% v7.0.0 consumes one static Monitoring Knowledge Base. Exact target-count
% and Critical-count quotas are preserved, while DEM/LOS observability, route
% and workload balance guide the upper layer. The inner five objectives are
% unchanged.
%
% Allocation score balances:
%   - spatial compactness;
%   - route/transit proxy mean, maximum and spread;
%   - aggregate terrain/risk workload;
%   - explicit risk workload balance;
%   - observability workload balance;
%   - Critical-target observability balance;
%   - per-UAV worst-target observability spread.

multiUAV.validateConfig(cfg,problem);
T = problem.monitorTargets;
M = size(T,1);
K = cfg.multiUAVCount;
xy = T(:,1:2);

span = max(max(xy,[],1)-min(xy,[],1),1);
xyN = (xy-min(xy,[],1))./span;

weights = T(:,3);
risk = localTargetRisk(problem);
slope = localTargetSlope(problem);
riskN = localNormalize(risk);
slopeN = localNormalize(slope);

knowledge = multiUAV.buildMonitoringKnowledgeBase(problem,cfg);
observability = knowledge.observability;
obsWeight = localCfg(cfg,'multiUAVObservabilityDifficultyWeight',0.55);
difficulty = weights.*(1 + 0.45*riskN + 0.25*slopeN + ...
    obsWeight*observability.difficulty);
riskBurden = weights.*(0.70*riskN+0.30*slopeN);
observabilityBurden = weights.*observability.difficulty;

targetZ = localTargetObservationAltitude(problem,T,cfg);

criticalMask = false(M,1);
critical = cfg.criticalTargetIndices(:);
critical = critical(critical>=1 & critical<=M);
criticalMask(critical) = true;
criticalObservabilityBurden = observabilityBurden.*double(criticalMask);

targetQuota = localBalancedQuota(M,K);
criticalQuota = localBalancedQuota(numel(critical),K);

centres = localInitialCentres(xyN,difficulty,K);
previous = zeros(M,1);
maxIter = max(1,round(localCfg(cfg,'multiUAVAllocationIterations',30)));

for iter = 1:maxIter
    targetToUAV = zeros(M,1);
    targetCount = zeros(K,1);
    criticalCount = zeros(K,1);
    loadValue = zeros(K,1);

    criticalOrder = find(criticalMask);
    [~,q] = sort(difficulty(criticalOrder),'descend');
    criticalOrder = criticalOrder(q);
    for n = 1:numel(criticalOrder)
        m = criticalOrder(n);
        allowed = find(criticalCount < criticalQuota & targetCount < targetQuota);
        if isempty(allowed), allowed = find(targetCount < targetQuota); end
        k = localBestVehicle(m,allowed,xyN,centres,difficulty, ...
            loadValue,targetCount,targetQuota,cfg);
        targetToUAV(m) = k;
        targetCount(k) = targetCount(k)+1;
        criticalCount(k) = criticalCount(k)+1;
        loadValue(k) = loadValue(k)+difficulty(m);
    end

    ordinaryOrder = find(~criticalMask);
    [~,q] = sort(difficulty(ordinaryOrder),'descend');
    ordinaryOrder = ordinaryOrder(q);
    for n = 1:numel(ordinaryOrder)
        m = ordinaryOrder(n);
        allowed = find(targetCount < targetQuota);
        if isempty(allowed)
            error('multiUAV:AllocationCapacity', ...
                'No remaining vehicle capacity while assigning target %d.',m);
        end
        k = localBestVehicle(m,allowed,xyN,centres,difficulty, ...
            loadValue,targetCount,targetQuota,cfg);
        targetToUAV(m) = k;
        targetCount(k) = targetCount(k)+1;
        loadValue(k) = loadValue(k)+difficulty(m);
    end

    centres = localCentres(targetToUAV,xyN,difficulty,K);
    if isequal(targetToUAV,previous), break; end
    previous = targetToUAV;
end

% Exact-quota pair swaps preserve target and Critical counts while improving
% route, risk and observability balance jointly.
[targetToUAV,refinement] = localRefineSwaps(targetToUAV,xy,xyN,targetZ, ...
    difficulty,riskBurden,observabilityBurden,criticalObservabilityBurden, ...
    observability.difficulty,criticalMask,K,problem,cfg);
centres = localCentres(targetToUAV,xyN,difficulty,K);

metrics = localAssignmentMetrics(targetToUAV,xy,xyN,targetZ,difficulty, ...
    riskBurden,observabilityBurden,criticalObservabilityBurden, ...
    observability.difficulty,K,problem,cfg);

groups = cell(K,1);
for k = 1:K, groups{k} = find(targetToUAV==k)'; end

assignment.method = 'v700_knowledge_risk_observability_route_balanced_exclusive';
assignment.monitoringKnowledge = knowledge;
assignment.targetToUAV = targetToUAV;
assignment.groups = groups;
assignment.centresNormalized = centres;
assignment.centresXY = centres.*span + min(xy,[],1);
assignment.targetDifficulty = difficulty;
assignment.targetRisk = risk;
assignment.targetSlope = slope;
assignment.targetObservationAltitude_m = targetZ;
assignment.targetObservabilityScore = observability.score;
assignment.targetObservabilityDifficulty = observability.difficulty;
assignment.targetVisibleViewFraction = observability.visibleFraction;
assignment.targetValidViewFraction = observability.validViewFraction;
assignment.targetMaxVisibleArcLength_m = observability.maxVisibleArcLength_m;
assignment.targetBestObservationRadiusScale = observability.bestRadiusScale;
assignment.targetBestVisibleSectorCenterRad = observability.bestSectorCenterRad;
assignment.targetBestVisibleSectorCenterDeg = observability.bestSectorCenterDeg;
assignment.targetBestVisibleSectorHalfWidthRad = observability.bestSectorHalfWidthRad;
assignment.targetBestVisibleSectorHalfWidthDeg = observability.bestSectorHalfWidthDeg;
assignment.targetBestVisibleRunCount = observability.bestVisibleRunCount;
assignment.observabilityMethod = observability.method;
assignment.targetQuota = targetQuota;
assignment.criticalQuota = criticalQuota;
assignment.targetCount = accumarray(targetToUAV,1,[K 1]);
assignment.criticalCount = accumarray(targetToUAV(criticalMask),1,[K 1]);
assignment.load = metrics.load;
assignment.riskLoad = metrics.riskLoad;
assignment.observabilityLoad = metrics.observabilityLoad;
assignment.criticalObservabilityLoad = metrics.criticalObservabilityLoad;
assignment.worstObservabilityDifficulty = metrics.worstObservabilityDifficulty;
assignment.criticalMask = criticalMask;
assignment.iterations = iter;
assignment.compactnessScore = metrics.compactness;
assignment.routeProxy_m = metrics.routeProxy;
assignment.transitProxy_s = metrics.routeProxy/max(cfg.multiUAVCruiseSpeed,eps);
assignment.transitMakespanProxy_s = max(assignment.transitProxy_s);
assignment.routeProxySpread_m = max(metrics.routeProxy)-min(metrics.routeProxy);
assignment.loadCV = localCV(metrics.load);
assignment.riskLoadCV = localCV(metrics.riskLoad);
assignment.observabilityLoadCV = localCV(metrics.observabilityLoad);
assignment.criticalObservabilityLoadCV = localCV(metrics.criticalObservabilityLoad);
assignment.worstObservabilitySpread = ...
    max(metrics.worstObservabilityDifficulty)-min(metrics.worstObservabilityDifficulty);
assignment.refinementPasses = refinement.passes;
assignment.refinementScore = refinement.score;
assignment.allocationScore = metrics.score;
end

function neutral = localNeutralObservability(M)
neutral.score = ones(M,1);
neutral.difficulty = zeros(M,1);
neutral.visibleFraction = ones(M,1);
neutral.validViewFraction = ones(M,1);
neutral.maxVisibleArcLength_m = zeros(M,1);
neutral.bestRadiusScale = ones(M,1);
neutral.bestSectorCenterRad = zeros(M,1);
neutral.bestSectorCenterDeg = zeros(M,1);
neutral.bestSectorHalfWidthRad = pi*ones(M,1);
neutral.bestSectorHalfWidthDeg = 180*ones(M,1);
neutral.bestVisibleRunCount = zeros(M,1);
neutral.method = 'disabled_neutral_proxy';
end

function [assignment,info] = localRefineSwaps(assignment,xy,xyN,z, ...
    difficulty,riskBurden,obsBurden,criticalObsBurden,obsDifficulty, ...
    criticalMask,K,problem,cfg)
maxPasses = max(1,round(localCfg(cfg,'multiUAVAllocationSwapPasses',35)));
bestMetrics = localAssignmentMetrics(assignment,xy,xyN,z,difficulty, ...
    riskBurden,obsBurden,criticalObsBurden,obsDifficulty,K,problem,cfg);
bestScore = bestMetrics.score;
passes = 0;
for pass = 1:maxPasses
    bestGain = 0;
    bestPair = [];
    M = numel(assignment);
    for i = 1:M-1
        for j = i+1:M
            % Pair swaps preserve exact target count. Restricting swaps to
            % equal Critical class also preserves the exact Critical quota.
            if assignment(i)==assignment(j) || ...
                    criticalMask(i)~=criticalMask(j)
                continue;
            end
            candidate = assignment;
            tmp = candidate(i); candidate(i) = candidate(j); candidate(j) = tmp;
            candidateMetrics = localAssignmentMetrics(candidate,xy,xyN,z, ...
                difficulty,riskBurden,obsBurden,criticalObsBurden, ...
                obsDifficulty,K,problem,cfg);
            gain = bestScore-candidateMetrics.score;
            if gain > bestGain+1e-10
                bestGain = gain;
                bestPair = [i j]; %#ok<AGROW>
            end
        end
    end
    if isempty(bestPair), break; end
    tmp = assignment(bestPair(1));
    assignment(bestPair(1)) = assignment(bestPair(2));
    assignment(bestPair(2)) = tmp;
    bestScore = bestScore-bestGain;
    passes = pass;
end
info.passes = passes;
info.score = bestScore;
end

function metrics = localAssignmentMetrics(assignment,xy,xyN,z,difficulty, ...
    riskBurden,obsBurden,criticalObsBurden,obsDifficulty,K,problem,cfg)
metrics.compactness = localCompactness(assignment,xyN,difficulty,K);
metrics.load = accumarray(assignment,difficulty,[K 1],@sum,0);
metrics.riskLoad = accumarray(assignment,riskBurden,[K 1],@sum,0);
metrics.observabilityLoad = accumarray(assignment,obsBurden,[K 1],@sum,0);
metrics.criticalObservabilityLoad = ...
    accumarray(assignment,criticalObsBurden,[K 1],@sum,0);
metrics.routeProxy = zeros(K,1);
metrics.worstObservabilityDifficulty = zeros(K,1);
for k = 1:K
    idx = find(assignment==k);
    metrics.routeProxy(k) = localRouteProxy(idx,xy,z,problem,cfg);
    if isempty(idx)
        metrics.worstObservabilityDifficulty(k) = 0;
    else
        metrics.worstObservabilityDifficulty(k) = max(obsDifficulty(idx));
    end
end

domainScale = max(norm([diff(problem.xBounds) diff(problem.yBounds)]),1);
routeN = metrics.routeProxy/domainScale;
loadN = localMeanNormalize(metrics.load);
riskLoadN = localMeanNormalize(metrics.riskLoad);
obsLoadN = localMeanNormalize(metrics.observabilityLoad);
criticalObsLoadN = localMeanNormalize(metrics.criticalObservabilityLoad);

cw = localCfg(cfg,'multiUAVAllocationCompactnessWeight',0.25);
rw = localCfg(cfg,'multiUAVAllocationRouteWeight',0.85);
mw = localCfg(cfg,'multiUAVAllocationMaxRouteWeight',1.20);
sw = localCfg(cfg,'multiUAVAllocationRouteSpreadWeight',0.35);
lw = localCfg(cfg,'multiUAVAllocationLoadBalanceWeight',0.25);
rbw = localCfg(cfg,'multiUAVAllocationRiskBalanceWeight',0.20);
obw = localCfg(cfg,'multiUAVAllocationObservabilityBalanceWeight',0.45);
cobw = localCfg(cfg,'multiUAVAllocationCriticalObservabilityBalanceWeight',0.35);
oww = localCfg(cfg,'multiUAVAllocationWorstObservabilitySpreadWeight',0.25);

metrics.score = cw*metrics.compactness + rw*mean(routeN) + ...
    mw*max(routeN) + sw*(max(routeN)-min(routeN)) + ...
    lw*std(loadN,1) + rbw*std(riskLoadN,1) + ...
    obw*std(obsLoadN,1) + cobw*std(criticalObsLoadN,1) + ...
    oww*std(metrics.worstObservabilityDifficulty,1);
end

function cost = localRouteProxy(idx,xy,z,problem,cfg)
if isempty(idx)
    cost = localWeightedDistance(problem.start,problem.goal,cfg);
    return;
end
obs = [xy(idx,:) z(idx)];
remaining = 1:size(obs,1);
order = zeros(1,numel(remaining));
current = problem.start;
goalBias = localCfg(cfg,'multiUAVAllocationGoalBias',0.08);
for q = 1:numel(order)
    dCurrent = zeros(numel(remaining),1);
    dGoal = zeros(numel(remaining),1);
    for j = 1:numel(remaining)
        dCurrent(j) = localWeightedDistance(current,obs(remaining(j),:),cfg);
        dGoal(j) = localWeightedDistance(obs(remaining(j),:),problem.goal,cfg);
    end
    [~,r] = min(dCurrent+goalBias*dGoal);
    order(q) = remaining(r);
    current = obs(order(q),:);
    remaining(r) = [];
end
order = localRouteTwoOpt(order,obs,problem.start,problem.goal,cfg);
cost = localOrderedRouteCost(order,obs,problem.start,problem.goal,cfg);
end

function order = localRouteTwoOpt(order,obs,startPoint,goalPoint,cfg)
passes = max(0,round(localCfg(cfg,'multiUAVAllocationTwoOptPasses',2)));
best = localOrderedRouteCost(order,obs,startPoint,goalPoint,cfg);
for pass = 1:passes
    improved = false;
    for i = 1:numel(order)-1
        for j = i+1:numel(order)
            c = order; c(i:j) = order(j:-1:i);
            v = localOrderedRouteCost(c,obs,startPoint,goalPoint,cfg);
            if v < best-1e-9
                order = c; best = v; improved = true;
            end
        end
    end
    if ~improved, break; end
end
end

function cost = localOrderedRouteCost(order,obs,startPoint,goalPoint,cfg)
route = [startPoint;obs(order,:);goalPoint];
cost = 0;
for i = 1:size(route,1)-1
    cost = cost+localWeightedDistance(route(i,:),route(i+1,:),cfg);
end
end

function d = localWeightedDistance(a,b,cfg)
vw = localCfg(cfg,'multiUAVAllocationVerticalWeight',2.5);
delta = a-b;
d = sqrt(delta(1)^2+delta(2)^2+(vw*delta(3))^2);
end

function z = localTargetObservationAltitude(problem,T,cfg)
M = size(T,1);
if isfield(problem,'monitorTargetTerrain') && numel(problem.monitorTargetTerrain)>=M
    terrain = problem.monitorTargetTerrain(1:M);
    terrain = terrain(:);
else
    terrain = data.terrainHeight(problem,T(:,1),T(:,2));
    terrain = terrain(:);
end
z = terrain+T(:,5);
z = min(z,localCfg(cfg,'maxAltitude',inf));
end

function score = localCompactness(assignment,xy,difficulty,K)
centres = localCentres(assignment,xy,difficulty,K);
score = 0;
for k = 1:K
    idx = find(assignment==k);
    if isempty(idx), continue; end
    score = score+sum(difficulty(idx).*vecnorm(xy(idx,:)-centres(k,:),2,2));
end
score = score/max(sum(difficulty),eps);
end

function centres = localCentres(assignment,xy,difficulty,K)
centres = zeros(K,2);
for k = 1:K
    idx = find(assignment==k);
    if isempty(idx), continue; end
    w = difficulty(idx);
    centres(k,:) = sum(xy(idx,:).*w,1)/max(sum(w),eps);
end
end

function k = localBestVehicle(m,allowed,xy,centres,difficulty,loadValue, ...
    targetCount,targetQuota,cfg)
dw = localCfg(cfg,'multiUAVAllocationDistanceWeight',0.85);
lw = localCfg(cfg,'multiUAVAllocationLoadWeight',0.45);
cw = localCfg(cfg,'multiUAVAllocationCountWeight',0.15);
meanLoad = max(sum(difficulty)/numel(loadValue),eps);
score = inf(numel(loadValue),1);
for ii = 1:numel(allowed)
    q = allowed(ii);
    spatial = norm(xy(m,:)-centres(q,:));
    projectedLoad = (loadValue(q)+difficulty(m))/meanLoad;
    projectedCount = (targetCount(q)+1)/max(targetQuota(q),1);
    score(q) = dw*spatial + lw*projectedLoad + cw*projectedCount;
end
[~,k] = min(score);
end

function centres = localInitialCentres(xy,difficulty,K)
centres = zeros(K,2);
[~,first] = max(difficulty);
seed = first; centres(1,:) = xy(seed,:);
chosen = false(size(xy,1),1); chosen(seed) = true;
for k = 2:K
    d = inf(size(xy,1),1);
    for j = 1:k-1, d = min(d,vecnorm(xy-centres(j,:),2,2)); end
    d(chosen) = -inf;
    weighted = d.*(difficulty/max(max(difficulty),eps));
    [~,seed] = max(weighted);
    centres(k,:) = xy(seed,:); chosen(seed) = true;
end
end

function quota = localBalancedQuota(N,K)
quota = repmat(floor(N/K),K,1);
remainder = mod(N,K);
if remainder > 0, quota(1:remainder) = quota(1:remainder)+1; end
end

function values = localTargetRisk(problem)
M = size(problem.monitorTargets,1);
if isfield(problem,'monitorTargetMeta') && numel(problem.monitorTargetMeta)>=M && ...
        isfield(problem.monitorTargetMeta,'risk')
    values = reshape([problem.monitorTargetMeta(1:M).risk],[],1);
else
    values = data.riskValue(problem,problem.monitorTargets(:,1), ...
        problem.monitorTargets(:,2));
    values = values(:);
end
end

function values = localTargetSlope(problem)
M = size(problem.monitorTargets,1);
if isfield(problem,'monitorTargetMeta') && numel(problem.monitorTargetMeta)>=M && ...
        isfield(problem.monitorTargetMeta,'slopeDeg')
    values = reshape([problem.monitorTargetMeta(1:M).slopeDeg],[],1);
else
    if isfield(problem,'gridXVector')
        x = problem.gridXVector; y = problem.gridYVector;
    else
        x = problem.gridX(1,:); y = problem.gridY(:,1);
    end
    values = interp2(x,y,problem.geology.slopeDeg,problem.monitorTargets(:,1), ...
        problem.monitorTargets(:,2),'linear',0);
    values = values(:);
end
end

function y = localNormalize(x)
x = x(:); lo = min(x,[],'omitnan'); hi = max(x,[],'omitnan');
if ~isfinite(lo) || ~isfinite(hi) || hi<=lo
    y = zeros(size(x));
else
    y = (x-lo)/(hi-lo); y(~isfinite(y)) = 0;
end
end

function y = localMeanNormalize(x)
x = x(:);
finite = x(isfinite(x));
if isempty(finite)
    y = zeros(size(x));
    return;
end
meanX = mean(finite);
if meanX<=eps
    y = zeros(size(x));
else
    y = x/meanX;
    y(~isfinite(y)) = 0;
end
end

function value = localCV(x)
x = x(:);
finite = x(isfinite(x));
if isempty(finite)
    value = 0;
    return;
end
mu = mean(finite);
if abs(mu)<=eps
    value = 0;
else
    value = std(finite,1)/abs(mu);
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
