function obs = estimateTargetObservability(problem,cfg)
%ESTIMATETARGETOBSERVABILITY DEM/LOS-based target observability proxy.
%
% v7.0.0 extends the v6.5.9 deterministic proxy with the centre and angular
% width of the longest visible sector. These fields are used only as geometry
% hints by monitoring-guided initialization/repair; formal monitoring quality,
% observation length and LOS remain evaluated by evaluation.monitoringQuality.

T = problem.monitorTargets;
M = size(T,1);
azimuthCount = max(8,round(localCfg(cfg, ...
    'multiUAVObservabilityAzimuthSamples',16)));
radiusScales = localCfg(cfg,'multiUAVObservabilityRadiusScales',[0.85 1.00 1.15]);
radiusScales = reshape(radiusScales,1,[]);
radiusScales = radiusScales(isfinite(radiusScales) & radiusScales>0);
if isempty(radiusScales), radiusScales = 1.0; end
raySamples = max(3,round(localCfg(cfg,'multiUAVObservabilityLOSRaySamples', ...
    localCfg(cfg,'monitorLineOfSightSamples',12))));
visibleWeight = localCfg(cfg,'multiUAVObservabilityVisibleWeight',0.60);
arcWeight = localCfg(cfg,'multiUAVObservabilityArcWeight',0.40);
weightSum = max(visibleWeight+arcWeight,eps);
visibleWeight = visibleWeight/weightSum;
arcWeight = arcWeight/weightSum;

if isfield(problem,'monitorTargetTerrain') && ...
        numel(problem.monitorTargetTerrain)>=M
    targetTerrain = problem.monitorTargetTerrain(1:M);
    targetTerrain = targetTerrain(:);
else
    targetTerrain = data.terrainHeight(problem,T(:,1),T(:,2));
    targetTerrain = targetTerrain(:);
end

score = zeros(M,1);
difficulty = ones(M,1);
visibleFraction = zeros(M,1);
validViewFraction = zeros(M,1);
maxVisibleArcLength_m = zeros(M,1);
bestRadiusScale = ones(M,1);
bestSectorCenterRad = zeros(M,1);
bestSectorHalfWidthRad = pi*ones(M,1);
bestVisibleRunCount = zeros(M,1);
candidateCount = repmat(azimuthCount*numel(radiusScales),M,1);

angles = (0:azimuthCount-1)'*(2*pi/azimuthCount);
stepAngle = 2*pi/azimuthCount;
alpha = linspace(0,1,raySamples);
alpha = alpha(2:end-1);
useLOS = localCfg(cfg,'enableLineOfSight',true) && ~isempty(alpha);
formalMinAGL = localCfg(cfg,'safeClearance',0);
formalMaxAGL = localCfg(cfg,'realMaximumAGL',inf);
requiredObservation = max(localCfg(cfg,'monitorRequiredObservationLength',1),eps);

for m = 1:M
    desiredR = max(T(m,4),eps);
    desiredH = T(m,5);
    targetXY = T(m,1:2);
    bestScore = -inf;
    bestVisible = 0;
    bestValid = 0;
    bestArc = 0;
    bestScale = radiusScales(1);
    bestCentre = 0;
    bestHalfWidth = pi;
    bestRun = 0;

    for s = 1:numel(radiusScales)
        radius = desiredR*radiusScales(s);
        x = targetXY(1)+radius*cos(angles);
        y = targetXY(2)+radius*sin(angles);
        inside = x>=problem.xBounds(1) & x<=problem.xBounds(2) & ...
            y>=problem.yBounds(1) & y<=problem.yBounds(2);

        ground = data.terrainHeight(problem,x,y);
        ground = ground(:);
        valid = inside & isfinite(ground);
        valid = valid & desiredH>=formalMinAGL & desiredH<=formalMaxAGL;
        z = ground+desiredH;

        visible = false(azimuthCount,1);
        if ~useLOS
            visible(valid) = true;
        else
            validIdx = find(valid);
            for q = 1:numel(validIdx)
                j = validIdx(q);
                lineX = x(j)+(targetXY(1)-x(j))*alpha;
                lineY = y(j)+(targetXY(2)-y(j))*alpha;
                lineZ = z(j)+(targetTerrain(m)+1-z(j))*alpha;
                terrainLOS = data.terrainHeight(problem,lineX,lineY);
                terrainLOS = terrainLOS(:)';
                lineZ = lineZ(:)';
                visible(j) = all(isfinite(terrainLOS)) && ...
                    ~any(terrainLOS > lineZ);
            end
        end

        vf = sum(visible)/azimuthCount;
        validFraction = sum(valid)/azimuthCount;
        [longestRun,startIndex] = localLongestCircularRun(visible);
        arcLength = longestRun*(2*pi*radius/azimuthCount);
        arcPotential = min(max(arcLength/requiredObservation,0),1);
        candidateScore = visibleWeight*vf+arcWeight*arcPotential;

        if longestRun>=azimuthCount
            sectorCentre = 0;
            sectorHalfWidth = pi;
        elseif longestRun>0
            sectorCentre = angles(startIndex)+0.5*(longestRun-1)*stepAngle;
            sectorCentre = atan2(sin(sectorCentre),cos(sectorCentre));
            sectorHalfWidth = min(pi,0.5*longestRun*stepAngle);
        else
            sectorCentre = 0;
            sectorHalfWidth = 0;
        end

        if candidateScore > bestScore+1e-12 || ...
                (abs(candidateScore-bestScore)<=1e-12 && arcLength>bestArc)
            bestScore = candidateScore;
            bestVisible = vf;
            bestValid = validFraction;
            bestArc = arcLength;
            bestScale = radiusScales(s);
            bestCentre = sectorCentre;
            bestHalfWidth = sectorHalfWidth;
            bestRun = longestRun;
        end
    end

    score(m) = min(max(bestScore,0),1);
    difficulty(m) = 1-score(m);
    visibleFraction(m) = min(max(bestVisible,0),1);
    validViewFraction(m) = min(max(bestValid,0),1);
    maxVisibleArcLength_m(m) = max(bestArc,0);
    bestRadiusScale(m) = bestScale;
    bestSectorCenterRad(m) = bestCentre;
    bestSectorHalfWidthRad(m) = bestHalfWidth;
    bestVisibleRunCount(m) = bestRun;
end

obs.score = score;
obs.difficulty = difficulty;
obs.visibleFraction = visibleFraction;
obs.validViewFraction = validViewFraction;
obs.maxVisibleArcLength_m = maxVisibleArcLength_m;
obs.bestRadiusScale = bestRadiusScale;
obs.bestSectorCenterRad = bestSectorCenterRad;
obs.bestSectorCenterDeg = rad2deg(bestSectorCenterRad);
obs.bestSectorHalfWidthRad = bestSectorHalfWidthRad;
obs.bestSectorHalfWidthDeg = rad2deg(bestSectorHalfWidthRad);
obs.bestVisibleRunCount = bestVisibleRunCount;
obs.candidateCount = candidateCount;
obs.azimuthSamples = azimuthCount;
obs.radiusScales = radiusScales;
obs.raySamples = raySamples;
obs.method = 'dem_los_contiguous_arc_sector_proxy';
end

function [runLength,startIndex] = localLongestCircularRun(mask)
mask = logical(mask(:));
N = numel(mask);
runLength = 0;
startIndex = 1;
if N==0 || ~any(mask), return; end
if all(mask)
    runLength = N;
    startIndex = 1;
    return;
end
extended = [mask;mask];
best = 0;
bestEnd = 1;
current = 0;
for k = 1:numel(extended)
    if extended(k)
        current = min(current+1,N);
        if current > best
            best = current;
            bestEnd = k;
        end
    else
        current = 0;
    end
end
runLength = min(best,N);
startIndex = mod(bestEnd-runLength,N)+1;
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
