function [subProblem,subCfg] = buildSubProblem(problem,cfg,assignment,uavId)
%BUILDSUBPROBLEM Create one UAV problem by subsetting monitoring targets.

K = cfg.multiUAVCount;
if uavId < 1 || uavId > K || uavId ~= round(uavId)
    error('multiUAV:InvalidVehicle','Invalid UAV index %g.',uavId);
end
idx = assignment.groups{uavId}(:);
if isempty(idx)
    error('multiUAV:EmptyTaskGroup','UAV %d has no assigned targets.',uavId);
end

subProblem = problem;
subProblem.name = sprintf('%s | UAV-%d',problem.name,uavId);
subProblem.sceneId = sprintf('%s-UAV%d',problem.sceneId,uavId);
subProblem.globalTargetIndices = idx;
subProblem.monitorTargets = problem.monitorTargets(idx,:);

% v7.0.0: carry the same static Monitoring Knowledge Base into the local
% problem. A1 and the single A3 repair therefore read identical DEM/LOS hints;
% no historical individual is stored or restored.
if isfield(assignment,'monitoringKnowledge')
    subProblem.monitoringKnowledge = localSubsetKnowledge( ...
        assignment.monitoringKnowledge,idx);
end

if isfield(assignment,'targetObservabilityScore')
    subProblem.monitorTargetObservabilityScore = assignment.targetObservabilityScore(idx);
    subProblem.monitorTargetObservabilityDifficulty = assignment.targetObservabilityDifficulty(idx);
    subProblem.monitorTargetBestRadiusScale = assignment.targetBestObservationRadiusScale(idx);
    subProblem.monitorTargetBestSectorCenterRad = assignment.targetBestVisibleSectorCenterRad(idx);
    subProblem.monitorTargetBestSectorHalfWidthRad = assignment.targetBestVisibleSectorHalfWidthRad(idx);
    subProblem.monitorTargetBestVisibleRunCount = assignment.targetBestVisibleRunCount(idx);
end

fields = {'monitorTargetTerrain','monitorTargetTypes','monitorTargetLabels', ...
    'monitorTargetNormals','monitorTargetLonLat','monitorTargetMeta'};
for f = 1:numel(fields)
    name = fields{f};
    if ~isfield(problem,name), continue; end
    value = problem.(name);
    if isstruct(value)
        subProblem.(name) = value(idx);
    elseif iscell(value)
        subProblem.(name) = value(idx,:);
    elseif isvector(value)
        subProblem.(name) = value(idx);
    else
        subProblem.(name) = value(idx,:);
    end
end

subCfg = cfg;
subCfg.randomSeed = cfg.randomSeed + (uavId-1)*cfg.multiUAVSeedStride;
subCfg.sceneId = subProblem.sceneId;
subCfg.multiUAVVehicleId = uavId;
subCfg.multiUAVGlobalTargetIndices = idx(:)';

M = numel(idx);
wp = round(localCfg(cfg,'multiUAVWaypointsPerTarget',3)*M + ...
    localCfg(cfg,'multiUAVWaypointBuffer',12));
wp = max(localCfg(cfg,'multiUAVMinWaypoints',30),wp);
wp = min(localCfg(cfg,'multiUAVMaxWaypoints',72),wp);
subCfg.numWaypoints = wp;
subCfg.monitorGuidedArcPoints = max(2,round(localCfg(cfg, ...
    'multiUAVMonitorGuidedArcPoints',3)));

% Convert global Critical indices to the local target numbering expected by
% monitoringQuality/updateDynamicConstraints.
globalCritical = cfg.criticalTargetIndices(:);
subCfg.criticalTargetIndices = find(ismember(idx,globalCritical))';

% v7.2.0 freezes the A1-compatible target order for the structured-encoding
% prototype. The order is problem data, not an evolving chromosome.
if localCfg(subCfg,'enableStructuredMonitoringEncoding',false)
    subProblem.structuredMonitoringTargetOrder = ...
        core.structuredMonitoringTargetOrder(subProblem,subCfg);
end

% Keep all final monitoring thresholds identical to the original scene.
subProblem.cfg = subCfg;
end

function out = localSubsetKnowledge(knowledge,idx)
out = knowledge;
fields = {'targetIndex','criticalMask','score','difficulty', ...
    'visibleViewFraction','validViewFraction','maxVisibleArcLength_m', ...
    'bestRadiusScale','bestSectorCenterRad','bestSectorCenterDeg', ...
    'bestSectorHalfWidthRad','bestSectorHalfWidthDeg','bestVisibleRunCount', ...
    'candidateCount'};
for k = 1:numel(fields)
    name = fields{k};
    if isfield(knowledge,name) && numel(knowledge.(name))>=max(idx)
        value = knowledge.(name);
        out.(name) = value(idx);
    end
end
out.globalTargetIndex = idx(:);
out.targetIndex = (1:numel(idx))';
if isfield(out,'observability')
    out = rmfield(out,'observability');
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
