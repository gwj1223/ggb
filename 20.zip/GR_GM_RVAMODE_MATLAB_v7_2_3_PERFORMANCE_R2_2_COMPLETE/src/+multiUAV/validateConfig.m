function validateConfig(cfg,problem)
%VALIDATECONFIG Validate v7.0.0 hierarchical multi-UAV settings.

required = {'multiUAVCount','multiUAVCruiseSpeed', ...
    'multiUAVSeparationTimeStep','multiUAVSafeSeparation', ...
    'multiUAVNearSeparation','multiUAVLaunchDelayStep', ...
    'multiUAVMaxLaunchDelay','multiUAVSeedStride'};
for i = 1:numel(required)
    if ~isfield(cfg,required{i})
        error('multiUAV:MissingConfig','Missing cfg.%s.',required{i});
    end
end

M = size(problem.monitorTargets,1);
K = cfg.multiUAVCount;
if ~isscalar(K) || K < 1 || K ~= round(K) || K > M
    error('multiUAV:InvalidCount', ...
        'multiUAVCount must be an integer between 1 and %d.',M);
end
if cfg.multiUAVCruiseSpeed <= 0
    error('multiUAV:InvalidSpeed','multiUAVCruiseSpeed must be positive.');
end
if cfg.multiUAVSeparationTimeStep <= 0
    error('multiUAV:InvalidTimeStep', ...
        'multiUAVSeparationTimeStep must be positive.');
end
if cfg.multiUAVSafeSeparation <= 0 || ...
        cfg.multiUAVNearSeparation < cfg.multiUAVSafeSeparation
    error('multiUAV:InvalidSeparation', ...
        'Near-separation must be >= safe-separation > 0.');
end
if cfg.multiUAVLaunchDelayStep <= 0 || cfg.multiUAVMaxLaunchDelay < 0
    error('multiUAV:InvalidLaunchSchedule', ...
        'Launch delay step must be positive and max delay nonnegative.');
end

aglValidationStep = localCfg(cfg,'localAGLValidationStep_m',10.0);
if ~isscalar(aglValidationStep) || ~isfinite(aglValidationStep) || ...
        aglValidationStep <= 0
    error('multiUAV:InvalidAGLValidationStep', ...
        'localAGLValidationStep_m must be a positive finite scalar.');
end
if localCfg(cfg,'enableLocalAGLConstraint',false)
    aglStep = localCfg(cfg,'aglConstraintSampleStep_m',15.0);
    aglMaxSamples = localCfg(cfg,'aglConstraintMaxSamplesPerSegment',96);
    if ~isscalar(aglStep) || ~isfinite(aglStep) || aglStep <= 0 || ...
            ~isscalar(aglMaxSamples) || ~isfinite(aglMaxSamples) || ...
            aglMaxSamples < 3
        error('multiUAV:InvalidAGLConstraintSampling', ...
            ['aglConstraintSampleStep_m must be positive and ' ...
             'aglConstraintMaxSamplesPerSegment must be at least 3.']);
    end
    maxAGL = localCfg(cfg,'realMaximumAGL',NaN);
    margin = localCfg(cfg,'segmentRepairMargin',0);
    if ~isscalar(maxAGL) || ~isfinite(maxAGL) || ...
            maxAGL <= cfg.safeClearance+2*margin
        error('multiUAV:InvalidLocalAGL', ...
            ['realMaximumAGL must exceed safeClearance plus twice ' ...
             'the repair margin when local AGL is enabled.']);
    end
end

if localCfg(cfg,'multiUAVAllocationVerticalWeight',1) <= 0
    error('multiUAV:InvalidRouteWeight', ...
        'multiUAVAllocationVerticalWeight must be positive.');
end

if localCfg(cfg,'enableObservabilityAwareAllocation',false) || ...
        localCfg(cfg,'enableObservabilityGuidedMonitoringArcs',false)
    az = localCfg(cfg,'multiUAVObservabilityAzimuthSamples',16);
    radii = localCfg(cfg,'multiUAVObservabilityRadiusScales',[0.85 1.00 1.15]);
    rays = localCfg(cfg,'multiUAVObservabilityLOSRaySamples',12);
    vw = localCfg(cfg,'multiUAVObservabilityVisibleWeight',0.60);
    aw = localCfg(cfg,'multiUAVObservabilityArcWeight',0.40);
    if ~isscalar(az) || ~isfinite(az) || az < 8 || ...
            ~isscalar(rays) || ~isfinite(rays) || rays < 3 || ...
            isempty(radii) || any(~isfinite(radii(:))) || any(radii(:)<=0) || ...
            ~isscalar(vw) || ~isscalar(aw) || vw < 0 || aw < 0 || vw+aw <= 0
        error('multiUAV:InvalidObservabilitySampling', ...
            ['Monitoring knowledge requires >=8 azimuth samples, >=3 LOS ' ...
             'ray samples, positive radius scales and nonnegative weights.']);
    end
end

if ~localCfg(cfg,'enableUnifiedMissionDeficit',false)
    error('multiUAV:UnifiedMissionDeficitRequired', ...
        'v7.0.0 requires the unified Mission Deficit hierarchy.');
end
if localCfg(cfg,'enableFeasibilityFeedbackThreshold',false) || ...
        localCfg(cfg,'monitorComponentwiseThresholdUpdate',false)
    error('multiUAV:LegacyThresholdControllerActive', ...
        'v7.0.0 forbids the legacy independent monitoring-threshold controller.');
end
startGen = localCfg(cfg,'missionFormationStartGeneration',25);
formalGen = localCfg(cfg,'missionFormalStartGeneration',100);
w = localCfg(cfg,'unifiedMissionDeficitWeights',[0.40 0.15 0.30 0.15]);
rho = localCfg(cfg,'missionDeficitAverageBlend',0.15);
qWorst = localCfg(cfg,'missionQualityWorstWeight',0.85);
gWorst = localCfg(cfg,'missionGeometryWorstWeight',0.90);
if ~isscalar(startGen) || ~isscalar(formalGen) || startGen < 1 || ...
        formalGen <= startGen || formalGen > cfg.maxGenerations
    error('multiUAV:InvalidMissionSchedule', ...
        'Mission generations must satisfy 1<=formation<formal<=maxGenerations.');
end
if numel(w)~=4 || any(~isfinite(w(:))) || any(w(:)<0) || sum(w(:))<=0
    error('multiUAV:InvalidMissionDeficitWeights', ...
        'unifiedMissionDeficitWeights must contain four nonnegative finite values.');
end
if any(~isfinite([rho qWorst gWorst])) || any([rho qWorst gWorst] < 0) || ...
        any([rho qWorst gWorst] > 1)
    error('multiUAV:InvalidMissionDeficitBlend', ...
        'Mission-deficit blend parameters must lie in [0,1].');
end

if localCfg(cfg,'enableMissionBandSelection',false)
    bandFraction = localCfg(cfg,'missionBandMinFraction',0.25);
    bandTol = localCfg(cfg,'missionBandTolerance',1e-10);
    if ~isscalar(bandFraction) || ~isfinite(bandFraction) || ...
            bandFraction<=0 || bandFraction>1 || ...
            ~isscalar(bandTol) || ~isfinite(bandTol) || bandTol<0
        error('multiUAV:InvalidMissionBandSelection', ...
            'missionBandMinFraction must lie in (0,1] and tolerance must be nonnegative.');
    end
end

if ~localCfg(cfg,'enableUnifiedMissionRepair',false)
    error('multiUAV:UnifiedMissionRepairRequired', ...
        'v7.0.0 requires the single unified A3 repair.');
end
if localCfg(cfg,'missionRepairStartGeneration',startGen) < startGen || ...
        localCfg(cfg,'missionRepairInterval',5) < 1 || ...
        localCfg(cfg,'missionRepairBaseCount',4) < 1 || ...
        localCfg(cfg,'missionRepairVariants',3) < 1 || ...
        localCfg(cfg,'missionRepairMaxEvaluationsPerEvent',12) < 1 || ...
        localCfg(cfg,'missionRepairMinTargetDeficitGain',1e-3) < 0 || ...
        localCfg(cfg,'missionRepairGlobalNonRegressionTolerance',1e-10) < 0 || ...
        localCfg(cfg,'missionRepairDesiredFormalCarriers',3) < 1 || ...
        localCfg(cfg,'missionRepairDesiredFormalCarriers',3) > cfg.populationSize
    error('multiUAV:InvalidUnifiedMissionRepair', ...
        'Unified A3 repair schedule/count/budget/carrier settings are invalid.');
end
tw = localCfg(cfg,'missionRepairTargetWeights',[1.00 0.35 1.30 0.80]);
if numel(tw)~=4 || any(~isfinite(tw(:))) || any(tw(:)<0) || sum(tw(:))<=0
    error('multiUAV:InvalidMissionRepairTargetWeights', ...
        'missionRepairTargetWeights must contain four nonnegative finite values.');
end
arcNames = {'missionRepairOrdinaryArcPoints','missionRepairCriticalArcPoints', ...
    'missionRepairOrdinaryHalfAngleDeg','missionRepairCriticalHalfAngleDeg', ...
    'missionRepairRadiusMultiplier'};
for i = 1:numel(arcNames)
    v = localCfg(cfg,arcNames{i},NaN);
    if ~isscalar(v) || ~isfinite(v) || v<=0
        error('multiUAV:InvalidMissionRepairGeometry', ...
            'cfg.%s must be a finite positive scalar.',arcNames{i});
    end
end

% These historical restoration mechanisms are deliberately prohibited in the
% final consolidated algorithm. Old releases remain available separately.
legacyFlags = {'enablePopulationCoveragePreservation', ...
    'enableTargetMemoryPreservation','enableMissionCarrierMemory', ...
    'enableCriticalObservationCorridorMemory', ...
    'enableCriticalObservationCorridorPreservation','enableDEObservationArcJump'};
for i = 1:numel(legacyFlags)
    if localCfg(cfg,legacyFlags{i},false)
        error('multiUAV:LegacyMonitoringRestorationActive', ...
            'v7.0.0 forbids legacy monitoring mechanism cfg.%s.',legacyFlags{i});
    end
end
if localCfg(cfg,'monitorEmergencyStrategyBlend',0) > 0
    error('multiUAV:LegacyEmergencyBlendActive', ...
        'v7.0.0 requires monitorEmergencyStrategyBlend=0.');
end

if localCfg(cfg,'enableDenseFinalAGLRepair',false)
    lowerMargin = localCfg(cfg,'denseFinalAGLLowerMargin_m',4);
    upperMargin = localCfg(cfg,'denseFinalAGLUpperMargin_m',2);
    if lowerMargin < 0 || upperMargin < 0 || ...
            cfg.safeClearance+lowerMargin >= ...
            localCfg(cfg,'realMaximumAGL',inf)-upperMargin
        error('multiUAV:InvalidDenseAGLMargin', ...
            'Dense final AGL safety margins leave no valid flight envelope.');
    end
end

if ~isfield(cfg,'criticalTargetIndices')
    error('multiUAV:MissingCriticalTargets', ...
        'cfg.criticalTargetIndices is required.');
end
critical = cfg.criticalTargetIndices(:);
if any(critical < 1 | critical > M | critical ~= round(critical))
    error('multiUAV:InvalidCriticalTargets', ...
        'Critical target indices must refer to the global target list.');
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
