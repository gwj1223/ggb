function assignment = allocateTargetsRiskAware(problem,cfg)
%ALLOCATETARGETSRISKAWARE Backward-compatible allocation entry point.
%
% v7.0.0 routes the historical function name to the observability-aware
% upper-layer allocator. Existing scripts therefore remain compatible while
% the implementation gains DEM/LOS-aware workload balancing.
assignment = multiUAV.allocateTargetsObservabilityAware(problem,cfg);
end
