function metricsOut = aggregateFleetMetrics(problem,cfg,assignment, ...
    uavResults,launchDelays,separation,wallClockTime)
%AGGREGATEFLEETMETRICS Fleet-level mission, monitoring and cost metrics.

K = numel(uavResults);
M = size(problem.monitorTargets,1);
pathLength = nan(K,1);
energy = nan(K,1);
risk = nan(K,1);
tailRisk = nan(K,1);
smoothness = nan(K,1);
finalFeasible = false(K,1);
controllerFinal = false(K,1);
strictEngineering = false(K,1);
runtime = nan(K,1);
QminLocal = nan(K,1);
QcriticalLocal = nan(K,1);
finalStageGenerations = zeros(K,1);
finalFeasibleRate = nan(K,1);
missionDeficitLocal = nan(K,1);
missionDeficitComponentsLocal = nan(K,4);
unifiedMissionRepairEvents = zeros(K,1);
unifiedMissionRepairEvaluations = zeros(K,1);
unifiedMissionRepairAccepted = zeros(K,1);
worstTargetIndexPerUAV = nan(K,1);
worstTargetQualityPerUAV = nan(K,1);
worstTargetObservationPerUAV = nan(K,1);
worstTargetLOSPerUAV = nan(K,1);
minAGL_m = nan(K,1);
maxAGL_m = nan(K,1);
lowerClearanceOK = false(K,1);
upperAGLOK = false(K,1);
aglValidationStep_m = localCfg(cfg,'localAGLValidationStep_m',10.0);

quality = nan(M,1);
observationLength = nan(M,1);
losRatio = nan(M,1);

for k = 1:K
    r = uavResults{k};
    b = r.best(1);
    idx = assignment.groups{k}(:);
    pathLength(k) = b.pathMetrics.rawLength;
    energy(k) = b.energyStats.total;
    risk(k) = b.riskStats.objective;
    tailRisk(k) = b.riskStats.tailRisk;
    smoothness(k) = b.objectives(4);
    finalFeasible(k) = r.bestSolutionSatisfiesFinalConstraints;
    controllerFinal(k) = r.controllerReachedFinalThresholds;
    if isfield(r,'reportedStrictEngineeringLimitsSatisfied')
        strictEngineering(k) = logical(r.reportedStrictEngineeringLimitsSatisfied);
    end
    runtime(k) = r.totalOptimizationTime;
    QminLocal(k) = b.monitorStats.minimumQuality;
    QcriticalLocal(k) = b.monitorStats.criticalQuality;
    % Mission Deficit is evaluated in the UAV-local target numbering.
    % Global Critical indices must therefore be mapped through this UAV's
    % assignment group before applying the four formal mission components.
    localMissionCfg = cfg;
    localMissionCfg.criticalTargetIndices = ...
        find(ismember(idx,cfg.criticalTargetIndices(:)))';
    missionInfoLocal = evaluation.missionDeficitComponents(b,localMissionCfg);
    missionDeficitLocal(k) = missionInfoLocal.total;
    missionDeficitComponentsLocal(k,:) = missionInfoLocal.components;
    if isfield(r,'finalStageGenerations')
        finalStageGenerations(k) = r.finalStageGenerations;
    end
    if isfield(r,'thresholdState') && ...
            isfield(r.thresholdState,'finalFeasibleRate')
        finalFeasibleRate(k) = r.thresholdState.finalFeasibleRate;
    end
    if isfield(r,'performance') && isfield(r.performance,'unifiedMissionRepairEvents')
        unifiedMissionRepairEvents(k) = r.performance.unifiedMissionRepairEvents;
    end
    if isfield(r,'performance') && isfield(r.performance,'unifiedMissionRepairEvaluations')
        unifiedMissionRepairEvaluations(k) = r.performance.unifiedMissionRepairEvaluations;
    end
    if isfield(r,'performance') && isfield(r.performance,'unifiedMissionRepairAccepted')
        unifiedMissionRepairAccepted(k) = r.performance.unifiedMissionRepairAccepted;
    end

    [minAGL_m(k),maxAGL_m(k),lowerClearanceOK(k),upperAGLOK(k)] = ...
        localPathAGL(problem,cfg,b.path,aglValidationStep_m);

    q = localMonitorVector(b,'truePerTarget','monitorPerTarget');
    obs = b.monitorStats.observationLength(:);
    los = b.monitorStats.losRatio(:);
    if numel(q) ~= numel(idx) || numel(obs) ~= numel(idx) || ...
            numel(los) ~= numel(idx)
        error('multiUAV:MonitoringSize', ...
            'UAV %d monitoring vector does not match its target group.',k);
    end
    quality(idx) = q(:);
    observationLength(idx) = obs;
    losRatio(idx) = los;
    [worstTargetQualityPerUAV(k),worstLocal] = min(q);
    worstTargetIndexPerUAV(k) = idx(worstLocal);
    worstTargetObservationPerUAV(k) = obs(worstLocal);
    worstTargetLOSPerUAV(k) = los(worstLocal);
end

weights = problem.monitorTargets(:,3);
Qavg = sum(weights.*quality)/max(sum(weights),eps);
[Qmin,worstTargetIndex] = min(quality);
worstTargetUAV = assignment.targetToUAV(worstTargetIndex);
critical = cfg.criticalTargetIndices(:);
critical = critical(critical>=1 & critical<=M);
if isempty(critical)
    Qcritical = Qavg;
    criticalObs = NaN;
    criticalLOS = NaN;
    criticalObsWorstTargetIndex = NaN;
    criticalLOSWorstTargetIndex = NaN;
else
    Qcritical = sum(weights(critical).*quality(critical))/ ...
        max(sum(weights(critical)),eps);
    [criticalObs,qObs] = min(observationLength(critical));
    [criticalLOS,qLOS] = min(losRatio(critical));
    criticalObsWorstTargetIndex = critical(qObs);
    criticalLOSWorstTargetIndex = critical(qLOS);
end

monitoringSatisfied = all(quality >= ...
    cfg.monitorMinTargetQuality-cfg.constraintTolerance) && ...
    Qcritical >= cfg.monitorCriticalMinQuality-cfg.constraintTolerance;
if ~isempty(critical)
    monitoringSatisfied = monitoringSatisfied && ...
        all(observationLength(critical) >= ...
        cfg.monitorCriticalMinObservationLength-cfg.constraintTolerance) && ...
        all(losRatio(critical) >= ...
        cfg.monitorCriticalMinLOSRatio-cfg.constraintTolerance);
end

riskMaxWeight = localCfg(cfg,'multiUAVFleetRiskMaxWeight',0.35);
fleetRisk = mean(risk,'omitnan') + riskMaxWeight*max(risk,[],'omitnan');

metricsOut.vehicleCount = K;
metricsOut.targetCount = M;
metricsOut.targetCountPerUAV = assignment.targetCount;
metricsOut.criticalCountPerUAV = assignment.criticalCount;
metricsOut.assignmentLoad = assignment.load;
metricsOut.pathLength_m = pathLength;
metricsOut.totalPathLength_m = sum(pathLength,'omitnan');
metricsOut.maximumPathLength_m = max(pathLength,[],'omitnan');
metricsOut.energy = energy;
metricsOut.totalEnergy = sum(energy,'omitnan');
metricsOut.maximumEnergy = max(energy,[],'omitnan');
metricsOut.risk = risk;
metricsOut.tailRisk = tailRisk;
metricsOut.fleetRiskScore = fleetRisk;
metricsOut.maximumRisk = max(risk,[],'omitnan');
metricsOut.maximumTailRisk = max(tailRisk,[],'omitnan');
metricsOut.smoothness = smoothness;
metricsOut.maximumSmoothness = max(smoothness,[],'omitnan');
metricsOut.Qavg = Qavg;
metricsOut.Qmin = Qmin;
metricsOut.Qcritical = Qcritical;
missionProxy.monitorPerTarget = quality;
missionProxy.monitorStats.truePerTarget = quality;
missionProxy.monitorStats.criticalQuality = Qcritical;
missionProxy.monitorStats.trueCriticalQuality = Qcritical;
missionProxy.monitorStats.observationLength = observationLength;
missionProxy.monitorStats.losRatio = losRatio;
missionProxy.monitorStats.minimumCriticalObservationLength = criticalObs;
missionProxy.monitorStats.minimumCriticalLOSRatio = criticalLOS;
missionInfo = evaluation.missionDeficitComponents(missionProxy,cfg);
metricsOut.missionDeficit = missionInfo.total;
metricsOut.missionDeficitComponents = missionInfo.components;
metricsOut.criticalMinObservationLength_m = criticalObs;
metricsOut.criticalMinLOS = criticalLOS;
metricsOut.criticalObsWorstTargetIndex = criticalObsWorstTargetIndex;
metricsOut.criticalObsWorstTargetUAV = localTargetUAV(assignment,criticalObsWorstTargetIndex);
metricsOut.criticalObsWorstTargetQuality = localTargetValue(quality,criticalObsWorstTargetIndex);
metricsOut.criticalObsWorstTargetLOS = localTargetValue(losRatio,criticalObsWorstTargetIndex);
metricsOut.criticalLOSWorstTargetIndex = criticalLOSWorstTargetIndex;
metricsOut.criticalLOSWorstTargetUAV = localTargetUAV(assignment,criticalLOSWorstTargetIndex);
metricsOut.criticalLOSWorstTargetQuality = localTargetValue(quality,criticalLOSWorstTargetIndex);
metricsOut.criticalLOSWorstTargetObservationLength_m = localTargetValue(observationLength,criticalLOSWorstTargetIndex);
metricsOut.perTargetQuality = quality;
metricsOut.perTargetObservationLength_m = observationLength;
metricsOut.perTargetLOS = losRatio;
metricsOut.worstTargetIndex = worstTargetIndex;
metricsOut.worstTargetUAV = worstTargetUAV;
metricsOut.worstTargetQuality = quality(worstTargetIndex);
metricsOut.worstTargetObservationLength_m = observationLength(worstTargetIndex);
metricsOut.worstTargetLOS = losRatio(worstTargetIndex);
metricsOut.perUAVWorstTargetIndex = worstTargetIndexPerUAV;
metricsOut.perUAVWorstTargetQuality = worstTargetQualityPerUAV;
metricsOut.perUAVWorstTargetObservationLength_m = worstTargetObservationPerUAV;
metricsOut.perUAVWorstTargetLOS = worstTargetLOSPerUAV;
metricsOut.monitoringSatisfied = monitoringSatisfied;
metricsOut.perUAVFinalFeasible = finalFeasible;
metricsOut.perUAVControllerFinal = controllerFinal;
metricsOut.controllerFinalCount = sum(controllerFinal);
metricsOut.allControllerFinal = all(controllerFinal);
metricsOut.perUAVStrictEngineering = strictEngineering;
metricsOut.strictEngineeringCount = sum(strictEngineering);
metricsOut.allUAVStrictEngineering = all(strictEngineering);
metricsOut.perUAVFinalStageGenerations = finalStageGenerations;
metricsOut.perUAVFinalFeasibleRate = finalFeasibleRate;
metricsOut.perUAVMissionDeficit = missionDeficitLocal;
metricsOut.perUAVMissionDeficitComponents = missionDeficitComponentsLocal;
metricsOut.perUAVUnifiedMissionRepairEvents = unifiedMissionRepairEvents;
metricsOut.totalUnifiedMissionRepairEvents = sum(unifiedMissionRepairEvents);
metricsOut.perUAVUnifiedMissionRepairEvaluations = unifiedMissionRepairEvaluations;
metricsOut.totalUnifiedMissionRepairEvaluations = sum(unifiedMissionRepairEvaluations);
metricsOut.perUAVUnifiedMissionRepairAccepted = unifiedMissionRepairAccepted;
metricsOut.totalUnifiedMissionRepairAccepted = sum(unifiedMissionRepairAccepted);
metricsOut.allUAVFinalFeasible = all(finalFeasible);
metricsOut.localAGLValidationStep_m = aglValidationStep_m;
metricsOut.perUAVMinAGL_m = minAGL_m;
metricsOut.perUAVMaxAGL_m = maxAGL_m;
metricsOut.perUAVLowerClearanceOK = lowerClearanceOK;
metricsOut.perUAVUpperAGLOK = upperAGLOK;
metricsOut.fleetMinAGL_m = min(minAGL_m,[],'omitnan');
metricsOut.fleetMaxAGL_m = max(maxAGL_m,[],'omitnan');
metricsOut.lowerClearanceOK = all(lowerClearanceOK);
metricsOut.upperAGLOK = all(upperAGLOK);
metricsOut.allAGLOK = metricsOut.lowerClearanceOK && metricsOut.upperAGLOK;
metricsOut.launchDelays_s = launchDelays(:);
metricsOut.makespan_s = separation.missionEndTime;
metricsOut.minimumSeparation_m = separation.minimumSeparation;
metricsOut.conflictPairCount = separation.conflictPairCount;
metricsOut.nearConflictPairCount = separation.nearConflictPairCount;
metricsOut.collisionFree = separation.collisionFree;
% Local AGL is already a formal hard constraint. The dense 10 m fleet
% validation is therefore included explicitly in mission success so a
% sub-sample terrain-envelope violation cannot be reported as successful.
metricsOut.missionSuccess = metricsOut.allUAVFinalFeasible && ...
    monitoringSatisfied && separation.collisionFree && metricsOut.allAGLOK;
metricsOut.perUAVRuntime_s = runtime;
metricsOut.totalInnerOptimizationTime_s = sum(runtime,'omitnan');
metricsOut.wallClockTime_s = wallClockTime;
metricsOut.perUAVQmin = QminLocal;
metricsOut.perUAVQcritical = QcriticalLocal;

% Deterministic upper-layer allocation diagnostics. These are not
% additional inner objectives; they document the cooperative task split.
metricsOut.allocationScore = localAssignmentField(assignment,'allocationScore',NaN);
metricsOut.allocationTransitMakespanProxy_s = ...
    localAssignmentField(assignment,'transitMakespanProxy_s',NaN);
metricsOut.allocationRouteProxySpread_m = ...
    localAssignmentField(assignment,'routeProxySpread_m',NaN);
metricsOut.allocationLoadCV = localAssignmentField(assignment,'loadCV',NaN);
metricsOut.allocationRiskLoadCV = localAssignmentField(assignment,'riskLoadCV',NaN);
metricsOut.allocationObservabilityLoadCV = ...
    localAssignmentField(assignment,'observabilityLoadCV',NaN);
metricsOut.allocationCriticalObservabilityLoadCV = ...
    localAssignmentField(assignment,'criticalObservabilityLoadCV',NaN);
metricsOut.allocationWorstObservabilitySpread = ...
    localAssignmentField(assignment,'worstObservabilitySpread',NaN);
end

function q = localMonitorVector(b,statsField,fallbackField)
if isfield(b,'monitorStats') && isfield(b.monitorStats,statsField)
    q = b.monitorStats.(statsField);
elseif isfield(b,fallbackField)
    q = b.(fallbackField);
else
    error('multiUAV:MissingMonitoringVector', ...
        'Reported solution is missing per-target monitoring quality.');
end
q = q(:);
end


function [minAGL,maxAGL,lowerOK,upperOK] = localPathAGL(problem,cfg,path,step)
pts = localResample(path,step);
terrain = interp2(problem.gridX,problem.gridY,problem.terrain, ...
    pts(:,1),pts(:,2),'linear');
if any(~isfinite(terrain))
    fallback = interp2(problem.gridX,problem.gridY,problem.terrain, ...
        pts(:,1),pts(:,2),'nearest');
    missing = ~isfinite(terrain);
    terrain(missing) = fallback(missing);
end
if any(~isfinite(terrain))
    minAGL = NaN;
    maxAGL = NaN;
    lowerOK = false;
    upperOK = false;
    return;
end
agl = pts(:,3)-terrain;
minAGL = min(agl);
maxAGL = max(agl);
tol = localCfg(cfg,'constraintTolerance',1e-6);
lowerOK = minAGL >= cfg.safeClearance-tol;
if localCfg(cfg,'enableLocalAGLConstraint',false) && ...
        isfield(cfg,'realMaximumAGL') && isfinite(cfg.realMaximumAGL)
    upperOK = maxAGL <= cfg.realMaximumAGL+tol;
else
    upperOK = true;
end
end

function pts = localResample(path,step)
if size(path,1) < 2
    pts = path;
    return;
end
pts = zeros(0,size(path,2));
for k = 1:size(path,1)-1
    a = path(k,:);
    b = path(k+1,:);
    n = max(2,ceil(norm(b-a)/step)+1);
    q = linspace(0,1,n)';
    block = a+q.*(b-a);
    if k>1, block = block(2:end,:); end
    pts = [pts;block]; %#ok<AGROW>
end
end


function value = localTargetUAV(assignment,targetIndex)
value = NaN;
if isfinite(targetIndex) && targetIndex>=1 && targetIndex<=numel(assignment.targetToUAV)
    value = assignment.targetToUAV(targetIndex);
end
end

function value = localTargetValue(values,targetIndex)
value = NaN;
if isfinite(targetIndex) && targetIndex>=1 && targetIndex<=numel(values)
    value = values(targetIndex);
end
end

function value = localAssignmentField(assignment,name,defaultValue)
if isfield(assignment,name)
    value = assignment.(name);
else
    value = defaultValue;
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
