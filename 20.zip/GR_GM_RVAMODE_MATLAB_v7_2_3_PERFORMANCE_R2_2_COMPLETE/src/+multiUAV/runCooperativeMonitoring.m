function fleetResult = runCooperativeMonitoring(problem,cfg)
%RUNCOOPERATIVEMONITORING Hierarchical cooperative multi-UAV planner.
%
% Architecture:
%   global 30-target scene
%       -> deterministic risk/observability/route-balanced task allocation
%       -> existing GR-GM-RVAMODE optimizer independently per UAV
%       -> temporal launch scheduling
%       -> fleet monitoring/separation aggregation
%
% The inner optimizer is not rewritten. This keeps the validated single-UAV
% path-planning mechanisms and physics consistent with previous experiments.

multiUAV.validateConfig(cfg,problem);
wallTimer = tic;
assignment = multiUAV.allocateTargetsObservabilityAware(problem,cfg);
K = cfg.multiUAVCount;

fprintf('\n=== Multi-UAV task allocation (%d UAVs / %d targets) ===\n', ...
    K,size(problem.monitorTargets,1));
for k = 1:K
    fprintf(['UAV-%d | targets=%2d | critical=%d | load=%.2f | ' ...
        'obsLoad=%.2f | worstObs=%.3f | routeProxy=%.2f km | ' ...
        'transit=%.1f min | global=[%s]\n'], ...
        k,assignment.targetCount(k),assignment.criticalCount(k), ...
        assignment.load(k),assignment.observabilityLoad(k), ...
        assignment.worstObservabilityDifficulty(k), ...
        assignment.routeProxy_m(k)/1000,assignment.transitProxy_s(k)/60, ...
        num2str(assignment.groups{k}));
end

uavResults = cell(K,1);
uavCfg = cell(K,1);
paths = cell(K,1);
uavInfo = repmat(struct('id',0,'globalTargetIndices',[], ...
    'randomSeed',NaN,'numWaypoints',NaN,'reportedSolutionLabel','', ...
    'finalFeasible',false,'controllerFinal',false,'stopGeneration',NaN),K,1);

for k = 1:K
    [subProblem,subCfg] = multiUAV.buildSubProblem( ...
        problem,cfg,assignment,k);
    config.validateConfig(subCfg,subProblem);

    fprintf('\n------------------------------------------------------------\n');
    if isfield(subCfg,'enableStructuredMonitoringEncoding') && ...
            subCfg.enableStructuredMonitoringEncoding
        encLayout = core.structuredMonitoringLayout(subProblem,subCfg);
        encDim = encLayout.dimension;
        encText = sprintf('structured=%dD | ',encDim);
    else
        encText = '';
    end
    fprintf(['Planning UAV-%d/%d | seed=%d | targets=%d | ' ...
        'waypoints=%d | %scritical=%d\n'], ...
        k,K,subCfg.randomSeed,size(subProblem.monitorTargets,1), ...
        subCfg.numWaypoints,encText,numel(subCfg.criticalTargetIndices));
    fprintf('------------------------------------------------------------\n');

    r = core.runGRAHMODE(subProblem,subCfg);
    uavResults{k} = r;
    uavCfg{k} = subCfg;
    paths{k} = r.best(1).path;

    uavInfo(k).id = k;
    uavInfo(k).globalTargetIndices = assignment.groups{k};
    uavInfo(k).randomSeed = subCfg.randomSeed;
    uavInfo(k).numWaypoints = subCfg.numWaypoints;
    uavInfo(k).reportedSolutionLabel = char(r.reportedSolutionLabel);
    uavInfo(k).finalFeasible = r.bestSolutionSatisfiesFinalConstraints;
    uavInfo(k).controllerFinal = r.controllerReachedFinalThresholds;
    uavInfo(k).stopGeneration = r.stopGeneration;
end

[launchDelays,separation] = multiUAV.scheduleLaunchDelays(paths,cfg);
wallClockTime = toc(wallTimer);
fleetMetrics = multiUAV.aggregateFleetMetrics(problem,cfg,assignment, ...
    uavResults,launchDelays,separation,wallClockTime);

fleetResult.assignment = assignment;
fleetResult.uavResults = uavResults;
fleetResult.uavCfg = uavCfg;
fleetResult.uavInfo = uavInfo;
fleetResult.launchDelays = launchDelays;
fleetResult.separation = separation;
fleetResult.metrics = fleetMetrics;
fleetResult.paths = paths;
fleetResult.wallClockTime = wallClockTime;
fleetResult.version = cfg.implementationVersion;

fprintf('\n=== Multi-UAV fleet result ===\n');
fprintf('Mission success              : %d\n',fleetMetrics.missionSuccess);
fprintf('All UAV final feasible       : %d\n',fleetMetrics.allUAVFinalFeasible);
fprintf('Controllers final            : %d / %d\n', ...
    fleetMetrics.controllerFinalCount,fleetMetrics.vehicleCount);
fprintf('Strict engineering           : %d / %d\n', ...
    fleetMetrics.strictEngineeringCount,fleetMetrics.vehicleCount);
fprintf('Sampled AGL min / max        : %.2f / %.2f m (valid=%d)\n', ...
    fleetMetrics.fleetMinAGL_m,fleetMetrics.fleetMaxAGL_m, ...
    fleetMetrics.allAGLOK);
fprintf('Fleet monitoring satisfied   : %d\n',fleetMetrics.monitoringSatisfied);
fprintf('Collision-free after schedule: %d\n',fleetMetrics.collisionFree);
fprintf('Makespan                     : %.1f s\n',fleetMetrics.makespan_s);
fprintf('Minimum separation           : %.1f m\n',fleetMetrics.minimumSeparation_m);
fprintf('Total path length            : %.2f km\n', ...
    fleetMetrics.totalPathLength_m/1000);
fprintf('Total energy score           : %.2f\n',fleetMetrics.totalEnergy);
fprintf('Fleet Qavg / Qmin / Qcrit    : %.3f / %.3f / %.3f\n', ...
    fleetMetrics.Qavg,fleetMetrics.Qmin,fleetMetrics.Qcritical);
fprintf('Unified Mission Deficit      : %.6f\n',fleetMetrics.missionDeficit);
fprintf('Critical obs / LOS           : %.1f m / %.3f\n', ...
    fleetMetrics.criticalMinObservationLength_m, ...
    fleetMetrics.criticalMinLOS);
fprintf('Unified A3 events/evals/acc  : %d / %d / %d\n', ...
    fleetMetrics.totalUnifiedMissionRepairEvents, ...
    fleetMetrics.totalUnifiedMissionRepairEvaluations, ...
    fleetMetrics.totalUnifiedMissionRepairAccepted);
end
