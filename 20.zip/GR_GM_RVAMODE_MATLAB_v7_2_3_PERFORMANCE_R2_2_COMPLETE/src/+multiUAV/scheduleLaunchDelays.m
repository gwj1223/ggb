function [launchDelays,separation] = scheduleLaunchDelays(paths,cfg)
%SCHEDULELAUNCHDELAYS Deterministic temporal deconfliction by launch delay.
%
% Spatial paths are not altered. UAVs are scheduled one by one. For each new
% vehicle, the earliest conflict-free delay is selected. If none exists in
% the configured horizon, the least-conflicting candidate is returned and
% collisionFree remains false in the fleet metrics.

K = numel(paths);
launchDelays = zeros(K,1);
if K <= 1
    separation = multiUAV.evaluateFleetSeparation(paths,launchDelays,cfg);
    return;
end

spacing = localCfg(cfg,'multiUAVMinimumLaunchSpacing',10);
step = cfg.multiUAVLaunchDelayStep;
maxDelay = cfg.multiUAVMaxLaunchDelay;

for i = 2:K
    startDelay = launchDelays(i-1)+spacing;
    candidates = (startDelay:step:maxDelay)';
    if isempty(candidates)
        warning('multiUAV:LaunchHorizonExceeded', ...
            ['Minimum launch spacing pushes UAV %d beyond the nominal ' ...
            'max delay %.1f s. Testing %.1f s to preserve launch order.'], ...
            i,maxDelay,startDelay);
        candidates = startDelay;
    end

    bestDelay = candidates(1);
    bestConflict = inf;
    bestMinSep = -inf;
    safeFound = false;

    for q = 1:numel(candidates)
        trialDelays = launchDelays(1:i);
        trialDelays(i) = candidates(q);
        trialSep = multiUAV.evaluateFleetSeparation( ...
            paths(1:i),trialDelays,cfg);
        if trialSep.collisionFree
            bestDelay = candidates(q);
            safeFound = true;
            break;
        end

        conflict = trialSep.conflictSampleCount;
        minSep = trialSep.minimumSeparation;
        if conflict < bestConflict || ...
                (conflict == bestConflict && minSep > bestMinSep)
            bestConflict = conflict;
            bestMinSep = minSep;
            bestDelay = candidates(q);
        end
    end

    launchDelays(i) = bestDelay;
    if ~safeFound
        warning('multiUAV:TemporalDeconflictionIncomplete', ...
            ['No conflict-free launch time was found for UAV %d up to ' ...
            '%.1f s; using least-conflicting delay %.1f s.'], ...
            i,maxDelay,bestDelay);
    end
end

separation = multiUAV.evaluateFleetSeparation(paths,launchDelays,cfg);
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
