function archive = updateFormalArchive(archive,candidates,maxSize,cfg)
%UPDATEFORMALARCHIVE Strict five-objective archive for formal mission solutions.
%
% This archive is intentionally independent from v7.1.0 mission-band search
% preservation.  Callers must pass candidates that have already been evaluated
% at the formal mission threshold (epsilon_D=0).  Only the feasible rank-1
% five-objective front is retained, then deduplicated and reference-vector
% truncated.  Mission Deficit is never used as an archive objective or tie-break.

all = [archive(:);candidates(:)];
if isempty(all)
    archive = all;
    return;
end

all = selection.assignRankCrowding(all);
front = all([all.rank]==1 & [all.feasible]);
if isempty(front)
    % Defensive: a formal archive must never manufacture a non-formal member.
    archive = all([]);
    return;
end

front = selection.deduplicateArchive(front,cfg.archiveObjectiveTolerance);
if numel(front)>maxSize
    front = selection.referenceVectorTruncate(front,maxSize,cfg);
end
archive = front(:);
end
