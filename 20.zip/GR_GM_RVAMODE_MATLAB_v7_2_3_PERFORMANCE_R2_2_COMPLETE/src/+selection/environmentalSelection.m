function [next,selectedIdx] = environmentalSelection(pop,N,cfg,generation)
%ENVIRONMENTALSELECTION Hierarchical reference-vector selection.
%
% v7.1.0 adds a population-relative mission leader band for unified-mission
% runs.  The hard hierarchy is preserved:
%   S0 scheduled-mission admissible  -> five-objective Pareto/reference vector
%   S1 near-mission leader band      -> five-objective Pareto/reference vector
%   S2 remaining static-feasible     -> five-objective Pareto/reference vector
%   S3 static-infeasible             -> static-CV pressure
%
% S0/S1 form a protected mission-leader quota; the remaining static-feasible
% capacity is deliberately filled by five-objective diversity rather than exact
% D_M ordering.  This prevents the 2N->N selection from degenerating into a
% scalar D_M optimizer when scheduled feasibility is empty. Legacy configs keep
% the original Deb environmental selection exactly.

if nargin < 3 || isempty(cfg), cfg = struct(); end
if nargin < 4 || isempty(generation), generation = 1; end
if isempty(pop)
    next = pop;
    selectedIdx = zeros(0,1);
    return;
end
N = min(max(0,round(N)),numel(pop));

useBand = localCfg(cfg,'enableMissionBandSelection',false) && ...
    localCfg(cfg,'enableUnifiedMissionDeficit',false);
if useBand
    [next,selectedIdx] = localMissionBandSelection(pop,N,cfg,generation);
    return;
end

[next,selectedIdx] = localLegacySelection(pop,N,cfg,generation);
end

function [next,selectedIdx] = localMissionBandSelection(pop,N,cfg,generation)
state = selection.missionBandState(pop,cfg,generation,N);
selectedIdx = zeros(N,1);
selectedCount = 0;

% Tier S0: preserve the current scheduled mission frontier first.
idx = find(state.scheduledAdmissible);
if ~isempty(idx) && selectedCount<N
    take = localObjectivePoolSelection(pop,idx,N-selectedCount,cfg,generation);
    selectedIdx(selectedCount+(1:numel(take))) = take(:);
    selectedCount = selectedCount+numel(take);
end

% Tier S1: only after S0, admit the bounded near-mission leader band.
idx = find(state.bandExtra);
if ~isempty(idx) && selectedCount<N
    take = localObjectivePoolSelection(pop,idx,N-selectedCount,cfg,generation);
    selectedIdx(selectedCount+(1:numel(take))) = take(:);
    selectedCount = selectedCount+numel(take);
end

% Tier S2: restore genuine five-objective exploration for all remaining
% static-feasible candidates. Mission progress is protected by the S0/S1 quota
% already selected above; D_M is not used as an exact scalar ordering here.
idx = find(state.staticFeasible);
idx = setdiff(idx,selectedIdx(1:selectedCount),'stable');
if ~isempty(idx) && selectedCount<N
    take = localObjectivePoolSelection(pop,idx,N-selectedCount,cfg,generation);
    selectedIdx(selectedCount+(1:numel(take))) = take(:);
    selectedCount = selectedCount+numel(take);
end

% Tier S3: only then allow physically infeasible candidates, ordered by static CV.
idx = find(~state.staticFeasible);
if ~isempty(idx) && selectedCount<N
    staticCV = inf(numel(idx),1);
    for k = 1:numel(idx)
        if isfield(pop(idx(k)),'staticCV') && isfinite(pop(idx(k)).staticCV)
            staticCV(k) = pop(idx(k)).staticCV;
        elseif isfield(pop(idx(k)),'cv') && isfinite(pop(idx(k)).cv)
            staticCV(k) = pop(idx(k)).cv;
        end
    end
    [~,ord] = sort(staticCV,'ascend');
    need = min(N-selectedCount,numel(ord));
    take = idx(ord(1:need));
    selectedIdx(selectedCount+(1:need)) = take(:);
    selectedCount = selectedCount+need;
end

% Defensive fallback for incomplete/malformed diagnostic fields.
if selectedCount<N
    remaining = setdiff((1:numel(pop))',selectedIdx(1:selectedCount),'stable');
    need = min(N-selectedCount,numel(remaining));
    selectedIdx(selectedCount+(1:need)) = remaining(1:need);
    selectedCount = selectedCount+need;
end

selectedIdx = selectedIdx(1:selectedCount);
next = pop(selectedIdx);
% Store formal Deb ranks/crowding on the returned individuals.  Search-band
% admissibility is population-relative and must never overwrite ind.feasible.
next = selection.assignRankCrowding(next);
end

function chosen = localObjectivePoolSelection(pop,idx,need,cfg,generation)
% Select within one hierarchy tier using only the five physical objectives.
idx = idx(:);
if isempty(idx) || need<=0
    chosen = zeros(0,1);
    return;
end
if need>=numel(idx)
    chosen = idx;
    return;
end

view = pop(idx);
for i = 1:numel(view)
    view(i).feasible = true;
    view(i).cv = 0;
end
view = selection.assignRankCrowding(view);
if ~localCfg(cfg,'useReferenceVectorEnvironmentalSelection',false)
    [~,ord] = sortrows([[view.rank]' -[view.crowding]'],[1 2]);
    chosen = idx(ord(1:min(need,numel(ord))));
    return;
end

selectedLocal = zeros(need,1);
selectedCount = 0;
rankValues = unique([view.rank]);
rankValues = sort(rankValues(isfinite(rankValues)));
rankValues = rankValues(:)';
for r = rankValues
    front = find([view.rank]==r);
    if selectedCount+numel(front)<=need
        selectedLocal(selectedCount+(1:numel(front))) = front(:);
        selectedCount = selectedCount+numel(front);
        if selectedCount==need, break; end
    else
        slots = need-selectedCount;
        if slots>0
            take = localSplitFrontSelection(view, ...
                selectedLocal(1:selectedCount),front,slots,cfg,generation);
            selectedLocal(selectedCount+(1:numel(take))) = take(:);
            selectedCount = selectedCount+numel(take);
        end
        break;
    end
end

if selectedCount<need
    remaining = setdiff((1:numel(view))',selectedLocal(1:selectedCount),'stable');
    [~,ord] = sortrows([[view(remaining).rank]' -[view(remaining).crowding]'],[1 2]);
    take = remaining(ord(1:min(need-selectedCount,numel(ord))));
    selectedLocal(selectedCount+(1:numel(take))) = take;
    selectedCount = selectedCount+numel(take);
end
chosen = idx(selectedLocal(1:selectedCount));
end

function [next,selectedIdx] = localLegacySelection(pop,N,cfg,generation)
pop = selection.assignRankCrowding(pop);
useRV = isfield(cfg,'useReferenceVectorEnvironmentalSelection') && ...
    cfg.useReferenceVectorEnvironmentalSelection;
if ~useRV || numel(pop)<=N
    [~,ord] = sortrows([[pop.rank]' -[pop.crowding]'],[1 2]);
    selectedIdx = ord(1:min(N,numel(ord)));
    next = pop(selectedIdx);
    next = selection.assignRankCrowding(next);
    return;
end

rankValues = unique([pop.rank]);
rankValues = sort(rankValues(isfinite(rankValues)));
rankValues = rankValues(:)';
selectedIdx = zeros(N,1);
selectedCount = 0;
for r = rankValues
    front = find([pop.rank]==r);
    if selectedCount+numel(front) <= N
        selectedIdx(selectedCount+(1:numel(front))) = front(:);
        selectedCount = selectedCount+numel(front);
        if selectedCount==N, break; end
    else
        need = N-selectedCount;
        if need>0
            chosen = localSplitFrontSelection(pop,selectedIdx(1:selectedCount), ...
                front,need,cfg,generation);
            selectedIdx(selectedCount+(1:numel(chosen))) = chosen(:);
            selectedCount = selectedCount+numel(chosen);
        end
        break;
    end
end

if selectedCount<N
    remaining = setdiff((1:numel(pop))',selectedIdx(1:selectedCount),'stable');
    [~,ord] = sortrows([[pop(remaining).rank]' -[pop(remaining).crowding]'],[1 2]);
    take = remaining(ord(1:min(N-selectedCount,numel(ord))));
    selectedIdx(selectedCount+(1:numel(take))) = take;
    selectedCount = selectedCount+numel(take);
end
selectedIdx = selectedIdx(1:selectedCount);
next = pop(selectedIdx);
next = selection.assignRankCrowding(next);
end

function chosen = localSplitFrontSelection(pop,selected,front,need,cfg,generation)
if need>=numel(front)
    chosen = front(:);
    return;
end
if ~all([pop(front).feasible])
    cv = [pop(front).cv]';
    crowd = [pop(front).crowding]';
    [~,ord] = sortrows([cv -crowd],[1 2]);
    chosen = front(ord(1:need));
    return;
end

pool = [selected(:);front(:)];
obj = vertcat(pop(pool).objectives);
ideal = min(obj,[],1);
nadir = max(obj,[],1);
z = bsxfun(@rdivide,bsxfun(@minus,obj,ideal),nadir-ideal+eps);
M = size(z,2);
H = localCfg(cfg,'referenceVectorDivisions',4);
R = selection.generateReferenceVectors(M,H);
R = bsxfun(@rdivide,R,sqrt(sum(R.^2,2))+eps);
znorm = sqrt(sum(z.^2,2));
zunit = bsxfun(@rdivide,z,znorm+eps);
cosine = max(-1,min(1,zunit*R'));
[maxCos,assoc] = max(cosine,[],2);
angle = acos(maxCos);

rr = max(-1,min(1,R*R'));
rr(1:size(rr,1)+1:end) = -1;
gamma = acos(max(rr,[],2));
gamma = max(gamma,1e-12);
alpha = localCfg(cfg,'referenceVectorAlpha',2);
progress = min(1,max(0,generation/max(localCfg(cfg,'maxGenerations',1),1)));
localGamma = gamma(assoc);
apd = znorm.*(1+M*(progress^alpha).*angle./localGamma);

nSelected = numel(selected);
selectedAssoc = assoc(1:nSelected);
frontAssoc = assoc(nSelected+1:end);
frontAPD = apd(nSelected+1:end);
nicheCount = zeros(size(R,1),1);
if ~isempty(selectedAssoc)
    nicheCount = accumarray(selectedAssoc,1,[size(R,1) 1]);
end
available = true(numel(front),1);
chosenLocal = zeros(need,1);
chosenCount = 0;
while chosenCount<need && any(available)
    activeNiches = unique(frontAssoc(available));
    activeCounts = nicheCount(activeNiches);
    minCount = min(activeCounts);
    nicheId = activeNiches(find(activeCounts==minCount,1,'first'));
    candidates = find(available & frontAssoc==nicheId);
    [~,q] = min(frontAPD(candidates));
    idx = candidates(q);
    chosenCount = chosenCount+1;
    chosenLocal(chosenCount) = idx;
    available(idx) = false;
    nicheCount(nicheId) = nicheCount(nicheId)+1;
end

if chosenCount<need
    remaining = find(available);
    [~,ord] = sort(frontAPD(remaining),'ascend');
    take = remaining(ord(1:min(need-chosenCount,numel(ord))));
    chosenLocal(chosenCount+(1:numel(take))) = take;
    chosenCount = chosenCount+numel(take);
end
chosen = front(chosenLocal(1:chosenCount));
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
