function [solution,index,cost,details] = ...
    selectMinimumPhysicalCostSolution(archive,cfg)
%SELECTMINIMUMPHYSICALCOSTSOLUTION Lowest physical cost with safe fallback.
if isempty(archive)
    error('selection:EmptyArchive','Archive is empty.');
end
archive = archive(:);
[strictMask,strictDetails] = selection.engineeringLimitMask( ...
    archive,cfg,'strict',archive);
[relaxedMask,relaxedDetails] = selection.engineeringLimitMask( ...
    archive,cfg,'relaxed',archive);

if any(strictMask)
    candidateIndex = find(strictMask);
    level = 'strict_engineering';
elseif any(relaxedMask)
    candidateIndex = find(relaxedMask);
    level = 'relaxed_engineering';
else
    cv = reshape([archive.cv],[],1);
    candidateIndex = find(isfinite(cv) & ...
        cv<=localCfg(cfg,'constraintTolerance',1e-8));
    if isempty(candidateIndex), candidateIndex = (1:numel(archive))'; end
    level = 'final_feasible_fallback';
end

candidateCost = metrics.finalStageCostIndicator( ...
    archive(candidateIndex),cfg);
[bestCost,localIndex] = min(candidateCost);
localIndex = localIndex(1);
index = candidateIndex(localIndex);
solution = archive(index);
cost = bestCost;
details.level = level;
details.strictMask = strictMask;
details.relaxedMask = relaxedMask;
details.strictLimits = strictDetails;
details.relaxedLimits = relaxedDetails;
details.selectedEngineeringSatisfied = strictMask(index);
details.selectedRelaxedSatisfied = relaxedMask(index);
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
