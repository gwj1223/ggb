function tf = isBetterDeb(a,b)
%ISBETTERDEB Deb comparison with scale-free multiobjective tie breaking.
if a.feasible && ~b.feasible
    tf = true;
    return;
end
if ~a.feasible && b.feasible
    tf = false;
    return;
end
if ~a.feasible && ~b.feasible
    tolerance = 1e-10;
    if a.cv < b.cv-tolerance
        tf = true;
        return;
    elseif a.cv > b.cv+tolerance
        tf = false;
        return;
    end
    meritA = localMonitoringMerit(a);
    meritB = localMonitoringMerit(b);
    if meritA > meritB+tolerance
        tf = true;
    elseif meritA < meritB-tolerance
        tf = false;
    elseif numel(a.objectives)>=5 && numel(b.objectives)>=5 && ...
            abs(a.objectives(5)-b.objectives(5))>tolerance
        tf = a.objectives(5)<b.objectives(5);
    else
        tf = localScaleFreePreference(a.objectives,b.objectives)<0;
    end
    return;
end

% Pareto dominance remains the primary rule for feasible paths.
aDominates = all(a.objectives<=b.objectives) && any(a.objectives<b.objectives);
bDominates = all(b.objectives<=a.objectives) && any(b.objectives<a.objectives);
if aDominates
    tf = true;
elseif bDominates
    tf = false;
else
    % Raw objective sums are dimensionally biased (energy dominates the
    % other four objectives). Relative pairwise differences are scale-free.
    tf = localScaleFreePreference(a.objectives,b.objectives)<0;
end
end

function score = localScaleFreePreference(a,b)
a = double(a(:)');
b = double(b(:)');
den = abs(a)+abs(b)+eps;
relativeDifference = (a-b)./den;
score = mean(relativeDifference);
if abs(score)<=1e-14
    % Deterministic secondary comparison without restoring unit bias.
    score = max(relativeDifference)+min(relativeDifference);
end
end

function merit = localMonitoringMerit(ind)
merit = 0;
if isfield(ind,'monitorStats') && ~isempty(ind.monitorStats)
    s = ind.monitorStats;
    if isfield(s,'minimumQuality') && isfinite(s.minimumQuality)
        merit = merit+s.minimumQuality;
    end
    if isfield(s,'searchMinimumQuality') && isfinite(s.searchMinimumQuality)
        merit = merit+0.35*s.searchMinimumQuality;
    end
    if isfield(s,'criticalQuality') && isfinite(s.criticalQuality)
        merit = merit+0.25*s.criticalQuality;
    end
    if isfield(s,'searchCriticalQuality') && isfinite(s.searchCriticalQuality)
        merit = merit+0.10*s.searchCriticalQuality;
    end
    if isfield(s,'minimumCriticalObservationLength') && ...
            isfinite(s.minimumCriticalObservationLength)
        merit = merit+0.05*tanh(s.minimumCriticalObservationLength/12);
    end
    if isfield(s,'minimumCriticalLOSRatio') && ...
            isfinite(s.minimumCriticalLOSRatio)
        merit = merit+0.10*s.minimumCriticalLOSRatio;
    end
end
end
