function R = generateReferenceVectors(M,H)
%GENERATEREFERENCEVECTORS Cached Das-Dennis reference directions.
persistent cachedM cachedH cachedR
if ~isempty(cachedR) && isequal(cachedM,M) && isequal(cachedH,H)
    R = cachedR;
    return;
end
R = compositions(H,M)/H;
R = R(sqrt(sum(R.^2,2))>0,:);
R = bsxfun(@rdivide,R,sqrt(sum(R.^2,2))+eps);
cachedM = M; cachedH = H; cachedR = R;
end

function C = compositions(total,parts)
if parts==1, C = total; return; end
blocks = cell(total+1,1);
for k = 0:total
    tail = compositions(total-k,parts-1);
    blocks{k+1} = [repmat(k,size(tail,1),1),tail];
end
C = vertcat(blocks{:});
end
