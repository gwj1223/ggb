function archive = updateArchive(archive,pop,maxSize,cfg,generation)
%UPDATEARCHIVE Search archive with v7.1.0 mission-band diversity.
%
% In unified-mission + mission-band runs this archive is a SEARCH archive:
% static-feasible mission leaders are kept by five-objective nondominance and
% reference-vector truncation even when no candidate satisfies the scheduled
% mission epsilon.  The separate finalArchive in runGRAHMODE remains the sole
% formal D_M=0 archive used for final reporting/stopping.
%
% Legacy configurations retain the historical feasible-front archive.

if nargin < 5 || isempty(generation), generation = 1; end
all = [archive(:);pop(:)];
if isempty(all), archive = all; return; end

useBand = localCfg(cfg,'enableMissionBandSelection',false) && ...
    localCfg(cfg,'enableUnifiedMissionDeficit',false);
if ~useBand
    archive = localLegacyArchive(all,maxSize,cfg);
    return;
end

state = selection.missionBandState(all,cfg,generation, ...
    localCfg(cfg,'populationSize',numel(pop)));
if state.staticCount==0
    staticCV = inf(numel(all),1);
    for i = 1:numel(all)
        if isfield(all(i),'staticCV') && isfinite(all(i).staticCV)
            staticCV(i) = all(i).staticCV;
        elseif isfield(all(i),'cv') && isfinite(all(i).cv)
            staticCV(i) = all(i).cv;
        end
    end
    [~,i] = min(staticCV);
    archive = all(i);
    return;
end

poolIdx = find(state.searchAdmissible);
if isempty(poolIdx)
    % Defensive only: missionBandState guarantees at least one leader when a
    % static-feasible individual exists.
    staticIdx = find(state.staticFeasible);
    [~,q] = min(state.missionDeficit(staticIdx));
    archive = all(staticIdx(q));
    return;
end

% Preserve hierarchy inside the search archive too: scheduled-admissible
% objective leaders are retained first; near-band leaders fill only remaining
% capacity.  If S0 is empty, the entire band supplies the search front.
scheduledIdx = find(state.scheduledAdmissible);
extraIdx = find(state.bandExtra);
if isempty(scheduledIdx)
    front = localObjectiveFront(all(poolIdx));
    front = selection.deduplicateArchive(front,cfg.archiveObjectiveTolerance);
    if numel(front)>maxSize
        front = selection.referenceVectorTruncate(front,maxSize,cfg);
    end
else
    scheduledFront = localObjectiveFront(all(scheduledIdx));
    scheduledFront = selection.deduplicateArchive( ...
        scheduledFront,cfg.archiveObjectiveTolerance);
    if numel(scheduledFront)>=maxSize
        front = selection.referenceVectorTruncate(scheduledFront,maxSize,cfg);
    else
        front = scheduledFront(:);
        capacity = maxSize-numel(front);
        if capacity>0 && ~isempty(extraIdx)
            extraFront = localObjectiveFront(all(extraIdx));
            extraFront = selection.deduplicateArchive( ...
                extraFront,cfg.archiveObjectiveTolerance);
            if numel(extraFront)>capacity
                extraFront = selection.referenceVectorTruncate(extraFront,capacity,cfg);
            end
            front = [front(:);extraFront(:)];
        end
    end
end

% Preserve one explicit current best-D leader. This is not historical memory:
% it is reselected from the current archive+population pool every update.
[~,leaderLocal] = min(state.missionDeficit(poolIdx));
leader = all(poolIdx(leaderLocal));
if localContainsGenes(front,leader)
    % Put the current best-D leader first so objective deduplication retains it.
    keep = true(numel(front),1);
    for i=1:numel(front)
        if numel(front(i).genes)==numel(leader.genes) && ...
                max(abs(front(i).genes(:)-leader.genes(:)))<=1e-12
            keep(i)=false;
            break;
        end
    end
    front = [leader(:);front(keep)];
else
    front = [leader(:);front(:)];
end
front = selection.deduplicateArchive(front,cfg.archiveObjectiveTolerance);
if numel(front)>maxSize
    if maxSize<=1
        front = leader;
    else
        rest = front(2:end);
        rest = selection.referenceVectorTruncate(rest,maxSize-1,cfg);
        front = [front(1);rest(:)];
    end
end
archive = front(:);
end

function front = localObjectiveFront(pool)
if isempty(pool)
    front = pool;
    return;
end
view = pool;
for i = 1:numel(view)
    view(i).feasible = true;
    view(i).cv = 0;
end
view = selection.assignRankCrowding(view);
front = pool([view.rank]==1);
front = front(:);
end

function archive = localLegacyArchive(all,maxSize,cfg)
all = selection.assignRankCrowding(all);
front = all([all.rank]==1 & [all.feasible]);
if isempty(front)
    [~,i] = min([all.cv]);
    archive = all(i);
    return;
end
front = selection.deduplicateArchive(front,cfg.archiveObjectiveTolerance);
if numel(front)>maxSize
    front = selection.referenceVectorTruncate(front,maxSize,cfg);
end
archive = front(:);
end

function tf = localContainsGenes(pop,ind)
tf = false;
if isempty(pop) || ~isfield(ind,'genes') || isempty(ind.genes), return; end
for i = 1:numel(pop)
    if isfield(pop(i),'genes') && numel(pop(i).genes)==numel(ind.genes) && ...
            max(abs(pop(i).genes(:)-ind.genes(:)))<=1e-12
        tf = true;
        return;
    end
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
