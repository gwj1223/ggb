function best = selectMonitoringCompromise(archive,cfg)
%SELECTMONITORINGCOMPROMISE Select a robust final-feasible low-cost path.
%
% Monitoring requirements are treated as constraints with small margins.
% Among paths clearing those margins, the representative is selected mainly
% by detour, risk, energy and smoothness rather than excessive quality.
if isempty(archive)
    error('selection:EmptyArchive','Archive is empty.');
end
archive = archive(:);
feasible = archive([archive.cv] <= cfg.constraintTolerance);
if isempty(feasible)
    cv = reshape([archive.cv],[],1);
    cv(~isfinite(cv)) = inf;
    [~,idx] = min(cv);
    best = archive(idx(1));
    return;
end

candidates = feasible;
marginMin = localCfg(cfg,'finalRepresentativeMinimumMargin',0.03);
marginCritical = localCfg(cfg,'finalRepresentativeCriticalMargin',0.03);
marginObs = localCfg(cfg,'finalRepresentativeObservationMargin',0.50);
marginLOS = localCfg(cfg,'finalRepresentativeLOSMargin',0.02);
safeMinimum = max(cfg.monitorMinTargetQuality+marginMin, ...
    localCfg(cfg,'finalStageSafeMinimumQuality',0.65));
safeCritical = max(cfg.monitorCriticalMinQuality+marginCritical, ...
    localCfg(cfg,'finalStageSafeCriticalQuality',0.75));
safeObservation = max(cfg.monitorCriticalMinObservationLength+marginObs, ...
    localCfg(cfg,'finalStageSafeObservationLength',9.0));
safeLOS = max(cfg.monitorCriticalMinLOSRatio+marginLOS, ...
    localCfg(cfg,'finalStageSafeLOSRatio',0.50));
maxDispersion = localCfg(cfg,'finalStageMaxMonitoringDispersion',0.22);
mask = arrayfun(@(x) ...
    x.monitorStats.minimumQuality >= ...
        safeMinimum-cfg.constraintTolerance && ...
    x.monitorStats.criticalQuality >= ...
        safeCritical-cfg.constraintTolerance && ...
    x.monitorStats.minimumCriticalObservationLength >= ...
        safeObservation-cfg.constraintTolerance && ...
    x.monitorStats.minimumCriticalLOSRatio >= ...
        safeLOS-cfg.constraintTolerance && ...
    x.monitorStats.dispersionPenalty <= ...
        maxDispersion+cfg.constraintTolerance,feasible);
if any(mask)
    candidates = feasible(mask);
end
candidates = candidates(:);
if localCfg(cfg,'finalRepresentativePreferSmoothnessTarget',true)
    smoothTarget = localCfg(cfg,'finalStageSmoothnessTargetLimit',0.135);
    smoothMask = arrayfun(@(x)x.objectives(4) <= ...
        smoothTarget+cfg.constraintTolerance,candidates);
    if any(smoothMask)
        candidates = candidates(smoothMask);
    end
end

obj = vertcat(candidates.objectives);
cost = obj(:,1:4);
normalizedCost = localNormalize(cost);
w = localCfg(cfg,'finalRepresentativeCostWeights',[0.34 0.26 0.25 0.15]);
w = max(reshape(w,1,[]),0);
w = w/max(sum(w),eps);
score = sqrt(sum(bsxfun(@times,normalizedCost.^2,w),2));

% Objective five is used only as a weak tie breaker after final feasibility.
monitorTie = localNormalize(obj(:,5));
score = score+localCfg(cfg,'finalRepresentativeMonitoringTieWeight',0.03)* ...
    monitorTie;
score(~isfinite(score)) = inf;
[~,idx] = min(score);
best = candidates(idx(1));
end

function z = localNormalize(x)
lo = min(x,[],1);
hi = max(x,[],1);
z = bsxfun(@rdivide,bsxfun(@minus,x,lo),hi-lo+eps);
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
