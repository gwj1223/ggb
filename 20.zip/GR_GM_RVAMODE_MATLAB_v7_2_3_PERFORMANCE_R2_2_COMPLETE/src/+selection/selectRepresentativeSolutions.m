function reps = selectRepresentativeSolutions( ...
    archive,cfg,commonArchive,bestPhysicalSolution)
%SELECTREPRESENTATIVESOLUTIONS Interpretable Pareto representatives.
if isempty(archive)
    error('selection:EmptyArchive','Archive is empty.');
end
archive = archive(:);
feasible = archive([archive.cv] <= cfg.constraintTolerance);
if isempty(feasible), feasible = archive; end
if nargin < 3 || isempty(commonArchive)
    commonSource = feasible;
else
    commonSource = commonArchive(:);
    commonMask = evaluation.checkFinalMonitoringFeasibility(commonSource,cfg);
    commonSource = commonSource(reshape(commonMask,[],1) & ...
        reshape([commonSource.cv],[],1)<=cfg.constraintTolerance);
    if isempty(commonSource), commonSource = feasible; end
end

obj = vertcat(feasible.objectives);
[~,iLength] = min(obj(:,1));
[~,iRisk] = min(obj(:,2));
[~,iMonitor] = min(obj(:,5));

mn = min(obj,[],1);
mx = max(obj,[],1);
z = (obj-mn)./(mx-mn+eps);
if isfield(cfg,'balancedRepresentativeWeights')
    w = cfg.balancedRepresentativeWeights(:)';
else
    w = ones(1,size(z,2));
end
w = w/max(sum(w),eps);
balancedScore = sqrt(sum(bsxfun(@times,z.^2,w),2));
[~,iBalanced] = min(balancedScore);
[knee,~,~] = selection.selectKneeSolution(feasible,cfg);

% Include the historical best-cost path as a candidate, but do not trust it
% blindly: it must pass the same report-level engineering filter as the
% current Common Archive.
physicalSource = commonSource;
if nargin >= 4 && ~isempty(bestPhysicalSolution)
    physicalSource = [physicalSource(:);bestPhysicalSolution(1)];
end
[minimumPhysical,~,~,physicalDetails] = ...
    selection.selectMinimumPhysicalCostSolution(physicalSource,cfg);
[commonKnee,~,~,commonKneeDetails] = ...
    selection.selectCommonKneeSolution(commonSource,cfg);
[riskBalanced,~,~,riskBalancedDetails] = ...
    selection.selectRiskBalancedSolution(physicalSource,cfg);

reps.labels = {'MinimumDetour';'MinimumRisk'; ...
    'MonitoringPriority';'Balanced';'KneePoint'; ...
    'MinimumPhysicalCost';'CommonKneePoint';'RiskBalanced'};
reps.solutions = [feasible(iLength);feasible(iRisk); ...
    feasible(iMonitor);feasible(iBalanced);knee; ...
    minimumPhysical;commonKnee;riskBalanced];

strictMask = selection.engineeringLimitMask( ...
    reps.solutions,cfg,'strict',commonSource);
relaxedMask = selection.engineeringLimitMask( ...
    reps.solutions,cfg,'relaxed',commonSource);
finalMask = localFinalMask(reps.solutions,cfg);
reps.engineeringSatisfied = reshape(strictMask,[],1);
reps.relaxedEngineeringSatisfied = reshape(relaxedMask,[],1);
reps.finalConstraintsSatisfied = reshape(finalMask,[],1);
reps.physicalCost = metrics.finalStageCostIndicator(reps.solutions,cfg);
reps.selectionLevels = repmat({'archive_extreme'},numel(reps.labels),1);
reps.selectionLevels{4} = 'normalized_balanced';
reps.selectionLevels{5} = 'internal_knee';
reps.selectionLevels{6} = physicalDetails.level;
reps.selectionLevels{7} = commonKneeDetails.level;
reps.selectionLevels{8} = riskBalancedDetails.level;
end

function mask = localFinalMask(archive,cfg)
archive = archive(:);
mask = reshape([archive.cv],[],1)<=cfg.constraintTolerance;
if isfield(archive,'monitorStats') && isfield(archive,'staticCV')
    try
        missionMask = evaluation.checkFinalMonitoringFeasibility(archive,cfg);
        mask = mask & reshape(missionMask,[],1);
    catch
    end
end
end
