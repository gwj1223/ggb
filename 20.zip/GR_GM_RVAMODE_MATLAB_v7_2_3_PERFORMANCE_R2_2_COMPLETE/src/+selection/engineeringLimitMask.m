function [mask,details] = engineeringLimitMask(archive,cfg,mode,referenceArchive)
%ENGINEERINGLIMITMASK Report-level flight and monitoring quality filter.
%
% The optimization archive intentionally preserves a wide Pareto set. This
% filter is applied only when selecting paths for engineering reporting. It
% therefore does not remove valid Pareto solutions from any archive.
if nargin < 3 || isempty(mode), mode = 'strict'; end
if nargin < 4 || isempty(referenceArchive), referenceArchive = archive; end
if isempty(archive)
    mask = false(0,1);
    details = localEmptyDetails(mode);
    return;
end
archive = archive(:);
referenceArchive = referenceArchive(:);
N = numel(archive);
tol = localCfg(cfg,'constraintTolerance',1e-8);

obj = localObjectives(archive);
detour = obj(:,1);
riskObjective = obj(:,2);
meanRisk = localRiskMetric(archive,'meanRisk',riskObjective);
tailRisk = localRiskMetric(archive,'tailRisk',riskObjective);
energy = obj(:,3);
smoothness = obj(:,4);
cv = localNumericField(archive,'cv',inf);
baseMask = isfinite(cv) & cv <= tol;

% Use the final mission constraints when the complete monitoring schema is
% available. Lightweight unit-test structures still fall back to CV only.
finalMask = baseMask;
if localHasMonitoringSchema(archive)
    try
        missionMask = evaluation.checkFinalMonitoringFeasibility(archive,cfg);
        finalMask = finalMask & reshape(missionMask,[],1);
    catch
        % Keep the selector robust for legacy or deliberately reduced test
        % structures; real evaluated individuals use the branch above.
    end
end

minimumQuality = localMonitorMetric(archive,'minimumQuality',inf);
criticalQuality = localMonitorMetric(archive,'criticalQuality',inf);
observationLength = localMonitorMetric(archive, ...
    'minimumCriticalObservationLength',inf);
losRatio = localMonitorMetric(archive,'minimumCriticalLOSRatio',inf);
dispersion = localMonitorMetric(archive,'dispersionPenalty',0);

switch lower(char(mode))
    case 'strict'
        smoothLimit = localCfg(cfg,'finalReportedSmoothnessLimit',0.145);
        detourLimit = localCfg(cfg,'finalReportedMaximumDetour',1.34);
        energyRatio = localCfg(cfg, ...
            'finalReportedMaximumEnergyRatioToBest',1.08);
        minimumLimit = max(localCfg(cfg, ...
            'finalStageSafeMinimumQuality',0.65), ...
            localCfg(cfg,'monitorMinTargetQuality',0));
        criticalLimit = max(localCfg(cfg, ...
            'finalStageSafeCriticalQuality',0.75), ...
            localCfg(cfg,'monitorCriticalMinQuality',0));
        observationLimit = max(localCfg(cfg, ...
            'finalStageSafeObservationLength',9.0), ...
            localCfg(cfg,'monitorCriticalMinObservationLength',0));
        losLimit = max(localCfg(cfg,'finalStageSafeLOSRatio',0.50), ...
            localCfg(cfg,'monitorCriticalMinLOSRatio',0));
        dispersionLimit = localCfg(cfg, ...
            'finalReportedMaximumMonitoringDispersion', ...
            localCfg(cfg,'finalStageMaxMonitoringDispersion',0.22));
        riskObjectiveLimit = localCfg(cfg, ...
            'finalReportedMaximumRiskObjective',0.34);
        meanRiskLimit = localCfg(cfg, ...
            'finalReportedMaximumMeanRisk',0.25);
        tailRiskLimit = localCfg(cfg, ...
            'finalReportedMaximumTailRisk',0.56);
    case 'relaxed'
        smoothLimit = localCfg(cfg, ...
            'finalReportedRelaxedSmoothnessLimit',0.18);
        detourLimit = localCfg(cfg, ...
            'finalReportedRelaxedMaximumDetour',1.42);
        energyRatio = localCfg(cfg, ...
            'finalReportedRelaxedMaximumEnergyRatioToBest',1.18);
        minimumLimit = localCfg(cfg,'monitorMinTargetQuality',0);
        criticalLimit = localCfg(cfg,'monitorCriticalMinQuality',0);
        observationLimit = localCfg(cfg, ...
            'monitorCriticalMinObservationLength',0);
        losLimit = localCfg(cfg,'monitorCriticalMinLOSRatio',0);
        dispersionLimit = localCfg(cfg, ...
            'finalReportedRelaxedMaximumMonitoringDispersion',0.28);
        riskObjectiveLimit = localCfg(cfg, ...
            'finalReportedRelaxedMaximumRiskObjective',0.38);
        meanRiskLimit = localCfg(cfg, ...
            'finalReportedRelaxedMaximumMeanRisk',0.29);
        tailRiskLimit = localCfg(cfg, ...
            'finalReportedRelaxedMaximumTailRisk',0.62);
    otherwise
        error('selection:UnknownEngineeringMode', ...
            'Unknown engineering filter mode: %s',char(mode));
end

referenceObj = localObjectives(referenceArchive);
referenceRiskObjective = referenceObj(:,2);
referenceMeanRisk = localRiskMetric(referenceArchive,'meanRisk', ...
    referenceRiskObjective);
referenceTailRisk = localRiskMetric(referenceArchive,'tailRisk', ...
    referenceRiskObjective);
referenceEnergy = referenceObj(:,3);
referenceCV = localNumericField(referenceArchive,'cv',inf);
% Estimate the energy baseline only from geometrically plausible paths. An
% extremely short but sharply kinked archive extreme must not make the
% report-level energy band impossible for otherwise safe solutions.
referenceSmoothLimit = localCfg(cfg, ...
    'finalReportedRelaxedSmoothnessLimit',0.18);
referenceDetourLimit = localCfg(cfg, ...
    'finalReportedRelaxedMaximumDetour',1.42);
referenceRiskLimit = localCfg(cfg, ...
    'finalReportedRelaxedMaximumRiskObjective',0.38);
referenceMeanRiskLimit = localCfg(cfg, ...
    'finalReportedRelaxedMaximumMeanRisk',0.29);
referenceTailRiskLimit = localCfg(cfg, ...
    'finalReportedRelaxedMaximumTailRisk',0.62);
referenceValid = isfinite(referenceEnergy) & isfinite(referenceCV) & ...
    referenceCV <= tol & ...
    referenceObj(:,1) <= referenceDetourLimit+tol & ...
    referenceRiskObjective <= referenceRiskLimit+tol & ...
    referenceMeanRisk <= referenceMeanRiskLimit+tol & ...
    referenceTailRisk <= referenceTailRiskLimit+tol & ...
    referenceObj(:,4) <= referenceSmoothLimit+tol;
if any(referenceValid)
    bestReferenceEnergy = min(referenceEnergy(referenceValid));
elseif any(isfinite(energy))
    bestReferenceEnergy = min(energy(isfinite(energy)));
else
    bestReferenceEnergy = inf;
end
energyLimit = bestReferenceEnergy*energyRatio;
absoluteEnergyLimit = localCfg(cfg,'finalReportedMaximumEnergy',inf);
energyLimit = min(energyLimit,absoluteEnergyLimit);

mask = finalMask & ...
    detour <= detourLimit+tol & ...
    riskObjective <= riskObjectiveLimit+tol & ...
    meanRisk <= meanRiskLimit+tol & ...
    tailRisk <= tailRiskLimit+tol & ...
    energy <= energyLimit+tol & ...
    smoothness <= smoothLimit+tol & ...
    minimumQuality >= minimumLimit-tol & ...
    criticalQuality >= criticalLimit-tol & ...
    observationLength >= observationLimit-tol & ...
    losRatio >= losLimit-tol & ...
    dispersion <= dispersionLimit+tol;
mask = reshape(mask,N,1);

% Expose all diagnostics so exports and tests can explain why a candidate
% was accepted or rejected.
details.mode = char(mode);
details.finalMask = finalMask;
details.detour = detour;
details.riskObjective = riskObjective;
details.meanRisk = meanRisk;
details.tailRisk = tailRisk;
details.energy = energy;
details.smoothness = smoothness;
details.minimumQuality = minimumQuality;
details.criticalQuality = criticalQuality;
details.observationLength = observationLength;
details.losRatio = losRatio;
details.dispersion = dispersion;
details.detourLimit = detourLimit;
details.riskObjectiveLimit = riskObjectiveLimit;
details.meanRiskLimit = meanRiskLimit;
details.tailRiskLimit = tailRiskLimit;
details.energyLimit = energyLimit;
details.smoothnessLimit = smoothLimit;
details.minimumQualityLimit = minimumLimit;
details.criticalQualityLimit = criticalLimit;
details.observationLengthLimit = observationLimit;
details.losRatioLimit = losLimit;
details.dispersionLimit = dispersionLimit;
end

function obj = localObjectives(archive)
N = numel(archive);
obj = inf(N,5);
for i = 1:N
    if isfield(archive(i),'objectives') && ...
            numel(archive(i).objectives) >= 4
        value = reshape(archive(i).objectives,1,[]);
        obj(i,1:min(5,numel(value))) = value(1:min(5,numel(value)));
    end
    if isfield(archive(i),'pathMetrics') && ...
            isfield(archive(i).pathMetrics,'detourRatio') && ...
            isfinite(archive(i).pathMetrics.detourRatio)
        obj(i,1) = archive(i).pathMetrics.detourRatio;
    end
    if isfield(archive(i),'energyStats') && ...
            isfield(archive(i).energyStats,'total') && ...
            isfinite(archive(i).energyStats.total)
        obj(i,3) = archive(i).energyStats.total;
    end
end
end

function values = localNumericField(archive,name,defaultValue)
values = defaultValue*ones(numel(archive),1);
if isempty(archive) || ~isfield(archive,name), return; end
for i = 1:numel(archive)
    value = archive(i).(name);
    if isnumeric(value) && isscalar(value), values(i) = value; end
end
end

function values = localMonitorMetric(archive,name,defaultValue)
values = defaultValue*ones(numel(archive),1);
if isempty(archive) || ~isfield(archive,'monitorStats'), return; end
for i = 1:numel(archive)
    if isstruct(archive(i).monitorStats) && ...
            isfield(archive(i).monitorStats,name)
        value = archive(i).monitorStats.(name);
        if isnumeric(value) && isscalar(value) && isfinite(value)
            values(i) = value;
        end
    end
end
end

function values = localRiskMetric(archive,name,fallback)
values = reshape(fallback,[],1);
if isempty(archive) || ~isfield(archive,'riskStats'), return; end
for i = 1:numel(archive)
    if isstruct(archive(i).riskStats) && ...
            isfield(archive(i).riskStats,name)
        value = archive(i).riskStats.(name);
        if isnumeric(value) && isscalar(value) && isfinite(value)
            values(i) = value;
        end
    end
end
end

function tf = localHasMonitoringSchema(archive)
tf = ~isempty(archive) && isfield(archive,'monitorStats') && ...
    isfield(archive,'monitorPerTarget') && isfield(archive,'staticCV');
end

function details = localEmptyDetails(mode)
details = struct('mode',char(mode),'finalMask',false(0,1), ...
    'detour',zeros(0,1),'riskObjective',zeros(0,1), ...
    'meanRisk',zeros(0,1),'tailRisk',zeros(0,1), ...
    'energy',zeros(0,1), ...
    'smoothness',zeros(0,1),'minimumQuality',zeros(0,1), ...
    'criticalQuality',zeros(0,1),'observationLength',zeros(0,1), ...
    'losRatio',zeros(0,1),'dispersion',zeros(0,1), ...
    'detourLimit',NaN,'riskObjectiveLimit',NaN, ...
    'meanRiskLimit',NaN,'tailRiskLimit',NaN, ...
    'energyLimit',NaN,'smoothnessLimit',NaN, ...
    'minimumQualityLimit',NaN,'criticalQualityLimit',NaN, ...
    'observationLengthLimit',NaN,'losRatioLimit',NaN, ...
    'dispersionLimit',NaN);
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
