function selected = referenceVectorTruncate(all,maxSize,cfg)
%REFERENCEVECTORTRUNCATE Reference-niche archive preservation.
obj = vertcat(all.objectives);
mn = min(obj,[],1);
z = bsxfun(@rdivide,bsxfun(@minus,obj,mn),max(obj,[],1)-mn+eps);
R = selection.generateReferenceVectors(size(z,2), ...
    cfg.referenceVectorDivisions);
zn = bsxfun(@rdivide,z,sqrt(sum(z.^2,2))+eps);
[~,assoc] = max(zn*R',[],2);
associatedR = R(assoc,:);
projection = sum(z.*associatedR,2);
perp = sqrt(sum((z-bsxfun(@times,projection,associatedR)).^2,2));
selectedIdx = zeros(min(maxSize,numel(all)),1);
selectedCount = 0;
used = false(size(z,1),1);
niche = zeros(size(R,1),1);
while selectedCount<min(maxSize,numel(all))
    active = unique(assoc(~used));
    if isempty(active), break; end
    counts = niche(active);
    minCount = min(counts);
    candidateNiches = active(counts==minCount);
    nicheId = candidateNiches(randi(numel(candidateNiches)));
    candidates = find(~used & assoc==nicheId);
    if niche(nicheId)==0
        [~,q] = min(perp(candidates));
        idx = candidates(q);
    else
        idx = candidates(randi(numel(candidates)));
    end
    selectedCount = selectedCount+1;
    selectedIdx(selectedCount) = idx;
    used(idx) = true;
    niche(nicheId) = niche(nicheId)+1;
end
selectedIdx = selectedIdx(1:selectedCount);
if selectedCount<maxSize
    remaining = find(~used);
    [~,order] = sort([all(remaining).crowding],'descend');
    need = min(maxSize-selectedCount,numel(order));
    selectedIdx = [selectedIdx;remaining(order(1:need))]; %#ok<AGROW>
end
selected = all(selectedIdx);
end
