function [solution,index,score,details] = selectCommonKneeSolution(archive,cfg)
%SELECTCOMMONKNEESOLUTION Engineering-safe knee in common objectives.
if isempty(archive)
    error('selection:EmptyArchive','Archive is empty.');
end
archive = archive(:);
[strictMask,strictDetails] = selection.engineeringLimitMask( ...
    archive,cfg,'strict',archive);
[relaxedMask,relaxedDetails] = selection.engineeringLimitMask( ...
    archive,cfg,'relaxed',archive);

if any(strictMask)
    candidateIndex = find(strictMask);
    level = 'strict_engineering';
elseif any(relaxedMask)
    candidateIndex = find(relaxedMask);
    level = 'relaxed_engineering';
else
    finalMask = evaluation.checkFinalMonitoringFeasibility(archive,cfg);
    cv = reshape([archive.cv],[],1);
    candidateIndex = find(reshape(finalMask,[],1) & ...
        cv<=localCfg(cfg,'constraintTolerance',1e-8));
    if isempty(candidateIndex), candidateIndex = (1:numel(archive))'; end
    level = 'final_feasible_fallback';
end

candidates = archive(candidateIndex);
F = metrics.commonObjectiveMatrix(candidates);
lo = min(F,[],1);
hi = max(F,[],1);
Z = bsxfun(@rdivide,bsxfun(@minus,F,lo),hi-lo+eps);
w = localCfg(cfg,'commonKneeWeights',ones(1,size(Z,2)));
w = max(reshape(w,1,[]),0);
w = w/max(sum(w),eps);
rho = localCfg(cfg,'commonKneeAugmentation',0.05);
weighted = bsxfun(@times,Z,w);
score = max(weighted,[],2)+rho*sum(weighted,2);
score(~isfinite(score)) = inf;
[~,localIndex] = min(score);
localIndex = localIndex(1);
index = candidateIndex(localIndex);
solution = archive(index);

details.level = level;
details.candidateIndex = candidateIndex;
details.strictMask = strictMask;
details.relaxedMask = relaxedMask;
details.strictLimits = strictDetails;
details.relaxedLimits = relaxedDetails;
details.selectedEngineeringSatisfied = strictMask(index);
details.selectedRelaxedSatisfied = relaxedMask(index);
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
