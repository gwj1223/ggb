function best = selectCompromise(archive,weights)
if isempty(archive), error('Archive is empty.'); end
obj=vertcat(archive.objectives); mn=min(obj,[],1); mx=max(obj,[],1);
normObj=(obj-mn)./(mx-mn+eps); weights=weights(:)'/sum(weights);
score=sqrt(sum(weights.*normObj.^2,2)); [~,i]=min(score); best=archive(i);
end
