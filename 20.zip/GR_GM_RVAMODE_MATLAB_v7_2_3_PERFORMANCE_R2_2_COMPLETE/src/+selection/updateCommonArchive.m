function archive = updateCommonArchive(archive,candidates,maxSize,cfg)
%UPDATECOMMONARCHIVE Preserve a nondominated archive in fixed physical space.
%
% The common objectives are:
%   detour ratio, geological risk, total energy, smoothness,
%   and one minus the true minimum target quality.
% Only solutions satisfying the complete final mission constraints enter this
% archive. Original internal objectives remain unchanged in the returned
% individuals.
%
% v6.3.4.1 hotfix:
%   The candidate pool must not be named "all", because that shadows the
%   MATLAB built-in all() used by the finite-objective row check.

pool = [archive(:);candidates(:)];
if isempty(pool)
    archive = pool;
    return;
end

finalMask = evaluation.checkFinalMonitoringFeasibility(pool,cfg);
finalMask = reshape(logical(finalMask),[],1);
staticCV = reshape([pool.cv],[],1);
staticMask = isfinite(staticCV) & ...
    staticCV <= cfg.constraintTolerance;

if numel(finalMask) ~= numel(pool) || numel(staticMask) ~= numel(pool)
    error('selection:updateCommonArchive:MaskSizeMismatch', ...
        ['Feasibility masks must contain one value per candidate. ' ...
         'Candidates=%d, finalMask=%d, staticMask=%d.'], ...
        numel(pool),numel(finalMask),numel(staticMask));
end

keep = finalMask & staticMask;
pool = pool(keep);
if isempty(pool)
    archive = pool;
    return;
end

obj = metrics.commonObjectiveMatrix(pool);
if size(obj,1) ~= numel(pool)
    error('selection:updateCommonArchive:ObjectiveRowMismatch', ...
        ['The common-objective matrix must contain one row per candidate. ' ...
         'Candidates=%d, objectiveRows=%d.'],numel(pool),size(obj,1));
end

finiteMask = all(isfinite(obj),2);
pool = pool(finiteMask);
obj = obj(finiteMask,:);
if isempty(pool)
    archive = pool;
    return;
end

[pool,obj] = localDeduplicate(pool,obj,localCfg(cfg, ...
    'commonArchiveObjectiveTolerance',1e-5));
frontMask = localNondominatedMask(obj);
front = pool(frontMask);
frontObj = obj(frontMask,:);

if numel(front)>maxSize
    temp = front;
    for i = 1:numel(temp)
        temp(i).objectives = frontObj(i,:);
        temp(i).cv = 0;
        temp(i).feasible = true;
        temp(i).commonArchiveIndex = i;
    end
    temp = selection.assignRankCrowding(temp);
    commonCfg = cfg;
    if isfield(cfg,'commonArchiveReferenceVectorDivisions')
        commonCfg.referenceVectorDivisions = ...
            cfg.commonArchiveReferenceVectorDivisions;
    end
    selectedTemp = selection.referenceVectorTruncate( ...
        temp,maxSize,commonCfg);
    selectedIdx = reshape([selectedTemp.commonArchiveIndex],[],1);
    front = front(selectedIdx);
end
archive = front(:);
end

function [out,objOut] = localDeduplicate(in,obj,tol)
if isempty(in)
    out = in;
    objOut = obj;
    return;
end
lo = min(obj,[],1);
scale = max(obj,[],1)-lo;
z = bsxfun(@rdivide,bsxfun(@minus,obj,lo),scale+eps);
keep = true(size(obj,1),1);
for i = 1:size(obj,1)
    if ~keep(i), continue; end
    duplicate = find(keep & (1:size(obj,1))'>i & ...
        max(abs(bsxfun(@minus,z,z(i,:))),[],2)<tol);
    keep(duplicate) = false;
end
out = in(keep);
objOut = obj(keep,:);
end

function keep = localNondominatedMask(obj)
N = size(obj,1);
keep = true(N,1);
for i = 1:N
    if ~keep(i), continue; end
    dominatesI = all(bsxfun(@le,obj(i,:),obj),2) & ...
        any(bsxfun(@lt,obj(i,:),obj),2);
    dominatedByI = find(dominatesI);
    keep(dominatedByI) = false;

    dominators = all(bsxfun(@le,obj,obj(i,:)),2) & ...
        any(bsxfun(@lt,obj,obj(i,:)),2);
    if any(dominators)
        keep(i) = false;
    end
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
