function [best,label,index,selectionLevel] = ...
    selectReportedSolution(reps,archive,cfg)
%SELECTREPORTEDSOLUTION Select the engineering-safe reported path.
%
% Selection order is strict engineering, relaxed engineering, then final
% feasibility. The requested representative is tried first, followed by a
% configurable fallback and deterministic safety fallbacks.
if nargin < 1 || isempty(reps) || ~isfield(reps,'solutions') || ...
        isempty(reps.solutions)
    if nargin < 2 || isempty(archive)
        error('selection:EmptyArchive','No solution is available to report.');
    end
    best = selection.selectMonitoringCompromise(archive,cfg);
    label = 'MonitoringCompromise';
    index = NaN;
    selectionLevel = 'monitoring_compromise_fallback';
    return;
end
labels = reps.labels(:);
solutions = reps.solutions(:);
if numel(labels) ~= numel(solutions)
    error('selection:RepresentativeShape', ...
        'Representative labels and solutions must have equal lengths.');
end

requested = localCfg(cfg,'finalReportedSolution','RiskBalanced');
fallback = localCfg(cfg,'finalReportedFallback','MinimumPhysicalCost');
order = localLabelOrder(requested,fallback);
referenceArchive = archive;
if isempty(referenceArchive), referenceArchive = solutions; end
strictMask = selection.engineeringLimitMask( ...
    solutions,cfg,'strict',referenceArchive);
relaxedMask = selection.engineeringLimitMask( ...
    solutions,cfg,'relaxed',referenceArchive);

[index,selectionLevel] = localResolve(labels,order,strictMask, ...
    'strict_engineering');
if isempty(index)
    [index,selectionLevel] = localResolve(labels,order,relaxedMask, ...
        'relaxed_engineering');
end
if isempty(index)
    finalMask = localFinalMask(solutions,cfg);
    [index,selectionLevel] = localResolve(labels,order,finalMask, ...
        'final_feasible_fallback');
end
if isempty(index)
    if nargin >= 2 && ~isempty(archive)
        best = selection.selectMonitoringCompromise(archive,cfg);
        label = 'MonitoringCompromise';
        index = NaN;
        selectionLevel = 'monitoring_compromise_fallback';
        return;
    end
    index = 1;
    selectionLevel = 'first_available_fallback';
end
index = index(1);
best = solutions(index);
label = char(labels{index});
end

function [index,level] = localResolve(labels,order,mask,levelName)
index = [];
level = '';
mask = reshape(mask,[],1);
for k = 1:numel(order)
    candidate = localFindLabel(labels,order{k});
    if ~isempty(candidate) && mask(candidate)
        index = candidate;
        level = levelName;
        return;
    end
end
end

function order = localLabelOrder(requested,fallback)
base = {char(requested),char(fallback),'RiskBalanced', ...
    'MinimumPhysicalCost','CommonKneePoint','Balanced','KneePoint','MinimumRisk', ...
    'MinimumDetour','MonitoringPriority'};
order = cell(0,1);
for i = 1:numel(base)
    if isempty(base{i}), continue; end
    duplicate = false;
    for j = 1:numel(order)
        if strcmpi(order{j},base{i}), duplicate = true; break; end
    end
    if ~duplicate, order{end+1,1} = base{i}; end %#ok<AGROW>
end
end

function index = localFindLabel(labels,target)
index = [];
for k = 1:numel(labels)
    if strcmpi(char(labels{k}),char(target))
        index = k;
        return;
    end
end
end

function mask = localFinalMask(solutions,cfg)
solutions = solutions(:);
mask = reshape([solutions.cv],[],1)<= ...
    localCfg(cfg,'constraintTolerance',1e-8);
if isfield(solutions,'monitorStats') && isfield(solutions,'staticCV')
    try
        finalMask = evaluation.checkFinalMonitoringFeasibility(solutions,cfg);
        mask = mask & reshape(finalMask,[],1);
    catch
    end
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
