function [solution,index,score,details] = ...
    selectRiskBalancedSolution(archive,cfg)
%SELECTRISKBALANCEDSOLUTION Risk-limited engineering compromise.
if isempty(archive)
    error('selection:EmptyArchive','Archive is empty.');
end
archive = archive(:);
[strictMask,strictDetails] = selection.engineeringLimitMask( ...
    archive,cfg,'strict',archive);
[relaxedMask,relaxedDetails] = selection.engineeringLimitMask( ...
    archive,cfg,'relaxed',archive);

if any(strictMask)
    candidateIndex = find(strictMask);
    level = 'strict_engineering';
elseif any(relaxedMask)
    candidateIndex = find(relaxedMask);
    level = 'relaxed_engineering';
else
    finalMask = localFinalMask(archive,cfg);
    candidateIndex = find(finalMask);
    if isempty(candidateIndex), candidateIndex = (1:numel(archive))'; end
    level = 'final_feasible_fallback';
end

candidateScore = metrics.riskBalancedCostIndicator( ...
    archive(candidateIndex),cfg);
[bestScore,localIndex] = min(candidateScore);
localIndex = localIndex(1);
index = candidateIndex(localIndex);
solution = archive(index);
score = bestScore;
details.level = level;
details.candidateIndex = candidateIndex;
details.strictMask = strictMask;
details.relaxedMask = relaxedMask;
details.strictLimits = strictDetails;
details.relaxedLimits = relaxedDetails;
details.selectedEngineeringSatisfied = strictMask(index);
details.selectedRelaxedSatisfied = relaxedMask(index);
end

function mask = localFinalMask(archive,cfg)
archive = archive(:);
cv = inf(numel(archive),1);
if isfield(archive,'cv'), cv = reshape([archive.cv],[],1); end
mask = isfinite(cv) & cv<=localCfg(cfg,'constraintTolerance',1e-8);
if isfield(archive,'monitorStats') && isfield(archive,'staticCV')
    try
        missionMask = evaluation.checkFinalMonitoringFeasibility(archive,cfg);
        mask = mask & reshape(missionMask,[],1);
    catch
    end
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
