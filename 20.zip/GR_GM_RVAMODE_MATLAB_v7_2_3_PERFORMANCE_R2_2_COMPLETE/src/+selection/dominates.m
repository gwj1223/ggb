function tf = dominates(a,b)
if a.feasible && ~b.feasible, tf=true; return; end
if ~a.feasible && b.feasible, tf=false; return; end
if ~a.feasible && ~b.feasible, tf=a.cv<b.cv; return; end
tf=all(a.objectives<=b.objectives) && any(a.objectives<b.objectives);
end
