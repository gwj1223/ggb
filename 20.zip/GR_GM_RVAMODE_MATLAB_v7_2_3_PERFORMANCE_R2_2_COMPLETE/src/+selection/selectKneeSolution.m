function [solution,index,score] = selectKneeSolution(archive,cfg)
%SELECTKNEESOLUTION Achievement-scalarizing knee/compromise candidate.
%
% The normalized Chebyshev term identifies a point where improvement in
% any one objective requires a noticeable sacrifice elsewhere. A small
% weighted L1 augmentation removes ties and avoids weakly efficient points.
if isempty(archive)
    error('selection:EmptyArchive','Archive is empty.');
end
archive = archive(:);
feasible = archive([archive.cv] <= cfg.constraintTolerance);
if isempty(feasible), feasible = archive; end
F = vertcat(feasible.objectives);
lo = min(F,[],1);
hi = max(F,[],1);
Z = (F-lo)./(hi-lo+eps);
if isfield(cfg,'kneeRepresentativeWeights')
    w = cfg.kneeRepresentativeWeights(:)';
else
    w = ones(1,size(Z,2));
end
w = w/max(sum(w),eps);
if isfield(cfg,'kneeAugmentation')
    rho = cfg.kneeAugmentation;
else
    rho = 0.05;
end
weighted = bsxfun(@times,Z,w);
score = max(weighted,[],2)+rho*sum(weighted,2);
score(~isfinite(score)) = inf;
[~,index] = min(score);
index = index(1);
solution = feasible(index);
end
