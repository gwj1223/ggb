function out = deduplicateArchive(in,tol)
if isempty(in), out=in; return; end
obj=vertcat(in.objectives); mn=min(obj,[],1); sc=max(obj,[],1)-mn; z=(obj-mn)./(sc+eps); keep=true(size(z,1),1);
for i=1:size(z,1)
 if ~keep(i), continue; end
 for j=i+1:size(z,1)
  if keep(j) && max(abs(z(i,:)-z(j,:)))<tol, keep(j)=false; end
 end
end
out=in(keep);
end
