function diagnostics = engineeringLimitDiagnostics(details,index,tol)
%ENGINEERINGLIMITDIAGNOSTICS Explain report-level engineering filtering.
%
% This helper is diagnostic only. It does not participate in optimization or
% representative selection; it simply expands engineeringLimitMask details
% into one row per criterion for the selected candidate.
if nargin<2 || isempty(index), index=1; end
if nargin<3 || isempty(tol), tol=1e-8; end
if isempty(details) || ~isstruct(details)
    diagnostics=repmat(localRow(),0,1);
    return;
end
rows=repmat(localRow(),12,1);
rows(1)=localBooleanRow('final_feasibility',localValue(details,'finalMask',index,false));
rows(2)=localUpperRow('detour',localValue(details,'detour',index,inf), ...
    localScalar(details,'detourLimit',inf),tol);
rows(3)=localUpperRow('risk_objective',localValue(details,'riskObjective',index,inf), ...
    localScalar(details,'riskObjectiveLimit',inf),tol);
rows(4)=localUpperRow('mean_risk',localValue(details,'meanRisk',index,inf), ...
    localScalar(details,'meanRiskLimit',inf),tol);
rows(5)=localUpperRow('tail_risk',localValue(details,'tailRisk',index,inf), ...
    localScalar(details,'tailRiskLimit',inf),tol);
rows(6)=localUpperRow('energy',localValue(details,'energy',index,inf), ...
    localScalar(details,'energyLimit',inf),tol);
rows(7)=localUpperRow('smoothness',localValue(details,'smoothness',index,inf), ...
    localScalar(details,'smoothnessLimit',inf),tol);
rows(8)=localLowerRow('minimum_quality',localValue(details,'minimumQuality',index,-inf), ...
    localScalar(details,'minimumQualityLimit',-inf),tol);
rows(9)=localLowerRow('critical_quality',localValue(details,'criticalQuality',index,-inf), ...
    localScalar(details,'criticalQualityLimit',-inf),tol);
rows(10)=localLowerRow('critical_observation_length', ...
    localValue(details,'observationLength',index,-inf), ...
    localScalar(details,'observationLengthLimit',-inf),tol);
rows(11)=localLowerRow('critical_los_ratio',localValue(details,'losRatio',index,-inf), ...
    localScalar(details,'losRatioLimit',-inf),tol);
rows(12)=localUpperRow('monitoring_dispersion',localValue(details,'dispersion',index,inf), ...
    localScalar(details,'dispersionLimit',inf),tol);
diagnostics=rows;
end

function row=localRow()
row=struct('name','','value',NaN,'limit',NaN,'relation','','passed',false);
end

function row=localBooleanRow(name,value)
row=localRow();
row.name=name; row.value=double(logical(value)); row.limit=1;
row.relation='=='; row.passed=logical(value);
end

function row=localUpperRow(name,value,limit,tol)
row=localRow();
row.name=name; row.value=value; row.limit=limit; row.relation='<=';
row.passed=isfinite(value) && value<=limit+tol;
end

function row=localLowerRow(name,value,limit,tol)
row=localRow();
row.name=name; row.value=value; row.limit=limit; row.relation='>=';
row.passed=isfinite(value) && value>=limit-tol;
end

function value=localValue(s,name,index,defaultValue)
value=defaultValue;
if ~isfield(s,name), return; end
v=s.(name);
if isempty(v) || numel(v)<index, return; end
candidate=v(index);
if (isnumeric(candidate) || islogical(candidate)) && isscalar(candidate)
    value=candidate;
end
end

function value=localScalar(s,name,defaultValue)
value=defaultValue;
if ~isfield(s,name), return; end
v=s.(name);
if (isnumeric(v) || islogical(v)) && isscalar(v)
    value=v;
end
end
