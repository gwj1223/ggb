function state = missionBandState(pop,cfg,generation,targetSize)
%MISSIONBANDSTATE Population-relative mission leader band for v7.1.0.
%
% The formal/scheduled mission epsilon remains untouched.  This helper only
% defines a SEARCH band among static-feasible individuals so that, when the
% scheduled epsilon contains too few candidates, the optimizer still retains
% a bounded set of near-mission leaders for five-objective diversity.
%
% scheduledAdmissible : static feasible and D_M <= scheduled epsilon
% searchAdmissible    : static feasible and D_M <= effective search epsilon
% bandExtra           : searchAdmissible but not scheduledAdmissible
% outsideBand         : static feasible but outside the search band
%
% effectiveEpsilon = max(scheduledEpsilon, K-th smallest static-feasible D_M)
% where K = ceil(missionBandMinFraction * targetSize), with a minimum of two
% when at least two static-feasible individuals exist.

if nargin < 3 || isempty(generation), generation = 1; end
if nargin < 4 || isempty(targetSize), targetSize = numel(pop); end

N = numel(pop);
state = struct( ...
    'enabled',false, ...
    'staticFeasible',false(N,1), ...
    'scheduledAdmissible',false(N,1), ...
    'searchAdmissible',false(N,1), ...
    'bandExtra',false(N,1), ...
    'outsideBand',false(N,1), ...
    'formalSatisfied',false(N,1), ...
    'missionDeficit',inf(N,1), ...
    'scheduledEpsilon',1, ...
    'effectiveEpsilon',1, ...
    'minimumLeaderCount',0, ...
    'staticCount',0, ...
    'scheduledCount',0, ...
    'bandCount',0, ...
    'formalCount',0, ...
    'minimumDeficit',inf, ...
    'bandEdgeDeficit',inf, ...
    'medianDeficit',inf);
if N==0, return; end

state.enabled = localCfg(cfg,'enableMissionBandSelection',false) && ...
    localCfg(cfg,'enableUnifiedMissionDeficit',false);

tol = localCfg(cfg,'constraintTolerance',1e-8);
componentTol = localCfg(cfg,'missionDeficitComponentTolerance',1e-12);
for i = 1:N
    if isfield(pop(i),'staticFeasible') && isscalar(pop(i).staticFeasible)
        state.staticFeasible(i) = logical(pop(i).staticFeasible);
    elseif isfield(pop(i),'staticCV') && isfinite(pop(i).staticCV)
        state.staticFeasible(i) = pop(i).staticCV <= tol;
    elseif isfield(pop(i),'feasible')
        state.staticFeasible(i) = logical(pop(i).feasible);
    end

    if isfield(pop(i),'missionDeficit') && isfinite(pop(i).missionDeficit)
        state.missionDeficit(i) = pop(i).missionDeficit;
    elseif localCfg(cfg,'enableUnifiedMissionDeficit',false) && ...
            isfield(pop(i),'monitorStats') && ~isempty(pop(i).monitorStats)
        state.missionDeficit(i) = evaluation.finalMonitoringDeficit(pop(i),cfg);
    elseif state.staticFeasible(i)
        state.missionDeficit(i) = 0;
    end

    if isfield(pop(i),'formalMissionSatisfied') && ...
            isscalar(pop(i).formalMissionSatisfied)
        state.formalSatisfied(i) = logical(pop(i).formalMissionSatisfied) && ...
            state.staticFeasible(i);
    else
        state.formalSatisfied(i) = state.staticFeasible(i) && ...
            state.missionDeficit(i) <= componentTol;
    end
end

scheduledEpsilon = localScheduledEpsilon(pop,cfg,generation);
state.scheduledEpsilon = scheduledEpsilon;
state.effectiveEpsilon = scheduledEpsilon;

staticIdx = find(state.staticFeasible & isfinite(state.missionDeficit));
state.staticCount = numel(staticIdx);
if isempty(staticIdx)
    return;
end

Dstatic = state.missionDeficit(staticIdx);
state.minimumDeficit = min(Dstatic);
state.medianDeficit = median(Dstatic);

scheduledTol = localCfg(cfg,'missionDeficitScheduleTolerance',1e-12);
bandTol = localCfg(cfg,'missionBandTolerance',1e-10);
state.scheduledAdmissible = state.staticFeasible & ...
    state.missionDeficit <= scheduledEpsilon + scheduledTol;

if state.enabled
    fraction = localCfg(cfg,'missionBandMinFraction',0.25);
    fraction = min(max(fraction,0),1);
    requested = ceil(fraction*max(1,round(targetSize)));
    if numel(staticIdx)>=2
        requested = max(2,requested);
    else
        requested = max(1,requested);
    end
    K = min(numel(staticIdx),requested);
    sortedD = sort(Dstatic,'ascend');
    kthD = sortedD(K);
    state.minimumLeaderCount = K;
    state.bandEdgeDeficit = kthD;
    state.effectiveEpsilon = max(scheduledEpsilon,kthD);
else
    state.minimumLeaderCount = sum(state.scheduledAdmissible);
    state.bandEdgeDeficit = scheduledEpsilon;
end

state.searchAdmissible = state.staticFeasible & ...
    state.missionDeficit <= state.effectiveEpsilon + bandTol;
state.bandExtra = state.searchAdmissible & ~state.scheduledAdmissible;
state.outsideBand = state.staticFeasible & ~state.searchAdmissible;
state.scheduledCount = sum(state.scheduledAdmissible);
state.bandCount = sum(state.searchAdmissible);
state.formalCount = sum(state.formalSatisfied);
end

function epsilonD = localScheduledEpsilon(pop,cfg,generation)
if isfield(cfg,'runtimeMissionDeficitEpsilon') && ...
        isscalar(cfg.runtimeMissionDeficitEpsilon) && ...
        isfinite(cfg.runtimeMissionDeficitEpsilon)
    epsilonD = cfg.runtimeMissionDeficitEpsilon;
    epsilonD = min(max(epsilonD,0),1);
    return;
end

for i = 1:numel(pop)
    if isfield(pop(i),'missionDeficitEpsilon') && ...
            isscalar(pop(i).missionDeficitEpsilon) && ...
            isfinite(pop(i).missionDeficitEpsilon)
        epsilonD = pop(i).missionDeficitEpsilon;
        epsilonD = min(max(epsilonD,0),1);
        return;
    end
end

thresholds = evaluation.currentMonitoringThresholds(generation,cfg);
if isfield(thresholds,'missionDeficitEpsilon') && ...
        isfinite(thresholds.missionDeficitEpsilon)
    epsilonD = thresholds.missionDeficitEpsilon;
else
    epsilonD = 1;
end
epsilonD = min(max(epsilonD,0),1);
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
