function pop = assignRankCrowding(pop)
%ASSIGNRANKCROWDING Vectorized Deb dominance and NSGA-II crowding.
N = numel(pop);
if N==0, return; end
for i = 1:N
    pop(i).rank = inf;
    pop(i).crowding = 0;
end
feasible = reshape([pop.feasible],[],1);
cv = reshape([pop.cv],[],1);
obj = vertcat(pop.objectives);
feasibleIdx = find(feasible);
infeasibleIdx = find(~feasible);
S = cell(N,1);
n = zeros(N,1);
front1 = zeros(N,1); frontCount = 0;

for p = 1:N
    if feasible(p)
        qf = feasibleIdx(feasibleIdx~=p);
        if isempty(qf)
            dominatedFeasible = [];
            dominatorCount = 0;
        else
            pLeq = all(bsxfun(@le,obj(p,:),obj(qf,:)),2);
            pLt = any(bsxfun(@lt,obj(p,:),obj(qf,:)),2);
            qLeq = all(bsxfun(@le,obj(qf,:),obj(p,:)),2);
            qLt = any(bsxfun(@lt,obj(qf,:),obj(p,:)),2);
            dominatedFeasible = qf(pLeq & pLt);
            dominatorCount = sum(qLeq & qLt);
        end
        S{p} = [dominatedFeasible(:);infeasibleIdx(:)];
        n(p) = dominatorCount;
    else
        qi = infeasibleIdx(infeasibleIdx~=p);
        S{p} = qi(cv(qi)>cv(p));
        n(p) = numel(feasibleIdx)+sum(cv(qi)<cv(p));
    end
    if n(p)==0
        pop(p).rank = 1;
        frontCount = frontCount+1;
        front1(frontCount) = p;
    end
end

fronts = cell(1,N);
fronts{1} = front1(1:frontCount)';
f = 1;
while f<=N && ~isempty(fronts{f})
    next = zeros(N,1); nextCount = 0;
    for ii = 1:numel(fronts{f})
        p = fronts{f}(ii);
        dominated = S{p};
        for jj = 1:numel(dominated)
            q = dominated(jj);
            n(q) = n(q)-1;
            if n(q)==0
                pop(q).rank = f+1;
                nextCount = nextCount+1;
                next(nextCount) = q;
            end
        end
    end
    f = f+1;
    if nextCount>0
        fronts{f} = unique(next(1:nextCount))';
    end
end

for f = 1:numel(fronts)
    idx = fronts{f};
    if isempty(idx), continue; end
    if numel(idx)<=2
        for k = 1:numel(idx), pop(idx(k)).crowding = inf; end
        continue;
    end
    frontObj = obj(idx,:);
    crowd = zeros(numel(idx),1);
    for m = 1:size(frontObj,2)
        [vals,order] = sort(frontObj(:,m));
        crowd(order(1)) = inf;
        crowd(order(end)) = inf;
        den = max(vals(end)-vals(1),eps);
        for k = 2:numel(idx)-1
            if isfinite(crowd(order(k)))
                crowd(order(k)) = crowd(order(k))+ ...
                    (vals(k+1)-vals(k-1))/den;
            end
        end
    end
    for k = 1:numel(idx)
        pop(idx(k)).crowding = crowd(k);
    end
end
end
