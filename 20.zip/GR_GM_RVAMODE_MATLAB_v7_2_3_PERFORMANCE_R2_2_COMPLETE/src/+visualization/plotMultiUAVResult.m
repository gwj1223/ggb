function plotMultiUAVResult(problem,fleetResult,cfg)
%PLOTMULTIUAVRESULT Unified real-DEM map with cooperative UAV fleet paths.

style = visualization.shiyanMapStyle();
[terrainRGB,~,~] = visualization.buildTerrainRGB(problem,style);
[riskRGB,riskAlpha,~] = visualization.buildRiskOverlay(problem,style);
Xkm = problem.gridX/1000;
Ykm = problem.gridY/1000;
Zkm = problem.terrain/1000;

pathColors = localPathColors(cfg.multiUAVCount,style.multiUAVPathColors);
f = figure('Name','Shiyan G1 Multi UAV Cooperative Paths', ...
    'Color',style.backgroundColor,'Position',style.figurePosition);
ax = axes(f); hold(ax,'on');

surface(ax,Xkm,Ykm,Zkm,'CData',terrainRGB, ...
    'FaceColor','texturemap','EdgeColor','none', ...
    'FaceAlpha',1,'HandleVisibility','off');
surface(ax,Xkm,Ykm,(problem.terrain+style.riskZOffset)/1000, ...
    'CData',riskRGB,'FaceColor','texturemap','EdgeColor','none', ...
    'AlphaData',riskAlpha,'AlphaDataMapping','none', ...
    'FaceAlpha','texturemap','HandleVisibility','off');

critical = cfg.criticalTargetIndices(:)';
targetTerrain = problem.monitorTargetTerrain(:);
hNormal = gobjects(1); hCritical = gobjects(1);
for m = 1:size(problem.monitorTargets,1)
    t = problem.monitorTargets(m,:);
    z = (targetTerrain(m)+style.targetZOffset)/1000;
    if ismember(m,critical)
        h = scatter3(ax,t(1)/1000,t(2)/1000,z, ...
            style.criticalTargetSize,'^','filled', ...
            'MarkerFaceColor',style.criticalTargetColor, ...
            'MarkerEdgeColor','none');
        if ~isgraphics(hCritical)
            hCritical = h; set(h,'DisplayName','Critical target');
        else
            set(h,'HandleVisibility','off');
        end
    else
        h = scatter3(ax,t(1)/1000,t(2)/1000,z, ...
            style.normalTargetSize,'^','filled', ...
            'MarkerFaceColor',style.normalTargetColor, ...
            'MarkerEdgeColor','none');
        if ~isgraphics(hNormal)
            hNormal = h; set(h,'DisplayName','Monitoring target');
        else
            set(h,'HandleVisibility','off');
        end
    end
end

K = cfg.multiUAVCount;
hPath = gobjects(K,1);
for k = 1:K
    p = fleetResult.paths{k};
    hPath(k) = plot3(ax,p(:,1)/1000,p(:,2)/1000,p(:,3)/1000,'-', ...
        'Color',pathColors(k,:),'LineWidth',style.multiUAVPathLineWidth, ...
        'DisplayName',sprintf('UAV-%d path',k));
end

hStart = scatter3(ax,problem.start(1)/1000,problem.start(2)/1000, ...
    problem.start(3)/1000,style.startSize,'o','filled', ...
    'MarkerFaceColor',style.startColor,'MarkerEdgeColor','k', ...
    'LineWidth',0.8,'DisplayName','Start');
hGoal = scatter3(ax,problem.goal(1)/1000,problem.goal(2)/1000, ...
    problem.goal(3)/1000,style.goalSize,'s','filled', ...
    'MarkerFaceColor',style.goalColor,'MarkerEdgeColor','k', ...
    'LineWidth',0.8,'DisplayName','Goal');

xlabel(ax,'Local Easting (km)');
ylabel(ax,'Local Northing (km)');
zlabel(ax,'Elevation (km)');
axis(ax,'tight'); box(ax,'on'); grid(ax,'off');
view(ax,style.viewAzimuth,style.viewElevation);
pbaspect(ax,style.plotBoxAspect); camproj(ax,style.cameraProjection);
set(ax,'FontName',style.fontName,'FontSize',style.axisFontSize, ...
    'LineWidth',style.axisLineWidth,'TickLength',[0 0]);

colormap(ax,style.riskMap); clim(ax,style.riskCLim);
cb = colorbar(ax,'eastoutside'); ylabel(cb,'DEM-derived risk proxy');
cb.FontName = style.fontName; cb.FontSize = style.colorbarFontSize;
cb.Ticks = style.riskColorbarTicks;

handles = hPath(:)'; labels = arrayfun(@(k)sprintf('UAV-%d path',k), ...
    1:K,'UniformOutput',false);
if isgraphics(hNormal)
    handles(end+1)=hNormal; labels{end+1}='Monitoring target'; %#ok<AGROW>
end
if isgraphics(hCritical)
    handles(end+1)=hCritical; labels{end+1}='Critical target'; %#ok<AGROW>
end
handles(end+1:end+2)=[hStart hGoal];
labels(end+1:end+2)={'Start','Goal'};
lgd=legend(ax,handles,labels,'Location','northeast','Box','on');
lgd.FontName=style.fontName; lgd.FontSize=style.legendFontSize;

m=fleetResult.metrics;
title(ax,sprintf(['Shiyan-G1 | %d-UAV cooperative monitoring | ' ...
    'Success=%d | Makespan=%.1f min | d_{min}=%.0f m'], ...
    K,m.missionSuccess,m.makespan_s/60,m.minimumSeparation_m), ...
    'FontWeight','normal','FontSize',style.titleFontSize);
end

function c = localPathColors(K,base)
%LOCALPATHCOLORS Use the shared publication palette for the fleet paths.
if K <= size(base,1)
    c = base(1:K,:);
else
    % Preserve the curated first colours and only generate additional hues
    % when a fleet larger than the defined palette is requested.
    extra = hsv(K-size(base,1));
    c = [base; extra];
end
end
