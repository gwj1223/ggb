function plotFleetSeparation(fleetResult,cfg)
%PLOTFLEETSEPARATION Pairwise 3-D separation versus mission time.
sep = fleetResult.separation;
K = size(sep.positions,3);
if K < 2, return; end
f=figure('Name','Multi UAV Pairwise Separation','Color','w', ...
    'Position',[100 100 1050 560]);
ax=axes(f); hold(ax,'on');
for i=1:K-1
    for j=i+1:K
        both=sep.active(:,i)&sep.active(:,j);
        d=nan(size(sep.time));
        if any(both)
            delta=sep.positions(both,:,i)-sep.positions(both,:,j);
            d(both)=sqrt(sum(delta.^2,2));
        end
        plot(ax,sep.time/60,d,'LineWidth',1.5, ...
            'DisplayName',sprintf('UAV-%d / UAV-%d',i,j));
    end
end
yline(ax,cfg.multiUAVSafeSeparation,'--','Safe separation', ...
    'LineWidth',1.2);
yline(ax,cfg.multiUAVNearSeparation,':','Near separation', ...
    'LineWidth',1.2);
xlabel(ax,'Mission time (min)'); ylabel(ax,'3-D separation (m)');
box(ax,'on'); grid(ax,'on'); legend(ax,'Location','best');
title(ax,sprintf('Pairwise separation | minimum = %.1f m | collision-free = %d', ...
    sep.minimumSeparation,sep.collisionFree),'FontWeight','normal');
end
