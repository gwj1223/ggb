function plotMultiUAVAssignment(problem,assignment,cfg)
%PLOTMULTIUAVASSIGNMENT Preview deterministic task groups before optimizing.
style = visualization.shiyanMapStyle();
[terrainRGB,~,~] = visualization.buildTerrainRGB(problem,style);
[riskRGB,riskAlpha,~] = visualization.buildRiskOverlay(problem,style);
colors = localPathColors(cfg.multiUAVCount,style.multiUAVPathColors);

f=figure('Name','Shiyan G1 Multi UAV Target Assignment', ...
    'Color',style.backgroundColor,'Position',style.figurePosition);
ax=axes(f); hold(ax,'on');
surface(ax,problem.gridX/1000,problem.gridY/1000,problem.terrain/1000, ...
    'CData',terrainRGB,'FaceColor','texturemap','EdgeColor','none', ...
    'HandleVisibility','off');
surface(ax,problem.gridX/1000,problem.gridY/1000, ...
    (problem.terrain+style.riskZOffset)/1000,'CData',riskRGB, ...
    'FaceColor','texturemap','EdgeColor','none','AlphaData',riskAlpha, ...
    'AlphaDataMapping','none','FaceAlpha','texturemap', ...
    'HandleVisibility','off');

critical = cfg.criticalTargetIndices(:)';
h = gobjects(cfg.multiUAVCount,1);
for m=1:size(problem.monitorTargets,1)
    k=assignment.targetToUAV(m);
    z=(problem.monitorTargetTerrain(m)+style.targetZOffset)/1000;
    if ismember(m,critical), marker='p'; sz=style.criticalTargetSize;
    else, marker='^'; sz=style.normalTargetSize; end
    q=scatter3(ax,problem.monitorTargets(m,1)/1000, ...
        problem.monitorTargets(m,2)/1000,z,sz,marker,'filled', ...
        'MarkerFaceColor',colors(k,:),'MarkerEdgeColor','none');
    if ~isgraphics(h(k))
        h(k)=q; set(q,'DisplayName',sprintf('UAV-%d targets',k));
    else
        set(q,'HandleVisibility','off');
    end
end

scatter3(ax,problem.start(1)/1000,problem.start(2)/1000, ...
    problem.start(3)/1000,style.startSize,'o','filled', ...
    'MarkerFaceColor',style.startColor,'MarkerEdgeColor','k', ...
    'HandleVisibility','off');
scatter3(ax,problem.goal(1)/1000,problem.goal(2)/1000, ...
    problem.goal(3)/1000,style.goalSize,'s','filled', ...
    'MarkerFaceColor',style.goalColor,'MarkerEdgeColor','k', ...
    'HandleVisibility','off');

xlabel(ax,'Local Easting (km)'); ylabel(ax,'Local Northing (km)');
zlabel(ax,'Elevation (km)'); axis(ax,'tight'); box(ax,'on'); grid(ax,'off');
view(ax,style.viewAzimuth,style.viewElevation); pbaspect(ax,style.plotBoxAspect);
camproj(ax,style.cameraProjection); set(ax,'FontName',style.fontName, ...
    'FontSize',style.axisFontSize,'LineWidth',style.axisLineWidth, ...
    'TickLength',[0 0]);
colormap(ax,style.riskMap); clim(ax,style.riskCLim);
cb=colorbar(ax,'eastoutside'); ylabel(cb,'DEM-derived risk proxy');
cb.FontName=style.fontName; cb.FontSize=style.colorbarFontSize;
cb.Ticks=style.riskColorbarTicks;
legend(ax,h,arrayfun(@(k)sprintf('UAV-%d targets',k),1:cfg.multiUAVCount, ...
    'UniformOutput',false),'Location','northeast','Box','on');
title(ax,sprintf(['Shiyan-G1 | %d-UAV risk/spatial balanced assignment | ' ...
    'pentagram = Critical'],cfg.multiUAVCount), ...
    'FontWeight','normal','FontSize',style.titleFontSize);
end

function c = localPathColors(K,base)
if K <= size(base,1)
    c = base(1:K,:);
else
    extra = hsv(K-size(base,1));
    c = [base; extra];
end
end
