function plotShiyanG1Result(problem,result,cfg)
%PLOTSHIYANG1RESULT Unified publication map for Shiyan-G1.
%
% Displays the same DEM, hillshade, risk scale, target symbols, camera,
% typography and color standard as preview_30_targets.m, plus the reported
% UAV route. X/Y/Z are displayed in kilometres.
%
% IMPORTANT:
%   This function changes visualization only. Internal path coordinates,
%   DEM elevation, monitoring geometry and optimization/evaluation remain
%   in metres and are not modified.

%% Validate result
if ~isfield(result,'best') || isempty(result.best)
    error('visualization:MissingBestSolution', ...
        'result.best is empty or missing.');
end

b = result.best(1);
if ~isfield(b,'path') || isempty(b.path)
    error('visualization:MissingPath', ...
        'result.best(1).path is empty or missing.');
end
p = b.path;

%% Style and unified visual layers
style = visualization.shiyanMapStyle();
[terrainRGB,~,~] = visualization.buildTerrainRGB(problem,style);
[riskRGB,riskAlpha,~] = visualization.buildRiskOverlay(problem,style);

% Publication coordinates: X/Y/Z all use kilometres.
Xkm = problem.gridX/1000;
Ykm = problem.gridY/1000;
Zkm = problem.terrain/1000;

%% Figure
f = figure( ...
    'Name','Shiyan G1 Unified UAV Path', ...
    'Color',style.backgroundColor, ...
    'Position',style.figurePosition);
ax = axes(f);
hold(ax,'on');

%% Terrain
surface(ax,Xkm,Ykm,Zkm, ...
    'CData',terrainRGB, ...
    'FaceColor','texturemap', ...
    'EdgeColor','none', ...
    'FaceAlpha',1.0, ...
    'HandleVisibility','off');

%% Risk overlay
surface(ax,Xkm,Ykm,(problem.terrain + style.riskZOffset)/1000, ...
    'CData',riskRGB, ...
    'FaceColor','texturemap', ...
    'EdgeColor','none', ...
    'AlphaData',riskAlpha, ...
    'AlphaDataMapping','none', ...
    'FaceAlpha','texturemap', ...
    'HandleVisibility','off');

%% Monitoring targets
criticalIdx = [];
if isfield(cfg,'criticalTargetIndices') && ~isempty(cfg.criticalTargetIndices)
    criticalIdx = cfg.criticalTargetIndices(:)';
end

hNormal = gobjects(1);
hCritical = gobjects(1);

if isfield(problem,'monitorTargetTerrain') && ...
        numel(problem.monitorTargetTerrain) >= size(problem.monitorTargets,1)
    targetTerrain = problem.monitorTargetTerrain(:);
else
    targetTerrain = data.terrainHeight(problem, ...
        problem.monitorTargets(:,1),problem.monitorTargets(:,2));
    targetTerrain = targetTerrain(:);
end

for m = 1:size(problem.monitorTargets,1)
    t = problem.monitorTargets(m,:);
    tz = targetTerrain(m);

    % Visual lift only; the target used by the optimizer is unchanged.
    zPlotKm = (tz + style.targetZOffset)/1000;

    if ismember(m,criticalIdx)

        % Main critical marker.
        h = scatter3(ax,t(1)/1000,t(2)/1000,zPlotKm, ...
            style.criticalTargetSize,'^','filled', ...
            'MarkerFaceColor',style.criticalTargetColor, ...
            'MarkerEdgeColor','none');

        if ~isgraphics(hCritical)
            hCritical = h;
            set(hCritical,'DisplayName','Critical target');
        else
            set(h,'HandleVisibility','off');
        end
    else

        % Main monitoring marker.
        h = scatter3(ax,t(1)/1000,t(2)/1000,zPlotKm, ...
            style.normalTargetSize,'^','filled', ...
            'MarkerFaceColor',style.normalTargetColor, ...
            'MarkerEdgeColor','none');

        if ~isgraphics(hNormal)
            hNormal = h;
            set(hNormal,'DisplayName','Monitoring target');
        else
            set(h,'HandleVisibility','off');
        end
    end

    if style.showTargetLabels && ...
            isfield(problem,'monitorTargetLabels') && ...
            numel(problem.monitorTargetLabels) >= m
        text(ax,t(1)/1000,t(2)/1000, ...
            (tz + style.targetZOffset + 25)/1000, ...
            problem.monitorTargetLabels{m}, ...
            'FontName',style.fontName, ...
            'FontSize',8, ...
            'HorizontalAlignment','center', ...
            'BackgroundColor','w', ...
            'Margin',1, ...
            'Interpreter','none');
    end
end

%% UAV route: pure-color line, no white halo
hPath = plot3(ax,p(:,1)/1000,p(:,2)/1000,p(:,3)/1000,'-', ...
    'Color',style.pathColor, ...
    'LineWidth',style.pathLineWidth, ...
    'DisplayName','UAV path');

%% Sparse waypoint markers
markerIdx = 1:style.pathMarkerStep:size(p,1);
if isempty(markerIdx)
    markerIdx = 1;
end
if markerIdx(end) ~= size(p,1)
    markerIdx(end+1) = size(p,1); %#ok<AGROW>
end

scatter3(ax, ...
    p(markerIdx,1)/1000,p(markerIdx,2)/1000,p(markerIdx,3)/1000, ...
    style.pathMarkerSize,'o','filled', ...
    'MarkerFaceColor',style.pathColor, ...
    'MarkerEdgeColor','none', ...
    'LineWidth',0.1, ...
    'HandleVisibility','off');

%% Start / Goal
hStart = scatter3(ax, ...
    problem.start(1)/1000,problem.start(2)/1000,problem.start(3)/1000, ...
    style.startSize,'o','filled', ...
    'MarkerFaceColor',style.startColor, ...
    'MarkerEdgeColor','k','LineWidth',0.8, ...
    'DisplayName','Start');

hGoal = scatter3(ax, ...
    problem.goal(1)/1000,problem.goal(2)/1000,problem.goal(3)/1000, ...
    style.goalSize,'s','filled', ...
    'MarkerFaceColor',style.goalColor, ...
    'MarkerEdgeColor','k','LineWidth',0.8, ...
    'DisplayName','Goal');

%% Axes: X/Y/Z use the same km unit
xlabel(ax,'Local Easting (km)');
ylabel(ax,'Local Northing (km)');
zlabel(ax,'Elevation (km)');
axis(ax,'tight');
box(ax,'on');
grid(ax,'off');
view(ax,style.viewAzimuth,style.viewElevation);
pbaspect(ax,style.plotBoxAspect);
camproj(ax,style.cameraProjection);

set(ax, ...
    'FontName',style.fontName, ...
    'FontSize',style.axisFontSize, ...
    'LineWidth',style.axisLineWidth, ...
    'GridColor',style.gridColor, ...
    'GridAlpha',style.gridAlpha, ...
    'TickLength',[0 0]);

%% Risk colorbar
colormap(ax,style.riskMap);
clim(ax,style.riskCLim);
cb = colorbar(ax,'eastoutside');
ylabel(cb,'DEM-derived risk proxy');
cb.FontName = style.fontName;
cb.FontSize = style.colorbarFontSize;
cb.Ticks = style.riskColorbarTicks;

%% Legend
legendHandles = hPath;
legendLabels = {'UAV path'};

if isgraphics(hNormal)
    legendHandles(end+1) = hNormal; %#ok<AGROW>
    legendLabels{end+1} = 'Monitoring target'; %#ok<AGROW>
end
if isgraphics(hCritical)
    legendHandles(end+1) = hCritical; %#ok<AGROW>
    legendLabels{end+1} = 'Critical target'; %#ok<AGROW>
end
legendHandles(end+1:end+2) = [hStart hGoal];
legendLabels(end+1:end+2) = {'Start','Goal'};

lgd = legend(ax,legendHandles,legendLabels, ...
    'Location','northeast','Box','on');
lgd.FontName = style.fontName;
lgd.FontSize = style.legendFontSize;

%% Title
solutionLabel = 'Reported';
if isfield(result,'reportedSolutionLabel') && ~isempty(result.reportedSolutionLabel)
    solutionLabel = result.reportedSolutionLabel;
end

titleParts = {'Shiyan-G1 real DEM',solutionLabel};

if isfield(b,'pathMetrics') && isfield(b.pathMetrics,'rawLength') && ...
        isfinite(b.pathMetrics.rawLength)
    titleParts{end+1} = sprintf('L = %.2f km',b.pathMetrics.rawLength/1000); %#ok<AGROW>
end

if isfield(b,'riskStats') && isfield(b.riskStats,'objective') && ...
        isfinite(b.riskStats.objective)
    titleParts{end+1} = sprintf('Risk = %.3f',b.riskStats.objective); %#ok<AGROW>
end

if isfield(b,'monitorStats') && isfield(b.monitorStats,'minimumQuality') && ...
        isfinite(b.monitorStats.minimumQuality)
    titleParts{end+1} = sprintf('Q_{min} = %.3f',b.monitorStats.minimumQuality); %#ok<AGROW>
end

title(ax,strjoin(titleParts,' | '), ...
    'FontWeight','normal', ...
    'FontSize',style.titleFontSize);

%% Optional publication export
% exportgraphics(f,'Shiyan_G1_UAV_path.png', ...
%     'Resolution',style.exportResolution);

end
