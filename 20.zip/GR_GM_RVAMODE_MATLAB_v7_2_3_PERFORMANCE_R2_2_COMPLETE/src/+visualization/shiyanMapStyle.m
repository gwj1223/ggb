function style = shiyanMapStyle()
%SHIYANMAPSTYLE Unified publication style for Shiyan real-DEM maps.
%
% Keep all map appearance settings here so preview, proposed-algorithm,
% and baseline result maps use the same visual standard.
%
% IMPORTANT:
%   All physical/optimization data remain in metres internally.
%   Only plotting functions convert X/Y/Z to kilometres.
%   targetZOffset is a VISUAL offset only; it does not change monitoring
%   target geometry or the optimization/evaluation model.

%% Typography
style.fontName         = 'Times New Roman';
style.axisFontSize     = 11;
style.titleFontSize    = 12;
style.legendFontSize   = 9.5;
style.colorbarFontSize = 10.5;

%% Figure / camera
style.figurePosition   = [80 60 1180 800];
style.backgroundColor  = [1 1 1];
style.viewAzimuth      = 138;
style.viewElevation    = 31;
style.plotBoxAspect    = [1 1 0.62];
style.cameraProjection = 'orthographic';

%% DEM earth-tone palette
terrainCP = [ ...
    0.00   0.18 0.22 0.16
    0.22   0.29 0.35 0.24
    0.45   0.47 0.50 0.34
    0.65   0.62 0.59 0.42
    0.82   0.76 0.70 0.56
    1.00   0.93 0.91 0.85
    ];
style.terrainMap = localInterpolateMap(terrainCP,256);
style.terrainCLim = [];  % [] = use DEM min/max for this scene

%% Hillshade
style.hillshadeAzimuth  = 315;
style.hillshadeAltitude = 45;
style.hillshadeMin      = 0.68;
style.hillshadeMax      = 1.06;

%% Risk palette: pale yellow -> orange -> dark red
riskCP = [ ...
    0.00   1.00 0.96 0.76
    0.28   0.99 0.82 0.38
    0.52   0.97 0.58 0.18
    0.75   0.86 0.28 0.08
    1.00   0.58 0.03 0.05
    ];
style.riskMap = localInterpolateMap(riskCP,256);

% Fixed visible risk range across preview/result/baseline maps.
% Values below 0.35 are intentionally transparent and therefore are not
% represented on the quantitative colorbar. This keeps map colors and the
% colorbar numerically consistent.
style.riskCLim          = [0.35 0.62];
style.riskThreshold     = 0.35;
style.riskColorbarTicks = [0.35 0.40 0.50 0.60];
style.riskMaxAlpha      = 0.33;
style.riskAlphaExponent = 2.20;
style.riskZOffset       = 2.0;   % metres; visual anti-z-fighting offset

%% UAV route
style.pathColor      = [0.025 0.180 0.500];
style.pathHaloColor  = [1.000 1.000 1.000];
style.pathLineWidth  = 2.8;
style.pathHaloWidth  = 0.0;  % disabled: no route halo
style.pathMarkerSize = 20;
style.pathMarkerStep = 4;

% Multi-UAV publication palette: muted, terrain-compatible colours.
% Keep these separate from the single-UAV route style so changing the fleet
% figure does not alter the established single-UAV publication map.
style.multiUAVPathColors = [ ...
    0.150 0.330 0.600; ... % UAV-1 muted blue
    0.520 0.340 0.630; ... % UAV-2 muted purple
    0.100 0.560 0.520; ... % UAV-3 teal
    0.780 0.470 0.180; ... % UAV-4 muted orange
    0.300 0.520 0.280; ... % UAV-5 muted green
    0.380 0.380 0.380];    % UAV-6 neutral gray
style.multiUAVPathLineWidth = 2.3;
style.multiUAVPathHaloWidth = 0.0;  % disabled: no fleet route halo

%% Monitoring targets
style.normalTargetColor   = [0.000 0.350 0.950];
style.criticalTargetColor = [0.750 0.020 0.050];

% Slightly larger markers for 30-target publication maps.
style.normalTargetSize    = 62;
style.criticalTargetSize  = 88;

% Pure filled target markers: no halo and no marker edge.
style.targetEdgeColor = 'none';

% VISUAL ONLY: lift target symbols 75 m above terrain to reduce occlusion.
% The actual monitoring target coordinates and evaluation remain unchanged.
style.targetZOffset       = 75;
style.showTargetLabels    = false;

%% Start / Goal
style.startColor = [0.050 0.620 0.270];
style.goalColor  = [0.560 0.080 0.600];
style.startSize  = 105;
style.goalSize   = 110;

%% Axes
style.gridColor     = [0.72 0.72 0.72];
style.gridAlpha     = 0.24;
style.axisLineWidth = 0.9;

%% Export
style.exportResolution = 600;

end


function cmap = localInterpolateMap(cp,n)
x = linspace(0,1,n)';
cmap = [ ...
    interp1(cp(:,1),cp(:,2),x,'linear'), ...
    interp1(cp(:,1),cp(:,3),x,'linear'), ...
    interp1(cp(:,1),cp(:,4),x,'linear') ...
    ];
cmap = min(max(cmap,0),1);
end
