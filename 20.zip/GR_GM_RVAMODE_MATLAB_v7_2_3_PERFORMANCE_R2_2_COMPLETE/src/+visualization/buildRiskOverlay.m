function [riskRGB,riskAlpha,riskNorm] = buildRiskOverlay(problem,style)
%BUILDRISKOVERLAY Build the unified visible risk layer and alpha mask.
%
% The quantitative risk colour scale is defined only over the visible range
% style.riskCLim = [riskThreshold, riskMaximum]. Values below the threshold
% are fully transparent. Therefore the map and colorbar use exactly the same
% yellow -> orange -> dark-red mapping.
%
% This is visualization only. problem.risk itself is not modified.

R = double(problem.risk);
riskCLim = style.riskCLim;

if numel(riskCLim) ~= 2 || riskCLim(2) <= riskCLim(1)
    error('visualization:InvalidRiskCLim', ...
        'style.riskCLim must contain two increasing values.');
end
if style.riskThreshold < riskCLim(1)-eps || ...
        style.riskThreshold > riskCLim(2)+eps
    error('visualization:InvalidRiskThreshold', ...
        'style.riskThreshold must lie inside style.riskCLim.');
end

%% Normalize using exactly the range shown by the colorbar
riskNorm = (R-riskCLim(1)) ./ max(riskCLim(2)-riskCLim(1),eps);
riskNorm = min(max(riskNorm,0),1);

%% True-colour risk RGB
riskRGB = localRGBFromMap(riskNorm,style.riskMap);

%% Alpha mask
% riskThreshold equals the lower end of the visible colour range in the
% current publication style. Keeping the more general formula below makes
% the helper robust if a higher threshold is selected later.
thresholdNorm = (style.riskThreshold-riskCLim(1)) ./ ...
    max(riskCLim(2)-riskCLim(1),eps);
thresholdNorm = min(max(thresholdNorm,0),0.999);

visibleRisk = (riskNorm-thresholdNorm) ./ max(1-thresholdNorm,eps);
visibleRisk = min(max(visibleRisk,0),1);

riskAlpha = style.riskMaxAlpha .* ...
    visibleRisk.^style.riskAlphaExponent;

riskAlpha(R < style.riskThreshold) = 0;
riskAlpha(~isfinite(R)) = 0;

end


function rgb = localRGBFromMap(normValue,cmap)
normValue = min(max(normValue,0),1);
n = size(cmap,1);
index = 1 + normValue*(n-1);
base = (1:n)';
rgb = zeros([size(normValue),3]);
for c = 1:3
    values = interp1(base,cmap(:,c),index(:),'linear');
    rgb(:,:,c) = reshape(values,size(normValue));
end
rgb = min(max(rgb,0),1);
end
