function [terrainRGB,hillshade,terrainCLim] = buildTerrainRGB(problem,style)
%BUILDTERRAINRGB Build unified true-color DEM with hillshade.
%
% Inputs
%   problem.terrain : DEM elevation matrix
%   problem.gridX   : local easting grid (m)
%   problem.gridY   : local northing grid (m)
%   style           : visualization.shiyanMapStyle()
%
% Outputs
%   terrainRGB      : M-by-N-by-3 true-color terrain image
%   hillshade       : M-by-N illumination multiplier
%   terrainCLim     : elevation limits used for color mapping

Z = double(problem.terrain);

finiteZ = Z(isfinite(Z));
if isempty(finiteZ)
    error('visualization:InvalidDEM','DEM contains no finite values.');
end

if isempty(style.terrainCLim)
    terrainCLim = [min(finiteZ), max(finiteZ)];
else
    terrainCLim = style.terrainCLim;
end

if numel(terrainCLim) ~= 2 || terrainCLim(2) <= terrainCLim(1)
    error('visualization:InvalidTerrainCLim', ...
        'terrainCLim must contain two increasing values.');
end

%% Elevation -> earth-tone RGB
zNorm = (Z-terrainCLim(1)) ./ max(terrainCLim(2)-terrainCLim(1),eps);
zNorm = min(max(zNorm,0),1);
terrainRGB = localRGBFromMap(zNorm,style.terrainMap);

%% Grid spacing in metres
X = double(problem.gridX);
Y = double(problem.gridY);

dxValues = abs(diff(X,1,2));
dyValues = abs(diff(Y,1,1));
dxValues = dxValues(isfinite(dxValues) & dxValues > 0);
dyValues = dyValues(isfinite(dyValues) & dyValues > 0);

if isempty(dxValues)
    dx = 1;
else
    dx = median(dxValues);
end

if isempty(dyValues)
    dy = 1;
else
    dy = median(dyValues);
end

%% Surface normals
% MATLAB gradient: first output is derivative along columns (x),
% second output is derivative along rows (y).
[dZdx,dZdy] = gradient(Z,dx,dy);

nx = -dZdx;
ny = -dZdy;
nz = ones(size(Z));

normalLength = sqrt(nx.^2 + ny.^2 + nz.^2);
nx = nx ./ max(normalLength,eps);
ny = ny ./ max(normalLength,eps);
nz = nz ./ max(normalLength,eps);

%% Illumination direction
az  = style.hillshadeAzimuth;
alt = style.hillshadeAltitude;

% x=east, y=north, z=up
sx = cosd(alt) * sind(az);
sy = cosd(alt) * cosd(az);
sz = sind(alt);

illumination = nx.*sx + ny.*sy + nz.*sz;
illumination = (illumination + 1) ./ 2;
illumination = min(max(illumination,0),1);

hillshade = style.hillshadeMin + ...
    (style.hillshadeMax-style.hillshadeMin).*illumination;

%% Apply hillshade
for c = 1:3
    terrainRGB(:,:,c) = terrainRGB(:,:,c).*hillshade;
end
terrainRGB = min(max(terrainRGB,0),1);

% Invalid DEM pixels are shown white.
bad = ~isfinite(Z);
for c = 1:3
    tmp = terrainRGB(:,:,c);
    tmp(bad) = 1;
    terrainRGB(:,:,c) = tmp;
end

end


function rgb = localRGBFromMap(normValue,cmap)
normValue = min(max(normValue,0),1);
n = size(cmap,1);
index = 1 + normValue*(n-1);
base = (1:n)';
rgb = zeros([size(normValue),3]);
for c = 1:3
    values = interp1(base,cmap(:,c),index(:),'linear');
    rgb(:,:,c) = reshape(values,size(normValue));
end
rgb = min(max(rgb,0),1);
end
