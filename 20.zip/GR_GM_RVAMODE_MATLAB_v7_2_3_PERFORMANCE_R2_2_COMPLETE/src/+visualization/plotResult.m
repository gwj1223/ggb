function plotResult(problem,result,cfg)
%PLOTRESULT Plot v6.3.6 risk-balanced metrics and diagnostics.
best = localScalarBest(result,cfg);
archive = result.archive(:);

figure('Name','GR-GM-RVAMODE VI 3D Path');
surf(problem.gridX,problem.gridY,problem.terrain, ...
    'EdgeColor','none','FaceAlpha',0.72);
hold on;
contour3(problem.gridX,problem.gridY,problem.risk,8,'LineWidth',0.8);
for j = 1:size(problem.obstacles,1)
    o = problem.obstacles(j,:);
    [cx,cy,cz] = cylinder(o(3),24);
    cz = cz*o(4);
    surf(cx+o(1),cy+o(2),cz,'EdgeColor','none','FaceAlpha',0.40);
end
for m = 1:size(problem.monitorTargets,1)
    t = problem.monitorTargets(m,:);
    z = data.terrainHeight(problem,t(1),t(2))+2;
    scatter3(t(1),t(2),z,90,'^','filled');
    text(t(1),t(2),z+3,sprintf('M%d',m));
end
p = best.path;
plot3(p(:,1),p(:,2),p(:,3),'k-o','LineWidth',2,'MarkerSize',4);
scatter3(problem.start(1),problem.start(2),problem.start(3),70,'filled');
scatter3(problem.goal(1),problem.goal(2),problem.goal(3),70,'filled');
xlabel('X'); ylabel('Y'); zlabel('Z'); grid on; axis tight; view(45,30);
title(sprintf('Monitoring path | Qtrue=%.3f Qmin=%.3f L=%.1f D=%.3f', ...
    best.monitorQuality,best.monitorStats.minimumQuality, ...
    best.pathMetrics.rawLength,best.pathMetrics.detourRatio));

figure('Name','Pareto Front Final Threshold');
obj = vertcat(archive.objectives);
scatter3(obj(:,1),obj(:,2),1-obj(:,5),35,obj(:,3),'filled');
xlabel('Detour ratio'); ylabel('Mean-tail risk'); zlabel('Monitoring quality');
colorbar; grid on; title('Final-threshold Pareto archive (color=energy)');

figure('Name','Convergence and Thresholds');
gen = result.history(:,1);
yyaxis left;
plot(gen,result.history(:,8),'LineWidth',1.1); hold on;
plot(gen,result.history(:,9),'LineWidth',1.6);
hasCommonHV = size(result.history,2)>=60;
if hasCommonHV
    plot(gen,result.history(:,60),'LineWidth',1.1);
    if size(result.history,2)>=67
        plot(gen,result.history(:,67),'LineWidth',1.5);
    end
end
ylabel('Approx. hypervolume');
yyaxis right;
plot(gen,result.history(:,2),'LineWidth',1.1);
ylabel('Feasible individuals'); xlabel('Generation'); grid on;
if hasCommonHV
    if size(result.history,2)>=67
        legend('Current-threshold HV','Final-threshold HV', ...
            'Current Common HV','Best Common HV','Feasible count', ...
            'Location','best');
    else
        legend('Current-threshold HV','Final-threshold HV', ...
            'Common physical HV','Feasible count','Location','best');
    end
else
    legend('Current-threshold HV','Final-threshold HV', ...
        'Feasible count','Location','best');
end
title('Dual-archive convergence');


if size(result.history,2)>=84
    figure('Name','Final Stage Cost and Operators');
    yyaxis left;
    plot(gen,result.history(:,68),'LineWidth',1.6); hold on;
    plot(gen,result.history(:,69),'--','LineWidth',1.2);
    ylabel('Best physical cost / smoothness limit');
    yyaxis right;
    plot(gen,result.history(:,62:66),'LineWidth',1.1);
    ylabel('Operator probability'); xlabel('Generation'); grid on;
    legend('Best physical cost','Smoothness limit', ...
        'Smooth window','Shortcut','Arc shrink', ...
        'Arc rotation','Altitude smoothing','Location','best');
    title('Adaptive final-stage smooth cost refinement');
end

figure('Name','Monitoring Threshold Controller');
plot(gen,result.history(:,29),'LineWidth',1.4); hold on;
plot(gen,result.history(:,30),'LineWidth',1.4);
plot(gen,result.history(:,42)/max(cfg.monitorCriticalMinObservationLength,eps), ...
    'LineWidth',1.4);
plot(gen,result.history(:,43),'LineWidth',1.4);
yline(cfg.monitorMinTargetQuality,'--');
yline(cfg.monitorCriticalMinQuality,'--');
yline(1,'--');
yline(cfg.monitorCriticalMinLOSRatio,'--');
xlabel('Generation'); ylabel('Threshold / normalized length'); grid on;
legend('Minimum quality','Critical quality', ...
    'Critical observation length / final','Critical LOS', ...
    'Final minimum','Final critical','Final observation length', ...
    'Final LOS','Location','best');
title('Feasibility-feedback monitoring thresholds');

figure('Name','Monitoring Quality Components');
q = [best.monitorPerTarget(:),best.searchMonitorPerTarget(:), ...
    best.monitorStats.rangeQuality(:), ...
    best.monitorStats.heightQuality(:),best.monitorStats.losRatio(:), ...
    best.monitorStats.durationQuality(:)];
bar(q);
hold on; yline(cfg.monitorMinTargetQuality,'--');
ylim([0 1]); xlabel('Monitoring target'); ylabel('Quality'); grid on;
legend('True combined','Search combined','Range','Height','LOS', ...
    'Duration','Final minimum', ...
    'Location','bestoutside');
title('True and search-proxy monitoring quality components');

figure('Name','Observation Geometry');
yyaxis left;
bar(best.monitorStats.observationLength(:));
yline(cfg.monitorCriticalMinObservationLength,'--');
ylabel('Visible observation length');
yyaxis right;
plot(1:numel(best.monitorPerTarget),best.monitorStats.losRatio(:),'-o', ...
    'LineWidth',1.5);
yline(cfg.monitorCriticalMinLOSRatio,'--');
ylabel('Weighted LOS quality'); xlabel('Monitoring target'); grid on;
title('Observation duration and line of sight');
end

function best = localScalarBest(result,cfg)
if isfield(result,'best') && numel(result.best)==1
    best = result.best;
elseif isfield(result,'archive') && ~isempty(result.archive)
    best = selection.selectMonitoringCompromise(result.archive,cfg);
else
    error('visualization:MissingBest', ...
        'No scalar best solution or nonempty archive is available.');
end
best = best(1);
end
