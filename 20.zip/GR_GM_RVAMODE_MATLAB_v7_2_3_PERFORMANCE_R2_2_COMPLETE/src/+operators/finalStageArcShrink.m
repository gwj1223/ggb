function genes = finalStageArcShrink(ind,problem,cfg)
%FINALSTAGEARCSHRINK Contract an over-served observation arc conservatively.
pts = reshape(ind.genes,[],3);
K = size(pts,1);
genes = ind.genes;
if K < 2 || isempty(ind.monitorPerTarget), return; end
[targetIndex,surplus] = localTarget(ind,cfg);
if surplus <= 0.02, return; end

target = problem.monitorTargets(targetIndex,:);
[~,centre] = min(sum((pts(:,1:2)-target(1:2)).^2,2));
blockCount = min(K,3);
first = max(1,min(K-blockCount+1,centre-floor(blockCount/2)));
indices = first:(first+blockCount-1);
range = sort(localCfg(cfg,'finalStageArcShrinkFraction',[0.03 0.12]));
shrink = range(1)+(range(end)-range(1))*rand;
lower = cfg.monitorObservationRangeFactor(1)*target(4);
upper = cfg.monitorObservationRangeFactor(2)*target(4);
original = pts;
trustRatio = localCfg(cfg,'finalStageTrustRegionRatio',0.22);

for j = indices
    radial = original(j,1:2)-target(1:2);
    r = norm(radial);
    if r<=eps || r>1.35*upper, continue; end
    newR = max(1.08*lower,r*(1-shrink));
    if newR >= r-1e-12, continue; end
    newXY = target(1:2)+(newR/r)*radial;
    terrain = data.terrainHeight(problem,newXY(1),newXY(2));
    desiredZ = terrain+target(5);
    targetPoint = [newXY 0.80*original(j,3)+0.20*desiredZ];
    delta = targetPoint-original(j,:);
    if j==1, previous = problem.start; else, previous = original(j-1,:); end
    if j==K, following = problem.goal; else, following = original(j+1,:); end
    radius = trustRatio*max(min(norm(original(j,:)-previous), ...
        norm(following-original(j,:))),eps);
    pts(j,:) = original(j,:)+localLimit(delta,radius);
end

genes = reshape(pts,1,[]);
end

function [idx,surplus] = localTarget(ind,cfg)
q = ind.monitorPerTarget(:);
safe = localCfg(cfg,'finalStageSafeMinimumQuality',0.65)*ones(size(q));
critical = cfg.criticalTargetIndices(:);
critical = critical(critical>=1 & critical<=numel(q));
safe(critical) = localCfg(cfg,'finalStageSafeCriticalQuality',0.75);
values = q-safe;
[valuesSorted,order] = sort(values,'descend');
idx = order(1); surplus = valuesSorted(1);
end

function delta = localLimit(delta,radius)
n = norm(delta);
if n>radius && n>0, delta = delta*(radius/n); end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
