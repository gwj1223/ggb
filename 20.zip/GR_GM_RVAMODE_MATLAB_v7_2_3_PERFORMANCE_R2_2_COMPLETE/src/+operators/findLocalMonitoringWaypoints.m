function indices = findLocalMonitoringWaypoints(path,target)
%FINDLOCALMONITORINGWAYPOINTS Return internal points near a target.
if size(path,1)<=2, indices=[]; return; end
d=vecnorm(path(:,1:2)-target(1:2),2,2);
[~,nearest]=min(d);
indices=max(2,nearest-1):min(size(path,1)-1,nearest+1);
indices=indices(:)';
end
