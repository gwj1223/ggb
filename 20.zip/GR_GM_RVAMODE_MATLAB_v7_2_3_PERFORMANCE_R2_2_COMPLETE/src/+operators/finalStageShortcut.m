function genes = finalStageShortcut(ind,problem,cfg)
%FINALSTAGESHORTCUT Soft-delete a redundant waypoint block by a chord.
pts = reshape(ind.genes,[],3);
K = size(pts,1);
genes = ind.genes;
minSpan = max(2,round(localCfg(cfg,'finalStageShortcutMinSpan',2)));
maxSpan = min(K,round(localCfg(cfg,'finalStageShortcutMaxSpan',6)));
if K < minSpan, return; end

blocks = zeros(0,3);
for span = minSpan:maxSpan
    for first = 1:(K-span+1)
        last = first+span-1;
        if first==1, left = problem.start; else, left = pts(first-1,:); end
        if last==K, right = problem.goal; else, right = pts(last+1,:); end
        segment = [left;pts(first:last,:);right];
        excess = sum(vecnorm(diff(segment,1,1),2,2))-norm(right-left);
        blocks(end+1,:) = [first last excess]; %#ok<AGROW>
    end
end
if isempty(blocks), return; end
[~,order] = sort(blocks(:,3),'descend');
topCount = max(1,min(size(blocks,1),ceil(0.30*size(blocks,1))));
selected = blocks(order(randi(topCount)),:);
first = selected(1); last = selected(2); span = last-first+1;
if first==1, left = problem.start; else, left = pts(first-1,:); end
if last==K, right = problem.goal; else, right = pts(last+1,:); end

original = pts;
trustRatio = localCfg(cfg,'finalStageTrustRegionRatio',0.22);
alpha = 0.55+0.35*rand;
for q = 1:span
    j = first+q-1;
    chord = left+(q/(span+1))*(right-left);
    delta = alpha*(chord-original(j,:));
    if j==1, previous = problem.start; else, previous = original(j-1,:); end
    if j==K, following = problem.goal; else, following = original(j+1,:); end
    radius = trustRatio*max(min(norm(original(j,:)-previous), ...
        norm(following-original(j,:))),eps);
    pts(j,:) = original(j,:)+localLimit(delta,radius);
end

genes = reshape(pts,1,[]);
end

function delta = localLimit(delta,radius)
n = norm(delta);
if n>radius && n>0, delta = delta*(radius/n); end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
