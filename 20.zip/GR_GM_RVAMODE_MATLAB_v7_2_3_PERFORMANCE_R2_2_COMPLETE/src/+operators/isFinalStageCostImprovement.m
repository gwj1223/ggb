function [tf,diag] = isFinalStageCostImprovement(cand,best,cfg)
%ISFINALSTAGECOSTIMPROVEMENT Accept safe flight-cost gains with risk guards.
diag = struct('relativeGain',-inf,'relativeChange',nan(1,4), ...
    'monitoringMarginSatisfied',false,'dispersionSatisfied',false, ...
    'finalFeasible',false,'smoothnessGuard',false, ...
    'progressiveSmoothnessGuard',false,'progressiveSmoothnessLimit',NaN, ...
    'riskGuard',false,'progressiveRiskGuard',false, ...
    'progressiveRiskLimit',NaN,'tailRiskGuard',false, ...
    'progressiveTailRiskGuard',false,'progressiveTailRiskLimit',NaN, ...
    'energyGuard',false,'reward',0);
tf = false;
if isempty(cand) || isempty(best) || ~cand.feasible || ~best.feasible
    return;
end

[finalMask,~,~] = evaluation.checkFinalMonitoringFeasibility(cand,cfg);
diag.finalFeasible = isscalar(finalMask) && finalMask;
if ~diag.finalFeasible, return; end

margin = localCfg(cfg,'finalStageMonitoringSafetyMargin', ...
    [0.02 0.03 0.50 0.03]);
margin = reshape(margin,1,[]);
if numel(margin)<4, margin(4)=0; end
safeMinimum = max(cfg.monitorMinTargetQuality+margin(1), ...
    localCfg(cfg,'finalStageSafeMinimumQuality',0.65));
safeCritical = max(cfg.monitorCriticalMinQuality+margin(2), ...
    localCfg(cfg,'finalStageSafeCriticalQuality',0.75));
safeObservation = max(cfg.monitorCriticalMinObservationLength+margin(3), ...
    localCfg(cfg,'finalStageSafeObservationLength',9.0));
safeLOS = max(cfg.monitorCriticalMinLOSRatio+margin(4), ...
    localCfg(cfg,'finalStageSafeLOSRatio',0.50));
stats = cand.monitorStats;
marginOK = stats.minimumQuality >= safeMinimum-cfg.constraintTolerance && ...
    stats.criticalQuality >= safeCritical-cfg.constraintTolerance && ...
    stats.minimumCriticalObservationLength >= ...
        safeObservation-cfg.constraintTolerance && ...
    stats.minimumCriticalLOSRatio >= safeLOS-cfg.constraintTolerance;
diag.monitoringMarginSatisfied = marginOK;
if ~marginOK, return; end

maxDispersion = localCfg(cfg,'finalStageMaxMonitoringDispersion',0.22);
diag.dispersionSatisfied = stats.dispersionPenalty <= ...
    maxDispersion+cfg.constraintTolerance;
if ~diag.dispersionSatisfied, return; end

bestCost = best.objectives(1:4);
candCost = cand.objectives(1:4);
bestTailRisk = localTailRisk(best,bestCost(2));
candTailRisk = localTailRisk(cand,candCost(2));

smoothLimit = max( ...
    bestCost(4)*localCfg(cfg,'finalStageMaxSmoothnessRatio',1.05), ...
    bestCost(4)+localCfg(cfg,'finalStageMaxSmoothnessAbsoluteIncrease',0.005));
riskLimit = max( ...
    bestCost(2)*localCfg(cfg,'finalStageMaxRiskRatio',1.02), ...
    bestCost(2)+localCfg(cfg,'finalStageMaxRiskAbsoluteIncrease',0.006));
tailRiskLimit = max( ...
    bestTailRisk*localCfg(cfg,'finalStageMaxTailRiskRatio',1.02), ...
    bestTailRisk+localCfg(cfg,'finalStageMaxTailRiskAbsoluteIncrease',0.012));
energyLimit = max( ...
    bestCost(3)*localCfg(cfg,'finalStageMaxEnergyRatio',1.01), ...
    bestCost(3)+localCfg(cfg,'finalStageMaxEnergyAbsoluteIncrease',1.0));

finalStageGeneration = max(1,localCfg(cfg,'runtimeFinalStageGeneration',1));

% Progressive smoothness ceiling.
tighteningGenerations = max(1,localCfg(cfg, ...
    'finalStageSmoothnessTighteningGenerations',80));
progress = min(1,max(0,(finalStageGeneration-1)/ ...
    max(tighteningGenerations-1,1)));
relaxedLimit = localCfg(cfg,'finalStageSmoothnessRelaxedLimit',0.170);
targetLimit = localCfg(cfg,'finalStageSmoothnessTargetLimit',0.135);
absoluteSmoothLimit = relaxedLimit+progress*(targetLimit-relaxedLimit);
diag.progressiveSmoothnessLimit = absoluteSmoothLimit;
aboveTolerance = localCfg(cfg, ...
    'finalStageSmoothnessAboveLimitTolerance',1e-6);
if bestCost(4)>absoluteSmoothLimit
    progressiveSmoothLimit = bestCost(4)+aboveTolerance;
else
    progressiveSmoothLimit = absoluteSmoothLimit;
end

% Progressive risk and tail-risk ceilings. When the parent is above the
% current ceiling, a candidate may only hold or improve the corresponding
% risk metric. Once below the ceiling, the absolute ceiling is enforced.
riskTighteningGenerations = max(1,localCfg(cfg, ...
    'finalStageRiskTighteningGenerations',80));
riskProgress = min(1,max(0,(finalStageGeneration-1)/ ...
    max(riskTighteningGenerations-1,1)));
riskRelaxed = localCfg(cfg,'finalStageRiskRelaxedLimit',0.38);
riskTarget = localCfg(cfg,'finalStageRiskTargetLimit',0.34);
absoluteRiskLimit = riskRelaxed+riskProgress*(riskTarget-riskRelaxed);
tailRelaxed = localCfg(cfg,'finalStageTailRiskRelaxedLimit',0.62);
tailTarget = localCfg(cfg,'finalStageTailRiskTargetLimit',0.56);
absoluteTailLimit = tailRelaxed+riskProgress*(tailTarget-tailRelaxed);
riskTolerance = localCfg(cfg,'finalStageRiskAboveLimitTolerance',1e-6);
if bestCost(2)>absoluteRiskLimit
    progressiveRiskLimit = bestCost(2)+riskTolerance;
else
    progressiveRiskLimit = absoluteRiskLimit;
end
if bestTailRisk>absoluteTailLimit
    progressiveTailLimit = bestTailRisk+riskTolerance;
else
    progressiveTailLimit = absoluteTailLimit;
end
diag.progressiveRiskLimit = absoluteRiskLimit;
diag.progressiveTailRiskLimit = absoluteTailLimit;

diag.smoothnessGuard = candCost(4) <= smoothLimit+eps;
diag.progressiveSmoothnessGuard = ...
    candCost(4) <= progressiveSmoothLimit+eps;
diag.riskGuard = candCost(2) <= riskLimit+eps;
diag.progressiveRiskGuard = candCost(2) <= progressiveRiskLimit+eps;
diag.tailRiskGuard = candTailRisk <= tailRiskLimit+eps;
diag.progressiveTailRiskGuard = ...
    candTailRisk <= progressiveTailLimit+eps;
diag.energyGuard = candCost(3) <= energyLimit+eps;
if ~(diag.smoothnessGuard && diag.progressiveSmoothnessGuard && ...
        diag.riskGuard && diag.progressiveRiskGuard && ...
        diag.tailRiskGuard && diag.progressiveTailRiskGuard && ...
        diag.energyGuard)
    return;
end

scaleFloor = localCfg(cfg,'finalStageCostScaleFloor', ...
    [0.05 0.05 20.0 0.05]);
scale = max(abs(bestCost),reshape(scaleFloor,1,[]));
relativeChange = (candCost-bestCost)./max(scale,eps);
weights = localCfg(cfg,'finalStageCostWeights',[0.27 0.31 0.22 0.20]);
weights = max(reshape(weights,1,[]),0);
weights = weights/max(sum(weights),eps);
relativeGain = sum(weights.*(-relativeChange));
maxDeterioration = reshape(localCfg(cfg, ...
    'finalStageCostMaxRelativeDeterioration',[0.02 0.015 0.01 0.03]),1,[]);
relativeTailGain = (bestTailRisk-candTailRisk)/max(abs(bestTailRisk),0.10);

diag.relativeGain = relativeGain;
diag.relativeChange = relativeChange;
diag.reward = max(0,relativeGain)+ ...
    0.25*max(0,-relativeChange(2))+ ...
    0.15*max(0,relativeTailGain)+ ...
    0.15*max(0,-relativeChange(4))+ ...
    0.08*max(0,-relativeChange(1))+ ...
    0.08*max(0,-relativeChange(3));
tf = relativeGain > localCfg(cfg, ...
        'finalStageCostMinRelativeGain',5e-5) && ...
    all(relativeChange <= maxDeterioration+eps);
if ~tf, diag.reward = 0; end
end

function value = localTailRisk(ind,fallback)
value = fallback;
if isfield(ind,'riskStats') && isstruct(ind.riskStats) && ...
        isfield(ind.riskStats,'tailRisk') && ...
        isnumeric(ind.riskStats.tailRisk) && ...
        isscalar(ind.riskStats.tailRisk) && isfinite(ind.riskStats.tailRisk)
    value = ind.riskStats.tailRisk;
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
