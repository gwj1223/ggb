function state = initializeFinalStageOperatorState(cfg)
%INITIALIZEFINALSTAGEOPERATORSTATE Adaptive probabilities for five operators.
state.names = {'SmoothWindow','Shortcut','ArcShrink', ...
    'ArcRotation','AltitudeSmoothing'};
raw = localCfg(cfg,'finalStageOperatorInitialProbabilities', ...
    [0.28 0.24 0.16 0.14 0.18]);
state.probabilities = localNormalize(raw,cfg);
K = numel(state.names);
state.totalUses = zeros(1,K);
state.totalAccepted = zeros(1,K);
state.totalReward = zeros(1,K);
state.creditUses = zeros(1,K);
state.creditAccepted = zeros(1,K);
state.creditReward = zeros(1,K);
state.lastUses = zeros(1,K);
state.lastAccepted = zeros(1,K);
state.lastReward = zeros(1,K);
state.lastSuccessRate = zeros(1,K);
state.lastMeanAcceptedGain = zeros(1,K);
state.lastScore = ones(1,K)/K;
end

function p = localNormalize(raw,cfg)
raw = max(reshape(double(raw),1,[]),0);
K = numel(raw);
if sum(raw)<=eps, raw = ones(1,K); end
pMin = localCfg(cfg,'finalStageOperatorProbabilityMin',0.08);
pMax = localCfg(cfg,'finalStageOperatorProbabilityMax',0.45);
if K*pMin>=1, error('finalStageOperatorProbabilityMin is too large.'); end
p = pMin+(1-K*pMin)*raw/sum(raw);
for pass = 1:30
    above = p>pMax+1e-12;
    if ~any(above), break; end
    excess = sum(p(above)-pMax);
    p(above) = pMax;
    below = ~above;
    if ~any(below), break; end
    room = max(pMax-p(below),0);
    if sum(room)<=eps, break; end
    p(below) = p(below)+excess*room/sum(room);
end
p = max(p,pMin);
p = p/sum(p);
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
