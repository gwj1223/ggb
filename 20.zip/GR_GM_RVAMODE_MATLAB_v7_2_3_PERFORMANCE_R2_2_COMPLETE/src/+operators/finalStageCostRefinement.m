function [cand,operatorId,operatorName] = finalStageCostRefinement( ...
    ind,problem,cfg,gen,operatorState)
%FINALSTAGECOSTREFINEMENT Apply one adaptive smooth-cost neighbourhood.
if nargin < 5 || isempty(operatorState)
    operatorState = operators.initializeFinalStageOperatorState(cfg);
end
probabilities = operatorState.probabilities;
operatorId = find(rand<=cumsum(probabilities),1,'first');
if isempty(operatorId), operatorId = numel(probabilities); end
operatorName = operatorState.names{operatorId};

switch operatorId
    case 1
        genes = operators.finalStageSmoothWindow(ind,problem,cfg);
    case 2
        genes = operators.finalStageShortcut(ind,problem,cfg);
    case 3
        genes = operators.finalStageArcShrink(ind,problem,cfg);
    case 4
        genes = operators.finalStageArcRotation(ind,problem,cfg);
    otherwise
        genes = operators.finalStageAltitudeSmoothing(ind,problem,cfg);
end

cand = ind;
if isequaln(genes,ind.genes), return; end
cand.genes = genes;
cand = repair.repairPath(cand,problem,cfg);
cand = evaluation.evaluateIndividual(cand,problem,cfg,gen);
end
