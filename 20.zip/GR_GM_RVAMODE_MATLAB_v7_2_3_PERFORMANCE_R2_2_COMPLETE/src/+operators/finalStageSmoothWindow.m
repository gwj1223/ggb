function genes = finalStageSmoothWindow(ind,problem,cfg)
%FINALSTAGESMOOTHWINDOW Laplacian smoothing in a local trust region.
pts = reshape(ind.genes,[],3);
K = size(pts,1);
genes = ind.genes;
if K < 3, return; end

path = [problem.start;pts;problem.goal];
score = zeros(K,1);
for k = 1:K
    a = path(k,:); b = path(k+1,:); c = path(k+2,:);
    localScale = norm(b-a)+norm(c-b)+eps;
    score(k) = norm(a-2*b+c)/localScale;
end
[~,order] = sort(score,'descend');
topCount = max(1,min(K,ceil(0.35*K)));
centre = order(randi(topCount));
windowSize = round(localCfg(cfg,'finalStageSmoothWindowSize',5));
windowSize = max(3,min(K,windowSize));
if mod(windowSize,2)==0, windowSize = max(3,windowSize-1); end
half = floor(windowSize/2);
first = max(1,min(K-windowSize+1,centre-half));
indices = first:(first+windowSize-1);

original = pts;
alpha = 0.25+0.30*rand;
trustRatio = localCfg(cfg,'finalStageTrustRegionRatio',0.22);
for j = indices
    if j==1, previous = problem.start; else, previous = original(j-1,:); end
    if j==K, following = problem.goal; else, following = original(j+1,:); end
    target = 0.5*(previous+following);
    delta = alpha*(target-original(j,:));
    radius = trustRatio*max(min(norm(original(j,:)-previous), ...
        norm(following-original(j,:))),eps);
    pts(j,:) = original(j,:)+localLimit(delta,radius);
end

genes = reshape(pts,1,[]);
end

function delta = localLimit(delta,radius)
n = norm(delta);
if n>radius && n>0, delta = delta*(radius/n); end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
