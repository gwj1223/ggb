function [pop,stats,operatorState] = eliteLocalSearch( ...
    pop,problem,cfg,gen,operatorState)
%ELITELOCALSEARCH Mission recovery, then adaptive smooth cost refinement.
if nargin < 5 || isempty(operatorState)
    operatorState = operators.initializeFinalStageOperatorState(cfg);
end
Kop = numel(operatorState.probabilities);
stats = struct('evaluations',0,'accepted',0, ...
    'costEvaluations',0,'costAccepted',0, ...
    'operatorUses',zeros(1,Kop),'operatorAccepted',zeros(1,Kop), ...
    'operatorReward',zeros(1,Kop));
% v7.2.1: a structured individual is defined by structuredGenes and must be
% regenerated only through the structured decoder. The historical final-stage
% local operators edit XYZ genes directly; accepting them would leave a stale
% structured genotype attached to a different phenotype. Disable those legacy
% neighbourhoods until a semantic-space cost-refinement operator is introduced.
structuredMode = localCfg(cfg,'enableStructuredMonitoringEncoding',false) && ...
    localCfg(cfg,'structuredDisableLegacyXYZLocalSearch',true) && ...
    isfield(pop,'structuredGenes') && ...
    any(arrayfun(@(x)~isempty(x.structuredGenes),pop));
if structuredMode
    return;
end
pop = selection.assignRankCrowding(pop);
[~,ord] = sortrows([[pop.rank]' -[pop.crowding]'],[1 2]);
frac = cfg.localSearchMinFraction+ ...
    (cfg.localSearchMaxFraction-cfg.localSearchMinFraction)* ...
    (gen/cfg.maxGenerations)^2;
n = max(1,round(frac*numel(pop)));
finalStage = localCfg(cfg,'runtimeMonitoringFinalReached',false) && ...
    localCfg(cfg,'enableFinalStageCostRefinement',true);
costProbability = localCfg(cfg,'finalStageCostRefinementProbability',0.90);

for q = 1:min(n,numel(ord))
    i = ord(q);
    best = pop(i);
    for t = 1:cfg.localSearchTrials
        missionDeficit = evaluation.finalMonitoringDeficit(best,cfg);
        unifiedOwnsRecovery = localCfg(cfg,'unifiedMissionRepairOwnsMissionRecovery',false);
        if finalStage && unifiedOwnsRecovery && missionDeficit > cfg.constraintTolerance
            % v7.0.0: mission-infeasible individuals are repaired only by the
            % single population-level unifiedMissionRepair. Do not run a second
            % local observation-arc repair here.
            continue;
        end
        useCostRefinement = finalStage && ...
            missionDeficit <= cfg.constraintTolerance && ...
            (unifiedOwnsRecovery || rand < costProbability);
        if useCostRefinement
            [cand,operatorId] = operators.finalStageCostRefinement( ...
                best,problem,cfg,gen,operatorState);
            stats.evaluations = stats.evaluations+1;
            stats.costEvaluations = stats.costEvaluations+1;
            stats.operatorUses(operatorId) = ...
                stats.operatorUses(operatorId)+1;
            [accepted,diag] = operators.isFinalStageCostImprovement( ...
                cand,best,cfg);
            if accepted
                best = cand;
                stats.accepted = stats.accepted+1;
                stats.costAccepted = stats.costAccepted+1;
                stats.operatorAccepted(operatorId) = ...
                    stats.operatorAccepted(operatorId)+1;
                stats.operatorReward(operatorId) = ...
                    stats.operatorReward(operatorId)+diag.reward;
            end
        else
            cand = operators.worstTargetLocalSearch(best,problem,cfg,gen);
            stats.evaluations = stats.evaluations+1;
            if selection.isBetterDeb(cand,best) || ...
                    localMissionRecoveryAccept(cand,best,cfg)
                best = cand;
                stats.accepted = stats.accepted+1;
            end
        end
    end
    pop(i) = best;
end
if finalStage
    operatorState = operators.updateFinalStageOperatorState( ...
        operatorState,stats.operatorUses,stats.operatorAccepted, ...
        stats.operatorReward,cfg);
end
pop = selection.assignRankCrowding(pop);
end

function tf = localMissionRecoveryAccept(cand,best,cfg)
tf = false;
if ~(cand.feasible && best.feasible), return; end
bestDeficit = evaluation.finalMonitoringDeficit(best,cfg);
candDeficit = evaluation.finalMonitoringDeficit(cand,cfg);
missionGain = bestDeficit-candDeficit;
if missionGain <= localCfg(cfg,'monitorMissionMinGain',1e-4), return; end

detourOK = cand.objectives(1) <= best.objectives(1)+ ...
    localCfg(cfg,'monitorLocalMaxDetourIncrease',0.25);
riskOK = cand.objectives(2) <= best.objectives(2)+ ...
    localCfg(cfg,'monitorLocalMaxRiskIncrease',0.15);
energyOK = cand.objectives(3) <= ...
    localCfg(cfg,'monitorLocalMaxEnergyFactor',1.40)*best.objectives(3);
smoothOK = cand.objectives(4) <= best.objectives(4)+ ...
    localCfg(cfg,'monitorLocalMaxSmoothnessIncrease',0.75);
tf = detourOK && riskOK && energyOK && smoothOK;
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
