function candidate = worstTargetLocalSearch(base,problem,cfg,generation)
%WORSTTARGETLOCALSEARCH Insert a real observation arc at the weakest target.
if nargin<4, generation=cfg.maxGenerations; end
candidate = base;
if ~isfield(base,'monitorPerTarget') || isempty(base.monitorPerTarget)
    return;
end
if isfield(base,'monitorStats') && isfield(base.monitorStats,'repairTargetIndex')
    targetIndex = base.monitorStats.repairTargetIndex;
else
    targetIndex = evaluation.selectMonitoringRepairTarget(base.monitorStats,cfg);
end

zeroLike = base.monitorPerTarget(targetIndex) <= ...
    localCfg(cfg,'monitorArcInsertionTriggerQuality',0.05);
if isfield(base,'monitorStats') && ...
        isfield(base.monitorStats,'observationLength') && ...
        numel(base.monitorStats.observationLength)>=targetIndex
    zeroLike = zeroLike || ...
        base.monitorStats.observationLength(targetIndex)<=eps;
end
if zeroLike
    strength = localCfg(cfg,'monitorArcInsertionStrengthZero',1);
else
    strength = localCfg(cfg,'monitorArcInsertionStrength',0.75);
    if ismember(targetIndex,cfg.criticalTargetIndices(:)') && ...
            isfield(base,'monitorStats')
        obsDeficit = isfield(base.monitorStats,'observationLength') && ...
            numel(base.monitorStats.observationLength)>=targetIndex && ...
            base.monitorStats.observationLength(targetIndex) < ...
            localCfg(cfg,'monitorCriticalMinObservationLength',180);
        losDeficit = isfield(base.monitorStats,'losRatio') && ...
            numel(base.monitorStats.losRatio)>=targetIndex && ...
            base.monitorStats.losRatio(targetIndex) < ...
            localCfg(cfg,'monitorCriticalMinLOSRatio',0.45);
        if obsDeficit || losDeficit
            strength = max(strength,localCfg(cfg, ...
                'criticalGeometryArcInsertionStrength',0.90));
        end
    end
end
candidate.genes = operators.insertTargetObservationArc( ...
    candidate.genes,targetIndex,problem,cfg,strength);
candidate = repair.repairPath(candidate,problem,cfg);
candidate = evaluation.evaluateIndividual(candidate,problem,cfg,generation);
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
