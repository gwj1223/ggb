function context = buildTrialContext(pop,archive,cfg,generation)
%BUILDTRIALCONTEXT Precompute generation-constant DE ranking information.
%
% v7.1.0: when mission-band selection is enabled, p-best donors come from the
% static-feasible mission leader band rather than collapsing to exact D_M
% ordering whenever the scheduled mission-feasible set is empty.  The search
% archive is already mission-band filtered, so it can directly provide safe
% donor genes.  Legacy behavior is unchanged otherwise.

if nargin < 4 || isempty(generation), generation = 1; end
context = struct('pbestOrder',[],'pbestTopCount',0,'safeGenes',[], ...
    'safeStructuredGenes',[],'missionBandCount',0, ...
    'missionBandEffectiveEpsilon',NaN);
NP = numel(pop);
if NP == 0, return; end

useBand = localCfg(cfg,'enableMissionBandSelection',false) && ...
    localCfg(cfg,'enableUnifiedMissionDeficit',false);
if useBand
    band = selection.missionBandState(pop,cfg,generation,NP);
    leaders = find(band.searchAdmissible);
    context.missionBandCount = band.bandCount;
    context.missionBandEffectiveEpsilon = band.effectiveEpsilon;
    if isempty(leaders)
        staticIdx = find(band.staticFeasible);
        if isempty(staticIdx)
            [~,order] = sort([pop.cv],'ascend');
        else
            [~,q] = sort(band.missionDeficit(staticIdx),'ascend');
            order = staticIdx(q);
        end
    else
        view = pop(leaders);
        for i = 1:numel(view)
            view(i).feasible = true;
            view(i).cv = 0;
        end
        view = selection.assignRankCrowding(view);
        values = vertcat(view.objectives);
        score = sum(localNormalizeObjectives(values),2);
        rank = [view.rank]';
        crowd = [view.crowding]';
        [~,q] = sortrows([rank score -crowd],[1 2 3]);
        order = leaders(q);
    end
else
    feasible = find([pop.feasible]);
    if isempty(feasible)
        [~,order] = sort([pop.cv],'ascend');
    else
        values = vertcat(pop(feasible).objectives);
        score = sum(localNormalizeObjectives(values),2);
        [~,q] = sort(score,'ascend');
        order = feasible(q);
    end
end

order = order(:)';
p = localCfg(cfg,'pbestRate',0.20);
topCount = max(2,ceil(p*NP));
topCount = min(topCount,numel(order));
context.pbestOrder = order;
context.pbestTopCount = topCount;

if isempty(archive), return; end
if useBand
    donorArchive = archive;
else
    donorArchive = archive([archive.feasible]);
    if isempty(donorArchive), donorArchive = archive; end
end
if isempty(donorArchive), return; end
objectiveMatrix = vertcat(donorArchive.objectives);
normalized = localNormalizeObjectives(objectiveMatrix);
monitorScore = 0.35*normalized(:,2)+0.65*normalized(:,5);
[~,safeOrder] = sort(monitorScore,'ascend');
safeTopCount = max(1,ceil(p*numel(donorArchive)));
safeTopCount = min(safeTopCount,numel(safeOrder));
safeOrder = safeOrder(1:safeTopCount);
context.safeGenes = vertcat(donorArchive(safeOrder).genes);
if localCfg(cfg,'enableStructuredMonitoringEncoding',false) && ...
        isfield(donorArchive,'structuredGenes') && ...
        all(arrayfun(@(x)~isempty(x.structuredGenes),donorArchive(safeOrder)))
    context.safeStructuredGenes = vertcat(donorArchive(safeOrder).structuredGenes);
end
end

function normalized = localNormalizeObjectives(values)
mn = min(values,[],1);
mx = max(values,[],1);
normalized = bsxfun(@rdivide,bsxfun(@minus,values,mn),mx-mn+eps);
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
