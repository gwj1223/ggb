function state = updateFinalStageOperatorState(state,uses,accepted,reward,cfg)
%UPDATEFINALSTAGEOPERATORSTATE Learn reward per attempt with decayed memory.
uses = reshape(uses,1,[]);
accepted = reshape(accepted,1,[]);
reward = reshape(reward,1,[]);
K = numel(state.probabilities);
if numel(uses)~=K || numel(accepted)~=K || numel(reward)~=K
    error('Operator-statistic width does not match the operator state.');
end
state.lastUses = uses;
state.lastAccepted = accepted;
state.lastReward = reward;
state.totalUses = state.totalUses+uses;
state.totalAccepted = state.totalAccepted+accepted;
state.totalReward = state.totalReward+reward;

if ~isfield(state,'creditUses')
    state.creditUses = zeros(1,K);
    state.creditAccepted = zeros(1,K);
    state.creditReward = zeros(1,K);
end
decay = min(1,max(0,localCfg(cfg,'finalStageOperatorCreditDecay',0.90)));
state.creditUses = decay*state.creditUses+uses;
state.creditAccepted = decay*state.creditAccepted+accepted;
state.creditReward = decay*state.creditReward+reward;

% Beta(1,1) posterior prevents operators with one lucky trial from taking over.
successRate = (state.creditAccepted+1)./(state.creditUses+2);
meanAcceptedGain = state.creditReward./max(state.creditAccepted,1);
exploration = 1./sqrt(state.creditUses+1);
state.lastSuccessRate = successRate;
state.lastMeanAcceptedGain = meanAcceptedGain;

successScore = localUnitScale(successRate);
gainScore = localUnitScale(meanAcceptedGain);
explorationScore = localUnitScale(exploration);
scoreWeights = localCfg(cfg,'finalStageOperatorScoreWeights', ...
    [0.35 0.55 0.10]);
scoreWeights = max(reshape(scoreWeights,1,[]),0);
if numel(scoreWeights)~=3, scoreWeights = [0.35 0.55 0.10]; end
scoreWeights = scoreWeights/max(sum(scoreWeights),eps);
score = scoreWeights(1)*successScore+ ...
    scoreWeights(2)*gainScore+scoreWeights(3)*explorationScore+ ...
    localCfg(cfg,'finalStageOperatorRewardFloor',1e-4);
state.lastScore = score;

if sum(uses)<=0, return; end
pressure = max(0.25,localCfg(cfg, ...
    'finalStageOperatorSelectionPressure',1.0));
target = localNormalize(score.^pressure,cfg);
eta = localCfg(cfg,'finalStageOperatorUpdateRate',0.20);
state.probabilities = localNormalize( ...
    (1-eta)*state.probabilities+eta*target,cfg);
end

function y = localUnitScale(x)
x = max(reshape(x,1,[]),0);
lo = min(x); hi = max(x);
if hi-lo<=1e-12
    y = ones(size(x));
else
    y = (x-lo)/(hi-lo);
end
end

function p = localNormalize(raw,cfg)
raw = max(reshape(double(raw),1,[]),0);
K = numel(raw);
if sum(raw)<=eps, raw = ones(1,K); end
pMin = localCfg(cfg,'finalStageOperatorProbabilityMin',0.08);
pMax = localCfg(cfg,'finalStageOperatorProbabilityMax',0.45);
if K*pMin>=1, error('finalStageOperatorProbabilityMin is too large.'); end
p = pMin+(1-K*pMin)*raw/sum(raw);
for pass = 1:30
    above = p>pMax+1e-12;
    if ~any(above), break; end
    excess = sum(p(above)-pMax);
    p(above) = pMax;
    below = ~above;
    if ~any(below), break; end
    room = max(pMax-p(below),0);
    if sum(room)<=eps, break; end
    p(below) = p(below)+excess*room/sum(room);
end
p = max(p,pMin);
p = p/sum(p);
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
