function genes = finalStageAltitudeSmoothing(ind,problem,cfg)
%FINALSTAGEALTITUDESMOOTHING Reduce climb-angle changes without moving XY.
pts = reshape(ind.genes,[],3);
K = size(pts,1);
genes = ind.genes;
if K < 3, return; end
pathZ = [problem.start(3);pts(:,3);problem.goal(3)];
score = abs(pathZ(1:end-2)-2*pathZ(2:end-1)+pathZ(3:end));
[~,order] = sort(score,'descend');
topCount = max(1,min(K,ceil(0.35*K)));
centre = order(randi(topCount));
windowSize = min(K,max(3,round(localCfg(cfg,'finalStageSmoothWindowSize',5))));
if mod(windowSize,2)==0, windowSize = max(3,windowSize-1); end
half = floor(windowSize/2);
first = max(1,min(K-windowSize+1,centre-half));
indices = first:(first+windowSize-1);
strengthRange = sort(localCfg(cfg, ...
    'finalStageAltitudeSmoothingStrength',[0.25 0.55]));
alpha = strengthRange(1)+(strengthRange(end)-strengthRange(1))*rand;
trustRatio = localCfg(cfg,'finalStageTrustRegionRatio',0.22);
original = pts;

for j = indices
    if j==1, previous = problem.start; else, previous = original(j-1,:); end
    if j==K, following = problem.goal; else, following = original(j+1,:); end
    targetZ = 0.5*(previous(3)+following(3));
    deltaZ = alpha*(targetZ-original(j,3));
    radius = trustRatio*max(min(norm(original(j,:)-previous), ...
        norm(following-original(j,:))),eps);
    deltaZ = max(-radius,min(radius,deltaZ));
    terrain = data.terrainHeight(problem,original(j,1),original(j,2));
    minimumZ = terrain+cfg.safeClearance+0.5;
    pts(j,3) = min(cfg.maxAltitude,max(minimumZ,original(j,3)+deltaZ));
end

genes = reshape(pts,1,[]);
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
