function [genes,editedIndices] = insertTargetObservationArc( ...
    genes,targetIndex,problem,cfg,strength)
%INSERTTARGETOBSERVATIONARC Replace a local waypoint block by a smooth arc.
% v7.0.0 gives Critical targets a slightly longer, DEM/LOS-guided observation
% block and reuses the same target-specific sector/radius geometry as A1/A3.
if nargin < 5 || isempty(strength), strength = 1; end
strength = min(max(strength,0),1);
pts = reshape(genes,[],3);
K = size(pts,1);
if K==0 || targetIndex<1 || targetIndex>size(problem.monitorTargets,1)
    editedIndices = [];
    return;
end

target = problem.monitorTargets(targetIndex,:);
isCritical = ismember(targetIndex,cfg.criticalTargetIndices(:)');
[~,centre] = min(sum((pts(:,1:2)-target(1:2)).^2,2));
if isCritical
    blockCount = min(K,max(5,round(localCfg( ...
        cfg,'criticalMonitorArcInsertionWaypoints',6))));
    desiredArcCount = max(3,round(localCfg( ...
        cfg,'criticalMonitorArcInsertionArcPoints',4)));
    baseAngleDeg = localCfg(cfg,'criticalMonitorArcInsertionViewAngleDeg',46);
else
    blockCount = min(K,max(3,round(localCfg( ...
        cfg,'monitorArcInsertionWaypoints',5))));
    desiredArcCount = max(2,round(localCfg(cfg,'monitorGuidedArcPoints',3)));
    baseAngleDeg = localCfg(cfg,'monitorGuidedViewAngleDeg',28);
end
first = max(1,min(K-blockCount+1,centre-floor(blockCount/2)));
editedIndices = first:(first+blockCount-1);
if first==1, previous = problem.start; else, previous = pts(first-1,:); end
if editedIndices(end)==K
    following = problem.goal;
else
    following = pts(editedIndices(end)+1,:);
end

% Keep at least one connector when possible while allowing Critical targets
% enough explicit arc points to sustain the 180 m observation requirement.
maxArc = blockCount;
if blockCount>=5, maxArc = blockCount-2; end
arcCount = min(maxArc,desiredArcCount);
arcCount = max(2,arcCount);
arcXY = localArcXY(target,targetIndex,previous(1:2),following(1:2), ...
    arcCount,baseAngleDeg,problem,cfg);
arcTerrain = data.terrainHeight(problem,arcXY(:,1),arcXY(:,2));
arcZ = arcTerrain(:)+target(5);
arc = [arcXY arcZ];

remaining = blockCount-arcCount;
preCount = floor(remaining/2);
postCount = remaining-preCount;
ideal = zeros(blockCount,3);
row = 1;
for j = 1:preCount
    a = j/(preCount+1);
    xy = (1-a)*previous(1:2)+a*arc(1,1:2);
    zLinear = (1-a)*previous(3)+a*arc(1,3);
    terrain = data.terrainHeight(problem,xy(1),xy(2));
    ideal(row,:) = [xy max(zLinear,terrain+cfg.safeClearance+2)];
    row = row+1;
end
ideal(row:row+arcCount-1,:) = arc;
row = row+arcCount;
for j = 1:postCount
    a = j/(postCount+1);
    xy = (1-a)*arc(end,1:2)+a*following(1:2);
    zLinear = (1-a)*arc(end,3)+a*following(3);
    terrain = data.terrainHeight(problem,xy(1),xy(2));
    ideal(row,:) = [xy max(zLinear,terrain+cfg.safeClearance+2)];
    row = row+1;
end

pts(editedIndices,:) = (1-strength)*pts(editedIndices,:)+strength*ideal;
genes = pts(:)';
end

function arcXY = localArcXY(target,targetIndex,previousXY,nextXY,count, ...
    baseAngleDeg,problem,cfg)
targetXY = target(1:2);
incoming = previousXY-targetXY;
outgoing = nextXY-targetXY;
if norm(incoming)>eps, incoming = incoming/norm(incoming); end
if norm(outgoing)>eps, outgoing = outgoing/norm(outgoing); end
routeDirection = incoming+outgoing;
if norm(routeDirection)<1e-8
    route = nextXY-previousXY;
    routeDirection = [-route(2) route(1)];
end
if norm(routeDirection)<1e-8, routeDirection = [1 0]; end
geom = core.observationArcGeometry(targetIndex,problem,cfg,routeDirection,1, ...
    baseAngleDeg,localCfg(cfg,'monitorGuidedRadiusScale',1));
radius = geom.radius;
base = geom.direction;
angle = geom.halfAngleRad;
offsets = linspace(-angle,angle,count);
arcXY = zeros(count,2);
for j = 1:count
    R = [cos(offsets(j)) -sin(offsets(j)); ...
        sin(offsets(j)) cos(offsets(j))];
    arcXY(j,:) = targetXY+radius*(R*base')';
end
reverseXY = flipud(arcXY);
forwardCost = norm(previousXY-arcXY(1,:))+ ...
    sum(vecnorm(diff(arcXY,1,1),2,2))+norm(arcXY(end,:)-nextXY);
reverseCost = norm(previousXY-reverseXY(1,:))+ ...
    sum(vecnorm(diff(reverseXY,1,1),2,2))+norm(reverseXY(end,:)-nextXY);
if reverseCost < forwardCost, arcXY = reverseXY; end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
