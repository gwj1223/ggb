function [trial,F,CR,strategyId] = generateTrial(i,pop,archive,muF,muCR,strategyProb,problem,cfg,gen,context)
%GENERATETRIAL v6.3.6 risk-balanced multi-strategy differential evolution operator.
% Improvements over v6.2.1:
%   1) positive Cauchy sampling for F and Gaussian sampling for CR;
%   2) random p-best guidance instead of a single deterministic best;
%   3) optional use of the archive in the second difference vector;
%   4) waypoint-block crossover that changes X/Y/Z together.
% v6.4.1 optionally accepts a generation-level CONTEXT with cached p-best
% and monitoring-priority rankings. Existing callers remain compatible.
if nargin < 10 || isempty(context)
    context = operators.buildTrialContext(pop,archive,cfg);
end
NP = numel(pop);
D = numel(pop(i).genes);
K = cfg.numWaypoints;
strategyId = find(rand<=cumsum(strategyProb),1,'first');
if isempty(strategyId), strategyId = numel(strategyProb); end

F = localSampleF(muF(strategyId),cfg);
CR = min(cfg.CRmax,max(cfg.CRmin, ...
    muCR(strategyId)+localCfg(cfg,'CRnormalScale',0.08)*randn));

% v7.2.0: semantic DE operates on structuredGenes while the established
% XYZ genes remain the decoded phenotype consumed by repair/evaluation.
if localCfg(cfg,'enableStructuredMonitoringEncoding',false) && ...
        isfield(pop,'structuredGenes') && ~isempty(pop(i).structuredGenes)
    trial = localGenerateStructuredTrial(i,pop,archive,F,CR,strategyId, ...
        problem,cfg,gen,context);
    return;
end

x = pop(i).genes;

% Choose a random member from the pre-ranked best p fraction.  The Randi
% call is intentionally retained here so seeded runs preserve the same random
% sampling semantics as the original per-offspring ranking implementation.
if isempty(context.pbestOrder) || context.pbestTopCount < 1
    pbestIdx = localPBestIndex(pop,cfg);
else
    pbestIdx = context.pbestOrder(randi(context.pbestTopCount));
end
pbest = pop(pbestIdx).genes;

% Population donors are kept distinct from the target whenever possible.
ids = setdiff(1:NP,i);
ids = ids(randperm(numel(ids)));
r1 = ids(1);
r2pop = ids(min(2,numel(ids)));
r3 = ids(min(3,numel(ids)));

% The archive is a diversity source for current-to-pbest/1. This is not the
% final reporting archive semantics; it is only used as a donor pool.
r2 = pop(r2pop).genes;
if localCfg(cfg,'useArchiveDifference',true) && ~isempty(archive) && rand<0.5
    r2 = archive(randi(numel(archive))).genes;
end

% A monitoring-priority guide supports local task-specific differential search.
if isfield(context,'safeGenes') && ~isempty(context.safeGenes)
    safe = context.safeGenes(randi(size(context.safeGenes,1)),:);
elseif ~isempty(archive)
    % Defensive legacy fallback if a caller supplied an incomplete context.
    feasibleArchive = archive([archive.feasible]);
    if isempty(feasibleArchive), feasibleArchive = archive; end
    objectiveMatrix = vertcat(feasibleArchive.objectives);
    normalized = localNormalizeObjectives(objectiveMatrix);
    monitorScore = 0.35*normalized(:,2)+0.65*normalized(:,5);
    topCount = max(1,ceil(localCfg(cfg,'pbestRate',0.20)*numel(feasibleArchive)));
    [~,order] = sort(monitorScore,'ascend');
    q = order(randi(min(topCount,numel(order))));
    safe = feasibleArchive(q).genes;
else
    safe = pbest;
end

localWaypointSet = 1:K;
switch strategyId
    case 1
        % DE/rand/1: exploration.
        donor = pop(r1).genes+F*(pop(r2pop).genes-pop(r3).genes);
    case 2
        % DE/current-to-pbest/1 with optional archive difference: convergence.
        donor = x+F*(pbest-x)+F*(pop(r1).genes-r2);
    otherwise
        % Monitoring-guided local differential mutation: task refinement.
        donor = x;
        if isfield(pop(i).monitorStats,'repairTargetIndex')
            targetIdx = pop(i).monitorStats.repairTargetIndex;
        elseif isfield(pop(i).monitorStats,'worstTargetIndex')
            targetIdx = pop(i).monitorStats.worstTargetIndex;
        else
            [~,targetIdx] = min(pop(i).monitorPerTarget);
        end
        localWaypointSet = operators.findLocalMonitoringWaypoints( ...
            pop(i).path,problem.monitorTargets(targetIdx,:));
        localWaypointSet = localWaypointSet-1; % path includes fixed start.
        localWaypointSet = unique(localWaypointSet( ...
            localWaypointSet>=1 & localWaypointSet<=K));
        if isempty(localWaypointSet), localWaypointSet = 1:K; end
        dims = unique([localWaypointSet,localWaypointSet+K, ...
            localWaypointSet+2*K]);
        donor(dims) = x(dims)+F*(safe(dims)-x(dims))+ ...
            F*(pop(r1).genes(dims)-r2(dims));
end

if localCfg(cfg,'waypointBlockCrossover',true)
    waypointMask = rand(1,K)<CR;
    if strategyId==3
        allowed = false(1,K);
        allowed(localWaypointSet) = true;
        waypointMask = waypointMask & allowed;
    end
    if ~any(waypointMask)
        candidates = 1:K;
        if strategyId==3, candidates = localWaypointSet; end
        waypointMask(candidates(randi(numel(candidates)))) = true;
    end
    changed = find(waypointMask);
    mask = false(1,D);
    mask(unique([changed,changed+K,changed+2*K])) = true;
else
    mask = rand(1,D)<CR;
    if strategyId==3
        localMask = false(1,D);
        localMask(unique([localWaypointSet,localWaypointSet+K, ...
            localWaypointSet+2*K])) = true;
        mask = mask & localMask;
    end
    if ~any(mask), mask(randi(D)) = true; end
end

trial = pop(i);
trial.genes = x;
trial.genes(mask) = donor(mask);

% Early-stage perturbation remains small and vanishes with progress.
progress = gen/max(cfg.maxGenerations,1);
if rand<0.12*(1-progress)
    noiseScale = [cfg.initNoiseXY*ones(1,K), ...
        cfg.initNoiseXY*ones(1,K),cfg.initNoiseZ*ones(1,K)];
    trial.genes = trial.genes+0.15*randn(size(trial.genes)).*noiseScale;
end

% v7.0.0 deliberately performs no full observation-arc jump here.
% Strategy 3 remains a local task-guided differential mutation. Complete
% topological observation-corridor edits belong exclusively to
% core.unifiedMissionRepair, preventing duplicate A3 recovery pathways.

end

function F = localSampleF(mu,cfg)
scale = localCfg(cfg,'FcauchyScale',0.10);
useCauchy = localCfg(cfg,'useCauchyF',true);
if useCauchy
    F = -inf;
    attempt = 0;
    while F<=0 && attempt<20
        F = mu+scale*tan(pi*(rand-0.5));
        attempt = attempt+1;
    end
    if F<=0, F = mu; end
else
    F = mu+scale*randn;
end
F = min(cfg.Fmax,max(cfg.Fmin,F));
end

function idx = localPBestIndex(pop,cfg)
NP = numel(pop);
feasible = find([pop.feasible]);
if isempty(feasible)
    [~,order] = sort([pop.cv],'ascend');
else
    values = vertcat(pop(feasible).objectives);
    score = sum(localNormalizeObjectives(values),2);
    [~,q] = sort(score,'ascend');
    order = feasible(q);
end
p = localCfg(cfg,'pbestRate',0.20);
topCount = max(2,ceil(p*NP));
topCount = min(topCount,numel(order));
idx = order(randi(topCount));
end

function normalized = localNormalizeObjectives(values)
mn = min(values,[],1);
mx = max(values,[],1);
normalized = bsxfun(@rdivide,bsxfun(@minus,values,mn),mx-mn+eps);
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name)
    value = cfg.(name);
else
    value = defaultValue;
end
end


function trial = localGenerateStructuredTrial(i,pop,archive,F,CR,strategyId,problem,cfg,gen,context)
NP=numel(pop);
layout=core.structuredMonitoringLayout(problem,cfg);
x=reshape(pop(i).structuredGenes,1,[]);
D=numel(x);
if D~=layout.dimension
    error('operators:StructuredDimension','Structured gene dimension mismatch.');
end

if isempty(context.pbestOrder) || context.pbestTopCount<1
    pbestIdx=localPBestIndex(pop,cfg);
else
    pbestIdx=context.pbestOrder(randi(context.pbestTopCount));
end
pbest=reshape(pop(pbestIdx).structuredGenes,1,[]);
ids=setdiff(1:NP,i);
ids=ids(randperm(numel(ids)));
r1=ids(1);
r2pop=ids(min(2,numel(ids)));
r3=ids(min(3,numel(ids)));

r2=reshape(pop(r2pop).structuredGenes,1,[]);
if localCfg(cfg,'useArchiveDifference',true) && ~isempty(archive) && rand<0.5
    candidates=find(arrayfun(@(a)isfield(a,'structuredGenes') && ...
        ~isempty(a.structuredGenes) && numel(a.structuredGenes)==D,archive));
    if ~isempty(candidates)
        q=candidates(randi(numel(candidates)));
        r2=reshape(archive(q).structuredGenes,1,[]);
    end
end

if isfield(context,'safeStructuredGenes') && ~isempty(context.safeStructuredGenes)
    safe=context.safeStructuredGenes(randi(size(context.safeStructuredGenes,1)),:);
elseif ~isempty(archive)
    candidates=find(arrayfun(@(a)isfield(a,'structuredGenes') && ...
        ~isempty(a.structuredGenes) && numel(a.structuredGenes)==D,archive));
    if ~isempty(candidates)
        safe=reshape(archive(candidates(randi(numel(candidates)))).structuredGenes,1,[]);
    else
        safe=pbest;
    end
else
    safe=pbest;
end

selectedTarget=0;
switch strategyId
    case 1
        donor=reshape(pop(r1).structuredGenes,1,[])+F*( ...
            reshape(pop(r2pop).structuredGenes,1,[])- ...
            reshape(pop(r3).structuredGenes,1,[]));
    case 2
        donor=x+F*(pbest-x)+F*(reshape(pop(r1).structuredGenes,1,[])-r2);
    otherwise
        donor=x;
        if isfield(pop(i).monitorStats,'repairTargetIndex')
            selectedTarget=pop(i).monitorStats.repairTargetIndex;
        elseif isfield(pop(i).monitorStats,'worstTargetIndex')
            selectedTarget=pop(i).monitorStats.worstTargetIndex;
        else
            [~,selectedTarget]=min(pop(i).monitorPerTarget);
        end
        selectedTarget=min(max(round(selectedTarget),1),layout.targetCount);
        dims=layout.targetDims(selectedTarget,:);
        order=localStructuredOrder(problem,cfg);
        pos=find(order==selectedTarget,1,'first');
        if ~isempty(pos)
            dims=unique([dims layout.transitDims(pos) layout.transitDims(pos+1)]);
        end
        r1Structured=reshape(pop(r1).structuredGenes,1,[]);
        donor(dims)=x(dims)+F*(safe(dims)-x(dims))+ ...
            F*(r1Structured(dims)-r2(dims));
end

% Target-block crossover changes semantic observation structures together.
mask=false(1,D);
if strategyId==3
    dims=layout.targetDims(selectedTarget,:);
    order=localStructuredOrder(problem,cfg);
    pos=find(order==selectedTarget,1,'first');
    if ~isempty(pos)
        dims=unique([dims layout.transitDims(pos) layout.transitDims(pos+1)]);
    end
    localMask=rand(1,numel(dims))<CR;
    if ~any(localMask), localMask(randi(numel(dims)))=true; end
    mask(dims(localMask))=true;
else
    targetMask=rand(1,layout.targetCount)<CR;
    transitMask=rand(1,numel(layout.transitDims))<CR;
    if ~any(targetMask) && ~any(transitMask)
        targetMask(randi(layout.targetCount))=true;
    end
    for m=find(targetMask)
        mask(layout.targetDims(m,:))=true;
    end
    mask(layout.transitDims(transitMask))=true;
end

trial=pop(i);
trial.structuredGenes=x;
trial.structuredGenes(mask)=donor(mask);
progress=gen/max(cfg.maxGenerations,1);
if rand<0.12*(1-progress)
    trial.structuredGenes=trial.structuredGenes+ ...
        localCfg(cfg,'structuredGeneNoiseScale',0.05)*randn(1,D);
end
trial.structuredGenes=min(max(trial.structuredGenes,-1),1);
[trial.genes,trial.encodingInfo]=core.decodeStructuredMonitoringGenes( ...
    trial.structuredGenes,problem,cfg);
end

function order=localStructuredOrder(problem,cfg)
M=size(problem.monitorTargets,1);
if isfield(problem,'structuredMonitoringTargetOrder') && ...
        numel(problem.structuredMonitoringTargetOrder)==M
    order=reshape(problem.structuredMonitoringTargetOrder,1,[]);
else
    order=core.structuredMonitoringTargetOrder(problem,cfg);
end
end
