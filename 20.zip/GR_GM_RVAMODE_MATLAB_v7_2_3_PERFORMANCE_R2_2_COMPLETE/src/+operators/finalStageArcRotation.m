function genes = finalStageArcRotation(ind,problem,cfg)
%FINALSTAGEARCROTATION Rotate an over-served arc toward shorter connectors.
pts = reshape(ind.genes,[],3);
K = size(pts,1);
genes = ind.genes;
if K < 2 || isempty(ind.monitorPerTarget), return; end
[targetIndex,surplus] = localTarget(ind,cfg);
if surplus <= 0.02, return; end

target = problem.monitorTargets(targetIndex,:);
[~,centre] = min(sum((pts(:,1:2)-target(1:2)).^2,2));
blockCount = min(K,3);
first = max(1,min(K-blockCount+1,centre-floor(blockCount/2)));
indices = first:(first+blockCount-1);
if first==1, previous = problem.start; else, previous = pts(first-1,:); end
if indices(end)==K, following = problem.goal; else, following = pts(indices(end)+1,:); end
angles = localCfg(cfg,'finalStageArcRotationAnglesDeg',[-20 -10 10 20]);
angles = angles(:)';
if isempty(angles), return; end

bestPts = pts;
bestCost = inf;
for a = angles
    R = [cosd(a) -sind(a);sind(a) cosd(a)];
    candidate = pts;
    for j = indices
        radial = pts(j,1:2)-target(1:2);
        candidate(j,1:2) = target(1:2)+(R*radial')';
        terrain = data.terrainHeight(problem,candidate(j,1),candidate(j,2));
        candidate(j,3) = max(candidate(j,3),terrain+cfg.safeClearance+0.5);
    end
    segment = [previous;candidate(indices,:);following];
    cost = sum(vecnorm(diff(segment,1,1),2,2));
    if cost < bestCost
        bestCost = cost;
        bestPts = candidate;
    end
end

original = pts;
trustRatio = localCfg(cfg,'finalStageTrustRegionRatio',0.22);
for j = indices
    delta = bestPts(j,:)-original(j,:);
    if j==1, left = problem.start; else, left = original(j-1,:); end
    if j==K, right = problem.goal; else, right = original(j+1,:); end
    radius = trustRatio*max(min(norm(original(j,:)-left), ...
        norm(right-original(j,:))),eps);
    pts(j,:) = original(j,:)+localLimit(delta,radius);
end

genes = reshape(pts,1,[]);
end

function [idx,surplus] = localTarget(ind,cfg)
q = ind.monitorPerTarget(:);
safe = localCfg(cfg,'finalStageSafeMinimumQuality',0.65)*ones(size(q));
critical = cfg.criticalTargetIndices(:);
critical = critical(critical>=1 & critical<=numel(q));
safe(critical) = localCfg(cfg,'finalStageSafeCriticalQuality',0.75);
values = q-safe;
[valuesSorted,order] = sort(values,'descend');
idx = order(1); surplus = valuesSorted(1);
end

function delta = localLimit(delta,radius)
n = norm(delta);
if n>radius && n>0, delta = delta*(radius/n); end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
