function path = repairSegmentClearance(path,problem,cfg)
%REPAIRSEGMENTCLEARANCE Repair lower and upper AGL on evaluator-consistent grid.
%
% v7.0.5.1 fixes the sampling-contract regression introduced in v7.0.5.
% Default/demo configurations retain the evaluator's fixed cfg.segmentSamples
% grid, while Shiyan formal configurations use the same distance-adaptive
% grid as evaluateLocalAGLEnvelope. The repair therefore never sees a weaker
% or different hard-clearance grid than the evaluator selected by cfg.

n = size(path,1);
useUpper = isfield(cfg,'enableLocalAGLConstraint') && ...
    cfg.enableLocalAGLConstraint && isfield(cfg,'realMaximumAGL') && ...
    isfinite(cfg.realMaximumAGL);
policy = evaluation.aglSamplingPolicy(cfg);

for pass = 1:cfg.segmentRepairPasses
    numSegments=n-1;
    maxLowerDeficit=zeros(numSegments,1);
    maxUpperExcess=zeros(numSegments,1);

    if policy.isAdaptive
        for k=1:numSegments
            sample=evaluation.sampleSegmentTerrainAdaptive( ...
                path(k,:),path(k+1,:),problem,cfg);
            sampleZ=sample.z;
            lowerDeficit=sample.terrain+cfg.safeClearance+ ...
                cfg.segmentRepairMargin-sampleZ;
            maxLowerDeficit(k)=max(lowerDeficit);
            if useUpper
                upperExcess=sampleZ-(sample.terrain+cfg.realMaximumAGL- ...
                    cfg.segmentRepairMargin);
                maxUpperExcess(k)=max(upperExcess);
            end
        end
    else
        % Exact fixed-grid contract used by evaluateIndividual in legacy/demo
        % mode. Using cfg.segmentSamples here is intentional: a separate
        % repair-only grid can miss terrain points later checked by evaluator.
        cache=evaluation.buildPathSampleCache( ...
            path,problem,policy.fixedSamples,false);
        sampleZ=reshape(cache.points(:,3), ...
            cache.numSamples,cache.numSegments);
        lowerDeficit=cache.terrain+cfg.safeClearance+ ...
            cfg.segmentRepairMargin-sampleZ;
        maxLowerDeficit=max(lowerDeficit,[],1)';
        if useUpper
            upperExcess=sampleZ-(cache.terrain+cfg.realMaximumAGL- ...
                cfg.segmentRepairMargin);
            maxUpperExcess=max(upperExcess,[],1)';
        end
    end

    badLower=find(maxLowerDeficit>0);
    badUpper=find(maxUpperExcess>0);
    if isempty(badLower) && isempty(badUpper), break; end

    deltaByNode=zeros(n,1);
    if ~isempty(badLower)
        lift=cfg.segmentRepairRelaxation*maxLowerDeficit(badLower);
        deltaByNode=deltaByNode+localAccumulate(badLower,lift,n);
    end
    if ~isempty(badUpper)
        drop=cfg.segmentRepairRelaxation*maxUpperExcess(badUpper);
        deltaByNode=deltaByNode-localAccumulate(badUpper,drop,n);
    end
    path(:,3)=path(:,3)+deltaByNode;

    if n>2
        xy=path(2:end-1,1:2);
        h=data.terrainHeight(problem,xy(:,1),xy(:,2));
        lowerZ=h+cfg.safeClearance+cfg.segmentRepairMargin;
        upperZ=cfg.maxAltitude*ones(size(h));
        if useUpper
            upperZ=min(upperZ,h+cfg.realMaximumAGL-cfg.segmentRepairMargin);
        end
        path(2:end-1,3)=min(max(path(2:end-1,3),lowerZ),upperZ);
    end
end
end

function byNode = localAccumulate(bad,amount,n)
byNode = zeros(n,1);
bothMovable = bad>1 & bad+1<n;
if any(bothMovable)
    k = bad(bothMovable);
    halfAmount = 0.5*amount(bothMovable);
    idx = [k;k+1];
    val = [halfAmount;halfAmount];
    byNode = byNode+accumarray(idx,val,[n 1],@sum,0);
end
leftOnly = bad>1 & ~(bad+1<n);
if any(leftOnly)
    k = bad(leftOnly);
    byNode = byNode+accumarray(k,amount(leftOnly),[n 1],@sum,0);
end
rightOnly = ~(bad>1) & bad+1<n;
if any(rightOnly)
    k = bad(rightOnly)+1;
    byNode = byNode+accumarray(k,amount(rightOnly),[n 1],@sum,0);
end
end
