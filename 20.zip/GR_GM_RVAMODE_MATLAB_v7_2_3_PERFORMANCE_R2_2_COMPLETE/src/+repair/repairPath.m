function ind = repairPath(ind,problem,cfg)
%REPAIRPATH Bounded cyclic repair with local AGL flight-envelope enforcement.
pts = reshape(ind.genes,[],3);
lineVec = problem.goal-problem.start;
for pass = 1:cfg.maxRepairPasses
    previous = pts;
    pts(:,1) = min(max(pts(:,1),problem.xBounds(1)),problem.xBounds(2));
    pts(:,2) = min(max(pts(:,2),problem.yBounds(1)),problem.yBounds(2));
    % Preserve chromosome waypoint order. Global projection sorting can
    % rearrange a useful observation arc or obstacle detour. It remains
    % available only as an explicit backward-compatibility option.
    if isfield(cfg,'enableGlobalProgressSorting') && ...
            cfg.enableGlobalProgressSorting
        tau = ((pts-problem.start)*lineVec')/(dot(lineVec,lineVec)+eps);
        [~,ord] = sort(tau);
        pts = pts(ord,:);
    end

    h = data.terrainHeight(problem,pts(:,1),pts(:,2));
    lowerZ = h+cfg.safeClearance+cfg.segmentRepairMargin;
    upperZ = localUpperZ(h,cfg,cfg.segmentRepairMargin);
    pts(:,3) = min(max(pts(:,3),lowerZ),upperZ);

    for j = 1:size(problem.obstacles,1)
        o = problem.obstacles(j,:);
        v = pts(:,1:2)-o(1:2);
        dist = sqrt(sum(v.^2,2));
        inside = dist<o(3)+1 & pts(:,3)<=o(4)+2;
        zeroMask = inside & dist<eps;
        v(zeroMask,:) = repmat([1 0],sum(zeroMask),1);
        dist(zeroMask) = 1;
        if any(inside)
            direction = bsxfun(@rdivide,v(inside,:),dist(inside));
            pts(inside,1:2) = bsxfun(@plus,o(1:2), ...
                (o(3)+2).*direction);
        end
    end

    path = [problem.start;pts;problem.goal];
    path = repair.repairSegmentClearance(path,problem,cfg);
    for sweep = 1:2
        for k = 1:size(path,1)-2
            dx = norm(path(k+1,1:2)-path(k,1:2));
            maxDz = tand(cfg.maxClimbAngleDeg)*max(dx,eps);
            dz = path(k+1,3)-path(k,3);
            if abs(dz)>maxDz
                path(k+1,3) = path(k,3)+sign(dz)*maxDz;
            end
        end
        for k = size(path,1):-1:3
            dx = norm(path(k,1:2)-path(k-1,1:2));
            maxDz = tand(cfg.maxClimbAngleDeg)*max(dx,eps);
            dz = path(k-1,3)-path(k,3);
            if abs(dz)>maxDz
                path(k-1,3) = path(k,3)+sign(dz)*maxDz;
            end
        end
    end

    interiorXY = path(2:end-1,1:2);
    hInterior = data.terrainHeight(problem,interiorXY(:,1),interiorXY(:,2));
    lowerInterior = hInterior+cfg.safeClearance+cfg.segmentRepairMargin;
    upperInterior = localUpperZ(hInterior,cfg,cfg.segmentRepairMargin);
    path(2:end-1,3) = min(max(path(2:end-1,3),lowerInterior),upperInterior);
    path = repair.repairSegmentClearance(path,problem,cfg);
    pts = path(2:end-1,:);
    if max(abs(pts(:)-previous(:))) <= cfg.repairChangeTolerance
        break;
    end
end
ind.genes = reshape(pts,1,[]);
end

function upperZ = localUpperZ(terrain,cfg,margin)
upperZ = cfg.maxAltitude*ones(size(terrain));
if isfield(cfg,'enableLocalAGLConstraint') && cfg.enableLocalAGLConstraint && ...
        isfield(cfg,'realMaximumAGL') && isfinite(cfg.realMaximumAGL)
    upperZ = min(upperZ,terrain+cfg.realMaximumAGL-margin);
end
end
