function [ind,stats] = finalizeLocalAGL(ind,problem,cfg,generation)
%FINALIZELOCALAGL Feasibility-preserving dense final AGL validation/repair.
%
% v6.5.7 policy:
%   1) Dense-check the FORMAL AGL envelope first.
%   2) If the current path already satisfies the formal envelope, do not
%      perturb it merely to create extra internal AGL margin.
%   3) If repair is required, accept the repaired path only when it also
%      preserves any static/final-monitoring feasibility already achieved.
%   4) If a required repair is rejected, restore the original path and mark
%      its dense AGL violation in CV so downstream representative selection
%      cannot silently report a dense-invalid fallback.
%
% Formal constraints are unchanged:
%   cfg.safeClearance <= AGL <= cfg.realMaximumAGL.
if nargin < 4, generation = 1; end

stats = localEmptyStats();
if isempty(ind) || ~localCfg(cfg,'enableDenseFinalAGLRepair',false) || ...
        ~localCfg(cfg,'enableLocalAGLConstraint',false)
    return;
end

tol = localCfg(cfg,'constraintTolerance',1e-8);
step = max(1,localCfg(cfg,'denseFinalAGLRepairStep_m',8));
lowerMargin = max(0,localCfg(cfg,'denseFinalAGLLowerMargin_m',4));
upperMargin = max(0,localCfg(cfg,'denseFinalAGLUpperMargin_m',2));
extraPasses = max(1,round(localCfg(cfg,'denseFinalAGLRepairPasses',5)));

original = ind;
originalPath = localPath(original,problem);
before = localAGLDiagnostics(originalPath,problem,cfg,step);
stats = localStoreBefore(stats,before);
stats.staticFeasibleBefore = localStaticFeasible(original,tol);
stats.overallFeasibleBefore = localOverallFeasible(original,tol);
stats.finalMonitoringBefore = localFinalMonitoringFeasible(original,cfg);

% Most important v6.5.7 guard: a formally valid output path is already safe.
% Do not trade climb/turn/monitoring feasibility for unnecessary extra AGL
% margin such as forcing 60.7 m to 64 m.
if before.formalOK && ...
        localCfg(cfg,'denseFinalAGLRepairOnlyIfFormalViolation',true)
    stats.skippedFormalValid = true;
    stats.formalAGLOKAfter = true;
    stats.staticFeasibleAfter = stats.staticFeasibleBefore;
    stats.overallFeasibleAfter = stats.overallFeasibleBefore;
    stats.finalMonitoringAfter = stats.finalMonitoringBefore;
    stats.minAGLAfter = before.minAGL;
    stats.maxAGLAfter = before.maxAGL;
    stats.denseLowerViolationAfter = before.lowerViolation;
    stats.denseUpperViolationAfter = before.upperViolation;
    return;
end

segXY = diff(originalPath(:,1:2),1,1);
maxHorizontalSegment = max(vecnorm(segXY,2,2));
denseSamples = max(localCfg(cfg,'segmentRepairSamples',16), ...
    ceil(maxHorizontalSegment/step)+1);

denseCfg = cfg;
denseCfg.segmentRepairSamples = denseSamples;
denseCfg.segmentRepairPasses = max(localCfg(cfg,'segmentRepairPasses',3), ...
    extraPasses);
% Retain inherited repair margin when repair is genuinely necessary.
denseCfg.segmentRepairMargin = max([localCfg(cfg,'segmentRepairMargin',0), ...
    lowerMargin,upperMargin]);

candidate = repair.repairPath(original,problem,denseCfg);
candidate = evaluation.evaluateIndividual(candidate,problem,cfg,generation);
after = localAGLDiagnostics(candidate.path,problem,cfg,step);

stats.applied = true;
stats.passes = denseCfg.segmentRepairPasses;
stats.evaluations = 1;
stats.denseSamplesPerSegment = denseSamples;
stats = localStoreAfter(stats,after);
stats.staticFeasibleAfter = localStaticFeasible(candidate,tol);
stats.overallFeasibleAfter = localOverallFeasible(candidate,tol);
stats.finalMonitoringAfter = localFinalMonitoringFeasible(candidate,cfg);

preserveStatic = ~localCfg(cfg,'denseFinalAGLPreserveStaticFeasibility',true) || ...
    ~stats.staticFeasibleBefore || stats.staticFeasibleAfter;
preserveOverall = ~localCfg(cfg,'denseFinalAGLPreserveOverallFeasibility',true) || ...
    ~stats.overallFeasibleBefore || stats.overallFeasibleAfter;
preserveMonitoring = ~localCfg(cfg,'denseFinalAGLPreserveFinalMonitoring',true) || ...
    ~stats.finalMonitoringBefore || stats.finalMonitoringAfter;
acceptRepair = after.formalOK && preserveStatic && preserveOverall && ...
    preserveMonitoring;

if acceptRepair
    ind = candidate;
    stats.acceptedRepair = true;
    return;
end

% Reject cross-constraint damage. If the original itself failed the dense
% formal AGL check, keep its geometry but explicitly reflect the dense AGL
% violation in CV so later strict/relaxed/final/fallback selection rejects it.
stats.rolledBack = true;
ind = original;
if ~before.formalOK
    ind = localMarkDenseAGLViolation(ind,before,cfg,generation);
end
stats.formalAGLOKAfter = before.formalOK;
stats.staticFeasibleAfter = localStaticFeasible(ind,tol);
stats.overallFeasibleAfter = localOverallFeasible(ind,tol);
stats.finalMonitoringAfter = localFinalMonitoringFeasible(ind,cfg);
stats.minAGLAfter = before.minAGL;
stats.maxAGLAfter = before.maxAGL;
stats.denseLowerViolationAfter = before.lowerViolation;
stats.denseUpperViolationAfter = before.upperViolation;
end

function stats = localEmptyStats()
stats = struct( ...
    'applied',false, ...
    'passes',0, ...
    'evaluations',0, ...
    'denseSamplesPerSegment',0, ...
    'minAGLBefore',NaN, ...
    'maxAGLBefore',NaN, ...
    'minAGLAfter',NaN, ...
    'maxAGLAfter',NaN, ...
    'denseLowerViolationBefore',NaN, ...
    'denseUpperViolationBefore',NaN, ...
    'denseLowerViolationAfter',NaN, ...
    'denseUpperViolationAfter',NaN, ...
    'formalAGLOKBefore',false, ...
    'formalAGLOKAfter',false, ...
    'staticFeasibleBefore',false, ...
    'staticFeasibleAfter',false, ...
    'overallFeasibleBefore',false, ...
    'overallFeasibleAfter',false, ...
    'finalMonitoringBefore',false, ...
    'finalMonitoringAfter',false, ...
    'skippedFormalValid',false, ...
    'acceptedRepair',false, ...
    'rolledBack',false);
end

function path = localPath(ind,problem)
if isfield(ind,'path') && ~isempty(ind.path)
    path = ind.path;
else
    path = [problem.start;reshape(ind.genes,[],3);problem.goal];
end
end

function stats = localStoreBefore(stats,d)
stats.minAGLBefore = d.minAGL;
stats.maxAGLBefore = d.maxAGL;
stats.denseLowerViolationBefore = d.lowerViolation;
stats.denseUpperViolationBefore = d.upperViolation;
stats.formalAGLOKBefore = d.formalOK;
end

function stats = localStoreAfter(stats,d)
stats.minAGLAfter = d.minAGL;
stats.maxAGLAfter = d.maxAGL;
stats.denseLowerViolationAfter = d.lowerViolation;
stats.denseUpperViolationAfter = d.upperViolation;
stats.formalAGLOKAfter = d.formalOK;
end

function d = localAGLDiagnostics(path,problem,cfg,step)
d.minAGL = inf;
d.maxAGL = -inf;
d.lowerViolation = 0;
d.upperViolation = 0;
d.sampleCount = 0;
d.maximumSpacing_m = 0;
lower = localCfg(cfg,'safeClearance',-inf);
upper = localCfg(cfg,'realMaximumAGL',inf);
tol = localCfg(cfg,'constraintTolerance',1e-8);
for k = 1:size(path,1)-1
    a = path(k,:); b = path(k+1,:);
    horizontal = norm(b(1:2)-a(1:2));
    n = max(3,ceil(horizontal/step)+1);
    t = linspace(0,1,n)';
    pts = a+t.*(b-a);
    h = data.terrainHeight(problem,pts(:,1),pts(:,2));
    agl = pts(:,3)-h;
    d.sampleCount = d.sampleCount+n;
    if n>1
        d.maximumSpacing_m = max(d.maximumSpacing_m,horizontal/(n-1));
    end
    d.minAGL = min(d.minAGL,min(agl));
    d.maxAGL = max(d.maxAGL,max(agl));
    d.lowerViolation = d.lowerViolation + sum(max(0,lower-agl));
    if isfinite(upper)
        d.upperViolation = d.upperViolation + sum(max(0,agl-upper));
    end
end
d.formalOK = d.minAGL >= lower-tol && d.maxAGL <= upper+tol;
end

function tf = localStaticFeasible(ind,tol)
tf = false;
if isfield(ind,'staticCV') && isscalar(ind.staticCV) && isfinite(ind.staticCV)
    tf = ind.staticCV <= tol;
elseif isfield(ind,'cv') && isscalar(ind.cv) && isfinite(ind.cv)
    tf = ind.cv <= tol;
end
end


function tf = localOverallFeasible(ind,tol)
tf = false;
if isfield(ind,'cv') && isscalar(ind.cv) && isfinite(ind.cv)
    tf = ind.cv <= tol;
end
end

function tf = localFinalMonitoringFeasible(ind,cfg)
tf = false;
try
    mask = evaluation.checkFinalMonitoringFeasibility(ind,cfg);
    tf = isscalar(mask) && logical(mask);
catch
    % If the structure does not carry monitoring diagnostics, do not impose
    % a preservation requirement that cannot be evaluated confidently.
    tf = false;
end
end

function ind = localMarkDenseAGLViolation(ind,d,cfg,generation)
clearance = max(0,d.lowerViolation) + max(0,d.upperViolation);
if clearance <= 0
    return;
end
if ~isfield(ind,'violation') || isempty(ind.violation)
    ind.violation = struct();
end
ind.violation.clearance = max(localViolation(ind,'clearance'),clearance);
% Keep diagnostics aligned with the dense formal validation that caused the
% rejection. This avoids a fallback carrying stale 15 m AGL statistics.
ind.aglStats = struct('lowerViolation',d.lowerViolation, ...
    'upperViolation',d.upperViolation,'minimumAGL',d.minAGL, ...
    'maximumAGL',d.maxAGL,'sampleCount',d.sampleCount, ...
    'maximumSpacing_m',d.maximumSpacing_m);

collision = localViolation(ind,'collision');
climb = localViolation(ind,'climb');
turn = localViolation(ind,'turn');
energy = localViolation(ind,'energy');
ind.staticCV = collision/max(localCfg(cfg,'cvScaleCollision',1),eps) + ...
    ind.violation.clearance/max(localCfg(cfg,'cvScaleClearance',1),eps) + ...
    climb/max(localCfg(cfg,'cvScaleClimb',1),eps) + ...
    turn/max(localCfg(cfg,'cvScaleTurn',1),eps) + ...
    energy/max(localCfg(cfg,'cvScaleEnergy',1),eps);
try
    ind = evaluation.updateDynamicConstraints(ind,cfg,generation);
catch
    ind.cv = ind.staticCV;
    ind.feasible = ind.cv <= localCfg(cfg,'constraintTolerance',1e-8);
end
end

function value = localViolation(ind,name)
value = 0;
if isfield(ind,'violation') && isfield(ind.violation,name) && ...
        isscalar(ind.violation.(name)) && isfinite(ind.violation.(name))
    value = ind.violation.(name);
end
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
