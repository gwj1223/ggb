function [reps,stats] = finalizeRepresentativeSetAGL( ...
    reps,problem,cfg,generation)
%FINALIZEREPRESENTATIVESETAGL Validate/polish report candidates before select.
%
% v6.5.7 keeps v6.5.6 post-repair reselection, but dense AGL processing is
% now feasibility-preserving: formally AGL-valid candidates are untouched;
% necessary repairs are accepted only when they do not destroy feasibility.
if nargin < 4, generation = 1; end
stats = struct('totalEvaluations',0,'candidateCount',0, ...
    'candidateStats',[],'skippedFormalValidCount',0, ...
    'acceptedRepairCount',0,'rollbackCount',0, ...
    'formalInvalidAfterCount',0);
if isempty(reps) || ~isfield(reps,'solutions') || isempty(reps.solutions)
    return;
end
solutions = reps.solutions(:);
candidateStats = repmat(localEmptyCandidateStats(),numel(solutions),1);
for i = 1:numel(solutions)
    [solutions(i),candidateStats(i)] = repair.finalizeLocalAGL( ...
        solutions(i),problem,cfg,generation);
end
reps.solutions = solutions;

% Refresh all masks and physical costs from the actual post-validation paths.
referenceArchive = solutions;
reps.engineeringSatisfied = reshape(selection.engineeringLimitMask( ...
    solutions,cfg,'strict',referenceArchive),[],1);
reps.relaxedEngineeringSatisfied = reshape(selection.engineeringLimitMask( ...
    solutions,cfg,'relaxed',referenceArchive),[],1);
reps.finalConstraintsSatisfied = reshape(localFinalMask(solutions,cfg),[],1);
reps.physicalCost = metrics.finalStageCostIndicator(solutions,cfg);

stats.totalEvaluations = sum([candidateStats.evaluations]);
stats.candidateCount = numel(solutions);
stats.candidateStats = candidateStats;
stats.skippedFormalValidCount = sum([candidateStats.skippedFormalValid]);
stats.acceptedRepairCount = sum([candidateStats.acceptedRepair]);
stats.rollbackCount = sum([candidateStats.rolledBack]);
stats.formalInvalidAfterCount = sum(~[candidateStats.formalAGLOKAfter]);
end

function s = localEmptyCandidateStats()
s = struct( ...
    'applied',false,'passes',0,'evaluations',0, ...
    'denseSamplesPerSegment',0, ...
    'minAGLBefore',NaN,'maxAGLBefore',NaN, ...
    'minAGLAfter',NaN,'maxAGLAfter',NaN, ...
    'denseLowerViolationBefore',NaN,'denseUpperViolationBefore',NaN, ...
    'denseLowerViolationAfter',NaN,'denseUpperViolationAfter',NaN, ...
    'formalAGLOKBefore',false,'formalAGLOKAfter',false, ...
    'staticFeasibleBefore',false,'staticFeasibleAfter',false, ...
    'overallFeasibleBefore',false,'overallFeasibleAfter',false, ...
    'finalMonitoringBefore',false,'finalMonitoringAfter',false, ...
    'skippedFormalValid',false,'acceptedRepair',false,'rolledBack',false);
end

function mask = localFinalMask(archive,cfg)
archive = archive(:);
mask = reshape([archive.cv],[],1)<=cfg.constraintTolerance;
try
    missionMask = evaluation.checkFinalMonitoringFeasibility(archive,cfg);
    mask = mask & reshape(missionMask,[],1);
catch
end
end
