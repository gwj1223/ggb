function file = exportGeographicPath(problem,result,outDir)
%EXPORTGEOGRAPHICPATH Save the reported path with WGS84 coordinates.
b = result.best(1);
[lon,lat] = realdata.localXYToLonLat(problem,b.path(:,1),b.path(:,2));
ground = data.terrainHeight(problem,b.path(:,1),b.path(:,2));
T = table((1:size(b.path,1))',lon(:),lat(:),b.path(:,1),b.path(:,2), ...
    ground(:),b.path(:,3),b.path(:,3)-ground(:), ...
    'VariableNames',{'Waypoint','Longitude','Latitude','LocalX_m','LocalY_m', ...
    'TerrainElevation_m','FlightElevation_m','AGL_m'});
file = fullfile(outDir,'best_path_geographic.csv');
writetable(T,file);
end
