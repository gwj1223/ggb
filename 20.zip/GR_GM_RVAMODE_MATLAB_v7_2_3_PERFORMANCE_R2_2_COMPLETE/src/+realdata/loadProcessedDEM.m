function D = loadProcessedDEM(matFile)
%LOADPROCESSEDDEM Load and validate the self-contained Shiyan-G1 DEM MAT.
if ~isfile(matFile)
    error('realdata:MissingDEM','Processed DEM not found: %s',matFile);
end
D = load(matFile);
required = {'x','y','lon','lat','Z','slopeDeg','aspectDeg','curvature', ...
    'roughness','dZdx','dZdy','topographicSusceptibility','risk', ...
    'referenceLongitude','referenceLatitude','originEasting','originNorthing'};
for k=1:numel(required)
    if ~isfield(D,required{k})
        error('realdata:InvalidDEM','Missing field %s in %s.',required{k},matFile);
    end
end
D.x = D.x(:)';
D.y = D.y(:);
D.lon = D.lon(:)';
D.lat = D.lat(:);
if size(D.Z,1)~=numel(D.y) || size(D.Z,2)~=numel(D.x)
    error('realdata:InvalidDEM','DEM dimensions do not match x/y vectors.');
end
end
