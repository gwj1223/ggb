function [targets,meta] = buildMonitoringTargets(problem,cfg,def)
%BUILDMONITORINGTARGETS Create reproducible DEM-derived risk targets.
%
% v6.4.1: the geographic projection and terrain/geology interpolation are
% performed in vectorized batches.  Target coordinates, weights and all
% physical definitions are unchanged.

M = size(def.targetLonLat,1);
lon = def.targetLonLat(:,1);
lat = def.targetLonLat(:,2);
[x,y] = realdata.lonLatToLocalXY(lon,lat,problem.geo);
x = x(:);
y = y(:);

terrainZ = data.terrainHeight(problem,x,y);
r = data.riskValue(problem,x,y);

[xGrid,yGrid] = localGridVectors(problem);
slope = interp2(xGrid,yGrid,problem.geology.slopeDeg,x,y,'linear',NaN);
gx = interp2(xGrid,yGrid,problem.geology.dZdx,x,y,'linear',0);
gy = interp2(xGrid,yGrid,problem.geology.dZdy,x,y,'linear',0);

normals = [-gx(:) -gy(:) ones(M,1)];
normalLength = sqrt(sum(normals.^2,2));
normals = normals./max(normalLength,eps);

targets = [x y def.targetWeights(:) ...
    def.targetDesiredRange(:) def.targetDesiredHeight(:)];

meta = repmat(struct('type','','label','','lon',NaN,'lat',NaN, ...
    'terrainElevation',NaN,'slopeDeg',NaN,'risk',NaN, ...
    'surfaceNormal',[0 0 1]),M,1);
for m = 1:M
    meta(m).type = def.targetType{m};
    meta(m).label = def.targetLabel{m};
    meta(m).lon = lon(m);
    meta(m).lat = lat(m);
    meta(m).terrainElevation = terrainZ(m);
    meta(m).slopeDeg = slope(m);
    meta(m).risk = r(m);
    meta(m).surfaceNormal = normals(m,:);
end

cfg = cfg; %#ok<NASGU> % retained for future target-specific constraints
end

function [xGrid,yGrid] = localGridVectors(problem)
if isfield(problem,'gridXVector') && isfield(problem,'gridYVector')
    xGrid = problem.gridXVector;
    yGrid = problem.gridYVector;
else
    xGrid = problem.gridX(1,:);
    yGrid = problem.gridY(:,1);
end
xGrid = reshape(xGrid,1,[]);
yGrid = reshape(yGrid,[],1);
end
