function report = validateRealScene(problem,cfg)
%VALIDATEREALSCENE Defensive validation of real DEM problem construction.
report.ok = true;
report.messages = {};
report.gridSize = size(problem.terrain);
report.elevationRange = [min(problem.terrain(:)) max(problem.terrain(:))];
report.riskRange = [min(problem.risk(:)) max(problem.risk(:))];
report.extentMetres = [diff(problem.xBounds) diff(problem.yBounds)];
report.numTargets = size(problem.monitorTargets,1);

checks = { ...
    all(isfinite(problem.terrain(:))), 'DEM contains non-finite values'; ...
    all(problem.risk(:)>=0 & problem.risk(:)<=1), 'Risk proxy is outside [0,1]'; ...
    all(problem.start(1:2)>=[problem.xBounds(1) problem.yBounds(1)]) && ...
      all(problem.start(1:2)<=[problem.xBounds(2) problem.yBounds(2)]), 'Start outside ROI'; ...
    all(problem.goal(1:2)>=[problem.xBounds(1) problem.yBounds(1)]) && ...
      all(problem.goal(1:2)<=[problem.xBounds(2) problem.yBounds(2)]), 'Goal outside ROI'; ...
    size(problem.monitorTargets,1)==30, 'Expected 30 Shiyan-G1 risk targets'};
for k=1:size(checks,1)
    if ~checks{k,1}
        report.ok = false;
        report.messages{end+1} = checks{k,2}; %#ok<AGROW>
    end
end
startGround = data.terrainHeight(problem,problem.start(1),problem.start(2));
goalGround = data.terrainHeight(problem,problem.goal(1),problem.goal(2));
if problem.start(3)-startGround < cfg.safeClearance
    report.ok=false; report.messages{end+1}='Start clearance is insufficient';
end
if problem.goal(3)-goalGround < cfg.safeClearance
    report.ok=false; report.messages{end+1}='Goal clearance is insufficient';
end
if ~report.ok
    error('realdata:InvalidScene','Shiyan-G1 validation failed: %s', ...
        strjoin(report.messages,'; '));
end
end
