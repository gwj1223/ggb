function outFile = prepareShiyanG1Data(rawTif,outFile)
%PREPARESHIYANG1DATA Regenerate processed Shiyan-G1 MAT from GDEMV3 tile.
% This implementation has no Mapping Toolbox dependency. For the ASTER/GDEM
% 1-degree 3601x3601 tile it infers geographic grid posts from N32E110.
if nargin<1 || isempty(rawTif)
    error('realdata:MissingInput','Provide ASTGTMV003_N32E110_dem.tif.');
end
if nargin<2 || isempty(outFile)
    outFile = fullfile(fileparts(rawTif),'Shiyan_G1_DEM.mat');
end
Zfull = double(imread(rawTif));
[nr,nc] = size(Zfull);
name = char(rawTif);
tok = regexp(name,'N(\d\d)E(\d\d\d)','tokens','once');
if isempty(tok)
    error('realdata:UnsupportedTile','Cannot infer NxxExxx tile coordinates.');
end
lat0 = str2double(tok{1}); lon0 = str2double(tok{2});
lonFull = linspace(lon0,lon0+1,nc);
latFull = linspace(lat0+1,lat0,nr); % north to south
def = realdata.shiyanG1Definition();
roi = def.roiBoundsLonLat;
cols = find(lonFull>=roi(1) & lonFull<=roi(3));
rows = find(latFull>=roi(2) & latFull<=roi(4));
Z = flipud(Zfull(rows,cols));
lon = lonFull(cols); lat = fliplr(latFull(rows));
refLon = mean(lon); refLat = mean(lat);
[E,~] = realdata.lonLatToUTM49N(lon,refLat+zeros(size(lon)));
[~,N] = realdata.lonLatToUTM49N(refLon+zeros(size(lat)),lat);
x = E-E(1); y = N-N(1);
feat = realdata.deriveTerrainFeatures(Z,x,y);
[risk,topographicSusceptibility] = realdata.buildTopographicRisk(feat);
referenceLongitude=refLon; referenceLatitude=refLat; %#ok<NASGU>
originEasting=E(1); originNorthing=N(1); %#ok<NASGU>
roiBoundsLonLat=roi; utmZone=49; utmEPSG=32649; %#ok<NASGU>
slopeDeg=feat.slopeDeg; aspectDeg=feat.aspectDeg; curvature=feat.curvature; %#ok<NASGU>
roughness=feat.roughness; dZdx=feat.dZdx; dZdy=feat.dZdy; %#ok<NASGU>
gridSpacingX=median(diff(x)); gridSpacingY=median(diff(y)); %#ok<NASGU>
sourceFilename=string(rawTif); sourceCRS='EPSG:4326'; %#ok<NASGU>
save(outFile,'x','y','lon','lat','Z','slopeDeg','aspectDeg','curvature', ...
    'roughness','dZdx','dZdy','topographicSusceptibility','risk', ...
    'roiBoundsLonLat','utmZone','utmEPSG','referenceLongitude', ...
    'referenceLatitude','originEasting','originNorthing','gridSpacingX', ...
    'gridSpacingY','sourceFilename','sourceCRS','-v7');
end
