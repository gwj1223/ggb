function [E,N] = lonLatToUTM49N(lon,lat)
%LONLATTOUTM49N WGS84 forward UTM projection, zone 49N, no toolbox needed.
% Vectorized implementation of the standard Transverse Mercator series.
a = 6378137.0;
f = 1/298.257223563;
e2 = f*(2-f);
ep2 = e2/(1-e2);
k0 = 0.9996;
lon0 = deg2rad(111); % central meridian of UTM zone 49
phi = deg2rad(lat);
lambda = deg2rad(lon);
Nphi = a./sqrt(1-e2*sin(phi).^2);
T = tan(phi).^2;
C = ep2*cos(phi).^2;
A = cos(phi).*(lambda-lon0);
M = a*((1-e2/4-3*e2^2/64-5*e2^3/256).*phi ...
    -(3*e2/8+3*e2^2/32+45*e2^3/1024).*sin(2*phi) ...
    +(15*e2^2/256+45*e2^3/1024).*sin(4*phi) ...
    -(35*e2^3/3072).*sin(6*phi));
E = 500000+k0*Nphi.*(A+(1-T+C).*A.^3/6+ ...
    (5-18*T+T.^2+72*C-58*ep2).*A.^5/120);
N = k0*(M+Nphi.*tan(phi).*(A.^2/2+ ...
    (5-T+9*C+4*C.^2).*A.^4/24+ ...
    (61-58*T+T.^2+600*C-330*ep2).*A.^6/720));
end
