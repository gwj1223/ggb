function file = exportSceneMetadata(problem,outDir)
%EXPORTSCENEMETADATA Export target semantics and terrain diagnostics.
M = size(problem.monitorTargets,1);
type = string(problem.monitorTargetTypes(:));
label = string(problem.monitorTargetLabels(:));
lon = problem.monitorTargetLonLat(:,1);
lat = problem.monitorTargetLonLat(:,2);
terrainZ = problem.monitorTargetTerrain(:);

if isfield(problem,'gridXVector') && isfield(problem,'gridYVector')
    xGrid = problem.gridXVector;
    yGrid = problem.gridYVector;
else
    xGrid = problem.gridX(1,:);
    yGrid = problem.gridY(:,1);
end
xq = problem.monitorTargets(:,1);
yq = problem.monitorTargets(:,2);
slope = interp2(xGrid,yGrid,problem.geology.slopeDeg,xq,yq,'linear');
risk = data.riskValue(problem,xq,yq);

T = table((1:M)',type,label,lon,lat,problem.monitorTargets(:,1), ...
    problem.monitorTargets(:,2),terrainZ,slope(:),risk(:), ...
    problem.monitorTargets(:,3),problem.monitorTargets(:,4), ...
    problem.monitorTargets(:,5), ...
    'VariableNames',{'Target','Type','Label','Longitude','Latitude', ...
    'LocalX_m','LocalY_m','TerrainElevation_m','Slope_deg','RiskProxy', ...
    'Weight','DesiredRange_m','DesiredAGL_m'});
file = fullfile(outDir,'shiyan_g1_scene_targets.csv');
writetable(T,file);
end
