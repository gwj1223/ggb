function feat = deriveTerrainFeatures(Z,x,y)
%DERIVETERRAINFEATURES Slope, aspect, curvature and roughness from a DEM.
dx = median(diff(x));
dy = median(diff(y));
[dZdy,dZdx] = gradient(double(Z),dy,dx);
feat.dZdx = dZdx;
feat.dZdy = dZdy;
feat.slopeDeg = atand(hypot(dZdx,dZdy));
feat.aspectDeg = mod(atan2d(-dZdx,dZdy),360);

% Seven-cell local standard deviation without Image Processing Toolbox.
k = 7;
K = ones(k)/(k*k);
mu = conv2(double(Z),K,'same');
mu2 = conv2(double(Z).^2,K,'same');
feat.roughness = sqrt(max(mu2-mu.^2,0));

% Small Gaussian smoothing followed by the 2-D Laplacian.
r = -3:3;
g = exp(-0.5*(r/1.2).^2); g = g/sum(g);
S = conv2(conv2(double(Z),g,'same'),g','same');
[gy,gx] = gradient(S,dy,dx);
[gyy,~] = gradient(gy,dy,dx);
[~,gxx] = gradient(gx,dy,dx);
feat.curvature = gxx+gyy;
end
