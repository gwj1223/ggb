function [x,y] = lonLatToLocalXY(lon,lat,geo)
%LONLATT LOCALXY Rectified local metric coordinates for Shiyan-G1.
% X is UTM49N easting evaluated along the scene reference latitude and Y is
% UTM49N northing evaluated along the scene reference longitude. This keeps
% the DEM grid rectilinear for interp2 while retaining metre-scale geometry.
[E,~] = realdata.lonLatToUTM49N(lon, ...
    geo.referenceLatitude+zeros(size(lon)));
[~,N] = realdata.lonLatToUTM49N( ...
    geo.referenceLongitude+zeros(size(lat)),lat);
x = E-geo.originEasting;
y = N-geo.originNorthing;
end
