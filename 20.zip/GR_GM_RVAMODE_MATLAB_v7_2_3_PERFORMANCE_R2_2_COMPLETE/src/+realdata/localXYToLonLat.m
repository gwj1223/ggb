function [lon,lat] = localXYToLonLat(problem,x,y)
%LOCALXYTOLONLAT Convert local Shiyan-G1 metric axes back to WGS84.
% Since the optimization grid is rectified from UTM49N center lines, the
% geographic coordinates are recovered by 1-D interpolation of stored axes.
lon = interp1(problem.gridX(1,:),problem.geo.lon,x,'linear','extrap');
lat = interp1(problem.gridY(:,1),problem.geo.lat,y,'linear','extrap');
end
