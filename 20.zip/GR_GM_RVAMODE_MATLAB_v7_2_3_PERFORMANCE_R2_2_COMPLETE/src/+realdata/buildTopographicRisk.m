function [risk,susceptibility,components] = buildTopographicRisk(feat)
%BUILDTOPOGRAPHICRISK DEM-derived terrain susceptibility and flight-risk proxy.
% This is a reproducible proxy for algorithm experiments, not a calibrated
% landslide probability or an official geological-hazard map.
rs = localRobust01(feat.slopeDeg,10,98);
rr = localRobust01(feat.roughness,10,98);
rc = localRobust01(abs(feat.curvature),10,98);
susceptibility = min(max(0.52*rs+0.28*rr+0.20*rc,0),1);
% Lightweight 3x3 smoothing.
K = [1 2 1;2 4 2;1 2 1]/16;
susceptibility = conv2(susceptibility,K,'same');
susceptibility = min(max(susceptibility,0),1);
risk = min(max(0.04+0.58*susceptibility,0),1);
components.slope = rs;
components.roughness = rr;
components.curvature = rc;
end

function q = localRobust01(a,p0,p1)
v = sort(double(a(isfinite(a))));
if isempty(v), q = zeros(size(a)); return; end
lo = localPercentileSorted(v,p0);
hi = localPercentileSorted(v,p1);
q = min(max((double(a)-lo)/max(hi-lo,eps),0),1);
end

function value = localPercentileSorted(v,p)
pos = 1+(numel(v)-1)*p/100;
lo = floor(pos); hi = ceil(pos);
if lo==hi, value=v(lo); else
    value = v(lo)+(pos-lo)*(v(hi)-v(lo));
end
end
