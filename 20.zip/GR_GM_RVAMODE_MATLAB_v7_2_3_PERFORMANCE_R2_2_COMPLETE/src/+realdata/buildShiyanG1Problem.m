function [problem,cfg,scene] = buildShiyanG1Problem(projectRoot,cfg)
%BUILDSHIYANG1PROBLEM Construct the real-DEM Shiyan-G1 optimization problem.
if nargin<1 || isempty(projectRoot)
    projectRoot = fileparts(fileparts(fileparts(mfilename('fullpath'))));
end
if nargin<2 || isempty(cfg), cfg = config.shiyanG1Config(); end
matFile = fullfile(projectRoot,cfg.realProcessedDEM);
D = realdata.loadProcessedDEM(matFile);
def = realdata.shiyanG1Definition();

[X,Y] = meshgrid(double(D.x),double(D.y));
problem.name = def.sceneName;
problem.sceneId = def.sceneId;
problem.xBounds = [min(D.x) max(D.x)];
problem.yBounds = [min(D.y) max(D.y)];
problem.gridX = X;
problem.gridY = Y;
% Compact rectilinear axes used by high-frequency interpolation helpers.
problem.gridXVector = double(D.x(:)');
problem.gridYVector = double(D.y(:));
problem.terrain = double(D.Z);
problem.risk = double(D.risk);
% v7.2.3 Performance R2: immutable real-DEM interpolation cache identity.
% This affects only interpolation object reuse; DEM values and bilinear
% interpolation semantics are unchanged.
problem.enableTerrainInterpolatorCache = localCfg(cfg, ...
    'enableTerrainInterpolatorCache',true);
problem.terrainInterpolationCacheId = sprintf( ...
    '%s|%dx%d|%.17g|%.17g|%.17g|%.17g|%.17g|%.17g', ...
    def.sceneId,size(problem.terrain,1),size(problem.terrain,2), ...
    problem.gridXVector(1),problem.gridXVector(end), ...
    problem.gridYVector(1),problem.gridYVector(end), ...
    min(problem.terrain(:)),max(problem.terrain(:)));
problem.obstacles = zeros(0,4); % DEM is the hard terrain obstacle.
problem.wind = cfg.realAssumedWind;

problem.geo.crs = 'EPSG:4326';
problem.geo.metricCRS = 'EPSG:32649';
problem.geo.utmZone = 49;
problem.geo.referenceLongitude = double(D.referenceLongitude(1));
problem.geo.referenceLatitude = double(D.referenceLatitude(1));
problem.geo.originEasting = double(D.originEasting(1));
problem.geo.originNorthing = double(D.originNorthing(1));
problem.geo.lon = double(D.lon(:)');
problem.geo.lat = double(D.lat(:));
problem.geo.roiBoundsLonLat = double(D.roiBoundsLonLat(:)');

problem.geology.slopeDeg = double(D.slopeDeg);
problem.geology.aspectDeg = double(D.aspectDeg);
problem.geology.curvature = double(D.curvature);
problem.geology.roughness = double(D.roughness);
problem.geology.dZdx = double(D.dZdx);
problem.geology.dZdy = double(D.dZdy);
problem.geology.topographicSusceptibility = ...
    double(D.topographicSusceptibility);
problem.geology.flightRiskProxy = double(D.risk);
problem.geology.riskIsProxy = true;
problem.geology.riskDescription = [ ...
    'DEM-derived topographic flight-risk proxy; not an official geological-hazard probability'];

% Absolute altitude ceiling is tied to this DEM rather than the synthetic
% demo elevation scale.
cfg.maxAltitude = max(problem.terrain(:))+cfg.realMaximumAGL;
problem.zBounds = [min(problem.terrain(:)) cfg.maxAltitude];

[sx,sy] = realdata.lonLatToLocalXY(def.startLonLat(1), ...
    def.startLonLat(2),problem.geo);
[gx,gy] = realdata.lonLatToLocalXY(def.goalLonLat(1), ...
    def.goalLonLat(2),problem.geo);
problem.start = [sx sy data.terrainHeight(problem,sx,sy)+cfg.realStartGoalAGL];
problem.goal  = [gx gy data.terrainHeight(problem,gx,gy)+cfg.realStartGoalAGL];

[problem.monitorTargets,targetMeta] = ...
    realdata.buildMonitoringTargets(problem,cfg,def);
problem.monitorTargetTerrain = data.terrainHeight(problem, ...
    problem.monitorTargets(:,1),problem.monitorTargets(:,2));
problem.monitorTargetTypes = {targetMeta.type}';
problem.monitorTargetLabels = {targetMeta.label}';
problem.monitorTargetNormals = vertcat(targetMeta.surfaceNormal);
problem.monitorTargetLonLat = [[targetMeta.lon]' [targetMeta.lat]'];
problem.monitorTargetMeta = targetMeta;
cfg.criticalTargetIndices = def.criticalIndices;
problem.cfg = cfg;

scene.definition = def;
scene.dataFile = matFile;
scene.targetMeta = targetMeta;
scene.validation = realdata.validateRealScene(problem,cfg);
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
