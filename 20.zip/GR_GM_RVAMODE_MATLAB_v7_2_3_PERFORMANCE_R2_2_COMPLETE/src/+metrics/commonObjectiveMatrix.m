function obj = commonObjectiveMatrix(archive)
%COMMONOBJECTIVEMATRIX Version-independent physical five-objective matrix.
% The fifth component is one minus the true minimum target quality.
if isempty(archive)
    obj = zeros(0,5);
    return;
end
archive = archive(:);
base = vertcat(archive.objectives);
obj = [base(:,1:4),1-localColumn(arrayfun( ...
    @(x)x.monitorStats.minimumQuality,archive))];
end

function value = localColumn(value)
value = reshape(value,[],1);
end
