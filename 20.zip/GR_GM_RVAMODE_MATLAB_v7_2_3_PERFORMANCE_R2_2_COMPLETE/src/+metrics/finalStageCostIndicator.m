function value = finalStageCostIndicator(archive,cfg)
%FINALSTAGECOSTINDICATOR Fixed-scale physical flight-cost score.
if isempty(archive)
    value = zeros(0,1);
    return;
end
archive = archive(:);
obj = vertcat(archive.objectives);
obj = obj(:,1:4);
ideal = localCfg(cfg,'finalStageCostIndicatorIdeal',[1.00 0.00 90 0.00]);
scale = localCfg(cfg,'finalStageCostIndicatorScale',[0.50 0.50 200 0.20]);
weights = localCfg(cfg,'finalStageCostIndicatorWeights',[0.30 0.20 0.25 0.25]);
ideal = reshape(ideal,1,[]);
scale = max(reshape(scale,1,[]),eps);
weights = max(reshape(weights,1,[]),0);
weights = weights/max(sum(weights),eps);
normalized = max((obj-ideal)./scale,0);
value = sqrt(sum(bsxfun(@times,normalized.^2,weights),2));
invalid = ~isfinite([archive.cv]') | [archive.cv]'>cfg.constraintTolerance;
value(invalid) = inf;
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
