function value = riskBalancedCostIndicator(archive,cfg)
%RISKBALANCEDCOSTINDICATOR Fixed-scale risk-aware engineering score.
%
% Columns are detour ratio, risk objective, upper-tail risk, total energy
% and smoothness. Monitoring is intentionally excluded from this score and
% is enforced separately by final-stage safety constraints.
if isempty(archive)
    value = zeros(0,1);
    return;
end
archive = archive(:);
N = numel(archive);
X = inf(N,5);
for i = 1:N
    if isfield(archive(i),'pathMetrics') && ...
            isfield(archive(i).pathMetrics,'detourRatio')
        X(i,1) = archive(i).pathMetrics.detourRatio;
    elseif isfield(archive(i),'objectives') && ...
            numel(archive(i).objectives)>=1
        X(i,1) = archive(i).objectives(1);
    end
    if isfield(archive(i),'riskStats') && ...
            isfield(archive(i).riskStats,'objective')
        X(i,2) = archive(i).riskStats.objective;
    elseif isfield(archive(i),'objectives') && ...
            numel(archive(i).objectives)>=2
        X(i,2) = archive(i).objectives(2);
    end
    if isfield(archive(i),'riskStats') && ...
            isfield(archive(i).riskStats,'tailRisk')
        X(i,3) = archive(i).riskStats.tailRisk;
    else
        X(i,3) = X(i,2);
    end
    if isfield(archive(i),'energyStats') && ...
            isfield(archive(i).energyStats,'total')
        X(i,4) = archive(i).energyStats.total;
    elseif isfield(archive(i),'objectives') && ...
            numel(archive(i).objectives)>=3
        X(i,4) = archive(i).objectives(3);
    end
    if isfield(archive(i),'objectives') && ...
            numel(archive(i).objectives)>=4
        X(i,5) = archive(i).objectives(4);
    end
end
ideal = localCfg(cfg,'riskBalancedIndicatorIdeal', ...
    [1.00 0.00 0.00 90 0.00]);
scale = localCfg(cfg,'riskBalancedIndicatorScale', ...
    [0.50 0.50 0.80 200 0.20]);
weights = localCfg(cfg,'riskBalancedIndicatorWeights', ...
    [0.22 0.26 0.22 0.15 0.15]);
rho = localCfg(cfg,'riskBalancedIndicatorAugmentation',0.05);
ideal = reshape(ideal,1,[]);
scale = max(reshape(scale,1,[]),eps);
weights = max(reshape(weights,1,[]),0);
weights = weights/max(sum(weights),eps);
Z = max(bsxfun(@rdivide,bsxfun(@minus,X,ideal),scale),0);
weighted = bsxfun(@times,Z,weights);
value = max(weighted,[],2)+rho*sum(weighted,2);
cv = inf(N,1);
if isfield(archive,'cv')
    cv = reshape([archive.cv],[],1);
end
invalid = any(~isfinite(X),2) | ~isfinite(cv) | ...
    cv>localCfg(cfg,'constraintTolerance',1e-8);
value(invalid) = inf;
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
