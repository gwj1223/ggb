function hv = approxHypervolumeFixed(archive,cfg,samples,requireFeasible)
%APPROXHYPERVOLUMEFIXED Fixed-scale deterministic hypervolume estimate.
%
% By default the historical behavior is preserved: only individuals with
% cv<=constraintTolerance contribute. v7.1.1 Search Archive diagnostics may
% pass REQUIREFeasible=false because that archive is already a curated
% mission-band search set whose members can legitimately have scheduled CV>0.
if nargin < 4 || isempty(requireFeasible)
    requireFeasible = true;
end
if isempty(archive)
    hv = NaN;
    return;
end
if requireFeasible
    points = archive([archive.cv] <= cfg.constraintTolerance);
else
    points = archive;
end
if isempty(points)
    hv = NaN;
    return;
end
obj = vertcat(points.objectives);
ideal = cfg.hvIdealPoint(:)';
ref = cfg.hvReferencePoint(:)';
if size(obj,2) ~= numel(ideal) || numel(ref) ~= numel(ideal)
    error('HV ideal/reference point dimension does not match objective count.');
end
scale = max(ref-ideal,eps);
z = (obj-ideal)./scale;
% Points outside the reference box contribute no volume there.
z = min(max(z,0),1);
dominated = false(size(samples,1),1);
for i = 1:size(z,1)
    dominated = dominated | all(samples >= z(i,:),2);
end
hv = mean(dominated); % Normalised to [0,1].
end
