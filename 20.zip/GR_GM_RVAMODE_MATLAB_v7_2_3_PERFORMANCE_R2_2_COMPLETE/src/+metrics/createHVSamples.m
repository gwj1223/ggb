function samples = createHVSamples(cfg)
% Generate one fixed Monte-Carlo sample set for the complete run.
old = rng;
cleanup = onCleanup(@() rng(old)); %#ok<NASGU>
rng(cfg.hvSeed,'twister');
samples = rand(cfg.hvSamples,cfg.numObjectives);
end
