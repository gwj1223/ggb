function hv = approxCommonHypervolumeFixed(archive,cfg,samples)
%APPROXCOMMONHYPERVOLUMEFIXED Comparable HV using physical objectives.
if isempty(archive)
    hv = NaN;
    return;
end
feasible = archive([archive.cv] <= cfg.constraintTolerance);
if isempty(feasible)
    hv = NaN;
    return;
end
obj = metrics.commonObjectiveMatrix(feasible);
ideal = localCfg(cfg,'commonHVIdealPoint',[1.00 0.00 90 0 0]);
ref = localCfg(cfg,'commonHVReferencePoint',[1.80 1.00 550 1.50 1.00]);
ideal = ideal(:)'; ref = ref(:)';
if size(obj,2)~=numel(ideal) || numel(ref)~=numel(ideal)
    error('Common-HV ideal/reference dimension does not match.');
end
scale = max(ref-ideal,eps);
z = min(max((obj-ideal)./scale,0),1);
dominated = false(size(samples,1),1);
for i = 1:size(z,1)
    dominated = dominated | all(samples>=z(i,:),2);
end
hv = mean(dominated);
end

function value = localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value = cfg.(name); else, value = defaultValue; end
end
