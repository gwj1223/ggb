function hv = approxHypervolume(archive,cfg)
if isempty(archive), hv=0; return; end
obj=vertcat(archive.objectives); mn=min(obj,[],1); mx=max(obj,[],1); z=(obj-mn)./(mx-mn+eps); ref=cfg.hvReferencePoint;
rng(1001,'twister'); samples=rand(cfg.hvSamples,size(z,2)).*ref; dominated=false(size(samples,1),1);
for i=1:size(z,1), dominated=dominated | all(samples>=z(i,:),2); end
hv=mean(dominated)*prod(ref);
end
