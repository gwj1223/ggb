function out = summarizeViolations(pop,tolerance)
%SUMMARIZEVIOLATIONS Component minima, medians and violation counts.
if nargin < 2, tolerance = 1e-8; end
fields = {'collision','clearance','climb','turn','energy', ...
    'monitorMinimum','monitorCritical','monitorObservationLength', ...
    'monitorLOSRatio'};
for k = 1:numel(fields)
    f = fields{k};
    vals = arrayfun(@(x)x.violation.(f),pop);
    out.([f 'Min']) = min(vals);
    out.([f 'Median']) = median(vals);
    out.([f 'Count']) = sum(vals>tolerance);
end
cv = [pop.cv];
out.totalMin = min(cv);
out.totalMedian = median(cv);
out.totalCount = sum(cv>tolerance);
end
