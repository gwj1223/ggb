function T = validate_fleet_result_v700(resultFile)
%VALIDATE_FLEET_RESULT_V700 Diagnose v7.0.0 mission/safety and unified A3.
if nargin < 1 || isempty(resultFile)
    [f,p] = uigetfile('fleet_result.mat','Select fleet_result.mat');
    if isequal(f,0), error('No fleet_result.mat selected.'); end
    resultFile = fullfile(p,f);
end
S=load(resultFile); problem=S.problem; fleetResult=S.fleetResult; cfg=S.cfg;
K=numel(fleetResult.paths); denseStep=localCfg(cfg,'denseFinalAGLRepairStep_m',8.0);
tol=localCfg(cfg,'constraintTolerance',1e-8);
UAV=(1:K)'; FinalFeasible=false(K,1); ControllerFinal=false(K,1);
MinAGL_m=nan(K,1); MaxAGL_m=nan(K,1); AGLOK=false(K,1);
MaxClimb_deg=nan(K,1); ClimbOK=false(K,1); Qmin=nan(K,1);
Qcritical=nan(K,1); CriticalObs_m=nan(K,1); CriticalLOS=nan(K,1);
MissionDeficit=nan(K,1); UnifiedRepairEvents=zeros(K,1);
UnifiedRepairEvaluations=zeros(K,1); UnifiedRepairAccepted=zeros(K,1);
for k=1:K
    path=fleetResult.paths{k}; [MinAGL_m(k),MaxAGL_m(k)]=localDenseAGL(path,problem,denseStep);
    AGLOK(k)=MinAGL_m(k)>=cfg.safeClearance-tol && MaxAGL_m(k)<=cfg.realMaximumAGL+tol;
    seg=diff(path,1,1); horizontal=hypot(seg(:,1),seg(:,2));
    MaxClimb_deg(k)=max(atan2d(abs(seg(:,3)),max(horizontal,eps)));
    ClimbOK(k)=MaxClimb_deg(k)<=cfg.maxClimbAngleDeg+tol;
    r=fleetResult.uavResults{k}; b=r.best(1);
    FinalFeasible(k)=logical(localField(r,'bestSolutionSatisfiesFinalConstraints',false));
    ControllerFinal(k)=logical(localField(r,'controllerReachedFinalThresholds',false));
    Qmin(k)=b.monitorStats.minimumQuality; Qcritical(k)=b.monitorStats.criticalQuality;
    CriticalObs_m(k)=b.monitorStats.minimumCriticalObservationLength;
    CriticalLOS(k)=b.monitorStats.minimumCriticalLOSRatio;
    MissionDeficit(k)=evaluation.finalMonitoringDeficit(b,fleetResult.uavCfg{k});
    if isfield(r,'performance')
        UnifiedRepairEvents(k)=localField(r.performance,'unifiedMissionRepairEvents',0);
        UnifiedRepairEvaluations(k)=localField(r.performance,'unifiedMissionRepairEvaluations',0);
        UnifiedRepairAccepted(k)=localField(r.performance,'unifiedMissionRepairAccepted',0);
    end
end
T=table(UAV,FinalFeasible,ControllerFinal,MinAGL_m,MaxAGL_m,AGLOK, ...
    MaxClimb_deg,ClimbOK,Qmin,Qcritical,CriticalObs_m,CriticalLOS,MissionDeficit, ...
    UnifiedRepairEvents,UnifiedRepairEvaluations,UnifiedRepairAccepted);
disp(T);
out=fullfile(fileparts(resultFile),'v700_validation.csv'); writetable(T,out);
fprintf('Validation CSV: %s\n',out);
if isfield(fleetResult,'metrics')
    m=fleetResult.metrics;
    fprintf('Mission success             : %d\n',m.missionSuccess);
    fprintf('Fleet Mission Deficit       : %.6f\n',m.missionDeficit);
    fprintf('Fleet Qmin / Qcritical      : %.4f / %.4f\n',m.Qmin,m.Qcritical);
    fprintf('Critical obs / LOS          : %.2f m / %.4f\n',m.criticalMinObservationLength_m,m.criticalMinLOS);
    fprintf('Critical-obs worst target   : R%02d (UAV %d)\n',m.criticalObsWorstTargetIndex,m.criticalObsWorstTargetUAV);
    fprintf('Critical-LOS worst target   : R%02d (UAV %d)\n',m.criticalLOSWorstTargetIndex,m.criticalLOSWorstTargetUAV);
    fprintf('Unified repair events/evals : %d / %d\n',m.totalUnifiedMissionRepairEvents,m.totalUnifiedMissionRepairEvaluations);
    fprintf('Unified repair accepted     : %d\n',m.totalUnifiedMissionRepairAccepted);
end
end

function [minAGL,maxAGL]=localDenseAGL(path,problem,step)
minAGL=inf; maxAGL=-inf;
for k=1:size(path,1)-1
    a=path(k,:); b=path(k+1,:); horizontal=norm(b(1:2)-a(1:2));
    n=max(3,ceil(horizontal/max(step,1))+1); q=linspace(0,1,n)'; pts=a+q.*(b-a);
    terrain=data.terrainHeight(problem,pts(:,1),pts(:,2)); agl=pts(:,3)-terrain;
    minAGL=min(minAGL,min(agl)); maxAGL=max(maxAGL,max(agl));
end
end
function value=localField(s,name,defaultValue)
if isfield(s,name), value=s.(name); else, value=defaultValue; end
end
function value=localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value=cfg.(name); else, value=defaultValue; end
end
