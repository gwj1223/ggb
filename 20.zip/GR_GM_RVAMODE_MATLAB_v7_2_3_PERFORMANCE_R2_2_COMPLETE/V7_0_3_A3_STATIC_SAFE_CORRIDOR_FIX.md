# GR-GM-RVAMODE-VI v7.0.3 — A3 Static-Safe Corridor Fix

## Evidence motivating this release
The real Shiyan-G1 seed-42 v7.0.2 run reported `A3 eval=12 replace=0 eligible=0` at every repair checkpoint, with `rej[s/i/g/p/n]=[12 0 0 0 0]`. Thus all A3 candidates were rejected before mission-progress policy because they were static-infeasible.

## Runtime change
- Formal mission thresholds, five objectives, population 96, max generations 220, A1, A6, allocation, and epsilon schedule are unchanged.
- Critical/ordinary observation arcs remain 5/3 central observation waypoints.
- A3 now uses two Bezier transition shoulders on each side of the central arc. The incoming shoulder follows the existing-route tangent and joins the arc tangent; the outgoing shoulder performs the symmetric transition. Chromosome length is unchanged.
- The normal `repair.repairPath` and exact static feasibility gate remain mandatory. No static constraint is relaxed.
- A3 diagnostics now split static rejects into collision, clearance, climb, turn, and energy channels.

## Interpretation of the next run
A healthy change is `rej[s/... ] < 12`, followed by `eligible>0` and eventually `replace>0`. If static rejects remain, inspect `static[col/clr/clm/trn/E]` to identify the exact remaining physical constraint.
