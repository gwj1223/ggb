# GR-GM-RVAMODE-VI v7.0.4 — A3 Vertical Feasibility Fix

The real Shiyan-G1 v7.0.3 trace showed that every A3 trial was still rejected
by static feasibility. Collision and energy were clean; clearance/AGL failed
in 11–12/12 trials and climb failed in 12/12, while turn had already fallen to
only 2–4/12 after the Bezier XY shoulders.

R02 lies on roughly 53.9 degree terrain while the aircraft hard climb limit is
22 degrees. The previous A3 altitude construction followed `terrain +
desiredHeight` point by point. On steep terrain that can satisfy waypoint AGL
but be structurally incompatible with the aircraft climb limit; the following
clearance and climb repairs then fight each other.

## v7.0.4 change

A3 now chooses a preferred **absolute observation shelf** close to the target's
desired monitoring height, bounded by the dense local terrain range. It then
uses `core.projectStaticSafeAltitudeProfile`, a no-toolbox forward/backward
reachable-interval projection, to keep the surrounding route endpoints fixed
while enforcing waypoint AGL and the 22 degree climb cone. Existing dense
segment clearance repair remains the final safety check.

No formal constraints are relaxed. Five objectives, population 96, maximum
220 generations, Qmin 0.33, Qcritical 0.42, Critical observation 180 m,
Critical LOS 0.45, AGL 60–320 m, max climb 22 deg, max turn 95 deg, A1, one
Unified A3, A6, Formation Gen25 and Formal Gen100 are unchanged.

A3 diagnostics now also report lower/upper AGL failure counts, rejected-trial
AGL range, and worst climb angle.
