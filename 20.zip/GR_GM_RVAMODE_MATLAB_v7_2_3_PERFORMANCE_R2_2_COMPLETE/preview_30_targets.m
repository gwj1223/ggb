clear;
clc;
close all;

%% Project setup
projectRoot = fileparts(mfilename('fullpath'));
setupProject(projectRoot);

cfg = config.shiyanG1Config();
[problem,cfg] = realdata.buildShiyanG1Problem(projectRoot,cfg);
style = visualization.shiyanMapStyle();

%% Unified visual layers
[terrainRGB,~,~] = visualization.buildTerrainRGB(problem,style);
[riskRGB,riskAlpha,~] = visualization.buildRiskOverlay(problem,style);

% Publication coordinates: X/Y/Z are all shown in kilometres.
% Internal optimization data remain in metres.
Xkm = problem.gridX/1000;
Ykm = problem.gridY/1000;
Zkm = problem.terrain/1000;

%% Figure
f = figure( ...
    'Name','Shiyan G1 Unified Scene Preview', ...
    'Color',style.backgroundColor, ...
    'Position',style.figurePosition);
ax = axes(f);
hold(ax,'on');

%% Terrain
surface(ax,Xkm,Ykm,Zkm, ...
    'CData',terrainRGB, ...
    'FaceColor','texturemap', ...
    'EdgeColor','none', ...
    'FaceAlpha',1.0, ...
    'HandleVisibility','off');

%% Risk overlay
% Risk values remain dimensionless; only the surface Z coordinate is km.
% FaceAlpha='texturemap' is used with matrix AlphaData for compatibility.
surface(ax,Xkm,Ykm,(problem.terrain + style.riskZOffset)/1000, ...
    'CData',riskRGB, ...
    'FaceColor','texturemap', ...
    'EdgeColor','none', ...
    'AlphaData',riskAlpha, ...
    'AlphaDataMapping','none', ...
    'FaceAlpha','texturemap', ...
    'HandleVisibility','off');

%% Monitoring targets
criticalIdx = [];
if isfield(cfg,'criticalTargetIndices') && ~isempty(cfg.criticalTargetIndices)
    criticalIdx = cfg.criticalTargetIndices(:)';
end

hNormal = gobjects(1);
hCritical = gobjects(1);

if isfield(problem,'monitorTargetTerrain') && ...
        numel(problem.monitorTargetTerrain) >= size(problem.monitorTargets,1)
    targetTerrain = problem.monitorTargetTerrain(:);
else
    targetTerrain = data.terrainHeight(problem, ...
        problem.monitorTargets(:,1),problem.monitorTargets(:,2));
    targetTerrain = targetTerrain(:);
end

for m = 1:size(problem.monitorTargets,1)
    t = problem.monitorTargets(m,:);
    tz = targetTerrain(m);

    % Visual lift only. The physical target remains at its original terrain
    % position in all optimization/evaluation computations.
    zPlotKm = (tz + style.targetZOffset)/1000;

    if ismember(m,criticalIdx)

        % Main critical marker.
        h = scatter3(ax,t(1)/1000,t(2)/1000,zPlotKm, ...
            style.criticalTargetSize,'^','filled', ...
            'MarkerFaceColor',style.criticalTargetColor, ...
            'MarkerEdgeColor','none');

        if ~isgraphics(hCritical)
            hCritical = h;
            set(hCritical,'DisplayName','Critical target');
        else
            set(h,'HandleVisibility','off');
        end
    else

        % Main monitoring marker.
        h = scatter3(ax,t(1)/1000,t(2)/1000,zPlotKm, ...
            style.normalTargetSize,'^','filled', ...
            'MarkerFaceColor',style.normalTargetColor, ...
            'MarkerEdgeColor','none');

        if ~isgraphics(hNormal)
            hNormal = h;
            set(hNormal,'DisplayName','Monitoring target');
        else
            set(h,'HandleVisibility','off');
        end
    end

    if style.showTargetLabels && ...
            isfield(problem,'monitorTargetLabels') && ...
            numel(problem.monitorTargetLabels) >= m
        text(ax,t(1)/1000,t(2)/1000, ...
            (tz + style.targetZOffset + 25)/1000, ...
            problem.monitorTargetLabels{m}, ...
            'FontName',style.fontName, ...
            'FontSize',8, ...
            'HorizontalAlignment','center', ...
            'BackgroundColor','w', ...
            'Margin',1, ...
            'Interpreter','none');
    end
end

%% Start / Goal
hStart = scatter3(ax, ...
    problem.start(1)/1000,problem.start(2)/1000,problem.start(3)/1000, ...
    style.startSize,'o','filled', ...
    'MarkerFaceColor',style.startColor, ...
    'MarkerEdgeColor','k','LineWidth',0.8, ...
    'DisplayName','Start');

hGoal = scatter3(ax, ...
    problem.goal(1)/1000,problem.goal(2)/1000,problem.goal(3)/1000, ...
    style.goalSize,'s','filled', ...
    'MarkerFaceColor',style.goalColor, ...
    'MarkerEdgeColor','k','LineWidth',0.8, ...
    'DisplayName','Goal');

%% Axes: X/Y/Z use the same km unit
xlabel(ax,'Local Easting (km)');
ylabel(ax,'Local Northing (km)');
zlabel(ax,'Elevation (km)');

title(ax,sprintf('Shiyan-G1 | %d DEM-derived monitoring targets', ...
    size(problem.monitorTargets,1)), ...
    'FontWeight','normal','FontSize',style.titleFontSize);

axis(ax,'tight');
box(ax,'on');
grid(ax,'off');
view(ax,style.viewAzimuth,style.viewElevation);
pbaspect(ax,style.plotBoxAspect);
camproj(ax,style.cameraProjection);

set(ax, ...
    'FontName',style.fontName, ...
    'FontSize',style.axisFontSize, ...
    'LineWidth',style.axisLineWidth, ...
    'GridColor',style.gridColor, ...
    'GridAlpha',style.gridAlpha, ...
     'TickLength',[0 0]);

%% Risk colorbar
colormap(ax,style.riskMap);
clim(ax,style.riskCLim);
cb = colorbar(ax,'eastoutside');
ylabel(cb,'DEM-derived risk proxy');
cb.FontName = style.fontName;
cb.FontSize = style.colorbarFontSize;
cb.Ticks = style.riskColorbarTicks;

%% Legend
legendHandles = gobjects(0);
legendLabels = {};

if isgraphics(hNormal)
    legendHandles(end+1) = hNormal; %#ok<SAGROW>
    legendLabels{end+1} = 'Monitoring target'; %#ok<SAGROW>
end
if isgraphics(hCritical)
    legendHandles(end+1) = hCritical; %#ok<SAGROW>
    legendLabels{end+1} = 'Critical target'; %#ok<SAGROW>
end
legendHandles(end+1) = hStart;
legendLabels{end+1} = 'Start';
legendHandles(end+1) = hGoal;
legendLabels{end+1} = 'Goal';

lgd = legend(ax,legendHandles,legendLabels, ...
    'Location','northeast','Box','on');
lgd.FontName = style.fontName;
lgd.FontSize = style.legendFontSize;

%% Console summary
fprintf('\n============================================\n');
fprintf('Shiyan-G1 unified map preview\n');
fprintf('Targets  : %d\n',size(problem.monitorTargets,1));
fprintf('Critical : %d\n',numel(criticalIdx));
fprintf('Waypoints: %d\n',cfg.numWaypoints);
fprintf('Plot axes : X/Y/Z in km\n');
fprintf('Target marker lift (visual only): %.0f m\n',style.targetZOffset);
fprintf('============================================\n');

%% Optional publication export
% exportgraphics(f,fullfile(projectRoot,'Shiyan_G1_scene_preview.png'), ...
%     'Resolution',style.exportResolution);
