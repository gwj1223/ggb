# v7.2.3 Performance R2.1 Hotfix

本热修复只处理 R2 中 `griddedInterpolant` 对 LOS/观测矩阵查询产生的大量
`MESHGRID -> NDGRID` 性能警告，不改变 GR-GM-RVAMODE-VI 的数学语义。

## 修复内容

- 同尺寸 `x/y` 查询按点展开成列向量：`x(:), y(:)`；
- 调用缓存的 `griddedInterpolant` 后 reshape 回原始查询尺寸；
- 标量扩展保持逐点语义；
- 不规则的不同尺寸查询保留历史 `interp2` fallback；
- `test_terrain_interpolator_cache_equivalence` 增加矩阵 LOS 查询、warning-free、
  scalar expansion 与 `interp2` 数值等价性检查。

## MATLAB 验收顺序

```matlab
run_all_tests
p = run_v723_performance_probe(2,12);
```

通过标准：
- `Passed: 109 / 109`
- 不再出现重复的 `Query data is in MESHGRID format` 警告
- probe 中 `contractMatch=1`
- phenotype/feasibility 与 cache-off 合同一致
- `speedup > 1` 为期望结果（实际加速比取决于 MATLAB 版本和机器）

算法冻结项保持不变：Population=96、Max generations=220、51D semantic genotype、
42 internal XYZ waypoints、五目标、Mission Deficit/Mission Band、A3、A6、AGL/climb/turn/
monitoring 正式阈值均未修改。
