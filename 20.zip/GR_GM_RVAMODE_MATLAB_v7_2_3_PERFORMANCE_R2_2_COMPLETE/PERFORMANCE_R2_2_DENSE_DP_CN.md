# v7.2.3 Performance R2.2 - Dense DP vectorization

本版本只优化 `projectDenseTerrainReachableProfile` 内部 altitude-grid DP 的实现，不修改 51D 表示、42 waypoint 表型、5 个目标、Mission Band、A3、A6 或任何正式约束。

## Profiling evidence
UAV-2 30-generation R2.1 profile showed decoder/total=98.89%, Dense/decoder=96.78%, terrain/Dense=12.44%. Therefore DEM sampling is no longer the dominant cost; Dense altitude DP is.

## Change
- Add `enableDenseProjectionVectorizedDP=true`.
- Retain the previous scalar predecessor loop as an exact reference path.
- Vectorize predecessor-to-next-grid feasibility and cost updates using the same inequalities, costs, tolerances and first-predecessor tie semantics.
- No topology/bias/tangent candidates are skipped; reach-attempt ordering is unchanged.

## Validation
1. `run_all_tests` (111 tests expected).
2. `p = run_v723_dense_dp_probe(2,48);`
Required: contractMatch=1, phenotype difference <=1e-8, identical reach attempts.
3. Only after the probe passes, repeat the 30-generation UAV-2 performance profile.
