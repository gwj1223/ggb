function report = run_v723_dense_dp_probe(uavId,samples)
%RUN_V723_DENSE_DP_PROBE Scalar-vs-vectorized Dense DP decoder equivalence/timing.
% Segment/terrain caches remain ON in both arms; only the internal altitude
% dynamic-programming transition implementation changes.
if nargin<1 || isempty(uavId), uavId=2; end
if nargin<2 || isempty(samples), samples=24; end
projectRoot=fileparts(mfilename('fullpath'));
setupProject(projectRoot);
cfg=config.multiUAVShiyanConfig();
[problem,cfg]=realdata.buildShiyanG1Problem(projectRoot,cfg);
assignment=multiUAV.allocateTargetsObservabilityAware(problem,cfg);
[subProblem,subCfg]=multiUAV.buildSubProblem(problem,cfg,assignment,uavId);
layout=core.structuredMonitoringLayout(subProblem,subCfg);
rng(subCfg.randomSeed+72322,'twister');
U=-1+2*rand(samples,layout.dimension);
subProblem.enableTerrainInterpolatorCache=true;
baseCfg=subCfg; baseCfg.enableStructuredSegmentTerrainCache=true;
baseCfg.enableDenseProjectionVectorizedDP=false;
fastCfg=subCfg; fastCfg.enableStructuredSegmentTerrainCache=true;
fastCfg.enableDenseProjectionVectorizedDP=true;
data.terrainHeight(subProblem,subProblem.start(1),subProblem.start(2));
baseTime=0; fastTime=0; contract=true(samples,1); maxGeneDiff=zeros(samples,1);
baseReach=zeros(samples,1); fastReach=zeros(samples,1);
for i=1:samples
    t=tic; [g0,i0]=core.decodeStructuredMonitoringGenes(U(i,:),subProblem,baseCfg); baseTime=baseTime+toc(t);
    t=tic; [g1,i1]=core.decodeStructuredMonitoringGenes(U(i,:),subProblem,fastCfg); fastTime=fastTime+toc(t);
    maxGeneDiff(i)=max(abs(g0(:)-g1(:)));
    sameReason=strcmp(char(i0.reason),char(i1.reason));
    sameSuccess=logical(i0.success)==logical(i1.success);
    sameDense=logical(i0.denseSuccess)==logical(i1.denseSuccess);
    sameTurn=(isinf(i0.maxTurnDeg) && isinf(i1.maxTurnDeg)) || ...
        abs(i0.maxTurnDeg-i1.maxTurnDeg)<=1e-8;
    contract(i)=sameReason && sameSuccess && sameDense && sameTurn && ...
        maxGeneDiff(i)<=1e-8;
    if isfield(i0,'reachAttempts'), baseReach(i)=i0.reachAttempts; end
    if isfield(i1,'reachAttempts'), fastReach(i)=i1.reachAttempts; end
end
report.uavId=uavId; report.samples=samples;
report.contractMatch=all(contract);
report.maximumPhenotypeDifference=max(maxGeneDiff);
report.scalarTime_s=baseTime; report.vectorizedTime_s=fastTime;
report.speedup=baseTime/max(fastTime,eps);
report.scalarReachAttempts=sum(baseReach);
report.vectorizedReachAttempts=sum(fastReach);
fprintf('\n=== v7.2.3 Performance R2.2 Dense-DP probe | UAV-%d ===\n',uavId);
fprintf('samples=%d semantic=%dD phenotype=%dD\n',samples,layout.dimension,3*subCfg.numWaypoints);
fprintf('contractMatch=%d maxPhenotypeDiff=%.3g reach[scalar/vector]=[%d/%d]\n', ...
    report.contractMatch,report.maximumPhenotypeDifference, ...
    report.scalarReachAttempts,report.vectorizedReachAttempts);
fprintf('time[scalar/vector]=[%.2f %.2f]s speedup=%.2fx\n', ...
    report.scalarTime_s,report.vectorizedTime_s,report.speedup);
if ~report.contractMatch
    error('run_v723_dense_dp_probe:ContractMismatch', ...
        'Vectorized Dense DP changed decoder output/flags beyond tolerance.');
end
end
