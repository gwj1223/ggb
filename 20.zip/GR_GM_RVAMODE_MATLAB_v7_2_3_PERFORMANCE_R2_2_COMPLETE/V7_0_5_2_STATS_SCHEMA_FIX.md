# GR-GM-RVAMODE-VI v7.0.5.2 — Mission-Repair Stats Schema Fix

This is a minimal integration hotfix on top of v7.0.5.1. It does **not**
change the Dense-3D A3 algorithm, mission thresholds, physical constraints,
objectives, population size, or generation budget.

## Root cause fixed

`runGRAHMODE` initialized a pre-A3 statistics struct using an older field set,
while v7.0.5 logging expected new Dense-3D fields such as
`geometryCandidates`. Before Gen25 the unified repair is not called, so the
old local struct reached the logging code and MATLAB raised an unknown-field
error.

## Fix

- Added `core.emptyUnifiedMissionRepairStats()` as the single canonical A3
  diagnostic schema.
- `runGRAHMODE` and `unifiedMissionRepair` now both initialize from that helper.
- Removed the duplicate local empty-stats schema from `unifiedMissionRepair`.
- Added `test_unified_mission_repair_stats_schema`, including an actual Gen1
  integration run to protect the exact pre-A3 failure path.

The sampling-contract fix from v7.0.5.1 and all Dense-3D terrain-reachability
logic from v7.0.5 are retained unchanged.
