function report = run_v723_performance_probe(uavId,samples)
%RUN_V723_PERFORMANCE_PROBE Fast cache OFF/ON semantic-decoder equivalence test.
% Does not run GR-GM-RVAMODE. It decodes the same semantic genes twice and
% verifies that performance caches preserve the 42-waypoint phenotype/flags.
if nargin<1 || isempty(uavId), uavId=2; end
if nargin<2 || isempty(samples), samples=12; end
projectRoot=fileparts(mfilename('fullpath'));
setupProject(projectRoot);
cfg=config.multiUAVShiyanConfig();
[problem,cfg]=realdata.buildShiyanG1Problem(projectRoot,cfg);
assignment=multiUAV.allocateTargetsObservabilityAware(problem,cfg);
[subProblem,subCfg]=multiUAV.buildSubProblem(problem,cfg,assignment,uavId);
layout=core.structuredMonitoringLayout(subProblem,subCfg);
rng(subCfg.randomSeed+72302,'twister');
U=-1+2*rand(samples,layout.dimension);

baseProblem=subProblem;
baseProblem.enableTerrainInterpolatorCache=false;
baseCfg=subCfg;
baseCfg.enableStructuredSegmentTerrainCache=false;
fastProblem=subProblem;
fastProblem.enableTerrainInterpolatorCache=true;
fastCfg=subCfg;
fastCfg.enableStructuredSegmentTerrainCache=true;

% Warm only the cached interpolator object so its one-time construction does
% not distort steady-state decoder timing.
data.terrainHeight(fastProblem,fastProblem.start(1),fastProblem.start(2));
baseTime=0; fastTime=0; contract=true(samples,1); maxGeneDiff=zeros(samples,1);
baseReach=zeros(samples,1); fastReach=zeros(samples,1);
cacheHits=zeros(samples,1); cacheMisses=zeros(samples,1);
for i=1:samples
    t=tic; [g0,i0]=core.decodeStructuredMonitoringGenes(U(i,:),baseProblem,baseCfg); baseTime=baseTime+toc(t);
    t=tic; [g1,i1]=core.decodeStructuredMonitoringGenes(U(i,:),fastProblem,fastCfg); fastTime=fastTime+toc(t);
    maxGeneDiff(i)=max(abs(g0(:)-g1(:)));
    sameReason=strcmp(char(i0.reason),char(i1.reason));
    sameSuccess=logical(i0.success)==logical(i1.success);
    sameDense=logical(i0.denseSuccess)==logical(i1.denseSuccess);
    sameTurn=(isinf(i0.maxTurnDeg) && isinf(i1.maxTurnDeg)) || ...
        abs(i0.maxTurnDeg-i1.maxTurnDeg)<=1e-8;
    contract(i)=sameReason && sameSuccess && sameDense && sameTurn && ...
        maxGeneDiff(i)<=1e-8;
    if isfield(i0,'reachAttempts'), baseReach(i)=i0.reachAttempts; end
    if isfield(i1,'reachAttempts'), fastReach(i)=i1.reachAttempts; end
    if isfield(i1,'terrainSampleCacheHits'), cacheHits(i)=i1.terrainSampleCacheHits; end
    if isfield(i1,'terrainSampleCacheMisses'), cacheMisses(i)=i1.terrainSampleCacheMisses; end
end
report.uavId=uavId;
report.samples=samples;
report.contractMatch=all(contract);
report.maximumPhenotypeDifference=max(maxGeneDiff);
report.baselineTime_s=baseTime;
report.performanceTime_s=fastTime;
report.speedup=baseTime/max(fastTime,eps);
report.baselineReachAttempts=sum(baseReach);
report.performanceReachAttempts=sum(fastReach);
report.cacheHits=sum(cacheHits);
report.cacheMisses=sum(cacheMisses);
report.cacheHitRate=report.cacheHits/max(report.cacheHits+report.cacheMisses,1);
fprintf('\n=== v7.2.3 Performance R2 probe | UAV-%d ===\n',uavId);
fprintf('samples=%d semantic=%dD phenotype=%dD\n',samples,layout.dimension,3*subCfg.numWaypoints);
fprintf('contractMatch=%d maxPhenotypeDiff=%.3g reach[off/on]=[%d/%d]\n', ...
    report.contractMatch,report.maximumPhenotypeDifference, ...
    report.baselineReachAttempts,report.performanceReachAttempts);
fprintf('time[off/on]=[%.2f %.2f]s speedup=%.2fx cache[h/m]=[%d/%d] hitRate=%.1f%%\n', ...
    report.baselineTime_s,report.performanceTime_s,report.speedup, ...
    report.cacheHits,report.cacheMisses,100*report.cacheHitRate);
if ~report.contractMatch
    error('run_v723_performance_probe:ContractMismatch', ...
        'Performance cache changed decoder output/flags beyond tolerance.');
end
end
