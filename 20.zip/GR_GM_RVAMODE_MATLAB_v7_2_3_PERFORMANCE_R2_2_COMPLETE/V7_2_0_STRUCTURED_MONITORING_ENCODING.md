# v7.2.0 Structured Monitoring Encoding Prototype

## Purpose

v7.2.0 isolates one scientific question: is the 42-waypoint free XYZ
representation the main reason the difficult UAV-1 monitoring mission stalls?
The optimizer family, Mission-Band selection, Mission Deficit, Dense-3D terrain
projection, A3 acceptance policy, A6, and all formal thresholds are retained.

## Search representation

For a local subproblem with M monitoring targets, the evolutionary genotype is
normalized to [-1,1] and has 5*M+1 variables:

- 4 genes per target: observation radius, sector offset, observation arc
  length, preferred observation AGL.
- M+1 genes: one lateral transit bias for each start/target/goal transition.

For the Shiyan 10-target UAV subproblem:

- semantic genotype: 5*10+1 = 51 dimensions;
- legacy phenotype: 42 XYZ waypoints = 126 coordinates.

The 51D genotype is decoded deterministically to the established 42-waypoint
phenotype. All formal evaluators and reporting continue to consume the same
XYZ path as before.

## Fixed target order in this prototype

Target order is intentionally not evolved in v7.2.0. The decoder freezes the
same nearest-neighbour plus 2-opt order used by A1 guided seed variant 1. This
keeps sequencing out of the experiment so the effect of representation can be
measured cleanly. Target-order random keys are reserved for a later version.

## Observation geometry

The zero semantic gene is centred on deterministic DEM/LOS knowledge:

- radius uses the target preferred radius scale from the Monitoring Knowledge
  Base and remains inside the existing [0.75,1.25] radius-scale bounds;
- sector offset is bounded around the existing best visible sector;
- arc length is centred on monitorRequiredObservationLength and bounded by
  [0.65,1.50] times that length, with the deterministic visible-arc estimate
  acting as an upper cap when available;
- observation height is centred on the existing target desired AGL and varies
  within 0.60 monitorHeightSigma, while remaining inside the formal AGL band.

Ordinary targets retain 3 arc nodes and Critical targets retain 5 arc nodes.
For the normal 8-ordinary/2-Critical UAV assignment this consumes 34 of the 42
waypoints. The remaining 8 waypoints are allocated deterministically to the
most difficult transit legs according to distance and DEM relief.

## Altitude is no longer an evolutionary coordinate

The decoder builds XY geometry and a preferred AGL vector, then calls the
existing core.projectDenseTerrainReachableProfile helper. The final waypoint Z
values therefore obey the same dense DEM, AGL and climb contract already used
by the v7.0.5.x A3 work. A failed dense decode is kept as a deterministic
static-infeasible phenotype; no legacy repair is allowed to silently change a
successful semantic structure.

## DE and A3

DE mutates structuredGenes instead of the 126D XYZ phenotype when structured
encoding is enabled. Target-block crossover changes the four semantic target
genes together. Strategy 3 restricts its mutation to the selected target plus
its adjacent transit genes.

Unified A3 also becomes semantic in structured mode. Its 9-candidate pool
changes only the selected target's four genes, decodes each candidate through
the same Dense-3D decoder, and then applies the unchanged v7.1.1 acceptance
chain:

1. static feasible;
2. valid evaluation;
3. global Mission Deficit non-regression;
4. stage-aware protection;
5. selected-target deficit gain.

No sixth objective, historical chromosome memory, persistent repair, or
emergency reinjection is introduced.

## Formal invariants unchanged

- population = 96
- generations = 220
- objectives = 5
- Qmin = 0.33
- Critical Q = 0.42
- Critical observation length = 180 m
- Critical LOS = 0.45
- AGL = 60--320 m
- maximum climb = 22 deg
- maximum turn = 95 deg
- mission formation starts Gen25
- formal stage starts Gen100
- A3 full evaluations <= 12/event

## New diagnostics

The per-UAV header reports the semantic dimension, for example:

`waypoints=42 | structured=51D | critical=2`

Mission-Band verbose generations also report:

`enc[semantic/XYZ]=[51D/126D] decodeOK=.../96`

The important runtime questions are:

1. how quickly decodeOK and static-feasible counts grow;
2. whether Dmin breaks the historical UAV-1 plateau near 0.90477;
3. whether A3 replacements occur more often;
4. whether the first D<0.8, D<0.5 and D=0 generations move earlier;
5. whether formal carriers appear before changing the optimizer backbone.

## Scope

This is intentionally a representation experiment. C-TAEA, PPS, target-order
random keys and cross-UAV evolutionary multitasking are not introduced in
v7.2.0. They should only be considered after this version establishes whether
semantic monitoring representation materially improves mission formation.
