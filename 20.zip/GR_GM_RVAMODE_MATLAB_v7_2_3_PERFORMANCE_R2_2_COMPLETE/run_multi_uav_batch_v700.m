function [T,summaryFile,statsFile,ratesFile] = run_multi_uav_batch_v700(seeds,tag)
%RUN_MULTI_UAV_BATCH_V700 Checkpointed v7.0.0 multi-UAV batch runner.
% Clean schema: static/mission feasibility, five-objective outcomes, Unified
% Mission Repair workload, allocation diagnostics and safety only.
if nargin<1 || isempty(seeds), seeds=(1:30)'; end
if nargin<2 || isempty(tag), tag='30seeds_v700'; end
seeds=seeds(:);
projectRoot=fileparts(mfilename('fullpath'));
setupProject(projectRoot);

cfgBase=config.multiUAVShiyanConfig();
cfgBase.saveFigures=false;
cfgBase.outputRoot=['output_shiyan_g1_30r_3uav_' char(tag)];
cfgBase.localAGLValidationStep_m=10.0;
[problem,cfgBase]=realdata.buildShiyanG1Problem(projectRoot,cfgBase);
multiUAV.validateConfig(cfgBase,problem);
if cfgBase.multiUAVCount~=3
    error('run_multi_uav_batch_v700:ExpectedThreeUAVs', ...
        'The v7.0.0 batch schema is configured for exactly 3 UAVs.');
end

batchRoot=fullfile(projectRoot,cfgBase.outputRoot);
if ~exist(batchRoot,'dir'), mkdir(batchRoot); end
summaryFile=fullfile(batchRoot,['batch_summary_multi_uav_' char(tag) '.csv']);
statsFile=fullfile(batchRoot,['batch_statistics_multi_uav_' char(tag) '.csv']);
ratesFile=fullfile(batchRoot,['batch_success_rates_multi_uav_' char(tag) '.csv']);

rows=repmat(localEmptyRow(0),numel(seeds),1);
for k=1:numel(seeds), rows(k)=localEmptyRow(seeds(k)); end

% Resume only rows from the exact same implementation version.
if isfile(summaryFile)
    old=readtable(summaryFile,'TextType','string');
    if all(ismember({'Seed','Status','ImplementationVersion'},old.Properties.VariableNames))
        for k=1:numel(seeds)
            r=find(old.Seed==seeds(k) & old.Status=="ok" & ...
                old.ImplementationVersion==string(cfgBase.implementationVersion),1,'last');
            if ~isempty(r), rows(k)=localMergeRow(rows(k),table2struct(old(r,:))); end
        end
    end
end

for k=1:numel(seeds)
    if string(rows(k).Status)=="ok"
        fprintf('Skipping completed v7.0.0 seed %d.\n',seeds(k));
        continue;
    end
    cfg=cfgBase; cfg.randomSeed=seeds(k); problem.cfg=cfg;
    rows(k).ErrorMessage="";
    fprintf('\n============================================================\n');
    fprintf('v7.0.0 multi-UAV seed %d (%d/%d) | %s\n',seeds(k),k,numel(seeds),char(tag));
    fprintf('============================================================\n');
    try
        fleetResult=multiUAV.runCooperativeMonitoring(problem,cfg);
        out=multiUAV.saveFleetRun(problem,fleetResult,cfg,projectRoot);
        rows(k)=localPopulateRow(rows(k),fleetResult,string(out));
        rows(k).Status="ok";
    catch ME
        rows(k).Status="failed";
        rows(k).ErrorMessage=string(ME.identifier)+": "+string(ME.message);
        warning('run_multi_uav_batch_v700:SeedFailed','Seed %d failed: %s',seeds(k),ME.message);
    end
    T=struct2table(rows); writetable(T,summaryFile);
    localWriteBatchStatistics(T,statsFile,ratesFile);
end
T=struct2table(rows); writetable(T,summaryFile);
localWriteBatchStatistics(T,statsFile,ratesFile);

ok=T.Status=="ok";
fprintf('\n============================================================\n');
fprintf('v7.0.0 batch finished: %s\n',char(tag));
fprintf('Completed runs               : %d / %d\n',sum(ok),height(T));
if any(ok)
    fprintf('Mission success              : %d / %d\n',sum(T.MissionSuccess(ok)),sum(ok));
    fprintf('All controllers final        : %d / %d\n',sum(T.AllControllerFinal(ok)),sum(ok));
    fprintf('All sampled AGL valid        : %d / %d\n',sum(T.AllAGLOK(ok)),sum(ok));
    fprintf('Collision-free               : %d / %d\n',sum(T.CollisionFree(ok)),sum(ok));
    fprintf('Qmin=0 runs                  : %d / %d\n',sum(T.Qmin(ok)<=1e-12),sum(ok));
    fprintf('MissionDeficit=0 runs        : %d / %d\n',sum(T.MissionDeficit(ok)<=1e-12),sum(ok));
    fprintf('Critical obs < formal        : %d / %d\n', ...
        sum(T.CriticalObservationLength_m(ok)<cfgBase.monitorCriticalMinObservationLength-1e-9),sum(ok));
end
fprintf('Per-seed summary             : %s\n',summaryFile);
fprintf('Numeric statistics           : %s\n',statsFile);
fprintf('Success rates                : %s\n',ratesFile);
fprintf('============================================================\n');
end

function row=localEmptyRow(seed)
row=struct();
row.Seed=seed; row.Status="pending"; row.ErrorMessage="";
row.AlgorithmVersion=""; row.ImplementationVersion="";
row.AGLValidationStep_m=NaN; row.AGLConstraintSampleStep_m=NaN;
row.MissionSuccess=false; row.AllUAVFinalFeasible=false; row.MonitoringSatisfied=false; row.CollisionFree=false;
row.ControllerFinalCount=0; row.AllControllerFinal=false;
row.UAV1_FinalFeasible=false; row.UAV2_FinalFeasible=false; row.UAV3_FinalFeasible=false;
row.UAV1_ControllerFinal=false; row.UAV2_ControllerFinal=false; row.UAV3_ControllerFinal=false;
row.StrictEngineeringCount=0; row.AllUAVStrictEngineering=false;
row.UAV1_StrictEngineering=false; row.UAV2_StrictEngineering=false; row.UAV3_StrictEngineering=false;
row.UAV1_FinalStageGenerations=0; row.UAV2_FinalStageGenerations=0; row.UAV3_FinalStageGenerations=0;
row.UAV1_FinalFeasibleRate=NaN; row.UAV2_FinalFeasibleRate=NaN; row.UAV3_FinalFeasibleRate=NaN;
row.FleetMinAGL_m=NaN; row.FleetMaxAGL_m=NaN; row.LowerClearanceOK=false; row.UpperAGLOK=false; row.AllAGLOK=false;
row.UAV1_MinAGL_m=NaN; row.UAV1_MaxAGL_m=NaN; row.UAV2_MinAGL_m=NaN; row.UAV2_MaxAGL_m=NaN; row.UAV3_MinAGL_m=NaN; row.UAV3_MaxAGL_m=NaN;
row.Makespan_min=NaN; row.MinimumSeparation_m=NaN; row.TotalPathLength_km=NaN;
row.TotalEnergy=NaN; row.MaximumEnergy=NaN; row.FleetRiskScore=NaN; row.MaximumRisk=NaN; row.MaximumTailRisk=NaN; row.MaximumSmoothness=NaN;
row.Qavg=NaN; row.Qmin=NaN; row.Qcritical=NaN;
row.MissionDeficit=NaN; row.MissionDeficit_Qmin=NaN; row.MissionDeficit_Qcritical=NaN; row.MissionDeficit_CriticalObs=NaN; row.MissionDeficit_CriticalLOS=NaN;
row.CriticalObservationLength_m=NaN; row.CriticalLOS=NaN;
row.WorstTargetIndex=NaN; row.WorstTargetUAV=NaN; row.WorstTargetQuality=NaN; row.WorstTargetObservationLength_m=NaN; row.WorstTargetLOS=NaN;
row.CriticalObsWorstTargetIndex=NaN; row.CriticalObsWorstTargetUAV=NaN; row.CriticalObsWorstTargetQuality=NaN; row.CriticalObsWorstTargetLOS=NaN;
row.CriticalLOSWorstTargetIndex=NaN; row.CriticalLOSWorstTargetUAV=NaN; row.CriticalLOSWorstTargetQuality=NaN; row.CriticalLOSWorstTargetObservationLength_m=NaN;
row.UAV1_WorstTargetIndex=NaN; row.UAV2_WorstTargetIndex=NaN; row.UAV3_WorstTargetIndex=NaN;
row.UAV1_WorstTargetQuality=NaN; row.UAV2_WorstTargetQuality=NaN; row.UAV3_WorstTargetQuality=NaN;
row.UAV1_MissionDeficit=NaN; row.UAV2_MissionDeficit=NaN; row.UAV3_MissionDeficit=NaN;
row.UnifiedMissionRepairEvents=0; row.UnifiedMissionRepairEvaluations=0; row.UnifiedMissionRepairAccepted=0;
row.UAV1_UnifiedMissionRepairEvents=0; row.UAV2_UnifiedMissionRepairEvents=0; row.UAV3_UnifiedMissionRepairEvents=0;
row.UAV1_UnifiedMissionRepairEvaluations=0; row.UAV2_UnifiedMissionRepairEvaluations=0; row.UAV3_UnifiedMissionRepairEvaluations=0;
row.UAV1_UnifiedMissionRepairAccepted=0; row.UAV2_UnifiedMissionRepairAccepted=0; row.UAV3_UnifiedMissionRepairAccepted=0;
row.AllocationScore=NaN; row.AllocationTransitMakespanProxy_min=NaN; row.AllocationRouteProxySpread_km=NaN;
row.AllocationLoadCV=NaN; row.AllocationRiskLoadCV=NaN; row.AllocationObservabilityLoadCV=NaN; row.AllocationCriticalObservabilityLoadCV=NaN; row.AllocationWorstObservabilitySpread=NaN;
row.Runtime_s=NaN; row.OutputDirectory="";
end

function row=localPopulateRow(row,fleetResult,outDir)
m=fleetResult.metrics;
if isfield(fleetResult,'uavCfg') && ~isempty(fleetResult.uavCfg)
    row.AlgorithmVersion=string(fleetResult.uavCfg{1}.algorithmVersion);
    row.AGLConstraintSampleStep_m=localCfg(fleetResult.uavCfg{1},'aglConstraintSampleStep_m',NaN);
end
if isfield(fleetResult,'version'), row.ImplementationVersion=string(fleetResult.version); end
row.AGLValidationStep_m=m.localAGLValidationStep_m;
row.MissionSuccess=logical(m.missionSuccess); row.AllUAVFinalFeasible=logical(m.allUAVFinalFeasible);
row.MonitoringSatisfied=logical(m.monitoringSatisfied); row.CollisionFree=logical(m.collisionFree);
ff=logical(m.perUAVFinalFeasible(:)); row.UAV1_FinalFeasible=ff(1); row.UAV2_FinalFeasible=ff(2); row.UAV3_FinalFeasible=ff(3);
row.ControllerFinalCount=m.controllerFinalCount; row.AllControllerFinal=logical(m.allControllerFinal);
ctrl=logical(m.perUAVControllerFinal(:)); row.UAV1_ControllerFinal=ctrl(1); row.UAV2_ControllerFinal=ctrl(2); row.UAV3_ControllerFinal=ctrl(3);
row.StrictEngineeringCount=m.strictEngineeringCount; row.AllUAVStrictEngineering=logical(m.allUAVStrictEngineering);
st=logical(m.perUAVStrictEngineering(:)); row.UAV1_StrictEngineering=st(1); row.UAV2_StrictEngineering=st(2); row.UAV3_StrictEngineering=st(3);
fg=m.perUAVFinalStageGenerations(:); row.UAV1_FinalStageGenerations=fg(1); row.UAV2_FinalStageGenerations=fg(2); row.UAV3_FinalStageGenerations=fg(3);
ffr=m.perUAVFinalFeasibleRate(:); row.UAV1_FinalFeasibleRate=ffr(1); row.UAV2_FinalFeasibleRate=ffr(2); row.UAV3_FinalFeasibleRate=ffr(3);
row.FleetMinAGL_m=m.fleetMinAGL_m; row.FleetMaxAGL_m=m.fleetMaxAGL_m;
row.LowerClearanceOK=logical(m.lowerClearanceOK); row.UpperAGLOK=logical(m.upperAGLOK); row.AllAGLOK=logical(m.allAGLOK);
mn=m.perUAVMinAGL_m(:); mx=m.perUAVMaxAGL_m(:);
row.UAV1_MinAGL_m=mn(1); row.UAV1_MaxAGL_m=mx(1); row.UAV2_MinAGL_m=mn(2); row.UAV2_MaxAGL_m=mx(2); row.UAV3_MinAGL_m=mn(3); row.UAV3_MaxAGL_m=mx(3);
row.Makespan_min=m.makespan_s/60; row.MinimumSeparation_m=m.minimumSeparation_m;
row.TotalPathLength_km=m.totalPathLength_m/1000; row.TotalEnergy=m.totalEnergy; row.MaximumEnergy=m.maximumEnergy;
row.FleetRiskScore=m.fleetRiskScore; row.MaximumRisk=m.maximumRisk; row.MaximumTailRisk=m.maximumTailRisk; row.MaximumSmoothness=m.maximumSmoothness;
row.Qavg=m.Qavg; row.Qmin=m.Qmin; row.Qcritical=m.Qcritical;
row.MissionDeficit=m.missionDeficit; row.MissionDeficit_Qmin=m.missionDeficitComponents(1); row.MissionDeficit_Qcritical=m.missionDeficitComponents(2);
row.MissionDeficit_CriticalObs=m.missionDeficitComponents(3); row.MissionDeficit_CriticalLOS=m.missionDeficitComponents(4);
row.CriticalObservationLength_m=m.criticalMinObservationLength_m; row.CriticalLOS=m.criticalMinLOS;
row.WorstTargetIndex=m.worstTargetIndex; row.WorstTargetUAV=m.worstTargetUAV; row.WorstTargetQuality=m.worstTargetQuality;
row.WorstTargetObservationLength_m=m.worstTargetObservationLength_m; row.WorstTargetLOS=m.worstTargetLOS;
row.CriticalObsWorstTargetIndex=m.criticalObsWorstTargetIndex; row.CriticalObsWorstTargetUAV=m.criticalObsWorstTargetUAV;
row.CriticalObsWorstTargetQuality=m.criticalObsWorstTargetQuality; row.CriticalObsWorstTargetLOS=m.criticalObsWorstTargetLOS;
row.CriticalLOSWorstTargetIndex=m.criticalLOSWorstTargetIndex; row.CriticalLOSWorstTargetUAV=m.criticalLOSWorstTargetUAV;
row.CriticalLOSWorstTargetQuality=m.criticalLOSWorstTargetQuality; row.CriticalLOSWorstTargetObservationLength_m=m.criticalLOSWorstTargetObservationLength_m;
wi=m.perUAVWorstTargetIndex(:); wq=m.perUAVWorstTargetQuality(:);
row.UAV1_WorstTargetIndex=wi(1); row.UAV2_WorstTargetIndex=wi(2); row.UAV3_WorstTargetIndex=wi(3);
row.UAV1_WorstTargetQuality=wq(1); row.UAV2_WorstTargetQuality=wq(2); row.UAV3_WorstTargetQuality=wq(3);
md=m.perUAVMissionDeficit(:); row.UAV1_MissionDeficit=md(1); row.UAV2_MissionDeficit=md(2); row.UAV3_MissionDeficit=md(3);
row.UnifiedMissionRepairEvents=m.totalUnifiedMissionRepairEvents;
row.UnifiedMissionRepairEvaluations=m.totalUnifiedMissionRepairEvaluations;
row.UnifiedMissionRepairAccepted=m.totalUnifiedMissionRepairAccepted;
e=m.perUAVUnifiedMissionRepairEvents(:); q=m.perUAVUnifiedMissionRepairEvaluations(:); a=m.perUAVUnifiedMissionRepairAccepted(:);
row.UAV1_UnifiedMissionRepairEvents=e(1); row.UAV2_UnifiedMissionRepairEvents=e(2); row.UAV3_UnifiedMissionRepairEvents=e(3);
row.UAV1_UnifiedMissionRepairEvaluations=q(1); row.UAV2_UnifiedMissionRepairEvaluations=q(2); row.UAV3_UnifiedMissionRepairEvaluations=q(3);
row.UAV1_UnifiedMissionRepairAccepted=a(1); row.UAV2_UnifiedMissionRepairAccepted=a(2); row.UAV3_UnifiedMissionRepairAccepted=a(3);
row.AllocationScore=m.allocationScore; row.AllocationTransitMakespanProxy_min=m.allocationTransitMakespanProxy_s/60;
row.AllocationRouteProxySpread_km=m.allocationRouteProxySpread_m/1000; row.AllocationLoadCV=m.allocationLoadCV;
row.AllocationRiskLoadCV=m.allocationRiskLoadCV; row.AllocationObservabilityLoadCV=m.allocationObservabilityLoadCV;
row.AllocationCriticalObservabilityLoadCV=m.allocationCriticalObservabilityLoadCV; row.AllocationWorstObservabilitySpread=m.allocationWorstObservabilitySpread;
row.Runtime_s=m.wallClockTime_s; row.OutputDirectory=outDir;
end

function row=localMergeRow(row,old)
fields=fieldnames(row);
for j=1:numel(fields)
    f=fields{j};
    if isfield(old,f)
        try, row.(f)=old.(f); catch, end %#ok<CTCH>
    end
end
end

function localWriteBatchStatistics(T,statsFile,ratesFile)
ok=T.Status=="ok"; names=T.Properties.VariableNames;
Metric=strings(0,1); N=zeros(0,1); Mean=zeros(0,1); Std=zeros(0,1); Median=zeros(0,1); Min=zeros(0,1); Max=zeros(0,1);
for j=1:numel(names)
    name=names{j}; if strcmp(name,'Seed'), continue; end
    x=T.(name); if ~isnumeric(x) && ~islogical(x), continue; end
    x=double(x(ok)); x=x(isfinite(x));
    Metric(end+1,1)=string(name); N(end+1,1)=numel(x); %#ok<AGROW>
    if isempty(x)
        Mean(end+1,1)=NaN; Std(end+1,1)=NaN; Median(end+1,1)=NaN; Min(end+1,1)=NaN; Max(end+1,1)=NaN; %#ok<AGROW>
    else
        Mean(end+1,1)=mean(x); Std(end+1,1)=std(x); Median(end+1,1)=median(x); Min(end+1,1)=min(x); Max(end+1,1)=max(x); %#ok<AGROW>
    end
end
writetable(table(Metric,N,Mean,Std,Median,Min,Max),statsFile);
checkNames={'MissionSuccess','AllUAVFinalFeasible','MonitoringSatisfied','CollisionFree', ...
    'AllControllerFinal','UAV1_ControllerFinal','UAV2_ControllerFinal','UAV3_ControllerFinal', ...
    'UAV1_FinalFeasible','UAV2_FinalFeasible','UAV3_FinalFeasible', ...
    'AllUAVStrictEngineering','UAV1_StrictEngineering','UAV2_StrictEngineering','UAV3_StrictEngineering', ...
    'LowerClearanceOK','UpperAGLOK','AllAGLOK'};
Check=string(checkNames(:)); SuccessfulSeeds=zeros(numel(checkNames),1);
EvaluatedSeeds=repmat(sum(ok),numel(checkNames),1); SuccessRate=nan(numel(checkNames),1);
for j=1:numel(checkNames)
    if any(ok), SuccessfulSeeds(j)=sum(T.(checkNames{j})(ok)); SuccessRate(j)=SuccessfulSeeds(j)/sum(ok); end
end
writetable(table(Check,SuccessfulSeeds,EvaluatedSeeds,SuccessRate),ratesFile);
end

function value=localCfg(cfg,name,defaultValue)
if isfield(cfg,name), value=cfg.(name); else, value=defaultValue; end
end
