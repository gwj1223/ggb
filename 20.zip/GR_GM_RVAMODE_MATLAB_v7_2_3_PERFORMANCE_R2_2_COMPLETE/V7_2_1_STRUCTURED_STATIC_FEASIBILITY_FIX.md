# v7.2.1 Structured Static-Feasibility Fix

## Why this patch exists

The first complete v7.2.0 Shiyan 3-UAV run established that the 51D semantic
monitoring representation can drive all three UAVs to formal Mission Deficit
D_M=0. The fleet still reported MissionSuccess=0 because UAV-2 had no final
static-feasible solution.

Post-run inspection localized the dominant UAV-2 defect to the final
observation-arc -> Goal transition. The fixed 42-waypoint decoder spent all
8 transit connector nodes elsewhere, leaving zero nodes on the final leg. The
resulting arc-exit/Goal junction exceeded the unchanged 95 degree turn limit.
A second decoder defect discarded an already successful Dense-3D altitude
profile whenever only the turn precheck failed, creating avoidable AGL/climb
violations in the fallback phenotype.

This patch is intentionally surgical. It does NOT change formal mission or
flight thresholds, the 51D semantic chromosome, the 42-waypoint phenotype,
Mission Band, A3, the five objectives, target allocation, or target order.

## Changes

1. **Boundary connector reservation**
   - Start -> first target: at least 1 connector.
   - Last target -> Goal: at least 1 connector.
   - The Shiyan 10-target phenotype remains exactly 42 internal waypoints.

2. **Turn-aware connector allocation**
   - Transit score now combines distance/terrain relief with endpoint heading
     mismatch.
   - Near-limit internal legs are protected before residual proportional allocation.
   - Boundary legs are capped at one tangent-aware connector so scarce 42-point
     geometry is not over-segmented.

3. **Tangent-aware transit geometry**
   - Connector positions use a cubic tangent-aware transition between
     observation arcs.
   - The handle length increases toward 0.495 of leg length for severe heading
     mismatch, so the single scarce connector node actually reduces the turn
     rather than merely subdividing the same straight chord.

4. **Preserve Dense-3D Z on turn-only failure**
   - If Dense-3D succeeds but the turn precheck fails, the best Dense-3D path
     is returned as the finite infeasible phenotype.
   - The old weaker waypoint-level altitude fallback is used only when Dense-3D
     itself fails.

5. **Representation-consistency guards**
   - Legacy XYZ final-stage local search is disabled in structured mode.
   - Infeasible restart now regenerates/perturbs `structuredGenes` and decodes
     them, rather than overwriting XYZ `genes` directly.

6. **Static diagnostics in `uav_summary.csv`**
   - `StaticCV`
   - collision / clearance / climb / turn / energy violation columns
   - structured decode success/reason/max turn
   - final-leg connector count

## Unchanged formal settings

- Population 96
- Max generations 220
- Five objectives
- Qmin 0.33
- Critical Q 0.42
- Critical observation 180 m
- Critical LOS 0.45
- AGL 60--320 m
- Max climb 22 degrees
- Max turn 95 degrees
- Formation starts Gen25
- Formal starts Gen100

## Recommended verification

Run `run_all_tests` first. Then run `run_uav2_only_v721` before rerunning the
full 3-UAV experiment. The UAV-2 check should focus on:

- `LastConnectorCount = 1` for the protected final boundary leg
- `StructuredDecodeReason = ok` for final feasible carriers
- turn violation -> 0
- clearance/climb violations -> 0
- `MissionDeficit = 0` retained
- `bestSolutionSatisfiesFinalConstraints = 1`
