# v7.1.0 Mission-Band Hierarchical Selection

## 1. Structural problem fixed

In v7.0.x, a static-feasible but mission-incomplete individual had

`cv = max(0, D_M - epsilon_D)`.

Within one generation `epsilon_D` is common to the population, so Tier-2 CV
ordering is exactly `D_M` ordering. When no individual satisfied the current
mission epsilon, environmental selection and p-best guidance therefore became
scalar Mission-Deficit optimization, while the ordinary archive retained only
one minimum-CV individual.

This contradicted the intended architecture:

`flight feasibility > mission formation > five-objective Pareto search`.

## 2. Formal semantics are not relaxed

`evaluation.updateDynamicConstraints` now exposes three explicit meanings:

- `staticFeasible`: hard flight constraints only;
- `missionScheduleFeasible`: static feasible and inside current scheduled epsilon;
- `formalMissionSatisfied`: formal monitoring requirements satisfied.

`ind.feasible` remains the scheduled-mission feasibility flag for backward
compatibility. Search-band membership is intentionally not stored on one
individual because it depends on the whole population.

## 3. Mission leader band

`selection.missionBandState` computes:

`K = ceil(missionBandMinFraction * NP)`

with a minimum of two leaders when possible. For Shiyan:

`missionBandMinFraction = 0.25`, `NP = 96`, therefore `K = 24`.

Let `D_(K)` be the K-th smallest Mission Deficit among static-feasible paths.
The search epsilon is

`epsilon_search = max(epsilon_scheduled, D_(K))`.

This value never changes the formal/scheduled epsilon stored on individuals.
It only identifies protected search leaders.

## 4. 2N -> N environmental selection

The new quota-based hierarchy is:

- S0: scheduled-mission admissible candidates;
- S1: additional mission-band leaders needed to protect the leader quota;
- S2: remaining static-feasible candidates;
- S3: static-infeasible candidates.

S0 is always selected before S1. S0+S1 form the protected mission-pressure
quota. Remaining S2 capacity is filled by the five physical objectives using
Pareto fronts and reference-vector split-front selection. Exact `D_M` sorting
is no longer used to fill the whole next population.

This design is intentional: merely protecting K leaders and then filling the
other N-K slots by `D_M` would still produce the N smallest-D candidates and
would not solve the original degeneration.

## 5. Search Archive vs Final Archive

`selection.updateArchive` is now the search-diversity archive in Mission-Band
runs. It keeps five-objective leaders from the current mission band and always
retains a current best-D leader. It can therefore remain multi-member when
scheduled mission feasibility is zero.

`finalArchive` remains strict but now has an explicit canonical update path.
`localUpdateFinalArchive` first re-evaluates candidates with formal epsilon zero,
rejects nonformal candidates, and then calls `selection.updateFormalArchive`.
That helper retains only the five-objective nondominated formal front and never
applies Search-Archive best-D leader preservation. Thus Mission-Band search
semantics cannot contaminate formal Pareto/HV reporting.

## 6. DE p-best guidance

`operators.buildTrialContext` uses `missionBandState.searchAdmissible` for
p-best ranking. Within that band the candidates are ranked by five-objective
Pareto rank plus normalized objective merit/crowding. This removes the old
fallback where an empty scheduled-feasible set made p-best exact-CV ordered.

The search archive remains the optional DE difference-vector donor pool.

Mutation-strategy credit follows the same semantic separation. In Mission-Band
runs, the "infeasible" CV-recovery credit branch is entered only when the
population has no static-feasible path. A population with static-feasible but
mission-incomplete paths uses survival + monitoring-gain + diversity credit, so
strategy learning does not silently revert to scalar Mission-Deficit reduction.

## 7. A3 base diversification

`core.selectMissionRepairBases` is a canonical base selector. Unified A3 first
restricts base candidates to the mission leader band when enabled, then uses:

1. minimum-D candidate;
2. distinct repair targets first;
3. normalized five-objective max-min diversity for remaining slots.

A3 acceptance remains exactly the v7.0.5.4 contract:

- static feasibility required;
- global D_M non-regression;
- protected formal conditions cannot be broken;
- selected target must gain at least the configured amount.

Dense-3D precheck and the 12 full-evaluation/event budget are unchanged.

## 8. New tests

Seven new regressions are registered:

- `test_mission_band_selection`
- `test_mission_band_preserves_formal_semantics`
- `test_mission_band_reference_vector_selection`
- `test_mission_band_trial_context`
- `test_search_archive_no_singleton_collapse`
- `test_formal_archive_pareto_separation`
- `test_a3_diverse_base_selection`

Total registered tests: 88.

## 9. What to inspect in the first real run

Healthy early/mid-stage behavior should show:

- `static` remains high;
- `band` stays around at least 24 when `mission` falls below 24;
- Search Archive remains multi-member;
- population diversity no longer collapses solely because scheduled epsilon shrinks;
- A3 `targets` often contain more than one distinct bottleneck;
- `D[min]` trends downward without forcing all 96 survivors to be exact-D leaders;
- formal carriers eventually appear and remain protected.

Formal thresholds and physical constraints are unchanged.
