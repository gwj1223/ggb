# v7.0.0.1 Test-Synchronization Fix

This patch changes **tests only**. The v7.0.0 production algorithm is unchanged.

## Cause

`allocateTargetsObservabilityAware` intentionally changed the allocation method label in v7.0.0 to:

`v700_knowledge_risk_observability_route_balanced_exclusive`

Two legacy tests still asserted the v6.5.9 label:

`risk_observability_3d_route_balanced_exclusive`

Therefore `run_all_tests` stopped at `test_multi_uav_assignment`, even though the allocator had already returned a valid v7.0.0 assignment. `test_observability_aware_assignment` contained the same stale assertion and would have failed next.

## Fix

Updated only:

- `tests/test_multi_uav_assignment.m`
- `tests/test_observability_aware_assignment.m`

The tests now verify v7 behavior semantically:

- the method identifies the knowledge/risk/observability/route-balanced allocator;
- a `monitoringKnowledge` structure is present;
- the knowledge base version is `v7.0.0-static-dem-los-knowledge`;
- all existing quota, route, observability and wrapper-equivalence assertions remain.

No objective, constraint, operator, allocator rule, Mission Deficit, A1/A3/A6 mechanism, population, generation count or threshold was changed.
