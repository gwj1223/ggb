clear; clc; close all;
%RUN_UAV1_ONLY_V722 Focused v7.2.2 structured-decoder verification.
projectRoot=fileparts(mfilename('fullpath'));
setupProject(projectRoot);
cfg=config.multiUAVShiyanConfig();
[problem,cfg]=realdata.buildShiyanG1Problem(projectRoot,cfg);
assignment=multiUAV.allocateTargetsObservabilityAware(problem,cfg);
[subProblem,subCfg]=multiUAV.buildSubProblem(problem,cfg,assignment,1);
config.validateConfig(subCfg,subProblem);
layout=core.structuredMonitoringLayout(subProblem,subCfg);
fprintf('\n=== v7.2.2 UAV-1 focused verification ===\n');
fprintf('seed=%d targets=%d waypoints=%d semantic=%dD phenotype=%dD\n', ...
    subCfg.randomSeed,size(subProblem.monitorTargets,1),subCfg.numWaypoints, ...
    layout.dimension,3*subCfg.numWaypoints);
fprintf('global targets=[%s]\n',num2str(assignment.groups{1}));
r=core.runGRAHMODE(subProblem,subCfg);
b=r.best(1);
fprintf('\n--- UAV-1 final ---\n');
fprintf('FinalFeasible=%d | D=%.6f | staticCV=%.6g\n', ...
    r.bestSolutionSatisfiesFinalConstraints, ...
    evaluation.finalMonitoringDeficit(b,subCfg),b.staticCV);
fprintf('viol[col/clr/clm/trn/E]=[%.6g %.6g %.6g %.6g %.6g]\n', ...
    b.violation.collision,b.violation.clearance,b.violation.climb, ...
    b.violation.turn,b.violation.energy);
if isfield(b,'encodingInfo') && isstruct(b.encodingInfo)
    info=b.encodingInfo;
    if isfield(info,'connectorCount') && ~isempty(info.connectorCount)
        fprintf('connectorCount=[%s] | last=%d\n', ...
            num2str(info.connectorCount(:)'),info.connectorCount(end));
        if isfield(info,'connectorTurnCostDeg') && ~isempty(info.connectorTurnCostDeg)
            fprintf('turnCostDeg[0/1/2] per leg:\n');
            disp(info.connectorTurnCostDeg);
        end
    end
    if isfield(info,'legTurnDemandDeg') && ~isempty(info.legTurnDemandDeg)
        fprintf('legTurnDemandDeg=[%s]\n',num2str(info.legTurnDemandDeg(:)','%.1f '));
    end
    if isfield(info,'reason') && isfield(info,'maxTurnDeg')
        fprintf('decode=%s | maxTurn=%.3f deg\n', ...
            char(string(info.reason)),info.maxTurnDeg);
    end
end
fprintf('Qmin=%.4f Qcritical=%.4f CriticalObs=%.2f CriticalLOS=%.4f\n', ...
    b.monitorStats.minimumQuality,b.monitorStats.criticalQuality, ...
    b.monitorStats.minimumCriticalObservationLength, ...
    b.monitorStats.minimumCriticalLOSRatio);
