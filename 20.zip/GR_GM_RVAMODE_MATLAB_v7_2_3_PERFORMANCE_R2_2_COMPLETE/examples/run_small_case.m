clear; clc; close all;
root = fileparts(fileparts(mfilename('fullpath')));
setupProject(root);
cfg = config.fastConfig();
problem = data.createDemoProblem(cfg);
result = core.runGRAHMODE(problem,cfg);
visualization.plotResult(problem,result,cfg);
fprintf('Fast run completed in %.2f s.\n',result.totalOptimizationTime);
