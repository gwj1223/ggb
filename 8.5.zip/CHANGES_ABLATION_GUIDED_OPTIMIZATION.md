# Ablation-guided PEAR-MOEA optimization

This update applies the conclusions from the ablation study to the default proposed algorithm.

## Default PEAR-MOEA changes

The default full PEAR-MOEA now disables two instance-dependent components:

```matlab
params.usePriorityInit = false;
params.useEpsGridArchive = false;
```

The following modules remain enabled:

```matlab
params.useSpatialInit = true;
params.usePriorityRelocate = true;
params.useTwoOpt = true;
params.useInterTripRelocation = true;
params.useTripCompression = true;
```

## Rationale

The ablation results showed that trip-compression repair, spatial initialization, 2-opt local search, and risk-aware relocation are the main useful modules. Priority initialization and epsilon-grid archive had marginal or negative effects on the current UAV geohazard monitoring instance, so they are no longer part of the default full method.

## Updated files

- `defaultParams.m`
- `algorithm/runComparator.m`
- `examples/ablation_experiment.m`
- `README.md`
- `CHANGES_ABLATION_STUDY.md`

## Recommended next experiments

Run the updated paper comparison and the updated ablation study:

```matlab
run('examples/compare_algorithms.m')
run('examples/batch_runs.m')
run('examples/ablation_experiment.m')
```
