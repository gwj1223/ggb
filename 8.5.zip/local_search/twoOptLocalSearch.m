function perm2 = twoOptLocalSearch(perm, problem)
% twoOptLocalSearch
% Apply 2-opt inside each decoded trip.

    [trips, ~] = decodeTrips(perm, problem);
    for k = 1:numel(trips)
        trips{k} = twoOptTrip(trips{k}, problem.distMat);
    end
    perm2 = [trips{:}];
end
