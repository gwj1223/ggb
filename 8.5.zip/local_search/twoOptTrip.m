function bestTrip = twoOptTrip(trip, distMat)
% twoOptTrip
% 2-opt local search for one trip.

    bestTrip = trip;
    n = numel(trip);
    if n < 3
        return;
    end

    improved = true;
    while improved
        improved = false;
        bestDist = calcTripDistance(bestTrip, distMat);
        for i = 1:n-1
            for j = i+1:n
                cand = bestTrip;
                cand(i:j) = fliplr(cand(i:j));
                candDist = calcTripDistance(cand, distMat);
                if candDist < bestDist - 1e-9
                    bestTrip = cand;
                    bestDist = candDist;
                    improved = true;
                end
            end
        end
    end
end
