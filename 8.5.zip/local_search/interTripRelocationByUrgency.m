function permNew = interTripRelocationByUrgency(perm, problem, params)
% interTripRelocationByUrgency
% Urgency-aware inter-trip relocation operator.
% It attempts to move high-risk nodes from later trips to earlier trips
% without violating the maximum range constraint.

    permNew = perm;

    if ~isfield(params, 'interTripMaxTrial')
        params.interTripMaxTrial = 20;
    end
    if ~isfield(params, 'highRiskRatio')
        params.highRiskRatio = 0.20;
    end

    [trips, oldMetrics] = decodeTrips(perm, problem);
    K = numel(trips);
    if K < 2
        return;
    end

    urgency = problem.urgency;
    nHigh = max(1, ceil(params.highRiskRatio * problem.nGS));
    [~, idx] = sort(urgency, 'descend');
    highRiskNodes = idx(1:nHigh);

    oldScore = relocationScore(oldMetrics, problem);
    bestTrips = trips;
    bestScore = oldScore;

    lateTrips = ceil(K/2)+1 : K;
    if isempty(lateTrips)
        lateTrips = 2:K;
    end

    for trial = 1:params.interTripMaxTrial
        candidateList = [];
        for s = lateTrips
            nodes = trips{s};
            highNodesInTrip = intersect(nodes, highRiskNodes);
            for a = 1:numel(highNodesInTrip)
                candidateList = [candidateList; s, highNodesInTrip(a)]; %#ok<AGROW>
            end
        end

        if isempty(candidateList)
            return;
        end

        row = candidateList(randi(size(candidateList, 1)), :);
        sourceTripIndex = row(1);
        node = row(2);

        for targetTripIndex = 1:sourceTripIndex-1
            sourceTrip = trips{sourceTripIndex};
            targetTrip = trips{targetTripIndex};
            sourceTrip2 = sourceTrip(sourceTrip ~= node);

            for pos = 1:numel(targetTrip)+1
                targetTrip2 = [targetTrip(1:pos-1), node, targetTrip(pos:end)];
                dTarget = calcTripDistance(targetTrip2, problem.distMat);
                dSource = calcTripDistance(sourceTrip2, problem.distMat);

                if dTarget > problem.Lmax || dSource > problem.Lmax
                    continue;
                end

                newTrips = trips;
                newTrips{targetTripIndex} = targetTrip2;
                newTrips{sourceTripIndex} = sourceTrip2;
                newTrips = newTrips(~cellfun(@isempty, newTrips));
                candidatePerm = [newTrips{:}];

                [~, candMetrics] = decodeTrips(candidatePerm, problem);
                candScore = relocationScore(candMetrics, problem);

                if candScore < bestScore
                    bestScore = candScore;
                    bestTrips = newTrips;
                end
            end
        end
    end

    if bestScore < oldScore
        permNew = [bestTrips{:}];
    end
end

function score = relocationScore(metrics, problem)
% Local score for relocation. Smaller is better.
    totalUrgency = sum(problem.urgency);
    profitTerm = -metrics.totalProfit / (totalUrgency + eps);
    distanceTerm = metrics.totalDistance / (problem.nGS * problem.Lmax + eps);
    timeTerm = metrics.totalMissionTime / (problem.nGS + eps);
    utilTerm = metrics.maxRangeUtilization;

    wProfit = 0.45;
    wDistance = 0.20;
    wTime = 0.25;
    wUtil = 0.10;

    score = wProfit * profitTerm + wDistance * distanceTerm + wTime * timeTerm + wUtil * utilTerm;
end
