function permNew = energyRiskInsertionRepair(perm, problem, params)
% energyRiskInsertionRepair
% Lightweight local repair for PEAR-MOEA.
%
% This operator relocates individual nodes between feasible trips and accepts
% only moves that improve an energy/risk-aware score. Unlike trip compression,
% it does not require eliminating a trip; it fine-tunes trip composition and
% node insertion positions after crossover/mutation, 2-opt, and trip
% compression.

    permNew = perm;

    if nargin < 3 || ~isstruct(params)
        params = struct();
    end
    if ~isfield(params, 'insertionRepairMaxMove')
        params.insertionRepairMaxMove = 3;
    end

    [trips, baseMetrics] = decodeTrips(perm, problem);
    if isempty(trips)
        return;
    end

    bestTrips = trips;
    bestScore = insertionScore(baseMetrics, problem);

    for moveNo = 1:params.insertionRepairMaxMove
        bestMoveTrips = [];
        bestMoveScore = bestScore;

        for s = 1:numel(bestTrips)
            sourceTrip = bestTrips{s};
            if isempty(sourceTrip)
                continue;
            end

            % Try lower-urgency nodes first, but still allow high-risk nodes
            % to move if the risk-aware score improves.
            [~, nodeOrder] = sort(problem.urgency(sourceTrip), 'ascend');
            orderedSource = sourceTrip(nodeOrder);

            for ii = 1:numel(orderedSource)
                node = orderedSource(ii);
                sourceWithoutNode = sourceTrip(sourceTrip ~= node);

                for t = 1:numel(bestTrips)
                    targetTrip = bestTrips{t};
                    if t == s
                        targetTrip = sourceWithoutNode;
                    end

                    for pos = 1:(numel(targetTrip) + 1)
                        candTrips = bestTrips;
                        candTrips{s} = sourceWithoutNode;
                        candTrips{t} = [targetTrip(1:pos-1), node, targetTrip(pos:end)];
                        candTrips = candTrips(~cellfun(@isempty, candTrips));

                        if ~allTripsFeasibleLocal(candTrips, problem)
                            continue;
                        end

                        candPerm = [candTrips{:}];
                        if numel(unique(candPerm)) ~= problem.nGS
                            continue;
                        end

                        [~, candMetrics] = decodeTrips(candPerm, problem);
                        candScore = insertionScore(candMetrics, problem);

                        if candScore < bestMoveScore - 1e-12
                            bestMoveScore = candScore;
                            bestMoveTrips = candTrips;
                        end
                    end
                end
            end
        end

        if isempty(bestMoveTrips)
            break;
        end

        bestTrips = bestMoveTrips;
        bestScore = bestMoveScore;
    end

    candPerm = [bestTrips{:}];
    [~, candMetrics] = decodeTrips(candPerm, problem);
    if insertionScore(candMetrics, problem) <= insertionScore(baseMetrics, problem) + 1e-12
        permNew = candPerm;
    end
end

function ok = allTripsFeasibleLocal(trips, problem)
    ok = true;
    for k = 1:numel(trips)
        if calcTripDistance(trips{k}, problem.distMat) > problem.Lmax + 1e-9
            ok = false;
            return;
        end
    end
end

function score = insertionScore(metrics, problem)
% Smaller is better. This local score is less trip-dominant than the trip
% compression score and is intended to fine-tune energy and risk scheduling.
    profitTerm = -metrics.totalProfit / (sum(problem.urgency) + eps);
    distanceTerm = metrics.totalDistance / (problem.nGS * problem.Lmax + eps);
    energyTerm = metrics.totalEnergy / (problem.nGS * problem.Lmax + eps);
    timeTerm = metrics.totalMissionTime / (problem.nGS * problem.Lmax / problem.speed + eps);
    tripTerm = metrics.nTrips / max(1, problem.nGS);
    utilTerm = metrics.maxRangeUtilization;
    riskAvgTerm = metrics.highRiskAvgTrip / max(1, metrics.nTrips);
    riskMaxTerm = metrics.highRiskMaxTrip / max(1, metrics.nTrips);

    wProfit = 0.18;
    wDistance = 0.20;
    wEnergy = 0.22;
    wTime = 0.08;
    wTrip = 0.12;
    wUtil = 0.05;
    wRiskAvg = 0.10;
    wRiskMax = 0.05;

    score = wProfit * profitTerm + wDistance * distanceTerm + ...
            wEnergy * energyTerm + wTime * timeTerm + ...
            wTrip * tripTerm + wUtil * utilTerm + ...
            wRiskAvg * riskAvgTerm + wRiskMax * riskMaxTerm;
end
