function permNew = tripCompressionRepair(perm, problem, params)
% tripCompressionRepair
% Enhanced PEAR-MOEA repair operator for reducing redundant UAV trips.
%
% The operator decodes a permutation into trips and tries to move nodes from
% short trips into other feasible trips. Candidate moves are selected by an
% energy/risk-aware compactness score. Compared with the previous version,
% this version gives stronger preference to route compression while also
% penalizing late high-risk visits, so it avoids improving distance at the
% expense of risk-sensitive scheduling.

    permNew = perm;

    if nargin < 3 || ~isstruct(params)
        params = struct();
    end
    if ~isfield(params, 'tripCompressionMaxPass')
        params.tripCompressionMaxPass = 3;
    end

    [trips, oldMetrics] = decodeTrips(perm, problem);
    if numel(trips) < 2
        return;
    end

    bestTrips = trips;
    bestScore = compressionScore(oldMetrics, problem);

    for pass = 1:params.tripCompressionMaxPass
        improvedThisPass = false;

        % Compress the shortest trips first. They are usually the easiest
        % candidates to absorb into neighbouring trips.
        [~, sourceOrder] = sort(cellfun(@numel, bestTrips), 'ascend');
        for oo = 1:numel(sourceOrder)
            s = sourceOrder(oo);
            if s > numel(bestTrips) || isempty(bestTrips{s})
                continue;
            end

            % Move less urgent nodes first. This protects high-risk nodes
            % that have already been placed early in the schedule.
            sourceNodes = bestTrips{s};
            [~, nodeOrder] = sort(problem.urgency(sourceNodes), 'ascend');
            sourceNodes = sourceNodes(nodeOrder);

            for nn = 1:numel(sourceNodes)
                node = sourceNodes(nn);
                currentTrips = bestTrips;
                sourceTrip = currentTrips{s};
                sourceTrip = sourceTrip(sourceTrip ~= node);

                bestMoveTrips = [];
                bestMoveScore = bestScore;

                for t = 1:numel(currentTrips)
                    if t == s
                        continue;
                    end
                    targetTrip = currentTrips{t};

                    for pos = 1:(numel(targetTrip) + 1)
                        candTrips = currentTrips;
                        candTrips{s} = sourceTrip;
                        candTrips{t} = [targetTrip(1:pos-1), node, targetTrip(pos:end)];
                        candTrips = candTrips(~cellfun(@isempty, candTrips));

                        if ~allTripsFeasible(candTrips, problem)
                            continue;
                        end

                        candPerm = [candTrips{:}];
                        [~, candMetrics] = decodeTrips(candPerm, problem);
                        candScore = compressionScore(candMetrics, problem);

                        if candScore < bestMoveScore - 1e-12
                            bestMoveScore = candScore;
                            bestMoveTrips = candTrips;
                        end
                    end
                end

                if ~isempty(bestMoveTrips)
                    bestTrips = bestMoveTrips;
                    bestScore = bestMoveScore;
                    improvedThisPass = true;
                    break;
                end
            end

            if improvedThisPass
                break;
            end
        end

        if ~improvedThisPass
            break;
        end
    end

    candPerm = [bestTrips{:}];
    [~, candMetrics] = decodeTrips(candPerm, problem);
    if compressionScore(candMetrics, problem) <= compressionScore(oldMetrics, problem) + 1e-12
        permNew = candPerm;
    end
end

function ok = allTripsFeasible(trips, problem)
    ok = true;
    for k = 1:numel(trips)
        if calcTripDistance(trips{k}, problem.distMat) > problem.Lmax + 1e-9
            ok = false;
            return;
        end
    end
end

function score = compressionScore(metrics, problem)
% Smaller is better. The score prioritizes fewer trips, then balances route
% compactness, energy, profit, utilization, and high-risk scheduling.
    tripTerm = metrics.nTrips / max(1, problem.nGS);
    profitTerm = -metrics.totalProfit / (sum(problem.urgency) + eps);
    distanceTerm = metrics.totalDistance / (problem.nGS * problem.Lmax + eps);
    energyTerm = metrics.totalEnergy / (problem.nGS * problem.Lmax + eps);
    utilTerm = metrics.maxRangeUtilization;
    riskAvgTerm = metrics.highRiskAvgTrip / max(1, metrics.nTrips);
    riskMaxTerm = metrics.highRiskMaxTrip / max(1, metrics.nTrips);

    wTrip = 0.42;
    wProfit = 0.20;
    wDistance = 0.15;
    wEnergy = 0.12;
    wUtil = 0.03;
    wRiskAvg = 0.05;
    wRiskMax = 0.03;

    score = wTrip * tripTerm + wProfit * profitTerm + ...
            wDistance * distanceTerm + wEnergy * energyTerm + ...
            wUtil * utilTerm + wRiskAvg * riskAvgTerm + ...
            wRiskMax * riskMaxTerm;
end
