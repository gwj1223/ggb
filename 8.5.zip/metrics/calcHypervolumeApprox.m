function hv = calcHypervolumeApprox(pop, idealPoint, refPoint, nSamples)
% calcHypervolumeApprox
% Monte Carlo hypervolume approximation for minimization.
% Objectives should be finite. Larger HV is better.

    if nargin < 4
        nSamples = 20000;
    end

    if isempty(pop)
        hv = 0;
        return;
    end

    costs = vertcat(pop.Cost);
    nObj = size(costs, 2);

    idealPoint = idealPoint(:)';
    refPoint = refPoint(:)';
    span = refPoint - idealPoint;
    span(span <= 0) = eps;

    samples = rand(nSamples, nObj) .* span + idealPoint;
    dominated = false(nSamples, 1);

    for i = 1:size(costs, 1)
        dominated = dominated | all(costs(i, :) <= samples, 2);
    end

    boxVolume = prod(span);
    hv = boxVolume * mean(dominated);
end
