function [bestSol, bestIndex, closeness] = selectCompromiseSolutionByTOPSIS(pop, weights)
% selectCompromiseSolutionByTOPSIS
% TOPSIS compromise solution selection. All costs are minimized.

    if isempty(pop)
        bestSol = [];
        bestIndex = [];
        closeness = [];
        return;
    end

    if nargin < 2 || isempty(weights)
        weights = ones(1, numel(pop(1).Cost));
        weights = weights / sum(weights);
    else
        weights = weights(:)';
        weights = weights / sum(weights);
    end

    costs = vertcat(pop.Cost);
    minC = min(costs, [], 1);
    maxC = max(costs, [], 1);
    normCosts = (costs - minC) ./ (maxC - minC + eps);
    weightedCosts = normCosts .* weights;

    idealBest = min(weightedCosts, [], 1);
    idealWorst = max(weightedCosts, [], 1);

    dBest = sqrt(sum((weightedCosts - idealBest).^2, 2));
    dWorst = sqrt(sum((weightedCosts - idealWorst).^2, 2));
    closeness = dWorst ./ (dBest + dWorst + eps);

    [~, bestIndex] = max(closeness);
    bestSol = pop(bestIndex);
end
