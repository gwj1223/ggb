function [normCosts, minCost, maxCost] = normalizeObjectiveCosts(costs, minCost, maxCost)
% normalizeObjectiveCosts
% Linearly normalize objective values to [0, 1].
%
% All objectives are assumed to be minimization objectives.
%
% Inputs:
%   costs   : N x M objective matrix
%   minCost : 1 x M lower bounds. Optional.
%   maxCost : 1 x M upper bounds. Optional.
%
% Outputs:
%   normCosts : N x M normalized objective matrix
%   minCost   : lower bounds used
%   maxCost   : upper bounds used

    if isempty(costs)
        normCosts = [];
        if nargin < 2
            minCost = [];
        end
        if nargin < 3
            maxCost = [];
        end
        return;
    end

    if nargin < 2 || isempty(minCost)
        minCost = min(costs, [], 1);
    end

    if nargin < 3 || isempty(maxCost)
        maxCost = max(costs, [], 1);
    end

    minCost = minCost(:)';
    maxCost = maxCost(:)';

    normCosts = (costs - minCost) ./ (maxCost - minCost + eps);

    % Numerical clipping.
    normCosts = max(0, min(1, normCosts));
end
