function spacing = calcSpacing(pop)
% calcSpacing
% Spacing indicator based on normalized objective vectors. Smaller is better.

    if isempty(pop) || numel(pop) <= 2
        spacing = 0;
        return;
    end

    costs = vertcat(pop.Cost);
    minC = min(costs, [], 1);
    maxC = max(costs, [], 1);
    normCosts = (costs - minC) ./ (maxC - minC + eps);

    n = size(normCosts, 1);
    d = zeros(n, 1);
    for i = 1:n
        diffs = sum(abs(normCosts - normCosts(i, :)), 2);
        diffs(i) = inf;
        d(i) = min(diffs);
    end
    dbar = mean(d);
    spacing = sqrt(sum((d - dbar).^2) / max(1, n - 1));
end
