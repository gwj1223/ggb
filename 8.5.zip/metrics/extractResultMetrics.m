function row = extractResultMetrics(result)
% extractResultMetrics
% Extract scalar metrics from a run result.
%
% Note:
%   NormHV is initialized here so that this structure has the same fields as
%   the preallocated rows used in examples/batch_runs.m. The actual NormHV
%   value is calculated later after all runs using global normalization
%   bounds and then written back to row.NormHV.

    sol = result.bestSol;
    row.Profit = sol.Metrics.totalProfit;
    row.Distance = sol.Metrics.totalDistance;
    row.Time = sol.Metrics.totalMissionTime;
    row.MaxUtil = sol.Metrics.maxRangeUtilization;
    row.Trips = sol.Metrics.nTrips;
    row.Energy = sol.Metrics.totalEnergy;
    row.EarlyRate = sol.Metrics.highRiskEarlyRate;
    row.HighRiskAvgTrip = sol.Metrics.highRiskAvgTrip;
    row.HighRiskMaxTrip = sol.Metrics.highRiskMaxTrip;
    row.Spacing = calcSpacing(result.archive);
    row.NormHV = 0;
    row.ArchiveSize = numel(result.archive);
end
