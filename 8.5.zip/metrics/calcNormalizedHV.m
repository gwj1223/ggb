function hvNorm = calcNormalizedHV(costs, minCost, maxCost, refPoint, nSamples)
% calcNormalizedHV
% Monte Carlo hypervolume in normalized objective space for minimization.
%
% This function first normalizes objective values to [0, 1] using common
% bounds, then computes the dominated hypervolume with respect to refPoint.
% The returned value is divided by prod(refPoint), so hvNorm is in [0, 1]
% when refPoint is positive, e.g., refPoint = [1.1 1.1 1.1 1.1].
%
% Inputs:
%   costs    : N x M objective matrix. All objectives are minimized.
%   minCost  : 1 x M global lower bounds, computed from all compared methods.
%   maxCost  : 1 x M global upper bounds, computed from all compared methods.
%   refPoint : 1 x M reference point in normalized space. Default: 1.1.
%   nSamples : number of Monte Carlo samples. Default: 50000.
%
% Output:
%   hvNorm   : normalized hypervolume in [0, 1]. Larger is better.

    if nargin < 5 || isempty(nSamples)
        nSamples = 50000;
    end

    if isempty(costs)
        hvNorm = 0;
        return;
    end

    [normCosts, ~, ~] = normalizeObjectiveCosts(costs, minCost, maxCost);
    nObj = size(normCosts, 2);

    if nargin < 4 || isempty(refPoint)
        refPoint = 1.1 * ones(1, nObj);
    end

    refPoint = refPoint(:)';

    % Keep only points inside the reference box.
    valid = all(normCosts <= refPoint, 2);
    normCosts = normCosts(valid, :);

    if isempty(normCosts)
        hvNorm = 0;
        return;
    end

    % Keep only non-dominated points to speed up HV calculation.
    normCosts = getNonDominatedCostsForHV(normCosts);

    if nObj == 2
        hvRaw = exactHV2D(normCosts, refPoint);
    else
        hvRaw = monteCarloHV(normCosts, refPoint, nSamples);
    end

    refVolume = prod(refPoint);
    if refVolume <= 0
        hvNorm = hvRaw;
    else
        hvNorm = hvRaw / refVolume;
    end

    % Guard against tiny Monte Carlo / floating point overshoot.
    hvNorm = max(0, min(1, hvNorm));
end

function ndCosts = getNonDominatedCostsForHV(costs)
% getNonDominatedCostsForHV
% Return non-dominated objective vectors for minimization.

    n = size(costs, 1);
    isDominated = false(n, 1);

    for i = 1:n
        for j = 1:n
            if i == j
                continue;
            end
            if all(costs(j, :) <= costs(i, :)) && any(costs(j, :) < costs(i, :))
                isDominated(i) = true;
                break;
            end
        end
    end

    ndCosts = costs(~isDominated, :);
    ndCosts = unique(round(ndCosts, 10), 'rows');
end

function hv = exactHV2D(costs, refPoint)
% exactHV2D
% Exact hypervolume for two minimization objectives.

    costs = sortrows(costs, 1);
    hv = 0;
    currentY = refPoint(2);

    for i = 1:size(costs, 1)
        width = refPoint(1) - costs(i, 1);
        height = currentY - costs(i, 2);

        if width > 0 && height > 0
            hv = hv + width * height;
            currentY = costs(i, 2);
        end
    end
end

function hv = monteCarloHV(costs, refPoint, nSamples)
% monteCarloHV
% Monte Carlo hypervolume approximation for minimization objectives.

    nObj = size(costs, 2);

    lower = zeros(1, nObj);
    upper = refPoint;

    samples = rand(nSamples, nObj) .* (upper - lower) + lower;
    dominated = false(nSamples, 1);

    for i = 1:size(costs, 1)
        dominated = dominated | all(samples >= costs(i, :), 2);
    end

    boxVolume = prod(upper - lower);
    hv = boxVolume * mean(dominated);
end
