%% main.m
% PEAR-MOEA for multi-trip UAV geohazard monitoring path planning.
%
% PEAR-MOEA:
% Priority-guided Energy-aware and Risk-aware Multi-Objective Evolutionary Algorithm
%
% Cost vector, all minimized:
%   1) -Profit    : maximize urgency-decay monitoring profit
%   2) Distance   : minimize total flight distance
%   3) Energy     : minimize total energy consumption
%   4) MaxUtil    : minimize maximum range utilization

clear; clc; close all;
addpath(genpath(pwd));

params = defaultParams();
params.seed = 1;

problem = createUAVProblem(params);

fprintf('\n================ Run PEAR-MOEA ================\n');
result = runComparator('PEAR-MOEA', problem, params, true);

printSolution(result.bestSol, problem, 'PEAR-MOEA Compromise Solution');
checkUAVSolution(result.bestSol, problem);

plotSolution(result.bestSol, problem);
plotParetoFront(result.archive, 'PEAR-MOEA Archive Pareto Set');
plotConvergence(result.history);
