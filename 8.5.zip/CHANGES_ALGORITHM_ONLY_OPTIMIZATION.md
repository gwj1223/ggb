# Algorithm-only optimization update

This version applies a small, algorithm-only optimization based on the final
ablation study. The problem definition, objective vector, comparison baselines,
and experiment scripts are kept unchanged.

## Main changes

### 1. Priority mutation disabled by default

The final ablation showed that priority relocation mutation had only marginal
benefit once risk relocation and trip compression were enabled. Therefore the
final default is now:

```matlab
params.usePriorityRelocate = false;
```

The operator is not removed. It remains available for ablation as `with Priority
Mutation`.

### 2. Enhanced trip-compression repair

`local_search/tripCompressionRepair.m` was updated with a more energy/risk-aware
compactness score. The score now considers:

- number of trips,
- monitoring profit,
- total distance,
- total energy,
- maximum range utilization,
- average high-risk trip index,
- latest high-risk trip index.

Default parameters were slightly intensified:

```matlab
params.pTripCompression = 0.35;
params.tripCompressionMaxPass = 3;
```

### 3. New energy/risk-aware insertion repair

A new local repair operator was added:

```text
local_search/energyRiskInsertionRepair.m
```

It relocates individual nodes across feasible trips only when an energy/risk-aware
score improves. Unlike trip compression, it does not require eliminating a trip;
it fine-tunes trip composition and insertion positions.

Default parameters:

```matlab
params.useInsertionRepair = true;
params.pInsertionRepair = 0.20;
params.insertionRepairMaxMove = 3;
```

### 4. Updated PEAR-MOEA default configuration

The final PEAR-MOEA default is now:

```matlab
params.usePriorityInit = false;
params.useSpatialInit = true;
params.usePriorityRelocate = false;
params.useTwoOpt = true;
params.useInterTripRelocation = true;
params.useTripCompression = true;
params.useInsertionRepair = true;
params.useEpsGridArchive = false;
```

## Recommended verification

Run a single comparison first:

```matlab
run('examples/compare_algorithms.m')
```

Then run the 30-run comparison:

```matlab
run('examples/batch_runs.m')
```

If the batch result is not better than the previous optimized version, disable
only insertion repair while keeping the stronger trip compression:

```matlab
params.useInsertionRepair = false;
```
