function [pop, F] = nonDominatedSorting(pop)
% nonDominatedSorting
% Fast non-dominated sorting for minimization.

    nPop = numel(pop);
    S = cell(nPop, 1);
    nDom = zeros(nPop, 1);
    F = {};
    F{1} = [];

    for i = 1:nPop
        pop(i).Rank = [];
        pop(i).CrowdingDistance = 0;
    end

    for p = 1:nPop
        S{p} = [];
        nDom(p) = 0;
        for q = 1:nPop
            if dominates(pop(p).Cost, pop(q).Cost)
                S{p} = [S{p}, q]; %#ok<AGROW>
            elseif dominates(pop(q).Cost, pop(p).Cost)
                nDom(p) = nDom(p) + 1;
            end
        end
        if nDom(p) == 0
            pop(p).Rank = 1;
            F{1} = [F{1}, p]; %#ok<AGROW>
        end
    end

    k = 1;
    while true
        Q = [];
        for p = F{k}
            for q = S{p}
                nDom(q) = nDom(q) - 1;
                if nDom(q) == 0
                    pop(q).Rank = k + 1;
                    Q = [Q, q]; %#ok<AGROW>
                end
            end
        end
        if isempty(Q)
            break;
        end
        F{k+1} = Q; %#ok<AGROW>
        k = k + 1;
    end
end

function b = dominates(cost1, cost2)
    b = all(cost1 <= cost2) && any(cost1 < cost2);
end
