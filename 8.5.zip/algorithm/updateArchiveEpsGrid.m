function archive = updateArchiveEpsGrid(archive, candidates, maxArchiveSize, epsGrid)
% updateArchiveEpsGrid
% External archive maintenance using non-dominated sorting, cost uniqueness,
% epsilon-grid filtering, and crowding truncation.

    if isempty(archive)
        combined = candidates;
    elseif isempty(candidates)
        combined = archive;
    else
        combined = [archive; candidates];
    end

    if isempty(combined)
        archive = [];
        return;
    end

    [combined, F] = nonDominatedSorting(combined);
    if isempty(F) || isempty(F{1})
        archive = [];
        return;
    end

    archive = combined(F{1});
    archive = uniquePopulationByCost(archive, 1e-8);
    archive = epsGridFilter(archive, epsGrid);

    if numel(archive) > maxArchiveSize
        F2{1} = 1:numel(archive);
        archive = calcCrowdingDistance(archive, F2);
        archive = sortPopulation(archive);
        archive = archive(1:maxArchiveSize);
    end
end

function pop2 = epsGridFilter(pop, epsGrid)
    if isempty(pop)
        pop2 = pop;
        return;
    end

    costs = vertcat(pop.Cost);
    minC = min(costs, [], 1);
    maxC = max(costs, [], 1);
    normCosts = (costs - minC) ./ (maxC - minC + eps);
    gridIndex = floor(normCosts / epsGrid);

    [uniqueGrid, ~, ic] = unique(gridIndex, 'rows', 'stable');
    pop2 = repmat(pop(1), size(uniqueGrid, 1), 1);

    for g = 1:size(uniqueGrid, 1)
        members = find(ic == g);
        if numel(members) == 1
            pop2(g) = pop(members);
        else
            subCosts = normCosts(members, :);
            [~, bestLocal] = min(sum(subCosts, 2));
            pop2(g) = pop(members(bestLocal));
        end
    end
end
