function result = runGreedyBaseline(problem, params, mode, verbose)
% runGreedyBaseline
% Simple heuristic baselines for the UAV geohazard routing problem.
%
% Supported modes:
%   'NN'     : nearest-neighbor trip construction. It only uses distance and
%              the range constraint; it does not use urgency, profit, risk,
%              2-opt, archive search, or PEAR-MOEA repair operators.
%   'Random' : random permutation baseline.
%
% These baselines intentionally return a single solution archive. They are
% included as traditional routing references rather than multi-objective
% optimizers.

    if nargin < 3 || isempty(mode), mode = 'NN'; end
    if nargin < 4, verbose = true; end

    empty = algorithmEmptyIndividual();
    ind = empty;

    switch lower(mode)
        case {'nn', 'nearest', 'nearest-neighbor', 'nearestneighbor'}
            ind.Position = nearestNeighborPermutation(problem);
            label = 'NN-Greedy';
        case {'random', 'random-greedy', 'rand'}
            ind.Position = randperm(problem.nGS);
            label = 'Random-Greedy';
        otherwise
            error('Unknown greedy baseline mode: %s', mode);
    end

    ind = evaluateIndividual(ind, problem);
    pop = ind;
    archive = ind;

    history = initAlgorithmHistory(params.MaxIt);
    for it = 1:params.MaxIt
        history = updateAlgorithmHistory(history, it, archive, ind, 0);
    end

    if verbose
        fprintf('%s completed. Archive = %d | Profit = %.4f | Distance = %.4f | Energy = %.4f | Trips = %d\n', ...
            label, numel(archive), ind.Metrics.totalProfit, ind.Metrics.totalDistance, ...
            ind.Metrics.totalEnergy, ind.Metrics.nTrips);
    end

    result = finalizeAlgorithmResult(pop, archive, history, params);
end

function perm = nearestNeighborPermutation(problem)
% Build a distance-only nearest-neighbor order while respecting the single
% trip range as much as possible. The returned permutation is still decoded
% by decodeTrips, so all algorithms share the same decoder.

    n = problem.nGS;
    remaining = 1:n;
    perm = zeros(1, n);
    pos = 0;
    trip = [];
    current = 0;

    while ~isempty(remaining)
        bestIdx = [];
        bestDist = inf;

        for j = 1:numel(remaining)
            node = remaining(j);
            candidateTrip = [trip, node]; %#ok<AGROW>
            dTrip = calcTripDistance(candidateTrip, problem.distMat);
            if dTrip <= problem.Lmax
                dStep = distanceBetween(current, node, problem);
                if dStep < bestDist
                    bestDist = dStep;
                    bestIdx = j;
                end
            end
        end

        if isempty(bestIdx)
            % No remaining node can be added to the current trip. Start a new
            % trip from the depot and try again. If the trip is already empty,
            % fall back to the nearest remaining node to avoid an infinite loop.
            if isempty(trip)
                bestIdx = nearestFromDepot(remaining, problem);
            else
                trip = [];
                current = 0;
                continue;
            end
        end

        node = remaining(bestIdx);
        pos = pos + 1;
        perm(pos) = node;
        trip = [trip, node]; %#ok<AGROW>
        current = node;
        remaining(bestIdx) = [];
    end
end

function idx = nearestFromDepot(nodes, problem)
    d = zeros(1, numel(nodes));
    for i = 1:numel(nodes)
        d(i) = problem.distMat(1, nodes(i)+1);
    end
    [~, idx] = min(d);
end

function d = distanceBetween(a, b, problem)
    % Node 0 is depot, task nodes are 1..nGS. distMat uses depot index 1 and
    % task node i at index i+1.
    d = problem.distMat(a+1, b+1);
end
