function result = runMOABC(problem, params, verbose)
% runMOABC
% Multi-objective artificial bee colony baseline for permutation coding.

    if nargin < 3, verbose = true; end
    empty = algorithmEmptyIndividual();
    nPop = params.nPop;
    MaxIt = params.MaxIt;
    limit = max(10, round(0.2 * MaxIt));
    trial = zeros(nPop, 1);
    pop = repmat(empty, nPop, 1);
    for i = 1:nPop
        pop(i).Position = randperm(problem.nGS);
        pop(i) = evaluateIndividual(pop(i), problem);
    end
    [pop, F] = nonDominatedSorting(pop);
    pop = calcCrowdingDistance(pop, F);
    archive = archiveByParams([], pop(F{1}), params);
    history = initAlgorithmHistory(MaxIt);

    for it = 1:MaxIt
        pm = params.pmMax - (params.pmMax - params.pmMin) * (it - 1) / max(1, MaxIt - 1);
        % Employed bees
        for i = 1:nPop
            cand = neighborFood(pop(i).Position, problem, params, pm);
            ind = empty; ind.Position = cand; ind = evaluateIndividual(ind, problem);
            if acceptCandidate(ind, pop(i))
                pop(i) = ind; trial(i) = 0;
            else
                trial(i) = trial(i) + 1;
            end
        end
        % Onlooker bees
        scores = scalarFitness(pop);
        prob = scores / (sum(scores) + eps);
        for k = 1:nPop
            i = roulette(prob);
            cand = neighborFood(pop(i).Position, problem, params, pm);
            ind = empty; ind.Position = cand; ind = evaluateIndividual(ind, problem);
            if acceptCandidate(ind, pop(i))
                pop(i) = ind; trial(i) = 0;
            else
                trial(i) = trial(i) + 1;
            end
        end
        % Scout bees
        for i = 1:nPop
            if trial(i) > limit
                pop(i).Position = randperm(problem.nGS);
                pop(i) = evaluateIndividual(pop(i), problem);
                trial(i) = 0;
            end
        end
        [pop, F] = nonDominatedSorting(pop);
        pop = calcCrowdingDistance(pop, F);
        archive = archiveByParams(archive, pop(F{1}), params);
        [bestSol, ~, ~] = selectCompromiseSolutionByTOPSIS(archive, params.topsisWeights);
        history = updateAlgorithmHistory(history, it, archive, bestSol, pm);
        if verbose && (it == 1 || mod(it, 20) == 0 || it == MaxIt)
            fprintf('MOABC iteration %d / %d, Archive = %d, pm = %.4f\n', it, MaxIt, numel(archive), pm);
        end
    end
    result = finalizeAlgorithmResult(pop, archive, history, params);
end

function y = neighborFood(x, problem, params, pm)
    y = x;
    if rand < 0.5
        y = reverseMutation(y);
    else
        y = swapMutation(y);
    end
    if rand < pm
        y = mutatePermutation(y, problem, params);
    end
end

function ok = acceptCandidate(a, b)
    if all(a.Cost <= b.Cost) && any(a.Cost < b.Cost)
        ok = true;
    elseif ~(all(b.Cost <= a.Cost) && any(b.Cost < a.Cost))
        ok = rand < 0.5;
    else
        ok = false;
    end
end

function s = scalarFitness(pop)
    C = vertcat(pop.Cost);
    C = (C - min(C, [], 1)) ./ (max(C, [], 1) - min(C, [], 1) + eps);
    s = 1 ./ (1 + sum(C, 2));
end

function idx = roulette(p)
    c = cumsum(p(:));
    r = rand * c(end);
    idx = find(c >= r, 1, 'first');
    if isempty(idx), idx = randi(numel(p)); end
end
