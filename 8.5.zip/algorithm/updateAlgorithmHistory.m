function history = updateAlgorithmHistory(history, it, archive, bestSol, pm)
% updateAlgorithmHistory
% Fill common convergence curves.
    history.paretoSize(it) = numel(archive);
    history.archiveSize(it) = numel(archive);
    history.pm(it) = pm;
    history.bestProfit(it) = bestSol.Metrics.totalProfit;
    history.bestDistance(it) = bestSol.Metrics.totalDistance;
    history.bestTime(it) = bestSol.Metrics.totalMissionTime;
    history.bestEnergy(it) = bestSol.Metrics.totalEnergy;
end
