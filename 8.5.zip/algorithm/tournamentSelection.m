function selected = tournamentSelection(pop)
% tournamentSelection
% Binary tournament by rank and crowding distance.

    nPop = numel(pop);
    i = randi(nPop);
    j = randi(nPop);
    a = pop(i);
    b = pop(j);

    if isBetter(a, b)
        selected = a;
    else
        selected = b;
    end
end

function flag = isBetter(a, b)
    if a.Rank < b.Rank
        flag = true;
    elseif a.Rank == b.Rank
        flag = a.CrowdingDistance > b.CrowdingDistance;
    else
        flag = false;
    end
end
