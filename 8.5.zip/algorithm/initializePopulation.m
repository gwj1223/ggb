function pop = initializePopulation(problem, params, empty)
% initializePopulation
% Mixed initialization for P-NSGA-II; random for standard NSGA-II.

    nPop = params.nPop;
    pop = repmat(empty, nPop, 1);

    usePriority = isfield(params, 'usePriorityInit') && params.usePriorityInit;
    useSpatial = isfield(params, 'useSpatialInit') && params.useSpatialInit;

    for i = 1:nPop
        if usePriority && i <= round(0.4 * nPop)
            pop(i).Position = priorityInitialization(problem, params.alphaPriority);
        elseif useSpatial && i <= round(0.7 * nPop)
            pop(i).Position = spatialInitialization(problem);
        else
            pop(i).Position = randperm(problem.nGS);
        end
        pop(i) = evaluateIndividual(pop(i), problem);
    end
end
