function archive = archiveByParams(archive, candidates, params)
% archiveByParams
    if isfield(params, 'useEpsGridArchive') && params.useEpsGridArchive
        archive = updateArchiveEpsGrid(archive, candidates, params.maxArchiveSize, params.epsGrid);
    else
        archive = updateArchive(archive, candidates, params.maxArchiveSize);
    end
end
