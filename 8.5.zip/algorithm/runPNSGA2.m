function result = runPNSGA2(problem, params, verbose)
% runPNSGA2
% Run PEAR-MOEA or standard NSGA-II depending on switches in params.

    if nargin < 3
        verbose = true;
    end

    nPop = params.nPop;
    MaxIt = params.MaxIt;

    empty.Position = [];
    empty.Cost = [];
    empty.Rank = [];
    empty.CrowdingDistance = [];
    empty.Trips = [];
    empty.Metrics = [];

    pop = initializePopulation(problem, params, empty);
    [pop, F] = nonDominatedSorting(pop);
    pop = calcCrowdingDistance(pop, F);
    pop = sortPopulation(pop);

    archive = [];
    F1 = pop([pop.Rank] == 1);
    archive = updateArchiveByParams(archive, F1, params);

    history.paretoSize = zeros(MaxIt, 1);
    history.archiveSize = zeros(MaxIt, 1);
    history.pm = zeros(MaxIt, 1);
    history.bestProfit = zeros(MaxIt, 1);
    history.bestDistance = zeros(MaxIt, 1);
    history.bestTime = zeros(MaxIt, 1);
    history.bestEnergy = zeros(MaxIt, 1);

    for it = 1:MaxIt

        if isfield(params, 'useAdaptiveMutation') && params.useAdaptiveMutation
            pm = params.pmMax - (params.pmMax - params.pmMin) * (it - 1) / max(1, MaxIt - 1);
        else
            pm = params.pm;
        end

        if isfield(params, 'useAdaptiveLocalSearch') && params.useAdaptiveLocalSearch
            pLocalSearch = params.pLSMin + (params.pLSMax - params.pLSMin) * (it - 1) / max(1, MaxIt - 1);
        else
            pLocalSearch = params.pLocalSearch;
        end

        offspring = repmat(empty, nPop, 1);

        for k = 1:2:nPop
            p1 = tournamentSelection(pop);
            p2 = tournamentSelection(pop);

            x1 = p1.Position;
            x2 = p2.Position;

            if rand <= params.pc
                [y1, y2] = orderCrossover(x1, x2);
            else
                y1 = x1;
                y2 = x2;
            end

            if rand <= pm
                y1 = mutatePermutation(y1, problem, params);
            end
            if rand <= pm
                y2 = mutatePermutation(y2, problem, params);
            end

            if isfield(params, 'useTwoOpt') && params.useTwoOpt
                if rand <= pLocalSearch
                    y1 = twoOptLocalSearch(y1, problem);
                end
                if rand <= pLocalSearch
                    y2 = twoOptLocalSearch(y2, problem);
                end
            end

            if isfield(params, 'useInterTripRelocation') && params.useInterTripRelocation
                if rand <= params.pInterTripRelocation
                    y1 = interTripRelocationByUrgency(y1, problem, params);
                end
                if rand <= params.pInterTripRelocation
                    y2 = interTripRelocationByUrgency(y2, problem, params);
                end
            end

            if isfield(params, 'useTripCompression') && params.useTripCompression
                if rand <= params.pTripCompression
                    y1 = tripCompressionRepair(y1, problem, params);
                end
                if rand <= params.pTripCompression
                    y2 = tripCompressionRepair(y2, problem, params);
                end
            end

            if isfield(params, 'useInsertionRepair') && params.useInsertionRepair
                if rand <= params.pInsertionRepair
                    y1 = energyRiskInsertionRepair(y1, problem, params);
                end
                if rand <= params.pInsertionRepair
                    y2 = energyRiskInsertionRepair(y2, problem, params);
                end
            end

            offspring(k).Position = y1;
            offspring(k) = evaluateIndividual(offspring(k), problem);

            if k + 1 <= nPop
                offspring(k + 1).Position = y2;
                offspring(k + 1) = evaluateIndividual(offspring(k + 1), problem);
            end
        end

        combinedPop = [pop; offspring];
        combinedPop = uniquePopulationByPosition(combinedPop);

        % If too many unique individuals vanished, add random immigrants.
        while numel(combinedPop) < nPop
            newInd = empty;
            newInd.Position = randperm(problem.nGS);
            newInd = evaluateIndividual(newInd, problem);
            combinedPop = [combinedPop; newInd]; %#ok<AGROW>
        end

        [combinedPop, F] = nonDominatedSorting(combinedPop);
        combinedPop = calcCrowdingDistance(combinedPop, F);
        combinedPop = sortPopulation(combinedPop);

        if numel(combinedPop) >= nPop
            pop = combinedPop(1:nPop);
        else
            pop = combinedPop;
        end

        F1 = pop([pop.Rank] == 1);
        archive = updateArchiveByParams(archive, F1, params);

        history.paretoSize(it) = numel(F1);
        history.archiveSize(it) = numel(archive);
        history.pm(it) = pm;

        decisionSet = archive;
        if isempty(decisionSet)
            decisionSet = F1;
        end
        [tmpBest, ~, ~] = selectCompromiseSolutionByTOPSIS(decisionSet, params.topsisWeights);
        history.bestProfit(it) = tmpBest.Metrics.totalProfit;
        history.bestDistance(it) = tmpBest.Metrics.totalDistance;
        history.bestTime(it) = tmpBest.Metrics.totalMissionTime;
        history.bestEnergy(it) = tmpBest.Metrics.totalEnergy;

        if verbose && (it == 1 || mod(it, 20) == 0 || it == MaxIt)
            fprintf('Iteration %d / %d, Pareto solutions = %d, Archive = %d, pm = %.4f\n', ...
                it, MaxIt, numel(F1), numel(archive), pm);
        end
    end

    if isempty(archive)
        archive = pop([pop.Rank] == 1);
    end

    [bestSol, bestIndex, closeness] = selectCompromiseSolutionByTOPSIS(archive, params.topsisWeights);

    result.pop = pop;
    result.archive = archive;
    result.bestSol = bestSol;
    result.bestIndex = bestIndex;
    result.topsisCloseness = closeness;
    result.history = history;
    result.params = params;
end

function archive = updateArchiveByParams(archive, F1, params)
    if isfield(params, 'useEpsGridArchive') && params.useEpsGridArchive
        archive = updateArchiveEpsGrid(archive, F1, params.maxArchiveSize, params.epsGrid);
    else
        archive = updateArchive(archive, F1, params.maxArchiveSize);
    end
end
