function result = runMOPSO(problem, params, verbose)
% runMOPSO
% Discrete MOPSO baseline for permutation-coded UAV route planning.
% Velocity is represented by a list of swap operations learned from pbest and
% a leader selected from the external archive.

    if nargin < 3, verbose = true; end
    empty = algorithmEmptyIndividual();
    nPop = params.nPop;
    MaxIt = params.MaxIt;
    pop = repmat(empty, nPop, 1);
    for i = 1:nPop
        pop(i).Position = randperm(problem.nGS);
        pop(i) = evaluateIndividual(pop(i), problem);
        pop(i).BestPosition = pop(i).Position;
        pop(i).BestCost = pop(i).Cost;
    end
    [pop, F] = nonDominatedSorting(pop);
    pop = calcCrowdingDistance(pop, F);
    archive = archiveByParams([], pop(F{1}), params);
    history = initAlgorithmHistory(MaxIt);

    for it = 1:MaxIt
        pm = params.pmMax - (params.pmMax - params.pmMin) * (it - 1) / max(1, MaxIt - 1);
        for i = 1:nPop
            if isempty(archive)
                leader = pop(randi(nPop));
            else
                leader = archive(randi(numel(archive)));
            end
            x = pop(i).Position;
            x = moveTowardPermutation(x, pop(i).BestPosition, 0.35);
            x = moveTowardPermutation(x, leader.Position, 0.35);
            if rand < pm
                x = mutatePermutation(x, problem, params);
            end
            pop(i).Position = x;
            pop(i) = evaluateIndividual(pop(i), problem);
            if dominatesCost(pop(i).Cost, pop(i).BestCost) || (~dominatesCost(pop(i).BestCost, pop(i).Cost) && rand < 0.5)
                pop(i).BestPosition = pop(i).Position;
                pop(i).BestCost = pop(i).Cost;
            end
        end
        [pop, F] = nonDominatedSorting(pop);
        pop = calcCrowdingDistance(pop, F);
        pop = sortPopulation(pop);
        archive = archiveByParams(archive, pop(F{1}), params);
        [bestSol, ~, ~] = selectCompromiseSolutionByTOPSIS(archive, params.topsisWeights);
        history = updateAlgorithmHistory(history, it, archive, bestSol, pm);
        if verbose && (it == 1 || mod(it, 20) == 0 || it == MaxIt)
            fprintf('MOPSO iteration %d / %d, Archive = %d, pm = %.4f\n', it, MaxIt, numel(archive), pm);
        end
    end
    result = finalizeAlgorithmResult(pop, archive, history, params);
end

function x = moveTowardPermutation(x, target, prob)
    n = numel(x);
    nMove = max(1, round(prob * n * rand));
    for t = 1:nMove
        pos = randi(n);
        gene = target(pos);
        cur = find(x == gene, 1);
        if ~isempty(cur) && cur ~= pos
            x([pos cur]) = x([cur pos]);
        end
    end
end

function b = dominatesCost(c1, c2)
    b = all(c1 <= c2) && any(c1 < c2);
end
