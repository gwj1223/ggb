function archive = updateArchive(archive, candidates, maxArchiveSize)
% updateArchive
% Basic external archive maintenance by non-dominated sorting and crowding.

    if isempty(archive)
        combined = candidates;
    elseif isempty(candidates)
        combined = archive;
    else
        combined = [archive; candidates];
    end

    if isempty(combined)
        archive = [];
        return;
    end

    combined = uniquePopulationByCost(combined, 1e-8);
    [combined, F] = nonDominatedSorting(combined);
    archive = combined(F{1});

    if numel(archive) > maxArchiveSize
        F2{1} = 1:numel(archive);
        archive = calcCrowdingDistance(archive, F2);
        archive = sortPopulation(archive);
        archive = archive(1:maxArchiveSize);
    end
end
