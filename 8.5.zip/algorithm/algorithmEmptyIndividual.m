function empty = algorithmEmptyIndividual()
% algorithmEmptyIndividual
% Shared individual template.
    empty.Position = [];
    empty.Cost = [];
    empty.Rank = [];
    empty.CrowdingDistance = [];
    empty.Trips = [];
    empty.Metrics = [];
    empty.Fitness = [];
    empty.Velocity = [];
    empty.BestPosition = [];
    empty.BestCost = [];
end
