function result = runMOEAD(problem, params, verbose)
% runMOEAD
% Simplified MOEA/D baseline with permutation operators and Tchebycheff
% replacement.

    if nargin < 3, verbose = true; end
    empty = algorithmEmptyIndividual();
    nPop = params.nPop;
    MaxIt = params.MaxIt;
    M = 4;
    W = generateReferenceDirections(M, nPop);
    T = min(20, nPop);
    D = pairwiseDist(W);
    [~, B] = sort(D, 2, 'ascend');
    B = B(:, 1:T);

    pop = repmat(empty, nPop, 1);
    for i = 1:nPop
        pop(i).Position = randperm(problem.nGS);
        pop(i) = evaluateIndividual(pop(i), problem);
    end
    ideal = min(vertcat(pop.Cost), [], 1);
    [popND, F] = nonDominatedSorting(pop);
    archive = archiveByParams([], popND(F{1}), params);
    history = initAlgorithmHistory(MaxIt);

    for it = 1:MaxIt
        pm = params.pm;
        if isfield(params, 'useAdaptiveMutation') && params.useAdaptiveMutation
            pm = params.pmMax - (params.pmMax - params.pmMin) * (it - 1) / max(1, MaxIt - 1);
        end
        for i = 1:nPop
            nb = B(i, :);
            r = nb(randperm(numel(nb), 2));
            p1 = pop(r(1)); p2 = pop(r(2));
            if rand <= params.pc
                [childPos, ~] = orderCrossover(p1.Position, p2.Position);
            else
                childPos = p1.Position;
            end
            if rand <= pm
                childPos = mutatePermutation(childPos, problem, params);
            end
            child = empty;
            child.Position = childPos;
            child = evaluateIndividual(child, problem);
            ideal = min(ideal, child.Cost);
            for jj = 1:numel(nb)
                j = nb(jj);
                if tcheby(child.Cost, W(j, :), ideal) <= tcheby(pop(j).Cost, W(j, :), ideal)
                    pop(j) = child;
                end
            end
        end
        [pop, F] = nonDominatedSorting(pop);
        pop = calcCrowdingDistance(pop, F);
        archive = archiveByParams(archive, pop(F{1}), params);
        decisionSet = archive;
        if isempty(decisionSet), decisionSet = pop(F{1}); end
        [bestSol, ~, ~] = selectCompromiseSolutionByTOPSIS(decisionSet, params.topsisWeights);
        history = updateAlgorithmHistory(history, it, archive, bestSol, pm);
        if verbose && (it == 1 || mod(it, 20) == 0 || it == MaxIt)
            fprintf('MOEA/D iteration %d / %d, Archive = %d, pm = %.4f\n', it, MaxIt, numel(archive), pm);
        end
    end
    result = finalizeAlgorithmResult(pop, archive, history, params);
end

function val = tcheby(cost, w, ideal)
    val = max(max(w, 1e-6) .* abs(cost - ideal));
end

function D = pairwiseDist(W)
    n = size(W, 1);
    D = zeros(n, n);
    for i = 1:n
        dif = W - W(i, :);
        D(i, :) = sqrt(sum(dif.^2, 2));
    end
end
