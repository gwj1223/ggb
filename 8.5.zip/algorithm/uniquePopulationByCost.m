function pop2 = uniquePopulationByCost(pop, tol)
% uniquePopulationByCost
% Remove individuals with duplicated objective vectors.

    if isempty(pop)
        pop2 = pop;
        return;
    end

    costs = vertcat(pop.Cost);
    costsRound = round(costs / tol) * tol;
    [~, ia] = unique(costsRound, 'rows', 'stable');
    pop2 = pop(ia);
end
