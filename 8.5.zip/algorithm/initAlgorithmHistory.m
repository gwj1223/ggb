function history = initAlgorithmHistory(MaxIt)
% initAlgorithmHistory
    history.paretoSize = zeros(MaxIt, 1);
    history.archiveSize = zeros(MaxIt, 1);
    history.pm = zeros(MaxIt, 1);
    history.bestProfit = zeros(MaxIt, 1);
    history.bestDistance = zeros(MaxIt, 1);
    history.bestTime = zeros(MaxIt, 1);
    history.bestEnergy = zeros(MaxIt, 1);
end
