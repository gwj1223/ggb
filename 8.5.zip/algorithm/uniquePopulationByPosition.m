function pop2 = uniquePopulationByPosition(pop)
% uniquePopulationByPosition
% Remove duplicated permutations.

    if isempty(pop)
        pop2 = pop;
        return;
    end

    positions = vertcat(pop.Position);
    [~, ia] = unique(positions, 'rows', 'stable');
    pop2 = pop(ia);
end
