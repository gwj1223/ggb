function result = runReferenceMOEA(problem, params, mode, verbose)
% runReferenceMOEA
% Common permutation MOEA runner for NSGA-III and SPEA2 baselines.

    if nargin < 4, verbose = true; end
    empty = algorithmEmptyIndividual();
    nPop = params.nPop;
    MaxIt = params.MaxIt;
    pop = repmat(empty, nPop, 1);
    for i = 1:nPop
        pop(i).Position = randperm(problem.nGS);
        pop(i) = evaluateIndividual(pop(i), problem);
    end
    [pop, F] = nonDominatedSorting(pop);
    pop = calcCrowdingDistance(pop, F);
    archive = archiveByParams([], pop(F{1}), params);
    history = initAlgorithmHistory(MaxIt);
    refDirs = generateReferenceDirections(size(pop(1).Cost, 2), nPop);

    for it = 1:MaxIt
        pm = params.pm;
        if isfield(params, 'useAdaptiveMutation') && params.useAdaptiveMutation
            pm = params.pmMax - (params.pmMax - params.pmMin) * (it - 1) / max(1, MaxIt - 1);
        end
        offspring = repmat(empty, nPop, 1);
        for k = 1:2:nPop
            p1 = binaryTournamentGeneric(pop);
            p2 = binaryTournamentGeneric(pop);
            if rand <= params.pc
                [y1, y2] = orderCrossover(p1.Position, p2.Position);
            else
                y1 = p1.Position;
                y2 = p2.Position;
            end
            if rand <= pm, y1 = mutatePermutation(y1, problem, params); end
            if rand <= pm, y2 = mutatePermutation(y2, problem, params); end
            offspring(k).Position = y1;
            offspring(k) = evaluateIndividual(offspring(k), problem);
            if k + 1 <= nPop
                offspring(k+1).Position = y2;
                offspring(k+1) = evaluateIndividual(offspring(k+1), problem);
            end
        end
        combined = uniquePopulationByPosition([pop; offspring]);
        while numel(combined) < nPop
            ind = empty;
            ind.Position = randperm(problem.nGS);
            ind = evaluateIndividual(ind, problem);
            combined = [combined; ind]; %#ok<AGROW>
        end
        switch upper(mode)
            case 'NSGA-III'
                pop = environmentalSelectionNSGA3(combined, nPop, refDirs);
            case 'SPEA2'
                pop = environmentalSelectionSPEA2(combined, nPop);
            otherwise
                error('Unknown reference MOEA mode.');
        end
        [pop, F] = nonDominatedSorting(pop);
        pop = calcCrowdingDistance(pop, F);
        archive = archiveByParams(archive, pop(F{1}), params);
        decisionSet = archive;
        if isempty(decisionSet), decisionSet = pop(F{1}); end
        [bestSol, ~, ~] = selectCompromiseSolutionByTOPSIS(decisionSet, params.topsisWeights);
        history = updateAlgorithmHistory(history, it, archive, bestSol, pm);
        if verbose && (it == 1 || mod(it, 20) == 0 || it == MaxIt)
            fprintf('%s iteration %d / %d, Archive = %d, pm = %.4f\n', mode, it, MaxIt, numel(archive), pm);
        end
    end
    result = finalizeAlgorithmResult(pop, archive, history, params);
end

function ind = binaryTournamentGeneric(pop)
    i = randi(numel(pop));
    j = randi(numel(pop));
    a = pop(i); b = pop(j);
    if isempty(a.Rank), a.Rank = inf; end
    if isempty(b.Rank), b.Rank = inf; end
    if a.Rank < b.Rank
        ind = a;
    elseif b.Rank < a.Rank
        ind = b;
    elseif a.CrowdingDistance > b.CrowdingDistance
        ind = a;
    else
        ind = b;
    end
end
