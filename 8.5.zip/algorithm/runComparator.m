function result = runComparator(algorithmName, problem, params, verbose)
% runComparator
% Unified entry point for paper-level algorithm comparison.
%
% Supported names:
%   NN-Greedy, Random-Greedy, NSGA-II, NSGA-III, MOEA/D, SPEA2,
%   MOPSO, MODE, MOACO-lite, PEAR-MOEA, Proposed
%
% Baselines use the same permutation representation and the same objective
% vector [-profit, distance, energy, maxUtil]. They do not use the proposed
% PEAR-MOEA spatial initialization, priority mutation, risk-aware relocation, 2-opt, trip-compression
% repair, or energy/risk insertion repair unless explicitly selected as PEAR-MOEA.

    if nargin < 4
        verbose = true;
    end

    name = upper(strtrim(algorithmName));
    name = strrep(name, '_', '-');

    switch name
        case {'PROPOSED', 'PEAR-MOEA', 'PEARMOEA'}
            p = params;
            p.algorithmLabel = 'PEAR-MOEA';
            % Algorithm-only optimized PEAR-MOEA.
            % Kept: spatial initialization, 2-opt, risk-aware relocation,
            % enhanced trip-compression repair, and energy/risk insertion repair.
            % Disabled by default: priority initialization, priority mutation,
            % and epsilon-grid archive, according to ablation evidence.
            p.usePriorityInit = false;
            p.useSpatialInit = true;
            p.usePriorityRelocate = false;
            p.useTwoOpt = true;
            p.useInterTripRelocation = true;
            p.useTripCompression = true;
            p.useInsertionRepair = true;
            p.useEpsGridArchive = false;
            result = runPNSGA2(problem, p, verbose);
            result.algorithmName = 'PEAR-MOEA';

        case {'NSGA-II', 'NSGA2'}
            p = params;
            p.algorithmLabel = 'NSGA-II';
            p = configureBaselineParams(p);
            p.usePriorityInit = false;
            p.useSpatialInit = false;
            p.usePriorityRelocate = false;
            p.useTwoOpt = false;
            p.useInterTripRelocation = false;
            p.useInsertionRepair = false;
            p.useEpsGridArchive = false;
            result = runPNSGA2(problem, p, verbose);
            result.algorithmName = 'NSGA-II';

        case {'NSGA-III', 'NSGA3'}
            p = params;
            p.algorithmLabel = 'NSGA-III';
            p = configureBaselineParams(p);
            result = runReferenceMOEA(problem, p, 'NSGA-III', verbose);
            result.algorithmName = 'NSGA-III';

        case {'MOEA/D', 'MOEAD', 'MOEA-D'}
            p = params;
            p.algorithmLabel = 'MOEA/D';
            p = configureBaselineParams(p);
            result = runMOEAD(problem, p, verbose);
            result.algorithmName = 'MOEA/D';

        case {'SPEA2'}
            p = params;
            p.algorithmLabel = 'SPEA2';
            p = configureBaselineParams(p);
            result = runReferenceMOEA(problem, p, 'SPEA2', verbose);
            result.algorithmName = 'SPEA2';

        case {'MOPSO'}
            p = params;
            p.algorithmLabel = 'MOPSO';
            p = configureBaselineParams(p);
            result = runMOPSO(problem, p, verbose);
            result.algorithmName = 'MOPSO';

        case {'MODE'}
            p = params;
            p.algorithmLabel = 'MODE';
            p = configureBaselineParams(p);
            result = runMODE(problem, p, verbose);
            result.algorithmName = 'MODE';

        case {'MOACO', 'MOACO-LITE', 'MOACO-L'}
            p = params;
            p.algorithmLabel = 'MOACO-lite';
            p = configureBaselineParams(p);
            result = runMOACO(problem, p, verbose);
            result.algorithmName = 'MOACO-lite';

        case {'NN-GREEDY', 'NEAREST-GREEDY', 'NEAREST-NEIGHBOR-GREEDY', 'GREEDY'}
            p = params;
            p.algorithmLabel = 'NN-Greedy';
            p = configureBaselineParams(p);
            result = runGreedyBaseline(problem, p, 'NN', verbose);
            result.algorithmName = 'NN-Greedy';

        case {'RANDOM-GREEDY', 'RAND-GREEDY'}
            p = params;
            p.algorithmLabel = 'Random-Greedy';
            p = configureBaselineParams(p);
            result = runGreedyBaseline(problem, p, 'Random', verbose);
            result.algorithmName = 'Random-Greedy';

        otherwise
            error('Unsupported algorithm: %s', algorithmName);
    end
end


function p = configureBaselineParams(p)
% configureBaselineParams
% Remove PEAR-MOEA-specific operators from comparison baselines.
% Baselines keep the same encoding, decoder, objective function, and metrics,
% but do not use priority-guided initialization/mutation, risk-aware relocation,
% 2-opt local search, or trip-compression repair.
    p.usePriorityInit = false;
    p.useSpatialInit = false;
    p.usePriorityRelocate = false;
    p.useTwoOpt = false;
    p.useInterTripRelocation = false;
    p.useTripCompression = false;
    p.useInsertionRepair = false;
end
