function W = generateReferenceDirections(M, n)
% generateReferenceDirections
% Generate approximately uniform reference directions on the positive simplex.
    W = rand(n, M);
    W = W ./ (sum(W, 2) + eps);
    % Add extreme directions to stabilize NSGA-III selection.
    for i = 1:min(M, n)
        W(i, :) = 0;
        W(i, i) = 1;
    end
end
