function result = runMODE(problem, params, verbose)
% runMODE
% Multi-objective differential-evolution-style baseline for permutation
% coding. Donor information is injected through order-preserving crossover.

    if nargin < 3, verbose = true; end
    empty = algorithmEmptyIndividual();
    nPop = params.nPop;
    MaxIt = params.MaxIt;
    pop = repmat(empty, nPop, 1);
    for i = 1:nPop
        pop(i).Position = randperm(problem.nGS);
        pop(i) = evaluateIndividual(pop(i), problem);
    end
    [pop, F] = nonDominatedSorting(pop);
    pop = calcCrowdingDistance(pop, F);
    archive = archiveByParams([], pop(F{1}), params);
    history = initAlgorithmHistory(MaxIt);

    for it = 1:MaxIt
        pm = params.pmMax - (params.pmMax - params.pmMin) * (it - 1) / max(1, MaxIt - 1);
        trial = repmat(empty, nPop, 1);
        for i = 1:nPop
            ids = randperm(nPop, 3);
            a = pop(ids(1)).Position;
            b = pop(ids(2)).Position;
            c = pop(ids(3)).Position;
            donor = permutationDifferentialDonor(a, b, c);
            if rand <= params.pc
                [y, ~] = orderCrossover(pop(i).Position, donor);
            else
                y = donor;
            end
            if rand <= pm
                y = mutatePermutation(y, problem, params);
            end
            trial(i).Position = y;
            trial(i) = evaluateIndividual(trial(i), problem);
        end
        combined = uniquePopulationByPosition([pop; trial]);
        [combined, F] = nonDominatedSorting(combined);
        combined = calcCrowdingDistance(combined, F);
        combined = sortPopulation(combined);
        pop = combined(1:min(nPop, numel(combined)));
        while numel(pop) < nPop
            ind = empty; ind.Position = randperm(problem.nGS); ind = evaluateIndividual(ind, problem);
            pop = [pop; ind]; %#ok<AGROW>
        end
        [pop, F] = nonDominatedSorting(pop);
        pop = calcCrowdingDistance(pop, F);
        archive = archiveByParams(archive, pop(F{1}), params);
        [bestSol, ~, ~] = selectCompromiseSolutionByTOPSIS(archive, params.topsisWeights);
        history = updateAlgorithmHistory(history, it, archive, bestSol, pm);
        if verbose && (it == 1 || mod(it, 20) == 0 || it == MaxIt)
            fprintf('MODE iteration %d / %d, Archive = %d, pm = %.4f\n', it, MaxIt, numel(archive), pm);
        end
    end
    result = finalizeAlgorithmResult(pop, archive, history, params);
end

function donor = permutationDifferentialDonor(a, b, c)
    n = numel(a);
    donor = a;
    posB = zeros(1, n); posC = zeros(1, n);
    for i = 1:n
        posB(b(i)) = i;
        posC(c(i)) = i;
    end
    for k = 1:n
        gene = a(k);
        if abs(posB(gene) - posC(gene)) > n/4 && rand < 0.5
            targetPos = max(1, min(n, round((posB(gene) + posC(gene))/2)));
            donor(donor == gene) = [];
            donor = [donor(1:targetPos-1), gene, donor(targetPos:end)];
        end
    end
end
