function result = runMOACO(problem, params, verbose)
% runMOACO
% MOACO-lite
% Multi-objective ant colony optimization baseline for the UAV monitoring
% permutation problem. This lite version uses distance-only visibility and
% does not use urgency, profit priority, or PEAR-MOEA risk-aware operators.

    if nargin < 3, verbose = true; end
    empty = algorithmEmptyIndividual();
    nPop = params.nPop;
    MaxIt = params.MaxIt;
    n = problem.nGS;
    tau = ones(n, n);
    rho = 0.20;
    alpha = 1.0;
    beta = 2.0;
    archive = [];
    pop = repmat(empty, nPop, 1);
    history = initAlgorithmHistory(MaxIt);

    eta = heuristicMatrix(problem);  % distance-only visibility

    for it = 1:MaxIt
        for a = 1:nPop
            perm = constructAntPermutation(tau, eta, alpha, beta, problem);
            ind = empty;
            ind.Position = perm;
            ind = evaluateIndividual(ind, problem);
            pop(a) = ind;
        end
        [pop, F] = nonDominatedSorting(pop);
        pop = calcCrowdingDistance(pop, F);
        archive = archiveByParams(archive, pop(F{1}), params);
        tau = (1 - rho) * tau + 1e-6;
        tau = depositPheromone(tau, archive, problem);
        [bestSol, ~, ~] = selectCompromiseSolutionByTOPSIS(archive, params.topsisWeights);
        history = updateAlgorithmHistory(history, it, archive, bestSol, 0);
        if verbose && (it == 1 || mod(it, 20) == 0 || it == MaxIt)
            fprintf('MOACO-lite iteration %d / %d, Archive = %d\n', it, MaxIt, numel(archive));
        end
    end
    result = finalizeAlgorithmResult(pop, archive, history, params);
end

function eta = heuristicMatrix(problem)
    n = problem.nGS;
    eta = zeros(n, n);
    for i = 1:n
        for j = 1:n
            if i == j
                eta(i, j) = 0;
            else
                d = norm(problem.coord(i, :) - problem.coord(j, :));
                eta(i, j) = 1 / (1 + d);
            end
        end
    end
    eta = eta + 1e-6;
end

function perm = constructAntPermutation(tau, eta, alpha, beta, problem)
    n = problem.nGS;
    remaining = 1:n;
    perm = zeros(1, n);
    first = randi(n);
    current = first;
    perm(1) = current;
    remaining(remaining == current) = [];
    for k = 2:n
        desir = (tau(current, remaining) .^ alpha) .* (eta(current, remaining) .^ beta);
        desir = desir / (sum(desir) + eps);
        idx = rouletteACO(desir);
        current = remaining(idx);
        perm(k) = current;
        remaining(idx) = [];
    end
end

function tau = depositPheromone(tau, archive, problem)
% Distance-only pheromone update for MOACO-lite.
% This intentionally avoids profit, urgency, risk, and PEAR-MOEA-specific
% priority information, keeping the baseline simple and fair.
    if isempty(archive), return; end
    nElite = min(numel(archive), 20);
    [~, order] = sort(arrayfun(@(x) sum(normalizedSingleCost(x.Cost, archive)), archive), 'ascend');
    for e = 1:nElite
        ind = archive(order(e));
        p = ind.Position;
        q = max(1e-6, 1 / (1 + ind.Metrics.totalDistance));
        for k = 1:numel(p)-1
            tau(p(k), p(k+1)) = tau(p(k), p(k+1)) + q;
            tau(p(k+1), p(k)) = tau(p(k+1), p(k)) + 0.5*q;
        end
    end
    tau = min(tau, 1e3);
end

function c = normalizedSingleCost(cost, archive)
    C = vertcat(archive.Cost);
    mn = min(C, [], 1);
    mx = max(C, [], 1);
    c = (cost - mn) ./ (mx - mn + eps);
end

function idx = rouletteACO(p)
    c = cumsum(p(:));
    r = rand * c(end);
    idx = find(c >= r, 1, 'first');
    if isempty(idx), idx = randi(numel(p)); end
end
