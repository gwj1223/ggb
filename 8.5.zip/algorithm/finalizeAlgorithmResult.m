function result = finalizeAlgorithmResult(pop, archive, history, params)
% finalizeAlgorithmResult
% Build the common result structure used by plotting/metrics functions.
    if nargin < 3 || isempty(history)
        history = struct();
    end
    if isempty(archive)
        [pop, F] = nonDominatedSorting(pop);
        if ~isempty(F) && ~isempty(F{1})
            archive = pop(F{1});
        else
            archive = pop;
        end
    end
    if isempty(archive)
        error('No solution found by the algorithm.');
    end
    [bestSol, bestIndex, closeness] = selectCompromiseSolutionByTOPSIS(archive, params.topsisWeights);
    result.pop = pop;
    result.archive = archive;
    result.bestSol = bestSol;
    result.bestIndex = bestIndex;
    result.topsisCloseness = closeness;
    result.history = history;
    result.params = params;
end
