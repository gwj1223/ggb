function selected = environmentalSelectionSPEA2(pop, nPop)
% environmentalSelectionSPEA2
% SPEA2-style environmental selection using strength raw fitness plus
% density estimation.

    n = numel(pop);
    costs = vertcat(pop.Cost);
    dom = false(n, n);
    for i = 1:n
        for j = 1:n
            if i ~= j
                dom(i, j) = all(costs(i, :) <= costs(j, :)) && any(costs(i, :) < costs(j, :));
            end
        end
    end
    strength = sum(dom, 2);
    raw = zeros(n, 1);
    for i = 1:n
        dominators = find(dom(:, i));
        raw(i) = sum(strength(dominators));
    end
    normCosts = normalizeCosts(costs);
    D = squareformDistance(normCosts);
    D(D == 0) = inf;
    k = max(1, round(sqrt(n)));
    sortedD = sort(D, 2, 'ascend');
    density = 1 ./ (sortedD(:, min(k, size(sortedD, 2))) + 2);
    fit = raw + density;
    [~, order] = sort(fit, 'ascend');
    selected = pop(order(1:min(nPop, n)));
end

function C = normalizeCosts(C)
    C = (C - min(C, [], 1)) ./ (max(C, [], 1) - min(C, [], 1) + eps);
end

function D = squareformDistance(C)
    n = size(C, 1);
    D = zeros(n, n);
    for i = 1:n
        dif = C - C(i, :);
        D(i, :) = sqrt(sum(dif.^2, 2));
    end
end
