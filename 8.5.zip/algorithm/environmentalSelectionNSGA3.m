function selected = environmentalSelectionNSGA3(pop, nPop, refDirs)
% environmentalSelectionNSGA3
% Lightweight NSGA-III-style environmental selection using reference
% directions for the splitting front.

    [pop, F] = nonDominatedSorting(pop);
    selected = [];
    k = 1;
    while k <= numel(F) && numel(selected) + numel(F{k}) <= nPop
        selected = [selected; pop(F{k})]; %#ok<AGROW>
        k = k + 1;
    end
    if numel(selected) < nPop && k <= numel(F)
        last = pop(F{k});
        nNeed = nPop - numel(selected);
        last = selectByReferenceDirections(last, nNeed, refDirs);
        selected = [selected; last];
    end
    if numel(selected) > nPop
        selected = selected(1:nPop);
    end
end

function chosen = selectByReferenceDirections(front, nNeed, refDirs)
    if numel(front) <= nNeed
        chosen = front;
        return;
    end
    costs = vertcat(front.Cost);
    costs = normalizeMinCosts(costs);
    norms = sqrt(sum(costs.^2, 2)) + eps;
    C = costs ./ norms;
    R = refDirs ./ (sqrt(sum(refDirs.^2, 2)) + eps);
    assoc = zeros(size(costs, 1), 1);
    dist = zeros(size(costs, 1), 1);
    for i = 1:size(costs, 1)
        dots = R * C(i, :)';
        dots = max(min(dots, 1), -1);
        d = sqrt(max(0, 1 - dots.^2)) .* norms(i);
        [dist(i), assoc(i)] = min(d);
    end
    chosenIdx = [];
    refCount = zeros(size(R, 1), 1);
    available = true(size(costs, 1), 1);
    while numel(chosenIdx) < nNeed && any(available)
        [~, refOrder] = sort(refCount, 'ascend');
        added = false;
        for rr = 1:numel(refOrder)
            r = refOrder(rr);
            cand = find(available & assoc == r);
            if ~isempty(cand)
                [~, bestLocal] = min(dist(cand));
                idx = cand(bestLocal);
                chosenIdx = [chosenIdx; idx]; %#ok<AGROW>
                available(idx) = false;
                refCount(r) = refCount(r) + 1;
                added = true;
                break;
            end
        end
        if ~added
            cand = find(available);
            [~, bestLocal] = min(sum(costs(cand, :), 2));
            idx = cand(bestLocal);
            chosenIdx = [chosenIdx; idx]; %#ok<AGROW>
            available(idx) = false;
        end
    end
    chosen = front(chosenIdx);
end

function C = normalizeMinCosts(C)
    mn = min(C, [], 1);
    mx = max(C, [], 1);
    C = (C - mn) ./ (mx - mn + eps);
end
