function pop = sortPopulation(pop)
% sortPopulation
% Sort by rank ascending and crowding distance descending.

    ranks = [pop.Rank]';
    cd = [pop.CrowdingDistance]';
    [~, order] = sortrows([ranks, -cd], [1, 2]);
    pop = pop(order);
end
