function pop = calcCrowdingDistance(pop, F)
% calcCrowdingDistance
% NSGA-II crowding distance.

    if isempty(pop) || isempty(F)
        return;
    end

    nObj = numel(pop(1).Cost);

    for k = 1:numel(F)
        front = F{k};
        if isempty(front)
            continue;
        end

        nF = numel(front);
        costs = vertcat(pop(front).Cost);
        d = zeros(nF, 1);

        for j = 1:nObj
            [sortedCost, order] = sort(costs(:, j));
            d(order(1)) = inf;
            d(order(end)) = inf;
            if nF <= 2
                continue;
            end
            denom = sortedCost(end) - sortedCost(1);
            if denom == 0
                continue;
            end
            for i = 2:nF-1
                d(order(i)) = d(order(i)) + (sortedCost(i+1) - sortedCost(i-1)) / denom;
            end
        end

        for i = 1:nF
            pop(front(i)).CrowdingDistance = d(i);
        end
    end
end
