function names = getComparisonAlgorithmNames()
% getComparisonAlgorithmNames
% Paper-level comparison set.
%
% The two heuristic baselines are intentionally simple and do not use the
% proposed PEAR-MOEA priority/risk-aware operators. This keeps the role of
% each baseline clear in the manuscript.
    names = {'NN-Greedy', 'Random-Greedy', 'NSGA-II', 'NSGA-III', ...
             'MOEA/D', 'SPEA2', 'MOPSO', 'MODE', 'MOACO-lite', ...
             'PEAR-MOEA'};
end
