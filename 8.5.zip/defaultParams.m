function params = defaultParams()
% defaultParams
% Default parameters for the UAV geohazard monitoring PEAR-MOEA project.

    % Problem data
    params.nGS = 50;
    params.mapSize = 100;
    params.depot = [50, 50];
    params.dataMode = 'cluster';       % 'uniform' or 'cluster'
    params.nCluster = 4;
    params.clusterStd = 12;
    params.seed = 1;

    % UAV and mission parameters
    params.Lmax = 160;                 % km, maximum distance per trip
    params.speed = 50;                 % km/h
    params.rechargeTime = 0.5;         % h, after each trip except the last
    params.serviceTime = 0.02;         % h per GS

    % Urgency-profit decay
    params.decayType = 'exponential';  % exponential / linear / reciprocal
    params.beta = 0.80;
    params.lambda = 0.15;

    % Risk indicators
    params.highRiskRatio = 0.20;       % top 20% urgent sites are high risk
    params.earlyTripRatio = 0.30;      % first 30% trips are early trips

    % Energy model coefficients
    params.energyDistanceCoef = 1.0;
    params.energyServiceCoef = 10.0;
    params.energyTripCoef = 2.0;

    % Algorithm parameters
    params.nPop = 100;
    params.MaxIt = 200;
    params.pc = 0.90;
    params.pm = 0.25;
    params.useAdaptiveMutation = true;
    params.pmMax = 0.35;
    params.pmMin = 0.08;

    % Local search
    params.useTwoOpt = true;
    params.useAdaptiveLocalSearch = false;
    params.pLocalSearch = 0.20;
    params.pLSMin = 0.10;
    params.pLSMax = 0.40;

    % PEAR-MOEA operator switches
    % Optimized default from ablation: priority initialization is disabled
    % because spatial initialization preserves route compactness better on this instance.
    params.usePriorityInit = false;
    params.useSpatialInit = true;
    params.alphaPriority = 0.75;
    % Disabled by default after the final ablation: the priority mutation
    % showed only marginal effect once risk relocation and trip compression
    % are enabled.
    params.usePriorityRelocate = false;

    % Urgency-aware inter-trip relocation
    params.useInterTripRelocation = true;
    params.pInterTripRelocation = 0.25;
    params.interTripMaxTrial = 20;

    % Trip compression repair (PEAR-MOEA only)
    % Tries to merge short trips into other feasible trips to reduce the
    % number of UAV sorties, total distance, energy, and mission time.
    params.useTripCompression = true;
    params.pTripCompression = 0.35;
    params.tripCompressionMaxPass = 3;

    % Lightweight energy/risk-aware insertion repair.
    % It relocates individual nodes across feasible trips only when a
    % compactness score improves. This is a small local intensification
    % step and is used by PEAR-MOEA only.
    params.useInsertionRepair = true;
    params.pInsertionRepair = 0.20;
    params.insertionRepairMaxMove = 3;

    % Archive
    % Optimized default from ablation: use the ordinary archive by default;
    % epsilon-grid archive remains available as an ablation/comparison option.
    params.maxArchiveSize = 100;
    params.useEpsGridArchive = false;
    params.epsGrid = 0.03;

    % Objective mode
    % 'energy': Cost = [-profit, distance, energy, maxUtil] (default PEAR-MOEA)
    % 'time':   Cost = [-profit, distance, time,   maxUtil] (objective ablation only)
    params.objectiveMode = 'energy';

    % TOPSIS compromise solution weights
    % Cost vector is [-profit, distance, energy/time, maxUtil], all minimized.
    % UAV-oriented weights give higher priority to profit and energy efficiency.
    params.topsisWeights = [0.45, 0.25, 0.25, 0.05];

    % Normalized HV Monte Carlo samples
    params.hvSamples = 50000;

    % Constraint penalty
    params.penaltyCoef = 1e6;
end
