# PEAR-MOEA ablation study update

This update adds a 30-run ablation experiment for the PEAR-MOEA framework.

## Main script

Run:

```matlab
run('examples/ablation_experiment.m')
```

## Ablation variants

1. Full PEAR-MOEA (optimized default)
2. w/o Spatial Init
3. w/o Priority Mutation
4. w/o 2-opt
5. w/o Risk Relocation
6. w/o Trip Compression
7. with Priority Init
8. with Eps-Grid Archive
9. Plain NSGA-II Backbone
10. w/o Energy Objective

## Output files

The script writes:

- `results/ablation_PEAR_MOEA.mat`
- `results/ablation_summary_PEAR_MOEA.csv`
- `results/ablation_improvement_PEAR_MOEA.csv`
- `results/ablation_runs_<variant>.csv`

## Objective-mode note

The default objective vector is:

```matlab
[-Profit, Distance, Energy, MaxUtil]
```

The `w/o Energy Objective` variant uses:

```matlab
[-Profit, Distance, Time, MaxUtil]
```

Because its third objective is different, its NormHV is not directly comparable to the energy-objective variants and is reported as `NaN` in the ablation summary.


## Post-ablation optimization

The new **Full PEAR-MOEA** uses the ablation-guided optimized configuration:

```matlab
usePriorityInit    = false;
useSpatialInit     = true;
usePriorityRelocate = true;
useTwoOpt          = true;
useInterTripRelocation = true;
useTripCompression = true;
useEpsGridArchive  = false;
```

Priority initialization and epsilon-grid archive are now tested as optional add-on variants (`with Priority Init` and `with Eps-Grid Archive`) instead of being part of the default full method.
