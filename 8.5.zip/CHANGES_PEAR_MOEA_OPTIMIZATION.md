# PEAR-MOEA optimization update

This update implements the requested optimization changes.

## 1. TOPSIS weight update

The compromise-solution weights were changed from the previous setting to:

```matlab
params.topsisWeights = [0.45, 0.25, 0.25, 0.05];
```

for the objective vector:

```matlab
Cost = [-Profit, Distance, Energy, MaxUtil];
```

This makes the final selected solution less conservative with respect to maximum range utilization and gives more emphasis to profit, distance, and energy.

## 2. Trip-compression repair

A new PEAR-MOEA-only repair operator was added:

```text
local_search/tripCompressionRepair.m
```

It attempts to move nodes from short trips into other trips while preserving the UAV range constraint. The goal is to reduce:

- number of trips,
- total distance,
- mission time,
- energy consumption,
- late profit loss.

New parameters in `defaultParams.m`:

```matlab
params.useTripCompression = true;
params.pTripCompression = 0.30;
params.tripCompressionMaxPass = 2;
```

## 3. Fairer baseline settings

All comparison baselines now explicitly disable PEAR-MOEA-specific mechanisms through `configureBaselineParams` in:

```text
algorithm/runComparator.m
```

Disabled for baselines:

- priority-guided initialization,
- spatial initialization,
- priority relocation mutation,
- 2-opt local search,
- risk-aware inter-trip relocation,
- trip-compression repair.

## 4. MOACO-lite weakening

`algorithm/runMOACO.m` was updated so pheromone deposition is based only on distance. It no longer uses profit, urgency, risk, or priority information in the pheromone update.

## Recommended next run

```matlab
run('examples/compare_algorithms.m')
run('examples/batch_runs.m')
```

Use the single comparison first to verify the ranking, then use 30 independent runs for paper-level tables.
