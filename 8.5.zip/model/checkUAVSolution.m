function report = checkUAVSolution(ind, problem)
% checkUAVSolution
% Print and return feasibility report.

    trips = ind.Trips;
    if isempty(trips)
        report.isFeasible = false;
        fprintf('No valid trips.\n');
        return;
    end

    allVisited = [trips{:}];
    nVisited = numel(allVisited);
    nUnique = numel(unique(allVisited));
    missingNodes = setdiff(1:problem.nGS, allVisited);
    duplicateNodes = [];
    for i = 1:problem.nGS
        if sum(allVisited == i) > 1
            duplicateNodes = [duplicateNodes, i]; %#ok<AGROW>
        end
    end

    exceedTrips = [];
    for k = 1:numel(trips)
        d = calcTripDistance(trips{k}, problem.distMat);
        if d > problem.Lmax + 1e-9
            exceedTrips = [exceedTrips, k]; %#ok<AGROW>
        end
    end

    report.nVisited = nVisited;
    report.nUnique = nUnique;
    report.missingNodes = missingNodes;
    report.duplicateNodes = duplicateNodes;
    report.exceedTrips = exceedTrips;
    report.isFeasible = isempty(missingNodes) && isempty(duplicateNodes) && isempty(exceedTrips) && ...
                        nVisited == problem.nGS && nUnique == problem.nGS;

    fprintf('\n========== Feasibility Check ==========\n');
    fprintf('Visited nodes        = %d\n', nVisited);
    fprintf('Unique visited nodes = %d\n', nUnique);
    if isempty(missingNodes)
        fprintf('Missing nodes        = none\n');
    else
        fprintf('Missing nodes        = '); fprintf('%d ', missingNodes); fprintf('\n');
    end
    if isempty(duplicateNodes)
        fprintf('Duplicate nodes      = none\n');
    else
        fprintf('Duplicate nodes      = '); fprintf('%d ', duplicateNodes); fprintf('\n');
    end
    if isempty(exceedTrips)
        fprintf('Trips over Lmax      = none\n');
    else
        fprintf('Trips over Lmax      = '); fprintf('%d ', exceedTrips); fprintf('\n');
    end
    fprintf('Max range utilization= %.2f%%\n', 100 * ind.Metrics.maxRangeUtilization);
    fprintf('Mission time         = %.4f h\n', ind.Metrics.totalMissionTime);

    if report.isFeasible
        fprintf('Result              = feasible\n');
    else
        fprintf('Result              = infeasible\n');
    end
end
