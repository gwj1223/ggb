function [trips, metrics] = decodeTrips(perm, problem)
% decodeTrips
% Greedy split decoding from a permutation to feasible UAV trips.

    Lmax = problem.Lmax;
    distMat = problem.distMat;
    urgency = problem.urgency;

    trips = {};
    currentTrip = [];

    for i = 1:numel(perm)
        node = perm(i);
        if isempty(currentTrip)
            currentTrip = node;
        else
            candidateTrip = [currentTrip, node];
            candidateDistance = calcTripDistance(candidateTrip, distMat);
            if candidateDistance <= Lmax
                currentTrip = candidateTrip;
            else
                trips{end+1} = currentTrip; %#ok<AGROW>
                currentTrip = node;
            end
        end
    end

    if ~isempty(currentTrip)
        trips{end+1} = currentTrip;
    end

    nTrips = numel(trips);
    totalDistance = 0;
    totalProfit = 0;
    violation = 0;

    tripDistance = zeros(nTrips, 1);
    tripProfit = zeros(nTrips, 1);
    nodeTripIndex = zeros(problem.nGS, 1);

    for k = 1:nTrips
        trip = trips{k};
        d = calcTripDistance(trip, distMat);
        p = sum(decayProfit(urgency(trip), k, problem));

        tripDistance(k) = d;
        tripProfit(k) = p;
        totalDistance = totalDistance + d;
        totalProfit = totalProfit + p;
        violation = violation + max(0, d - Lmax);
        nodeTripIndex(trip) = k;
    end

    totalFlightTime = totalDistance / problem.speed;
    totalRechargeTime = max(0, nTrips - 1) * problem.rechargeTime;
    totalServiceTime = problem.nGS * problem.serviceTime;
    totalMissionTime = totalFlightTime + totalRechargeTime + totalServiceTime;

    maxTripDistance = max(tripDistance);
    maxRangeUtilization = maxTripDistance / problem.Lmax;
    tripDistanceStd = std(tripDistance);
    tripDistanceCV = tripDistanceStd / (mean(tripDistance) + eps);

    totalEnergy = problem.energyDistanceCoef * totalDistance + ...
                  problem.energyServiceCoef * totalServiceTime + ...
                  problem.energyTripCoef * nTrips;

    highRiskRatio = problem.highRiskRatio;
    nHigh = max(1, ceil(highRiskRatio * problem.nGS));
    [~, urgencyOrder] = sort(problem.urgency, 'descend');
    highRiskNodes = urgencyOrder(1:nHigh);
    highRiskTripIndex = nodeTripIndex(highRiskNodes);

    earlyCutoff = max(1, ceil(problem.earlyTripRatio * nTrips));
    highRiskEarlyCount = sum(highRiskTripIndex <= earlyCutoff);
    highRiskEarlyRate = highRiskEarlyCount / nHigh;

    metrics.totalDistance = totalDistance;
    metrics.totalProfit = totalProfit;
    metrics.nTrips = nTrips;
    metrics.violation = violation;
    metrics.tripDistance = tripDistance;
    metrics.tripProfit = tripProfit;
    metrics.nodeTripIndex = nodeTripIndex;

    metrics.totalFlightTime = totalFlightTime;
    metrics.totalRechargeTime = totalRechargeTime;
    metrics.totalServiceTime = totalServiceTime;
    metrics.totalMissionTime = totalMissionTime;

    metrics.maxTripDistance = maxTripDistance;
    metrics.maxRangeUtilization = maxRangeUtilization;
    metrics.tripDistanceStd = tripDistanceStd;
    metrics.tripDistanceCV = tripDistanceCV;
    metrics.totalEnergy = totalEnergy;

    metrics.highRiskNodes = highRiskNodes;
    metrics.highRiskEarlyCount = highRiskEarlyCount;
    metrics.highRiskTotal = nHigh;
    metrics.highRiskEarlyRate = highRiskEarlyRate;
    metrics.highRiskAvgTrip = mean(highRiskTripIndex);
    metrics.highRiskMaxTrip = max(highRiskTripIndex);
end
