function p = decayProfit(urgencyValue, tripIndex, problem)
% decayProfit
% Urgency profit decay by trip index.

    k = tripIndex;
    u = urgencyValue;

    switch lower(problem.decayType)
        case 'exponential'
            factor = problem.beta^(k - 1);
        case 'linear'
            factor = max(0, 1 - problem.lambda * (k - 1));
        case 'reciprocal'
            factor = 1 / (1 + problem.lambda * (k - 1));
        otherwise
            error('Unknown decay type: %s', problem.decayType);
    end

    p = u .* factor;
end
