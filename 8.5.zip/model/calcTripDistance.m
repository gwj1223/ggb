function d = calcTripDistance(trip, distMat)
% calcTripDistance
% Distance of route 0 -> i1 -> ... -> im -> 0.
% Depot index is 1 in distMat, GS i is i+1.

    if isempty(trip)
        d = 0;
        return;
    end

    d = distMat(1, trip(1) + 1);
    for i = 1:numel(trip)-1
        d = d + distMat(trip(i) + 1, trip(i+1) + 1);
    end
    d = d + distMat(trip(end) + 1, 1);
end
