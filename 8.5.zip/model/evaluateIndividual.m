function ind = evaluateIndividual(ind, problem)
% evaluateIndividual
% Evaluate a permutation-coded individual.
% Cost vector is minimized. Default PEAR-MOEA objective mode:
%   [-profit, distance, energy, max utilization]
% Optional ablation mode:
%   [-profit, distance, time, max utilization]

    perm = ind.Position;
    nGS = problem.nGS;

    if numel(perm) ~= nGS || any(perm < 1) || any(perm > nGS) || numel(unique(perm)) ~= nGS
        penalty = problem.penaltyCoef * 100;
        ind.Cost = [penalty, penalty, penalty, penalty];
        ind.Trips = {};
        ind.Metrics = emptyMetrics();
        ind.Metrics.violation = penalty;
        return;
    end

    [trips, metrics] = decodeTrips(perm, problem);

    f1 = -metrics.totalProfit;
    f2 = metrics.totalDistance;
    objectiveMode = 'energy';
    if isfield(problem, 'objectiveMode')
        objectiveMode = lower(problem.objectiveMode);
    end

    switch objectiveMode
        case 'time'
            f3 = metrics.totalMissionTime;
        otherwise
            f3 = metrics.totalEnergy;
    end
    f4 = metrics.maxRangeUtilization;

    penalty = problem.penaltyCoef * metrics.violation;
    ind.Cost = [f1 + penalty, f2 + penalty, f3 + penalty, f4 + penalty];
    ind.Trips = trips;
    ind.Metrics = metrics;
end

function m = emptyMetrics()
    m.totalProfit = 0;
    m.totalDistance = inf;
    m.totalMissionTime = inf;
    m.totalEnergy = inf;
    m.maxRangeUtilization = inf;
    m.nTrips = inf;
    m.violation = inf;
end
