function problem = createUAVProblem(params)
% createUAVProblem
% Build the problem structure for multi-trip UAV geohazard monitoring.

    if isfield(params, 'seed') && ~isempty(params.seed)
        rng(params.seed);
    end

    nGS = getField(params, 'nGS', 50);
    mapSize = getField(params, 'mapSize', 100);
    depot = getField(params, 'depot', [mapSize/2, mapSize/2]);

    if isfield(params, 'coord')
        coord = params.coord;
        nGS = size(coord, 1);
    else
        dataMode = getField(params, 'dataMode', 'cluster');
        switch lower(dataMode)
            case 'cluster'
                nCluster = getField(params, 'nCluster', 4);
                clusterStd = getField(params, 'clusterStd', 12);
                centers = mapSize * rand(nCluster, 2);
                coord = zeros(nGS, 2);
                for i = 1:nGS
                    c = randi(nCluster);
                    coord(i, :) = centers(c, :) + clusterStd * randn(1, 2);
                end
                coord = max(coord, 0);
                coord = min(coord, mapSize);
            otherwise
                coord = mapSize * rand(nGS, 2);
        end
    end

    if isfield(params, 'urgency')
        urgency = params.urgency(:);
    else
        urgency = 1 + 9 * rand(nGS, 1);
    end

    points = [depot; coord];
    dx = points(:, 1) - points(:, 1)';
    dy = points(:, 2) - points(:, 2)';
    distMat = sqrt(dx.^2 + dy.^2);

    Lmax = getField(params, 'Lmax', 160);
    d0 = distMat(1, 2:end)';
    singleTripDistance = 2 * d0;
    infeasibleNode = find(singleTripDistance > Lmax);
    if ~isempty(infeasibleNode)
        warning('Some nodes cannot be visited even by a single round trip. Increase Lmax or adjust data.');
    end

    problem.nGS = nGS;
    problem.mapSize = mapSize;
    problem.depot = depot;
    problem.coord = coord;
    problem.points = points;
    problem.urgency = urgency;
    problem.distMat = distMat;

    problem.Lmax = Lmax;
    problem.speed = getField(params, 'speed', 50);
    problem.rechargeTime = getField(params, 'rechargeTime', 0.5);
    problem.serviceTime = getField(params, 'serviceTime', 0.02);

    problem.decayType = getField(params, 'decayType', 'exponential');
    problem.beta = getField(params, 'beta', 0.8);
    problem.lambda = getField(params, 'lambda', 0.15);

    problem.highRiskRatio = getField(params, 'highRiskRatio', 0.20);
    problem.earlyTripRatio = getField(params, 'earlyTripRatio', 0.30);

    problem.energyDistanceCoef = getField(params, 'energyDistanceCoef', 1.0);
    problem.energyServiceCoef = getField(params, 'energyServiceCoef', 10.0);
    problem.energyTripCoef = getField(params, 'energyTripCoef', 2.0);

    problem.penaltyCoef = getField(params, 'penaltyCoef', 1e6);
    problem.objectiveMode = getField(params, 'objectiveMode', 'energy');
    problem.singleTripDistance = singleTripDistance;
    problem.infeasibleNode = infeasibleNode;
end

function value = getField(s, fieldName, defaultValue)
    if isfield(s, fieldName)
        value = s.(fieldName);
    else
        value = defaultValue;
    end
end
