# PEAR-MOEA comparison update

The proposed algorithm is named **PEAR-MOEA**:

**Priority-guided Energy-aware and Risk-aware Multi-Objective Evolutionary Algorithm**

The optimized objective vector is:

```matlab
Cost = [-Profit, Distance, Energy, MaxUtil]
```

All objectives are minimized. Mission time is retained as an evaluation metric.

## Paper-level comparison algorithms

The current comparison set contains 10 algorithms:

1. `NN-Greedy`
2. `Random-Greedy`
3. `NSGA-II`
4. `NSGA-III`
5. `MOEA/D`
6. `SPEA2`
7. `MOPSO`
8. `MODE`
9. `MOACO-lite`
10. `PEAR-MOEA`

## Fair baseline rule

The selected baselines share the same problem model, route decoder, objective function, and evaluation metrics. They do **not** use PEAR-MOEA-specific modules such as priority-guided initialization, priority relocation mutation, risk-aware inter-trip relocation, or 2-opt local search.

- `NN-Greedy` is a distance-only nearest-neighbor route construction baseline.
- `Random-Greedy` is a random permutation construction baseline.
- `MOACO-lite` uses distance-only visibility and random initial ant positions.

## How to run

Single-run comparison:

```matlab
run('examples/compare_algorithms.m')
```

30-run comparison:

```matlab
run('examples/batch_runs.m')
```
