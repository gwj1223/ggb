# Baseline selection update

This update revises the paper-level comparison algorithms so that the baseline methods do not reuse the core PEAR-MOEA mechanisms.

## Updated comparison set

The 10 algorithms are now:

1. `NN-Greedy`
2. `Random-Greedy`
3. `NSGA-II`
4. `NSGA-III`
5. `MOEA/D`
6. `SPEA2`
7. `MOPSO`
8. `MODE`
9. `MOACO-lite`
10. `PEAR-MOEA`

## Rationale

The previous `Greedy` baseline used urgency/priority information and generated a multi-solution archive, making it too close to the proposed idea. It has been replaced by two simpler baselines:

- `NN-Greedy`: distance-only nearest-neighbor construction under the UAV range constraint.
- `Random-Greedy`: random permutation construction, decoded by the same UAV trip decoder.

`MOACO` has been renamed to `MOACO-lite`. Its visibility heuristic is now distance-only and its initial ant node is random. It does not use urgency, profit priority, high-risk relocation, 2-opt local search, or PEAR-MOEA repair mechanisms.

## Files changed

- `algorithm/getComparisonAlgorithmNames.m`
- `algorithm/runComparator.m`
- `algorithm/runGreedyBaseline.m`
- `algorithm/runMOACO.m`
- `examples/compare_algorithms.m`
- `examples/batch_runs.m`
- `README.md`

## How to run

Single-run comparison:

```matlab
run('examples/compare_algorithms.m')
```

30-run statistical comparison:

```matlab
run('examples/batch_runs.m')
```
