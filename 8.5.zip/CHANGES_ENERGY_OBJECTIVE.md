# Energy-objective update

This update changes the optimized four-objective cost vector from:

```matlab
[-Profit, Distance, Time, MaxUtil]
```

to:

```matlab
[-Profit, Distance, Energy, MaxUtil]
```

## Modified files

- `model/evaluateIndividual.m`
  - The third objective is now `metrics.totalEnergy` instead of `metrics.totalMissionTime`.
  - The file header comment was updated.

- `defaultParams.m`
  - TOPSIS comment now matches `[-Profit, Distance, Energy, MaxUtil]`.

- `main.m`
  - Objective description updated.

- `plotting/plotParetoFront.m`
  - Pareto visualization now uses Distance-Energy-Profit, with MaxUtil as color.

- `algorithm/runPNSGA2.m`
  - Added `history.bestEnergy` while keeping `history.bestTime` as a reported metric.

- `plotting/plotConvergence.m`
  - Added Energy convergence plot when available.

- `examples/batch_runs.m`
  - Batch output filename changed to `results/batch_results_energy_normhv.mat`.

- `README.md`
  - Documentation updated to reflect the new objective vector.

## Notes

`Time` is still calculated in `decodeTrips.m`, printed in solution summaries, and saved in batch statistics. It is now a reported metric rather than a directly optimized objective.
