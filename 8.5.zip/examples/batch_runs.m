%% batch_runs.m
% 30 independent runs for all comparison algorithms.
%
% Algorithms:
% NN-Greedy, Random-Greedy, NSGA-II, NSGA-III, MOEA/D, SPEA2,
% MOPSO, MODE, MOACO-lite, PEAR-MOEA.
%
% NormHV is computed after all runs using one global normalization box from
% all archives of all algorithms. NormHV is divided by the reference-box
% volume, so it is bounded in [0, 1].

clear; clc; close all;
addpath(genpath(fileparts(fileparts(mfilename('fullpath')))));
cd(fileparts(fileparts(mfilename('fullpath'))));

baseParams = defaultParams();
baseParams.seed = 1;
problem = createUAVProblem(baseParams);

nRun = 30;
algorithms = getComparisonAlgorithmNames();
nAlg = numel(algorithms);

Rows = cell(nAlg, 1);
Archives = cell(nAlg, nRun);
for a = 1:nAlg
    Rows{a} = repmat(emptyRow(), nRun, 1);
end

fprintf('\n================ PEAR-MOEA paper comparison: %d algorithms x %d runs ================\n', nAlg, nRun);
for a = 1:nAlg
    alg = algorithms{a};
    fprintf('\n================ %s: %d independent runs ================\n', alg, nRun);
    for r = 1:nRun
        params = baseParams;
        rng(100000 * a + r);
        result = runComparator(alg, problem, params, false);
        row = extractResultMetrics(result);
        Rows{a}(r) = row;
        Archives{a, r} = result.archive;
        fprintf('%-14s Run %02d/%02d | Profit %.2f | Distance %.2f | Energy %.2f | Time %.2f | Trips %d | EarlyRate %.2f%% | AvgHighTrip %.2f | Archive %d\n', ...
            alg, r, nRun, row.Profit, row.Distance, row.Energy, row.Time, row.Trips, 100*row.EarlyRate, row.HighRiskAvgTrip, row.ArchiveSize);
    end
end

%% Normalized HV with global bounds
allCosts = [];
for a = 1:nAlg
    for r = 1:nRun
        if ~isempty(Archives{a, r})
            allCosts = [allCosts; vertcat(Archives{a, r}.Cost)]; %#ok<AGROW>
        end
    end
end

globalMinCost = min(allCosts, [], 1);
globalMaxCost = max(allCosts, [], 1);
refPointNorm = 1.1 * ones(1, size(allCosts, 2));
hvSamples = getParam(baseParams, 'hvSamples', 50000);

fprintf('\n================ Normalized HV calculation ================\n');
fprintf('Global min cost: '); fprintf('%.4f ', globalMinCost); fprintf('\n');
fprintf('Global max cost: '); fprintf('%.4f ', globalMaxCost); fprintf('\n');
fprintf('Reference point in normalized space: '); fprintf('%.2f ', refPointNorm); fprintf('\n');
fprintf('Reference-box volume: %.4f\n', prod(refPointNorm));
fprintf('Note: NormHV is divided by the reference-box volume and is bounded in [0, 1].\n');

for a = 1:nAlg
    for r = 1:nRun
        if ~isempty(Archives{a, r})
            Rows{a}(r).NormHV = calcNormalizedHV(vertcat(Archives{a, r}.Cost), globalMinCost, globalMaxCost, refPointNorm, hvSamples);
        end
    end
end

fprintf('\n================ Statistical Summary: mean ± std ================\n');
for a = 1:nAlg
    printStats(algorithms{a}, Rows{a});
end

idxProposed = find(strcmpi(algorithms, 'PEAR-MOEA'), 1);
comparisonSummary = buildAllComparisonSummary(algorithms, Rows, idxProposed);

fprintf('\n================ Improvements of PEAR-MOEA over each baseline ================\n');
printImprovementTable(comparisonSummary);

if ~exist('results', 'dir')
    mkdir('results');
end
save(fullfile('results', 'batch_all_algorithms_PEAR_MOEA.mat'), ...
    'algorithms', 'Rows', 'Archives', 'globalMinCost', 'globalMaxCost', 'refPointNorm', 'hvSamples', 'comparisonSummary');
writeSummaryCSV(fullfile('results', 'batch_all_algorithms_summary_PEAR_MOEA.csv'), algorithms, Rows);
writeImprovementCSV(fullfile('results', 'batch_all_algorithms_improvement_PEAR_MOEA.csv'), comparisonSummary);
for a = 1:nAlg
    safeName = regexprep(algorithms{a}, '[^A-Za-z0-9]', '_');
    writeRunsCSV(fullfile('results', sprintf('batch_runs_%s.csv', safeName)), Rows{a});
end
fprintf('\nMAT results saved to: %s\n', fullfile(pwd, 'results', 'batch_all_algorithms_PEAR_MOEA.mat'));
fprintf('CSV summary saved to: %s\n', fullfile(pwd, 'results', 'batch_all_algorithms_summary_PEAR_MOEA.csv'));
fprintf('CSV improvement table saved to: %s\n', fullfile(pwd, 'results', 'batch_all_algorithms_improvement_PEAR_MOEA.csv'));

function row = emptyRow()
    row.Profit = 0;
    row.Distance = 0;
    row.Time = 0;
    row.MaxUtil = 0;
    row.Trips = 0;
    row.Energy = 0;
    row.EarlyRate = 0;
    row.HighRiskAvgTrip = 0;
    row.HighRiskMaxTrip = 0;
    row.Spacing = 0;
    row.NormHV = 0;
    row.ArchiveSize = 0;
end

function printStats(name, R)
    fprintf('%-14s | Profit %8.3f ± %-7.3f | Distance %8.3f ± %-7.3f | Time %7.3f ± %-6.3f | Energy %8.3f ± %-7.3f | MaxUtil %.4f ± %.4f | Trips %.2f ± %.2f | EarlyRate %6.2f ± %-6.2f | AvgHighTrip %.2f ± %.2f | MaxHighTrip %.2f ± %.2f | Spacing %.4f ± %.4f | NormHV %.4f ± %.4f | Archive %.2f ± %.2f\n', ...
        name, mean([R.Profit]), std([R.Profit]), mean([R.Distance]), std([R.Distance]), ...
        mean([R.Time]), std([R.Time]), mean([R.Energy]), std([R.Energy]), mean([R.MaxUtil]), std([R.MaxUtil]), ...
        mean([R.Trips]), std([R.Trips]), 100*mean([R.EarlyRate]), 100*std([R.EarlyRate]), ...
        mean([R.HighRiskAvgTrip]), std([R.HighRiskAvgTrip]), mean([R.HighRiskMaxTrip]), std([R.HighRiskMaxTrip]), ...
        mean([R.Spacing]), std([R.Spacing]), mean([R.NormHV]), std([R.NormHV]), mean([R.ArchiveSize]), std([R.ArchiveSize]));
end

function S = buildAllComparisonSummary(algorithms, Rows, idxProposed)
    fields = getMetricFields();
    P = Rows{idxProposed};
    k = 0;
    for a = 1:numel(algorithms)
        if a == idxProposed
            continue;
        end
        B = Rows{a};
        for i = 1:size(fields, 1)
            k = k + 1;
            name = fields{i, 1};
            higherBetter = fields{i, 2};
            pVals = [P.(name)];
            bVals = [B.(name)];
            S(k).Baseline = algorithms{a}; %#ok<AGROW>
            S(k).Metric = name;
            S(k).HigherBetter = higherBetter;
            S(k).PEAR_Mean = mean(pVals);
            S(k).PEAR_Std = std(pVals);
            S(k).Base_Mean = mean(bVals);
            S(k).Base_Std = std(bVals);
            if higherBetter
                S(k).ImprovementPercent = 100 * (S(k).PEAR_Mean - S(k).Base_Mean) / max(abs(S(k).Base_Mean), eps);
                S(k).PEAR_Wins = sum(pVals > bVals);
                S(k).Ties = sum(pVals == bVals);
            else
                S(k).ImprovementPercent = 100 * (S(k).Base_Mean - S(k).PEAR_Mean) / max(abs(S(k).Base_Mean), eps);
                S(k).PEAR_Wins = sum(pVals < bVals);
                S(k).Ties = sum(pVals == bVals);
            end
            try
                S(k).WilcoxonP = signrank(pVals, bVals);
            catch
                S(k).WilcoxonP = NaN;
            end
        end
    end
end

function printImprovementTable(S)
    for i = 1:numel(S)
        if strcmp(S(i).Metric, 'Profit') || strcmp(S(i).Metric, 'Energy') || strcmp(S(i).Metric, 'NormHV') || strcmp(S(i).Metric, 'Trips')
            fprintf('vs %-14s | %-14s | Improvement %+8.2f%% | PEAR wins %2d/30 | p = %.3g\n', ...
                S(i).Baseline, S(i).Metric, S(i).ImprovementPercent, S(i).PEAR_Wins, S(i).WilcoxonP);
        end
    end
end

function fields = getMetricFields()
    fields = {
        'Profit', true;
        'Distance', false;
        'Time', false;
        'Energy', false;
        'Trips', false;
        'MaxUtil', false;
        'EarlyRate', true;
        'HighRiskAvgTrip', false;
        'HighRiskMaxTrip', false;
        'NormHV', true;
        'Spacing', false;
        'ArchiveSize', true
    };
end

function writeSummaryCSV(filename, algorithms, Rows)
    fid = fopen(filename, 'w');
    if fid < 0, warning('Could not write %s', filename); return; end
    fprintf(fid, 'Algorithm,Metric,Mean,Std\n');
    fields = getMetricFields();
    for a = 1:numel(algorithms)
        R = Rows{a};
        for i = 1:size(fields, 1)
            name = fields{i, 1};
            vals = [R.(name)];
            fprintf(fid, '%s,%s,%.10g,%.10g\n', algorithms{a}, name, mean(vals), std(vals));
        end
    end
    fclose(fid);
end

function writeImprovementCSV(filename, S)
    fid = fopen(filename, 'w');
    if fid < 0, warning('Could not write %s', filename); return; end
    fprintf(fid, 'Baseline,Metric,HigherBetter,PEAR_Mean,PEAR_Std,Base_Mean,Base_Std,ImprovementPercent,PEAR_Wins,Ties,WilcoxonP\n');
    for i = 1:numel(S)
        fprintf(fid, '%s,%s,%d,%.10g,%.10g,%.10g,%.10g,%.10g,%d,%d,%.10g\n', ...
            S(i).Baseline, S(i).Metric, S(i).HigherBetter, S(i).PEAR_Mean, S(i).PEAR_Std, ...
            S(i).Base_Mean, S(i).Base_Std, S(i).ImprovementPercent, S(i).PEAR_Wins, S(i).Ties, S(i).WilcoxonP);
    end
    fclose(fid);
end

function writeRunsCSV(filename, R)
    fid = fopen(filename, 'w');
    if fid < 0, warning('Could not write %s', filename); return; end
    fprintf(fid, 'Run,Profit,Distance,Time,Energy,MaxUtil,Trips,EarlyRate,HighRiskAvgTrip,HighRiskMaxTrip,Spacing,NormHV,ArchiveSize\n');
    for i = 1:numel(R)
        fprintf(fid, '%d,%.10g,%.10g,%.10g,%.10g,%.10g,%d,%.10g,%.10g,%.10g,%.10g,%.10g,%d\n', ...
            i, R(i).Profit, R(i).Distance, R(i).Time, R(i).Energy, R(i).MaxUtil, R(i).Trips, ...
            R(i).EarlyRate, R(i).HighRiskAvgTrip, R(i).HighRiskMaxTrip, R(i).Spacing, R(i).NormHV, R(i).ArchiveSize);
    end
    fclose(fid);
end

function value = getParam(s, fieldName, defaultValue)
    if isfield(s, fieldName)
        value = s.(fieldName);
    else
        value = defaultValue;
    end
end
