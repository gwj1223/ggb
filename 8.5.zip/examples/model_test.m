%% model_test.m
% Test model layer.
clear; clc; close all;
addpath(genpath(fileparts(fileparts(mfilename('fullpath')))));
cd(fileparts(fileparts(mfilename('fullpath'))));

params = defaultParams();
problem = createUAVProblem(params);

ind.Position = randperm(problem.nGS);
ind = evaluateIndividual(ind, problem);
printSolution(ind, problem, 'Random Individual Model Test');
checkUAVSolution(ind, problem);
