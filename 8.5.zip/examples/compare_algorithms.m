%% compare_algorithms.m
% One independent run for all paper-level comparison algorithms.
%
% Algorithms:
% NN-Greedy, Random-Greedy, NSGA-II, NSGA-III, MOEA/D, SPEA2,
% MOPSO, MODE, MOACO-lite, PEAR-MOEA.
%
% NormHV is computed using common bounds from all compared archives and then
% divided by the normalized reference-box volume, so NormHV is in [0, 1].

clear; clc; close all;
addpath(genpath(fileparts(fileparts(mfilename('fullpath')))));
cd(fileparts(fileparts(mfilename('fullpath'))));

params = defaultParams();
params.seed = 1;
problem = createUAVProblem(params);
algorithms = getComparisonAlgorithmNames();
nAlg = numel(algorithms);

Results = cell(nAlg, 1);
Rows = repmat(emptyMetricRow(), nAlg, 1);
Archives = cell(nAlg, 1);

fprintf('\n================ Single-run algorithm comparison ================\n');
for a = 1:nAlg
    alg = algorithms{a};
    fprintf('\n================ Run %s ================\n', alg);
    rng(1000 + a);
    Results{a} = runComparator(alg, problem, params, true);
    printSolution(Results{a}.bestSol, problem, sprintf('%s Compromise Solution', alg));
    Rows(a) = extractResultMetrics(Results{a});
    Archives{a} = Results{a}.archive;
end

[Rows, hvInfo] = fillNormHVForRows(Rows, Archives, params);

fprintf('\n================ Normalized HV Settings ================\n');
fprintf('Global min cost: '); fprintf('%.4f ', hvInfo.globalMinCost); fprintf('\n');
fprintf('Global max cost: '); fprintf('%.4f ', hvInfo.globalMaxCost); fprintf('\n');
fprintf('Reference point: '); fprintf('%.2f ', hvInfo.refPointNorm); fprintf('\n');
fprintf('Reference-box volume: %.4f\n', prod(hvInfo.refPointNorm));
fprintf('Note: NormHV is divided by the reference-box volume and is bounded in [0, 1].\n');

fprintf('\n================ Single-run Summary ================\n');
for a = 1:nAlg
    printOneLine(algorithms{a}, Rows(a));
end

if ~exist('results', 'dir')
    mkdir('results');
end
save(fullfile('results', 'compare_all_algorithms_PEAR_MOEA.mat'), ...
    'algorithms', 'Results', 'Rows', 'Archives', 'hvInfo');
writeSingleRunCSV(fullfile('results', 'compare_all_algorithms_PEAR_MOEA.csv'), algorithms, Rows);
fprintf('\nComparison data saved to:\n  %s\n  %s\n', ...
    fullfile(pwd, 'results', 'compare_all_algorithms_PEAR_MOEA.mat'), ...
    fullfile(pwd, 'results', 'compare_all_algorithms_PEAR_MOEA.csv'));

% Plot the proposed archive by default. Plotting all archives can create many figures.
idxProposed = find(strcmpi(algorithms, 'PEAR-MOEA'), 1);
if ~isempty(idxProposed)
    plotParetoFront(Results{idxProposed}.archive, 'PEAR-MOEA Archive');
end

function row = emptyMetricRow()
    row.Profit = 0;
    row.Distance = 0;
    row.Time = 0;
    row.MaxUtil = 0;
    row.Trips = 0;
    row.Energy = 0;
    row.EarlyRate = 0;
    row.HighRiskAvgTrip = 0;
    row.HighRiskMaxTrip = 0;
    row.Spacing = 0;
    row.NormHV = 0;
    row.ArchiveSize = 0;
end

function [Rows, info] = fillNormHVForRows(Rows, Archives, params)
    allCosts = [];
    for i = 1:numel(Archives)
        if ~isempty(Archives{i})
            allCosts = [allCosts; vertcat(Archives{i}.Cost)]; %#ok<AGROW>
        end
    end
    info.globalMinCost = min(allCosts, [], 1);
    info.globalMaxCost = max(allCosts, [], 1);
    info.refPointNorm = 1.1 * ones(1, size(allCosts, 2));
    info.hvSamples = getParam(params, 'hvSamples', 50000);
    for i = 1:numel(Archives)
        if ~isempty(Archives{i})
            Rows(i).NormHV = calcNormalizedHV(vertcat(Archives{i}.Cost), info.globalMinCost, info.globalMaxCost, info.refPointNorm, info.hvSamples);
        end
    end
end

function printOneLine(name, row)
    fprintf('%-14s | Profit %8.3f | Distance %8.3f | Time %7.3f | Energy %8.3f | MaxUtil %.4f | Trips %2d | EarlyRate %6.2f%% | AvgHighTrip %.2f | MaxHighTrip %.2f | Spacing %.4f | NormHV %.4f | Archive %3d\n', ...
        name, row.Profit, row.Distance, row.Time, row.Energy, row.MaxUtil, row.Trips, 100*row.EarlyRate, ...
        row.HighRiskAvgTrip, row.HighRiskMaxTrip, row.Spacing, row.NormHV, row.ArchiveSize);
end

function writeSingleRunCSV(filename, algorithms, Rows)
    fid = fopen(filename, 'w');
    if fid < 0
        warning('Could not write %s', filename);
        return;
    end
    fprintf(fid, 'Algorithm,Profit,Distance,Time,Energy,MaxUtil,Trips,EarlyRate,HighRiskAvgTrip,HighRiskMaxTrip,Spacing,NormHV,ArchiveSize\n');
    for i = 1:numel(algorithms)
        r = Rows(i);
        fprintf(fid, '%s,%.10g,%.10g,%.10g,%.10g,%.10g,%d,%.10g,%.10g,%.10g,%.10g,%.10g,%d\n', ...
            algorithms{i}, r.Profit, r.Distance, r.Time, r.Energy, r.MaxUtil, r.Trips, r.EarlyRate, ...
            r.HighRiskAvgTrip, r.HighRiskMaxTrip, r.Spacing, r.NormHV, r.ArchiveSize);
    end
    fclose(fid);
end

function value = getParam(s, fieldName, defaultValue)
    if isfield(s, fieldName)
        value = s.(fieldName);
    else
        value = defaultValue;
    end
end
