%% ablation_experiment.m
% PEAR-MOEA ablation study for the UAV geohazard monitoring problem.
%
% This script evaluates the contribution of the main PEAR-MOEA modules:
%   1) spatial initialization,
%   2) priority relocation mutation,
%   3) 2-opt local search,
%   4) risk-aware inter-trip relocation,
%   5) trip-compression repair,
%   6) optional priority initialization / epsilon-grid archive checks,
%   7) energy-aware objective formulation.
%
% The default setting is 30 independent runs per variant. The output files are:
%   results/ablation_PEAR_MOEA.mat
%   results/ablation_summary_PEAR_MOEA.csv
%   results/ablation_improvement_PEAR_MOEA.csv
%   results/ablation_runs_<variant>.csv
%
% Note on NormHV:
%   NormHV is computed only for variants using the same four objectives
%   [-profit, distance, energy, maxUtil]. The variant "w/o Energy Objective"
%   optimizes [-profit, distance, time, maxUtil], so its NormHV is not directly
%   comparable and is reported as NaN in the summary table.

clear; clc; close all;
addpath(genpath(fileparts(fileparts(mfilename('fullpath')))));
cd(fileparts(fileparts(mfilename('fullpath'))));

baseParams = defaultParams();
baseParams.seed = 1;
nRun = 30;

variants = buildAblationVariants(baseParams);
nVar = numel(variants);

Rows = cell(nVar, 1);
Archives = cell(nVar, nRun);
for v = 1:nVar
    Rows{v} = repmat(emptyRow(), nRun, 1);
end

fprintf('\n================ PEAR-MOEA ablation study: %d variants x %d runs ================\n', nVar, nRun);
for v = 1:nVar
    name = variants(v).Name;
    fprintf('\n================ %s: %d independent runs ================\n', name, nRun);

    for r = 1:nRun
        params = variants(v).Params;
        problem = createUAVProblem(params);
        rng(200000 * v + r);

        result = runPNSGA2(problem, params, false);
        row = extractResultMetrics(result);
        Rows{v}(r) = row;
        Archives{v, r} = result.archive;

        fprintf('%-26s Run %02d/%02d | Profit %.2f | Distance %.2f | Energy %.2f | Time %.2f | Trips %d | EarlyRate %.2f%% | AvgHighTrip %.2f | Archive %d\n', ...
            name, r, nRun, row.Profit, row.Distance, row.Energy, row.Time, row.Trips, ...
            100*row.EarlyRate, row.HighRiskAvgTrip, row.ArchiveSize);
    end
end

%% Normalized HV for comparable objective variants only
energyVariantMask = false(nVar, 1);
for v = 1:nVar
    energyVariantMask(v) = strcmpi(getParam(variants(v).Params, 'objectiveMode', 'energy'), 'energy');
end

allCosts = [];
for v = 1:nVar
    if ~energyVariantMask(v)
        continue;
    end
    for r = 1:nRun
        if ~isempty(Archives{v, r})
            allCosts = [allCosts; vertcat(Archives{v, r}.Cost)]; %#ok<AGROW>
        end
    end
end

globalMinCost = min(allCosts, [], 1);
globalMaxCost = max(allCosts, [], 1);
refPointNorm = 1.1 * ones(1, size(allCosts, 2));
hvSamples = getParam(baseParams, 'hvSamples', 50000);

fprintf('\n================ Ablation Normalized HV calculation ================\n');
fprintf('Comparable objective variants: energy objective only.\n');
fprintf('Global min cost: '); fprintf('%.4f ', globalMinCost); fprintf('\n');
fprintf('Global max cost: '); fprintf('%.4f ', globalMaxCost); fprintf('\n');
fprintf('Reference point in normalized space: '); fprintf('%.2f ', refPointNorm); fprintf('\n');
fprintf('Reference-box volume: %.4f\n', prod(refPointNorm));

for v = 1:nVar
    if ~energyVariantMask(v)
        for r = 1:nRun
            Rows{v}(r).NormHV = NaN;
        end
        continue;
    end

    for r = 1:nRun
        if ~isempty(Archives{v, r})
            Rows{v}(r).NormHV = calcNormalizedHV(vertcat(Archives{v, r}.Cost), globalMinCost, globalMaxCost, refPointNorm, hvSamples);
        end
    end
end

fprintf('\n================ Ablation Summary: mean ± std ================\n');
for v = 1:nVar
    printStats(variants(v).Name, Rows{v});
end

idxFull = find(strcmpi({variants.Name}, 'Full PEAR-MOEA'), 1);
ablationSummary = buildAblationSummary(variants, Rows, idxFull);

fprintf('\n================ Full PEAR-MOEA vs ablated variants ================\n');
printAblationImprovement(ablationSummary);

if ~exist('results', 'dir')
    mkdir('results');
end

variantNames = {variants.Name};
save(fullfile('results', 'ablation_PEAR_MOEA.mat'), ...
    'variants', 'variantNames', 'Rows', 'Archives', 'globalMinCost', 'globalMaxCost', ...
    'refPointNorm', 'hvSamples', 'energyVariantMask', 'ablationSummary');
writeSummaryCSV(fullfile('results', 'ablation_summary_PEAR_MOEA.csv'), variants, Rows);
writeImprovementCSV(fullfile('results', 'ablation_improvement_PEAR_MOEA.csv'), ablationSummary);
for v = 1:nVar
    safeName = regexprep(variants(v).Name, '[^A-Za-z0-9]', '_');
    writeRunsCSV(fullfile('results', sprintf('ablation_runs_%s.csv', safeName)), Rows{v});
end

fprintf('\nAblation MAT results saved to: %s\n', fullfile(pwd, 'results', 'ablation_PEAR_MOEA.mat'));
fprintf('Ablation summary saved to: %s\n', fullfile(pwd, 'results', 'ablation_summary_PEAR_MOEA.csv'));
fprintf('Ablation improvement table saved to: %s\n', fullfile(pwd, 'results', 'ablation_improvement_PEAR_MOEA.csv'));

%% Local functions
function variants = buildAblationVariants(baseParams)
    variants = struct('Name', {}, 'Params', {}, 'Description', {});

    % The algorithm-only optimized full version follows the latest ablation:
    % priority initialization, priority mutation, and epsilon-grid archive are
    % disabled. Spatial initialization, risk relocation, 2-opt, enhanced trip
    % compression, and energy/risk insertion repair are enabled.
    fullParams = baseParams;
    fullParams.usePriorityInit = false;
    fullParams.useSpatialInit = true;
    fullParams.usePriorityRelocate = false;
    fullParams.useTwoOpt = true;
    fullParams.useInterTripRelocation = true;
    fullParams.useTripCompression = true;
    fullParams.useInsertionRepair = true;
    fullParams.useEpsGridArchive = false;

    addVariant('Full PEAR-MOEA', fullParams, ...
        'Optimized proposed method after ablation-guided simplification.');

    p = fullParams;
    p.useSpatialInit = false;
    addVariant('w/o Spatial Init', p, ...
        'Disables spatial initialization.');

    p = fullParams;
    p.usePriorityRelocate = true;
    addVariant('with Priority Mutation', p, ...
        'Adds priority relocation mutation to test its marginal effect.');

    p = fullParams;
    p.useTwoOpt = false;
    addVariant('w/o 2-opt', p, ...
        'Disables intra-trip 2-opt local search.');

    p = fullParams;
    p.useInterTripRelocation = false;
    addVariant('w/o Risk Relocation', p, ...
        'Disables risk-aware inter-trip relocation.');

    p = fullParams;
    p.useTripCompression = false;
    addVariant('w/o Trip Compression', p, ...
        'Disables the trip-compression repair operator.');

    p = fullParams;
    p.useInsertionRepair = false;
    addVariant('w/o Insertion Repair', p, ...
        'Disables the energy/risk-aware insertion repair operator.');

    p = fullParams;
    p.usePriorityInit = true;
    addVariant('with Priority Init', p, ...
        'Adds priority-guided initialization to test its instance-dependent effect.');

    p = fullParams;
    p.useEpsGridArchive = true;
    addVariant('with Eps-Grid Archive', p, ...
        'Adds epsilon-grid archive pruning to test its instance-dependent effect.');

    p = fullParams;
    p.usePriorityInit = false;
    p.useSpatialInit = false;
    p.usePriorityRelocate = false;
    p.useTwoOpt = false;
    p.useInterTripRelocation = false;
    p.useTripCompression = false;
    p.useInsertionRepair = false;
    p.useEpsGridArchive = false;
    addVariant('Plain NSGA-II Backbone', p, ...
        'Removes all PEAR-MOEA enhancement modules.');

    p = fullParams;
    p.objectiveMode = 'time';
    addVariant('w/o Energy Objective', p, ...
        'Optimizes time instead of energy as the third objective; NormHV is not directly comparable.');

    function addVariant(name, params, desc)
        k = numel(variants) + 1;
        variants(k).Name = name;
        variants(k).Params = params;
        variants(k).Description = desc;
    end
end

function row = emptyRow()
    row.Profit = 0;
    row.Distance = 0;
    row.Time = 0;
    row.MaxUtil = 0;
    row.Trips = 0;
    row.Energy = 0;
    row.EarlyRate = 0;
    row.HighRiskAvgTrip = 0;
    row.HighRiskMaxTrip = 0;
    row.Spacing = 0;
    row.NormHV = 0;
    row.ArchiveSize = 0;
end

function printStats(name, R)
    fprintf('%-26s | Profit %8.3f ± %-7.3f | Distance %8.3f ± %-7.3f | Time %7.3f ± %-6.3f | Energy %8.3f ± %-7.3f | MaxUtil %.4f ± %.4f | Trips %.2f ± %.2f | EarlyRate %6.2f ± %-6.2f | AvgHighTrip %.2f ± %.2f | MaxHighTrip %.2f ± %.2f | Spacing %.4f ± %.4f | NormHV %.4f ± %.4f | Archive %.2f ± %.2f\n', ...
        name, mean([R.Profit]), std([R.Profit]), mean([R.Distance]), std([R.Distance]), ...
        mean([R.Time]), std([R.Time]), mean([R.Energy]), std([R.Energy]), mean([R.MaxUtil]), std([R.MaxUtil]), ...
        mean([R.Trips]), std([R.Trips]), 100*mean([R.EarlyRate]), 100*std([R.EarlyRate]), ...
        mean([R.HighRiskAvgTrip]), std([R.HighRiskAvgTrip]), mean([R.HighRiskMaxTrip]), std([R.HighRiskMaxTrip]), ...
        mean([R.Spacing], 'omitnan'), std([R.Spacing], 'omitnan'), mean([R.NormHV], 'omitnan'), std([R.NormHV], 'omitnan'), ...
        mean([R.ArchiveSize]), std([R.ArchiveSize]));
end

function S = buildAblationSummary(variants, Rows, idxFull)
    fields = getMetricFields();
    F = Rows{idxFull};
    k = 0;
    for v = 1:numel(variants)
        if v == idxFull
            continue;
        end
        B = Rows{v};
        for i = 1:size(fields, 1)
            name = fields{i, 1};
            higherBetter = fields{i, 2};
            fullVals = [F.(name)];
            baseVals = [B.(name)];
            valid = ~(isnan(fullVals) | isnan(baseVals));
            k = k + 1;
            S(k).Variant = variants(v).Name; %#ok<AGROW>
            S(k).Metric = name;
            S(k).HigherBetter = higherBetter;
            S(k).Full_Mean = mean(fullVals(valid));
            S(k).Full_Std = std(fullVals(valid));
            S(k).Ablated_Mean = mean(baseVals(valid));
            S(k).Ablated_Std = std(baseVals(valid));
            if any(valid)
                if higherBetter
                    S(k).ImprovementPercent = 100 * (S(k).Full_Mean - S(k).Ablated_Mean) / max(abs(S(k).Ablated_Mean), eps);
                    S(k).Full_Wins = sum(fullVals(valid) > baseVals(valid));
                    S(k).Ties = sum(fullVals(valid) == baseVals(valid));
                else
                    S(k).ImprovementPercent = 100 * (S(k).Ablated_Mean - S(k).Full_Mean) / max(abs(S(k).Ablated_Mean), eps);
                    S(k).Full_Wins = sum(fullVals(valid) < baseVals(valid));
                    S(k).Ties = sum(fullVals(valid) == baseVals(valid));
                end
                try
                    S(k).WilcoxonP = signrank(fullVals(valid), baseVals(valid));
                catch
                    S(k).WilcoxonP = NaN;
                end
            else
                S(k).ImprovementPercent = NaN;
                S(k).Full_Wins = 0;
                S(k).Ties = 0;
                S(k).WilcoxonP = NaN;
            end
        end
    end
end

function printAblationImprovement(S)
    importantMetrics = {'Profit', 'Energy', 'Trips', 'EarlyRate', 'HighRiskAvgTrip', 'NormHV'};
    for i = 1:numel(S)
        if any(strcmp(S(i).Metric, importantMetrics))
            fprintf('vs %-24s | %-16s | Improvement %+8.2f%% | Full wins %2d/30 | p = %.3g\n', ...
                S(i).Variant, S(i).Metric, S(i).ImprovementPercent, S(i).Full_Wins, S(i).WilcoxonP);
        end
    end
end

function fields = getMetricFields()
    fields = {
        'Profit', true;
        'Distance', false;
        'Time', false;
        'Energy', false;
        'Trips', false;
        'MaxUtil', false;
        'EarlyRate', true;
        'HighRiskAvgTrip', false;
        'HighRiskMaxTrip', false;
        'NormHV', true;
        'Spacing', false;
        'ArchiveSize', true
    };
end

function writeSummaryCSV(filename, variants, Rows)
    fid = fopen(filename, 'w');
    if fid < 0, warning('Could not write %s', filename); return; end
    fprintf(fid, 'Variant,Description,Metric,Mean,Std\n');
    fields = getMetricFields();
    for v = 1:numel(variants)
        R = Rows{v};
        for i = 1:size(fields, 1)
            name = fields{i, 1};
            vals = [R.(name)];
            fprintf(fid, '%s,%s,%s,%.10g,%.10g\n', escapeCSV(variants(v).Name), escapeCSV(variants(v).Description), name, mean(vals, 'omitnan'), std(vals, 'omitnan'));
        end
    end
    fclose(fid);
end

function writeImprovementCSV(filename, S)
    fid = fopen(filename, 'w');
    if fid < 0, warning('Could not write %s', filename); return; end
    fprintf(fid, 'AblatedVariant,Metric,HigherBetter,Full_Mean,Full_Std,Ablated_Mean,Ablated_Std,ImprovementPercent,Full_Wins,Ties,WilcoxonP\n');
    for i = 1:numel(S)
        fprintf(fid, '%s,%s,%d,%.10g,%.10g,%.10g,%.10g,%.10g,%d,%d,%.10g\n', ...
            escapeCSV(S(i).Variant), S(i).Metric, S(i).HigherBetter, S(i).Full_Mean, S(i).Full_Std, ...
            S(i).Ablated_Mean, S(i).Ablated_Std, S(i).ImprovementPercent, S(i).Full_Wins, S(i).Ties, S(i).WilcoxonP);
    end
    fclose(fid);
end

function writeRunsCSV(filename, R)
    fid = fopen(filename, 'w');
    if fid < 0, warning('Could not write %s', filename); return; end
    fprintf(fid, 'Run,Profit,Distance,Time,Energy,MaxUtil,Trips,EarlyRate,HighRiskAvgTrip,HighRiskMaxTrip,Spacing,NormHV,ArchiveSize\n');
    for i = 1:numel(R)
        fprintf(fid, '%d,%.10g,%.10g,%.10g,%.10g,%.10g,%d,%.10g,%.10g,%.10g,%.10g,%.10g,%d\n', ...
            i, R(i).Profit, R(i).Distance, R(i).Time, R(i).Energy, R(i).MaxUtil, R(i).Trips, ...
            R(i).EarlyRate, R(i).HighRiskAvgTrip, R(i).HighRiskMaxTrip, R(i).Spacing, R(i).NormHV, R(i).ArchiveSize);
    end
    fclose(fid);
end

function s = escapeCSV(s)
    s = char(s);
    if contains(s, ',') || contains(s, '"')
        s = strrep(s, '"', '""');
        s = ['"' s '"']; %#ok<AGROW>
    end
end

function value = getParam(s, fieldName, defaultValue)
    if isfield(s, fieldName)
        value = s.(fieldName);
    else
        value = defaultValue;
    end
end
