function plotSolution(sol, problem)
% plotSolution
% Plot UAV multi-trip solution.

    figure;
    hold on; grid on; axis equal;
    scatter(problem.coord(:,1), problem.coord(:,2), 45, problem.urgency, 'filled');
    colorbar;
    scatter(problem.depot(1), problem.depot(2), 140, 'kp', 'filled');
    text(problem.depot(1), problem.depot(2), ' Depot', 'FontWeight', 'bold');
    for i = 1:problem.nGS
        text(problem.coord(i,1), problem.coord(i,2), [' ', num2str(i)], 'FontSize', 8);
    end

    K = sol.Metrics.nTrips;
    colors = lines(max(K, 1));
    for k = 1:K
        trip = sol.Trips{k};
        path = [problem.depot; problem.coord(trip, :); problem.depot];
        plot(path(:,1), path(:,2), '-o', 'Color', colors(k,:), 'LineWidth', 1.5, 'MarkerSize', 4);
    end

    xlabel('X / km'); ylabel('Y / km');
    title(sprintf('UAV Multi-trip Path | Profit %.2f | Distance %.2f | Trips %d', ...
        sol.Metrics.totalProfit, sol.Metrics.totalDistance, K));
    hold off;
end
