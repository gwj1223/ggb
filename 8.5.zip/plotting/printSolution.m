function printSolution(bestSol, problem, titleStr)
% printSolution
% Print one solution.

    if nargin < 3
        titleStr = 'Compromise Solution';
    end

    fprintf('\n===================== %s =====================\n', titleStr);
    fprintf('Total Profit              = %.4f\n', bestSol.Metrics.totalProfit);
    fprintf('Total Distance            = %.4f\n', bestSol.Metrics.totalDistance);
    fprintf('Total Mission Time        = %.4f h\n', bestSol.Metrics.totalMissionTime);
    fprintf('  Flight Time             = %.4f h\n', bestSol.Metrics.totalFlightTime);
    fprintf('  Recharge Time           = %.4f h\n', bestSol.Metrics.totalRechargeTime);
    fprintf('  Service Time            = %.4f h\n', bestSol.Metrics.totalServiceTime);
    fprintf('Max Range Utilization     = %.4f\n', bestSol.Metrics.maxRangeUtilization);
    fprintf('Trip Distance Std         = %.4f\n', bestSol.Metrics.tripDistanceStd);
    fprintf('Trip Distance CV          = %.4f\n', bestSol.Metrics.tripDistanceCV);
    fprintf('Total Energy              = %.4f\n', bestSol.Metrics.totalEnergy);
    fprintf('High-risk Early Rate      = %.2f%% (%d/%d)\n', ...
        100 * bestSol.Metrics.highRiskEarlyRate, ...
        bestSol.Metrics.highRiskEarlyCount, bestSol.Metrics.highRiskTotal);
    fprintf('High-risk Avg Trip        = %.2f\n', bestSol.Metrics.highRiskAvgTrip);
    fprintf('High-risk Max Trip        = %d\n', bestSol.Metrics.highRiskMaxTrip);
    fprintf('Number of Trips           = %d\n', bestSol.Metrics.nTrips);
    fprintf('Lmax                      = %.4f\n', problem.Lmax);

    fprintf('\nTrips:\n');
    for k = 1:bestSol.Metrics.nTrips
        trip = bestSol.Trips{k};
        fprintf('Trip %d: 0 -> ', k);
        fprintf('%d -> ', trip);
        fprintf('0 | Distance = %.2f | Util = %.2f%% | Profit = %.2f | Nodes = %d\n', ...
            bestSol.Metrics.tripDistance(k), ...
            100 * bestSol.Metrics.tripDistance(k) / problem.Lmax, ...
            bestSol.Metrics.tripProfit(k), numel(trip));
    end
end
