function plotParetoFront(pop, titleStr)
% plotParetoFront
% 3D visualization using Distance, Energy, and Profit. Color = MaxUtil.

    if isempty(pop)
        return;
    end

    profit = arrayfun(@(x) x.Metrics.totalProfit, pop)';
    distance = arrayfun(@(x) x.Metrics.totalDistance, pop)';
    energy = arrayfun(@(x) x.Metrics.totalEnergy, pop)';
    maxUtil = arrayfun(@(x) x.Metrics.maxRangeUtilization, pop)';

    figure;
    scatter3(distance, energy, profit, 45, maxUtil, 'filled');
    grid on;
    xlabel('Distance'); ylabel('Energy'); zlabel('Profit');
    title(titleStr);
    colorbar;
end
