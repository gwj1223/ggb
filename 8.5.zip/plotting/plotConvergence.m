function plotConvergence(history)
% plotConvergence
% Plot convergence curves.

    figure;
    plot(history.bestProfit, 'LineWidth', 1.6);
    grid on; xlabel('Iteration'); ylabel('Best TOPSIS Profit');
    title('Profit Convergence');


    if isfield(history, 'bestEnergy')
        figure;
        plot(history.bestEnergy, 'LineWidth', 1.6);
        grid on; xlabel('Iteration'); ylabel('Best TOPSIS Energy');
        title('Energy Convergence');
    end

    figure;
    plot(history.archiveSize, 'LineWidth', 1.6);
    grid on; xlabel('Iteration'); ylabel('Archive Size');
    title('Archive Size');
end
