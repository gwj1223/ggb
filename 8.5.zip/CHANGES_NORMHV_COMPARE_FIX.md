# Update: bounded NormHV and comparison-data export

This update makes two practical changes for paper-level experiments.

## 1. Bounded normalized hypervolume

`metrics/calcNormalizedHV.m` now returns the hypervolume divided by the reference-box volume:

```matlab
NormHV = HV / prod(refPointNorm)
```

For the default reference point `[1.1, 1.1, 1.1, 1.1]`, this means the value is divided by `1.1^4 = 1.4641`. Therefore, `NormHV` is now bounded in `[0, 1]`, which is more suitable for tables and manuscript reporting.

## 2. Comparison experiment export

`examples/compare_algorithms.m` now saves the single-run comparison to:

```text
results/compare_results_energy_normhv.mat
```

The saved file contains:

- `comparison.P`: scalar metrics of P-NSGA-II
- `comparison.N`: scalar metrics of standard NSGA-II
- `comparison.resultP`: full P-NSGA-II result object
- `comparison.resultN`: full standard NSGA-II result object
- `comparison.minCost`, `comparison.maxCost`, `comparison.refPointNorm`, `comparison.hvSamples`

## 3. Batch experiment export

`examples/batch_runs.m` now saves both MAT and CSV comparison data:

```text
results/batch_results_energy_normhv.mat
results/batch_summary_energy_normhv.csv
results/batch_runs_P_energy_normhv.csv
results/batch_runs_N_energy_normhv.csv
```

The MAT file contains:

- `P`, `N`
- `ArchivesP`, `ArchivesN`
- `globalMinCost`, `globalMaxCost`, `refPointNorm`, `hvSamples`
- `comparisonSummary`

The CSV files are convenient for paper tables and spreadsheet checks.
