function [c1, c2] = orderCrossover(p1, p2)
% orderCrossover
% OX crossover for permutations.

    c1 = oxOneChild(p1, p2);
    c2 = oxOneChild(p2, p1);
end

function child = oxOneChild(parentA, parentB)
    n = numel(parentA);
    pts = sort(randperm(n, 2));
    l = pts(1);
    r = pts(2);
    child = zeros(1, n);
    child(l:r) = parentA(l:r);
    segment = child(l:r);
    seq = [parentB(r+1:end), parentB(1:r)];
    fillValues = seq(~ismember(seq, segment));
    fillPositions = [r+1:n, 1:l-1];
    child(fillPositions) = fillValues;
end
