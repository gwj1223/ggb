function perm = spatialInitialization(problem)
% spatialInitialization
% Angle-based spatial initialization.

    coord = problem.coord;
    depot = problem.depot;
    n = problem.nGS;
    angle = atan2(coord(:, 2) - depot(2), coord(:, 1) - depot(1));
    [~, order] = sort(angle);
    perm = order';
    if rand < 0.5
        perm = fliplr(perm);
    end
    perm = circshift(perm, [0, randi(n)]);
end
