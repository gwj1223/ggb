function y = priorityRelocateMutation(x, urgency)
% priorityRelocateMutation
% Move a high-urgency node from late position to early position.

    y = x;
    n = numel(x);
    [~, highOrder] = sort(urgency, 'descend');
    topNum = max(1, ceil(0.30 * n));
    highNodes = highOrder(1:topNum);
    positions = 1:n;
    candidatePositions = find(ismember(y, highNodes) & positions > ceil(n/2));

    if isempty(candidatePositions)
        y = swapMutation(x);
        return;
    end

    fromPos = candidatePositions(randi(numel(candidatePositions)));
    node = y(fromPos);
    y(fromPos) = [];
    toPos = randi(max(1, ceil(n/3)));
    toPos = min(toPos, numel(y) + 1);
    y = [y(1:toPos-1), node, y(toPos:end)];
end
