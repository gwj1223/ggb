function y = reverseMutation(x)
% reverseMutation
    y = x;
    n = numel(x);
    p = sort(randperm(n, 2));
    y(p(1):p(2)) = fliplr(y(p(1):p(2)));
end
