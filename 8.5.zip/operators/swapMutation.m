function y = swapMutation(x)
% swapMutation
    y = x;
    n = numel(x);
    p = randperm(n, 2);
    y([p(1), p(2)]) = y([p(2), p(1)]);
end
