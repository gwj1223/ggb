function perm = priorityInitialization(problem, alpha)
% priorityInitialization
% Urgency-distance priority initialization.

    coord = problem.coord;
    depot = problem.depot;
    urgency = problem.urgency;
    n = problem.nGS;

    d0 = sqrt(sum((coord - depot).^2, 2));
    urgencyScore = urgency / max(urgency);
    distanceScore = 1 - d0 / (max(d0) + eps);
    score = alpha * urgencyScore + (1 - alpha) * distanceScore;
    score = score + 0.05 * randn(n, 1);
    [~, order] = sort(score, 'descend');
    perm = order';
end
