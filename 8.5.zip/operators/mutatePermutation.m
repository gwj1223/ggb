function y = mutatePermutation(x, problem, params)
% mutatePermutation
% Mixed mutation: swap, reverse, and priority relocation.

    r = rand;
    usePriorityRelocate = isfield(params, 'usePriorityRelocate') && params.usePriorityRelocate;

    if r < 0.40
        y = swapMutation(x);
    elseif r < 0.70
        y = reverseMutation(x);
    else
        if usePriorityRelocate
            y = priorityRelocateMutation(x, problem.urgency);
        else
            y = swapMutation(x);
        end
    end
end
