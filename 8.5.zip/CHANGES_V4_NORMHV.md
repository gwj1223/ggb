# v4 update: Normalized HV

This version keeps the P-NSGA-II v3 model and operators unchanged, and updates the multi-objective performance indicator calculation.

## Main changes

1. Added `metrics/normalizeObjectiveCosts.m`.
2. Added `metrics/calcNormalizedHV.m`.
3. Updated `examples/compare_algorithms.m` to report `NormHV` instead of raw HV.
4. Updated `examples/batch_runs.m` to:
   - save all archives from 30 independent runs;
   - compute one global normalization box using all archive solutions from all compared algorithms;
   - calculate normalized HV for every run;
   - save results to `results/batch_results_v3_normhv.mat`.
5. Added `params.hvSamples = 50000` in `defaultParams.m`.

## Why normalized HV?

The four objectives have different numerical scales:

- `-Profit`
- `Distance`
- `Time`
- `MaxUtil`

Raw HV can be dominated by large-scale objectives such as distance. Normalized HV first maps all objectives to `[0, 1]` using common bounds and then computes HV with reference point `[1.1, 1.1, 1.1, 1.1]`.

## Recommended scripts

```matlab
main
run('examples/compare_algorithms.m')
run('examples/batch_runs.m')
```
