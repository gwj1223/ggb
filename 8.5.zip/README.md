# UAV_Geohazard_PNSGA2 energy-objective update

This MATLAB project implements a four-objective P-NSGA-II for multi-trip UAV geohazard monitoring path planning. In this update, the optimized objective vector is `[-Profit, Distance, Energy, MaxUtil]`. Mission time is still reported as an evaluation metric.

## Main objectives

The cost vector is minimized:

1. `-Profit`: maximize urgency-decay monitoring profit
2. `Distance`: minimize total flight distance
3. `Energy`: minimize total energy consumption
4. `MaxUtil`: minimize maximum range utilization

Additional reported metrics:

- number of trips
- total mission time
- high-risk early monitoring rate
- high-risk average visited trip
- high-risk latest visited trip
- spacing
- normalized HV in comparison and batch scripts



## Energy-objective update

The core cost vector has been changed from `[-Profit, Distance, Time, MaxUtil]` to:

```matlab
Cost = [-Profit, Distance, Energy, MaxUtil];
```

`Time` remains in `Metrics` and in the result summaries, but it is no longer the third optimized objective. This makes the formulation more UAV-oriented because energy consumption is directly optimized.

## v4 update

This version adds normalized HV calculation for fair multi-objective comparison:

- `metrics/normalizeObjectiveCosts.m`
- `metrics/calcNormalizedHV.m`
- `examples/compare_algorithms.m` now reports `NormHV`
- `examples/batch_runs.m` saves archives and computes global-bound normalized HV
- results are saved to `results/batch_results_energy_normhv.mat`

Normalized HV uses common bounds from all compared archive solutions and reference point `[1.1, 1.1, 1.1, 1.1]`. The HV value is divided by the reference-box volume `1.1^4`, so `NormHV` is bounded in `[0, 1]` and is suitable for manuscript tables.

## v3 updates

Compared with the previous archive + TOPSIS version, this version adds:

- urgency-aware inter-trip relocation operator
- epsilon-grid archive maintenance
- weighted TOPSIS compromise solution selection
- high-risk average visited trip metric
- high-risk latest visited trip metric
- batch run script with the new indicators
- ablation experiment including inter-trip relocation

## How to run

Open MATLAB, set the current folder to this project root, then run:

```matlab
main
```

Run one paper-level comparison across all selected algorithms:

```matlab
run('examples/compare_algorithms.m')
```

Run 30 independent runs:

```matlab
run('examples/batch_runs.m')
```

Run ablation experiment:

```matlab
run('examples/ablation_experiment.m')
```

If batch runs are slow, edit `examples/batch_runs.m` and set:

```matlab
nRun = 5;
```

## Key parameter switches

Defined in `defaultParams.m`:

```matlab
params.useInterTripRelocation = true;
params.pInterTripRelocation = 0.25;
params.interTripMaxTrial = 20;
params.usePriorityInit = false;       % disabled by optimized ablation result
params.useSpatialInit = true;
params.usePriorityRelocate = false;  % disabled by final ablation result
params.useTwoOpt = true;
params.useInterTripRelocation = true;
params.useTripCompression = true;
params.pTripCompression = 0.35;
params.tripCompressionMaxPass = 3;
params.useInsertionRepair = true;    % energy/risk-aware insertion repair
params.pInsertionRepair = 0.20;
params.useEpsGridArchive = false;    % ordinary archive is the optimized default
params.epsGrid = 0.03;               % available for optional ablation
params.topsisWeights = [0.45, 0.25, 0.25, 0.05];  % [-Profit, Distance, Energy, MaxUtil]
```

## Folder structure

- `model/`: problem model, decoding, objectives, constraints
- `algorithm/`: NSGA-II core, archive, sorting, selection
- `operators/`: initialization, crossover, mutation
- `local_search/`: 2-opt and urgency-aware inter-trip relocation
- `metrics/`: TOPSIS, spacing, approximate HV, result extraction
- `plotting/`: solution and Pareto plots
- `examples/`: comparison, batch runs, ablation, model test


## Experiment output files

- `examples/compare_algorithms.m` saves single-run comparison data to `results/compare_all_algorithms_PEAR_MOEA.mat` and `.csv`.
- `examples/batch_runs.m` saves batch data to `results/batch_all_algorithms_PEAR_MOEA.mat` and CSV summaries for all selected algorithms.


## PEAR-MOEA comparison update

The proposed algorithm is named **PEAR-MOEA**: **Priority-guided Energy-aware and Risk-aware Multi-Objective Evolutionary Algorithm**.

The current objective vector is:

```matlab
Cost = [-Profit, Distance, Energy, MaxUtil]
```

All objectives are minimized. `Time` is retained as an evaluation metric rather than a main objective.

The paper-level comparison scripts support the following algorithms:

1. NN-Greedy
2. Random-Greedy
3. NSGA-II
4. NSGA-III
5. MOEA/D
6. SPEA2
7. MOPSO
8. MODE
9. MOACO-lite
10. PEAR-MOEA

The heuristic and swarm-intelligence baselines do not use the PEAR-MOEA-specific spatial initialization, risk-aware inter-trip relocation, 2-opt local search, trip-compression repair, or energy/risk insertion repair modules. `NN-Greedy` is a distance-only nearest-neighbor baseline; `Random-Greedy` is a random permutation baseline; `MOACO-lite` uses distance-only ant visibility.

Run one comparison:

```matlab
examples/compare_algorithms
```

Run 30 independent comparisons:

```matlab
examples/batch_runs
```

Batch outputs are saved in the `results/` folder as MAT and CSV files.


## Latest optimization update: PEAR-MOEA+

This version strengthens PEAR-MOEA with three changes:

1. **More aggressive compromise selection**: TOPSIS weights are updated to `[0.45, 0.25, 0.25, 0.05]` for the objective vector `[-Profit, Distance, Energy, MaxUtil]`, reducing excessive conservativeness caused by `MaxUtil`.
2. **Trip-compression repair**: a new PEAR-MOEA-only route repair operator tries to merge short trips into other feasible trips, aiming to reduce the number of UAV sorties, total distance, energy consumption, and mission time.
3. **Fairer baselines**: comparison baselines explicitly disable PEAR-MOEA-specific mechanisms, including priority initialization, priority relocation, 2-opt, risk-aware inter-trip relocation, and trip-compression repair. MOACO-lite now uses distance-only pheromone reinforcement.

The proposed method is still called **PEAR-MOEA** in the paper, while the implementation includes the new trip-compression repair mechanism.


## Algorithm-only optimized default

Based on the final ablation study, the default PEAR-MOEA configuration has been further simplified and strengthened:

- Disabled by default: `usePriorityInit = false`
- Disabled by default: `usePriorityRelocate = false`
- Disabled by default: `useEpsGridArchive = false`
- Kept enabled: spatial initialization, 2-opt local search, risk-aware inter-trip relocation, enhanced trip-compression repair, and energy/risk-aware insertion repair

This configuration keeps the modules with clear support from the ablation results, weakens the marginal priority mutation operator, and adds a lightweight insertion repair for local energy/risk fine-tuning. Optional priority initialization, priority mutation, and epsilon-grid archive remain available in `defaultParams.m` and in `examples/ablation_experiment.m`.
