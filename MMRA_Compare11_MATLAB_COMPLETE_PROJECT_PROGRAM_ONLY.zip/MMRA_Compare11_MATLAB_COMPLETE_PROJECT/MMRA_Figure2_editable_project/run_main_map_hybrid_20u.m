%RUN_MAIN_MAP_HYBRID_20U A/B/C pilot on SAME saved Figure 2 20-UAV paths.
% A: original speed schedule (without obstacle).
% B: existing obstacle-aware speed schedule.
% C: speed-only or candidate local detour + full rescheduling.
% No RRT* paths are overwritten, and no extra Figure 2 map is drawn.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
% Reuse the existing reproducible moving-obstacle scenario generator and
% its independent baseline collision audit; it publishes P/newOpt/etc.
run(fullfile(root,'run_main_map_dynamic_obstacle_20u.m'));
[envHybrid,cfgHybrid,~]=mmra_defaults('mountain_cluster_figure2_custom_5km');
assert(isequal(env,envHybrid), 'Current Figure 2 terrain differs from checkpoint.');
newOpt.hybridWaitTrigger_s=2;
newOpt.hybridMaxCandidates=8;
newOpt.hybridMaxLengthRatio=1.20;
newOpt.hybridExtraLengthWeight=.25;
newOpt.hybridTryLocalRRT=true;
[hybrid,hybridPaths,hybridReport]= ...
    mmra_hybrid_dynamic_obstacle_schedule(P,env,cfgHybrid,newOpt);
fprintf('\n=== FIGURE 2 20-UAV HYBRID OBSTACLE PILOT ===\n');
fprintf('Speed-only: success=%d, reason=%s, makespan=%.2f s\n', ...
    controlled.success,controlled.reason,controlled.makespan);
fprintf('Hybrid: success=%d, reason=%s, strategy=%s\n', ...
    hybrid.success,hybrid.reason,hybridReport.strategy);
fprintf('Hybrid checked: %d candidates, completed: %d; extra path=%.2f m\n', ...
    hybridReport.detoursSimulated,hybridReport.detoursCompleted, ...
    hybridReport.selectedExtraLength_m);
fprintf('Obstacle clearance=%.3f m, inter-UAV min gap=%.3f m\n', ...
    hybrid.obstacleMinClearance_m,hybrid.minSeparation);
if hybrid.success
    assert(hybrid.validation.safe && hybrid.validation.complete && ...
        hybrid.validation.dynamicObstacles.safe && ...
        hybrid.obstacleMinClearance_m>=-newOpt.tol && ...
        hybrid.minSeparation>=newOpt.dSafe-newOpt.tol, ...
        'Hybrid claimed success without independent verification.');
end
saveDir=fullfile(root,'results_dynamic_obstacles_dev');
if ~exist(saveDir,'dir'),mkdir(saveDir);end
save(fullfile(saveDir,'Figure2_hybrid_20u_latest.mat'), ...
    'hybrid','hybridPaths','hybridReport','checkpoint','newOpt', ...
    'controlled','obstacle','-v7');
fprintf('Saved (without overwriting the baseline path checkpoint): %s\n',saveDir);
