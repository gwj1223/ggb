%RUN_RRT_TERRAIN_ADAPTIVE_TESTS New adaptive planner + established regressions.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'tests'));
mmra_rrt_terrain_adaptive_tests();
mmra_rrt_anytime_tests();
mmra_rrt_multiobjective_tests();
mmra_rrt_threeobjective_tests();
