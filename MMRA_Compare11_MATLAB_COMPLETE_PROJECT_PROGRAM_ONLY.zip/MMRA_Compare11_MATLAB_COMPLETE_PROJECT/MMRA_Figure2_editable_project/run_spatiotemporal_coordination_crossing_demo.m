%RUN_SPATIOTEMPORAL_COORDINATION_CROSSING_DEMO Control-only stress example.
% Three 3D polylines share a central crossing; this is a deterministic
% unit-level TRAFFIC configuration, NOT a different terrain map or RRT* run.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'tests'));
[~,~,opt]=mmra_defaults('paper_gmm');
opt.speed=15;opt.dSafe=10;
opt.startPolicy='hold';opt.endPolicy='hold';
opt.speedFeedbackLaunchInterval_s=0;
opt.speedFeedbackMaxTime_s=100;
opt.speedFeedbackMaxStall_s=12;
opt.speedFeedbackDt_s=0.2;
opt.coordinationV2MaxTrials=30;
opt.coordinationV2PriorityPolicy='dynamic_eta';
paths={[-45 0 20;45 0 20], ...
    [0 -45 20;0 45 20], ...
    [-32 -32 20;32 32 20]};
fprintf('\n=== THREE-UAV CROSSING / NOMINAL CONFLICT VS EXECUTED AUDIT ===\n');
base=mmra_schedule_speed_feedback(paths,opt);
co=mmra_schedule_spatiotemporal_coordination(paths,opt);
m=co.coordination;
fprintf('Nominal simultaneous-launch pair risks=%d\n', ...
    m.baselineNominal.numUnsafePairs);
fprintf('Baseline: success=%d, reason=%s, yields=%d, minsep=%.2f m\n', ...
    base.success,base.reason,base.yieldSteps,base.minSeparation);
fprintf(['V2: success=%d, reason=%s, policy=%s, ' ...
    'priority=%s, priority decisions=%d, yields=%d, minsep=%.2f m\n'], ...
    co.success,co.reason,m.selectedPolicy,m.selectedPriorityMode, ...
    co.dynamicPriorityDecisions,co.yieldSteps,co.minSeparation);
fprintf('Trials=%d, feasible=%d, stalled=%d\n', ...
    m.numTrials,m.numFeasible,m.numStalled);
if co.success
    assert(co.validation.safe && co.validation.complete && ...
        co.minSeparation>=opt.dSafe-opt.tol-1e-8);
end
fprintf(['Note: a stalled outcome is a valid safe failure, not evidence ' ...
    'of collision-free completion.\n']);
