%RUN_MAIN_MAP_DYNAMIC_OBSTACLES Saved Figure 2 + static & moving obstacles.
% Produces a STATIC SNAPSHOT at a selected absolute time (120 s). Animate
% with run_main_map_dynamic_animation or the editor time bar / PLAY.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
% A standalone view must not reuse an editor figure with stale UI state.
close all;
[env,cfg,opt]=mmra_defaults('mountain_cluster_figure2_custom_5km');
env=mmra_figure2_add_static_obstacles(env);
[obstacles,info]=mmra_figure2_dynamic_obstacles(env);
[starts,goals]=mmra_5km_mission(env,20,24001,'cross_center');
fig=mmra_plot_single_main_map(env,starts,goals);
ax=gca;
snapshot_s=120;
mmra_figure2_plot_dynamic_overlay(ax,obstacles,snapshot_s,[]);
title(ax,sprintf('Figure 2 | %d NFZ + %d moving spheres | t=%.0f s', ...
    size(env.noFlyCylinders,1),numel(obstacles),snapshot_s));
drawnow;
nAxes=numel(findall(fig,'Type','axes'));
nSurfaces=numel(findall(fig,'Type','surface'));
fprintf('Figure 2 drawable objects: axes=%d, surfaces=%d\n',nAxes,nSurfaces);
assert(nAxes>0 && nSurfaces>=1, ...
    'Figure 2 has no terrain surface. Run run_diagnose_figure2_blank.m.');
outDir=fullfile(root,'results_static_dynamic_dev');
if ~exist(outDir,'dir'),mkdir(outDir);end
outPng=fullfile(outDir,'Figure2_static_and_dynamic_t120.png');
saveas(fig,outPng);
save(fullfile(outDir,'Figure2_dynamic_scene.mat'), ...
    'env','cfg','opt','obstacles','info','snapshot_s','-v7');
fprintf('SAVED static + moving scene at t=%.0f s: %s\n',snapshot_s,outPng);
fprintf('Moving obstacles=%d, data source=%s, NFZ=%d, boxes=%d\n', ...
    numel(obstacles),info.source,size(env.noFlyCylinders,1), ...
    size(env.staticBoxes,1));
fprintf(['The scene is a SNAPSHOT. Use run_main_map_dynamic_animation.m ' ...
    'for moving spheres. Terrain/NFZ settings were NOT changed.\n']);
