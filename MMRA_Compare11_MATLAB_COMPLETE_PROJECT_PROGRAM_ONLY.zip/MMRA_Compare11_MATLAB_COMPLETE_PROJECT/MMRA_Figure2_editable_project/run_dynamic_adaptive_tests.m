%RUN_DYNAMIC_ADAPTIVE_TESTS V3 test entry point with installation diagnostics.
% Keep this file beside run_main_map.m in the MMRA project root.
root = fileparts(mfilename('fullpath'));
srcDir = fullfile(root,'src');
testDir = fullfile(root,'tests');

required = { ...
    fullfile(srcDir,'mmra_dynamic_adaptive_hybrid_schedule.m'), ...
    fullfile(srcDir,'mmra_schedule_speed_feedback.m'), ...
    fullfile(testDir,'mmra_dynamic_adaptive_tests.m'), ...
    fullfile(testDir,'mmra_dynamic_obstacle_tests.m')};
missing = false;
for k = 1:numel(required)
    if exist(required{k},'file') ~= 2
        fprintf(2,'MISSING: %s\n', required{k});
        missing = true;
    end
end
if missing
    error('MMRA:AdaptiveV3:IncompleteInstall', ...
        ['V3 files are missing. Extract the INSTALL_FIX ZIP directly into ', ...
         'the folder containing run_main_map.m, and merge src and tests.']);
end

addpath(srcDir,testDir,'-begin');
rehash;
if exist('mmra_dynamic_adaptive_tests','file') ~= 2 || ...
        exist('mmra_dynamic_adaptive_hybrid_schedule','file') ~= 2
    error('MMRA:AdaptiveV3:NotOnPath', ...
        'V3 files exist but are not on the MATLAB path. Check active project and which -all.');
end
fprintf('V3 test file: %s\n', which('mmra_dynamic_adaptive_tests'));
fprintf('V3 algorithm: %s\n', which('mmra_dynamic_adaptive_hybrid_schedule'));
mmra_dynamic_obstacle_tests();
mmra_dynamic_adaptive_tests();
