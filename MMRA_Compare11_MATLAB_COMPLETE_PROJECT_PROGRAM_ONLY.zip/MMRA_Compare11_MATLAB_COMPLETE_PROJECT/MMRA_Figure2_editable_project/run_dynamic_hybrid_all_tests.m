%RUN_DYNAMIC_HYBRID_ALL_TESTS Run dependency preflight and both test suites.
root=fileparts(mfilename('fullpath'));
run(fullfile(root,'run_check_dynamic_hybrid_install.m'));
run(fullfile(root,'run_dynamic_obstacle_tests.m'));
run(fullfile(root,'run_hybrid_dynamic_obstacle_tests.m'));
fprintf('Combined dynamic/hybrid regression scripts completed.\n');
