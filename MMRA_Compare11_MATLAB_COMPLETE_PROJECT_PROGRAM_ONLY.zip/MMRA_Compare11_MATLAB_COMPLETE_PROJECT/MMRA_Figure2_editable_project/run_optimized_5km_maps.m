%RUN_OPTIMIZED_5KM_MAPS Compatibility alias: now ONE selected figure.
root=fileparts(mfilename('fullpath'));
run(fullfile(root,'run_main_map.m'));
