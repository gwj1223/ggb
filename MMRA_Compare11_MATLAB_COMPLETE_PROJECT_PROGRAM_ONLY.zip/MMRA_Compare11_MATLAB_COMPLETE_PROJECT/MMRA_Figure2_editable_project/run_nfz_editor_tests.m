%RUN_NFZ_EDITOR_TESTS Check NFZ saved-config reload and real collision APIs.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'tests'));
mmra_figure2_nfz_editor_tests();
mmra_static_obstacle_tests();
