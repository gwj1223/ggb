%RUN_MAIN_MAP_TESTS Geometry and compatibility checks for ONE Figure 2.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
[env,cfg,opt]=mmra_defaults('mountain_cluster_figure2_v28_5km');
assert(isequal(env.boundsLo,[0 0 0]) && ...
    isequal(env.boundsHi,[5000 5000 2000]));
assert(size(env.peaks,1)==21 && size(env.peaks,2)==5);
assert(size(env.terrainRidges,1)==6);
assert(size(env.terrainErosionGullies,1)==4);
assert(size(env.terrainMicroWaves,1)==3);
assert(all(all(env.peaks(:,4:5)>0)));
assert(opt.dSafe==10 && opt.speed==15 && ...
    opt.speedFeedbackLaunchInterval_s==3);
assert(cfg.guardFineResolution>0 && env.safetyMargin==50);
[x,y]=meshgrid(linspace(0,5000,161)); P=[x(:) y(:)];
[h,hx,hy]=mmra_terrain(P,env);
assert(all(isfinite(h)) && all(isfinite(hx)) && all(isfinite(hy)));
assert(min(h)>0 && max(h)+env.safetyMargin<2000, ...
    'Terrain violates flyable space under the 2 km ceiling.');
assert(max(h)>1200 && max(h)-median(h)>700, ...
    'Staggered summit relief is missing.');
heightAtSummits=mmra_terrain([990 940;3210 2740; ...
    1870 3610;4150 1220],env);
assert(max(heightAtSummits)-min(heightAtSummits)>500, ...
    'Summit heights remain too uniform.');
% Check analytical gradients used by APF against numerical differences.
samples=[990 940;3210 2740;1870 3610;4150 1220; ...
    2100 1600;2700 3700;500 4500;4200 2500];
step=0.05;
for k=1:size(samples,1)
    q=samples(k,:);
    [~,ax,ay]=mmra_terrain(q,env);
    fx=(mmra_terrain(q+[step 0],env)- ...
        mmra_terrain(q-[step 0],env))/(2*step);
    fy=(mmra_terrain(q+[0 step],env)- ...
        mmra_terrain(q-[0 step],env))/(2*step);
    assert(abs(ax-fx)<5e-5 && abs(ay-fy)<5e-5, ...
        'Analytical gradients differ from finite differences.');
end
% Planning clearance must be checked against new Figure 2, not old map.
q=[3210 2740];hh=mmra_terrain(q,env);
assert(~mmra_is_free([q hh+env.safetyMargin-1],env));
assert( mmra_is_free([q hh+env.safetyMargin+100],env));
for U=[5 10 20]
    [starts,goals]=mmra_5km_mission(env,U,24001,'cross_center');
    assert(all(mmra_is_free(starts,env)) && ...
        all(mmra_is_free(goals,env)), ...
        'Mission endpoint cannot be used with the new terrain.');
end
% The exact original screenshot geometry is still available for
% reproducible comparisons, but is not drawn by run_main_map.m.
[old,~,~]=mmra_defaults('mountain_cluster_5km');
assert(size(old.peaks,1)==12 && ~isfield(old,'terrainRidges'));
assert(norm(mmra_terrain(P,old)-h)>500, ...
    'Optimized terrain did not change numerically.');
fprintf('One Figure 2 map geometry verified: %.1f-%.1f m.\n', ...
    min(h),max(h));
