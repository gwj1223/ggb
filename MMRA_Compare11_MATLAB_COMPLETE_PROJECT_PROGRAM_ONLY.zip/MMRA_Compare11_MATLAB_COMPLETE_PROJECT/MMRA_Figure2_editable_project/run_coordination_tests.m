%RUN_COORDINATION_TESTS Second innovation: offline multi-UAV coordination.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'tests'));
mmra_speed_feedback_tests();
mmra_coordination_tests();
