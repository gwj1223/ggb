%RUN_RRT_ANYTIME_FIGURE2_5U First-feasible vs anytime, same Figure 2 map.
% This script neither edits the saved map nor overwrites pilot checkpoints.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
profile='mountain_cluster_figure2_custom_5km';
[env,cfg,~]=mmra_defaults(profile);
assert(all(env.boundsHi==[5000 5000 2000]));
assert(isfile(fullfile(root,'results_main_map','Figure2_user_settings.mat')), ...
    'Figure 2 user settings not found in this project');

U=5;
seed=24001;
layout='cross_center';
% Quick first-stage benchmark; increase to 1800 for extended curves.
maxIterations=600;
cfg.maxIter=maxIterations;
cfg.wallBudget_s=Inf;    % essential for paired fixed-seed comparisons
cfg.prune=false;cfg.smooth=false;  % compare raw RRT* objective honestly
cfgAny=cfg;
cfgAny.rrtStopMode='anytime';
[starts,goals,missionMeta]=mmra_5km_mission(env,U,seed,layout);

outDir=fullfile(root,'results_rrt_anytime_figure2_dev');
if ~exist(outDir,'dir'),mkdir(outDir);end
legacyPaths=cell(U,1);anytimePaths=cell(U,1);
legacyStats=cell(U,1);anytimeStats=cell(U,1);
legacyWall_s=NaN(U,1);anytimeWall_s=NaN(U,1);
rows=repmat(struct('uav',0,'seed',0,'baselineSuccess',false, ...
    'anytimeSuccess',false,'firstIter',NaN,'anytimeIterations',NaN, ...
    'baselineObjective_m',NaN,'anytimeObjective_m',NaN, ...
    'gain_pct',NaN,'baselineLength_m',NaN,'anytimeLength_m',NaN, ...
    'baselineRiskIntegral_m',NaN,'anytimeRiskIntegral_m',NaN, ...
    'baselineAscent_m',NaN,'anytimeAscent_m',NaN, ...
    'baselineWall_s',NaN,'anytimeWall_s',NaN, ...
    'improvementCount',0,'fineClearance_m',NaN),U,1);
fprintf('\n=== FIGURE 2 RRT* SAME-SEED FIRST vs ANYTIME: U=%d, maxIter=%d ===\n', ...
    U,maxIterations);
fprintf('Saved map revision: %s\n',env.customMapRevision);
for i=1:U
    localSeed=seed+10007*i;
    rng(localSeed,'twister');t0=tic;
    [legacyPaths{i},legacyStats{i}]=mmra_plan_single( ...
        starts(i,:),goals(i,:),env,cfg,true);
    legacyWall_s(i)=toc(t0);
    rng(localSeed,'twister');t0=tic;
    [anytimePaths{i},anytimeStats{i}]=mmra_plan_single( ...
        starts(i,:),goals(i,:),env,cfgAny,true);
    anytimeWall_s(i)=toc(t0);
    a=legacyStats{i};b=anytimeStats{i};
    rows(i).uav=i;rows(i).seed=localSeed;
    rows(i).baselineSuccess=a.success;rows(i).anytimeSuccess=b.success;
    rows(i).firstIter=a.firstIter;rows(i).anytimeIterations=b.iterations;
    rows(i).baselineWall_s=legacyWall_s(i);
    rows(i).anytimeWall_s=anytimeWall_s(i);
    if a.success && b.success
        tol=max(1e-6,1e-8*abs(a.pathObjective_m));
        assert(a.firstIter==b.firstIter && ...
            isequaln(legacyPaths{i},b.firstFeasiblePath) && ...
            abs(a.pathObjective_m-b.firstObjective_m)<=tol, ...
            'Different pre-first-feasible histories: UAV %d',i);
        assert(b.pathObjective_m<=a.pathObjective_m+tol, ...
            'Anytime objective worsened: UAV %d',i);
        assert(b.iterations==maxIterations && b.treeCostError<1e-6, ...
            'Anytime search did not exhaust budget or corrupted tree');
        [cl,~]=mmra_path_clearance( ...
            anytimePaths{i},env,cfg.guardFineResolution);
        assert(isfinite(cl) && cl>0 && mmra_path_free( ...
            anytimePaths{i},env,cfg.guardFineResolution), ...
            'Fine terrain audit failed: UAV %d',i);
        rows(i).fineClearance_m=cl;
        rows(i).baselineObjective_m=a.pathObjective_m;
        rows(i).anytimeObjective_m=b.pathObjective_m;
        rows(i).gain_pct=b.improvementPct;
        rows(i).baselineLength_m=a.pathLength;
        rows(i).anytimeLength_m=b.pathLength;
        rows(i).baselineRiskIntegral_m=a.pathRiskIntegral_m;
        rows(i).anytimeRiskIntegral_m=b.pathRiskIntegral_m;
        rows(i).baselineAscent_m=a.pathAscent_m;
        rows(i).anytimeAscent_m=b.pathAscent_m;
        rows(i).improvementCount=b.improvementCount;
        fprintf(['UAV %d: firstIter=%d, finalIter=%d, ' ...
            'J=%.2f -> %.2f m, gain=%.2f%%, time=%.2f -> %.2f s\n'], ...
            i,b.firstIter,b.iterations,a.pathObjective_m, ...
            b.pathObjective_m,b.improvementPct, ...
            legacyWall_s(i),anytimeWall_s(i));
    else
        fprintf('UAV %d: baseline success=%d; anytime success=%d\n', ...
            i,a.success,b.success);
    end
end
results=struct('protocol','FIGURE2_RRT_ANYTIME_PHASE1_20261031', ...
    'terrain',profile,'mapRevision',env.customMapRevision, ...
    'seed',seed,'layout',layout,'U',U,'maxIterations',maxIterations, ...
    'env',env,'cfgBaseline',cfg,'cfgAnytime',cfgAny, ...
    'starts',starts,'goals',goals,'missionMeta',missionMeta, ...
    'legacyPaths',{legacyPaths},'anytimePaths',{anytimePaths}, ...
    'legacyStats',{legacyStats},'anytimeStats',{anytimeStats}, ...
    'legacyWall_s',legacyWall_s,'anytimeWall_s',anytimeWall_s);
summaryTable=struct2table(rows);
matFile=fullfile(outDir,'figure2_rrt_anytime_5u_seed24001.mat');
csvFile=fullfile(outDir,'figure2_rrt_anytime_5u_seed24001.csv');
save(matFile,'results','summaryTable','-v7');
writetable(summaryTable,csvFile);

% Objective convergence is a CHART, not an alternative terrain/map image.
try
    f=figure('Visible','off','Color','w');hold on;
    for i=1:U
        if ~anytimeStats{i}.success,continue;end
        trace=anytimeStats{i}.bestCostByIteration_m;
        plot(1:numel(trace),trace,'LineWidth',1.25, ...
            'DisplayName',sprintf('UAV %d',i));
    end
    xlabel('RRT* iteration');
    ylabel('Best feasible L + 0.5 R + 0.5 A (m)');
    title('Figure 2: raw RRT* anytime convergence');
    legend('Location','best');
    saveas(f,fullfile(outDir,'figure2_rrt_anytime_cost_convergence.png'));
    close(f);
catch plotErr
    warning('Convergence chart was not saved: %s',plotErr.message);
end
fprintf('Successes: baseline %d/%d, anytime %d/%d\n', ...
    sum([rows.baselineSuccess]),U,sum([rows.anytimeSuccess]),U);
fprintf('New independent output directory: %s\n',outDir);
