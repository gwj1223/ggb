%RUN_RRT_TERRAIN_ADAPTIVE_ABLATION_5U Independent feature ablation.
% This does NOT create another terrain map or alter mission checkpoints.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
[env,cfg,~]=mmra_defaults('mountain_cluster_figure2_custom_5km');
assert(isfile(fullfile(root,'results_main_map','Figure2_user_settings.mat')));
cfg.maxIter=600;
cfg.wallBudget_s=Inf;
cfg.prune=false;cfg.smooth=false;
U=5;seed=24001;
[starts,goals]=mmra_5km_mission(env,U,seed,'cross_center');
names={'anytime','terrain_only','corridor_only','step_only','combined'};
switches=[0 0 0;1 0 0;0 1 0;0 0 1;1 1 1];
N=numel(names);
records=repmat(struct('uav',0,'seed',0,'mode','', ...
    'success',false,'objective_m',NaN,'length_m',NaN, ...
    'risk_m',NaN,'ascent_m',NaN,'runtime_s',NaN, ...
    'firstIter',NaN,'finalIter',NaN,'terrainSamples',0, ...
    'corridorSamples',0,'adaptedSteps',0),U*N,1);
idx=0;
fprintf('\n=== FIGURE 2 TERRAIN-ADAPTIVE ABLATION / %d routes ===\n',U);
for i=1:U
    for m=1:N
        idx=idx+1;
        trial=cfg;
        if m==1
            trial.rrtStopMode='anytime';
        else
            trial.rrtStopMode='terrain_adaptive';
            trial.taUseTerrainSampling=logical(switches(m,1));
            trial.taUseCorridorSampling=logical(switches(m,2));
            trial.taUseAdaptiveStep=logical(switches(m,3));
        end
        localSeed=seed+10007*i;
        rng(localSeed,'twister');t=tic;
        [p,s]=mmra_plan_single(starts(i,:),goals(i,:),env,trial,true);
        tElapsed=toc(t);
        r=records(idx);
        r.uav=i;r.seed=localSeed;r.mode=names{m};
        r.success=s.success;r.runtime_s=tElapsed;r.firstIter=s.firstIter;
        r.finalIter=s.iterations;
        if s.success
            assert(s.treeCostError<1e-6 && ...
                mmra_path_free(p,env,cfg.guardFineResolution), ...
                'Ablation path failed geometry audit');
            r.objective_m=s.pathObjective_m;
            r.length_m=s.pathLength;
            r.risk_m=s.pathRiskIntegral_m;
            r.ascent_m=s.pathAscent_m;
        end
        if m>1
            r.terrainSamples=s.taTerrainSamples;
            r.corridorSamples=s.taCorridorSamples;
            r.adaptedSteps=s.taAdaptedSteps;
        end
        records(idx)=r;
        fprintf('UAV %d %-14s success=%d J=%.2f time=%.2f s\n', ...
            i,names{m},s.success,r.objective_m,tElapsed);
    end
end
outDir=fullfile(root,'results_rrt_terrain_adaptive_dev');
if ~exist(outDir,'dir'),mkdir(outDir);end
summaryTable=struct2table(records);
save(fullfile(outDir,'figure2_rrt_terrain_ablation_5u.mat'), ...
    'summaryTable','records','names','switches','cfg','-v7');
writetable(summaryTable, ...
    fullfile(outDir,'figure2_rrt_terrain_ablation_5u.csv'));
fprintf('Ablation output saved: %s\n',outDir);
