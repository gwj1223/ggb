%RUN_DIAGNOSE_FIGURE2_BLANK Inspect current Figure 2 graphics state.
% Safe: does NOT modify any map, NFZ or obstacle settings.
f=findall(groot,'Type','figure','Number',2);
if isempty(f)
    fprintf('Figure 2 does not currently exist.\n');
else
    f=f(1);
    axesHandles=findall(f,'Type','axes');
    surfHandles=findall(f,'Type','surface');
    fprintf('Figure 2: visible=%s, renderer=%s, axes=%d, surfaces=%d\n', ...
        get(f,'Visible'),get(f,'Renderer'),numel(axesHandles),numel(surfHandles));
    fprintf('Figure name: %s\n',get(f,'Name'));
    for k=1:numel(axesHandles)
        ax=axesHandles(k);
        fprintf(' Axis %d: visible=%s, children=%d, position=[%s]\n', ...
            k,get(ax,'Visible'),numel(allchild(ax)),num2str(get(ax,'Position')));
    end
    for k=1:min(3,numel(surfHandles))
        h=surfHandles(k);
        z=get(h,'ZData');
        fprintf(' Surface %d: visible=%s, z-dims=[%s]\n', ...
            k,get(h,'Visible'),num2str(size(z)));
    end
    drawnow;
end
fprintf('Basic renderer test (optional): figure(99); surf(peaks(40)); drawnow;\n');
