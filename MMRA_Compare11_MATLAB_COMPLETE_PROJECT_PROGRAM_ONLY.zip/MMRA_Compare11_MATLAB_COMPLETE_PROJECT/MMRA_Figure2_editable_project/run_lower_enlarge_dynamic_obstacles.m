%RUN_LOWER_ENLARGE_DYNAMIC_OBSTACLES Safely update saved dynamic obstacles.
% This is an OPTIONAL one-time assistant for users of the slider editor.
% Leaves terrain, NFZ, static obstacles and existing RRT* paths untouched.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
[env,~,~]=mmra_defaults('mountain_cluster_figure2_custom_5km');
env=mmra_figure2_add_static_obstacles(env);
[original,info]=mmra_figure2_dynamic_obstacles(env);
[obstacles,report]=mmra_figure2_tune_dynamic_obstacles(original,env);
fprintf('Previous moving sphere source: %s\n',info.source);
for k=1:numel(obstacles)
    fprintf('D%d: radius %.0f -> %.0f m, lower by %.0f m | %s\n', ...
        k,report.oldRadius_m(k),report.newRadius_m(k), ...
        report.drop_m(k),report.note{k});
end
if report.changedCount==0
    fprintf(['No changes saved. Larger AND lower was not safe on these ' ...
        'XY tracks; move a track away from nearby peaks/NFZ first.\n']);
else
    targetFile=fullfile(root,'results_main_map', ...
        'Figure2_dynamic_obstacles_settings.mat');
    if ~exist(fileparts(targetFile),'dir')
        mkdir(fileparts(targetFile));
    end
    if isfile(targetFile)
        backupFile=[targetFile '.backup_' datestr(now,'yyyymmdd_HHMMSSFFF')];
        [ok,msg]=copyfile(targetFile,backupFile);
        assert(ok,'Unable to back up saved dynamic settings: %s',msg);
        fprintf('Backup: %s\n',backupFile);
    end
    dynamicParams=struct('obstacles',obstacles, ...
        'revision',datestr(now,'yyyymmdd_HHMMSSFFF'));
    save(targetFile,'dynamicParams','-v7');
    [check,meta]=mmra_figure2_dynamic_obstacles(env);
    for k=1:numel(check)
        assert(isequal(check(k).position_m,obstacles(k).position_m) ...
            && check(k).radius_m==obstacles(k).radius_m, ...
            'Saved dynamic settings failed the reload check.');
    end
    fprintf('Saved %d adjusted sphere(s): %s (%s)\n', ...
        report.changedCount,targetFile,meta.source);
end
fprintf(['Run run_main_map_dynamic_obstacles.m to see striped spheres, ' ...
    'or run_main_map_editor for further edits.\n']);
