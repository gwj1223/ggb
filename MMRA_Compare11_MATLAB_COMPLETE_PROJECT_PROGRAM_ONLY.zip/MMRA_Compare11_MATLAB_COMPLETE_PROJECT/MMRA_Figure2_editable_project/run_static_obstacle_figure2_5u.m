%RUN_STATIC_OBSTACLE_FIGURE2_5U Fresh obstacle-aware 3-objective RRT*.
% Old cached trajectories MUST NOT be reused as obstacle-free evidence.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
[env,cfg,sched]=mmra_defaults('mountain_cluster_figure2_custom_5km');
env=mmra_figure2_add_static_obstacles(env);
[starts,goals,meta]=mmra_5km_mission(env,5,24001,'cross_center');
cfg.rrtStopMode='terrain_adaptive';
cfg.maxIter=1200;
% Match the last terrain-adaptive study's 3-objective cost definition.
assert(strcmp(cfg.costMode,'length_risk_climb'));
paths=cell(5,1);records=struct('success',{},'reason',{}, ...
    'length_m',{},'risk_m',{},'climb_m',{},'objective_m',{}, ...
    'minTerrainClearance_m',{},'elapsed_s',{});
rng(24001,'twister');
for i=1:5
    [p,st]=mmra_plan_single(starts(i,:),goals(i,:),env,cfg,true);
    paths{i}=p;
    records(i).success=logical(st.success);
    records(i).reason=char(st.reason);
    records(i).elapsed_s=st.total_s;
    records(i).length_m=NaN;
    records(i).risk_m=NaN;
    records(i).climb_m=NaN;
    records(i).objective_m=NaN;
    records(i).minTerrainClearance_m=NaN;
    if st.success
        % Cross-check both node/edge exclusions after all post-processing.
        assert(mmra_path_free(p,env,cfg.guardFineResolution), ...
            'Returned path intersects a buffered static exclusion.');
        assert(all(mmra_no_fly_free(p,env)));
        records(i).length_m=mmra_path_length(p);
        records(i).risk_m=mmra_path_risk(p,env, ...
            cfg.riskCostBand_m,cfg.riskCostResolution_m);
        records(i).climb_m=mmra_path_ascent(p);
        records(i).objective_m=st.finalObjective_m;
        records(i).minTerrainClearance_m= ...
            mmra_path_clearance(p,env,cfg.guardFineResolution);
    end
    fprintf('UAV %d: success=%d, reason=%s, J=%.2f, time=%.2f s\n', ...
        i,st.success,st.reason,records(i).objective_m,st.total_s);
end
outDir=fullfile(root,'results_static_obstacles_dev');
if ~exist(outDir,'dir'),mkdir(outDir);end
save(fullfile(outDir,'Figure2_static_obstacle_rrt_5u.mat'), ...
    'env','cfg','sched','starts','goals','meta','paths','records','-v7');
fig=mmra_plot_single_main_map(env,starts,goals);
colors=lines(5);
for i=1:5
    p=paths{i};
    if ~isempty(p)
        plot3(p(:,1)/1000,p(:,2)/1000,p(:,3)/1000,'-', ...
            'Color',colors(i,:),'LineWidth',2, ...
            'HandleVisibility','off');
    end
end
saveas(fig,fullfile(outDir,'Figure2_static_obstacle_planned_paths_5u.png'));
fprintf('Fresh obstacle-aware RRT*: %d/5 successful.\n', ...
    sum([records.success]));
fprintf('Output directory: %s\n',outDir);
fprintf('No prior cached paths or map settings were overwritten.\n');
