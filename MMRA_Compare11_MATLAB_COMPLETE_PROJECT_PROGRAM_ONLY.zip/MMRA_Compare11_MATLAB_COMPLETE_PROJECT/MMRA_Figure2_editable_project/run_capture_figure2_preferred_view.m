%RUN_CAPTURE_FIGURE2_PREFERRED_VIEW
% OPTIONAL: run with the ORIGINAL global-XY Figure 2 in front, after
% rotating it to the desired paper viewpoint. Preserves exact az/el.
% Do this BEFORE close all or running the new local plotting script.
root = fileparts(mfilename('fullpath'));
fig = get(groot,'CurrentFigure');
assert(~isempty(fig) && isgraphics(fig,'figure'), ...
    'First click the existing global Figure 2 with your preferred view.');
ax = get(fig,'CurrentAxes');
assert(~isempty(ax) && isgraphics(ax,'axes'), ...
    'Active figure must have an actual 3-D terrain axes.');
% With TWO outputs view(ax) returns azimuth and elevation.
% With ONE output it returns a 4x4 transform matrix (not [az el]).
[az,el] = view(ax);
viewGlobalAzEl = [az,el];
assert(isnumeric(viewGlobalAzEl) && numel(viewGlobalAzEl)==2 && ...
    all(isfinite(viewGlobalAzEl)), 'Invalid camera azimuth/elevation.');
outDir = fullfile(root,'results_common_base_origin_dev');
if ~exist(outDir,'dir'), mkdir(outDir); end
outFile = fullfile(outDir,'Figure2_preferred_global_view.mat');
save(outFile,'viewGlobalAzEl');
fprintf('Saved original global-XY view = [%.2f %.2f] deg\n',viewGlobalAzEl);
fprintf('When plotted in the rotated local frame, azimuth is adjusted -90 deg.\n');
fprintf('View file: %s\n',outFile);
