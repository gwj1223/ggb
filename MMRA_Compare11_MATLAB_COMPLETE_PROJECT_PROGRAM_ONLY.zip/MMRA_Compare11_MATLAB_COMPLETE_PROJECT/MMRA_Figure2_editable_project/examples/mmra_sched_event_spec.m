function s=mmra_sched_event_spec()
%MMRA_SCHED_EVENT_SPEC LOCKED experimental settings; development cohort.
s=mmra_sched_repair_spec();
s.protocolID='MMRA_EVENT_WINDOW_DEV_20261029_A';
s.pathSourceProtocolID='MMRA_SCHED_REPAIR_DEV_20261029_A';
s.eventBeamWidth=12;
s.eventMaxExpandedNodes=450;
s.eventMaxDelayChoices=8;
s.eventMaxVariableChoices=2;
s.eventMaxVerifyCandidates=12;
s.maxWallRatio=4.0;
s.bootstrapB=1500;
s.bootstrapSeed=51017;
end
