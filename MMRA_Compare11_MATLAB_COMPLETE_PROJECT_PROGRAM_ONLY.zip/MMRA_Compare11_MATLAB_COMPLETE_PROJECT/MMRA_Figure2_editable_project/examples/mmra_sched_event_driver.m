function mmra_sched_event_driver(root,only20)
%MMRA_SCHED_EVENT_DRIVER Compare three schedulers on PREVIOUSLY SAVED paths.
% No RRT*, no APF, no terrain planning, and no change to original results.
% 20-UAV pilot is resumable; the full 180-case test reuses its checkpoints.
if nargin<2,only20=true;end
s=mmra_sched_event_spec();
caseDir=fullfile(root,'results_scheduler_repair_dev','path_cases');
assert(isfolder(caseDir), ...
    ['Saved original RRT* paths were not found: %s\n' ...
    'Copy the patch into the original MMRA_Unified_MATLAB_v2_1_scheduler ' ...
    'project root (with results_scheduler_repair_dev/path_cases). ' ...
    'Do not re-run RRT* or change scheduler occupancy rules.'],caseDir);
outDir=fullfile(root,'results_scheduler_eventwindow_dev');
partDir=fullfile(outDir,'checkpoints');
if ~isfolder(partDir),mkdir(partDir);end
lock=fullfile(outDir,'PROTOCOL_LOCK.txt');
if isfile(lock)
    contents=fileread(lock);
    assert(contains(contents,s.protocolID), ...
        'Different protocol detected; do not mix event-window checkpoints.');
else
    f=fopen(lock,'w');assert(f>0);
    fprintf(f,'%s\n',s.protocolID);
    fprintf(f,'Development on previously used MMRA v2.1 scheduler seeds.\n');
    fprintf(f,'Original spatial paths: %s\n',caseDir);
    fprintf(f,'Same hold/hold, speed=15, dSafe=10, delay grid=0:0.25:60.\n');
    fprintf(f,'Event-window cache + endpoint graph + bounded beam.\n');
    fprintf(f,'B=%d, expanded=%d, delay choices=%d, variable choices=%d, verified=%d.\n', ...
        s.eventBeamWidth,s.eventMaxExpandedNodes,s.eventMaxDelayChoices, ...
        s.eventMaxVariableChoices,s.eventMaxVerifyCandidates);
    fprintf(f,'All comparisons use same saved fixed paths, no RRT* replanning.\n');
    fprintf(f,'Core MATLAB; no optimality, physical robustness or speedup claim.\n');
    fclose(f);
end
if only20,sizes=20;else,sizes=s.sizes;end
fprintf('=== EVENT-WINDOW SCHEDULER: existing paths ONLY ===\n');
fprintf('Path source: %s\n',caseDir);
fprintf('UAV sizes: %s; %d saved seeds per terrain-size.\n', ...
    mat2str(sizes),s.nTrials);
fprintf('Preserving fixed 15 m/s, 10 m safety, 0:0.25:60 s, HOLD/HOLD.\n');

for ie=1:numel(s.terrains)
    terrain=s.terrains{ie};
    [~,~,opt]=mmra_defaults(terrain);
    opt.speed=s.speed_mps;opt.dSafe=s.dSafe_m;
    opt.delayStep=s.delayStep_s;opt.maxDelay=s.maxDelay_s;
    opt.startPolicy=s.startPolicy;opt.endPolicy=s.endPolicy;
    opt.repairMaxCandidates=s.repairMaxCandidates;
    opt.repairMaxRounds=s.repairMaxRounds;
    opt.eventBeamWidth=s.eventBeamWidth;
    opt.eventMaxExpandedNodes=s.eventMaxExpandedNodes;
    opt.eventMaxDelayChoices=s.eventMaxDelayChoices;
    opt.eventMaxVariableChoices=s.eventMaxVariableChoices;
    opt.eventMaxVerifyCandidates=s.eventMaxVerifyCandidates;
    for ni=1:numel(sizes)
        n=sizes(ni);
        for rep=1:s.nTrials
            seed=930000+10000*ie+100*n+rep;
            stamp=sprintf('%s_u%d_seed%d',terrain,n,seed);
            caseFile=fullfile(caseDir,['case_' stamp '.mat']);
            partFile=fullfile(partDir,['part_' stamp '.csv']);
            assert(isfile(caseFile), ...
                'Missing SAVED spatial case: %s (no replanning performed).',caseFile);
            if isfile(partFile)
                existing=readtable(partFile);
                assert(height(existing)==1 && ...
                    all(strcmp(string(existing.ProtocolID),string(s.protocolID))) && ...
                    existing.Seed(1)==seed && existing.NumUAV(1)==n, ...
                    'Invalid event-window checkpoint: %s',partFile);
                continue;
            end
            a=load(caseFile,'caseData');c=a.caseData;
            assert(strcmp(c.ProtocolID,s.pathSourceProtocolID) && ...
                c.Seed==seed && c.NumUAV==n && ...
                strcmp(c.Terrain,terrain), ...
                'Cached spatial case does not match original protocol.');
            row=struct('ProtocolID',s.protocolID,'Terrain',terrain, ...
                'NumUAV',double(n),'Seed',double(seed), ...
                'SpatialOK',logical(c.SpatialOK), ...
                'CAOK',false,'RepairOK',false,'WindowOK',false, ...
                'CAMakespan_s',NaN,'RepairMakespan_s',NaN, ...
                'WindowMakespan_s',NaN, ...
                'CAWall_s',NaN,'RepairWall_s',NaN,'WindowWall_s',NaN, ...
                'CAMinSep_m',NaN,'RepairMinSep_m',NaN, ...
                'WindowMinSep_m',NaN, ...
                'CAMaxDelay_s',NaN,'RepairMaxDelay_s',NaN, ...
                'WindowMaxDelay_s',NaN, ...
                'InitialConflicts',NaN, ...
                'WindowStrategy','not_run', ...
                'WindowCacheWall_s',NaN,'WindowSearchWall_s',NaN, ...
                'WindowExpandedNodes',NaN, ...
                'WindowVerifiedSchedules',NaN, ...
                'WindowFalseSafeCandidates',NaN, ...
                'WindowNoCompatiblePairs',NaN, ...
                'WindowRouteNearGoalN',NaN);
            if c.SpatialOK
                paths=c.Paths;
                assert(iscell(paths) && numel(paths)==n, ...
                    'Unexpected paths in %s',caseFile);
                clock=tic;ca=mmra_schedule_conflict_aware(paths,opt);
                row.CAWall_s=toc(clock);
                clock=tic;repair=mmra_schedule_bottleneck(paths,opt);
                row.RepairWall_s=toc(clock);
                clock=tic;new=mmra_schedule_eventwindow(paths,opt);
                row.WindowWall_s=toc(clock);
                assert(~ca.success || (repair.success && ...
                    repair.makespan<=ca.makespan+1e-8), ...
                    'Original bounded repair fallback was violated.');
                assert(~ca.success || (new.success && ...
                    new.makespan<=ca.makespan+1e-8), ...
                    'Event-window fallback lost a feasible CA schedule.');
                if new.success
                    assert(new.postConflicts==0 && ...
                        new.minSeparation>=s.dSafe_m-opt.tol-1e-8);
                end
                row.CAOK=ca.success;
                row.RepairOK=repair.success;
                row.WindowOK=new.success;
                row.CAMakespan_s=ca.makespan;
                row.RepairMakespan_s=repair.makespan;
                row.WindowMakespan_s=new.makespan;
                row.CAMinSep_m=ca.minSeparation;
                row.RepairMinSep_m=repair.minSeparation;
                row.WindowMinSep_m=new.minSeparation;
                if ca.success,row.CAMaxDelay_s=max(ca.delays);end
                if repair.success,row.RepairMaxDelay_s=max(repair.delays);end
                if new.success,row.WindowMaxDelay_s=max(new.delays);end
                row.InitialConflicts=ca.preConflicts;
                row.WindowStrategy=new.eventStrategy;
                row.WindowCacheWall_s=new.eventCacheWall_s;
                row.WindowSearchWall_s=new.eventSearchWall_s;
                row.WindowExpandedNodes=new.eventExpandedNodes;
                row.WindowVerifiedSchedules=new.eventVerifiedSchedules;
                row.WindowFalseSafeCandidates=new.eventCacheFalseSafeN;
                row.WindowNoCompatiblePairs=new.eventNoCompatiblePairs;
                row.WindowRouteNearGoalN=new.eventRouteNearGoalN;
            end
            tmp=fullfile(partDir,['tmp_part_' stamp '.csv']);
            writetable(struct2table(row),tmp);
            [ok,msg]=movefile(tmp,partFile);
            assert(ok,'Cannot finalize checkpoint: %s',msg);
            if mod(rep,5)==0 || rep==s.nTrials
                fprintf('SAVED %s / U=%d / %d of %d cases.\n', ...
                    terrain,n,rep,s.nTrials);
            end
        end
    end
end
mmra_sched_event_report(root,only20);
end
