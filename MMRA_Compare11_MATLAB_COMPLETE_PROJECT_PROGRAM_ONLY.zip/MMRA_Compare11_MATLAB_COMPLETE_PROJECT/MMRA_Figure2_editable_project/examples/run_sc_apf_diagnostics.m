%RUN_SC_APF_DIAGNOSTICS Actual-sampling APF attribution (NOT runtime study).
% Reruns original first 5 seeds plus 5 new seeds with same terrain/paths.
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'));
profiles={'paper_gmm','legacy20_sine'};
variants={'MMRA_legacy_APF','MMRA_SC_APF'};
seeds=12001:12010;
rows=struct([]);
for ip=1:numel(profiles)
    for is=1:numel(seeds)
        for iv=1:numel(variants)
            row=mmra_sc_trial(profiles{ip},seeds(is),variants{iv},struct(),false,true);
            if isempty(rows),rows=row;else,rows(end+1,1)=row;end %#ok<SAGROW>
        end
    end
    fprintf('Completed diagnostic sampling on %s\n',profiles{ip});
end
T=struct2table(rows);
outDir=fullfile(root,'results_sc_apf_v13');
if ~exist(outDir,'dir'),mkdir(outDir);end
writetable(T,fullfile(outDir,'sc_apf_diagnostic_trials.csv'));
for ip=1:numel(profiles)
    for iv=1:numel(variants)
        j=strcmp(T.Terrain,profiles{ip}) & strcmp(T.Variant,variants{iv});
        fprintf('%s / %s: active=%.1f%% nearSafety=%.1f%% ', ...
            profiles{ip},variants{iv},100*mean(T.ActiveFraction(j)), ...
            100*mean(T.NearSafetyFraction(j)));
        fprintf('rep/att=%.3f angleVsLegacy=%.2f deg\n', ...
            mean(T.RepulsionAttractionRatio(j)),mean(T.AngleFromLegacy_deg(j)));
    end
end
fprintf('Diagnostic instrumentation changes wall-clock timings.\n');
fprintf('Use the separate non-instrumented validation script for runtime.\n');
