%RUN_GUARDED_SC_FINAL_EVAL Fixed-parameter guarded SC versus same-seed baselines.
% No tuning or selection based on the evaluation data. A final status CSV
% and a machine-readable per-seed CSV are written without extra toolboxes.
% SC parameters are historical development candidate #3 (4,4,30).
% 16001:16050 were RESERVED and not run by v1.5 (all candidates failed).
% 19001:19030 are separate hard-scenario seeds. Do not retune on them.
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'));
outDir=fullfile(root,'results_guarded_sc_v17');
if ~exist(outDir,'dir'),mkdir(outDir);end
% Incomplete reruns are labeled, preventing stale tables from appearing final.
statusPath=fullfile(outDir,'RUN_STATUS.txt');
f=fopen(statusPath,'w');
assert(f>0,'Cannot create status marker');
fprintf(f,'IN_PROGRESS\n');fclose(f);
profiles={'paper_gmm','legacy20_sine'};
variants={'RRTstar_unguided','MMRA_legacy_APF','MMRA_SC_APF','MMRA_guarded_SC_APF'};
seedGroups={16001:16050,19001:19030};
hardGroups=[false true];
rows=struct([]);
runClock=tic;
for ih=1:numel(hardGroups)
    for ip=1:numel(profiles)
        profile=profiles{ip};
        hard=hardGroups(ih);
        [env,cfg,startPos,goalPos]=mmra_sc_case(profile,hard);
        cfg.scSafeBand=4;cfg.scSoftWidth=4;cfg.scKRep=30;
        cfg.collectApfDiagnostics=false;
        assert(abs(cfg.edgeResolution-0.25)<1e-12);
        for is=1:numel(seedGroups{ih})
            seed=seedGroups{ih}(is);
            for iv=1:numel(variants)
                name=variants{iv};
                cfgRun=cfg;
                guided=~strcmp(name,'RRTstar_unguided');
                if strcmp(name,'MMRA_SC_APF')
                    cfgRun.apfMode='sc_apf';
                elseif strcmp(name,'MMRA_guarded_SC_APF')
                    cfgRun.apfMode='guarded_sc';
                else
                    cfgRun.apfMode='legacy';
                end
                rng(seed,'twister');
                perCall=tic;
                [path,st]=mmra_plan_single(startPos,goalPos,env,cfgRun,guided);
                callWall_s=toc(perCall);
                mClear=NaN;
                if st.success
                    [mClear,~]=mmra_path_clearance(path,env,0.10);
                end
                reason=st.reason;
                chosen='n/a';guardReason='n/a';
                baseSearch=NaN;scSearch=NaN;
                if strcmp(name,'MMRA_guarded_SC_APF')
                    chosen=st.chosenMode;
                    guardReason=st.guardDecision;
                    baseSearch=st.LegacySearch_s;
                    scSearch=st.SCSearch_s;
                end
                rej=NaN;
                if (st.accepted+st.rejected)>0
                    rej=st.rejected/(st.accepted+st.rejected);
                end
                row=struct('Terrain',profile,'Hard',logical(hard), ...
                    'Variant',name,'Seed',seed,'Success',logical(st.success), ...
                    'Path_m',st.pathLength,'FullWall_s',callWall_s, ...
                    'ReportedTotal_s',st.total_s,'SearchAll_s',st.search_s,'FirstIterChosen',st.firstIter, ...
                    'RejectFractionChosen',rej, ...
                    'MinClearFine_m',mClear, ...
                    'ChosenMode',chosen,'GuardDecision',guardReason, ...
                    'LegacySearch_s',baseSearch,'SCSearch_s',scSearch, ...
                    'FailureReason',reason);
                if isempty(rows),rows=row;
                else,rows(end+1,1)=row;end %#ok<SAGROW>
            end
        end
        fprintf('Completed %s / hard=%d / %d seeds.\n', ...
            profile,hard,numel(seedGroups{ih}));
    end
end
T=struct2table(rows);
writetable(T,fullfile(outDir,'guarded_sc_trials.csv'));
summary=struct([]);
for ih=1:numel(hardGroups)
    for ip=1:numel(profiles)
        for iv=1:numel(variants)
            idx=strcmp(T.Terrain,profiles{ip}) & ...
                T.Hard==hardGroups(ih) & strcmp(T.Variant,variants{iv});
            q=T(idx,:);okay=logical(q.Success);
            meanPath=NaN;meanClear=NaN;minClear=NaN;
            if any(okay)
                meanPath=mean(q.Path_m(okay));
                meanClear=mean(q.MinClearFine_m(okay));
                minClear=min(q.MinClearFine_m(okay));
            end
            meanRej=NaN;
            validRej=isfinite(q.RejectFractionChosen);
            if any(validRej),meanRej=mean(q.RejectFractionChosen(validRej));end
            entry=struct('Terrain',profiles{ip},'Hard',hardGroups(ih), ...
                'Variant',variants{iv},'N',height(q), ...
                'SuccessN',sum(okay),'SuccessRate',mean(double(okay)), ...
                'MeanPath_m',meanPath,'MeanMinClearFine_m',meanClear, ...
                'WorstMinClearFine_m',minClear, ...
                'MeanFullWall_s',mean(q.FullWall_s), ...
                'MeanRejectFractionChosen',meanRej);
            if isempty(summary),summary=entry;
            else,summary(end+1,1)=entry;end %#ok<SAGROW>
        end
    end
end
S=struct2table(summary);
writetable(S,fullfile(outDir,'guarded_sc_summary.csv'));

% No hidden selection: verify the stated per-seed guard from the SAVED rows.
checks=struct([]);
for ih=1:numel(hardGroups)
    for ip=1:numel(profiles)
        idx=strcmp(T.Terrain,profiles{ip}) & T.Hard==hardGroups(ih);
        B=sortrows(T(idx & strcmp(T.Variant,'MMRA_legacy_APF'),:),'Seed');
        G=sortrows(T(idx & strcmp(T.Variant,'MMRA_guarded_SC_APF'),:),'Seed');
        assert(height(B)==height(G) && isequal(B.Seed,G.Seed), ...
            'Baseline and guarded seeds not aligned');
        baseFine=B.Success & isfinite(B.MinClearFine_m) & B.MinClearFine_m>=1e-6;
        good=G.Success & isfinite(G.MinClearFine_m) & G.MinClearFine_m>=1e-6;
        missing=sum(baseFine & ~good);
        paired=baseFine & good;
        pathWorse=sum(G.Path_m(paired)>B.Path_m(paired)+1e-7);
        clearWorse=sum(G.MinClearFine_m(paired)<B.MinClearFine_m(paired)-0.25-1e-8);
        countSC=sum(strcmp(G.ChosenMode,'sc_apf'));
        countBaseline=sum(strcmp(G.ChosenMode,'legacy'));
        avgDeltaPath=NaN;avgDeltaClear=NaN;
        if any(paired)
            avgDeltaPath=mean(G.Path_m(paired)-B.Path_m(paired));
            avgDeltaClear=mean(G.MinClearFine_m(paired)-B.MinClearFine_m(paired));
        end
        wallRatio=mean(G.FullWall_s)/mean(B.FullWall_s);
        assert(missing==0 && pathWorse==0 && clearWorse==0, ...
            'Guarded planner output invariant failed on evaluated seeds');
        e=struct('Terrain',profiles{ip},'Hard',hardGroups(ih), ...
            'N',height(B),'LegacyFineValidN',sum(baseFine), ...
            'GuardFineValidN',sum(good),'GuardSelectSC_N',countSC, ...
            'GuardFallbackLegacy_N',countBaseline, ...
            'PairedMeanPathDelta_m',avgDeltaPath, ...
            'PairedMeanClearDelta_m',avgDeltaClear, ...
            'MeanFullWallRatioToLegacy',wallRatio, ...
            'LegacyFineValidButGuardFailedN',missing, ...
            'GuardPathWorseThanLegacyN',pathWorse, ...
            'GuardClearLossAbove0p25mN',clearWorse);
        if isempty(checks),checks=e;else,checks(end+1,1)=e;end %#ok<SAGROW>
    end
end
C=struct2table(checks);
writetable(C,fullfile(outDir,'guarded_sc_invariant_checks.csv'));

disp(S);
disp(C);
report=fullfile(outDir,'RUN_SUMMARY.txt');
fid=fopen(report,'w');
assert(fid>0,'Failed to write final run summary');
fprintf(fid,'MMRA v1.7 Guarded SC-APF: fixed-parameter independent evaluation\n');
fprintf(fid,'Core RRT* + both APF equations unchanged; prior seed selection is not re-run.\n');
fprintf(fid,'SC: scSafeBand=4, scSoftWidth=4, scKRep=30 (development candidate).\n');
fprintf(fid,'Planner edge checks 0.25m; post checks 0.10m. No continuous certificate.\n');
fprintf(fid,'Guard: candidate nonlonger, min clearance >= legacy minus 0.25m.\n');
fprintf(fid,'Both searches executed: FullWall_s includes both search costs.\n');
fprintf(fid,'Reserved seeds 16001:16050; hard seeds 19001:19030.\n');
fprintf(fid,'Run time for this evaluation: %.2f s.\n',toc(runClock));
fprintf(fid,'No additional parameter tuning was performed on evaluation seeds.\n');
fclose(fid);
f=fopen(statusPath,'w');
assert(f>0,'Cannot write completion marker');
fprintf(f,'SUCCESS: ALL INVARIANTS CHECKED\n');fclose(f);
fprintf('SUCCESS: wrote CSV summaries to %s\n',outDir);
fprintf('CAUTION: paired output guard is by construction, not a global\n');
fprintf('search optimality guarantee or proof that SC-APF alone is superior.\n');
