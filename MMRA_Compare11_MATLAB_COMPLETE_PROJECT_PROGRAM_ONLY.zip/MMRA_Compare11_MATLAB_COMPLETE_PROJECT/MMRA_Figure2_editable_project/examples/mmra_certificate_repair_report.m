function mmra_certificate_repair_report(root,only20)
%MMRA_CERTIFICATE_REPAIR_REPORT REPORT ONLY; never invokes planning/scheduling.
if nargin<2,only20=true;end
s=mmra_certificate_repair_spec();
if only20,sizes=20;tag='20u';else,sizes=s.sizes;tag='all';end
outDir=fullfile(root,'results_certificate_spatial_repair_dev');
partDir=fullfile(outDir,'checkpoints');
assert(isfolder(partDir),'No saved checkpoints: %s',partDir);
T=table();missing=0;
for ie=1:numel(s.terrains)
    terrain=s.terrains{ie};
    for n=reshape(sizes,1,[])
        for rep=1:s.nTrials
            seed=930000+10000*ie+100*n+rep;
            name=sprintf('part_%s_u%d_seed%d.csv',terrain,n,seed);
            fp=fullfile(partDir,name);
            if ~isfile(fp),missing=missing+1;continue;end
            row=readtable(fp);
            assert(height(row)==1 && ...
                all(strcmp(string(row.ProtocolID),string(s.protocolID))) && ...
                all(strcmp(string(row.Terrain),string(terrain))) && ...
                row.NumUAV(1)==n && row.Seed(1)==seed, ...
                'Invalid checkpoint or mismatched protocol: %s',fp);
            if isempty(T),T=row;else,T=[T;row];end %#ok<AGROW>
        end
    end
end
assert(~isempty(T),'No saved trial rows in %s',partDir);
writetable(T,fullfile(outDir,['certificate_repair_trials_' tag '.csv']));
summaryRows=struct([]);gateRows=struct([]);
for ie=1:numel(s.terrains)
    terrain=s.terrains{ie};
    for n=reshape(sizes,1,[])
        g=T(strcmp(string(T.Terrain),string(terrain)) & ...
            T.NumUAV==n,:);
        if isempty(g),continue;end
        spatial=localLogical(g.SpatialOK);
        baseline=localLogical(g.BaselineOK);
        feedback=localLogical(g.FeedbackOK);
        assert(~any((baseline|feedback)&~spatial), ...
            'Scheduling success without valid original paths.');
        assert(~any(baseline&~feedback), ...
            'Spatial-feedback method lost a baseline feasible schedule.');
        [bL,bU]=localWilson(sum(baseline),height(g));
        [fL,fU]=localWilson(sum(feedback),height(g));
        rescue=~baseline & feedback;
        score=double(feedback)-double(baseline);
        [gainL,gainU]=localBootMean(score,s.bootstrapB, ...
            s.bootstrapSeed+200*ie+n);
        initial=g.OriginalGridCertificates;
        finish=g.FinalGridCertificates;
        reduction=max(0,initial-finish);
        fixed=initial>0 & finish==0;
        hadCert=initial>0;
        madeRepair=g.AcceptedRepairsN>0;
        paired=baseline & feedback;
        timeGain=g.BaselineMakespan_s(paired)- ...
            g.FeedbackMakespan_s(paired);
        [makesL,makesU]=localBootMean(timeGain,s.bootstrapB, ...
            s.bootstrapSeed+201*ie+n);
        ratio=localFiniteMean(g.FeedbackWall_s(spatial) ./ ...
            max(g.BaselineWall_s(spatial),eps));
        validScore=all(g.FineClearanceMin_m(spatial)>=s.minFineClear_m) && ...
            all(isfinite(g.FineClearanceMin_m(spatial)));
        data=struct('Terrain',terrain,'NumUAV',double(n), ...
            'Cases',height(g),'SpatialValidN',sum(spatial), ...
            'BaselineSuccessN',sum(baseline), ...
            'FeedbackSuccessN',sum(feedback), ...
            'RescuedFullSchedulesN',sum(rescue), ...
            'BaselineSuccessRate',sum(baseline)/height(g), ...
            'FeedbackSuccessRate',sum(feedback)/height(g), ...
            'BaselineSuccessCI95_L',bL,'BaselineSuccessCI95_U',bU, ...
            'FeedbackSuccessCI95_L',fL,'FeedbackSuccessCI95_U',fU, ...
            'PairedSuccessDelta',mean(score), ...
            'PairedSuccessDeltaCI95_L',gainL, ...
            'PairedSuccessDeltaCI95_U',gainU, ...
            'OriginalGridCertifiedCasesN',sum(hadCert), ...
            'AnyCertificateReductionN',sum(reduction>0), ...
            'AllOriginalCertificatesClearedN',sum(fixed), ...
            'MeanCertificatesBefore',localFiniteMean(initial(spatial)), ...
            'MeanCertificatesAfter',localFiniteMean(finish(spatial)), ...
            'MeanCertificatesReduced',localFiniteMean(reduction(spatial)), ...
            'AnyPathRepairCasesN',sum(madeRepair), ...
            'MeanRepairedPathsN',localFiniteMean(g.RepairedPathsN(spatial)), ...
            'MeanAcceptedRepairsN',localFiniteMean(g.AcceptedRepairsN(spatial)), ...
            'MeanLengthDelta_m',localFiniteMean(g.PathLengthDelta_m(spatial)), ...
            'MeanRiskDelta_m',localFiniteMean(g.RiskDelta_m(spatial)), ...
            'MeanAscentDelta_m',localFiniteMean(g.AscentDelta_m(spatial)), ...
            'MeanBaselineWall_s',localFiniteMean(g.BaselineWall_s(spatial)), ...
            'MeanFeedbackWall_s',localFiniteMean(g.FeedbackWall_s(spatial)), ...
            'FeedbackToBaselineWallRatio',ratio, ...
            'MeanPairedMakespanGain_s',localFiniteMean(timeGain), ...
            'MakespanGainCI95_L_s',makesL,'MakespanGainCI95_U_s',makesU, ...
            'MeanFeedbackMakespanIfSuccess_s', ...
            localFiniteMean(g.FeedbackMakespan_s(feedback)));
        if isempty(summaryRows),summaryRows=data;
        else,summaryRows(end+1,1)=data;end %#ok<AGROW>
        protocolOK=validScore && ~any(baseline&~feedback);
        evidenceOK=any(reduction>0);
        fullRescueOK=any(rescue);
        costOK=isfinite(ratio) && ratio<=s.maxPilotWallRatio;
        gate=struct('Terrain',terrain,'NumUAV',double(n), ...
            'OriginalGeometryFineValid',logical(validScore), ...
            'BaselineScheduleRetained',logical(~any(baseline&~feedback)), ...
            'GridCertificateReductionObserved',logical(evidenceOK), ...
            'AnyNewFullSchedule',logical(fullRescueOK), ...
            'ComputeBudgetOK',logical(costOK), ...
            'DevGatePass',logical(protocolOK && evidenceOK && ...
                fullRescueOK && costOK));
        if isempty(gateRows),gateRows=gate;
        else,gateRows(end+1,1)=gate;end %#ok<AGROW>
    end
end
summary=struct2table(summaryRows);gates=struct2table(gateRows);
writetable(summary,fullfile(outDir, ...
    ['certificate_repair_summary_' tag '.csv']));
writetable(gates,fullfile(outDir, ...
    ['certificate_repair_gates_' tag '.csv']));
fprintf('\n=== CERTIFICATE-GUIDED SPATIAL REPAIR SUMMARY ===\n');disp(summary);
fprintf('\n=== PREDECLARED DEVELOPMENT GATES ===\n');disp(gates);
expected=numel(s.terrains)*numel(sizes)*s.nTrials;
fprintf('Saved %d/%d comparisons; %d missing.\n',height(T),expected,missing);
if missing==0
    fprintf('DEV GATES: %d/%d passed.\n', ...
        sum(gates.DevGatePass),height(gates));
else
    fprintf('PARTIAL. Do not interpret as a completed benchmark.\n');
end
status=fullfile(outDir,['RUN_STATUS_' tag '.txt']);
f=fopen(status,'w');assert(f>0);
fprintf(f,'Protocol: %s\n',s.protocolID);
fprintf(f,'Completed: %d/%d. Missing: %d.\n',height(T),expected,missing);
fprintf(f,'No RRT* replanning; original cached cases untouched.\n');
fprintf(f,'The feedback method CHANGES spatial paths, unlike pure timing baselines.\n');
fprintf(f,'HOLD/HOLD, 15 m/s, 10 m, 0:0.25:60 s fixed.\n');
fprintf(f,'Pairwise GRID certificates do not prove continuous real-time infeasibility.\n');
fprintf(f,'Clearing ALL pair certificates does NOT prove joint multi-UAV feasibility.\n');
fprintf(f,'Makespan comparison is defined only for BOTH methods successful.\n');
fprintf(f,'This is REUSED DEVELOPMENT data, not a new holdout.\n');
fprintf(f,'All geometry validated with 0.10m sampling, not continuous proof.\n');
fclose(f);
end

function b=localLogical(raw)
if islogical(raw)
    b=raw(:);
elseif isnumeric(raw)
    assert(all(isfinite(raw(:)) & (raw(:)==0 | raw(:)==1)));
    b=(raw(:)==1);
else
    s=lower(strtrim(string(raw(:))));
    assert(all(s=="true" | s=="false" | s=="1" | s=="0"));
    b=(s=="true" | s=="1");
end
b=logical(b(:));
end

function m=localFiniteMean(x)
x=x(isfinite(x));
if isempty(x),m=NaN;else,m=mean(x);end
end

function [lo,hi]=localBootMean(x,B,seed)
x=x(isfinite(x));n=numel(x);
if n==0,lo=NaN;hi=NaN;return;end
if n==1,lo=x;hi=x;return;end
state=rng;rng(seed,'twister');vals=zeros(B,1);
for k=1:B
    vals(k)=mean(x(randi(n,n,1)));
end
rng(state);
vals=sort(vals);
lo=vals(max(1,ceil(B*0.025)));
hi=vals(min(B,ceil(B*0.975)));
end

function [lo,hi]=localWilson(k,n)
if n<=0,lo=NaN;hi=NaN;return;end
z=1.95996398454005;p=k/n;
a=(p+z^2/(2*n))/(1+z^2/n);
b=z*sqrt(p*(1-p)/n+z^2/(4*n^2))/(1+z^2/n);
lo=max(0,a-b);hi=min(1,a+b);
end
