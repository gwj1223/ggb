function mmra_speed_feedback_cached_driver(root,sizes,pathCasesFolder,repairedPathsFolder,seeds)
%MMRA_SPEED_FEEDBACK_CACHED_DRIVER Fair DEV replay using EXISTING RRT* paths.
% Uses same ORIGINAL paths for fixed-speed eventwindow and variable-speed
% feedback; separately evaluates repaired paths ONLY if prior saved MAT
% files exist. Never reruns RRT*, writes into a NEW results directory.
if nargin<2 || isempty(sizes),sizes=20;end
if nargin<3,pathCasesFolder='';end
if nargin<4,repairedPathsFolder='';end
if nargin<5 || isempty(seeds),seeds=1:30;end
pathCasesFolder=localFindCached(root,pathCasesFolder);
if isempty(repairedPathsFolder)
    repairedPathsFolder=fullfile(root,'results_certificate_spatial_repair_dev','repaired_paths');
end
outdir=fullfile(root,'results_speed_feedback_dev');
parts=fullfile(outdir,'checkpoints');traces=fullfile(outdir,'traces');
if ~isfolder(parts),mkdir(parts);end
if ~isfolder(traces),mkdir(traces);end
protocol='MMRA_SPEED_FEEDBACK_DEV_20261029_A';
lock=fullfile(outdir,'PROTOCOL_LOCK.txt');
if isfile(lock)
    contents=fileread(lock);
    assert(contains(contents,protocol),'Do not mix distinct speed protocols.');
else
    fid=fopen(lock,'w');assert(fid>0);
    fprintf(fid,'%s\n',protocol);
    fprintf(fid,'DEVELOPMENT only: saved historical path cases, not holdout.\n');
    fprintf(fid,'Original paths: %s\n',pathCasesFolder);
    fprintf(fid,'Repaired path folder if available: %s\n',repairedPathsFolder);
    fprintf(fid,'Common hold/hold, dSafe=10 m, cruise cap=15 m/s.\n');
    fprintf(fid,'Original event-window keeps its ORIGINAL 0:0.25:60 s.\n');
    fprintf(fid,'Feedback dt=.20, a+=3, a-=6, horizon=8, forecast dt=.4.\n');
    fprintf(fid,'Exact piecewise-constant speed polyline safety model only.\n');
    fclose(fid);
end
fprintf('=== MMRA v2.2 DYNAMIC SPEED FEEDBACK DEV ===\n');
fprintf('Original RRT* source: %s\n',pathCasesFolder);
fprintf('Sizes: %s; seeds: %s\n',mat2str(sizes),mat2str(seeds));
fprintf('Fixed baseline vs speed feedback on IDENTICAL original polylines.\n');
fprintf('Repaired geometry evaluated separately when precomputed MAT exists.\n');
terrains={'paper_gmm','legacy20_sine'};
for ie=1:numel(terrains)
    terrain=terrains{ie};
    [~,~,opts]=mmra_defaults(terrain);
    opts.startPolicy='hold';opts.endPolicy='hold';
    opts.speed=15;opts.dSafe=10;
    for n=reshape(sizes,1,[])
        for rep=reshape(seeds,1,[])
            seed=930000+10000*ie+100*n+rep;
            stamp=sprintf('%s_u%d_seed%d',terrain,n,seed);
            partfile=fullfile(parts,['part_' stamp '.csv']);
            casefile=fullfile(pathCasesFolder,['case_' stamp '.mat']);
            assert(isfile(casefile),'Missing saved original geometry: %s',casefile);
            if isfile(partfile)
                prior=readtable(partfile);
                assert(height(prior)==1 && ...
                    strcmp(string(prior.ProtocolID),string(protocol)) && ...
                    prior.Seed(1)==seed,'Old result checkpoint mismatch.');
                continue;
            end
            f=load(casefile,'caseData');c=f.caseData;
            assert(c.Seed==seed && c.NumUAV==n && ...
                strcmp(c.Terrain,terrain), ...
                'Source cache metadata mismatch.');
            row=struct('ProtocolID',protocol,'Terrain',terrain, ...
                'NumUAV',double(n),'Seed',double(seed), ...
                'SpatialOK',logical(c.SpatialOK), ...
                'FixedSuccess',false,'SpeedSuccess',false, ...
                'SpeedOnRepairedAvailable',false, ...
                'SpeedOnRepairedSuccess',false, ...
                'FixedMakespan_s',NaN,'SpeedMakespan_s',NaN, ...
                'SpeedOnRepairedMakespan_s',NaN, ...
                'FixedWall_s',NaN,'SpeedWall_s',NaN, ...
                'SpeedOnRepairedWall_s',NaN, ...
                'SpeedMinSeparation_m',NaN, ...
                'SpeedRepairedMinSeparation_m',NaN, ...
                'SpeedYieldStepsN',NaN, ...
                'SpeedShieldChangesN',NaN, ...
                'SpeedCompletedUAVsN',NaN, ...
                'SpeedReason','spatial_paths_unavailable', ...
                'SpeedRepairedReason','not_available');
            if c.SpatialOK
                paths=c.Paths;
                assert(iscell(paths) && numel(paths)==n, ...
                    'Unexpected cached paths.');
                t0=tic;fixed=mmra_schedule_eventwindow(paths,opts);
                row.FixedWall_s=toc(t0);
                t0=tic;dynamic=mmra_schedule_speed_feedback(paths,opts);
                row.SpeedWall_s=toc(t0);
                row.FixedSuccess=logical(fixed.success);
                row.SpeedSuccess=logical(dynamic.success);
                row.FixedMakespan_s=fixed.makespan;
                row.SpeedMakespan_s=dynamic.makespan;
                row.SpeedMinSeparation_m=dynamic.minSeparation;
                row.SpeedYieldStepsN=dynamic.yieldSteps;
                row.SpeedShieldChangesN=dynamic.shieldAdjustments;
                row.SpeedCompletedUAVsN=dynamic.completedUAVs;
                row.SpeedReason=dynamic.reason;
                assert(dynamic.validation.safe, ...
                    'Controller emitted an unsafe partial trace: %s',stamp);
                trace=dynamic.trace;validation=dynamic.validation;
                save(fullfile(traces,['speed_' stamp '.mat']), ...
                    'trace','validation','paths','-v7');
                repairedFile=fullfile(repairedPathsFolder,['paths_' stamp '.mat']);
                if isfile(repairedFile)
                    repaired=load(repairedFile,'originalPaths','repairedPaths');
                    rp=repaired.repairedPaths;
                    assert(numel(rp)==n,'Repaired path count mismatch.');
                    for ii=1:n
                        assert(norm(rp{ii}(1,:)-paths{ii}(1,:))<1e-6 && ...
                            norm(rp{ii}(end,:)-paths{ii}(end,:))<1e-6, ...
                            'Repaired paths changed mission endpoints.');
                    end
                    t0=tic;dynRep=mmra_schedule_speed_feedback(rp,opts);
                    row.SpeedOnRepairedWall_s=toc(t0);
                    row.SpeedOnRepairedAvailable=true;
                    row.SpeedOnRepairedSuccess=dynRep.success;
                    row.SpeedOnRepairedMakespan_s=dynRep.makespan;
                    row.SpeedRepairedMinSeparation_m=dynRep.minSeparation;
                    row.SpeedRepairedReason=dynRep.reason;
                    assert(dynRep.validation.safe, ...
                        'Repaired-path run emitted an unsafe partial trace.');
                end
            end
            tmp=fullfile(parts,['tmp_' stamp '.csv']);
            writetable(struct2table(row),tmp);
            [ok,msg]=movefile(tmp,partfile);assert(ok,msg);
            fprintf('%-14s U=%2d seed=%6d: fixed=%d speed=%d repaired=%d reason=%s\n', ...
                terrain,n,seed,row.FixedSuccess,row.SpeedSuccess, ...
                row.SpeedOnRepairedSuccess,row.SpeedReason);
        end
    end
end
% Aggregate just the requested case set. Never conflate original-path and
% repaired-path denominators or replace missing repaired paths with zeroes.
rows=table();
for ie=1:numel(terrains)
    for n=reshape(sizes,1,[])
        for rep=reshape(seeds,1,[])
            seed=930000+10000*ie+100*n+rep;
            stamp=sprintf('%s_u%d_seed%d',terrains{ie},n,seed);
            r=readtable(fullfile(parts,['part_' stamp '.csv']));
            if isempty(rows),rows=r;else,rows=[rows;r];end %#ok<AGROW>
        end
    end
end
file=fullfile(outdir,'speed_feedback_trials.csv');
writetable(rows,file);
fprintf('\n=== SPEED FEEDBACK DEVELOPMENT SUMMARY ===\n');
for ie=1:numel(terrains)
    for n=reshape(sizes,1,[])
        pick=strcmp(string(rows.Terrain),terrains{ie}) & rows.NumUAV==n;
        total=sum(pick);
        available=sum(rows.SpeedOnRepairedAvailable(pick));
        fprintf('%s U=%d: fixed=%d/%d  speed=%d/%d  ', ...
            terrains{ie},n,sum(rows.FixedSuccess(pick)),total, ...
            sum(rows.SpeedSuccess(pick)),total);
        fprintf('repaired-speed=%d/%d available (NOT %d).\n', ...
            sum(rows.SpeedOnRepairedSuccess(pick)),available,total);
    end
end
fprintf('Saved %s\n',file);
end

function found=localFindCached(root,override)
if nargin>=2 && ~isempty(override)
    found=override;
else
    rel=fullfile('results_scheduler_repair_dev','path_cases');
    old='MMRA_Unified_MATLAB_v2_1_scheduler';
    base=root;
    choices={fullfile(root,rel)};
    for k=1:4
        choices{end+1}=fullfile(base,old,rel); %#ok<AGROW>
        choices{end+1}=fullfile(base, ...
            'MMRA_v21_scheduler_bottleneck_repair',old,rel); %#ok<AGROW>
        base=fileparts(base);
    end
    found='';
    for k=1:numel(choices)
        if isfile(fullfile(choices{k},'case_paper_gmm_u20_seed942001.mat')) && ...
                isfile(fullfile(choices{k},'case_legacy20_sine_u20_seed952001.mat'))
            found=choices{k};break;
        end
    end
end
assert(~isempty(found) && isfolder(found), ...
    ['Cached original paths not found. Edit pathCasesFolder in the root ', ...
    'run_speed_feedback_20u_cached.m and point to the OLD path_cases.']);
end
