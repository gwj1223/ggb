%RUN_SC_APF_STRESS Designed low-ceiling terrain tests with limited budget.
% Run this AFTER the tuning script. Not part of candidate selection.
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'));
outDir=fullfile(root,'results_sc_apf_v13');
if ~exist(outDir,'dir'),mkdir(outDir);end
choice=fullfile(outDir,'sc_apf_selected_params.mat');
if exist(choice,'file')
    x=load(choice,'selectedParams'); selectedParams=x.selectedParams;
else
    selectedParams=struct('scSafeBand',8,'scSoftWidth',4,'scKRep',30);
    fprintf('No selected parameters saved; using v1.2 default SC values.\n');
end
profiles={'paper_gmm','legacy20_sine'};
variants={'RRTstar_unguided','MMRA_legacy_APF','MMRA_SC_APF'};
seeds=15001:15030;
rows=struct([]);
for ip=1:numel(profiles)
    for si=1:numel(seeds)
        for iv=1:numel(variants)
            if iv==3,p=selectedParams;else,p=struct();end
            row=mmra_sc_trial(profiles{ip},seeds(si), ...
                variants{iv},p,true,false);
            if isempty(rows),rows=row;else,rows(end+1,1)=row;end %#ok<SAGROW>
        end
    end
    fprintf('Stress case %s completed\n',profiles{ip});
end
T=struct2table(rows);
writetable(T,fullfile(outDir,'sc_apf_stress_trials.csv'));
for ip=1:numel(profiles)
    for iv=1:numel(variants)
        idx=strcmp(T.Terrain,profiles{ip}) & strcmp(T.Variant,variants{iv});
        q=T(idx,:);
        if any(q.Success),mp=mean(q.Path_m(q.Success));else,mp=NaN;end
        fprintf('STRESS %-14s %-18s success=%.1f%% meanPath=%.2fm meanTime=%.4fs\n', ...
            profiles{ip},variants{iv},100*mean(double(q.Success)), ...
            mp,mean(q.Search_s));
    end
end
