function mmra_sched_event_report(root,only20)
%MMRA_SCHED_EVENT_REPORT Robust REPORT ONLY from saved per-case checkpoints.
% No spatial planning or rescheduling, even if the benchmark was interrupted.
if nargin<2,only20=true;end
s=mmra_sched_event_spec();
if only20,sizes=20;else,sizes=s.sizes;end
outDir=fullfile(root,'results_scheduler_eventwindow_dev');
partDir=fullfile(outDir,'checkpoints');
assert(isfolder(partDir),'Missing event-window checkpoints: %s',partDir);
T=table();missing=0;
for ie=1:numel(s.terrains)
    terrain=s.terrains{ie};
    for n=reshape(sizes,1,[])
        for rep=1:s.nTrials
            seed=930000+10000*ie+100*n+rep;
            file=fullfile(partDir,sprintf( ...
                'part_%s_u%d_seed%d.csv',terrain,n,seed));
            if ~isfile(file),missing=missing+1;continue;end
            a=readtable(file);
            assert(height(a)==1 && ...
                all(strcmp(string(a.ProtocolID),string(s.protocolID))) && ...
                all(strcmp(string(a.Terrain),string(terrain))) && ...
                a.NumUAV(1)==n && a.Seed(1)==seed, ...
                'Invalid event checkpoint: %s',file);
            if isempty(T),T=a;else,T=[T;a];end %#ok<AGROW>
        end
    end
end
assert(~isempty(T),'No event-window checkpoints to summarize.');
allFile=fullfile(outDir, ...
    sprintf('eventwindow_trials_%s.csv',localScope(only20)));
writetable(T,allFile);
summaryRows=struct([]);pairRows=struct([]);gateRows=struct([]);
for ie=1:numel(s.terrains)
    terrain=s.terrains{ie};
    for n=reshape(sizes,1,[])
        g=T(strcmp(string(T.Terrain),string(terrain)) & ...
            T.NumUAV==n,:);
        if isempty(g),continue;end
        S=logicalColumn(g.SpatialOK,'SpatialOK');
        C=logicalColumn(g.CAOK,'CAOK');
        R=logicalColumn(g.RepairOK,'RepairOK');
        W=logicalColumn(g.WindowOK,'WindowOK');
        assert(~any((C|R|W)&~S),'Scheduler succeeded without valid paths');
        assert(~any(C&~R) && ~any(C&~W), ...
            'Reference feasible schedule was lost by a fallback method.');
        for method={'CA','Repair','Window'}
            m=method{1};
            ok=logicalColumn(g.([m 'OK']),[m 'OK']);
            [lo,hi]=wilson(sum(ok),height(g));
            makes=g.([m 'Makespan_s']);
            runtime=g.([m 'Wall_s']);
            sep=g.([m 'MinSep_m']);
            delay=g.([m 'MaxDelay_s']);
            x=struct('Terrain',terrain,'NumUAV',double(n), ...
                'Method',m,'Cases',height(g), ...
                'SpatialValidN',double(sum(S)), ...
                'SuccessN',double(sum(ok)), ...
                'SuccessRate',double(sum(ok)/height(g)), ...
                'SuccessCI95_L',lo,'SuccessCI95_U',hi, ...
                'MeanMakespan_s',safeMean(makes(ok)), ...
                'MeanFullWall_s',safeMean(runtime(S)), ...
                'MeanMinSep_m',safeMean(sep(ok)), ...
                'MeanMaxDelay_s',safeMean(delay(ok)));
            if isempty(summaryRows),summaryRows=x;
            else,summaryRows(end+1,1)=x;end %#ok<AGROW>
        end
        both=C & W;
        gains=g.CAMakespan_s(both)-g.WindowMakespan_s(both);
        assert(all(gains>=-1e-7), ...
            'Event-window schedule increased makespan for CA-feasible path');
        gains(abs(gains)<1e-7)=0;
        [gLo,gHi]=bootMeanCI(gains,s.bootstrapB, ...
            s.bootstrapSeed+100*ie+n);
        ratio=safeMean(g.WindowWall_s(S)./max(g.CAWall_s(S),eps));
        rescued=sum(~C & W);
        strict=sum(gains>1e-8);
        rate=strict/max(1,numel(gains));
        pr=struct('Terrain',terrain,'NumUAV',double(n), ...
            'Cases',height(g),'BothValidN',double(sum(both)), ...
            'CAFailedWindowSucceededN',double(rescued), ...
            'RepairFailedWindowSucceededN',double(sum(~R & W)), ...
            'WindowFailedRepairSucceededN',double(sum(R & ~W)), ...
            'StrictMakespanImprovementN',double(strict), ...
            'StrictImprovementFractionOnPairs',rate, ...
            'MeanPairedMakespanGain_s',safeMean(gains), ...
            'GainCI95_L_s',gLo,'GainCI95_U_s',gHi, ...
            'MeanWindowToCAWallRatio',ratio, ...
            'MeanCacheWall_s',safeMean(g.WindowCacheWall_s(S)), ...
            'MeanExpandedNodes',safeMean(g.WindowExpandedNodes(S)), ...
            'MeanFalseSafeCandidates',safeMean( ...
                g.WindowFalseSafeCandidates(S)), ...
            'MeanPairwiseNoCompatible',safeMean(g.WindowNoCompatiblePairs(S)), ...
            'MeanInitialConflicts',safeMean(g.InitialConflicts(S)));
        if isempty(pairRows),pairRows=pr;
        else,pairRows(end+1,1)=pr;end %#ok<AGROW>
        relOK=~any(C & ~W);
        makesOK=all(gains>=-1e-8);
        benefitOK=(rescued>=1) || (rate>=s.minImprovedFraction && ...
            sum(both)>0);
        costOK=isfinite(ratio) && ratio<=s.maxWallRatio;
        gate=struct('Terrain',terrain,'NumUAV',double(n), ...
            'ReliabilityNoninferior',logical(relOK), ...
            'MakespanNoninferior',logical(makesOK), ...
            'ObservedBenefit',logical(benefitOK), ...
            'ComputeCostOK',logical(costOK), ...
            'DevGatePass',logical(relOK && makesOK && benefitOK && costOK));
        if isempty(gateRows),gateRows=gate;
        else,gateRows(end+1,1)=gate;end %#ok<AGROW>
    end
end
summary=struct2table(summaryRows);
paired=struct2table(pairRows);
gates=struct2table(gateRows);
prefix=['eventwindow_' localScope(only20) '_'];
writetable(summary,fullfile(outDir,[prefix 'summary.csv']));
writetable(paired,fullfile(outDir,[prefix 'paired_ci95.csv']));
writetable(gates,fullfile(outDir,[prefix 'gates.csv']));
fprintf('\n=== Endpoint-aware window scheduling: same saved paths ===\n');
disp(summary);
fprintf('\n=== Paired CA -> event-window comparisons ===\n');
disp(paired);
fprintf('\n=== Predeclared DEVELOPMENT gates (not holdout) ===\n');
disp(gates);
expected=numel(s.terrains)*numel(sizes)*s.nTrials;
fprintf('Saved %d/%d event-window comparisons, %d missing.\n', ...
    height(T),expected,missing);
if missing==0
    fprintf('DEVELOPMENT GATES: %d/%d passed.\n', ...
        sum(gates.DevGatePass),height(gates));
    status='COMPLETE';
else
    fprintf('PARTIAL: no claim of full benchmark completion.\n');
    status='PARTIAL';
end
f=fopen(fullfile(outDir,['RUN_STATUS_' localScope(only20) '.txt']),'w');
assert(f>0);
fprintf(f,'%s: %d/%d; missing=%d; %s\n',status, ...
    height(T),expected,missing,s.protocolID);
fprintf(f,'No RRT*, same saved paths, same HOLD/HOLD and continuous check.\n');
fprintf(f,'Development data previously used; NOT independent validation.\n');
fprintf(f,'All CPU timings rerun together for CA/Repair/Window on same machine.\n');
fprintf(f,'CI for makespan is conditional on BOTH methods feasible; do not compare success-only means.\n');
fprintf(f,'Window feasibility is bounded heuristic; no global optimality proof.\n');
fclose(f);
end

function out=localScope(only20)
if only20,out='20u';else,out='all';end
end

function x=logicalColumn(raw,label)
if islogical(raw)
    x=raw(:);
elseif isnumeric(raw)
    assert(all(isfinite(raw(:)) & (raw(:)==0|raw(:)==1)), ...
        'Invalid numeric Boolean in %s',label);
    x=(raw(:)==1);
else
    v=lower(strtrim(string(raw(:))));
    positive=v=="true" | v=="1" | v=="t";
    negative=v=="false" | v=="0" | v=="f";
    assert(all(positive|negative),'Invalid text Boolean in %s',label);
    x=positive;
end
x=logical(x(:));
end

function v=safeMean(x)
x=x(isfinite(x));
if isempty(x),v=NaN;else,v=mean(x);end
end

function [low,high]=bootMeanCI(x,B,seed)
x=x(isfinite(x));
n=numel(x);
if n==0,low=NaN;high=NaN;return;end
if n==1,low=x;high=x;return;end
old=rng;rng(seed,'twister');samples=zeros(B,1);
for i=1:B
    ix=randi(n,n,1);samples(i)=mean(x(ix));
end
rng(old);
samples=sort(samples);
low=samples(max(1,ceil(0.025*B)));
high=samples(min(B,ceil(0.975*B)));
end

function [low,high]=wilson(k,n)
if n==0,low=NaN;high=NaN;return;end
z=1.959963984540054;
p=k/n;d=1+z^2/n;
center=(p+z^2/(2*n))/d;
half=z*sqrt(p*(1-p)/n+z^2/(4*n^2))/d;
low=max(0,center-half);high=min(1,center+half);
end
