%RUN_SC_APF_SAFETY_STRESS Follow-up stress test (NOT for tuning/selection).
% Run only after safety training; use fresh stress seeds 18001:18030.
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'));
outDir=fullfile(root,'results_sc_apf_v15');
chosen=fullfile(outDir,'sc_apf_selected_params.mat');
if ~exist(chosen,'file')
    fprintf('No selected safety-qualified SC parameters. Stress run skipped.\n');
    return;
end
x=load(chosen,'selectedParams'); selectedParams=x.selectedParams;
profiles={'paper_gmm','legacy20_sine'};
variants={'RRTstar_unguided','MMRA_legacy_APF','MMRA_SC_APF'};
seeds=18001:18030;
rows=struct([]);
for ip=1:numel(profiles)
    for is=1:numel(seeds)
        for iv=1:numel(variants)
            if iv==3,p=selectedParams;else,p=struct();end
            row=mmra_sc_trial(profiles{ip},seeds(is), ...
                variants{iv},p,true,false);
            if isempty(rows),rows=row;else,rows(end+1,1)=row;end %#ok<SAGROW>
        end
    end
    fprintf('Safety stress finished: %s\n',profiles{ip});
end
T=struct2table(rows);
writetable(T,fullfile(outDir,'sc_apf_stress_trials.csv'));
for ip=1:numel(profiles)
    for iv=1:numel(variants)
        mask=strcmp(T.Terrain,profiles{ip}) & strcmp(T.Variant,variants{iv});
        q=T(mask,:);
        if any(q.Success)
            mp=mean(q.Path_m(q.Success));
            mc=mean(q.MinClearFine_m(q.Success));
        else
            mp=NaN;mc=NaN;
        end
        fprintf('STRESS %-14s %-18s success=%5.1f%% meanPath=%7.2fm meanFineClear=%6.3fm\n', ...
            profiles{ip},variants{iv},100*mean(double(q.Success)),mp,mc);
    end
end
% No secondary tuning from these stress outcomes.
