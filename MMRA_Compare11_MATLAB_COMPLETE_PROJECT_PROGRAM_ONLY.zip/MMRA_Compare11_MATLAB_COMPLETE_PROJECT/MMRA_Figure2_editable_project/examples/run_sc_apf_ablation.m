%RUN_SC_APF_ABLATION Controlled same-seed SC-APF study (MATLAB R2023b).
% Main difference: ONLY the APF repulsion. Fixed RRT* settings;
% no pruning/smoothing, same GMM terrain, collision checker, and budget.
% Defaults to 5 seeds for smoke test; set NTRIAL=30 or more for paper.
% Runtime results are measurements of THIS interpreter/hardware only.
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'));
NTRIAL=5; % CHANGE TO 30 or more for manuscript experiments
seed0=12001;
profiles={'paper_gmm','legacy20_sine'};
variants={'RRTstar_unguided','MMRA_legacy_APF','MMRA_SC_APF'};
maxRows=numel(profiles)*numel(variants)*NTRIAL;
Terrain=cell(maxRows,1); Variant=cell(maxRows,1);
Seed=NaN(maxRows,1); Success=false(maxRows,1);
Path_m=NaN(maxRows,1); FirstIter=NaN(maxRows,1);
Search_s=NaN(maxRows,1); Accepted=NaN(maxRows,1);
Rejected=NaN(maxRows,1); RejectFraction=NaN(maxRows,1);
MinClearAboveSafe_m=NaN(maxRows,1);
MeanClearAboveSafe_m=NaN(maxRows,1);
GuidedSamples=NaN(maxRows,1);
UniformSamples=NaN(maxRows,1);
TreeCostError=NaN(maxRows,1);
r=0;
for icase=1:numel(profiles)
    [env,base,~]=mmra_defaults(profiles{icase});
    % Same physical start and goal for all methods in the given environment.
    if strcmp(profiles{icase},'paper_gmm')
        startPos=[5 7 24];goalPos=[94 93 25];
    else
        startXY=[6 8];goalXY=[94 90];
        startPos=[startXY mmra_terrain(startXY,env)+env.safetyMargin+12];
        goalPos=[goalXY mmra_terrain(goalXY,env)+env.safetyMargin+12];
    end
    assert(mmra_is_free(startPos,env) && mmra_is_free(goalPos,env), ...
        'Invalid start or goal in case %s',profiles{icase});
    base.prune=false;base.smooth=false;
    for trial=1:NTRIAL
        seed=seed0+trial-1;
        for k=1:numel(variants)
            c=base;
            isGuided=k>1;
            if k==3, c.apfMode='sc_apf'; else, c.apfMode='legacy'; end
            rng(seed,'twister');
            [path,st]=mmra_rrtstar(startPos,goalPos,env,c,isGuided);
            r=r+1;Terrain{r}=profiles{icase};Variant{r}=variants{k};
            Seed(r)=seed;Success(r)=st.success;
            if st.success
                Path_m(r)=st.pathLength;
                [MinClearAboveSafe_m(r),MeanClearAboveSafe_m(r)]= ...
                    mmra_path_clearance(path,env,c.edgeResolution);
            end
            FirstIter(r)=st.firstIter;
            Search_s(r)=st.elapsed_s;
            Accepted(r)=st.accepted;Rejected(r)=st.rejected;
            denom=st.accepted+st.rejected;
            if denom>0,RejectFraction(r)=st.rejected/denom;end
            GuidedSamples(r)=st.guidedSamples;
            UniformSamples(r)=st.uniformSamples;
            TreeCostError(r)=st.treeCostError;
        end
        fprintf('SC-APF ablation: %s seed %d done\n',profiles{icase},seed);
    end
end
T=table(Terrain,Variant,Seed,Success,Path_m,FirstIter, ...
    Search_s,Accepted,Rejected,RejectFraction, ...
    MinClearAboveSafe_m,MeanClearAboveSafe_m, ...
    GuidedSamples,UniformSamples,TreeCostError);
outDir=fullfile(root,'results_new');
if ~exist(outDir,'dir'),mkdir(outDir);end
writetable(T,fullfile(outDir,'sc_apf_ablation_trials.csv'));
save(fullfile(outDir,'sc_apf_ablation_trials.mat'), ...
    'T','profiles','variants','seed0','NTRIAL');
fprintf('Saved SC-APF trial-level measurements: %d rows\n',height(T));
fprintf('Report failure rate AND runtime; SC-APF is not guaranteed to win.\n');
