%RUN_SC_APF_BUFFER_PILOT Development-only factorial safety-buffer study.
% IMPORTANT: No held-out seeds are touched. All numbers are exploratory.
% Holdout seeds 16001:16050 remain CLOSED until final design is frozen.
% The previous v1.5 safety rules are used UNCHANGED.
% For scientific attribution, compare SC and legacy under THE SAME buffer,
% as well as the candidate SC method vs original legacy at zero buffer.
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'));
outDir=fullfile(root,'results_sc_apf_v16_buffer_pilot');
if ~exist(outDir,'dir'),mkdir(outDir);end
profiles={'paper_gmm','legacy20_sine'};
trainSeeds=17001:17030; % seen development seeds; NEVER call them holdout
buffers_m=[0 0.5 1.0 1.5];
% Candidate #3 from v1.5: closest to passing legacy20_sine mean guard.
% This parameter set is SELECTED FROM ALREADY VIEWED TRAINING RESULTS.
scParams=struct('scSafeBand',4,'scSoftWidth',4,'scKRep',30);
modes={'legacy','sc_apf'};
g=mmra_sc_guard_defaults();
fprintf('v1.6 BUFFER PILOT: 2 APFs x %d buffers x %d train seeds x %d terrains.\n', ...
    numel(buffers_m),numel(trainSeeds),numel(profiles));
fprintf('SC params: band=%.1fm, width=%.1fm, k=%.1f.\n', ...
    scParams.scSafeBand,scParams.scSoftWidth,scParams.scKRep);
fprintf('Only DEVELOPMENT seeds used. No holdout or candidate selection here.\n');
rows=struct([]);
for ip=1:numel(profiles)
    for is=1:numel(trainSeeds)
        for ib=1:numel(buffers_m)
            for iv=1:numel(modes)
                r=mmra_sc_buffer_trial(profiles{ip},trainSeeds(is), ...
                    modes{iv},buffers_m(ib),scParams);
                if isempty(rows),rows=r;
                else,rows(end+1,1)=r;end %#ok<SAGROW>
            end
        end
    end
    fprintf('Finished development buffer pilot on %s\n',profiles{ip});
end
T=struct2table(rows);
writetable(T,fullfile(outDir,'buffer_pilot_trials.csv'));
S=struct([]);
for ip=1:numel(profiles)
    profile=profiles{ip};
    zeroLegacy=T(strcmp(T.Terrain,profile) & ...
        strcmp(T.Variant,'MMRA_legacy_APF') & T.PlanBuffer_m==0,:);
    for ib=1:numel(buffers_m)
        b=buffers_m(ib);
        legacy=T(strcmp(T.Terrain,profile) & ...
            strcmp(T.Variant,'MMRA_legacy_APF') & T.PlanBuffer_m==b,:);
        sc=T(strcmp(T.Terrain,profile) & ...
            strcmp(T.Variant,'MMRA_SC_APF') & T.PlanBuffer_m==b,:);
        % Head-to-head same-buffer APF ablation: isolate APF contribution.
        matched=mmra_sc_guard_compare(legacy,sc,g);
        % Compared with the ORIGINAL unbuffered legacy reference.
        orig=mmra_sc_guard_compare(zeroLegacy,sc,g);
        good=logical(sc.Success);
        out=struct('Terrain',profile,'PlanBuffer_m',b, ...
            'SC_SuccessCount',sum(good),'N',height(sc), ...
            'SC_MeanPath_m',mean(sc.Path_m(good)), ...
            'SC_MeanTime_s',mean(sc.Search_s), ...
            'SC_MeanFineMinClear_m',mean(sc.MinClearFine_m(good)), ...
            'SC_WorstFineMinClear_m',min(sc.MinClearFine_m(good)), ...
            'AgainstOriginalEligible',orig.Eligible, ...
            'AgainstOriginalReason',orig.Reason, ...
            'AgainstOriginalPathRatio',orig.PathRatio, ...
            'AgainstOriginalTimeRatio',orig.TimeRatio, ...
            'AgainstOriginalMeanClearDelta_m',orig.MeanClearDelta_m, ...
            'AgainstOriginalP10ClearDelta_m',orig.P10ClearDelta_m, ...
            'AgainstOriginalWorstClearDelta_m',orig.WorstClearDelta_m, ...
            'AgainstSameBufferEligible',matched.Eligible, ...
            'AgainstSameBufferReason',matched.Reason, ...
            'AgainstSameBufferPathRatio',matched.PathRatio, ...
            'AgainstSameBufferMeanClearDelta_m',matched.MeanClearDelta_m);
        if isempty(S),S=out;else,S(end+1,1)=out;end %#ok<SAGROW>
    end
end
Summary=struct2table(S);
writetable(Summary,fullfile(outDir,'buffer_pilot_summary.csv'));
disp(Summary(:,{'Terrain','PlanBuffer_m','SC_SuccessCount','N', ...
    'AgainstOriginalEligible','AgainstOriginalMeanClearDelta_m', ...
    'AgainstOriginalPathRatio','AgainstSameBufferPathRatio'}));
fprintf('No held-out evaluation performed. If there is no eligible buffer, DO NOT loosen safety guards just to pass.\n');
fprintf('A passing unbuffered comparison alone does NOT establish an SC-APF advantage: inspect same-buffer comparison.\n');
