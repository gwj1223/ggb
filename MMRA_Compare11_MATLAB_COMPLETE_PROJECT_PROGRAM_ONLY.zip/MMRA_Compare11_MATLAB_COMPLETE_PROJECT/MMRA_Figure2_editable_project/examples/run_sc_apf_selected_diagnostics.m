%RUN_SC_APF_SELECTED_DIAGNOSTICS Diagnose TRAINING-selected SC parameters.
% Uses training seeds only, never the final holdout seed set.
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'));
outDir=fullfile(root,'results_sc_apf_v15');
chosen=fullfile(outDir,'sc_apf_selected_params.mat');
if ~exist(chosen,'file')
    fprintf('No eligible SC candidate. Run safety training; diagnostics skipped.\n');
    return;
end
x=load(chosen,'selectedParams','selectedId','trainSeeds');
selectedParams=x.selectedParams;seeds=x.trainSeeds(1:min(10,numel(x.trainSeeds)));
profiles={'paper_gmm','legacy20_sine'};
variants={'MMRA_legacy_APF','MMRA_SC_APF'};
rows=struct([]);
for ip=1:numel(profiles)
    for is=1:numel(seeds)
        for iv=1:numel(variants)
            if iv==2,p=selectedParams;else,p=struct();end
            row=mmra_sc_trial(profiles{ip},seeds(is),variants{iv},p,false,true);
            if isempty(rows),rows=row;else,rows(end+1,1)=row;end %#ok<SAGROW>
        end
    end
end
T=struct2table(rows);
writetable(T,fullfile(outDir,'sc_apf_selected_diagnostic_trials.csv'));
fprintf('Diagnostics of SELECTED candidate %d (training seeds only).\n',x.selectedId);
for ip=1:numel(profiles)
    for iv=1:numel(variants)
        mask=strcmp(T.Terrain,profiles{ip}) & strcmp(T.Variant,variants{iv});
        fprintf('%-14s %-18s active=%5.1f%% rep/att=%7.3f angleVsLegacy=%6.2f deg\n', ...
            profiles{ip},variants{iv},100*mean(T.ActiveFraction(mask)), ...
            mean(T.RepulsionAttractionRatio(mask)), ...
            mean(T.AngleFromLegacy_deg(mask)));
    end
end
fprintf('Instrumentation modifies timings: use non-instrumented final holdout for speed.\n');
