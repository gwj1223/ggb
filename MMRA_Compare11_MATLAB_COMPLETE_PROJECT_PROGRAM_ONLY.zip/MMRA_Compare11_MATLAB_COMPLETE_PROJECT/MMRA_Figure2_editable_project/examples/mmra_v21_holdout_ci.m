function [lo,hi] = mmra_v21_holdout_ci(d,B)
%MMRA_V21_HOLDOUT_CI Paired percentile bootstrap for a MEAN difference.
% Caller MUST set the fixed bootstrap RNG seed. Base MATLAB only.
d=double(d(:));
d=d(isfinite(d));
lo=NaN;hi=NaN;
if isempty(d),return;end
assert(isscalar(B) && B>=100 && B==floor(B));
if numel(d)==1
    lo=d;hi=d;return;
end
k=randi(numel(d),numel(d),B);
boot=sort(mean(d(k),1));
lo=local_pct(boot,0.025);
hi=local_pct(boot,0.975);
end

function v=local_pct(sorted,p)
n=numel(sorted);
t=1+(n-1)*p;
a=floor(t);b=ceil(t);
v=sorted(a)+(t-a)*(sorted(b)-sorted(a));
end
