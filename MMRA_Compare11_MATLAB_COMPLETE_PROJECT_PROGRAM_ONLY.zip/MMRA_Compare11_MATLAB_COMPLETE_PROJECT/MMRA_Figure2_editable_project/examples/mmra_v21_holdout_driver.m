function mmra_v21_holdout_driver(root)
%MMRA_V21_HOLDOUT_DRIVER Checkpoint by scene, never silently overwrite trials.
s=mmra_v21_holdout_spec();
outDir=fullfile(root,'results_v21_independent_holdout');
partDir=fullfile(outDir,'checkpoints');
if ~exist(outDir,'dir'),mkdir(outDir);end
if ~exist(partDir,'dir'),mkdir(partDir);end
protocolFile=fullfile(outDir,'PROTOCOL_LOCK.txt');
if isfile(protocolFile)
    old=fileread(protocolFile);
    assert(~isempty(strfind(old,s.protocolID)), ...
        'Protocol lock differs. Do not mix results across protocols.');
else
    f=fopen(protocolFile,'w');assert(f>0);
    fprintf(f,'%s\n',s.protocolID);
    fprintf(f,'FROZEN before independent evaluation; no parameter tuning.\n');
    fprintf(f,'Legacy APF only; modes: length, length_risk, length_climb, length_risk_climb.\n');
    fprintf(f,'Weights: risk 0 or 0.5; ascent 0 or 0.5; risk band 2m.\n');
    fprintf(f,'Normal seeds: 810001..810100; hard seeds: 820001..820100.\n');
    fprintf(f,'Terrains paper_gmm/legacy20_sine; ordinary/hard.\n');
    fprintf(f,'100 seeds x 4 objective modes x 4 scenes x 2 budgets = 3200 rows.\n');
    fprintf(f,'Equal iteration budget uses existing maxIter (900 normal, 200 hard).\n');
    fprintf(f,'Equal search clock caps: 0.030s normal; 0.045s hard.\n');
    fprintf(f,'Fixed 8m step; edge=0.25m; independent sampled check=0.10m.\n');
    fprintf(f,'Unprocessed paths: prune=false, smooth=false (matches pilot).\n');
    fprintf(f,'Only GMM/synthetic terrains, not real DEM or continuous safety proof.\n');
    fprintf(f,'MATLAB %s; platform %s; recorded %s\n', ...
        version,computer,datestr(now,30));
    fclose(f);
end
statusFile=fullfile(outDir,'RUN_STATUS.txt');
f=fopen(statusFile,'w');assert(f>0);
fprintf(f,'IN_PROGRESS. Checkpoints are safe to resume.\n');fclose(f);
for ib=1:numel(s.budgetModes)
 for ih=1:numel(s.hardGroups)
  hard=s.hardGroups(ih);
  if hard,seeds=s.hardSeeds;else,seeds=s.normalSeeds;end
  for ie=1:numel(s.terrains)
   terrain=s.terrains{ie};budget=s.budgetModes{ib};
   partFile=fullfile(partDir,sprintf('part_%s_%s_h%d.csv', ...
       budget,terrain,hard));
   if isfile(partFile)
       part=readtable(partFile);
       mmra_v21_holdout_validate_part(part,s,budget,terrain,hard,seeds);
       fprintf('REUSED saved checkpoint: %s / %s / hard=%d\n', ...
           budget,terrain,hard);
       continue;
   end
   [env,base,startPos,goalPos]=mmra_sc_case(terrain,hard);
   base.apfMode='legacy';base.prune=false;base.smooth=false;
   base.collectApfDiagnostics=false;
   base.costEvalMode='fused';
   base.riskCostBand_m=s.riskBand_m;
   base.riskCostResolution_m=s.riskResolution_m;
   base.wallBudget_s=Inf;
   if strcmp(budget,'equal_search_clock_cap')
       base.wallBudget_s=s.searchCaps_s(ih);
   end
   records=struct([]);
   for ik=1:numel(seeds)
    seed=seeds(ik);
    for iv=1:numel(s.variants)
     cfg=base;
     cfg.costMode=s.variants{iv};
     cfg.riskCostWeight=s.riskWeights(iv);
     cfg.ascentCostWeight=s.ascentWeights(iv);
     rng(seed,'twister');  % identical seed for all objective variants
     wallClock=tic;
     [path,st]=mmra_plan_single(startPos,goalPos,env,cfg,true);
     plannerWall=toc(wallClock); % includes the tree-cost audit
     validClock=tic;
     minClear=NaN;risk=NaN;ascent=NaN;refJ=NaN;
     isValid=false;
     if st.success
      [minClear,~]=mmra_path_clearance(path,env,s.fineResolution_m);
      isValid=isfinite(minClear) && ...
          minClear>=s.fineClearThreshold_m && ...
          mmra_path_free(path,env,s.fineResolution_m);
      if isValid
       risk=mmra_path_risk(path,env,s.riskBand_m,s.riskResolution_m);
       ascent=mmra_path_ascent(path);
       refJ=st.pathLength+0.5*risk+0.5*ascent;
      end
     end
     checkWall=toc(validClock);
     r=struct('ProtocolID',s.protocolID, ...
         'BudgetMode',budget,'Terrain',terrain,'Hard',logical(hard), ...
         'APF','legacyAPF','Variant',s.variants{iv}, ...
         'Seed',double(seed),'RiskWeight',s.riskWeights(iv), ...
         'AscentWeight',s.ascentWeights(iv), ...
         'Success',logical(st.success),'FineValid',logical(isValid), ...
         'TimedOut',logical(st.timedOut),'Reason',st.reason, ...
         'Path_m',st.pathLength,'RiskIntegral_m',risk, ...
         'Ascent_m',ascent,'MinClearFine_m',minClear, ...
         'CommonJref_m',refJ,'FirstIter',st.firstIter, ...
         'Search_s',st.search_s,'FullWall_s',plannerWall, ...
         'Validation_s',checkWall,'TreeCostError',st.treeCostError);
     if isempty(records),records=r;else,records(end+1,1)=r;end %#ok<AGROW>
    end
   end
   part=struct2table(records);
   mmra_v21_holdout_validate_part(part,s,budget,terrain,hard,seeds);
   % Save before any final reporting. Never discard completed groups.
   tempPart=fullfile(partDir,sprintf('tmp_%s_%s_h%d.csv', ...
       budget,terrain,hard));
   writetable(part,tempPart);
   [renamed,msg]=movefile(tempPart,partFile);
   assert(renamed,'Failed to finalize checkpoint: %s',msg);
   fprintf('SAVED checkpoint: %s / %s / hard=%d (%d records)\n', ...
       budget,terrain,hard,height(part));
  end
 end
end
mmra_v21_holdout_report(root);
end
