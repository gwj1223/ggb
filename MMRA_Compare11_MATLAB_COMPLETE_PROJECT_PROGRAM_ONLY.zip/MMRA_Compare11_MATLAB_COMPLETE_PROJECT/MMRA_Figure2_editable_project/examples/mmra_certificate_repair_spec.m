function s=mmra_certificate_repair_spec()
%MMRA_CERTIFICATE_REPAIR_SPEC LOCKED DEVELOPMENT experiment, not holdout.
s=mmra_sched_event_spec();
s.protocolID='MMRA_CERT_GUIDED_SPATIAL_REPAIR_DEV_20261029_A';
s.pathSourceProtocolID='MMRA_SCHED_REPAIR_DEV_20261029_A';
s.fineResolution_m=0.10;
s.minFineClear_m=1e-6;
s.maxRepairRounds=3;
s.maxCandidateEvaluations=48;  % per repair round
s.maxProposalsPerFocus=10;
s.maxRepairWall_s=12;           % heuristic wall budget, not formal hard RT cap
s.maxPathInflation=0.25;      % per-UAV, relative to ORIGINAL route
s.maxAddedObjective_m=65;     % per-UAV, relative to ORIGINAL J (metre units)
s.spatialRepairSpan_m=[18 28 38];
s.spatialRepairOffset_m=[18 26];
s.spatialRepairLift_m=[0 6];
s.bootstrapB=1200;
s.bootstrapSeed=71231;
s.maxPilotWallRatio=8;
end
