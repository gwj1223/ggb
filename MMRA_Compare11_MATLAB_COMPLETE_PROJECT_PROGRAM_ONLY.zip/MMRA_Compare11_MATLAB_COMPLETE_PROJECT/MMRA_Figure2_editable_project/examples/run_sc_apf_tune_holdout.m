%RUN_SC_APF_TUNE_HOLDOUT Predeclared SC-APF grid; independent holdout.
% Only SC repulsive-field parameters change; RRT* is untouched.
% Training uses seeds 13001:13010, HOLDOUT uses seeds 14001:14030.
% Never retune after viewing holdout, otherwise the holdout is not independent.
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'));
outDir=fullfile(root,'results_sc_apf_v13');
if ~exist(outDir,'dir'),mkdir(outDir);end
profiles={'paper_gmm','legacy20_sine'};
trainSeeds=13001:13010;
testSeeds=14001:14030;
safeBands=[4 8 12];softWidths=[2 4];kReps=[30 75];
params=struct([]);
for a=1:numel(safeBands)
    for b=1:numel(softWidths)
        for c=1:numel(kReps)
            x=struct('scSafeBand',safeBands(a), ...
                'scSoftWidth',softWidths(b),'scKRep',kReps(c));
            if isempty(params),params=x;else,params(end+1)=x;end %#ok<SAGROW>
        end
    end
end
fprintf('Grid: %d candidates, %d train seeds, %d holdout seeds.\n', ...
    numel(params),numel(trainSeeds),numel(testSeeds));
train=struct([]);
for ip=1:numel(profiles)
    for is=1:numel(trainSeeds)
        row=mmra_sc_trial(profiles{ip},trainSeeds(is), ...
            'MMRA_legacy_APF',struct(),false,false);
        row.Candidate=0;
        if isempty(train),train=row;else,train(end+1,1)=row;end %#ok<SAGROW>
        for ci=1:numel(params)
            row=mmra_sc_trial(profiles{ip},trainSeeds(is), ...
                'MMRA_SC_APF',params(ci),false,false);
            row.Candidate=ci;
            train(end+1,1)=row; %#ok<SAGROW>
        end
    end
    fprintf('Training completed on %s\n',profiles{ip});
end
Ttrain=struct2table(train);
writetable(Ttrain,fullfile(outDir,'sc_apf_train_trials.csv'));

% Predeclared guardrails: do not sacrifice baseline success on either terrain;
% median-like timing comparison would be more robust, but here threshold
% allows 35%% higher MEAN runtime (short MATLAB timings are noisy).
% A candidate can worsen mean path by at most 2%% on either training terrain.
% Score uses success-conditional path length only after guardrails pass.
scoreRows=struct([]);
baselineMeans=zeros(numel(profiles),1);
baselineTimes=zeros(numel(profiles),1);
baselineSuccess=zeros(numel(profiles),1);
for ip=1:numel(profiles)
    sub=Ttrain(Ttrain.Candidate==0 & strcmp(Ttrain.Terrain,profiles{ip}),:);
    baselineMeans(ip)=mean(sub.Path_m(sub.Success));
    baselineTimes(ip)=mean(sub.Search_s);
    baselineSuccess(ip)=sum(sub.Success);
end
for ci=1:numel(params)
    eligible=true;pathRatios=zeros(numel(profiles),1);
    timeRatios=zeros(numel(profiles),1);successCounts=zeros(numel(profiles),1);
    for ip=1:numel(profiles)
        sub=Ttrain(Ttrain.Candidate==ci & strcmp(Ttrain.Terrain,profiles{ip}),:);
        successCounts(ip)=sum(sub.Success);
        if successCounts(ip)==0 || baselineSuccess(ip)==0
            eligible=false;pathRatios(ip)=Inf;
        else
            pathRatios(ip)=mean(sub.Path_m(sub.Success))/baselineMeans(ip);
        end
        timeRatios(ip)=mean(sub.Search_s)/max(baselineTimes(ip),1e-10);
        if successCounts(ip)<baselineSuccess(ip) ...
                || pathRatios(ip)>1.02 || timeRatios(ip)>1.35 ...
                || any(sub.MinClearAboveSafe_m(sub.Success)<0)
            eligible=false;
        end
    end
    score=mean(pathRatios)+0.05*mean(timeRatios);
    sr=struct('Candidate',ci, ...
        'scSafeBand',params(ci).scSafeBand, ...
        'scSoftWidth',params(ci).scSoftWidth, ...
        'scKRep',params(ci).scKRep, ...
        'Eligible',eligible,'Score',score, ...
        'MeanPathRatio',mean(pathRatios), ...
        'MeanTimeRatio',mean(timeRatios), ...
        'PaperSuccess',successCounts(1), ...
        'LegacySuccess',successCounts(2));
    if isempty(scoreRows)
        scoreRows=sr;
    else
        scoreRows(end+1,1)=sr; %#ok<SAGROW>
    end
end
scores=struct2table(scoreRows);
writetable(scores,fullfile(outDir,'sc_apf_train_grid_summary.csv'));
allowed=find(scores.Eligible);
if isempty(allowed)
    % Always evaluate at least the original v1.2 SC parameters on holdout.
    selectedParams=struct('scSafeBand',8,'scSoftWidth',4,'scKRep',30);
    selectedId=0;
    fprintf('No candidate passed training guardrails; evaluating DEFAULT SC.\n');
else
    [~,ix]=min(scores.Score(allowed));
    selectedId=allowed(ix);
    selectedParams=params(selectedId);
    fprintf('Selected SC candidate %d by training data ONLY.\n',selectedId);
end
save(fullfile(outDir,'sc_apf_selected_params.mat'), ...
    'selectedParams','selectedId','trainSeeds','testSeeds', ...
    'safeBands','softWidths','kReps');

% Final independent evaluation: same fixed seeds, no diagnostics overhead.
variants={'RRTstar_unguided','MMRA_legacy_APF','MMRA_SC_APF'};
holdout=struct([]);
for ip=1:numel(profiles)
    for is=1:numel(testSeeds)
        for iv=1:numel(variants)
            if iv==3,p=selectedParams;else,p=struct();end
            row=mmra_sc_trial(profiles{ip},testSeeds(is), ...
                variants{iv},p,false,false);
            if isempty(holdout)
                holdout=row;
            else
                holdout(end+1,1)=row; %#ok<SAGROW>
            end
        end
    end
    fprintf('Holdout completed on %s\n',profiles{ip});
end
Th=struct2table(holdout);
writetable(Th,fullfile(outDir,'sc_apf_holdout_trials.csv'));
summary=struct([]);
for ip=1:numel(profiles)
    for iv=1:numel(variants)
        idx=strcmp(Th.Terrain,profiles{ip}) & strcmp(Th.Variant,variants{iv});
        q=Th(idx,:); yes=q.Success;
        mpath=NaN; mclear=NaN;
        if any(yes)
            mpath=mean(q.Path_m(yes));
            mclear=mean(q.MinClearAboveSafe_m(yes));
        end
        x=struct('Terrain',profiles{ip},'Variant',variants{iv}, ...
            'N',height(q),'SuccessRate',mean(double(yes)), ...
            'MeanPath_m',mpath,'MeanSearch_s',mean(q.Search_s), ...
            'MeanRejectFraction',mean(q.RejectFraction(~isnan(q.RejectFraction))), ...
            'MeanMinimumClear_m',mclear);
        if isempty(summary),summary=x;else,summary(end+1,1)=x;end %#ok<SAGROW>
    end
end
S=struct2table(summary);
writetable(S,fullfile(outDir,'sc_apf_holdout_summary.csv'));
disp(S);
fprintf('Holdout never used for selecting SC parameters.\n');
fprintf('Do not claim an improvement if success or safety worsens.\n');
