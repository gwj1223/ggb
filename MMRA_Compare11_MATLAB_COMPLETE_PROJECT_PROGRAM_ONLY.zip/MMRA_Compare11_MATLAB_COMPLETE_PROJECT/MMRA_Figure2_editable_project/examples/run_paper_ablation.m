%RUN_PAPER_ABLATION New controlled same-seed MATLAB ablation (30 seeds).
% All results are NEW runs, not restored historical measurements.
% Four variants: RRT* first solution, guided first solution,
% guided+pruning, guided+pruning+Bezier.
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'));
[env,cfg,~]=mmra_defaults('paper_gmm');
startPos=[5 7 24]; goalPos=[94 93 25];
assert(mmra_is_free(startPos,env) && mmra_is_free(goalPos,env));
NTRIAL=30;
Seed=zeros(4*NTRIAL,1); Variant=cell(4*NTRIAL,1);
Success=false(4*NTRIAL,1); PathLength_m=NaN(4*NTRIAL,1);
FirstIter=NaN(4*NTRIAL,1); Search_s=NaN(4*NTRIAL,1);
Post_s=NaN(4*NTRIAL,1); Total_s=NaN(4*NTRIAL,1);
SmoothAccepted=false(4*NTRIAL,1); r=0;
for seed=1000:1000+NTRIAL-1
    configs=cell(4,1); guided=[false,true,true,true];
    for j=1:4
        c=cfg; c.prune=j>=3; c.smooth=j>=4;
        configs{j}=c;
    end
    labels={'RRTstar_first','Gradient_first','Gradient_prune','Full_MMRA'};
    for j=1:4
        rng(seed,'twister');
        [p,st]=mmra_plan_single(startPos,goalPos,env,configs{j},guided(j));
        r=r+1;Seed(r)=seed;Variant{r}=labels{j};
        Success(r)=st.success;
        if st.success,PathLength_m(r)=st.pathLength;end
        FirstIter(r)=st.firstIter;
        Search_s(r)=st.search_s;Post_s(r)=st.post_s;
        Total_s(r)=st.total_s;SmoothAccepted(r)=st.smoothAccepted;
    end
    fprintf('New ablation seed %d done\n',seed);
end
T=table(Seed,Variant,Success,PathLength_m,FirstIter, ...
    Search_s,Post_s,Total_s,SmoothAccepted);
outDir=fullfile(root,'results_new');
if ~exist(outDir,'dir'),mkdir(outDir);end
writetable(T,fullfile(outDir,'ablation_new_trials.csv'));
save(fullfile(outDir,'ablation_new_trials.mat'),'T','env','cfg');
fprintf('New trial-level dataset saved; DO NOT merge its runtime with legacy MATLAB/Python tables.\n');
