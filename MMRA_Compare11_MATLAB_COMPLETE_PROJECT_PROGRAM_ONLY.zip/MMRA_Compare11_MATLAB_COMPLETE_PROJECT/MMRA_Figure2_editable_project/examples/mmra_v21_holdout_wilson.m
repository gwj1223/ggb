function [lo,hi] = mmra_v21_holdout_wilson(k,n)
%MMRA_V21_HOLDOUT_WILSON 95%% binomial Wilson CI, no stats toolbox.
assert(n>=0 && n==floor(n) && k>=0 && k<=n);
lo=NaN;hi=NaN;
if n==0,return;end
z=1.959963984540054;
p=k/n;
den=1+z*z/n;
center=(p+z*z/(2*n))/den;
half=z*sqrt(p*(1-p)/n+z*z/(4*n*n))/den;
lo=max(0,center-half);hi=min(1,center+half);
end
