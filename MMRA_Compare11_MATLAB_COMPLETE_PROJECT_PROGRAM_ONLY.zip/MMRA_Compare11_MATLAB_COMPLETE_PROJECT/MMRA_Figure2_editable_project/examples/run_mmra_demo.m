%RUN_MMRA_DEMO One controlled multi-UAV end-to-end geometric experiment.
% Does not reproduce archived MATLAB tables: new random trials are required.
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'));
[env,cfg,sched]=mmra_defaults('paper_gmm');
cfg.maxIter=2500; rng(2026,'twister');
xyStart=[5 7; 5 93; 93 7; 93 93; 10 50];
xyGoal =[93 80; 80 7; 20 83; 20 20; 88 50];
N=size(xyStart,1);
startZ=mmra_terrain(xyStart,env)+env.safetyMargin+12;
goalZ =mmra_terrain(xyGoal,env)+env.safetyMargin+12;
starts=[xyStart startZ]; goals=[xyGoal goalZ];
% Default 'hold' start and terminal occupancy; failure is a VALID outcome.
result=mmra_run_case(starts,goals,[],env,cfg,sched,true);
fprintf('Profile: %s | UAV count: %d | Success: %d | Status: %s\n', ...
    env.profile,N,result.success,result.reason);
fprintf('Spatial planning wall clock (s): %.3f\n',result.spatialTime_s);
if ~isempty(result.scheduler)
    disp(result.scheduler);
end
outDir=fullfile(root,'results_new');
if ~exist(outDir,'dir'),mkdir(outDir);end
save(fullfile(outDir,'demo_result.mat'),'result','env','cfg','sched', ...
    'starts','goals');
