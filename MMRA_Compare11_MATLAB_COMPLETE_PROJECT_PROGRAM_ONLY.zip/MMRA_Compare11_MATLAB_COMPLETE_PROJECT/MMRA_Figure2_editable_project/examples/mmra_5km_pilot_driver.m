function report=mmra_5km_pilot_driver(root,U,seed,terrain,layout)
%MMRA_5KM_PILOT_DRIVER Fresh 5 km RRT* plus staggered speed feedback.
% The OLD 100 m path caches are never used; each UAV's new RRT* path is
% checkpointed. This is a DEV pilot, not an independent validation cohort.
if nargin<4 || isempty(terrain),terrain='paper_gmm_5km';end
if nargin<5 || isempty(layout),layout='distributed';end
addpath(fullfile(root,'src'),fullfile(root,'tests'));
[env,cfg,opt]=mmra_defaults(terrain);
assert(all(env.boundsHi==[5000 5000 2000]));
[starts,goals,meta]=mmra_5km_mission(env,U,seed,layout);
outDir=fullfile(root,'results_5km_dev');
if ~exist(outDir,'dir'),mkdir(outDir);end
stamp=sprintf('%s_%s_u%d_seed%d',terrain,layout,U,seed);
% Separate checkpoints for each user-saved terrain revision.
% Old terrain checkpoint paths / results remain untouched.
if strcmp(terrain,'mountain_cluster_figure2_custom_5km') && ...
        isfield(env,'customMapRevision') && ...
        ~isempty(env.customMapRevision)
    stamp=[stamp '_v' env.customMapRevision];
end
checkpoint=fullfile(outDir,['paths_' stamp '.mat']);
paths=cell(U,1);stats=cell(U,1);spatialOK=false(U,1);
spatialTime_s=zeros(U,1);auditClear_m=NaN(U,1);
% Invalidate caches if geometry, endpoints or planning parameters differ.
protocol='MMRA_5KM_V23_DEV_20261029_A';
newScenery=isfield(env,'sceneTitle');
if newScenery
    % Do not silently reuse v2.3 geometry under an updated scene definition.
    protocol='MMRA_5KM_V24_SCENERY_DEV_20261030_A';
end
if isfile(checkpoint)
    d=load(checkpoint,'checkpointData');
    c=d.checkpointData;
    assert(strcmp(c.protocol,protocol) && ...
        strcmp(c.terrain,terrain) && strcmp(c.layout,layout) && ...
        c.U==U && c.seed==seed && ...
        isequal(c.cfg,cfg) && ...
        isequal(c.starts,starts) && isequal(c.goals,goals) && ...
        (~newScenery || (isfield(c,'env') && isequal(c.env,env))), ...
        'The 5 km path checkpoint belongs to a different experiment.');
    paths=c.paths;stats=c.stats;spatialOK=c.spatialOK;
    spatialTime_s=c.spatialTime_s;auditClear_m=c.auditClear_m;
end
fprintf('=== FRESH 5x5x2 km RRT* / %s / U=%d ===\n',layout,U);
for i=1:U
    if ~isempty(stats{i}),continue;end
    rng(seed+10007*i,'twister');
    tStart=tic;
    [p,st]=mmra_plan_single(starts(i,:),goals(i,:),env,cfg,true);
    spatialTime_s(i)=toc(tStart);
    if st.success
        [cl,~]=mmra_path_clearance(p,env,cfg.guardFineResolution);
        spatialOK(i)=isfinite(cl) && cl>0 && ...
            mmra_path_free(p,env,cfg.guardFineResolution);
        auditClear_m(i)=cl;
        if ~spatialOK(i)
            st.success=false;
            st.reason='failed_finer_sampled_terrain_audit';
        end
    end
    if spatialOK(i),paths{i}=p;else,paths{i}=[];end
    stats{i}=st;
    checkpointData=struct('protocol',protocol,'env',env,'terrain',terrain, ...
        'layout',layout,'U',U,'seed',seed,'cfg',cfg,'starts',starts, ...
        'goals',goals,'paths',{paths},'stats',{stats}, ...
        'spatialOK',spatialOK,'spatialTime_s',spatialTime_s, ...
        'auditClear_m',auditClear_m,'meta',meta);
    tempFile=[checkpoint '.tmp.mat'];
    save(tempFile,'checkpointData','-v7');
    [ok,msg]=movefile(tempFile,checkpoint,'f');assert(ok,msg);
    fprintf('  RRT* UAV %d/%d: success=%d, time=%.2fs, %s\n', ...
        i,U,spatialOK(i),spatialTime_s(i),st.reason);
end
report=struct('terrain',terrain,'layout',layout,'U',U, ...
    'seed',seed,'spatialOK',all(spatialOK), ...
    'numSpatialSuccess',sum(spatialOK),'totalSpatialWall_s', ...
    sum(spatialTime_s),'success',false,'reason','spatial_planning_failed', ...
    'minSeparation_m',NaN,'makespan_s',NaN, ...
    'schedulerWall_s',NaN,'launchInterval_s', ...
    opt.speedFeedbackLaunchInterval_s, ...
    'pathCheckpoint',checkpoint,'totalPathLength_m',NaN);
if all(spatialOK)
    totalLength=0;
    for i=1:U,totalLength=totalLength+mmra_path_length(paths{i});end
    report.totalPathLength_m=totalLength;
    tStart=tic;
    answer=mmra_schedule_speed_feedback(paths,opt);
    report.schedulerWall_s=toc(tStart);
    assert(isfield(answer,'validation') && answer.validation.safe, ...
        'Unsafe motion was emitted by the speed scheduler.');
    report.success=answer.success;
    report.reason=answer.reason;
    report.minSeparation_m=answer.minSeparation;
    report.makespan_s=answer.makespan;
    % Save even failed trajectories, but ONLY if partial motion was safe.
    save(fullfile(outDir,['schedule_' stamp '.mat']), ...
        'answer','env','cfg','opt','starts','goals','meta','-v7');
end
reportFile=fullfile(outDir,['trial_' stamp '.csv']);
writetable(struct2table(report),reportFile);
fprintf('RESULT: spatial=%d/%d, speed=%d, reason=%s, minsep=%g m\n', ...
    sum(spatialOK),U,report.success,report.reason,report.minSeparation_m);
fprintf('Results saved to %s\n',outDir);
end
