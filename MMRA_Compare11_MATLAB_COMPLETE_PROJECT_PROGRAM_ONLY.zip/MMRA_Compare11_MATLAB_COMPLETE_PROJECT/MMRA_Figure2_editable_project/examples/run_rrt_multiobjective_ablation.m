%RUN_RRT_MULTIOBJECTIVE_ABLATION v2.0 development-only cost pilot.
% Fixed 8m RRT*, SAME 0.25m planner collision check and 0.10m audit.
% Four weights x two APF guides, two terrains, two scenario difficulties.
% Compare by BOTH equal iteration ceiling and equal search-core clock cap.
% Do not tune/reuse these developer seeds as an independent holdout cohort.
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'));
outDir=fullfile(root,'results_rrt_multiobjective_v20');
if ~exist(outDir,'dir'),mkdir(outDir);end
statusFile=fullfile(outDir,'RUN_STATUS.txt');
f=fopen(statusFile,'w');assert(f>0);fprintf(f,'IN_PROGRESS\n');fclose(f);
runClock=tic;
terrains={'paper_gmm','legacy20_sine'};
hardGroups=[false true];
normalSeeds=46001:46030;
hardSeeds=49001:49020;
budgetModes={'equal_iterations','equal_search_clock_cap'};
searchCaps=[0.030 0.045]; % fixed before seeing any v2.0 outcomes, sec
apfModes={'legacy','sc_apf'};
apfNames={'legacyAPF','SC_APF'};
weights=[0 0.25 0.50 1.00];
referenceWeight=0.50; % COMMON evaluation Jref for all cost variants
riskBand_m=2.0;riskResolution_m=0.25;
rows=struct([]);
for ib=1:numel(budgetModes)
    for ih=1:numel(hardGroups)
        hard=hardGroups(ih);
        if hard, seeds=hardSeeds;else,seeds=normalSeeds;end
        for ie=1:numel(terrains)
            terrain=terrains{ie};
            [env,base,startPos,goalPos]=mmra_sc_case(terrain,hard);
            base.costMode='length';base.wallBudget_s=Inf;
            base.riskCostBand_m=riskBand_m;
            base.riskCostResolution_m=riskResolution_m;
            base.collectApfDiagnostics=false;
            base.prune=false;base.smooth=false;
            if strcmp(budgetModes{ib},'equal_search_clock_cap')
                base.wallBudget_s=searchCaps(ih);
            end
            for seed=seeds
                for ia=1:numel(apfModes)
                    for iw=1:numel(weights)
                        cfg=base;cfg.apfMode=apfModes{ia};
                        cfg.riskCostWeight=weights(iw);
                        if iw==1
                            cfg.costMode='length';
                        else
                            cfg.costMode='length_risk';
                        end
                        if iw==1
                            variant=[apfNames{ia} '_length'];
                        else
                            variant=sprintf('%s_riskW%g',apfNames{ia},weights(iw));
                        end
                        % Reset RNG for same-seed paired comparisons.
                        rng(seed,'twister');
                        wholeClock=tic;
                        [path,st]=mmra_plan_single(startPos,goalPos,env,cfg,true);
                        fullWall_s=toc(wholeClock);
                        clearFine=NaN;fineValid=false;
                        pathRisk=NaN;refCost=NaN;
                        if st.success
                            [clearFine,~]=mmra_path_clearance(path,env,0.10);
                            fineValid=isfinite(clearFine) && ...
                                clearFine>=1e-6 && ...
                                mmra_path_free(path,env,0.10);
                            if fineValid
                                pathRisk=mmra_path_risk(path,env, ...
                                    riskBand_m,riskResolution_m);
                                refCost=st.pathLength+referenceWeight*pathRisk;
                            end
                        end
                        rec=struct( ...
                            'BudgetMode',budgetModes{ib}, ...
                            'Terrain',terrain,'Hard',logical(hard), ...
                            'APF',apfNames{ia},'Variant',variant, ...
                            'Weight',weights(iw),'Seed',seed, ...
                            'Success',logical(st.success), ...
                            'FineValid',logical(fineValid), ...
                            'TimedOut',logical(st.timedOut), ...
                            'Reason',st.reason, ...
                            'Path_m',st.pathLength, ...
                            'RiskIntegral_m',pathRisk, ...
                            'Jref_w0p5_m',refCost, ...
                            'MinClearFine_m',clearFine, ...
                            'FirstIter',st.firstIter, ...
                            'Search_s',st.search_s, ...
                            'FullWall_s',fullWall_s, ...
                            'TreeCostError',st.treeCostError, ...
                            'RRTObjective_m',st.pathObjective_m, ...
                            'Accepted',st.accepted,'Rejected',st.rejected);
                        if isempty(rows),rows=rec;
                        else,rows(end+1,1)=rec;end %#ok<SAGROW>
                    end
                end
            end
            fprintf('%s / %s / hard=%d: %d seeds complete.\n', ...
                budgetModes{ib},terrain,hard,numel(seeds));
        end
    end
end
T=struct2table(rows);
writetable(T,fullfile(outDir,'multiobjective_trials.csv'));
S=struct([]);P=struct([]);G=struct([]);
for ib=1:numel(budgetModes)
    for ih=1:numel(hardGroups)
        for ie=1:numel(terrains)
            for ia=1:numel(apfNames)
                idx=strcmp(T.BudgetMode,budgetModes{ib}) & ...
                    T.Hard==hardGroups(ih) & ...
                    strcmp(T.Terrain,terrains{ie}) & ...
                    strcmp(T.APF,apfNames{ia});
                base=sortrows(T(idx & T.Weight==0,:),'Seed');
                for iw=1:numel(weights)
                    Q=sortrows(T(idx & T.Weight==weights(iw),:),'Seed');
                    assert(height(Q)==height(base) && ...
                        isequal(Q.Seed,base.Seed));
                    good=logical(Q.FineValid);both=good & logical(base.FineValid);
                    meanP=NaN;meanC=NaN;meanR=NaN;meanJ=NaN;meanIter=NaN;
                    if any(good)
                        meanP=mean(Q.Path_m(good));
                        meanC=mean(Q.MinClearFine_m(good));
                        meanR=mean(Q.RiskIntegral_m(good));
                        meanJ=mean(Q.Jref_w0p5_m(good));
                        meanIter=mean(Q.FirstIter(good));
                    end
                    rec=struct( ...
                        'BudgetMode',budgetModes{ib}, ...
                        'Terrain',terrains{ie},'Hard',hardGroups(ih), ...
                        'APF',apfNames{ia},'Variant',Q.Variant{1}, ...
                        'Weight',weights(iw),'N',height(Q), ...
                        'SuccessN',sum(Q.Success),'FineValidN',sum(good), ...
                        'FineValidRate',mean(double(good)), ...
                        'MeanPathFineValid_m',meanP, ...
                        'MeanMinClearFineValid_m',meanC, ...
                        'MeanRiskIntegralFineValid_m',meanR, ...
                        'MeanCommonJrefFineValid_m',meanJ, ...
                        'MeanFirstIterFineValid',meanIter, ...
                        'MeanSearch_s_All',mean(Q.Search_s), ...
                        'MeanFullWall_s_All',mean(Q.FullWall_s), ...
                        'TimedOutN',sum(Q.TimedOut));
                    if isempty(S),S=rec;else,S(end+1,1)=rec;end %#ok<SAGROW>
                    dPath=NaN;dRisk=NaN;dClear=NaN;dRef=NaN;
                    meanRefPath=NaN;
                    if any(both)
                        dPath=mean(Q.Path_m(both)-base.Path_m(both));
                        dRisk=mean(Q.RiskIntegral_m(both)-base.RiskIntegral_m(both));
                        dClear=mean(Q.MinClearFine_m(both)- ...
                                    base.MinClearFine_m(both));
                        dRef=mean(Q.Jref_w0p5_m(both)-base.Jref_w0p5_m(both));
                        meanRefPath=mean(base.Path_m(both));
                    end
                    lost=sum(base.FineValid & ~Q.FineValid);
                    gained=sum(~base.FineValid & Q.FineValid);
                    wallRatio=mean(Q.FullWall_s)/mean(base.FullWall_s);
                    pr=struct('BudgetMode',budgetModes{ib}, ...
                        'Terrain',terrains{ie},'Hard',hardGroups(ih), ...
                        'APF',apfNames{ia},'Variant',Q.Variant{1}, ...
                        'Weight',weights(iw),'N',height(Q), ...
                        'BothFineValidN',sum(both), ...
                        'BaselineValidCandidateInvalidN',lost, ...
                        'BaselineInvalidCandidateValidN',gained, ...
                        'PairedMeanPathDelta_m',dPath, ...
                        'PairedMeanRiskDelta_m',dRisk, ...
                        'PairedMeanClearDelta_m',dClear, ...
                        'PairedMeanCommonJrefDelta_m',dRef, ...
                        'BaselineMeanPathOnPairs_m',meanRefPath, ...
                        'FullWallRatioVsOwnAPFBaseline',wallRatio);
                    if isempty(P),P=pr;else,P(end+1,1)=pr;end %#ok<SAGROW>
                    if iw==1,continue;end
                    % Conservative development-only gates, not a proof of
                    % superior search or a replacement for unseen holdout.
                    reliabOK=(lost==0) && sum(good)>=sum(base.FineValid);
                    pathOK=isfinite(dPath) && ...
                        dPath<=0.02*meanRefPath;
                    riskOK=isfinite(dRisk) && dRisk<=-0.05;
                    clearOK=isfinite(dClear) && dClear>=-0.25;
                    wallOK=isfinite(wallRatio) && wallRatio<=1.50;
                    g=struct('BudgetMode',budgetModes{ib}, ...
                        'Terrain',terrains{ie},'Hard',hardGroups(ih), ...
                        'APF',apfNames{ia},'Weight',weights(iw), ...
                        'ReliabilityOK',logical(reliabOK), ...
                        'PathOK',logical(pathOK), ...
                        'RiskOK',logical(riskOK), ...
                        'ClearanceOK',logical(clearOK), ...
                        'WallOK',logical(wallOK), ...
                        'GatePass',logical(reliabOK && pathOK && ...
                                           riskOK && clearOK && wallOK));
                    if isempty(G),G=g;else,G(end+1,1)=g;end %#ok<SAGROW>
                end
            end
        end
    end
end
S=struct2table(S);P=struct2table(P);G=struct2table(G);
writetable(S,fullfile(outDir,'multiobjective_summary.csv'));
writetable(P,fullfile(outDir,'multiobjective_paired.csv'));
writetable(G,fullfile(outDir,'multiobjective_pilot_gates.csv'));
disp(S);disp(P);disp(G);
passed=false;
for ia=1:numel(apfNames)
    for iw=2:numel(weights)
        subset=strcmp(G.APF,apfNames{ia}) & G.Weight==weights(iw);
        if sum(subset)==8 && all(G.GatePass(subset))
            passed=true;
            fprintf('PILOT-GATE PASS across all scenes/budgets: %s w=%g\n', ...
                apfNames{ia},weights(iw));
        end
    end
end
if ~passed
    fprintf(['NO weight passed all 8 predeclared development gates', ...
        ' for either APF. Retain v1.7 length-only as default.\n']);
end
f=fopen(fullfile(outDir,'PILOT_INTERPRETATION.txt'),'w');assert(f>0);
fprintf(f,'MMRA v2.0 multiobjective COST pilot (development only)\n');
fprintf(f,'Default fixed8 and length-only RRT* are unchanged.\n');
fprintf(f,'Lambda candidates: 0, 0.25, 0.50, 1.00; band=2m, sample=0.25m.\n');
fprintf(f,'Only common fine-valid paired seeds support paired means.\n');
fprintf(f,'Gates: no loss of baseline-valid paths, path inflation <=2 percent,\n');
fprintf(f,'paired risk reduction >=0.05m, clearance loss <=0.25m, wall <=1.5x.\n');
fprintf(f,'All 8 scene/budget gates must pass for an APF + weight.\n');
fprintf(f,'Any improvements require independent held-out confirmation.\n');
fprintf(f,'NO continuous collision proof. NO Pareto-front optimization.\n');
fprintf(f,'NO multi-UAV scheduling evaluation or real DEM in this pilot.\n');
fprintf(f,'End-to-end wall runtime: %.3f s\n',toc(runClock));
fclose(f);
f=fopen(statusFile,'w');assert(f>0);
fprintf(f,'SUCCESS: development cost-function pilot completed; inspect gates.\n');
fclose(f);
fprintf('SUCCESS: CSV reports under %s\n',outDir);
