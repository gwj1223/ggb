function mmra_v21_holdout_report(root)
%MMRA_V21_HOLDOUT_REPORT Rebuild output tables from saved checkpoints only.
s=mmra_v21_holdout_spec();
outDir=fullfile(root,'results_v21_independent_holdout');
assert(isfolder(outDir),'Holdout results directory missing.');
protocolFile=fullfile(outDir,'PROTOCOL_LOCK.txt');
assert(isfile(protocolFile) && ...
    ~isempty(strfind(fileread(protocolFile),s.protocolID)), ...
    'Missing/incorrect holdout protocol lock.');
partDir=fullfile(outDir,'checkpoints');
rows={};
allPresent=true;
for ib=1:numel(s.budgetModes)
 for ih=1:numel(s.hardGroups)
  hard=s.hardGroups(ih);
  if hard,seeds=s.hardSeeds;else,seeds=s.normalSeeds;end
  for ie=1:numel(s.terrains)
   budget=s.budgetModes{ib};terrain=s.terrains{ie};
   partFile=fullfile(partDir,sprintf('part_%s_%s_h%d.csv', ...
       budget,terrain,hard));
   if ~isfile(partFile),allPresent=false;break;end
   Q=readtable(partFile);
   mmra_v21_holdout_validate_part(Q,s,budget,terrain,hard,seeds);
   rows{end+1,1}=Q; %#ok<AGROW>
  end
 end
end
masterFile=fullfile(outDir,'holdout_trials.csv');
if allPresent && numel(rows)==8
    T=vertcat(rows{:});
    assert(height(T)==3200,'Expected 3200 checkpoint rows.');
    writetable(T,masterFile);
elseif isfile(masterFile)
    fprintf('Using existing complete master trial CSV (checkpoint parts incomplete).\n');
    T=readtable(masterFile);
    assert(height(T)==3200,'Master CSV is incomplete.');
    for ib=1:numel(s.budgetModes)
     for ih=1:numel(s.hardGroups)
      hard=s.hardGroups(ih);
      if hard,seeds=s.hardSeeds;else,seeds=s.normalSeeds;end
      for ie=1:numel(s.terrains)
       budget=s.budgetModes{ib};terrain=s.terrains{ie};
       Q=T(strcmp(T.BudgetMode,budget) & ...
           strcmp(T.Terrain,terrain) & logical(T.Hard)==hard,:);
       mmra_v21_holdout_validate_part(Q,s,budget,terrain,hard,seeds);
      end
     end
    end
else
    error(['Holdout data incomplete. Rerun run_v21_independent_holdout.m ' ...
       'to resume MISSING scene checkpoints; existing checkpoints are reused.']);
end
fprintf('Validated %d FROZEN independent trial records. Reporting only.\n', ...
    height(T));
[S,P,G]=mmra_v21_holdout_analyze(T,s);
writetable(S,fullfile(outDir,'holdout_summary.csv'));
writetable(P,fullfile(outDir,'holdout_paired_ci95.csv'));
writetable(G,fullfile(outDir,'holdout_gates.csv'));
% Independent holdout results are not tuning data; no automatic parameter
% or algorithm replacement is triggered even when all gates pass.
primary=strcmp(G.Gate,'primary_vs_length');
addition=strcmp(G.Gate,'incremental_vs_length_risk');
nPrimary=nnz(G.GatePass(primary));
nAddition=nnz(G.GatePass(addition));
f=fopen(fullfile(outDir,'HOLDOUT_INTERPRETATION.txt'),'w');assert(f>0);
fprintf(f,'MMRA v2.1 FROZEN independent holdout (not development data)\n');
fprintf(f,'%s\n',s.protocolID);
fprintf(f,'N=100 per terrain x difficulty, 4 variants, 2 budget modes.\n');
fprintf(f,'APF=legacy only; risk weight=.5, climb weight=.5.\n');
fprintf(f,'Main candidate: length_risk_climb; each comparison is paired by seed.\n');
fprintf(f,'Primary gate vs length: %d / 8 scene-budget groups pass.\n',nPrimary);
fprintf(f,'Incremental climb gate vs length+risk: %d / 8 groups pass.\n',nAddition);
fprintf(f,'Gates are descriptive mean/observed-run thresholds, NOT formal tests.\n');
fprintf(f,'Gate thresholds are locked before this holdout, informed by development.\n');
fprintf(f,'Primary: no valid losses, path <=+2%%, risk <=-0.05m, ascent <=-0.10m,\n');
fprintf(f,'         clearance >=-0.25m, mean wall ratio <=1.50.\n');
fprintf(f,'Incremental: no valid losses, path <=+1%%, risk <=+0.50m,\n');
fprintf(f,'             ascent <=-0.10m, clearance >=-0.25m, wall <=1.20.\n');
fprintf(f,'95%% paired percentile bootstrap CIs use %d draws, seed %d.\n', ...
    s.bootstrapB,s.bootstrapSeed);
fprintf(f,'Wilson 95%% intervals are used for individual fine-valid proportions.\n');
fprintf(f,'Paired metric CIs condition on both variants yielding valid paths.\n');
fprintf(f,'Failures are NOT treated as zero-length or zero-risk paths.\n');
fprintf(f,'CIs are unadjusted for multiple comparisons; do not overclaim p-values.\n');
fprintf(f,'FullWall excludes independent validation; Search_s is search core only.\n');
fprintf(f,'Search clock cap is checked between iterations; not a strict\n');
fprintf(f,'          identical real CPU wall-time cap. Report full time too.\n');
fprintf(f,'Sampled 0.10m checks are NOT continuous safety guarantees.\n');
fprintf(f,'Risk and positive ascent are proxies, not physical energy models.\n');
fprintf(f,'GMM and sine are synthetic; real DEM and multi-UAV tests remain.\n');
fprintf(f,'The planner stops at first feasible path; no asymptotic optimality claim.\n');
if nPrimary==8 && nAddition==8
 fprintf(f,'All prespecified descriptive gates pass; statistical inference\n');
 fprintf(f,'and new-scene generalization remain to be established.\n');
else
 fprintf(f,'One or more gates failed. Do not retune using these holdout seeds.\n');
end
fclose(f);
statusFile=fullfile(outDir,'RUN_STATUS.txt');
f=fopen(statusFile,'w');assert(f>0);
fprintf(f,'SUCCESS: 3200 trial records validated and reported.\n');fclose(f);
fprintf('HOLDOUT primary vs length: %d/8; incremental vs length+risk: %d/8.\n', ...
    nPrimary,nAddition);
if nPrimary<8 || nAddition<8
    fprintf('NOT FULLY VALIDATED. Do not retune on these holdout seeds.\n');
else
    fprintf('All DESCRIPTIVE gates pass; inspect 95%% CIs before claims.\n');
end
fprintf('Outputs: %s\n',outDir);
% Show only the 8+8 confirmatory rows, not every comparison.
disp(G);
end
