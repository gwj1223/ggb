%RUN_RRT_THREEOBJECTIVE_ABLATION Development-only additive RRT* cost pilot.
% Four objectives x 2 APF x 2 terrains x 2 difficulty x 2 budget modes.
% Fifth cost strategy is IDENTICAL lambda=.5 length-risk with separate
% v2.0 checks, isolating the speed effect of fused collision+risk sampling.
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'));
outDir=fullfile(root,'results_rrt_threeobjective_v21');
if ~exist(outDir,'dir'),mkdir(outDir);end
statusFile=fullfile(outDir,'RUN_STATUS.txt');
f=fopen(statusFile,'w');assert(f>0);fprintf(f,'IN_PROGRESS\n');fclose(f);
clock=tic;
terrains={'paper_gmm','legacy20_sine'};
hardGroups=[false true];
normalSeeds=46001:46030;hardSeeds=49001:49020; % reused DEVELOPMENT seeds
budgetModes={'equal_iterations','equal_search_clock_cap'};
searchCaps=[0.030 0.045]; % unchanged from v2.0; includes both costs
apfModes={'legacy','sc_apf'};
apfNames={'legacyAPF','SC_APF'};
% Preselected for pilot; NOT optimized and NOT held-out validation.
referenceRiskWeight=0.5;referenceAscentWeight=0.5;
riskBand_m=2.0;riskResolution_m=0.25;
variantLabels={'length','length_risk','length_climb', ...
    'length_risk_climb','length_risk_separate'};
modeVals={'length','length_risk','length_climb', ...
    'length_risk_climb','length_risk'};
riskWeights=[0 0.5 0 0.5 0.5];
ascentWeights=[0 0 0.5 0.5 0];
evalModes={'fused','fused','fused','fused','separate'};
rows=struct([]);
for ib=1:numel(budgetModes)
 for ih=1:numel(hardGroups)
  hard=hardGroups(ih);
  if hard,seeds=hardSeeds;else,seeds=normalSeeds;end
  for ie=1:numel(terrains)
   terrain=terrains{ie};
   [env,base,startPos,goalPos]=mmra_sc_case(terrain,hard);
   base.costMode='length';base.wallBudget_s=Inf;
   base.riskCostBand_m=riskBand_m;
   base.riskCostResolution_m=riskResolution_m;
   base.collectApfDiagnostics=false;
   base.prune=false;base.smooth=false;
   if strcmp(budgetModes{ib},'equal_search_clock_cap')
       base.wallBudget_s=searchCaps(ih);
   end
   for seed=seeds
    for ia=1:numel(apfModes)
     for iv=1:numel(variantLabels)
      cfg=base;cfg.apfMode=apfModes{ia};
      cfg.costMode=modeVals{iv};
      cfg.riskCostWeight=riskWeights(iv);
      cfg.ascentCostWeight=ascentWeights(iv);
      cfg.costEvalMode=evalModes{iv};
      rng(seed,'twister');
      wholeClock=tic;
      [path,st]=mmra_plan_single(startPos,goalPos,env,cfg,true);
      fullWall=toc(wholeClock);  % INCLUDES tree-cost consistency audit
      clearFine=NaN;fineValid=false;
      riskPath=NaN;ascentPath=NaN;refCost=NaN;
      if st.success
       [clearFine,~]=mmra_path_clearance(path,env,0.10);
       fineValid=isfinite(clearFine) && clearFine>=1e-6 && ...
           mmra_path_free(path,env,0.10);
       if fineValid
        riskPath=mmra_path_risk(path,env, ...
            riskBand_m,riskResolution_m);
        ascentPath=mmra_path_ascent(path);
        refCost=st.pathLength+referenceRiskWeight*riskPath+ ...
            referenceAscentWeight*ascentPath;
       end
      end
      rec=struct('BudgetMode',budgetModes{ib}, ...
        'Terrain',terrain,'Hard',logical(hard), ...
        'APF',apfNames{ia},'Variant',variantLabels{iv}, ...
        'RiskWeight',riskWeights(iv), ...
        'AscentWeight',ascentWeights(iv), ...
        'EvalMode',evalModes{iv},'Seed',seed, ...
        'Success',logical(st.success), ...
        'FineValid',logical(fineValid), ...
        'TimedOut',logical(st.timedOut), ...
        'Reason',st.reason,'Path_m',st.pathLength, ...
        'RiskIntegral_m',riskPath,'Ascent_m',ascentPath, ...
        'Jref_m',refCost,'MinClearFine_m',clearFine, ...
        'FirstIter',st.firstIter,'Search_s',st.search_s, ...
        'FullWall_s',fullWall,'TreeCostError',st.treeCostError, ...
        'Objective_m',st.pathObjective_m, ...
        'EdgeCostEvaluations',st.edgeCostEvaluations, ...
        'FusedRiskEvaluations',st.fusedRiskEvaluations);
      if isempty(rows),rows=rec;else,rows(end+1,1)=rec;end %#ok<SAGROW>
     end
    end
   end
   fprintf('%s / %s / hard=%d: %d seeds complete.\n', ...
       budgetModes{ib},terrain,hard,numel(seeds));
  end
 end
end
T=struct2table(rows);
writetable(T,fullfile(outDir,'threeobjective_trials.csv'));
S=struct([]);P=struct([]);G=struct([]);E=struct([]);
for ib=1:numel(budgetModes)
 for ih=1:numel(hardGroups)
  for ie=1:numel(terrains)
   for ia=1:numel(apfNames)
    ix=strcmp(T.BudgetMode,budgetModes{ib}) & ...
       T.Hard==hardGroups(ih) & ...
       strcmp(T.Terrain,terrains{ie}) & ...
       strcmp(T.APF,apfNames{ia});
    baseline=sortrows(T(ix & strcmp(T.Variant,'length'),:),'Seed');
    separate=sortrows(T(ix & ...
        strcmp(T.Variant,'length_risk_separate'),:),'Seed');
    fused=sortrows(T(ix & strcmp(T.Variant,'length_risk'),:),'Seed');
    assert(isequal(baseline.Seed,separate.Seed) && ...
       isequal(baseline.Seed,fused.Seed));
    % Exact paired-path equivalence is meaningful for equal ITERATIONS.
    % Under equal CLOCK caps, faster evaluation changes how many iterations
    % are allowed, so divergent paths are expected and not a numerical bug.
    matching=all(logical(separate.FineValid)==logical(fused.FineValid)) ...
       && all((~separate.FineValid & ~fused.FineValid) | ...
         (abs(separate.Path_m-fused.Path_m)<1e-7 & ...
          abs(separate.RiskIntegral_m-fused.RiskIntegral_m)<1e-7 & ...
          abs(separate.Ascent_m-fused.Ascent_m)<1e-7));
    if strcmp(budgetModes{ib},'equal_search_clock_cap')
        matching=NaN; % not assessed for unequal iteration counts
    end
    e=struct('BudgetMode',budgetModes{ib}, ...
       'Terrain',terrains{ie},'Hard',hardGroups(ih), ...
       'APF',apfNames{ia},'N',height(separate), ...
       'SamePathsAndValidity',double(matching), ...
       'OldMeanWall_s',mean(separate.FullWall_s), ...
       'FusedMeanWall_s',mean(fused.FullWall_s), ...
       'FusedWallRatio',mean(fused.FullWall_s)/ ...
                          mean(separate.FullWall_s), ...
       'FusedRiskCalls',sum(fused.FusedRiskEvaluations));
    if isempty(E),E=e;else,E(end+1,1)=e;end %#ok<SAGROW>
    for iv=1:4
     Q=sortrows(T(ix & strcmp(T.Variant,variantLabels{iv}),:),'Seed');
     assert(isequal(Q.Seed,baseline.Seed));
     good=logical(Q.FineValid);
     both=good & logical(baseline.FineValid);
     mPath=NaN;mRisk=NaN;mAscent=NaN;mClear=NaN;mJ=NaN;
     if any(good)
      mPath=mean(Q.Path_m(good));mRisk=mean(Q.RiskIntegral_m(good));
      mAscent=mean(Q.Ascent_m(good));
      mClear=mean(Q.MinClearFine_m(good));mJ=mean(Q.Jref_m(good));
     end
     record=struct('BudgetMode',budgetModes{ib}, ...
       'Terrain',terrains{ie},'Hard',hardGroups(ih), ...
       'APF',apfNames{ia},'Variant',variantLabels{iv}, ...
       'N',height(Q),'FineValidN',sum(good), ...
       'FineValidRate',mean(double(good)), ...
       'MeanPath_m',mPath,'MeanRiskIntegral_m',mRisk, ...
       'MeanAscent_m',mAscent,'MeanMinClearFine_m',mClear, ...
       'MeanCommonJref_m',mJ, ...
       'MeanSearch_s_All',mean(Q.Search_s), ...
       'MeanFullWall_s_All',mean(Q.FullWall_s), ...
       'TimedOutN',sum(Q.TimedOut));
     if isempty(S),S=record;else,S(end+1,1)=record;end %#ok<SAGROW>
     dPath=NaN;dRisk=NaN;dAsc=NaN;dClear=NaN;dJ=NaN;meanBase=NaN;
     if any(both)
       dPath=mean(Q.Path_m(both)-baseline.Path_m(both));
       dRisk=mean(Q.RiskIntegral_m(both)-baseline.RiskIntegral_m(both));
       dAsc=mean(Q.Ascent_m(both)-baseline.Ascent_m(both));
       dClear=mean(Q.MinClearFine_m(both)- ...
           baseline.MinClearFine_m(both));
       dJ=mean(Q.Jref_m(both)-baseline.Jref_m(both));
       meanBase=mean(baseline.Path_m(both));
     end
     lost=sum(baseline.FineValid & ~Q.FineValid);
     gained=sum(~baseline.FineValid & Q.FineValid);
     wallRatio=mean(Q.FullWall_s)/mean(baseline.FullWall_s);
     pp=struct('BudgetMode',budgetModes{ib}, ...
       'Terrain',terrains{ie},'Hard',hardGroups(ih), ...
       'APF',apfNames{ia},'Variant',variantLabels{iv}, ...
       'N',height(Q),'BothFineValidN',sum(both), ...
       'BaselineValidCandidateInvalidN',lost, ...
       'BaselineInvalidCandidateValidN',gained, ...
       'PairedPathDelta_m',dPath,'PairedRiskDelta_m',dRisk, ...
       'PairedAscentDelta_m',dAsc, ...
       'PairedClearDelta_m',dClear, ...
       'PairedCommonJrefDelta_m',dJ, ...
       'MeanBasePathOnPairs_m',meanBase, ...
       'FullWallRatioVsBaseline',wallRatio);
     if isempty(P),P=pp;else,P(end+1,1)=pp;end %#ok<SAGROW>
     if iv==1,continue;end
     % These are development-only predeclared feasibility gates.
     % 'length_climb' has no required risk improvement by design.
     reliabOK=(lost==0) && sum(good)>=sum(baseline.FineValid);
     pathOK=isfinite(dPath) && dPath<=0.02*meanBase;
     if riskWeights(iv)>0
       riskOK=isfinite(dRisk) && dRisk<=-0.05;
     else
       riskOK=isfinite(dRisk) && dRisk<=0.25;
     end
     if ascentWeights(iv)>0
       ascentOK=isfinite(dAsc) && dAsc<=-0.10;
     else
       ascentOK=true;
     end
     clearOK=isfinite(dClear) && dClear>=-0.25;
     wallOK=isfinite(wallRatio) && wallRatio<=1.50;
     g=struct('BudgetMode',budgetModes{ib}, ...
       'Terrain',terrains{ie},'Hard',hardGroups(ih), ...
       'APF',apfNames{ia},'Variant',variantLabels{iv}, ...
       'ReliabilityOK',logical(reliabOK),'PathOK',logical(pathOK), ...
       'RiskOK',logical(riskOK),'AscentOK',logical(ascentOK), ...
       'ClearanceOK',logical(clearOK),'WallOK',logical(wallOK), ...
       'GatePass',logical(reliabOK && pathOK && riskOK && ...
            ascentOK && clearOK && wallOK));
     if isempty(G),G=g;else,G(end+1,1)=g;end %#ok<SAGROW>
    end
   end
  end
 end
end
S=struct2table(S);P=struct2table(P);G=struct2table(G);
E=struct2table(E);
writetable(S,fullfile(outDir,'threeobjective_summary.csv'));
writetable(P,fullfile(outDir,'threeobjective_paired.csv'));
writetable(G,fullfile(outDir,'threeobjective_pilot_gates.csv'));
writetable(E,fullfile(outDir,'risk_fusion_equivalence.csv'));
disp(S);disp(P);disp(G);disp(E);
for i=1:height(E)
 if isfinite(E.SamePathsAndValidity(i)) && ...
       ~E.SamePathsAndValidity(i)
  warning('Fused and separate risk evaluation differ; inspect seeds.');
 end
end
for ia=1:numel(apfNames)
 for iv=2:4
  subset=strcmp(G.APF,apfNames{ia}) & ...
      strcmp(G.Variant,variantLabels{iv});
  if sum(subset)==8 && all(G.GatePass(subset))
   fprintf('DEVELOPMENT GATE PASS across eight cases: %s / %s\n', ...
       apfNames{ia},variantLabels{iv});
  end
 end
end
f=fopen(fullfile(outDir,'PILOT_INTERPRETATION.txt'),'w');assert(f>0);
fprintf(f,'MMRA v2.1 three-objective pilot (DEVELOPMENT DATA ONLY)\n');
fprintf(f,'Four modes: length / length_risk / length_climb / length_risk_climb.\n');
fprintf(f,'Fixed risk=0.5, ascent=0.5, risk band 2m, resolution 0.25m.\n');
fprintf(f,'Search clock caps 0.030s normal, 0.045s hard (v2.0 unchanged).\n');
fprintf(f,'v2.0 separate checker+cost vs v2.1 fused uses IDENTICAL weights.\n');
fprintf(f,'Risk improvement >=0.05m if risk objective active, else <=0.25m worsening.\n');
fprintf(f,'Positive ascent objective requires paired ascent reduction >=0.10m.\n');
fprintf(f,'No loss of fine-valid paths; path increase <=2%%; clearance loss <=0.25m.\n');
fprintf(f,'Full wall time <=1.50x length-only baseline; ALL 8 gates required.\n');
fprintf(f,'Ascent is an energy PROXY not a power model; not Pareto multiobjective.\n');
fprintf(f,'No independent holdout, continuous safety proof, real DEM or multi-UAV scaling.\n');
fprintf(f,'Overall time %.3f seconds.\n',toc(clock));
fclose(f);
f=fopen(statusFile,'w');assert(f>0);
fprintf(f,'SUCCESS: development pilot complete; inspect CSV gates.\n');
fclose(f);
fprintf('SUCCESS: CSV reports under %s\n',outDir);
