%RUN_SC_APF_SAFETY_HOLDOUT Training-only safety-aware parameter selection.
% v1.5 reuses development training 17001:17030; holdout remains UNSEEN:
%   training 17001:17030 (30 per terrain); final holdout 16001:16050.
% Previously viewed v1.3 holdout 14001:14030 is EXPLORATORY now.
% RRT* expansion/APF equations unchanged; shared collision resolution refined.
% No SC candidate that fails guardrails is evaluated as the chosen method.
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'));
outDir=fullfile(root,'results_sc_apf_v15');
if ~exist(outDir,'dir'),mkdir(outDir);end
% Invalidate prior selection/holdout files before rerunning training. This
% prevents stale artifacts from being interpreted as a new successful fit.
stale={'sc_apf_selected_params.mat','sc_apf_holdout_trials.csv', ...
    'sc_apf_holdout_summary.csv','sc_apf_holdout_safety_verdict.csv', ...
    'sc_apf_selected_diagnostic_trials.csv','sc_apf_stress_trials.csv', ...
    'sc_apf_selection_status.txt'};
for i=1:numel(stale)
    f=fullfile(outDir,stale{i});
    if exist(f,'file'),delete(f);end
end
profiles={'paper_gmm','legacy20_sine'};
trainSeeds=17001:17030;
holdoutSeeds=16001:16050;
g=mmra_sc_guard_defaults();
safeBands=[4 8 12];softWidths=[2 4];kReps=[30 75];
params=struct([]);
for a=1:numel(safeBands)
    for b=1:numel(softWidths)
        for c=1:numel(kReps)
            x=struct('scSafeBand',safeBands(a), ...
                'scSoftWidth',softWidths(b),'scKRep',kReps(c));
            if isempty(params),params=x;else,params(end+1)=x;end %#ok<SAGROW>
        end
    end
end
fprintf('Safety grid: %d candidates, %d training seeds, %d NEW holdout seeds.\n', ...
    numel(params),numel(trainSeeds),numel(holdoutSeeds));
fprintf('Clearance slack: mean=%.2fm, p10=%.2fm, worst=%.2fm.\n', ...
    g.meanClearSlack_m,g.p10ClearSlack_m,g.worstClearSlack_m);
train=struct([]);
for ip=1:numel(profiles)
    for is=1:numel(trainSeeds)
        row=mmra_sc_trial(profiles{ip},trainSeeds(is), ...
            'MMRA_legacy_APF',struct(),false,false);
        row.Candidate=0;
        if isempty(train),train=row;else,train(end+1,1)=row;end %#ok<SAGROW>
        for ci=1:numel(params)
            row=mmra_sc_trial(profiles{ip},trainSeeds(is), ...
                'MMRA_SC_APF',params(ci),false,false);
            row.Candidate=ci;
            train(end+1,1)=row; %#ok<SAGROW>
        end
    end
    fprintf('Training finished: %s\n',profiles{ip});
end
Ttrain=struct2table(train);
writetable(Ttrain,fullfile(outDir,'sc_apf_train_trials.csv'));

% The guard comparison is a reusable pure function with unit tests.
scoreRows=struct([]);detailRows=struct([]);
for ci=1:numel(params)
    pathRatio=zeros(numel(profiles),1);
    timeRatio=zeros(numel(profiles),1);
    allEligible=true;
    terrainChecks=cell(numel(profiles),1);
    for ip=1:numel(profiles)
        baseline=Ttrain(Ttrain.Candidate==0 & ...
            strcmp(Ttrain.Terrain,profiles{ip}),:);
        candidate=Ttrain(Ttrain.Candidate==ci & ...
            strcmp(Ttrain.Terrain,profiles{ip}),:);
        r=mmra_sc_guard_compare(baseline,candidate,g);
        terrainChecks{ip}=r;
        allEligible=allEligible && r.Eligible;
        pathRatio(ip)=r.PathRatio;
        timeRatio(ip)=r.TimeRatio;
        r.Candidate=ci;r.Terrain=profiles{ip};
        if isempty(detailRows),detailRows=r;
        else,detailRows(end+1,1)=r;end %#ok<SAGROW>
    end
    score=mean(pathRatio)+0.05*mean(timeRatio);
    if ~isfinite(score),score=Inf;end
    sr=struct('Candidate',ci, ...
        'scSafeBand',params(ci).scSafeBand, ...
        'scSoftWidth',params(ci).scSoftWidth, ...
        'scKRep',params(ci).scKRep, ...
        'Eligible',allEligible,'Score',score, ...
        'MeanPathRatio',mean(pathRatio),'MeanTimeRatio',mean(timeRatio), ...
        'PaperEligible',terrainChecks{1}.Eligible, ...
        'LegacyEligible',terrainChecks{2}.Eligible, ...
        'PaperReason',terrainChecks{1}.Reason, ...
        'LegacyReason',terrainChecks{2}.Reason);
    if isempty(scoreRows),scoreRows=sr;
    else,scoreRows(end+1,1)=sr;end %#ok<SAGROW>
end
scores=struct2table(scoreRows);
writetable(scores,fullfile(outDir,'sc_apf_train_grid_summary.csv'));
writetable(struct2table(detailRows), ...
    fullfile(outDir,'sc_apf_train_guardrail_details.csv'));
allowed=find(scores.Eligible);
if isempty(allowed)
    fprintf('NO SC candidate met predeclared safety guards.\n');
    fprintf('NO holdout was run; do not label default SC parameters as validated.\n');
    fid=fopen(fullfile(outDir,'sc_apf_selection_status.txt'),'w');
    fprintf(fid,'NO_ELIGIBLE_SC_CANDIDATE\n');fclose(fid);
    return;
end
[~,ix]=min(scores.Score(allowed));
selectedId=allowed(ix);
selectedParams=params(selectedId);
save(fullfile(outDir,'sc_apf_selected_params.mat'), ...
    'selectedParams','selectedId','trainSeeds','holdoutSeeds', ...
    'safeBands','softWidths','kReps','g');
fid=fopen(fullfile(outDir,'sc_apf_selection_status.txt'),'w');
fprintf(fid,'SELECTED_TRAIN_ONLY candidate=%d\n',selectedId);fclose(fid);
fprintf('Selected candidate %d based on training only: band=%.1f, width=%.1f, k=%.1f.\n', ...
    selectedId,selectedParams.scSafeBand, ...
    selectedParams.scSoftWidth,selectedParams.scKRep);

% No SC tuning, selection or threshold adjustment after this point.
variants={'RRTstar_unguided','MMRA_legacy_APF','MMRA_SC_APF'};
holdout=struct([]);
for ip=1:numel(profiles)
    for is=1:numel(holdoutSeeds)
        for iv=1:numel(variants)
            if iv==3,p=selectedParams;else,p=struct();end
            row=mmra_sc_trial(profiles{ip},holdoutSeeds(is), ...
                variants{iv},p,false,false);
            if isempty(holdout),holdout=row;
            else,holdout(end+1,1)=row;end %#ok<SAGROW>
        end
    end
    fprintf('Final independent holdout finished: %s\n',profiles{ip});
end
Th=struct2table(holdout);
writetable(Th,fullfile(outDir,'sc_apf_holdout_trials.csv'));
summaryRows=struct([]);verdictRows=struct([]);
for ip=1:numel(profiles)
    for iv=1:numel(variants)
        mask=strcmp(Th.Terrain,profiles{ip}) & strcmp(Th.Variant,variants{iv});
        q=Th(mask,:);yes=logical(q.Success);
        mp=NaN;mc=NaN;worst=NaN;
        if any(yes)
            mp=mean(q.Path_m(yes));
            mc=mean(q.MinClearFine_m(yes));
            worst=min(q.MinClearFine_m(yes));
        end
        r=struct('Terrain',profiles{ip},'Variant',variants{iv}, ...
            'N',height(q),'SuccessCount',sum(yes), ...
            'SuccessRate',mean(double(yes)), ...
            'MeanPath_m',mp,'MeanSearch_s',mean(q.Search_s), ...
            'MeanRejectFraction',mean(q.RejectFraction(~isnan(q.RejectFraction))), ...
            'MeanFineMinClear_m',mc,'WorstFineMinClear_m',worst);
        if isempty(summaryRows),summaryRows=r;
        else,summaryRows(end+1,1)=r;end %#ok<SAGROW>
    end
    B=Th(strcmp(Th.Terrain,profiles{ip}) & ...
        strcmp(Th.Variant,'MMRA_legacy_APF'),:);
    C=Th(strcmp(Th.Terrain,profiles{ip}) & ...
        strcmp(Th.Variant,'MMRA_SC_APF'),:);
    verdict=mmra_sc_guard_compare(B,C,g);
    verdict.Terrain=profiles{ip};
    if isempty(verdictRows),verdictRows=verdict;
    else,verdictRows(end+1,1)=verdict;end %#ok<SAGROW>
    fprintf('FINAL guard %s: %s (path ratio=%.4f, min-clear mean delta=%.3fm).\n', ...
        profiles{ip},verdict.Reason,verdict.PathRatio,verdict.MeanClearDelta_m);
end
S=struct2table(summaryRows);V=struct2table(verdictRows);
writetable(S,fullfile(outDir,'sc_apf_holdout_summary.csv'));
writetable(V,fullfile(outDir,'sc_apf_holdout_safety_verdict.csv'));
disp(S);
if all(V.Eligible)
    fprintf('All PREDECLARED guards passed on final independent holdout.\n');
else
    fprintf('WARNING: At least one final holdout guard failed.\n');
    fprintf('Do not retune on these holdout seeds; report the failure transparently.\n');
end
fprintf('Planning edge check: 0.25m; independent path check: 0.10m. NOT a continuous guarantee.\n');
