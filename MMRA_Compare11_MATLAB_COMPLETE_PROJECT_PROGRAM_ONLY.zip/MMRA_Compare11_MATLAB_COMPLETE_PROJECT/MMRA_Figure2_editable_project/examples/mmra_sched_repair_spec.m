function s = mmra_sched_repair_spec()
%MMRA_SCHED_REPAIR_SPEC Development cohort; do NOT confuse with v2.1 holdout.
s=struct();
s.protocolID='MMRA_SCHED_REPAIR_DEV_20261029_A';
s.terrains={'paper_gmm','legacy20_sine'};
s.sizes=[5 10 20];
s.nTrials=30;
s.speed_mps=15;
s.dSafe_m=10;
s.delayStep_s=0.25;
s.maxDelay_s=60;
s.startPolicy='hold';
s.endPolicy='hold';
s.repairMaxCandidates=8;
s.repairMaxRounds=2;
s.pathFineResolution_m=0.10;
s.minFineClear_m=1e-6;
s.bootstrapB=1500;
s.bootstrapSeed=31019;
s.minImprovedFraction=0.10; % observed improvement beyond fallback
s.maxWallRatio=4.0;        % all-method wall clocks, not inner sched_s
s.costMode='length_risk_climb';
s.riskWeight=0.5;
s.ascentWeight=0.5;
s.maxIter=900;
s.prune=false;
s.smooth=false;
end
