%RUN_CONFLICT_PRIORITY_ABLATION Compare scheduling on SAME planned paths.
% No fake outcomes: failed spatial paths/scheduling are saved as failures.
% Default 5 seeds/size is a code shakedown; change NTRIAL to >=30 for paper.
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'));
[env,cfg,sched]=mmra_defaults('paper_gmm');
cfg.maxIter=2500;
% Ring-to-opposite terrain missions; distinct terminal points for each UAV.
% HOLD/HOLD occupancy is the conservative physical model.
sched.startPolicy='hold';sched.endPolicy='hold';
sizes=[5 10 20]; NTRIAL=5; nRows=numel(sizes)*NTRIAL;
U=zeros(nRows,1);Seed=zeros(nRows,1);SpatialOK=false(nRows,1);
BaselineOK=false(nRows,1);ConflictOnlyOK=false(nRows,1);ConflictAwareOK=false(nRows,1);
BaselineMakespan_s=NaN(nRows,1);ConflictOnlyMakespan_s=NaN(nRows,1);CAMakespan_s=NaN(nRows,1);
BaselineSched_s=NaN(nRows,1);ConflictOnlySched_s=NaN(nRows,1);CASched_s=NaN(nRows,1);
BaselineMaxDelay_s=NaN(nRows,1);CAMaxDelay_s=NaN(nRows,1);
BaselineMinSep_m=NaN(nRows,1);CAMinSep_m=NaN(nRows,1);
ConflictsBefore=NaN(nRows,1);Edges=NaN(nRows,1);
Chosen=cell(nRows,1);Reason=cell(nRows,1);
r=0;
for n=sizes
    for rep=1:NTRIAL
        r=r+1; U(r)=n; seed=20000+100*n+rep;Seed(r)=seed;
        rng(seed,'twister');
        theta=2*pi*(0:n-1)'/n+0.1;
        xy1=[50+43*cos(theta),50+43*sin(theta)];
        xy2=[50+43*cos(theta+pi+0.07),50+43*sin(theta+pi+0.07)];
        starts=[xy1,mmra_terrain(xy1,env)+env.safetyMargin+10];
        goals=[xy2,mmra_terrain(xy2,env)+env.safetyMargin+10];
        % Plan ONCE and reuse the SAME resulting paths in both schedulers.
        result=mmra_run_case(starts,goals,[],env,cfg,sched,true);
        SpatialOK(r)=isempty(result.failureUAV);
        if ~SpatialOK(r)
            Reason{r}=result.reason; Chosen{r}='none';
            fprintf('U=%d seed=%d spatial failure: %s\n',n,seed,result.reason);
            continue;
        end
        b=result.scheduler; c=mmra_schedule_conflict_aware(result.paths,sched);
        % Conflict-degree-only ablation: NO baseline fallback.
        lens=zeros(n,1);
        for ii=1:n, [~,~,lens(ii)]=mmra_arc(result.paths{ii});end
        [~,idx]=sortrows([-c.conflictDegrees,-lens,(1:n)'],[1 2 3]);
        pureOpts=sched; pureOpts.priorityOrder=reshape(idx,1,[]);
        pure=mmra_schedule(result.paths,pureOpts);
        BaselineOK(r)=b.success;ConflictOnlyOK(r)=pure.success;
        ConflictAwareOK(r)=c.success;
        BaselineMakespan_s(r)=b.makespan;
        ConflictOnlyMakespan_s(r)=pure.makespan;
        CAMakespan_s(r)=c.makespan;
        BaselineSched_s(r)=b.schedule_s;
        ConflictOnlySched_s(r)=pure.schedule_s;
        CASched_s(r)=c.schedule_s;
        BaselineMinSep_m(r)=b.minSeparation;CAMinSep_m(r)=c.minSeparation;
        ConflictsBefore(r)=b.preConflicts;Edges(r)=c.conflictGraphEdges;
        if b.success,BaselineMaxDelay_s(r)=max(b.delays);end
        if c.success,CAMaxDelay_s(r)=max(c.delays);end
        Chosen{r}=c.chosenStrategy;Reason{r}=c.reason;
        if b.success
            assert(c.success && c.makespan<=b.makespan+1e-8);
        end
        if pure.success
            assert(c.success && c.makespan<=pure.makespan+1e-8);
        end
        fprintf('U=%d seed=%d baseline=%d CA=%d chosen=%s\n', ...
            n,seed,b.success,c.success,c.chosenStrategy);
    end
end
T=table(U,Seed,SpatialOK,BaselineOK,ConflictOnlyOK,ConflictAwareOK, ...
    BaselineMakespan_s,ConflictOnlyMakespan_s,CAMakespan_s, ...
    BaselineSched_s,ConflictOnlySched_s,CASched_s, ...
    BaselineMaxDelay_s,CAMaxDelay_s,BaselineMinSep_m,CAMinSep_m, ...
    ConflictsBefore,Edges,Chosen,Reason);
outDir=fullfile(root,'results_new');
if ~exist(outDir,'dir'),mkdir(outDir);end
writetable(T,fullfile(outDir,'conflict_priority_ablation.csv'));
save(fullfile(outDir,'conflict_priority_ablation.mat'), ...
    'T','env','cfg','sched');
fprintf('Saved controlled priority ablation. Keep ALL failed trials.\n');
