%RUN_END_TO_END_SCALING New multi-UAV full-pipeline experiment template.
% Scenario: ring-to-opposite trajectories on documented paper GMM terrain.
% This has NOT been executed; path or scheduler failure must be reported.
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'));
[env,cfg,sched]=mmra_defaults('paper_gmm');
cfg.maxIter=2500;
% Set start/end to INACTIVE to model takeoff/landing *out of monitored
% airspace*. HOLD (default) is required when stationary aircraft remain
% physically present. This assumption must be stated in the paper.
sched.startPolicy='inactive'; sched.endPolicy='inactive';
sizes=[5 10 20]; nTrials=5; totalRows=numel(sizes)*nTrials;
U=zeros(totalRows,1); Seed=zeros(totalRows,1); Success=false(totalRows,1);
Spatial_s=NaN(totalRows,1); Scheduler_s=NaN(totalRows,1);
Total_s=NaN(totalRows,1); PreConflicts=NaN(totalRows,1);
PostConflicts=NaN(totalRows,1); MinSep_m=NaN(totalRows,1);
Makespan_s=NaN(totalRows,1); Failure=cell(totalRows,1);r=0;
for num=sizes
    for rep=1:nTrials
        seed=10000+100*num+rep; rng(seed,'twister');
        theta=2*pi*(0:num-1)'/num+0.13;
        x1=50+43*cos(theta); y1=50+43*sin(theta);
        x2=50+43*cos(theta+pi+0.07); y2=50+43*sin(theta+pi+0.07);
        startXY=[x1 y1];goalXY=[x2 y2];
        starts=[startXY mmra_terrain(startXY,env)+env.safetyMargin+10];
        goals =[goalXY mmra_terrain(goalXY,env)+env.safetyMargin+10];
        out=mmra_run_case(starts,goals,[],env,cfg,sched,true);
        r=r+1;U(r)=num;Seed(r)=seed;Success(r)=out.success;
        Spatial_s(r)=out.spatialTime_s; Failure{r}=out.reason;
        if ~isempty(out.scheduler)
            z=out.scheduler;
            Scheduler_s(r)=z.schedule_s;
            PreConflicts(r)=z.preConflicts;
            PostConflicts(r)=z.postConflicts;
            MinSep_m(r)=z.minSeparation;Makespan_s(r)=z.makespan;
            Total_s(r)=out.spatialTime_s+z.schedule_s;
        end
        fprintf('U=%d seed=%d success=%d [%s]\n',num,seed,out.success,out.reason);
    end
end
T=table(U,Seed,Success,Spatial_s,Scheduler_s,Total_s, ...
    PreConflicts,PostConflicts,MinSep_m,Makespan_s,Failure);
outDir=fullfile(root,'results_new');
if ~exist(outDir,'dir'),mkdir(outDir);end
writetable(T,fullfile(outDir,'end_to_end_new_trials.csv'));
save(fullfile(outDir,'end_to_end_new_trials.mat'),'T','env','cfg','sched');
