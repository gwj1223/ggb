%RUN_SC_APF_DEMO Demonstrate SC-APF on same 5-UAV geometry as prior demo.
% This uses the new repulsion option; scheduling stays on its old default.
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'));
[env,cfg,sched]=mmra_defaults('paper_gmm');
cfg.apfMode='sc_apf';cfg.maxIter=2500;
rng(2026,'twister');
xyStart=[5 7;5 93;93 7;93 93;10 50];
xyGoal =[93 80;80 7;20 83;20 20;88 50];
starts=[xyStart mmra_terrain(xyStart,env)+env.safetyMargin+12];
goals =[xyGoal  mmra_terrain(xyGoal,env)+env.safetyMargin+12];
result=mmra_run_case(starts,goals,[],env,cfg,sched,true);
fprintf('SC-APF demo: success=%d reason=%s, spatialTime_s=%.3f\n', ...
    result.success,result.reason,result.spatialTime_s);
outDir=fullfile(root,'results_new');
if ~exist(outDir,'dir'),mkdir(outDir);end
save(fullfile(outDir,'sc_apf_demo.mat'),'result','starts','goals','env','cfg','sched');
