function mmra_certificate_repair_driver(root,only20,sourceOverride)
%MMRA_CERTIFICATE_REPAIR_DRIVER Compare on cached ORIGINAL spatial tasks.
% No rerunning RRT*. Each case saves an independent CSV checkpoint and
% optionally a MAT file for follow-up visualization of repaired candidates.
if nargin<2,only20=true;end
if nargin<3,sourceOverride='';end
s=mmra_certificate_repair_spec();
caseDir=localLocatePaths(root,sourceOverride,s);
if only20,sizes=20;else,sizes=s.sizes;end
outDir=fullfile(root,'results_certificate_spatial_repair_dev');
partDir=fullfile(outDir,'checkpoints');
geomDir=fullfile(outDir,'repaired_paths');
if ~isfolder(partDir),mkdir(partDir);end
if ~isfolder(geomDir),mkdir(geomDir);end
lock=fullfile(outDir,'PROTOCOL_LOCK.txt');
if isfile(lock)
    info=fileread(lock);
    assert(contains(info,s.protocolID), ...
        'Protocol mismatch: do not reuse old repair checkpoints.');
else
    f=fopen(lock,'w');assert(f>0);
    fprintf(f,'%s\n',s.protocolID);
    fprintf(f,'Development seeds ALREADY used in prior scheduler experiments.\n');
    fprintf(f,'Original cached paths source: %s\n',caseDir);
    fprintf(f,'UNCHANGED: hold/hold, 15 m/s, 10 m separation, 0:0.25:60 s.\n');
    fprintf(f,'Local 3D dogleg path repair; original endpoints unchanged.\n');
    fprintf(f,'Frozen RRT* objective lambda=mu=0.5; original path source immutable.\n');
    fprintf(f,'Repair cap: %d rounds, %d proposals/round, %g s soft budget.\n', ...
        s.maxRepairRounds,s.maxCandidateEvaluations,s.maxRepairWall_s);
    fprintf(f,'NO multi-UAV success claim from repairing pair certificates alone.\n');
    fclose(f);
end
fprintf('=== Certificate-guided selective spatial feedback, CACHED paths ===\n');
fprintf('Path source: %s\n',caseDir);
fprintf('Testing UAV sizes %s, %d seeds per terrain/size.\n', ...
    mat2str(sizes),s.nTrials);
fprintf('UNCHANGED hold/hold, speed=15, distance=10, grid=0:0.25:60.\n');
fprintf('Original RRT* routes are NEVER replanned or overwritten.\n');
for ie=1:numel(s.terrains)
    terrain=s.terrains{ie};
    [env,cfg,opt]=mmra_defaults(terrain);
    cfg.apfMode='legacy';cfg.costMode='length_risk_climb';
    cfg.riskCostWeight=0.5;cfg.ascentCostWeight=0.5;
    cfg.prune=false;cfg.smooth=false;
    opt.speed=s.speed_mps;opt.dSafe=s.dSafe_m;
    opt.maxDelay=s.maxDelay_s;opt.delayStep=s.delayStep_s;
    opt.startPolicy=s.startPolicy;opt.endPolicy=s.endPolicy;
    opt.repairMaxCandidates=s.repairMaxCandidates;
    opt.repairMaxRounds=s.repairMaxRounds;
    opt.eventBeamWidth=s.eventBeamWidth;
    opt.eventMaxExpandedNodes=s.eventMaxExpandedNodes;
    opt.eventMaxDelayChoices=s.eventMaxDelayChoices;
    opt.eventMaxVariableChoices=s.eventMaxVariableChoices;
    opt.eventMaxVerifyCandidates=s.eventMaxVerifyCandidates;
    opt.spatialRepairMaxRepairRounds=s.maxRepairRounds;
    opt.spatialRepairMaxCandidateEvaluations=s.maxCandidateEvaluations;
    opt.spatialRepairMaxProposalsPerFocus=s.maxProposalsPerFocus;
    opt.spatialRepairMaxRepairWall_s=s.maxRepairWall_s;
    opt.spatialRepairMaxPathInflation=s.maxPathInflation;
    opt.spatialRepairMaxAddedObjective_m=s.maxAddedObjective_m;
    opt.spatialRepairFineResolution_m=s.fineResolution_m;
    opt.spatialRepairMinFineClear_m=s.minFineClear_m;
    opt.spatialRepairSpan_m=s.spatialRepairSpan_m;
    opt.spatialRepairOffset_m=s.spatialRepairOffset_m;
    opt.spatialRepairLift_m=s.spatialRepairLift_m;
    for n=reshape(sizes,1,[])
        for rep=1:s.nTrials
            seed=930000+10000*ie+100*n+rep;
            stamp=sprintf('%s_u%d_seed%d',terrain,n,seed);
            srcFile=fullfile(caseDir,['case_' stamp '.mat']);
            partFile=fullfile(partDir,['part_' stamp '.csv']);
            assert(isfile(srcFile),'Missing original RRT* path: %s',srcFile);
            if isfile(partFile)
                prior=readtable(partFile);
                assert(height(prior)==1 && ...
                    all(strcmp(string(prior.ProtocolID),string(s.protocolID))) && ...
                    prior.NumUAV(1)==n && prior.Seed(1)==seed, ...
                    'Invalid saved repair checkpoint %s',partFile);
                continue;
            end
            a=load(srcFile,'caseData'); c=a.caseData;
            assert(strcmp(c.ProtocolID,s.pathSourceProtocolID) && ...
                c.NumUAV==n && c.Seed==seed && ...
                strcmp(c.Terrain,terrain), ...
                'Cached spatial scenario metadata mismatch.');
            r=struct('ProtocolID',s.protocolID,'Terrain',terrain, ...
                'NumUAV',double(n),'Seed',double(seed), ...
                'SpatialOK',logical(c.SpatialOK), ...
                'BaselineOK',false,'FeedbackOK',false, ...
                'BaselineWall_s',NaN,'FeedbackWall_s',NaN, ...
                'BaselineMakespan_s',NaN,'FeedbackMakespan_s',NaN, ...
                'FeedbackMinSep_m',NaN,'OriginalNoGoPairs',NaN, ...
                'FinalNoGoPairs',NaN,'OriginalGridCertificates',NaN, ...
                'FinalGridCertificates',NaN,'ClearedGridCertificates',NaN, ...
                'RepairedPathsN',NaN,'AcceptedRepairsN',NaN, ...
                'CandidatesTriedN',NaN,'TerrainValidCandidatesN',NaN, ...
                'OracleCallsN',NaN,'PathLengthDelta_m',NaN, ...
                'RiskDelta_m',NaN,'AscentDelta_m',NaN, ...
                'FineClearanceMin_m',NaN, ...
                'RepairReason','skipped_invalid_original_paths');
            if c.SpatialOK
                oldPaths=c.Paths;
                assert(iscell(oldPaths) && numel(oldPaths)==n);
                t0=tic;
                baseline=mmra_schedule_eventwindow(oldPaths,opt);
                r.BaselineWall_s=toc(t0);
                t0=tic;
                feedback=mmra_certificate_guided_spatial_repair( ...
                    oldPaths,env,cfg,opt);
                r.FeedbackWall_s=toc(t0);
                if baseline.success
                    assert(feedback.success && ...
                        feedback.makespan<=baseline.makespan+1e-8, ...
                        'Previously feasible fixed path lost a safe result.');
                end
                assert(feedback.finalOracleCertificates<= ...
                    feedback.originalOracleCertificates || ...
                    feedback.acceptedRepairs==0, ...
                    'Feedback increased independently proven no-go count.');
                r.BaselineOK=logical(baseline.success);
                r.FeedbackOK=logical(feedback.success);
                r.BaselineMakespan_s=baseline.makespan;
                r.FeedbackMakespan_s=feedback.makespan;
                r.FeedbackMinSep_m=feedback.minSeparation;
                r.OriginalNoGoPairs=feedback.originalNoGoPairs;
                r.FinalNoGoPairs=feedback.finalNoGoPairs;
                r.OriginalGridCertificates=feedback.originalOracleCertificates;
                r.FinalGridCertificates=feedback.finalOracleCertificates;
                r.ClearedGridCertificates=max(0, ...
                    r.OriginalGridCertificates-r.FinalGridCertificates);
                r.RepairedPathsN=feedback.repairedPathCount;
                r.AcceptedRepairsN=feedback.acceptedRepairs;
                r.CandidatesTriedN=feedback.candidatesTried;
                r.TerrainValidCandidatesN=feedback.terrainValidCandidates;
                r.OracleCallsN=feedback.oracleCalls;
                r.PathLengthDelta_m=feedback.pathLengthDelta_m;
                r.RiskDelta_m=feedback.riskDelta_m;
                r.AscentDelta_m=feedback.ascentDelta_m;
                r.FineClearanceMin_m=feedback.fineClearanceMin_m;
                r.RepairReason=feedback.reason;
                if feedback.acceptedRepairs>0
                    originalPaths=oldPaths; repairedPaths=feedback.paths;
                    audit=rmfield(feedback,'paths');
                    file=fullfile(geomDir,['paths_' stamp '.mat']);
                    tmp=fullfile(geomDir,['tmp_paths_' stamp '.mat']);
                    save(tmp,'originalPaths','repairedPaths','audit','-v7');
                    [ok,msg]=movefile(tmp,file);assert(ok,msg);
                end
            end
            tmpFile=fullfile(partDir,['tmp_part_' stamp '.csv']);
            writetable(struct2table(r),tmpFile);
            [ok,msg]=movefile(tmpFile,partFile);
            assert(ok,'Could not finalize result checkpoint: %s',msg);
            if mod(rep,5)==0 || rep==s.nTrials
                fprintf('SAVED %s / U=%d / %d of %d cases.\n', ...
                    terrain,n,rep,s.nTrials);
            end
        end
    end
end
mmra_certificate_repair_report(root,only20);
end

function found=localLocatePaths(root,override,s)
if ~isempty(override)
    found=override;
else
    found=fullfile(root,'results_scheduler_repair_dev','path_cases');
end
probe=sprintf('case_%s_u20_seed%d.mat',s.terrains{1}, ...
    930000+10000+100*20+1);
if isfolder(found) && isfile(fullfile(found,probe)),return;end
% Optional automatic discovery of an adjacent old project. Never search
% the whole disk: limit search to the parent of the extracted project.
if isempty(override)
    up=fileparts(root);
    listings=dir(fullfile(up,'**',probe));
    for i=1:numel(listings)
        candidate=listings(i).folder;
        other=sprintf('case_%s_u20_seed%d.mat',s.terrains{2}, ...
            930000+20000+100*20+1);
        if isfile(fullfile(candidate,other))
            found=candidate;
            fprintf('AUTO-FOUND previous saved path cases: %s\n',found);
            return;
        end
    end
end
error(['Saved path-case MAT files not found. Copy the old project''s ' ...
    'results_scheduler_repair_dev/path_cases folder into this project, ' ...
    'or set pathCasesFolder in run_certificate_guided_20u_cached.m. ' ...
    'No RRT* replanning is required. Looked in: %s'],found);
end
