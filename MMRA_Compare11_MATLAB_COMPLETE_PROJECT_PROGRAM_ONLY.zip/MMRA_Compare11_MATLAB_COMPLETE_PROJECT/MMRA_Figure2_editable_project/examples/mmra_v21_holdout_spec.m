function s = mmra_v21_holdout_spec()
%MMRA_V21_HOLDOUT_SPEC Frozen before evaluation on independent seeds.
s = struct();
s.protocolID='MMRA_V21_HOLDOUT_FROZEN_20261029_A';
s.terrains={'paper_gmm','legacy20_sine'};
s.hardGroups=[false true];
s.budgetModes={'equal_iterations','equal_search_clock_cap'};
s.normalSeeds=(810001:810100).';
s.hardSeeds=(820001:820100).';
s.searchCaps_s=[0.030 0.045]; % same as v2.1 development
s.variants={'length','length_risk','length_climb','length_risk_climb'};
s.riskWeights=[0 0.5 0 0.5];
s.ascentWeights=[0 0 0.5 0.5];
s.riskBand_m=2.0;
s.riskResolution_m=0.25;
s.fineResolution_m=0.10;
s.fineClearThreshold_m=1e-6;
s.bootstrapB=2000;
s.bootstrapSeed=20261029;
assert(~any(ismember(s.normalSeeds,(46001:46030).')) && ...
    ~any(ismember(s.hardSeeds,(49001:49020).')), ...
    'Holdout seeds overlap v2.1 development seeds.');
assert(isempty(intersect(s.normalSeeds,s.hardSeeds)));
end
