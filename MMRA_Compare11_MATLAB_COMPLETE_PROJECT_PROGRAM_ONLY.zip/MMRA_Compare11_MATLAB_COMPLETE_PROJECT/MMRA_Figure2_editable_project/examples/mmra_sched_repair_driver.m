function mmra_sched_repair_driver(root)
%MMRA_SCHED_REPAIR_DRIVER Plan a scenario ONCE; run 3 schedulers on same paths.
% Save paths BEFORE scheduling, and checkpoint every comparison row.
s=mmra_sched_repair_spec();
outDir=fullfile(root,'results_scheduler_repair_dev');
caseDir=fullfile(outDir,'path_cases');
partDir=fullfile(outDir,'checkpoints');
if ~exist(caseDir,'dir'),mkdir(caseDir);end
if ~exist(partDir,'dir'),mkdir(partDir);end
protocolFile=fullfile(outDir,'PROTOCOL_LOCK.txt');
if isfile(protocolFile)
    prior=fileread(protocolFile);
    assert(~isempty(strfind(prior,s.protocolID)), ...
        'Protocol mismatch: do not mix scheduler experiments.');
else
    f=fopen(protocolFile,'w');assert(f>0);
    fprintf(f,'%s\n',s.protocolID);
    fprintf(f,'Development experiment, NOT frozen independent holdout.\n');
    fprintf(f,'APF legacy; spatial cost length_risk_climb; lambda=mu=0.5.\n');
    fprintf(f,'Raw polylines: prune=false, smooth=false; fixed 15m/s.\n');
    fprintf(f,'Collision: fixed polyline continuous-time pair minimum.\n');
    fprintf(f,'Endpoint occupancy: hold/hold; no artificial disappears.\n');
    fprintf(f,'Sizes 5,10,20; 30 seeded variable-geometries per terrain/size.\n');
    fprintf(f,'All methods receive identical paths and delay grid 0:0.25:60.\n');
    fprintf(f,'New method tests at most 8 additional priority orders and 2 repair rounds.\n');
    fprintf(f,'No dynamic feasibility or continuous terrain clearance certificate.\n');
    fprintf(f,'Generated MATLAB %s, %s, %s\n',version,computer,datestr(now,30));
    fclose(f);
end
statusFile=fullfile(outDir,'RUN_STATUS.txt');
f=fopen(statusFile,'w');assert(f>0);
fprintf(f,'IN_PROGRESS: case and comparison checkpoints are resumable.\n');fclose(f);

for ie=1:numel(s.terrains)
 terrain=s.terrains{ie};
 for ni=1:numel(s.sizes)
  n=s.sizes(ni);
  [env,cfg,sched]=mmra_defaults(terrain);
  cfg.apfMode='legacy';cfg.costMode=s.costMode;
  cfg.riskCostWeight=s.riskWeight;cfg.ascentCostWeight=s.ascentWeight;
  cfg.prune=s.prune;cfg.smooth=s.smooth;
  cfg.maxIter=s.maxIter;cfg.wallBudget_s=Inf;
  sched.speed=s.speed_mps;sched.dSafe=s.dSafe_m;
  sched.delayStep=s.delayStep_s;sched.maxDelay=s.maxDelay_s;
  sched.startPolicy=s.startPolicy;sched.endPolicy=s.endPolicy;
  sched.repairMaxCandidates=s.repairMaxCandidates;
  sched.repairMaxRounds=s.repairMaxRounds;
  sched.mode='length';
  for rep=1:s.nTrials
   seed=930000+10000*ie+100*n+rep;
   stamp=sprintf('%s_u%d_seed%d',terrain,n,seed);
   caseFile=fullfile(caseDir,['case_' stamp '.mat']);
   partFile=fullfile(partDir,['part_' stamp '.csv']);
   if isfile(partFile)
       already=readtable(partFile);
       assert(height(already)==1 && ...
           all(strcmp(already.ProtocolID,s.protocolID)) && ...
           already.NumUAV(1)==n && already.Seed(1)==seed, ...
           'Invalid saved checkpoint %s',partFile);
       continue;
   end
   if isfile(caseFile)
       data=load(caseFile,'caseData');caseData=data.caseData;
       assert(strcmp(caseData.ProtocolID,s.protocolID) && ...
           caseData.NumUAV==n && caseData.Seed==seed, ...
           'Cached spatial path case does not match protocol.');
   else
       % Randomized task geometry, not only randomized RRT* sampling.
       rng(seed,'twister');
       phase=rand*2*pi;
       rStart=45.5+0.5*rand; % >= 45.5m
       rGoal=33.5+0.5*rand;  % >= 33.5m
       rotation=pi+0.12+0.12*rand;
       theta=phase+2*pi*(0:n-1)'/n;
       startXY=[50+rStart*cos(theta),50+rStart*sin(theta)];
       goalXY=[50+rGoal*cos(theta+rotation),50+rGoal*sin(theta+rotation)];
       altitudeExtra=9+rand;
       starts=[startXY,mmra_terrain(startXY,env)+env.safetyMargin+altitudeExtra];
       goals=[goalXY,mmra_terrain(goalXY,env)+env.safetyMargin+altitudeExtra];
       spatialWall=tic;
       res=mmra_run_case(starts,goals,[],env,cfg,sched,true);
       spatialWall_s=toc(spatialWall);
       spatialOK=isempty(res.failureUAV);
       fineMin=NaN;
       if spatialOK
           fineMin=inf;
           for jj=1:numel(res.paths)
               p=res.paths{jj};
               [cl,~]=mmra_path_clearance(p,env,s.pathFineResolution_m);
               fineMin=min(fineMin,cl);
               if ~isfinite(cl) || cl<s.minFineClear_m || ...
                       ~mmra_path_free(p,env,s.pathFineResolution_m)
                   spatialOK=false;
               end
           end
       end
       caseData=struct('ProtocolID',s.protocolID,'Terrain',terrain, ...
           'NumUAV',n,'Seed',seed,'Paths',{res.paths}, ...
           'SpatialOK',logical(spatialOK), ...
           'SpatialWall_s',res.spatialTime_s, ...
           'GenerationWall_s',spatialWall_s, ...
           'FineClearMin_m',fineMin, ...
           'SpatialReason',localSpatialReason(spatialOK,res.reason), ...
           'Starts',starts,'Goals',goals);
       tmpCase=fullfile(caseDir,['tmp_case_' stamp '.mat']);
       save(tmpCase,'caseData','-v7');
       [ok,msg]=movefile(tmpCase,caseFile);
       assert(ok,'Cannot finalize spatial checkpoint: %s',msg);
   end
   r=struct('ProtocolID',s.protocolID,'Terrain',terrain, ...
       'NumUAV',double(n),'Seed',double(seed), ...
       'SpatialOK',logical(caseData.SpatialOK), ...
       'SpatialWall_s',caseData.SpatialWall_s, ...
       'FineClearMin_m',caseData.FineClearMin_m, ...
       'SpatialReason',caseData.SpatialReason, ...
       'InitialConflicts',NaN, ...
       'LengthOK',false,'CAOK',false,'RepairOK',false, ...
       'LengthMakespan_s',NaN,'CAMakespan_s',NaN,'RepairMakespan_s',NaN, ...
       'LengthWall_s',NaN,'CAWall_s',NaN,'RepairWall_s',NaN, ...
       'LengthMinSep_m',NaN,'CAMinSep_m',NaN,'RepairMinSep_m',NaN, ...
       'LengthMaxDelay_s',NaN,'CAMaxDelay_s',NaN,'RepairMaxDelay_s',NaN, ...
       'RepairCandidates',NaN,'RepairAccepted',NaN, ...
       'RepairPairChecks',NaN,'RepairStrategy','not_run', ...
       'EndpointPolicy','hold/hold');
   if caseData.SpatialOK
       paths=caseData.Paths;
       wall=tic; b=mmra_schedule(paths,sched); bw=toc(wall);
       wall=tic; c=mmra_schedule_conflict_aware(paths,sched); cw=toc(wall);
       wall=tic; d=mmra_schedule_bottleneck(paths,sched); dw=toc(wall);
       assert(~b.success || (c.success && ...
           c.makespan<=b.makespan+1e-8),'CA lost feasible baseline');
       assert(~c.success || (d.success && ...
           d.makespan<=c.makespan+1e-8),'Repair lost feasible CA');
       if d.success
           assert(d.postConflicts==0 && ...
               d.minSeparation>=s.dSafe_m-sched.tol-1e-8);
       end
       r.InitialConflicts=b.preConflicts;
       r.LengthOK=b.success;r.CAOK=c.success;r.RepairOK=d.success;
       r.LengthMakespan_s=b.makespan;
       r.CAMakespan_s=c.makespan;
       r.RepairMakespan_s=d.makespan;
       r.LengthWall_s=bw;r.CAWall_s=cw;r.RepairWall_s=dw;
       r.LengthMinSep_m=b.minSeparation;r.CAMinSep_m=c.minSeparation;
       r.RepairMinSep_m=d.minSeparation;
       if b.success,r.LengthMaxDelay_s=max(b.delays);end
       if c.success,r.CAMaxDelay_s=max(c.delays);end
       if d.success,r.RepairMaxDelay_s=max(d.delays);end
       r.RepairCandidates=d.repairCandidates;
       r.RepairAccepted=d.repairAccepted;
       r.RepairPairChecks=d.repairPairChecks;
       r.RepairStrategy=d.repairStrategy;
   end
   row=struct2table(r);
   tmpPart=fullfile(partDir,['tmp_part_' stamp '.csv']);
   writetable(row,tmpPart);
   [ok,msg]=movefile(tmpPart,partFile);
   assert(ok,'Cannot finalize comparison checkpoint: %s',msg);
   if mod(rep,10)==0 || rep==s.nTrials
       fprintf('SAVED %s / U=%d / %d of %d seeds.\n', ...
           terrain,n,rep,s.nTrials);
   end
  end
 end
end
mmra_sched_repair_report(root);
end

function reason=localSpatialReason(spatialOK,original)
if spatialOK, reason='spatial_paths_fine_valid';
else,reason=original;end
end
