%RUN_EDGE_RESOLUTION_AUDIT Small DEVELOPMENT-only sample audit.
% Focus on seeds that previously exposed coarse/fine clearance mismatches.
% The chosen SC parameters are diagnostic only, not tuned/selected here.
% This does NOT consume unseen final holdout seeds.
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'));
outDir=fullfile(root,'results_sc_apf_v15');
if ~exist(outDir,'dir'),mkdir(outDir);end
profiles={'paper_gmm','legacy20_sine'};
variants={'MMRA_legacy_APF','MMRA_SC_APF'};
seeds=[17003 17004 17013 17025 17027 17029];
% An existing SC grid point is used to diagnose sampling; it is not selected.
probe=struct('scSafeBand',12,'scSoftWidth',4,'scKRep',75);
rows=struct([]);
for ip=1:numel(profiles)
    for is=1:numel(seeds)
        for iv=1:numel(variants)
            if iv==2, p=probe; else, p=struct(); end
            row=mmra_sc_trial(profiles{ip},seeds(is),variants{iv}, ...
                p,false,false);
            if isempty(rows), rows=row;
            else, rows(end+1,1)=row; end %#ok<SAGROW>
        end
    end
end
T=struct2table(rows);
writetable(T,fullfile(outDir,'edge_resolution_audit_trials.csv'));
fprintf('v1.5: 0.25m planner and 0.10m independent sampled validation.\n');
for ip=1:numel(profiles)
    for iv=1:numel(variants)
        ix=strcmp(T.Terrain,profiles{ip}) & strcmp(T.Variant,variants{iv});
        q=T(ix,:); successful=logical(q.Success);
        fineBad=successful & (~isfinite(q.MinClearFine_m) | ...
            q.MinClearFine_m<1e-6);
        fprintf('%-14s %-18s successful=%d/%d fine-check-fail=%d\n', ...
            profiles{ip},variants{iv},sum(successful),height(q),sum(fineBad));
    end
end
fprintf('Audit is for debugging only, not a statistical claim or continuous safety proof.\n');
