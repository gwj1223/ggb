%% RUN_URBAN_MAP_STANDALONE - independent 3D urban environment preview.
% No external repository, no toolbox, no MMRA Figure 2 paths are needed.
% This is a VISUAL DEMO: routes are illustrative, NOT RRT* results.
% To animate, run: urbanAnimate = true; run('run_urban_map_standalone.m')
% Keep this script in its own independent directory.
mapRoot = fileparts(mfilename('fullpath'));
if isempty(mapRoot), mapRoot = pwd; end
if ~exist('urbanAnimate','var') || isempty(urbanAnimate)
    urbanAnimate = false;
end
if ~exist('urbanBuildingCount','var') || isempty(urbanBuildingCount)
    urbanBuildingCount = 26;
end
assert(isscalar(urbanAnimate) && (islogical(urbanAnimate) || isnumeric(urbanAnimate)));
assert(isnumeric(urbanBuildingCount) && isscalar(urbanBuildingCount) && ...
    isfinite(urbanBuildingCount) && urbanBuildingCount >= 1 && ...
    urbanBuildingCount <= 30 && urbanBuildingCount == round(urbanBuildingCount));

urbanSeed = 20261101;
urbanBounds = [0 90; 0 90; 0 35];
stream = RandStream('mt19937ar','Seed',urbanSeed);
% 30 fixed blocks on a jittered city grid; select a reproducible subset.
[cx,cy] = meshgrid([12 25 38 51 64 77],[12 27 42 57 72]);
slots = [cx(:),cy(:)];
[~,order] = sort(rand(stream,30,1));
slots = slots(order(1:urbanBuildingCount),:);
blocks = zeros(urbanBuildingCount,6);
for j=1:urbanBuildingCount
    wx = 5.2 + 3.5*rand(stream);
    wy = 5.0 + 3.2*rand(stream);
    ht = 9.0 + 17.0*rand(stream);
    px = slots(j,1) + 2*(rand(stream)-0.5);
    py = slots(j,2) + 2*(rand(stream)-0.5);
    blocks(j,:) = [px-wx/2,px+wx/2,py-wy/2,py+wy/2,0,ht];
end

% Five display-only corridors with different headings and lengths.
% Their planned-flight collision safety is NOT verified by this preview.
starts = [6 6 8; 84 6 9; 45 6 10; 6 45 10; 6 84 9];
goals  = [84 84 8; 6 84 9; 45 84 10; 84 45 10; 84 6 9];
N = 5;
flightDuration = [48 52 46 50 56];
routeColors = [0.14 0.93 0.19; ...
               1.00 0.95 0.15; ...
               1.00 0.17 0.17; ...
               0.89 0.45 0.98; ...
               0.84 0.56 0.00];
paths = cell(N,1);
for i=1:N
    u=linspace(0,1,241)';
    v=goals(i,1:2)-starts(i,1:2);
    n=[-v(2),v(1)]/norm(v);
    wiggle=2.0*sin(2*pi*u).*sin(pi*u);
    xy=(1-u).*starts(i,1:2)+u.*goals(i,1:2)+wiggle.*n;
    zz=(1-u)*starts(i,3)+u*goals(i,3)+20*sin(pi*u).^0.8;
    paths{i}=[xy,zz];
end

% Moving spheres cross nominal paths at known times (display only).
targetUav = [1 3 4];
fractions = [0.44 0.55 0.63];
obstacles = repmat(struct('p0',zeros(1,3),'p1',zeros(1,3), ...
    't0',0,'t1',0,'radius_m',2.1,'targetUAV',0,'crossTime',0),3,1);
for j=1:3
    i=targetUav(j);
    p=interp1(linspace(0,1,size(paths{i},1)),paths{i},fractions(j));
    heading=goals(i,1:2)-starts(i,1:2);
    sideways=[-heading(2),heading(1)]/norm(heading);
    a=p; b=p;
    a(1:2)=p(1:2)-7.0*sideways;
    b(1:2)=p(1:2)+7.0*sideways;
    ct=flightDuration(i)*fractions(j);
    obstacles(j).p0=a;
    obstacles(j).p1=b;
    obstacles(j).t0=ct-6;
    obstacles(j).t1=ct+6;
    obstacles(j).radius_m=2.1;
    obstacles(j).targetUAV=i;
    obstacles(j).crossTime=ct;
end

snapshotTime = 24;
fig=figure('Name','Independent Urban 5-UAV Map - Visualization Only', ...
    'NumberTitle','off','Color','w','Position',[80 70 1180 760]);
ax=axes('Parent',fig);
hold(ax,'on');
patch('Parent',ax,'Vertices',[0 0 0;90 0 0;90 90 0;0 90 0], ...
    'Faces',[1 2 3 4],'FaceColor',[0.91 0.94 0.96], ...
    'EdgeColor','none','HandleVisibility','off');
faceIdx=[1 2 3 4;5 6 7 8;1 2 6 5;2 3 7 6;3 4 8 7;4 1 5 8];
for j=1:size(blocks,1)
    b=blocks(j,:);
    x0=b(1); x1=b(2); y0=b(3); y1=b(4); z0=b(5); z1=b(6);
    verts=[x0 y0 z0;x1 y0 z0;x1 y1 z0;x0 y1 z0; ...
           x0 y0 z1;x1 y0 z1;x1 y1 z1;x0 y1 z1];
    patch('Parent',ax,'Vertices',verts,'Faces',faceIdx, ...
        'FaceColor',[0.55 0.65 0.75], ...
        'EdgeColor',[0.31 0.38 0.46], ...
        'FaceAlpha',0.75,'EdgeAlpha',0.5,'LineWidth',0.6, ...
        'HandleVisibility','off');
end
uavHandles=gobjects(N,1);
for i=1:N
    tr=paths{i}; c=routeColors(i,:);
    plot3(ax,tr(:,1),tr(:,2),tr(:,3),'-','Color',c, ...
        'LineWidth',2.5,'HandleVisibility','off');
    plot3(ax,tr(1,1),tr(1,2),tr(1,3),'o', ...
        'MarkerFaceColor',c,'MarkerEdgeColor','k','MarkerSize',6, ...
        'HandleVisibility','off');
    plot3(ax,tr(end,1),tr(end,2),tr(end,3),'s', ...
        'MarkerFaceColor',c,'MarkerEdgeColor','k','MarkerSize',7, ...
        'HandleVisibility','off');
    pos=interp1(linspace(0,flightDuration(i),size(tr,1)),tr, ...
        min(snapshotTime,flightDuration(i)));
    uavHandles(i)=plot3(ax,pos(1),pos(2),pos(3),'o', ...
        'MarkerFaceColor',c,'MarkerEdgeColor','k','MarkerSize',9, ...
        'HandleVisibility','off');
end
[sx,sy,sz]=sphere(20);
sphereHandles=gobjects(3,1);
for j=1:3
    ob=obstacles(j);
    plot3(ax,[ob.p0(1) ob.p1(1)],[ob.p0(2) ob.p1(2)], ...
        [ob.p0(3) ob.p1(3)],'--','Color',[0.52 0.28 0.11], ...
        'LineWidth',1.3,'HandleVisibility','off');
    p=urban_preview_sphere_position(ob,snapshotTime);
    r=ob.radius_m;
    sphereHandles(j)=surf(ax,p(1)+r*sx,p(2)+r*sy,p(3)+r*sz, ...
        'FaceColor',[1.00 0.72 0.30], ...
        'EdgeColor',[0.48 0.20 0.08], ...
        'FaceAlpha',0.90,'EdgeAlpha',0.7, ...
        'LineWidth',0.5,'HandleVisibility','off');
end
xlabel(ax,'X (m)');
ylabel(ax,'Y (m)');
zlabel(ax,'Altitude (m)');
xlim(ax,urbanBounds(1,:));
ylim(ax,urbanBounds(2,:));
zlim(ax,urbanBounds(3,:));
daspect(ax,[1 1 1]);
axis(ax,'vis3d');
view(ax,40,26);
set(ax,'Projection','orthographic','FontSize',11);
grid(ax,'off'); box(ax,'on');

outputDir=fullfile(mapRoot,'results_urban_map_preview');
if ~isfolder(outputDir), mkdir(outputDir); end
scene=struct('bounds',urbanBounds,'blocks',blocks,'starts',starts, ...
    'goals',goals,'displayPaths',{paths},'flightDuration',flightDuration, ...
    'obstacles',obstacles,'seed',urbanSeed,'routeColors',routeColors, ...
    'isPlannerOutput',false);
save(fullfile(outputDir,'urban_preview_scene.mat'),'scene');
try
    exportgraphics(fig,fullfile(outputDir,'urban_map_preview.png'),'Resolution',180);
catch
    saveas(fig,fullfile(outputDir,'urban_map_preview.png'));
end
fprintf('\nURBAN MAP PREVIEW: %d buildings, 5 display paths, 3 moving spheres.\n', ...
    size(blocks,1));
fprintf('Preview saved: %s\n',outputDir);
fprintf('NOTE: these visual paths are NOT RRT* output or safety verified.\n');

if urbanAnimate
    fprintf('Animating independent visual preview...\n');
    tFinal=max([flightDuration, [obstacles.t1]]);
    for t=0:0.5:tFinal
        if ~isgraphics(fig), break; end
        for i=1:N
            tr=paths{i};
            p=interp1(linspace(0,flightDuration(i),size(tr,1)),tr, ...
                min(t,flightDuration(i)));
            if isgraphics(uavHandles(i))
                set(uavHandles(i),'XData',p(1),'YData',p(2),'ZData',p(3));
            end
        end
        for j=1:3
            p=urban_preview_sphere_position(obstacles(j),t);
            r=obstacles(j).radius_m;
            if isgraphics(sphereHandles(j))
                set(sphereHandles(j),'XData',p(1)+r*sx, ...
                    'YData',p(2)+r*sy,'ZData',p(3)+r*sz);
            end
        end
        set(fig,'Name',sprintf('Urban Preview | t = %.1f s',t));
        drawnow limitrate;
    end
end

function pos=urban_preview_sphere_position(ob,t)
if t <= ob.t0
    pos=ob.p0;
elseif t >= ob.t1
    pos=ob.p1;
else
    alpha=(t-ob.t0)/(ob.t1-ob.t0);
    pos=(1-alpha)*ob.p0+alpha*ob.p1;
end
end
