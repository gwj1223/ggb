%RUN_V21_INDEPENDENT_HOLDOUT Fixed, independent, legacy-APF 3-objective test.
% Run from any working directory: run('run_v21_independent_holdout.m')
root = fileparts(mfilename('fullpath'));
assert(isfile(fullfile(root,'src','mmra_rrtstar.m')), ...
    'Could not resolve v2.1 project root.');
addpath(fullfile(root,'src'));
addpath(fullfile(root,'tests'));
addpath(fullfile(root,'examples'));
fprintf('=== MMRA v2.1 FROZEN independent holdout ===\n');
run(fullfile(root,'run_tests.m'));
mmra_rrt_threeobjective_tests();
mmra_v21_holdout_statistics_tests();
mmra_v21_holdout_driver(root);
fprintf('=== Independent holdout finished. See results_v21_independent_holdout/ ===\n');
