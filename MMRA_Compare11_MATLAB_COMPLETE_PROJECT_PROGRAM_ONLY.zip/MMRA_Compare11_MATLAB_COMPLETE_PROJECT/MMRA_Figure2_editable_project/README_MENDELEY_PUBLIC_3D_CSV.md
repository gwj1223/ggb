# 公开 Mendeley 三维 10-UAV CSV — MMRA MATLAB 回放评测包

## 先看结论

- 使用你上传的 `Data.rar`：取其中 **6 份 MATLAB 十机仿真 CSV**，未修改轨迹数值或原始时间戳。每份 10 架 UAV；共 60 个 **单机作为 ego、其余九机轨迹固定**的回放任务。不是 60 个完全独立的十机联合规划任务。
- 原日志总共 6/270 对 UAV 在分段线性插值下出现 `<10 m` 的接近事件，涉及 **9/60** 个 ego 回放任务。
- 独立 Python 预检：用统一 120 m/s 匀速直线从 CSV 实测起点飞到最终位置、提前到达后停留，**60/60** 已经满足所选 10 m 安全间距。因此原始“全程起终点”方案过于简单，不足以检验主动空间绕行效果。
- 额外提供 **9 例公开轨迹衍生 `incident2` 快照任务**：在每个发生参考冲突的 ego 案例的最近相遇时刻前 2 秒重新设置起点，其他九机的真实日志后续轨迹和时间差保持不变。独立预检该方案有 **3/9 例匀速直飞不满足 10 m 间距**，但均能在该离线时序搜索的候选速度/2s 延迟范围内找到安全直线调度。因此这组也是测试时间避碰的“演示样本”，不是空间绕行压力基准；不是 Mendeley 官方样本划分。

## 文件结构 / 安装

需要你之前已经使用的完整 `MMRA_Figure2_editable_project` 工程，包含：

```
MMRA_Figure2_editable_project/
  src/mmra_bezier.m
  src/mmra_prune.m
  Urban500_V3_HighRise_Download/Urban_Complex_500m_V3_HighRise/
    urban500_rrtstar_plan.m
    urban500_mmra_postprocess.m
  MMRA_AbilityBenchmark_V1/
    benchmark_minsep_continuous.m
    mendeley_public_plan.m                 <-- 新增
    mendeley_public_load_cases.m           <-- 新增
    mendeley_public_load_incidents.m       <-- 新增
    mendeley_public_evaluate.m             <-- 新增
    mendeley_public_minsep.m               <-- 新增
    mendeley_public_position.m             <-- 新增
    run_mendeley_public_benchmark.m        <-- 新增
    run_mendeley_public_smoketest.m        <-- 新增
    mendeley_public_plot_case.m            <-- 新增
    compare_mendeley_public_runs.m         <-- 新增
    Mendeley_Public_3D_CSV/
      RRTConnect_Baseline.csv
      RRTConnect_Improved.csv
      D3QN_Baseline.csv
      D3QN_Improved.csv
      SACDQN_Baseline.csv
      SACDQN_Improved.csv
      PUBLIC_SOURCE_MANIFEST.csv
      Mendeley_Public3D_reference_manifest.csv
      Mendeley_Public3D_270_pairs.csv
      Mendeley_Public3D_INCIDENT2_manifest.csv
      verify_mendeley_public_csv.py
```

**快速安装：** 把本 ZIP 中的 `MMRA_AbilityBenchmark_V1` 目录复制合并到已有完整工程根目录，保留已有 MATLAB 文件。不要把 `.m` 文件移动到别处。完整版 ZIP 可直接解压到一个新目录。

## 最少操作（MATLAB）

在 MATLAB 将当前文件夹设置为：`MMRA_Figure2_editable_project/MMRA_AbilityBenchmark_V1`，运行：

```matlab
run_mendeley_public_smoketest

% 先使用原始 CSV 全程场景：60 个 ego-centric 回放
run_mendeley_public_benchmark('straight',60);
run_mendeley_public_benchmark('temporal',60);
run_mendeley_public_benchmark('proxy',60);
compare_mendeley_public_runs('full');

% 再使用从公共相遇记录中截出的 9 个事件快照
run_mendeley_public_benchmark('straight',9,'incident2');
run_mendeley_public_benchmark('temporal',9,'incident2');
run_mendeley_public_benchmark('proxy',9,'incident2');
compare_mendeley_public_runs('incident2');

% 画出原始轨迹 / MMRA 轨迹 / 最近间距；选一个有直线冲突的快照
mendeley_public_plot_case('MEN_RRT_B_U04_SNAP2','temporal','incident2');
```

输出目录：`MMRA_AbilityBenchmark_V1/benchmark_results/Mendeley_Public3D/`。

首次仅尝试两个真实 RRT* / MMRA 案例：

```matlab
run_mendeley_public_benchmark('temporal',2)
```

再决定是否跑全量。

## 冻结的外部回放评测协议（非 Mendeley 官方协议）

| 字段 | 约束 |
|---|---|
| 坐标/时间 | 原 CSV `Time, Pos_X, Pos_Y, Pos_Z`；单位按数据原描述使用 s、m |
| 障碍物/其他 UAV | 其他 9 架原 CSV 记录的三维轨迹；时间戳完全保留；线性插值，末端悬停 |
| 规划对象 | 仅一个 ego 无人机，其余 9 架绝不重新规划 |
| 起点/目标 | CSV 对应 ego 首末行的三维位置；incident2 从原时间 `tmin-2s` 重新起算 |
| 时间上限 | 各原始 CSV 的实际最后时间，或该时刻减去快照偏移 |
| 空间边界 | 根据该 CSV 的所有实测坐标外扩 x/y 100m；z 上界至少 300m |
| 速度上限 | 120m/s（研究协议假设，**不是** Mendeley 官方的无人机物理速度上限） |
| 机间点间距 | 10m（研究协议假设，**不是**原数据集碰撞标签） |
| 起飞等待 | 最多 2s（仅时间调度和 proxy），可选匀速 `[120,105,90,75,60,45]` m/s |
| 在线性 | **离线、提前知道所有未来轨迹**；不是机载实时在线避障 |
| 验证器 | 输出路径时间/起终点/边界/限速/起飞等待 + 连续时间分段解析最小间距 |
| 未验证 | 加速度、jerk、执行跟踪误差、姿态、实际无人机动力学；转弯曲率不是全部输出的独立证明 |

## 算法方法名称务必准确

- **STRAIGHT**：匀速直线对照。不使用 MMRA。
- **GEOMETRY**：调用真实 `urban500_rrtstar_plan.m` + 共享 `mmra_prune/mmra_bezier`；外部场景没有静态城市建筑，所以通常等价于直线。
- **TEMPORAL**：上述真实 RRT*/共享 MMRA 几何路线，加速度候选速度和不超过 2s 的离线时间调度。不是原独立主函数 `mmra_plan_single.m`。
- **PROXY**：当时间调度无法通过安全验证时，提取原始动态交通航迹的最近时空冲突，构造临时静态 AABB；再调用真实 Urban500 RRT* + 共享 MMRA 平滑生成空间候选，最后针对**真实的全部 9 架移动源轨迹**重新做连续时间验证。这是**新加的实验性代理空间启发式**，不能称为未经修改的原版 MMRA 或真正在线 RRT*。
- 对于代理绕行，若 MMRA 后处理报告存在未圆滑的合格拐角，严格拒绝该代理路线；但是仍不能证明 jerk/姿态/推力合规。

## 公开数据说明与论文引用

来源：Mamunur Rahman, *MATLAB and Parrot Anafi data*, Mendeley Data, V1, DOI: `10.17632/gjjgpfdx22.1`，许可 CC BY 4.0。
https://data.mendeley.com/datasets/gjjgpfdx22/1

**不要**把各来源里既有的 D3QN、RRT-Connect 和 SAC-DQN 轨迹直接当作对等算法实验基准排名；这些是不同日志的已有输出，发布方没有提供我们此处的统一规划任务规范。当前比较的是所有输入任务下自己重新运行的三种方式。

外部回放只能支撑“在公开轨迹驱动的 **1-vs-9** 离线三维时空安全回放实验中……”一类论述。不能支撑“动态障碍物空间主动绕障优于公开 SoTA”、“完成十机联合重新规划”、“在线避障可靠”或“可飞行动态约束完全满足”。

## 验证状态

- 已通过独立 Python 数值审核：原始 6 份文件 SHA256、每 10 架时钟单调递增、270 对连续时间最近距离、60 个原始 ego 场景，以及 9 个快照场景。
- MATLAB 代码只做了静态接口和数据结构检查，**本环境没有 MATLAB/Octave，因此并未声称已实际执行或成功得到算法跑分**。
- 运行过程若显示 `PLANNER_ERROR` 说明未找到通过验证的路径，**不算成功**。保留完整输出 CSV，供后续诊断。
