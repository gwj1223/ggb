function run_main_map_editor()
%RUN_MAIN_MAP_EDITOR Edit saved terrain, 3 NFZs AND 3 moving obstacles.
% The original terrain and NFZ settings are stored in SEPARATE MAT files.
% Switch the top-left mode selector to change the visible editor controls.
% Both modes preview in Figure 2 without creating a second map figure.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
[env,~,~]=mmra_defaults('mountain_cluster_figure2_custom_5km');
[baseEnv,~,~]=mmra_defaults('mountain_cluster_figure2_v28_5km');
[starts,goals]=mmra_5km_mission(baseEnv,20,24001,'cross_center');
terrainSettingsFile=fullfile(root,'results_main_map','Figure2_user_settings.mat');
nfzSettingsFile=fullfile(root,'results_main_map', ...
    'Figure2_static_obstacles_settings.mat');
dynamicSettingsFile=fullfile(root,'results_main_map', ...
    'Figure2_dynamic_obstacles_settings.mat');
% Display-only preference; separate from the terrain/NFZ/obstacle data.
showUavPoints=mmra_figure2_uav_display_settings();
staticEnv=mmra_figure2_add_static_obstacles(env);
nfz=staticEnv.noFlyCylinders;
try
    dyn=mmra_figure2_dynamic_obstacles(staticEnv);
catch ME
    warning('Saved moving-obstacle settings need attention: %s',ME.message);
    dyn=mmra_figure2_dynamic_defaults();
end
selectedDynamic=1;
previewTime_s=120;
playStop=false;
dynHandles=[];
terrainDirty=false;
selectedPeak=1;
selectedNFZ=1;

fig=figure(2);clf(fig);
set(fig,'Units','pixels','Position',[60 60 1500 850], ...
    'Color','w','Name','Figure 2 terrain and no-fly editor', ...
    'NumberTitle','off','MenuBar','figure','ToolBar','figure');
terrainPanel=uipanel('Parent',fig,'Units','normalized', ...
    'Position',[.008 .015 .235 .915], ...
    'Title','Figure 2: terrain controls','FontSize',11);
nfzPanel=uipanel('Parent',fig,'Units','normalized', ...
    'Position',[.008 .015 .235 .915], ...
    'Title','Figure 2: no-fly cylinders','FontSize',11, ...
    'Visible','off');
dynamicPanel=uipanel('Parent',fig,'Units','normalized', ...
    'Position',[.008 .015 .235 .915], ...
    'Title','Figure 2: moving obstacles','FontSize',11, ...
    'Visible','off');
% Explicit, independent graphics container. Prevents UI panel redraws from
% blanking the 3-D axes on some desktop MATLAB graphics configurations.
plotPanel=uipanel('Parent',fig,'Units','normalized', ...
    'Position',[.247 .015 .745 .92], ...
    'BorderType','none','BackgroundColor','w','Visible','on');
modeSelect=uicontrol('Parent',fig,'Style','popupmenu', ...
    'Units','normalized','Position',[.014 .945 .222 .04], ...
    'String',{'EDIT TERRAIN','EDIT NO-FLY ZONES','EDIT MOVING OBSTACLES'}, ...
    'Value',1,'FontWeight','bold','Callback',@switchMode);
% Switches the green starts, orange goals, and assignment dotted lines.
% Immediate persistence is limited to a display-only settings file.
uavPointsCheckbox=uicontrol('Parent',fig,'Style','checkbox', ...
    'Units','normalized','Position',[.310 .947 .230 .035], ...
    'String','SHOW UAV POINTS','Value',double(showUavPoints), ...
    'BackgroundColor','w','FontWeight','bold', ...
    'Callback',@toggleUavPoints);
% Keep refresh outside the editor panels so a blank canvas is recoverable.
uicontrol('Parent',fig,'Style','pushbutton', ...
    'Units','normalized','Position',[.862 .945 .125 .038], ...
    'String','REFRESH 3-D VIEW','Callback',@forceRefreshPlot);
% Preview-only automatic size/height adjustment; SAVE DYNAMIC persists.
dynamicAutoButton=uicontrol('Parent',fig,'Style','pushbutton', ...
    'Units','normalized','Position',[.705 .945 .15 .038], ...
    'String','LOWER + GROW ALL','Visible','off', ...
    'Callback',@autoTuneDynamic);
ax=axes('Parent',plotPanel,'Units','normalized', ...
    'Position',[.075 .13 .78 .78],'Visible','on');
x=linspace(0,5000,161);[X,Y]=meshgrid(x,x);
Z=reshape(mmra_terrain([X(:) Y(:)],env),size(X));
surfHandle=surf(ax,X/1000,Y/1000,Z/1000, ...
    'EdgeColor','none','FaceAlpha',.94);
hold(ax,'on');shading(ax,'interp');colormap(ax,parula(128));
cb=colorbar(ax);ylabel(cb,'Terrain elevation (km)');
hs=scatter3(ax,starts(:,1)/1000,starts(:,2)/1000, ...
    starts(:,3)/1000,32,[.12 .65 .28],'filled');
hg=scatter3(ax,goals(:,1)/1000,goals(:,2)/1000, ...
    goals(:,3)/1000,32,[.95 .35 .12],'filled');
lineHandles=cell(size(starts,1),1);
for i=1:size(starts,1)
    lineHandles{i}=plot3(ax,[starts(i,1),goals(i,1)]/1000, ...
        [starts(i,2),goals(i,2)]/1000, ...
        [starts(i,3),goals(i,3)]/1000,':', ...
        'Color',[.48 .48 .48],'LineWidth',.5, ...
        'HandleVisibility','off');
end
xlabel(ax,'X (km)');ylabel(ax,'Y (km)');zlabel(ax,'Altitude (km)');
title(ax,'Multi-peak complex terrain | 5 x 5 x 2 km');
% Legend and marker visibility are synchronized with the checkbox.
updateUavPointsLayer();
xlim(ax,[0 5]);ylim(ax,[0 5]);zlim(ax,[0 2]);
daspect(ax,[1 1 .55]);view(ax,42,29);grid(ax,'off');
% Hide tick marks, NOT numerical tick labels.
set(ax,'TickLength',[0 0]);

% Three red NFZ cylinders, no gray building overlays. They appear
% in NFZ/moving editing mode; terrain editing remains uncluttered.
theta=linspace(0,2*pi,73);
cylSide=cell(3,1);cylRim=cell(3,1);
for k=1:3
    cylSide{k}=surf(ax,nan(2,numel(theta)),nan(2,numel(theta)), ...
        nan(2,numel(theta)),'FaceColor',[.89 .16 .20], ...
        'FaceAlpha',.17,'EdgeColor','none', ...
        'HandleVisibility','off','Visible','off');
    cylRim{k}=plot3(ax,nan(1,numel(theta)),nan(1,numel(theta)), ...
        nan(1,numel(theta)),'Color',[.70 .13 .16], ...
        'LineWidth',.9,'HandleVisibility','off','Visible','off');
end
% Gray building patches have been removed. Keep the empty handle list
% because switchMode already iterates over it when toggling layers.
boxHandle=cell(0,1);

% -------------------- Existing terrain controls --------------------
uicontrol('Parent',terrainPanel,'Style','text','Units','normalized', ...
    'Position',[.06 .93 .88 .045], ...
    'String','Choose a summit / hill / ridge settings:', ...
    'HorizontalAlignment','left');
numPeaks=size(env.peaks,1);
strings=cell(numPeaks,1);
for k=1:numPeaks
    strings{k}=sprintf('Peak %02d - (%.0f, %.0f) m', ...
        k,baseEnv.peaks(k,2),baseEnv.peaks(k,3));
end
selector=uicontrol('Parent',terrainPanel,'Style','popupmenu', ...
    'Units','normalized','Position',[.055 .885 .89 .045], ...
    'String',strings,'Value',1,'Callback',@selectPeak);
labels={'Peak height contribution (m)','Peak X position (m)', ...
    'Peak Y position (m)','Peak width X (m)','Peak width Y (m)', ...
    'Ridge height multiplier','Valley erosion multiplier', ...
    'Small-relief multiplier','Base elevation (m)'};
keys={'height','x','y','wx','wy','ridge','valley','wave','base'};
ranges=[0 1350;100 4900;100 4900;100 1000;100 1000; ...
    0 2.5;0 1.7;0 2.5;10 250];
slider=struct();valueText=struct();
for k=1:numel(keys)
    y0=.835-(k-1)*.078;
    uicontrol('Parent',terrainPanel,'Style','text','Units','normalized', ...
        'Position',[.06 y0 .78 .026],'String',labels{k}, ...
        'HorizontalAlignment','left');
    valueText.(keys{k})=uicontrol('Parent',terrainPanel,'Style','text', ...
        'Units','normalized','Position',[.80 y0 .15 .026], ...
        'String','0','HorizontalAlignment','right');
    slider.(keys{k})=uicontrol('Parent',terrainPanel,'Style','slider', ...
        'Units','normalized','Position',[.07 y0-.04 .86 .036], ...
        'Min',ranges(k,1),'Max',ranges(k,2), ...
        'Value',ranges(k,1),'Callback',@sliderChanged, ...
        'Tag',keys{k});
end
terrainStatus=uicontrol('Parent',terrainPanel,'Style','text', ...
    'Units','normalized','Position',[.055 .080 .90 .061], ...
    'String','Ready','HorizontalAlignment','left', ...
    'ForegroundColor',[.1 .35 .18]);
uicontrol('Parent',terrainPanel,'Style','pushbutton', ...
    'Units','normalized','Position',[.04 .025 .44 .048], ...
    'String','SAVE MAP','FontWeight','bold','Callback',@saveMap);
uicontrol('Parent',terrainPanel,'Style','pushbutton', ...
    'Units','normalized','Position',[.52 .025 .44 .048], ...
    'String','RESET TERRAIN','Callback',@resetMap);

% --------------------- New NFZ controls ---------------------------
uicontrol('Parent',nfzPanel,'Style','text','Units','normalized', ...
    'Position',[.055 .92 .90 .046], ...
    'String','Choose one of the 3 restricted cylinders:', ...
    'HorizontalAlignment','left');
nfzSelector=uicontrol('Parent',nfzPanel,'Style','popupmenu', ...
    'Units','normalized','Position',[.055 .865 .89 .052], ...
    'String',{'No-fly cylinder 1','No-fly cylinder 2', ...
              'No-fly cylinder 3'},'Value',1,'Callback',@selectNFZ);
nfzKeys={'x','y','radius','bottom','top'};
nfzLabels={'Center X (m)','Center Y (m)', ...
    'Cylinder radius (m)','Bottom altitude (m)','Top altitude (m)'};
nfzRanges=[0 5000;0 5000;50 650;0 1800;200 2000];
nfzSliders=struct();nfzValueTexts=struct();
for k=1:numel(nfzKeys)
    y0=.79-(k-1)*.125;
    uicontrol('Parent',nfzPanel,'Style','text','Units','normalized', ...
        'Position',[.065 y0 .67 .04], ...
        'String',nfzLabels{k},'HorizontalAlignment','left');
    nfzValueTexts.(nfzKeys{k})=uicontrol('Parent',nfzPanel, ...
        'Style','text','Units','normalized', ...
        'Position',[.74 y0 .19 .04], ...
        'String','0','HorizontalAlignment','right');
    nfzSliders.(nfzKeys{k})=uicontrol('Parent',nfzPanel, ...
        'Style','slider','Units','normalized', ...
        'Position',[.075 y0-.049 .85 .04], ...
        'Min',nfzRanges(k,1),'Max',nfzRanges(k,2), ...
        'Value',nfzRanges(k,1),'Tag',nfzKeys{k}, ...
        'Callback',@nfzSliderChanged);
end
uicontrol('Parent',nfzPanel,'Style','text','Units','normalized', ...
    'Position',[.055 .145 .90 .06], ...
    'String','Hard buffer: 35 m. Red = NFZ; gray buildings removed.', ...
    'HorizontalAlignment','left');
nfzStatus=uicontrol('Parent',nfzPanel,'Style','text', ...
    'Units','normalized','Position',[.055 .075 .90 .071], ...
    'String','Select a cylinder to edit.','HorizontalAlignment','left', ...
    'ForegroundColor',[.1 .35 .18]);
uicontrol('Parent',nfzPanel,'Style','pushbutton', ...
    'Units','normalized','Position',[.04 .025 .44 .048], ...
    'String','SAVE NFZ','FontWeight','bold','Callback',@saveNFZ);
uicontrol('Parent',nfzPanel,'Style','pushbutton', ...
    'Units','normalized','Position',[.52 .025 .44 .048], ...
    'String','RESET NFZ','Callback',@resetNFZ);

% ------------------ Moving sphere controls (NEW) -------------------
uicontrol('Parent',dynamicPanel,'Style','text','Units','normalized', ...
    'Position',[.045 .93 .91 .043], ...
    'String','Edit moving sphere (linearly between two XYZ points):', ...
    'HorizontalAlignment','left');
dynamicSelector=uicontrol('Parent',dynamicPanel,'Style','popupmenu', ...
    'Units','normalized','Position',[.05 .877 .90 .05], ...
    'String',{'Moving sphere 1','Moving sphere 2','Moving sphere 3'}, ...
    'Value',1,'Callback',@selectDynamic);
dynamicKeys={'x0','y0','z0','x1','y1','z1','radius','t0','t1'};
dynamicLabels={'Start X (m)','Start Y (m)','Start altitude (m)', ...
    'End X (m)','End Y (m)','End altitude (m)', ...
    'Sphere radius (m)','Move start time (s)','Move finish time (s)'};
dynamicRanges=[50 4950;50 4950;100 1950; ...
    50 4950;50 4950;100 1950;10 200;0 300;1 420];
dynamicSliders=struct();dynamicValues=struct();
for k=1:numel(dynamicKeys)
    y0=.839-(k-1)*.073;
    key=dynamicKeys{k};
    uicontrol('Parent',dynamicPanel,'Style','text','Units','normalized', ...
        'Position',[.055 y0 .73 .032], ...
        'String',dynamicLabels{k},'HorizontalAlignment','left');
    dynamicValues.(key)=uicontrol('Parent',dynamicPanel,'Style','text', ...
        'Units','normalized','Position',[.77 y0 .17 .032], ...
        'String','0','HorizontalAlignment','right');
    dynamicSliders.(key)=uicontrol('Parent',dynamicPanel,'Style','slider', ...
        'Units','normalized','Position',[.065 y0-.037 .86 .031], ...
        'Min',dynamicRanges(k,1),'Max',dynamicRanges(k,2), ...
        'Value',dynamicRanges(k,1),'Tag',key, ...
        'Callback',@dynamicSliderChanged);
end
dynamicTimeLabel=uicontrol('Parent',dynamicPanel,'Style','text', ...
    'Units','normalized','Position',[.05 .188 .90 .035], ...
    'String','Preview time: 120 s','HorizontalAlignment','left');
dynamicTimeSlider=uicontrol('Parent',dynamicPanel,'Style','slider', ...
    'Units','normalized','Position',[.065 .158 .86 .030], ...
    'Min',0,'Max',420,'Value',previewTime_s, ...
    'Callback',@dynamicTimeChanged);
uicontrol('Parent',dynamicPanel,'Style','pushbutton', ...
    'Units','normalized','Position',[.055 .116 .42 .036], ...
    'String','PLAY','Callback',@playDynamic);
uicontrol('Parent',dynamicPanel,'Style','pushbutton', ...
    'Units','normalized','Position',[.525 .116 .42 .036], ...
    'String','STOP','Callback',@stopDynamic);
dynamicStatus=uicontrol('Parent',dynamicPanel,'Style','text', ...
    'Units','normalized','Position',[.045 .066 .92 .045], ...
    'String','Preview only until saved.', 'HorizontalAlignment','left', ...
    'ForegroundColor',[.1 .35 .18]);
uicontrol('Parent',dynamicPanel,'Style','pushbutton', ...
    'Units','normalized','Position',[.04 .018 .44 .045], ...
    'String','SAVE DYNAMIC','FontWeight','bold', ...
    'Callback',@saveDynamic);
uicontrol('Parent',dynamicPanel,'Style','pushbutton', ...
    'Units','normalized','Position',[.52 .018 .44 .045], ...
    'String','RESET DYNAMIC','Callback',@resetDynamic);

syncDynamicSliders();
syncSliders();syncNFZSliders();previewTerrain();
forceRefreshPlot([],[]);

    function toggleUavPoints(src,~)
        candidate=logical(get(src,'Value'));
        try
            % No modification to cached missions or obstacle parameters.
            mmra_figure2_uav_display_settings(candidate);
            showUavPoints=candidate;
            updateUavPointsLayer();
            drawnow;
        catch ME
            set(src,'Value',double(showUavPoints));
            errordlg(ME.message,'Unable to save display preference');
        end
    end

    function updateUavPointsLayer()
        if showUavPoints
            state='on';
        else
            state='off';
        end
        set(hs,'Visible',state);
        set(hg,'Visible',state);
        for u=1:numel(lineHandles)
            if ishandle(lineHandles{u})
                set(lineHandles{u},'Visible',state);
            end
        end
        if showUavPoints
            legend(ax,[surfHandle hs hg],{'Terrain','Starts','Goals'}, ...
                'Location','northeast');
        else
            legend(ax,surfHandle,{'Terrain'},'Location','northeast');
        end
    end

    function switchMode(~,~)
        playStop=true;
        value=get(modeSelect,'Value');
        set(terrainPanel,'Visible','off');
        set(nfzPanel,'Visible','off');
        set(dynamicPanel,'Visible','off');
        set(dynamicAutoButton,'Visible','off');
        if value==2
            set(nfzPanel,'Visible','on');
            setOverlaysVisible('on');
            setDynamicVisible('off');
            previewNFZ();
        elseif value==3
            set(dynamicPanel,'Visible','on');
            set(dynamicAutoButton,'Visible','on');
            setOverlaysVisible('on');
            previewNFZ();
            previewDynamic();
        else
            set(terrainPanel,'Visible','on');
            setOverlaysVisible('off');
            setDynamicVisible('off');
            previewTerrain();
        end
        forceRefreshPlot([],[]);
    end

    function forceRefreshPlot(~,~)
        % All scene geometry is retained; this only restores drawing state.
        if ~ishandle(fig) || ~ishandle(plotPanel) || ~ishandle(ax)
            warning('MMRA:EditorPlotMissing', ...
                'Plot axes were deleted. Close the editor and reopen it.');
            return;
        end
        set(plotPanel,'Visible','on');
        set(ax,'Visible','on','XLim',[0 5], ...
            'YLim',[0 5],'ZLim',[0 2], ...
            'TickLength',[0 0]);
        if ishandle(surfHandle)
            set(surfHandle,'Visible','on');
        end
        % Move the dedicated plot panel above any accidental white layer.
        % It is entirely to the right of the controls, so this is safe.
        try
            uistack(plotPanel,'top');
        catch
            % uistack behavior differs among MATLAB desktop versions.
        end
        drawnow;
        if isempty(findall(ax,'Type','surface'))
            warning('MMRA:EditorNoSurface', ...
                'No terrain surface in editor plot; run run_check_editor_display.');
        end
    end

    function setDynamicVisible(state)
        if isempty(dynHandles),return;end
        f={'sphere','trail','start','finish','center','tag'};
        for a=1:numel(f)
            for j=1:numel(dynHandles.(f{a}))
                h=dynHandles.(f{a}){j};
                if ishandle(h),set(h,'Visible',state);end
            end
        end
    end

    function setOverlaysVisible(state)
        for j=1:3
            set(cylSide{j},'Visible',state);
            set(cylRim{j},'Visible',state);
        end
        for j=1:numel(boxHandle)
            set(boxHandle{j},'Visible',state);
        end
    end

    function selectPeak(~,~)
        selectedPeak=get(selector,'Value');
        syncSliders();
    end

    function syncSliders()
        pk=env.peaks(selectedPeak,:);
        fill={'height','x','y','wx','wy'};
        for j=1:5,set(slider.(fill{j}),'Value',pk(j));end
        set(slider.ridge,'Value',env.terrainRidges(1,1) ...
            /baseEnv.terrainRidges(1,1));
        set(slider.valley,'Value',env.terrainErosionGullies(1,1) ...
            /baseEnv.terrainErosionGullies(1,1));
        set(slider.wave,'Value',env.terrainMicroWaves(1,1) ...
            /baseEnv.terrainMicroWaves(1,1));
        set(slider.base,'Value',env.baseHeight);
        updateNumbers();
    end

    function updateNumbers()
        for j=1:numel(keys)
            key=keys{j};val=get(slider.(key),'Value');
            if any(strcmp(key,{'ridge','valley','wave'}))
                set(valueText.(key),'String',sprintf('%.2fx',val));
            else
                set(valueText.(key),'String',sprintf('%.0f',val));
            end
        end
    end

    function sliderChanged(src,~)
        key=get(src,'Tag');v=get(src,'Value');
        switch key
            case 'height',env.peaks(selectedPeak,1)=v;
            case 'x',env.peaks(selectedPeak,2)=v;
            case 'y',env.peaks(selectedPeak,3)=v;
            case 'wx',env.peaks(selectedPeak,4)=v;
            case 'wy',env.peaks(selectedPeak,5)=v;
            case 'ridge'
                env.terrainRidges(:,1)=baseEnv.terrainRidges(:,1)*v;
            case 'valley'
                env.terrainErosionGullies(:,1)= ...
                    min(.93,baseEnv.terrainErosionGullies(:,1)*v);
            case 'wave'
                env.terrainMicroWaves(:,1)=baseEnv.terrainMicroWaves(:,1)*v;
            case 'base',env.baseHeight=v;
        end
        terrainDirty=true;
        updateNumbers();
        previewTerrain();
    end

    function previewTerrain()
        z=reshape(mmra_terrain([X(:) Y(:)],env),size(X));
        set(surfHandle,'ZData',z/1000,'CData',z/1000);
        lo=min(z(:));hi=max(z(:));
        if hi+env.safetyMargin>=2000
            set(terrainStatus,'ForegroundColor',[.75 .1 .05], ...
                'String',sprintf('TOO HIGH: peak %.0f m (+50 m > 2 km).',hi));
        elseif lo<0
            set(terrainStatus,'ForegroundColor',[.75 .1 .05], ...
                'String','NEGATIVE terrain height: adjust parameters.');
        else
            try
                [pStarts,pGoals]=mmra_5km_mission(env,20,24001,'cross_center');
                set(hs,'ZData',pStarts(:,3)/1000);
                set(hg,'ZData',pGoals(:,3)/1000);
                for j=1:numel(lineHandles)
                    set(lineHandles{j},'ZData', ...
                        [pStarts(j,3),pGoals(j,3)]/1000);
                end
                set(terrainStatus,'ForegroundColor',[.1 .35 .18], ...
                    'String',sprintf('Preview: %.0f-%.0f m. SAVE MAP to persist.', ...
                        lo,hi));
            catch ME
                set(terrainStatus,'ForegroundColor',[.75 .1 .05], ...
                    'String',sprintf('MISSION INVALID: %s',ME.message));
            end
        end
        drawnow limitrate;
    end

    function saveMap(~,~)
        try
            stats=mmra_figure2_user_validate(env,true);
            terrainParams=struct( ...
                'peaks',env.peaks, ...
                'terrainRidges',env.terrainRidges, ...
                'terrainErosionGullies',env.terrainErosionGullies, ...
                'terrainMicroWaves',env.terrainMicroWaves, ...
                'baseHeight',env.baseHeight, ...
                'revision',datestr(now,'yyyymmdd_HHMMSSFFF'));
            folder=fileparts(terrainSettingsFile);
            if ~exist(folder,'dir'),mkdir(folder);end
            save(terrainSettingsFile,'terrainParams','-v7');
            terrainDirty=false;
            set(terrainStatus,'ForegroundColor',[.1 .35 .18], ...
                'String',sprintf('SAVED terrain! Peak %.0f m.', ...
                    stats.maxHeight_m));
            fprintf('Custom Figure 2 terrain saved: %s\n',terrainSettingsFile);
        catch ME
            set(terrainStatus,'ForegroundColor',[.75 .1 .05], ...
                'String',sprintf('NOT SAVED: %s',ME.message));
            errordlg(ME.message,'Invalid terrain or mission');
        end
    end

    function resetMap(~,~)
        env=baseEnv;
        env.profile='mountain_cluster_figure2_custom_5km';
        terrainDirty=true;
        set(selector,'Value',1);selectedPeak=1;
        syncSliders();previewTerrain();
        set(terrainStatus,'String', ...
            'Original terrain in preview. SAVE MAP if wanted.');
    end

    function selectNFZ(~,~)
        selectedNFZ=get(nfzSelector,'Value');
        syncNFZSliders();
        previewNFZ();
    end

    function syncNFZSliders()
        c=nfz(selectedNFZ,:);
        values=[c(1) c(2) c(3) c(4) c(5)];
        for j=1:numel(nfzKeys)
            key=nfzKeys{j};
            set(nfzSliders.(key),'Value',values(j));
            set(nfzValueTexts.(key),'String',sprintf('%.0f',values(j)));
        end
    end

    function nfzSliderChanged(src,~)
        key=get(src,'Tag');v=get(src,'Value');
        j=find(strcmp(nfzKeys,key),1);
        % Store actual slider values, while displaying rounded metres.
        nfz(selectedNFZ,j)=v;
        set(nfzValueTexts.(key),'String',sprintf('%.0f',v));
        previewNFZ();
    end

    function previewNFZ()
        for j=1:3
            c=nfz(j,:);
            ringX=(c(1)+c(3)*cos(theta))/1000;
            ringY=(c(2)+c(3)*sin(theta))/1000;
            set(cylSide{j},'XData',[ringX;ringX], ...
                'YData',[ringY;ringY], ...
                'ZData',[c(4)*ones(1,numel(theta)); ...
                         c(5)*ones(1,numel(theta))]/1000);
            set(cylRim{j},'XData',ringX,'YData',ringY, ...
                'ZData',c(5)/1000*ones(1,numel(theta)));
        end
        try
            staticEnv=mmra_figure2_add_static_obstacles(env);
            staticEnv.noFlyCylinders=nfz;
            mmra_figure2_validate_nfz(staticEnv,true);
            if terrainDirty
                msg='Valid preview. SAVE MAP before SAVE NFZ.';
            else
                msg='NFZ valid. Press SAVE NFZ to persist all 3 cylinders.';
            end
            set(nfzStatus,'ForegroundColor',[.1 .35 .18], ...
                'String',msg);
        catch ME
            set(nfzStatus,'ForegroundColor',[.75 .1 .05], ...
                'String',sprintf('NOT SAVABLE: %s',ME.message));
        end
        drawnow limitrate;
    end

    function saveNFZ(~,~)
        try
            assert(~terrainDirty, ...
                'Save the edited terrain first using SAVE MAP.');
            % Validate against the terrain already persisted in the main
            % map settings, not an unsaved preview.
            [savedTerrain,~,~]=mmra_defaults( ...
                'mountain_cluster_figure2_custom_5km');
            checkedEnv=mmra_figure2_add_static_obstacles(savedTerrain);
            checkedEnv.noFlyCylinders=nfz;
            mmra_figure2_validate_nfz(checkedEnv,true);
            noFlyParams=struct('cylinders',nfz, ...
                'revision',datestr(now,'yyyymmdd_HHMMSSFFF'));
            folder=fileparts(nfzSettingsFile);
            if ~exist(folder,'dir'),mkdir(folder);end
            save(nfzSettingsFile,'noFlyParams','-v7');
            % Verify that subsequent display and RRT* calls see EXACTLY
            % the saved exclusion volumes.
            reloaded=mmra_figure2_add_static_obstacles(savedTerrain);
            assert(isequal(reloaded.noFlyCylinders,nfz), ...
                'Saved NFZ parameters failed the reload check.');
            set(nfzStatus,'ForegroundColor',[.1 .35 .18], ...
                'String','SAVED all 3 NFZs. Re-run static map and RRT*.');
            fprintf('Saved Figure 2 NFZ cylinders: %s\n',nfzSettingsFile);
            fprintf(['Run run_main_map_static_obstacles.m to draw them, then ' ...
                     'run_static_obstacle_figure2_5u.m to replan.\n']);
        catch ME
            set(nfzStatus,'ForegroundColor',[.75 .1 .05], ...
                'String',sprintf('NOT SAVED: %s',ME.message));
            errordlg(ME.message,'Invalid no-fly cylinder geometry');
        end
    end

    function resetNFZ(~,~)
        nfz=mmra_figure2_nfz_defaults();
        selectedNFZ=1;set(nfzSelector,'Value',1);
        syncNFZSliders();previewNFZ();
        set(nfzStatus,'String', ...
            'Original 3 NFZs in preview. SAVE NFZ if wanted.');
    end

    function selectDynamic(~,~)
        selectedDynamic=get(dynamicSelector,'Value');
        syncDynamicSliders();
        previewDynamic();
    end

    function syncDynamicSliders()
        ob=dyn(selectedDynamic);
        v=[ob.position_m(1,:) ob.position_m(2,:) ...
            ob.radius_m ob.time_s(1) ob.time_s(2)];
        for j=1:numel(dynamicKeys)
            key=dynamicKeys{j};
            set(dynamicSliders.(key),'Value',v(j));
            set(dynamicValues.(key),'String',sprintf('%.0f',v(j)));
        end
    end

    function dynamicSliderChanged(src,~)
        key=get(src,'Tag');v=get(src,'Value');
        i=selectedDynamic;
        switch key
            case 'x0',dyn(i).position_m(1,1)=v;
            case 'y0',dyn(i).position_m(1,2)=v;
            case 'z0',dyn(i).position_m(1,3)=v;
            case 'x1',dyn(i).position_m(2,1)=v;
            case 'y1',dyn(i).position_m(2,2)=v;
            case 'z1',dyn(i).position_m(2,3)=v;
            case 'radius',dyn(i).radius_m=v;
            case 't0',dyn(i).time_s(1)=v;
            case 't1',dyn(i).time_s(2)=v;
        end
        set(dynamicValues.(key),'String',sprintf('%.0f',v));
        previewDynamic();
    end

    function autoTuneDynamic(~,~)
        % Only propose edits. Save after reviewing the striped preview.
        try
            assert(~terrainDirty, ...
                'Save terrain edits first with SAVE MAP.');
            currentStatic=mmra_figure2_add_static_obstacles(env);
            currentStatic.noFlyCylinders=nfz;
            mmra_figure2_validate_dynamic_obstacles(dyn,currentStatic,true);
            [candidate,report]=mmra_figure2_tune_dynamic_obstacles( ...
                dyn,currentStatic);
            dyn=candidate;
            syncDynamicSliders();
            previewDynamic();
            if report.changedCount>0
                msg=sprintf('%d of 3 spheres adjusted. SAVE DYNAMIC.', ...
                    report.changedCount);
                set(dynamicStatus,'ForegroundColor',[.1 .35 .18], ...
                    'String',msg);
            else
                set(dynamicStatus,'ForegroundColor',[.75 .3 .05], ...
                    'String',['No safe lower+larger change with these ' ...
                    'XY paths. Shift a track toward a lower valley.']);
            end
            for j=1:numel(report.changed)
                fprintf(['Moving D%d: radius %.0f->%.0f m; ' ...
                    'height change -%.0f m; %s\n'],j, ...
                    report.oldRadius_m(j),report.newRadius_m(j), ...
                    report.drop_m(j),report.note{j});
            end
        catch ME
            set(dynamicStatus,'ForegroundColor',[.75 .1 .05], ...
                'String',sprintf('AUTO ADJUST ERROR: %s',ME.message));
        end
    end

    function dynamicTimeChanged(~,~)
        previewTime_s=get(dynamicTimeSlider,'Value');
        previewDynamic(false);
    end

    function previewDynamic(validateGeometry)
        if nargin<1,validateGeometry=true;end
        if get(modeSelect,'Value')~=3,return;end
        set(dynamicTimeLabel,'String', ...
            sprintf('Preview time: %.1f s (HOLD before/after)',previewTime_s));
        try
            dynHandles=mmra_figure2_plot_dynamic_overlay( ...
                ax,dyn,previewTime_s,dynHandles);
            setDynamicVisible('on');
            if validateGeometry
                currentStatic=mmra_figure2_add_static_obstacles(env);
                currentStatic.noFlyCylinders=nfz;
                mmra_figure2_validate_dynamic_obstacles( ...
                    dyn,currentStatic,true);
                if terrainDirty
                    msg='Preview valid. SAVE MAP before SAVE DYNAMIC.';
                else
                    msg='Preview valid. SAVE DYNAMIC persists all 3 tracks.';
                end
                set(dynamicStatus,'ForegroundColor',[.1 .35 .18], ...
                    'String',msg);
            end
        catch ME
            set(dynamicStatus,'ForegroundColor',[.75 .1 .05], ...
                'String',sprintf('NOT SAVABLE: %s',ME.message));
        end
        drawnow limitrate;
    end

    function playDynamic(~,~)
        playStop=false;
        fromTime=get(dynamicTimeSlider,'Value');
        for t=fromTime:3:420
            if ~ishandle(fig) || playStop || get(modeSelect,'Value')~=3
                break;
            end
            previewTime_s=t;
            set(dynamicTimeSlider,'Value',t);
            previewDynamic(false);
            drawnow;
            pause(.015);
        end
    end

    function stopDynamic(~,~)
        playStop=true;
    end

    function saveDynamic(~,~)
        try
            assert(~terrainDirty, ...
                'Save edited terrain first using SAVE MAP.');
            [savedTerrain,~,~]=mmra_defaults( ...
                'mountain_cluster_figure2_custom_5km');
            savedStatic=mmra_figure2_add_static_obstacles(savedTerrain);
            % Validate against currently saved NFZs. Unsaved red-cylinder
            % preview changes MUST NOT be silently used by scheduling.
            mmra_figure2_validate_dynamic_obstacles(dyn,savedStatic,true);
            clean=mmra_dynamic_obstacles_prepare(dyn);
            dynamicParams=struct('obstacles',clean, ...
                'revision',datestr(now,'yyyymmdd_HHMMSSFFF'));
            folder=fileparts(dynamicSettingsFile);
            if ~exist(folder,'dir'),mkdir(folder);end
            save(dynamicSettingsFile,'dynamicParams','-v7');
            [reloaded,~]=mmra_figure2_dynamic_obstacles(savedStatic);
            for j=1:numel(clean)
                assert(isequal(reloaded(j).position_m,clean(j).position_m) ...
                    && isequal(reloaded(j).time_s,clean(j).time_s) ...
                    && reloaded(j).radius_m==clean(j).radius_m, ...
                    'Failed to reload the saved moving sphere track.');
            end
            set(dynamicStatus,'ForegroundColor',[.1 .35 .18], ...
                'String','SAVED 3 moving spheres. Draw or animate Figure 2.');
            fprintf('Saved Figure 2 moving spheres: %s\n', ...
                dynamicSettingsFile);
            fprintf(['Run run_main_map_dynamic_obstacles.m to preview; ' ...
                'run_static_dynamic_figure2_5u.m to simulate.\n']);
        catch ME
            set(dynamicStatus,'ForegroundColor',[.75 .1 .05], ...
                'String',sprintf('NOT SAVED: %s',ME.message));
            errordlg(ME.message,'Invalid moving obstacle configuration');
        end
    end

    function resetDynamic(~,~)
        playStop=true;
        dyn=mmra_figure2_dynamic_defaults();
        selectedDynamic=1;set(dynamicSelector,'Value',1);
        previewTime_s=120;
        set(dynamicTimeSlider,'Value',previewTime_s);
        syncDynamicSliders();previewDynamic();
        set(dynamicStatus,'String', ...
            'Original 3 moving tracks in preview. SAVE DYNAMIC if wanted.');
    end
end
