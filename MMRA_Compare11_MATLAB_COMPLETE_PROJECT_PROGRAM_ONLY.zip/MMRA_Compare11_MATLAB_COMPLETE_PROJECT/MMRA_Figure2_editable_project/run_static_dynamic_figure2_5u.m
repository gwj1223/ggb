%RUN_STATIC_DYNAMIC_FIGURE2_5U 5-UAV saved-NFZ + 3 moving-sphere V3 pilot.
% Reads ONLY the obstacle-aware RRT* checkpoint, never an obstacle-free
% 5-UAV path cache. Results go to a new directory; no saved settings change.
% This is an OFFLINE known-trajectory simulation, not onboard autonomy.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
[env,cfg,opt]=mmra_defaults('mountain_cluster_figure2_custom_5km');
env=mmra_figure2_add_static_obstacles(env);
[obstacles,info]=mmra_figure2_dynamic_obstacles(env);
cacheFile=fullfile(root,'results_static_obstacles_dev', ...
    'Figure2_static_obstacle_rrt_5u.mat');
assert(isfile(cacheFile), ...
    ['No saved obstacle-aware RRT* paths. First run ' ...
     'run_static_obstacle_figure2_5u.m.']);
cached=load(cacheFile,'env','paths','records');
assert(isfield(cached,'env') && isfield(cached,'paths') && ...
    isfield(cached,'records') && isequal(cached.env,env) && ...
    iscell(cached.paths) && numel(cached.paths)==5 && ...
    all([cached.records.success]), ...
    ['Static NFZ/terrain has changed since the cached paths were made. ' ...
     'Rerun run_static_obstacle_figure2_5u.m FIRST.']);
paths=cached.paths;
for j=1:5
    assert(mmra_path_free(paths{j},env,cfg.guardFineResolution), ...
        'Cached path is unsafe in the current saved static scene.');
end
opt.speedFeedbackDynamicObstacles=obstacles;
opt.dynamicAdaptiveMaxCandidates=10;
opt.dynamicAdaptiveTryLocalRRT=false;  % keep initial pilot bounded
opt.dynamicAdaptivePredictionBound_m=0; % set only if justified
[best,chosenPaths,decision]= ...
    mmra_dynamic_adaptive_hybrid_schedule(paths,env,cfg,opt);
% Audit the actual executed trajectory, never just the nominal screen.
if best.success
    assert(best.validation.safe && best.validation.complete && ...
           best.validation.dynamicObstacles.safe && ...
           best.minSeparation>=opt.dSafe-opt.tol && ...
           best.obstacleMinClearance_m>=-opt.tol, ...
           'Completed dynamic run failed independent safety checks.');
    for j=1:numel(chosenPaths)
        assert(mmra_path_free(chosenPaths{j},env,cfg.guardFineResolution), ...
            'An accepted detour crosses the saved static exclusions.');
    end
end
fprintf('\n=== FIGURE 2: STATIC NFZ + MOVING OBSTACLES / FIVE UAV ===\n');
fprintf('Static-aware path source: %s\n',cacheFile);
fprintf('Moving obstacle source: %s, count=%d\n',info.source,numel(obstacles));
fprintf('V3 success=%d, reason=%s, strategy=%s\n', ...
    best.success,best.reason,decision.strategy);
fprintf('Obstacle-free estimate=%.2f, obstacle conflict margin=%.2f m\n', ...
    decision.nominalMakespan_s,decision.nominalObstacleClearance_m);
fprintf('Completed makespan=%.2f s, min UAV gap=%.2f m, obstacle clearance=%.2f m\n', ...
    best.makespan,best.minSeparation,best.obstacleMinClearance_m);
fprintf('Dynamic obstacle yield ticks=%d, candidate simulations=%d\n', ...
    best.obstacleYieldSteps,decision.simulatedCandidates);
if decision.nominalObstacleClearance_m>=0
    fprintf(['No nominal UAV/moving-sphere conflict was found with these ' ...
        'saved tracks. Move a sphere onto a flight corridor in the ' ...
        'editor if you want to test a real avoidance event.\n']);
end
outDir=fullfile(root,'results_static_dynamic_dev');
if ~exist(outDir,'dir'),mkdir(outDir);end
save(fullfile(outDir,'Figure2_static_dynamic_5u_v3.mat'), ...
    'env','cfg','opt','info','obstacles','paths','chosenPaths', ...
    'best','decision','cacheFile','-v7');
% Plot ONLY the user-selected Figure 2 with all static and dynamic volumes.
[starts,goals]=mmra_5km_mission(env,5,24001,'cross_center');
fig=mmra_plot_single_main_map(env,starts,goals);
ax=gca;
for j=1:5
    p=chosenPaths{j};
    if ~isempty(p)
        cc=lines(5);
        plot3(ax,p(:,1)/1000,p(:,2)/1000,p(:,3)/1000, ...
            'LineWidth',1.8,'Color',cc(j,:),'HandleVisibility','off');
    end
end
mmra_figure2_plot_dynamic_overlay(ax,obstacles,120,[]);
title(ax,'Figure 2 | validated static-aware routes + moving obstacle snapshot t=120 s');
saveas(fig,fullfile(outDir,'Figure2_static_dynamic_flights_t120.png'));
fprintf('Independent saved results: %s\n',outDir);
fprintf('Safety applies to the idealized prediction/command model only.\n');
