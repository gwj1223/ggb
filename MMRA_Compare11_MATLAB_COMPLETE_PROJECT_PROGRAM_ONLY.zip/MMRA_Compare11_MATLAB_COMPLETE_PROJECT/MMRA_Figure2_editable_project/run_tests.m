% One command to check core invariants. Run from package root in MATLAB.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src')); addpath(fullfile(root,'tests'));
mmra_run_tests();
mmra_rrt_multiobjective_tests();
