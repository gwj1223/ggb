%RUN_CERTIFICATE_GUIDED_20U_CACHED Auto-locate ORIGINAL cached UAV paths.
% Drop-in replacement for the v2.1 certificate repair project root.
% No original RRT* paths are recomputed or modified.
root=fileparts(mfilename('fullpath'));
pathCasesFolder='';
% The former scheduler project may be nested in a SIBLING folder two
% levels above this new project, not directly under the new project parent.
oldName='MMRA_Unified_MATLAB_v2_1_scheduler';
rel=fullfile('results_scheduler_repair_dev','path_cases');
parents={root,fileparts(root),fileparts(fileparts(root)), ...
    fileparts(fileparts(fileparts(root)))};
choices={fullfile(root,rel)};
for pi=1:numel(parents)
    p=parents{pi};
    choices{end+1}=fullfile(p,oldName,rel); %#ok<SAGROW>
    choices{end+1}=fullfile(p,'MMRA_v21_scheduler_bottleneck_repair',oldName,rel); %#ok<SAGROW>
end
probe1='case_paper_gmm_u20_seed942001.mat';
probe2='case_legacy20_sine_u20_seed952001.mat';
for ci=1:numel(choices)
    candidate=choices{ci};
    if isfolder(candidate) && isfile(fullfile(candidate,probe1)) && ...
            isfile(fullfile(candidate,probe2))
        pathCasesFolder=candidate;
        break;
    end
end
if isempty(pathCasesFolder)
    error(['Original saved MAT paths not found in expected nearby projects. ', ...
        'Edit pathCasesFolder in this script to the absolute old ', ...
        'results_scheduler_repair_dev/path_cases folder. ', ...
        'No RRT* rerun is necessary.']);
end
fprintf('AUTO-LOCATED cached RRT* paths: %s\n',pathCasesFolder);
addpath(fullfile(root,'src'),fullfile(root,'tests'),fullfile(root,'examples'));
fprintf('=== MMRA certificate-guided spatial feedback 20-UAV DEV pilot ===\n');
run(fullfile(root,'run_tests.m'));
mmra_rrt_threeobjective_tests();
mmra_sched_repair_tests();
mmra_sched_window_tests();
mmra_certificate_repair_tests();
mmra_certificate_repair_driver(root,true,pathCasesFolder);
