%RUN_DYNAMIC_OBSTACLE_TESTS Regression checks for moving obstacle handling.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'tests'));
mmra_speed_feedback_tests();
mmra_dynamic_obstacle_tests();
