%RUN_MAIN_MAP_5U_PILOT Uses ONLY the selected multi-peak terrain.
% Does not open or save additional map figures.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'examples'));
report=mmra_5km_pilot_driver(root,5,24001, ...
    'mountain_cluster_figure2_custom_5km','cross_center');
disp(report);
