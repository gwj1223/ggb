%RUN_MAIN_MAP_DYNAMIC_ANIMATION Animate 3 saved spheres on SAME Figure 2.
% No timer/background activity, no map or settings writes. The animation
% is visual only; separately run the safe V3 coordination experiment.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
% A standalone view must not reuse an editor figure with stale UI state.
close all;
[env,~,~]=mmra_defaults('mountain_cluster_figure2_custom_5km');
env=mmra_figure2_add_static_obstacles(env);
[obstacles,info]=mmra_figure2_dynamic_obstacles(env);
[starts,goals]=mmra_5km_mission(env,20,24001,'cross_center');
fig=mmra_plot_single_main_map(env,starts,goals);
ax=gca;
drawnow;
assert(~isempty(findall(fig,'Type','surface')), ...
    'Figure 2 terrain did not create a surface. Run run_diagnose_figure2_blank.m.');
handles=[];
maxT=max(arrayfun(@(o)o.time_s(end),obstacles));
fprintf('Playing %d moving obstacles from %s, t=0..%.0f s.\n', ...
    numel(obstacles),info.source,maxT);
for t=0:2:maxT
    if ~ishandle(fig),break;end
    handles=mmra_figure2_plot_dynamic_overlay(ax,obstacles,t,handles);
    title(ax,sprintf('Figure 2 | %d NFZ + %d moving spheres | t=%.0f s', ...
        size(env.noFlyCylinders,1),numel(obstacles),t));
    drawnow;
    pause(.02);
end
fprintf('Animation ended. No obstacle data or terrain setting was changed.\n');
