%RUN_MAIN_MAP_STATIC_OBSTACLES Show SAME saved Figure 2 with hard NFZs.
% Pure terrain/map editor and old baseline run_main_map.m are unchanged.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
close all;
[env,cfg,sched]=mmra_defaults('mountain_cluster_figure2_custom_5km');
env=mmra_figure2_add_static_obstacles(env);
[starts,goals,meta]=mmra_5km_mission(env,20,24001,'cross_center');
fig=mmra_plot_single_main_map(env,starts,goals);
outDir=fullfile(root,'results_static_obstacles_dev');
if ~exist(outDir,'dir'),mkdir(outDir);end
pngFile=fullfile(outDir,'Figure2_static_obstacles.png');
saveas(fig,pngFile);
save(fullfile(outDir,'Figure2_static_obstacles_scene.mat'), ...
    'env','cfg','sched','starts','goals','meta','-v7');
fprintf('SAVED Figure 2 + %d NFZ (gray buildings removed): %s\n', ...
    size(env.noFlyCylinders,1),pngFile);
fprintf('NFZ count=%d, box count=%d; mission endpoints are outside exclusions.\n', ...
    size(env.noFlyCylinders,1),size(env.staticBoxes,1));
fprintf('Original Figure2_user_settings.mat is NOT changed.\n');
