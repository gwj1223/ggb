%RUN_COORDINATION_FIGURE2_5U Fixed Figure 2 geometry, CACHED 5 UAV routes.
% Compares the original 3s staggered feedback controller with the new
% conflict-graph order/release search. No new terrain and no RRT* rerun.
% This is an offline, ideal-motion DEVELOPMENT comparison, not a flight test.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'tests'));
terrain='mountain_cluster_figure2_custom_5km';
[env,~,opt]=mmra_defaults(terrain);
cacheDir=fullfile(root,'results_5km_dev');
assert(exist(cacheDir,'dir')==7, ...
    'Missing cached paths. Keep results_5km_dev from your existing project.');
items=dir(fullfile(cacheDir, ...
    'paths_mountain_cluster_figure2_custom_5km_cross_center_u5_seed24001_*.mat'));
assert(~isempty(items),'Cached Figure 2 U=5 paths were not found.');
[~,reorder]=sort([items.datenum],'descend');items=items(reorder);
found=false;checkpoint='';
for n=1:numel(items)
    filename=fullfile(cacheDir,items(n).name);
    loaded=load(filename,'checkpointData');
    if ~isfield(loaded,'checkpointData'),continue;end
    c=loaded.checkpointData;
    if ~isfield(c,'env') || ~isequal(c.env,env) || ...
            ~isfield(c,'spatialOK') || ~all(c.spatialOK) || ...
            ~isfield(c,'paths') || numel(c.paths)~=5
        continue;
    end
    checkpoint=filename;found=true;break;
end
assert(found,['No cached routes match your CURRENT saved Figure 2 ' ...
    'map. Do not compare paths planned on a different terrain revision.']);
paths=c.paths; %#ok<NASGU>
opt.coordinationMaxTrials=12;
opt.coordinationHeadway_s=2;
opt.coordinationGraphExtra_m=25;
fprintf('\n=== FIGURE 2 MULTI-UAV COORDINATION / SAME 5 ROUTES ===\n');
fprintf('Checkpoint: %s\n',checkpoint);
if isfield(env,'customMapRevision')
    fprintf('Saved terrain revision: %s\n',env.customMapRevision);
end
baseline=mmra_schedule_speed_feedback(paths,opt);
coordinated=mmra_schedule_conflict_graph_coordination(paths,opt);
c=coordinated.coordination;
fprintf('Conflict graph: edges=%d, threshold=%.1f m\n', ...
    c.graph.numEdges,c.graph.threshold_m);
fprintf('Baseline: success=%d, reason=%s, makespan=%.2f s, minsep=%.3f m\n', ...
    baseline.success,baseline.reason,baseline.makespan,baseline.minSeparation);
fprintf('Coordinated: success=%d, reason=%s, makespan=%.2f s, minsep=%.3f m\n', ...
    coordinated.success,coordinated.reason,coordinated.makespan,coordinated.minSeparation);
fprintf('Trials: %d, feasible: %d, stalled: %d; selected: %s\n', ...
    c.numTrials,c.numFeasible,c.numStalled,c.selectedPolicy);
fprintf('Attempt  Policy                Safe  Makespan(s)  Score  Yields\n');
for k=1:c.numTrials
    tr=c.trials(k);
    fprintf('%5d    %-20s %d     %8.2f   %7.2f   %d\n', ...
        k,tr.policy,tr.feasible,tr.makespan_s,tr.score,tr.yieldSteps);
end
if coordinated.success
    assert(coordinated.validation.safe && coordinated.validation.complete && ...
        coordinated.minSeparation>=opt.dSafe-opt.tol-1e-8, ...
        'No coordinated trace may be accepted without independent audit.');
end
if baseline.success && coordinated.success
    assert(c.selectedScore<=c.baselineScore+1e-8, ...
        'Selected schedule must not degrade defined coordination objective.');
end
outDir=fullfile(root,'results_coordination_dev');
if ~exist(outDir,'dir'),mkdir(outDir);end
save(fullfile(outDir,'Figure2_coordination_5u_latest.mat'), ...
    'checkpoint','baseline','coordinated','opt','-v7');
fprintf('Independent output: %s\n',outDir);
fprintf(['Reminder: this is an offline ideal fixed-path speed-command model, ' ...
    'not a real-flight anti-deadlock guarantee.\n']);
