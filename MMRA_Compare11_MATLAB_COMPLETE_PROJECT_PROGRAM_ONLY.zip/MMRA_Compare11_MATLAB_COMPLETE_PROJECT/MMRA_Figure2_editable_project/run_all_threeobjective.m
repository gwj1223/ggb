%RUN_ALL_THREEOBJECTIVE One-command v2.1 MATLAB three-objective pilot.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
addpath(fullfile(root,'tests'));
fprintf('=== MMRA v2.1 length + risk + ascent RRT* pilot ===\n');
run(fullfile(root,'run_tests.m'));
mmra_rrt_threeobjective_tests();
run(fullfile(root,'examples','run_rrt_threeobjective_ablation.m'));
fprintf('=== Done. Results in results_rrt_threeobjective_v21/ ===\n');
