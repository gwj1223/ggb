%RUN_RRT_TERRAIN_ADAPTIVE_FIGURE2_5U Three algorithms on ONE saved map.
% Compare raw paths and weighted cost under exactly the same maxIter.
% Paired seeds fix missions and streams, but distinct search policies
% consume their random numbers differently: do NOT call samples identical.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
profile='mountain_cluster_figure2_custom_5km';
[env,cfg,~]=mmra_defaults(profile);
assert(isequal(env.boundsLo,[0 0 0]) && ...
    isequal(env.boundsHi,[5000 5000 2000]), ...
    'This script is restricted to the saved Figure 2 scene');
assert(isfile(fullfile(root,'results_main_map','Figure2_user_settings.mat')), ...
    'The user-edited Figure 2 settings are required');
U=5;seed=24001;layout='cross_center';
maxIterations=600; % Set to 1800 for longer fixed-budget comparisons.
cfg.maxIter=maxIterations;
cfg.wallBudget_s=Inf;
cfg.prune=false;cfg.smooth=false;
[starts,goals,missionMeta]=mmra_5km_mission(env,U,seed,layout);

labels={'first_feasible','anytime','terrain_adaptive'};
C=numel(labels);
paths=cell(U,C);stats=cell(U,C);
wall_s=NaN(U,C);
rows=repmat(struct('uav',0,'localSeed',0, ...
    'firstSuccess',false,'anytimeSuccess',false, ...
    'adaptiveSuccess',false,'firstObjective_m',NaN, ...
    'anytimeObjective_m',NaN,'adaptiveObjective_m',NaN, ...
    'adaptiveVsAnytime_gain_pct',NaN, ...
    'firstLength_m',NaN,'anytimeLength_m',NaN,'adaptiveLength_m',NaN, ...
    'firstRisk_m',NaN,'anytimeRisk_m',NaN,'adaptiveRisk_m',NaN, ...
    'firstAscent_m',NaN,'anytimeAscent_m',NaN,'adaptiveAscent_m',NaN, ...
    'firstWall_s',NaN,'anytimeWall_s',NaN,'adaptiveWall_s',NaN, ...
    'firstIter',NaN,'anytimeFirstIter',NaN, ...
    'adaptiveFirstIter',NaN,'adaptiveIterations',NaN, ...
    'adaptiveTerrainSamples',0,'adaptiveCorridorSamples',0, ...
    'adaptiveShortSteps',0,'adaptiveMinClearance_m',NaN),U,1);

fprintf('\n=== FIGURE 2 TERRAIN-ADAPTIVE RRT* / U=%d / maxIter=%d ===\n', ...
    U,maxIterations);
fprintf('Saved Figure 2 map revision: %s\n',env.customMapRevision);
for i=1:U
    localSeed=seed+10007*i;
    rows(i).uav=i;rows(i).localSeed=localSeed;
    for m=1:C
        trialCfg=cfg;trialCfg.rrtStopMode=labels{m};
        rng(localSeed,'twister');tStart=tic;
        [paths{i,m},stats{i,m}]=mmra_plan_single( ...
            starts(i,:),goals(i,:),env,trialCfg,true);
        wall_s(i,m)=toc(tStart);
        if stats{i,m}.success
            assert(stats{i,m}.treeCostError<1e-6, ...
                'RRT* tree inconsistency: UAV %d, %s',i,labels{m});
            assert(mmra_path_free(paths{i,m},env,cfg.guardFineResolution), ...
                'Independent fine terrain audit failed: UAV %d, %s', ...
                i,labels{m});
            expected=stats{i,m}.pathLength+ ...
                cfg.riskCostWeight*stats{i,m}.pathRiskIntegral_m+ ...
                cfg.ascentCostWeight*stats{i,m}.pathAscent_m;
            assert(abs(expected-stats{i,m}.pathObjective_m)<1e-6, ...
                'Weighted path objective mismatch: UAV %d, %s', ...
                i,labels{m});
        end
    end
    a=stats{i,1};b=stats{i,2};c=stats{i,3};
    rows(i).firstSuccess=a.success;
    rows(i).anytimeSuccess=b.success;
    rows(i).adaptiveSuccess=c.success;
    rows(i).firstWall_s=wall_s(i,1);
    rows(i).anytimeWall_s=wall_s(i,2);
    rows(i).adaptiveWall_s=wall_s(i,3);
    rows(i).firstIter=a.firstIter;
    rows(i).anytimeFirstIter=b.firstIter;
    rows(i).adaptiveFirstIter=c.firstIter;
    rows(i).adaptiveIterations=c.iterations;
    rows(i).adaptiveTerrainSamples=c.taTerrainSamples;
    rows(i).adaptiveCorridorSamples=c.taCorridorSamples;
    rows(i).adaptiveShortSteps=c.taAdaptedSteps;
    if a.success
        rows(i).firstObjective_m=a.pathObjective_m;
        rows(i).firstLength_m=a.pathLength;
        rows(i).firstRisk_m=a.pathRiskIntegral_m;
        rows(i).firstAscent_m=a.pathAscent_m;
    end
    if b.success
        rows(i).anytimeObjective_m=b.pathObjective_m;
        rows(i).anytimeLength_m=b.pathLength;
        rows(i).anytimeRisk_m=b.pathRiskIntegral_m;
        rows(i).anytimeAscent_m=b.pathAscent_m;
        if a.success
            assert(b.firstIter==a.firstIter && ...
                isequaln(b.firstFeasiblePath,paths{i,1}) && ...
                abs(b.firstObjective_m-a.pathObjective_m)<1e-6, ...
                'Frozen baseline differs from anytime first path');
        end
    end
    if c.success
        rows(i).adaptiveObjective_m=c.pathObjective_m;
        rows(i).adaptiveLength_m=c.pathLength;
        rows(i).adaptiveRisk_m=c.pathRiskIntegral_m;
        rows(i).adaptiveAscent_m=c.pathAscent_m;
        [clearance,~]=mmra_path_clearance( ...
            paths{i,3},env,cfg.guardFineResolution);
        rows(i).adaptiveMinClearance_m=clearance;
        assert(isfinite(clearance) && clearance>0, ...
            'Adaptive path violates fine terrain clearance');
        assert(c.pathObjective_m<=c.firstObjective_m+1e-7, ...
            'Adaptive best cost worsened relative to first feasibility');
        if b.success
            rows(i).adaptiveVsAnytime_gain_pct= ...
                100*(b.pathObjective_m-c.pathObjective_m)/ ...
                max(b.pathObjective_m,eps);
        end
    end
    fprintf(['UAV %d: success %d/%d/%d; J first=%.2f, any=%.2f, ' ...
        'adaptive=%.2f; adaptive vs anytime=%+.2f%%; time=%.2f/%.2f/%.2f s\n'], ...
        i,a.success,b.success,c.success,rows(i).firstObjective_m, ...
        rows(i).anytimeObjective_m,rows(i).adaptiveObjective_m, ...
        rows(i).adaptiveVsAnytime_gain_pct,wall_s(i,1),wall_s(i,2),wall_s(i,3));
end
outDir=fullfile(root,'results_rrt_terrain_adaptive_dev');
if ~exist(outDir,'dir'),mkdir(outDir);end
summaryTable=struct2table(rows);
results=struct('protocol','FIGURE2_TERRAIN_ADAPTIVE_V1', ...
    'profile',profile,'mapRevision',env.customMapRevision, ...
    'seed',seed,'layout',layout,'U',U, ...
    'maxIterations',maxIterations,'cfg',cfg, ...
    'starts',starts,'goals',goals,'missionMeta',missionMeta, ...
    'labels',{labels},'paths',{paths},'stats',{stats},'wall_s',wall_s);
save(fullfile(outDir,'figure2_rrt_terrain_5u_seed24001.mat'), ...
    'results','summaryTable','-v7');
writetable(summaryTable, ...
    fullfile(outDir,'figure2_rrt_terrain_5u_seed24001.csv'));
try
    f=figure('Visible','off','Color','w');hold on;
    for i=1:U
        if stats{i,2}.success
            x=stats{i,2}.bestCostByIteration_m;
            plot(1:numel(x),x,'--','LineWidth',1.0, ...
                'DisplayName',sprintf('UAV%d anytime',i));
        end
        if stats{i,3}.success
            x=stats{i,3}.bestCostByIteration_m;
            plot(1:numel(x),x,'-','LineWidth',1.0, ...
                'DisplayName',sprintf('UAV%d adaptive',i));
        end
    end
    xlabel('RRT* iteration');
    ylabel('Best raw weighted path cost J (m)');
    title('Figure 2: same-iteration RRT* cost convergence');
    legend('Location','bestoutside');
    grid on;
    saveas(f,fullfile(outDir,'figure2_rrt_terrain_convergence.png'));
    close(f);
catch plotErr
    warning('Convergence plot could not be saved: %s',plotErr.message);
end
fprintf(['Successes: first=%d/%d, anytime=%d/%d, ' ...
    'adaptive=%d/%d\n'],sum([rows.firstSuccess]),U, ...
    sum([rows.anytimeSuccess]),U,sum([rows.adaptiveSuccess]),U);
fprintf('New output folder: %s\n',outDir);
