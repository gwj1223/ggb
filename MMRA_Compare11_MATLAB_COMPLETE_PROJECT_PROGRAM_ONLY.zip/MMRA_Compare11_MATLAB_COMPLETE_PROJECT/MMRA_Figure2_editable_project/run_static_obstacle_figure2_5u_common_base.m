%RUN_STATIC_OBSTACLE_FIGURE2_5U_COMMON_BASE
% Five UAVs depart from ONE base (five separate launch pads, 45 m apart).
% Keep the five original goals, original Figure 2 map and saved NFZ settings.
% This is a NEW experiment: the old cross_center source script is unchanged.
% If all five new plans succeed, back up the old downstream path cache,
% then update it so run_static_dynamic_figure2_5u uses the NEW mission.
%
% Place this script in the project ROOT (next to run_static_dynamic_figure2_5u.m).

root = fileparts(mfilename('fullpath'));
addpath(fullfile(root, 'src'));

[env, cfg, sched] = mmra_defaults('mountain_cluster_figure2_custom_5km');
env = mmra_figure2_add_static_obstacles(env);

% The old generator supplies the five *existing* target positions.
[oldStarts, goals, meta] = mmra_5km_mission(env, 5, 24001, 'cross_center');

% The previous UAV 3 start has already been used successfully as a start.
% Nearby pads still need independent terrain and no-fly checks (below).
baseCenter_m = oldStarts(3, :);
padSpacing_m = 45;
padOffsets_m = padSpacing_m * [ ...
     0  0  0; ...  % UAV 1: base center
     1  0  0; ...  % UAV 2: east
    -1  0  0; ...  % UAV 3: west
     0  1  0; ...  % UAV 4: north
     0 -1  0];    % UAV 5: south
starts = repmat(baseCenter_m, 5, 1) + padOffsets_m;

% Preserve and identify the actual task without relying on unknown fields
% of the original meta returned by mmra_5km_mission.
missionInfo = struct();
missionInfo.name = 'five_uav_common_base';
missionInfo.originalGoalSource = 'cross_center, seed=24001';
missionInfo.baseCenter_m = baseCenter_m;
missionInfo.padSpacing_m = padSpacing_m;
missionInfo.oldStarts_m = oldStarts;
missionInfo.starts_m = starts;
missionInfo.goals_m = goals;
missionInfo.minPadSeparation_m = NaN;

fprintf('\n=== FIGURE 2 / COMMON BASE: 5 UAVs ===\n');
fprintf('Base center: [%.1f, %.1f, %.1f] m\n', baseCenter_m);

% Validate launch pads BEFORE attempting RRT*. A short nonzero segment is
% used so the same path/edge collision checker tests each pad.
minPadSep_m = inf;
for i = 1:5
    for j = i+1:5
        minPadSep_m = min(minPadSep_m, norm(starts(i,:) - starts(j,:)));
    end

    q = [starts(i,:); starts(i,:) + [1, 0, 0]]; % 1-m local probe
    terrainAndStaticOK = mmra_path_free(q, env, cfg.guardFineResolution);
    noFlyCheck = mmra_no_fly_free(q, env);
    localClearance_m = mmra_path_clearance(q, env, cfg.guardFineResolution);

    fprintf('UAV %d start=[%.1f %.1f %.1f] m, local terrain clearance=%.1f m\n', ...
        i, starts(i,1), starts(i,2), starts(i,3), localClearance_m);

    assert(isscalar(terrainAndStaticOK) && logical(terrainAndStaticOK) && ...
           all(noFlyCheck(:)) && isfinite(localClearance_m), ...
        ['UAV %d launch pad fails terrain, boundary or static-NFZ ' ...
         'validation. Move baseCenter_m or raise the common altitude ' ...
         'after checking the Figure 2 map.'], i);
end
missionInfo.minPadSeparation_m = minPadSep_m;
% The mission generator returned metadata for the OLD cross-center task.
% Keep its provenance, but synchronize common start/goal fields where they
% exist and explicitly identify the new task for downstream readers.
if isstruct(meta) && isscalar(meta)
    if isfield(meta, 'starts'),   meta.starts = starts; end
    if isfield(meta, 'starts_m'), meta.starts_m = starts; end
    if isfield(meta, 'goals'),    meta.goals = goals; end
    if isfield(meta, 'goals_m'),  meta.goals_m = goals; end
    if isfield(meta, 'mode'),     meta.mode = 'common_base'; end
    meta.commonBaseMission = missionInfo;
end
assert(minPadSep_m > 10, ...
    'Launch pads are too close for the 10-m initial UAV-separation rule.');
fprintf('Minimum launch-pad separation: %.1f m\n', minPadSep_m);

% Keep the original 3-objective cost and planning budget for comparison.
cfg.rrtStopMode = 'terrain_adaptive';
cfg.maxIter = 1200;
assert(strcmp(cfg.costMode, 'length_risk_climb'));

paths = cell(5,1);
records = struct('success',{},'reason',{}, ...
    'length_m',{},'risk_m',{},'climb_m',{},'objective_m',{}, ...
    'minTerrainClearance_m',{},'elapsed_s',{});

rng(24001, 'twister');
for i = 1:5
    [p, st] = mmra_plan_single(starts(i,:), goals(i,:), env, cfg, true);
    paths{i} = p;
    records(i).success = logical(st.success);
    records(i).reason = char(st.reason);
    records(i).elapsed_s = st.total_s;
    records(i).length_m = NaN;
    records(i).risk_m = NaN;
    records(i).climb_m = NaN;
    records(i).objective_m = NaN;
    records(i).minTerrainClearance_m = NaN;

    if st.success
        assert(size(p,2) == 3 && size(p,1) >= 2, ...
            'UAV %d returned a malformed path.', i);
        assert(norm(p(1,:) - starts(i,:)) < 1 && ...
               norm(p(end,:) - goals(i,:)) < 1, ...
            'UAV %d returned a path with unexpected endpoints.', i);
        assert(mmra_path_free(p, env, cfg.guardFineResolution), ...
            'UAV %d path intersects the terrain or a buffered exclusion.', i);
        assert(all(mmra_no_fly_free(p, env)), ...
            'UAV %d path intersects a static no-fly zone.', i);
        records(i).length_m = mmra_path_length(p);
        records(i).risk_m = mmra_path_risk(p, env, ...
            cfg.riskCostBand_m, cfg.riskCostResolution_m);
        records(i).climb_m = mmra_path_ascent(p);
        records(i).objective_m = st.finalObjective_m;
        records(i).minTerrainClearance_m = ...
            mmra_path_clearance(p, env, cfg.guardFineResolution);
    end

    fprintf('UAV %d: success=%d, reason=%s, J=%.2f, time=%.2f s\n', ...
        i, st.success, st.reason, records(i).objective_m, st.total_s);
end

% ALWAYS archive this new experiment independently of cross_center.
archiveDir = fullfile(root, 'results_common_base_dev');
if ~exist(archiveDir, 'dir'), mkdir(archiveDir); end
archiveMat = fullfile(archiveDir, 'Figure2_common_base_rrt_5u.mat');
save(archiveMat, 'env','cfg','sched','starts','goals','meta', ...
    'missionInfo','paths','records','-v7');

fig = mmra_plot_single_main_map(env, starts, goals);
colors = lines(5);
for i = 1:5
    p = paths{i};
    if ~isempty(p)
        plot3(p(:,1)/1000, p(:,2)/1000, p(:,3)/1000, '-', ...
            'Color',colors(i,:), 'LineWidth',2, ...
            'HandleVisibility','off');
    end
end
archivePng = fullfile(archiveDir, 'Figure2_common_base_planned_paths_5u.png');
saveas(fig, archivePng);

nSuccess = sum([records.success]);
fprintf('\nCommon-base obstacle-aware RRT*: %d/5 successful.\n', nSuccess);
fprintf('Independent archive: %s\n', archiveDir);

% Only fully successful tasks may replace the cache read downstream.
if nSuccess == 5
    downstreamDir = fullfile(root, 'results_static_obstacles_dev');
    if ~exist(downstreamDir, 'dir'), mkdir(downstreamDir); end
    downstreamMat = fullfile(downstreamDir, 'Figure2_static_obstacle_rrt_5u.mat');
    downstreamPng = fullfile(downstreamDir, ...
        'Figure2_static_obstacle_planned_paths_5u.png');

    stamp = datestr(now, 'yyyymmdd_HHMMSS');
    if exist(downstreamMat, 'file')
        backupMat = fullfile(downstreamDir, ...
            ['Figure2_static_obstacle_rrt_5u_before_common_base_' stamp '.mat']);
        assert(~exist(backupMat, 'file'), 'Backup name already exists. Rerun later.');
        [ok,msg] = copyfile(downstreamMat, backupMat);
        assert(ok, 'Unable to back up original mission MAT: %s', msg);
        fprintf('Old mission MAT backed up: %s\n', backupMat);
    end
    if exist(downstreamPng, 'file')
        backupPng = fullfile(downstreamDir, ...
            ['Figure2_static_obstacle_planned_paths_5u_before_common_base_' ...
             stamp '.png']);
        assert(~exist(backupPng, 'file'), 'PNG backup name already exists.');
        [ok,msg] = copyfile(downstreamPng, backupPng);
        assert(ok, 'Unable to back up original mission PNG: %s', msg);
    end

    [ok,msg] = copyfile(archiveMat, downstreamMat, 'f');
    assert(ok, 'Failed to update downstream path MAT: %s', msg);
    [ok,msg] = copyfile(archivePng, downstreamPng, 'f');
    assert(ok, 'Failed to update downstream path PNG: %s', msg);
    fprintf('Downstream path cache UPDATED to COMMON BASE: %s\n', downstreamMat);
    fprintf('Next: run(''run_static_dynamic_figure2_5u.m'')\n');
else
    warning(['Only %d/5 planned successfully. The original downstream ' ...
        'path cache was NOT touched. Check failed reasons, base safety, ' ...
        'and RRT* budget before rerunning.'], nSuccess);
end

fprintf('Saved Figure 2 map/NFZ/dynamic-obstacle settings were NOT modified.\n');
