%RUN_CHECK_EDITOR_DISPLAY Inspect Figure 2 graphics without changing data.
% Run with run_main_map_editor already open.
fig=findall(groot,'Type','figure','Number',2);
if isempty(fig)
    error('Figure 2 not found. Open it using run_main_map_editor first.');
end
fig=fig(1);
fprintf('Figure 2 visible=%s, renderer=%s\n', ...
    get(fig,'Visible'),get(fig,'Renderer'));
ax=findall(fig,'Type','axes');
fprintf('Axes count = %d\n',numel(ax));
if isempty(ax)
    warning('MMRA:NoAxes','No axes exists; GUI created but no 3-D plot.');
else
    for k=1:numel(ax)
        a=ax(k);
        ss=findall(a,'Type','surface');
        tt=findall(a,'Type','text');
        fprintf(['Axes %d: Visible=%s, surfaces=%d, text=%d, ' ...
                 'Position=[%s]\n'], ...
            k,get(a,'Visible'),numel(ss),numel(tt), ...
            num2str(get(a,'Position'),'%.3f '));
        for j=1:min(2,numel(ss))
            z=get(ss(j),'ZData');
            zr=double(z(:));zr=zr(isfinite(zr));
            if isempty(zr),zr=NaN;end
            fprintf('  Surface %d: Visible=%s; Z range [%.3f, %.3f]\n', ...
                j,get(ss(j),'Visible'),min(zr),max(zr));
        end
    end
end
p=findall(fig,'Type','uipanel');
fprintf('UI panel count=%d\n',numel(p));
for k=1:numel(p)
    if strcmpi(get(p(k),'BorderType'),'none')
        fprintf('Plot panel candidate: Visible=%s Position=[%s]\n', ...
            get(p(k),'Visible'),num2str(get(p(k),'Position'),'%.3f '));
    end
end
drawnow;
fprintf('If the axes and surfaces exist but the right side is blank,\n');
fprintf('try switching between EDIT TERRAIN and EDIT MOVING OBSTACLES,\n');
fprintf('then press REFRESH 3-D VIEW. If still blank, report this log.\n');
