%RUN_SPATIOTEMPORAL_COORDINATION_FIGURE2_5U Stage-2 innovation V2 pilot.
% Reuses the SAME saved 5-UAV Figure 2 paths; does not rerun RRT*, alter
% terrain parameters, or change the dynamic-obstacle innovation module.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'tests'));
[env,~,opt]=mmra_defaults('mountain_cluster_figure2_custom_5km');
files=dir(fullfile(root,'results_5km_dev', ...
    'paths_mountain_cluster_figure2_custom_5km_cross_center_u5_seed24001_*.mat'));
assert(~isempty(files),'Missing saved Figure 2 5-UAV route checkpoint.');
[~,idx]=sort([files.datenum],'descend');files=files(idx);
loadedOk=false;
for k=1:numel(files)
    file=fullfile(files(k).folder,files(k).name);
    saved=load(file,'checkpointData');
    if ~isfield(saved,'checkpointData'),continue;end
    data=saved.checkpointData;
    if isfield(data,'env') && isequal(data.env,env) && ...
            isfield(data,'spatialOK') && all(data.spatialOK) && ...
            isfield(data,'paths') && numel(data.paths)==5
        paths=data.paths;checkpoint=file;loadedOk=true;break;
    end
end
assert(loadedOk,'No checkpoint matches the CURRENT saved Figure 2 map.');
opt.coordinationV2MaxTrials=30;
opt.coordinationV2UniformGaps_s=[0 0.5 1 2];
opt.coordinationV2MakespanWeight=1;
opt.coordinationV2MeanFinishWeight=1;
opt.coordinationV2YieldPenalty=0.2;
opt.coordinationV2PriorityPolicy='dynamic_eta';

fprintf('\n=== FIGURE 2: SPATIOTEMPORAL MULTI-UAV COORDINATION V2 ===\n');
fprintf('Cached paths: %s\n',checkpoint);
if isfield(env,'customMapRevision')
    fprintf('Saved map revision: %s\n',env.customMapRevision);
end
old=mmra_schedule_speed_feedback(paths,opt);
new=mmra_schedule_spatiotemporal_coordination(paths,opt);
m=new.coordination;
fprintf(['Legacy 3 s: success=%d, makespan=%.2f s, ' ...
    'mean finish=%.2f s, minsep=%.3f m, yields=%d\n'], ...
    old.success,old.makespan,mean(old.completionTimes_s), ...
    old.minSeparation,old.yieldSteps);
fprintf(['V2 chosen: success=%d, policy=%s, priority=%s, ' ...
    'makespan=%.2f s, mean finish=%.2f s, ' ...
    'minsep=%.3f m, yields=%d\n'], ...
    new.success,m.selectedPolicy,m.selectedPriorityMode, ...
    new.makespan,mean(new.completionTimes_s), ...
    new.minSeparation,new.yieldSteps);
fprintf(['Spatial edges=%d; nominal unsafe edges baseline=%d, ' ...
    'chosen=%d (nominal screen only).\n'], ...
    m.spatialGraph.numEdges,m.baselineNominal.numUnsafePairs, ...
    m.selectedNominal.numUnsafePairs);
fprintf('Candidates: %d, feasible: %d, stalled: %d\n', ...
    m.numTrials,m.numFeasible,m.numStalled);
fprintf('Selected launch times [s] by UAV index:');
fprintf(' %.2f',m.selectedLaunchTimes_s);fprintf('\n');
fprintf('Trial  Policy                  Safe  MeanFinish  Makespan    Score  NominalRisk\n');
for i=1:m.numTrials
    c=m.trials(i);
    fprintf('%4d   %-23s  %d    %8.2f   %8.2f  %7.2f    %d\n', ...
        i,c.policy,c.feasible,c.meanFinish_s,c.makespan_s,c.score, ...
        c.predictedUnsafePairs);
end
if new.success
    assert(new.validation.safe && new.validation.complete && ...
        new.minSeparation>=opt.dSafe-opt.tol-1e-8);
end
if old.success
    assert(new.success && m.selectedScore<=m.baselineScore+1e-8);
end
outDir=fullfile(root,'results_coordination_v2_dev');
if ~exist(outDir,'dir'),mkdir(outDir);end
save(fullfile(outDir,'Figure2_5u_spatiotemporal_v2.mat'), ...
    'checkpoint','opt','old','new','-v7');
fprintf('Saved independent diagnostics: %s\n',outDir);
fprintf(['Limit: offline ideal fixed-route command model; nominal conflict ' ...
    'screening is NOT an executed-trajectory safety proof.\n']);
