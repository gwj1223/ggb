%RUN_DYNAMIC_OBSTACLE_DEMO One drone yields to ONE crossing moving sphere.
% No new terrain scene is generated; the user-selected Figure 2 is unchanged.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
[~,~,opt]=mmra_defaults('paper_gmm');
opt.speedFeedbackMaxTime_s=120;
opt.speedFeedbackMaxStall_s=25;
opt.speedFeedbackDroneRadius_m=1;
opt.speedFeedbackObstacleGuard_m=2;
path={[-90 0 200;90 0 200]};
ob=struct('name','moving_spherical_obstacle', ...
    'time_s',[0;2;14], ...
    'position_m',[0 -60 200;0 -60 200;0 60 200], ...
    'radius_m',10);
base=mmra_schedule_speed_feedback(path,opt);
opt.speedFeedbackDynamicObstacles=ob;
answer=mmra_schedule_speed_feedback(path,opt);
assert(base.success,'The unblocked baseline did not complete.');
baseOb=mmra_verify_dynamic_obstacles(path,base.trace,opt,ob);
fprintf('Unprotected nominal trajectory: obstacle conflict=%d, min clearance=%.3f m\n', ...
    ~baseOb.safe,baseOb.minClearance_m);
fprintf('Protected trajectory: success=%d reason=%s, min clearance=%.3f m, yielding ticks=%d\n', ...
    answer.success,answer.reason,answer.obstacleMinClearance_m, ...
    answer.obstacleYieldSteps);
assert(answer.validation.safe, ...
    'Never display an unverified unsafe execution as successful.');
T=answer.trace.time_s;
figure('Name','Moving obstacle: predictive stop-and-go speed control');
subplot(2,1,1);
stairs(T(2:end),answer.trace.speed_mps(:,1),'LineWidth',1.25);
ylabel('Speed (m/s)');title('Predicted obstacle crossing: yielding and recovery');
grid on;
subplot(2,1,2);
pos=squeeze(answer.trace.position_m(:,:,1));
centers=mmra_dynamic_obstacle_position( ...
    mmra_dynamic_obstacles_prepare(ob),T);
d=sqrt(sum((pos-centers).^2,2))-(ob.radius_m+ ...
    opt.speedFeedbackDroneRadius_m+opt.speedFeedbackObstacleGuard_m);
plot(T,d,'LineWidth',1.25);hold on;
plot([T(1),T(end)],[0 0],'--','LineWidth',1);
xlabel('Time (s)');ylabel('Clearance above protected radius (m)');
grid on;
legend('Clearance at ticks (for illustration)', ...
    'Minimum permitted','Location','best');
fprintf('Independent verifier also checks between ticks and path/obstacle knots.\n');
