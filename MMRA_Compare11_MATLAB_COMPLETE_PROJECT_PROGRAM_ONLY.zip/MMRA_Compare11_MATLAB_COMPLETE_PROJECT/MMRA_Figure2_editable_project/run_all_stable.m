%RUN_ALL_STABLE v1.7 one-command, noninteractive tests and fixed evaluation.
% MATLAB: run('run_all_stable.m') from the extracted package root.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
addpath(fullfile(root,'tests'));
outDir=fullfile(root,'results_guarded_sc_v17');
if ~exist(outDir,'dir'),mkdir(outDir);end
f=fopen(fullfile(outDir,'RUN_STATUS.txt'),'w');
assert(f>0,'Cannot write run status');
fprintf(f,'IN_PROGRESS: REGRESSION TESTS\n');fclose(f);
fprintf('=== MMRA v1.7 one-shot guarded SC-APF pipeline ===\n');
run(fullfile(root,'run_tests.m'));
run(fullfile(root,'examples','run_guarded_sc_final_eval.m'));
fprintf('=== Complete. Results are under results_guarded_sc_v17/ ===\n');
