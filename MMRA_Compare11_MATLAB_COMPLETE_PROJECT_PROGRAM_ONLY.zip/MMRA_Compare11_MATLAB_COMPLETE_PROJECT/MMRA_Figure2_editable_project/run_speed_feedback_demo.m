%RUN_SPEED_FEEDBACK_DEMO Two crossing quadrotors, dynamic speed profiles.
% IDEAL commanded polyline model only: requires real-dynamics verification.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'tests'));
[~,~,o]=mmra_defaults('paper_gmm');
o.mode='speed_feedback';
P={[-40 0 20;40 0 20],[0 -40 20;0 40 20]};
s=mmra_schedule_speed_feedback(P,o);
fprintf('Speed-feedback success=%d, reason=%s, makespan=%g s, minsep=%g m\n', ...
    s.success,s.reason,s.makespan,s.minSeparation);
fprintf('Yield steps=%d, shield changes=%d, independently verified=%d\n', ...
    s.yieldSteps,s.shieldAdjustments,s.validation.safe);
assert(s.validation.safe,'Do not plot any unchecked unsafe execution.');
T=s.trace.time_s;
figure('Name','MMRA dynamic speed coordination, two crossing UAVs');
subplot(2,1,1);
stairs(T(2:end),s.trace.speed_mps,'LineWidth',1.2);
ylabel('Commanded speed (m/s)');grid on;
title('Predictive speed feedback: crossing flight paths');
legend('UAV 1','UAV 2','Location','best');
subplot(2,1,2);
pa=squeeze(s.trace.position_m(:,:,1));
pb=squeeze(s.trace.position_m(:,:,2));
d=sqrt(sum((pa-pb).^2,2));
plot(T,d,'LineWidth',1.3);hold on;
plot([T(1),T(end)],[o.dSafe,o.dSafe],'--','LineWidth',1);
ylabel('Actual separation (m)');xlabel('Time (s)');grid on;
legend('At recorded ticks','Safety threshold','Location','best');
fprintf('Note: independent verifier checks between ticks and waypoint crossings.\n');
