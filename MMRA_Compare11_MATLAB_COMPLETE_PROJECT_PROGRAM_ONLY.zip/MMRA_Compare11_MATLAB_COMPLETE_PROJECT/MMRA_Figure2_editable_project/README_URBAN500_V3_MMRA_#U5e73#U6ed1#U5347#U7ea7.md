# Urban500 V3 × MMRA 共享剪枝/平滑升级包

**版本：V3/MMRA Adaptive-Safe（新增功能；不覆盖既有实验结果）**

## 做了哪些实际修改

1. **真正复用 MMRA 主算法模块**：Urban500 的 `run_urban500_rrtstar_5u.m` 在 RRT* 搜索后调用 `urban500_mmra_postprocess.m`，后者直接调用 `src/mmra_prune.m` 和 `src/mmra_bezier.m`。不再把 `urban500_rrtstar_shortcut.m` 当作最终的曲线平滑。
2. **改进 MMRA 剪枝**：保留过去的 `greedy` 默认行为，另提供 `cfg.pruneMode='shortest_visibility'`，通过“原路径节点间可见图 + 动态规划”找已知节点之间的最短碰撞安全折线路径。Urban500 默认选新模式。
3. **改进 MMRA 平滑**：保留原来的 `legacy_midpoint` 默认行为以保护旧实验可复现性；新增 `cfg.smoothMode='adaptive_safe'`，逐拐点、递减切入长度、二次 Bézier 转弯。被障碍挡住的角只回退该角，不强制整条路径回退。
4. **真正检查连续曲线**：Urban500 的 `urban500_bezier_curve_free.m` 用二次 Bézier 的控制点凸包包围性质与 de Casteljau 二分，保守检查**整段二次曲线**是否避开膨胀后的 3-D 建筑 AABB，不只检查绘制采样点。未能证明安全的候选直接拒绝。
5. **可配置几何约束**：新平滑可约束所接受曲线的最小三维曲率半径、最大切线爬升/下降角，以及输出采样密度。曲线端点与原有直线保持 **G1 切向方向连续**，但尚不是 C2 连续，不代表动力学可飞行。
6. **保存三阶段真实路径和可检查指标**：`rawPaths`、`prunedPaths`、`paths`、`postprocessStats`，每条路径有剪枝/曲线转角、曲线接受数与未平滑数量；新结果写在新目录，原 MAT/CSV/PNG 保留。

## MATLAB 使用步骤

解压后 **保持完整工程目录结构**：`MMRA_Figure2_editable_project/src` 与 `MMRA_Figure2_editable_project/Urban500_V3_HighRise_Download/Urban_Complex_500m_V3_HighRise` 必须同时存在。

在 MATLAB R2023b 中：

```matlab
city = fullfile('你的解压目录','MMRA_Figure2_editable_project', ...
    'Urban500_V3_HighRise_Download','Urban_Complex_500m_V3_HighRise');
cd(city)

% 1. 自动检查共享 MMRA 模块、回退、转弯半径、静态避碰、旧五航迹
run('run_urban500_mmra_selftest.m')

% 2. 快速查看：对历史 MAT 中的五条已剪枝路径再平滑（不跑 RRT*）
run('run_urban500_mmra_saved_demo.m')

% 3. 正式全流程：重跑五机 RRT*，执行 MMRA 剪枝 + 平滑
run('run_urban500_rrtstar_5u.m')
```

快速 demo 输出 `results_urban_complex_500_v3_rrtstar_mmra_demo/`；正式五机规划输出 `results_urban_complex_500_v3_rrtstar_mmra/`。原始 `results_urban_complex_500_v3_rrtstar/` **不覆盖**。

注意：快速 demo 读取的旧 MAT 已经是 *原旧版随机捷径剪枝之后* 的路径，所以 demo 中 `archivedNodes` 不是原始搜索树路径点数；只有重跑正式全流程后，`rawPaths` 才是真正的 RRT* 搜索结果。

## 配置与修改位置

在 `run_urban500_rrtstar_5u.m` 中可直接修改：

| 参数 | 当前默认 | 含义 |
|---|---:|---|
| `cfg.mmraPruneMode` | `shortest_visibility` | 剪枝可见图最短路；旧 `greedy` 仍可选 |
| `cfg.smoothMinRadius_m` | 10 m | 仅对**已接受**的 Bézier 弧段施加最小转弯半径 |
| `cfg.smoothMaxPitch_deg` | 75° | 仅限制生成曲线的几何最大切线俯仰角；**不是**飞行器能力声明 |
| `cfg.smoothTrimFraction` | 0.44 | 每侧最多截取相邻原折线段的 44%，避免相邻圆角重叠 |
| `cfg.smoothMaxChord_m` | 2.5 m | 绘制/保存折线的名义分段长度 |
| `cfg.smoothMaxSagitta_m` | 0.10 m | 采样密度的**启发式**弦高误差控制；真正建筑安全依赖连续曲线证书 |
| `cfg.smoothMinAngle_deg` | 2° | 太小的转角不作修改 |

调整最小半径或允许爬升角后，如果某个角无法安全平滑，会保持原始拐点，并在 `postprocessStats{k}.allEligibleCornersSmoothed` 中标记 **false**；这样不声称整条路径已满足转弯半径约束。工程**不会**为了平滑而穿楼。若要保证每个拐角都平滑，需要带曲率约束重新规划，而不只是路径后处理。

## MMRA 主算法如何使用升级功能

MMRA 原有 `cfg.smooth=true` 不变。`mmra_bezier` 默认仍用历史 `legacy_midpoint`，不会静默改变旧论文数据；要在 MMRA 新实验中启用升级模式，请在配置 `cfg` 上额外设置：

```matlab
cfg.smooth = true;
cfg.smoothMode = 'adaptive_safe';
cfg.smoothMinRadius_m = 2;   % 请根据 MMRA 场景的真实物理尺度另行设定
cfg.smoothMaxPitch_deg = 45;
cfg.smoothTrimFraction = 0.44;
cfg.smoothMaxChord_m = 0.75;
cfg.smoothMaxSagitta_m = 0.05;
```

MMRA 原始地形/NFZ 检查仍使用同一 `mmra_path_free` / `mmra_edge_free` 采样碰撞检查器；它**没有** Urban500 针对长方体建筑的连续曲线证书。在 MMRA 地形中是否存在曲线弦之间的漏检，仍取决于地形采样分辨率，不应声称连续安全得到证明。

## 数值交叉验证（不是 MATLAB 运行结果）

对源 ZIP 里保存的五条历史路径，额外以 **Python 独立几何参考实现**完成了剪枝 + 自适应平滑、每段新折线的静态建筑碰撞检查和每段原始二次曲线的保守证书。五条路径的圆角都可接受；以下是该独立试算的数值，**不是** MATLAB 已跑通或无人机真实飞行结果：

| UAV | MMRA 剪枝后最大采样折线转角 | 平滑后最大采样折线转角 | 成功平滑拐角 | 平滑后长度 |
|---|---:|---:|---:|---:|
| 1 | 108.15° | 4.68° | 10/10 | 891.13 m |
| 2 | 71.31° | 5.79° | 6/6 | 784.12 m |
| 3 | 67.58° | 7.01° | 8/8 | 707.79 m |
| 4 | 97.44° | 5.43° | 7/7 | 644.06 m |
| 5 | 85.32° | 7.32° | 5/5 | 605.59 m |

上述“最大采样转角”取自离散输出折线，**不能**被当成真实连续曲线的最大转向角，也不能替代最小曲率半径指标。验证原始数据见 `docs/urban500_mmra_numerical_QA/`；Python 复核入口是 `tests/check_urban500_mmra_geometry.py`。

## 风险与限制

- **只处理静态建筑物**。六个高空动态球体的时序碰撞、不同无人机之间的同时占用/冲突、速度与加速度/控制输入/推力约束，均未纳入此次剪枝平滑验证。
- “G1 连续”指几何切线方向，曲线转直线的曲率可能跳变，不是曲率连续的 C2 轨迹。
- 局部平滑失败时保留原折角，此时整条路径**没有**最小转弯半径保证；检查 `allEligibleCornersSmoothed`。
- `75°` 是为了保留现有三维 V3 航线而选的几何测试上限，实际飞行器可用爬升角、速度、侧向加速度需由具体机型确定。
- 当前执行环境未安装 MATLAB / Octave，**无法在这里实际运行 .m 文件**。已执行的是 Python 几何交叉验证，新增 MATLAB 自检脚本请在你的 MATLAB R2023b 环境中运行，若提示失败，请以该环境输出为准。
