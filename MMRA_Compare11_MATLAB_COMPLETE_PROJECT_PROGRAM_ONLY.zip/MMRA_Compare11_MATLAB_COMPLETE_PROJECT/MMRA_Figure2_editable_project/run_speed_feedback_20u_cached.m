%RUN_SPEED_FEEDBACK_20U_CACHED v2.2 DEVELOPMENT on SAVED RRT* paths ONLY.
% Optional: set pathCasesFolder to the absolute original path_cases folder.
% Optional: set repairedPathsFolder to the old repaired_paths folder.
% No RRT* rerun; does not modify v2.1 result files or caches.
root=fileparts(mfilename('fullpath'));
pathCasesFolder='';
repairedPathsFolder='';
seeds=1:30;  % For a quick smoke run, temporarily set e.g. seeds=1:3.
addpath(fullfile(root,'src'),fullfile(root,'examples'));
mmra_speed_feedback_cached_driver(root,20,pathCasesFolder,repairedPathsFolder,seeds);
