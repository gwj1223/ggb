%RUN_RRT_TERRAIN_ADAPTIVE_MULTISEED Optional paired 5-UAV evaluation.
% Run AFTER unit tests and quick pilot. Increase nMissionSeeds to 30 for
% statistical reporting. Same map, independent mission/random seeds.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
[env,cfg,~]=mmra_defaults('mountain_cluster_figure2_custom_5km');
assert(isfile(fullfile(root,'results_main_map','Figure2_user_settings.mat')));
cfg.maxIter=600;cfg.wallBudget_s=Inf;cfg.prune=false;cfg.smooth=false;
U=5;nMissionSeeds=10; % set 30 or more after a short development pilot
rows=repmat(struct('missionSeed',0,'uav',0,'plannerSeed',0, ...
    'anytimeSuccess',false,'adaptiveSuccess',false, ...
    'anytimeObjective_m',NaN,'adaptiveObjective_m',NaN, ...
    'gain_pct',NaN,'anytimeWall_s',NaN,'adaptiveWall_s',NaN, ...
    'anytimeFirstIter',NaN,'adaptiveFirstIter',NaN, ...
    'adaptiveTerrainSamples',0,'adaptiveCorridorSamples',0, ...
    'adaptiveShortSteps',0),nMissionSeeds*U,1);
idx=0;
for k=1:nMissionSeeds
    missionSeed=24001+97*(k-1);
    [starts,goals]=mmra_5km_mission(env,U,missionSeed,'cross_center');
    for i=1:U
        idx=idx+1;r=rows(idx);
        localSeed=missionSeed+10007*i;
        r.missionSeed=missionSeed;r.uav=i;r.plannerSeed=localSeed;
        cfgAny=cfg;cfgAny.rrtStopMode='anytime';
        cfgAdapt=cfg;cfgAdapt.rrtStopMode='terrain_adaptive';
        rng(localSeed,'twister');t=tic;
        [pAny,sAny]=mmra_plan_single( ...
            starts(i,:),goals(i,:),env,cfgAny,true);
        r.anytimeWall_s=toc(t);r.anytimeSuccess=sAny.success;
        r.anytimeFirstIter=sAny.firstIter;
        rng(localSeed,'twister');t=tic;
        [pAdapt,sAdapt]=mmra_plan_single( ...
            starts(i,:),goals(i,:),env,cfgAdapt,true);
        r.adaptiveWall_s=toc(t);r.adaptiveSuccess=sAdapt.success;
        r.adaptiveFirstIter=sAdapt.firstIter;
        r.adaptiveTerrainSamples=sAdapt.taTerrainSamples;
        r.adaptiveCorridorSamples=sAdapt.taCorridorSamples;
        r.adaptiveShortSteps=sAdapt.taAdaptedSteps;
        if sAny.success
            assert(mmra_path_free(pAny,env,cfg.guardFineResolution));
            r.anytimeObjective_m=sAny.pathObjective_m;
        end
        if sAdapt.success
            assert(mmra_path_free(pAdapt,env,cfg.guardFineResolution));
            r.adaptiveObjective_m=sAdapt.pathObjective_m;
        end
        if sAny.success && sAdapt.success
            r.gain_pct=100*(sAny.pathObjective_m-sAdapt.pathObjective_m)/ ...
                max(sAny.pathObjective_m,eps);
        end
        rows(idx)=r;
        fprintf('Mission %d/%d, UAV %d/%d: any=%d, adapt=%d, gain=%+.2f%%\n', ...
            k,nMissionSeeds,i,U,sAny.success,sAdapt.success,r.gain_pct);
    end
end
outDir=fullfile(root,'results_rrt_terrain_adaptive_dev');
if ~exist(outDir,'dir'),mkdir(outDir);end
summaryTable=struct2table(rows);
save(fullfile(outDir,'figure2_rrt_terrain_multiseed.mat'), ...
    'summaryTable','rows','cfg','nMissionSeeds','U','-v7');
writetable(summaryTable, ...
    fullfile(outDir,'figure2_rrt_terrain_multiseed.csv'));
valid=[rows.anytimeSuccess] & [rows.adaptiveSuccess];
gains=[rows.gain_pct];
if any(valid)
    fprintf('Paired valid cases=%d/%d, wins=%d, ties=%d, losses=%d\n', ...
        sum(valid),numel(rows),sum(gains(valid)>1e-6), ...
        sum(abs(gains(valid))<=1e-6),sum(gains(valid)<-1e-6));
    fprintf('Mean paired gain=%+.3f%% (NOT a confidence interval)\n', ...
        mean(gains(valid)));
end
fprintf('Successful paths: anytime=%d/%d; adaptive=%d/%d\n', ...
    sum([rows.anytimeSuccess]),numel(rows), ...
    sum([rows.adaptiveSuccess]),numel(rows));
fprintf('Multiseed output: %s\n',outDir);
