%% RUN_URBAN500_MMRA_SAVED_DEMO - fast comparison using archived V3 routes
% No new RRT* search. Source paths were ALREADY random-shortcut-pruned in
% the original V3 result. This demo tests shared MMRA pruning + upgraded
% smoothing on those archived paths, without overwriting the old results.
root=fileparts(mfilename('fullpath'));
addpath(root);
mmraSrc=fullfile(fileparts(fileparts(root)),'src');
assert(exist(fullfile(mmraSrc,'mmra_bezier.m'),'file')==2, ...
    'Keep MMRA src and Urban500 V3 in the supplied full project layout.');
addpath(mmraSrc);
archive=fullfile(root,'results_urban_complex_500_v3_rrtstar', ...
    'Urban500_RRTstar_5U_static.mat');
assert(exist(archive,'file')==2, ...
    'Original V3 MAT archive missing. Run the full 5-UAV planner instead.');
S=load(archive);
scene=S.scene;
cfg=S.cfg;
cfg.mmraPruneMode='shortest_visibility';
cfg.smoothMinRadius_m=10;
cfg.smoothMaxPitch_deg=75;
cfg.smoothTrimFraction=0.44;
cfg.smoothMaxChord_m=2.5;
cfg.smoothMaxSagitta_m=0.10;
cfg.smoothMinAngle_deg=2.0;

inflatedB=scene.buildings_m;
margin=scene.uavSafetyRadius_m+2;
inflatedB=bsxfun(@plus,inflatedB,[-margin margin -margin margin -margin margin]);

originalPaths=S.paths;
paths=cell(5,1);
prunedPaths=cell(5,1);
postprocessStats=cell(5,1);
stages=cell(5,1);
rows=zeros(5,10);
for k=1:5
    [paths{k},stages{k},postprocessStats{k}]= ...
        urban500_mmra_postprocess(originalPaths{k},inflatedB,cfg);
    prunedPaths{k}=stages{k}.pruned;
    p=postprocessStats{k};
    rows(k,:)=[k,p.rawWaypoints,p.prunedWaypoints,p.smoothWaypoints, ...
        p.prunedLength_m,p.smoothLength_m,p.maxAngleBefore_deg, ...
        p.maxAngleAfter_deg,p.roundedCorners,p.totalCorners];
    fprintf(['UAV%d: %d->%d->%d nodes, %d/%d corners, ' ...
        'turn %.1f->%.1f deg, static-AABB=PASS\n'], ...
        k,p.rawWaypoints,p.prunedWaypoints,p.smoothWaypoints, ...
        p.roundedCorners,p.totalCorners,p.maxAngleBefore_deg, ...
        p.maxAngleAfter_deg);
end
outDir=fullfile(root,'results_urban_complex_500_v3_rrtstar_mmra_demo');
if ~exist(outDir,'dir'), mkdir(outDir); end
save(fullfile(outDir,'Urban500_MMRA_saved_demo.mat'), ...
    'scene','cfg','originalPaths','prunedPaths','paths', ...
    'postprocessStats','-v7');
metrics=array2table(rows,'VariableNames', ...
    {'uav','archivedNodes','prunedNodes','smoothNodes', ...
    'prunedLength_m','smoothLength_m','maxTurnPruned_deg', ...
    'maxTurnSmooth_deg','roundedCorners','eligibleCorners'});
writetable(metrics,fullfile(outDir,'Urban500_MMRA_saved_demo_metrics.csv'));
urban500_mmra_comparison_plot(scene,stages, ...
    fullfile(outDir,'Urban500_MMRA_saved_demo_before_after.png'));
fprintf('\nArchived V3 paths reprocessed with MMRA shared modules.\n');
fprintf('Result folder: %s\n',outDir);
fprintf(['NOTE: This FAST demo starts from ALREADY SHORTCUT-PRUNED old ' ...
    'routes, not the raw original RRT* tree paths.\n']);
