function d = urban500_dynamic_shape_distance(q, ob)
%URBAN500_DYNAMIC_SHAPE_DISTANCE Centre-to-solid distance (metres).
% q is UAV centre relative to MOVING OBSTACLE CENTRE in local world axes.
% The cylinder is finite and vertical; box is axis-aligned without rotation.
% A sphere returns signed surface separation (negative when inside).
% For cylinders and boxes, interior distance is zero (collision is detected
% using a strictly positive UAV radius/required clearance).
q = reshape(double(q),1,3);
if isfield(ob,'type') && ~isempty(ob.type)
    typ = lower(char(ob.type));
else
    typ = 'sphere'; % backward compatible V3.1 dynamic obstacle
end
switch typ
    case 'sphere'
        d = norm(q) - ob.radius_m;
    case 'cylinder'
        radial = max(hypot(q(1),q(2)) - ob.radius_m, 0);
        vertical = max(abs(q(3)) - ob.halfHeight_m, 0);
        d = hypot(radial,vertical);
    case 'box'
        e = reshape(double(ob.halfSize_m),1,3);
        d = norm(max(abs(q)-e, 0));
    otherwise
        error('Unknown dynamic obstacle geometry type: %s',typ);
end
end
