function free = urban500_rrtstar_edge_free(p1, p2, boxes)
%URBAN500_RRTSTAR_EDGE_FREE Segment-vs-inflated-AABB collision test.
% boxes rows are [xmin xmax ymin ymax zmin zmax].
% A segment touching an inflated box boundary is treated as collision.

p1 = reshape(double(p1),1,3);
p2 = reshape(double(p2),1,3);
d = p2-p1;
free = true;

for j = 1:size(boxes,1)
    lo = boxes(j,[1 3 5]);
    hi = boxes(j,[2 4 6]);
    tEnter = 0;
    tExit = 1;
    intersects = true;

    for k = 1:3
        if abs(d(k)) < 1e-12
            if p1(k) < lo(k) || p1(k) > hi(k)
                intersects = false;
                break;
            end
        else
            tA = (lo(k)-p1(k))/d(k);
            tB = (hi(k)-p1(k))/d(k);
            tEnter = max(tEnter, min(tA,tB));
            tExit = min(tExit, max(tA,tB));
            if tEnter > tExit
                intersects = false;
                break;
            end
        end
    end

    if intersects && tExit >= 0 && tEnter <= 1
        free = false;
        return;
    end
end
end
