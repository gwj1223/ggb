# Urban Complex 500 m V3 High-Rise — 独立五无人机城市实验环境

## 本版变化

本版在 V2 的基础上提高建筑高度，保留城市平面布局、67 栋建筑数量、5 架无人机任务点、6 个动态球体、道路和广场。V2 的结果目录不会被覆盖。

- 地图：`X=0..500 m, Y=0..500 m, Z=0..200 m`。
- 中心高密度区：建筑高度 `90..170 m`。
- 中间过渡区：建筑高度 `50..115 m`。
- 外围区域：建筑高度 `25..70 m`。
- 建筑数量：固定规则生成 67 栋，XY 足迹不变。
- 无人机：原有 5 个起飞点和 5 个目标点不变。
- 动态障碍：6 个球体的路径、时间和物理半径保持 V2 原值；本版检查脚本按不超过 1 m 的中心位移采样重新检查球体与建筑物的几何净距。
- 建筑配色：按高度映射到 MATLAB `parula(256)`，与之前山体色系统一。

## 运行城市地图

在 MATLAB R2023b 中将当前文件夹切换到本目录，运行：

```matlab
close all
clear functions
run('run_urban_complex_500.m')
```

交互式动态球体播放器：

```matlab
run('run_urban_complex_500_player.m')
```

自动播放：

```matlab
run('run_urban_complex_500_animation.m')
```

场景检查：

```matlab
run('run_urban_complex_500_checks.m')
```

V3 地图结果写入 `results_urban_complex_500_v3`，不会覆盖 V2 的 `results_urban_complex_500`。

## 第一阶段：静态建筑 RRT* 规划

本目录同时包含独立的五无人机 3-D RRT* 扩展文件。先运行自检：

```matlab
run('run_urban500_rrtstar_selftest.m')
```

自检通过后运行：

```matlab
run('run_urban500_rrtstar_5u.m')
```

更新后正式规划结果写入 **`results_urban_complex_500_v3_rrtstar_mmra`**，原有 `results_urban_complex_500_v3_rrtstar` 保留为历史对照。程序会保存原始、剪枝、平滑三阶段路径的 MAT、CSV 和对照图。规划器使用建筑包围盒膨胀（无人机半径 3 m + 额外 2 m）进行静态碰撞检查。

如果 RRT* 在迭代预算内没有找到连接，代码含有经过同一碰撞检查器验证的高空走廊回退路径；输出中的 `method` 字段会区分 `RRTstar` 与 `high_altitude_fallback`，不能把回退路径误报为 RRT* 搜索结果。

## 研究使用的重要边界

- 地图预览不是无人机路径规划结果。
- 当前 RRT* 扩展只处理静态建筑物，不处理 6 个动态球体，也不处理无人机之间的时空冲突。
- 动态球体与建筑的检查是离散采样检查，不是严格的连续时间碰撞证明。
- 原有城市地图和动画不依赖 MMRA；**本次新增的 RRT* 路径后处理**明确依赖同一个完整工程内 `src/mmra_prune.m`、`src/mmra_bezier.m` 与共享适配函数。保持 ZIP 的目录结构即可，无需额外工具箱。
- `scene.buildings_m` 每行格式为 `[xmin xmax ymin ymax zmin zmax]`，单位米。
- `scene.dynamic(k)` 包含 `p0_m`,`p1_m`,`t0_s`,`t1_s`,`radius_m`。

## 文件结构

- `urban500_scene.m`：确定性场景生成器。
- `urban500_draw.m`：Parula 高度配色的三维城市绘图。
- `urban500_obstacle_position.m`：动态球体位置函数。
- `run_urban_complex_500*.m`：地图、检查、播放器和动画入口。
- `urban500_rrtstar_*.m`：RRT*、线段碰撞检测和路径平滑。
- `run_urban500_rrtstar_*.m`：规划入口与自检。

## V3 × MMRA 共享后处理（本次升级）

先运行 `run_urban500_mmra_selftest.m`，再运行 `run_urban500_mmra_saved_demo.m` 即可对比旧五条路径；正式重规划继续运行 `run_urban500_rrtstar_5u.m`。完整说明参见项目根目录 `README_URBAN500_V3_MMRA_平滑升级.md`。
