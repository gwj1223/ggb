function [fig,ax,sphereH] = urban500_draw(scene,t_s,varargin)
%URBAN500_DRAW Draw a standalone 3D city; no route is fabricated.
% Building colors use the MATLAB parula height palette to match the
% terrain colors used in the MMRA mountain-map visualization.
% [fig,ax,h] = urban500_draw(scene, t_s, 'ShowMotionLines',true)

showLines=false;
if ~isempty(varargin)
    p=inputParser;
    addParameter(p,'ShowMotionLines',false,@(v)islogical(v)&&isscalar(v));
    parse(p,varargin{:});
    showLines=p.Results.ShowMotionLines;
end

fig=figure('Name','Urban Complex 500 m V3 High-Rise | scene preview', ...
    'NumberTitle','off','Color','w','Position',[100 60 1420 870]);
ax=axes('Parent',fig,'Position',[0.05 0.10 0.88 0.85]);
hold(ax,'on');

% Ground plane and network of paved roads.
rectangle3(ax,[0 500 0 500],0,[0.93 0.94 0.95]);
for c=65:50:415
    rectangle3(ax,[0 500 c-6.5 c+6.5],0.025,[0.76 0.80 0.83]);
    rectangle3(ax,[c-6.5 c+6.5 0 500],0.025,[0.76 0.80 0.83]);
end
rectangle3(ax,[0 500 254 276],0.035,[0.66 0.71 0.75]);
rectangle3(ax,[254 276 0 500],0.035,[0.66 0.71 0.75]);
rectangle3(ax,[0 500 359 371],0.041,[0.70 0.75 0.77]);
rectangle3(ax,[109 121 0 500],0.041,[0.70 0.75 0.77]);

for j=1:size(scene.plazas,1)
    p=scene.plazas(j,:);
    side=0.95*p(3);
    rectangle3(ax,[p(1)-side p(1)+side p(2)-side p(2)+side], ...
        0.05,[0.71 0.83 0.72]);
end

% Building footprints remain unchanged collision geometry.
% Color each building by height using the same parula palette as the
% mountain terrain: low buildings are blue; taller buildings trend green
% and yellow. Truecolor faces avoid changing the axes colormap.
faces=[1 2 3 4; 5 6 7 8; 1 2 6 5; 2 3 7 6; ...
       3 4 8 7; 4 1 5 8];
B=scene.buildings_m;
heightMin=min(B(:,6));
heightMax=max(B(:,6));
heightSpan=max(heightMax-heightMin,eps);
terrainMap=parula(256);
edgeColor=[0.20 0.25 0.31];

for j=1:size(B,1)
    b=B(j,:);
    x0=b(1);x1=b(2);y0=b(3);y1=b(4);z0=b(5);z1=b(6);
    vertices=[x0 y0 z0;x1 y0 z0;x1 y1 z0;x0 y1 z0; ...
              x0 y0 z1;x1 y0 z1;x1 y1 z1;x0 y1 z1];

    heightNorm=(z1-heightMin)/heightSpan;
    colorIndex=1+round(heightNorm*(size(terrainMap,1)-1));
    fc=terrainMap(colorIndex,:);

    patch('Parent',ax,'Vertices',vertices,'Faces',faces, ...
        'FaceColor',fc,'FaceAlpha',0.96,'EdgeColor',edgeColor, ...
        'EdgeAlpha',0.48,'LineWidth',0.45,'HandleVisibility','off');
end

% The five true start/goal coordinates are retained, but without labels.
for j=1:5
    p=scene.starts_m(j,:);
    plot3(ax,p(1),p(2),p(3),'o','MarkerFaceColor',[0.15 0.67 0.22], ...
        'MarkerEdgeColor','k','MarkerSize',8,'LineWidth',0.8, ...
        'HandleVisibility','off');
    p=scene.goals_m(j,:);
    plot3(ax,p(1),p(2),p(3),'s','MarkerFaceColor',[1.0 0.48 0.10], ...
        'MarkerEdgeColor','k','MarkerSize',8,'LineWidth',0.8, ...
        'HandleVisibility','off');
end

% Render sphere, vertical cylinder, or moving box according to type.
obstacleH=gobjects(numel(scene.dynamic),1);
for k=1:numel(scene.dynamic)
    ob=scene.dynamic(k);
    if showLines
        plot3(ax,[ob.p0_m(1) ob.p1_m(1)], ...
            [ob.p0_m(2) ob.p1_m(2)], ...
            [ob.p0_m(3) ob.p1_m(3)], '--', ...
            'LineWidth',0.7,'Color',[0.58 0.49 0.39], ...
            'HandleVisibility','off');
    end
    obstacleH(k)=urban500_dynamic_draw_handle(ax,ob,t_s);
end
sphereH=obstacleH; % Retain the legacy third output name for callers.

xlabel(ax,'X (m)');ylabel(ax,'Y (m)');zlabel(ax,'Altitude (m)');
xlim(ax,scene.bounds_m(1,:));
ylim(ax,scene.bounds_m(2,:));
zlim(ax,scene.bounds_m(3,:));
daspect(ax,[1 1 1]);axis(ax,'vis3d');
view(ax,39,30);
set(ax,'Projection','orthographic','FontSize',11);
grid(ax,'off');box(ax,'on');
% Enable interactive 3-D mouse rotation
rotate3d(fig,'on');
title(ax,sprintf('Urban500 | %d buildings | %s | t = %.1f s', ...
    size(scene.buildings_m,1),urban500_dynamic_count_label(scene),t_s), ...
    'FontWeight','normal');

end

function rectangle3(ax,rect,z,c)
% Rectangle [xmin xmax ymin ymax] at fixed z.
x=rect([1 2 2 1]);y=rect([3 3 4 4]);
patch('Parent',ax,'XData',x,'YData',y,'ZData',z*ones(1,4), ...
    'FaceColor',c,'EdgeColor','none','HandleVisibility','off');
end
