function ok = urban500_bezier_curve_free(startPoint,controlPoint,endPoint,boxes,maxDepth)
%URBAN500_BEZIER_CURVE_FREE Conservative continuous-curve AABB certificate.
% A quadratic Bezier curve lies in the convex hull of its three controls.
% If the coordinate-wise AABB of that hull misses every inflated building,
% the ENTIRE curve is collision-free. If uncertain, subdivide exactly by
% de Casteljau. Unresolved boxes at maximum depth are conservatively
% rejected (false); never infer clearance from a plot or sparse sampling.
% This certificate covers STATIC inflated buildings ONLY.
if nargin<5 || isempty(maxDepth), maxDepth=15; end
assert(isnumeric(boxes) && size(boxes,2)==6, ...
    'boxes must have 6 columns: xmin xmax ymin ymax zmin zmax.');
assert(maxDepth>=0 && maxDepth==floor(maxDepth));
ctrl=[reshape(startPoint,1,3);reshape(controlPoint,1,3); ...
    reshape(endPoint,1,3)];
if ~all(isfinite(ctrl(:)))
    ok=false; return;
end
ok=checkHull(ctrl,boxes,maxDepth);
end

function ok=checkHull(q,boxes,depth)
if isempty(boxes), ok=true; return; end
lo=min(q,[],1); hi=max(q,[],1);
% Inclusive contact is unsafe. A very small numerical guard prevents
% floating-point rounding at an inflated building boundary being accepted.
margin=1e-10;
possible=(hi(1)>=boxes(:,1)-margin & lo(1)<=boxes(:,2)+margin) & ...
         (hi(2)>=boxes(:,3)-margin & lo(2)<=boxes(:,4)+margin) & ...
         (hi(3)>=boxes(:,5)-margin & lo(3)<=boxes(:,6)+margin);
if ~any(possible)
    ok=true; return;
end
if depth==0
    ok=false; return;
end
% Exact de Casteljau subdivision at t=0.5, preserving the same curve.
a=(q(1,:)+q(2,:))/2;
b=(q(2,:)+q(3,:))/2;
m=(a+b)/2;
nearby=boxes(possible,:);
ok=checkHull([q(1,:);a;m],nearby,depth-1) && ...
   checkHull([m;b;q(3,:)],nearby,depth-1);
end
