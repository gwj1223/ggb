%% RUN_URBAN500_INTERUAV_SELFTEST - synthetic continuous-time cases.
root=fileparts(mfilename('fullpath'));
addpath(root);
% Same-time crossing, crossing point at (0,0,30): exact collision.
A=makeTraj([-20 0 30;20 0 30],[0;4]);
B=makeTraj([0 -20 30;0 20 30],[0;4]);
[ok,d]=urban500_interuav_pair_check(A,B,10);
assert(~ok&&d.minDistance_m<1e-9&&abs(d.criticalTime_s-2)<1e-7, ...
    'The exact simultaneous crossing must be detected.');
% A launch delay must be evaluated together with held start and end pads.
B2=makeTraj([0 -20 30;0 -20 30;0 20 30],[0;3;7]);
[ok,d]=urban500_interuav_pair_check(A,B2,10);
assert(ok&&d.minDistance_m>=10,'Delayed crossing was not accepted.');
% Collisions after first vehicle arrives must not be missed.
C=makeTraj([0 0 30;10 0 30],[0;1]);
D=makeTraj([30 0 30;10 0 30],[0;3]);
[ok,~]=urban500_interuav_pair_check(C,D,10);
assert(~ok,'Held destination collision was not detected.');
% Vertical 3D separation counts; XY crossing alone is not a collision.
B3=makeTraj([0 -20 50;0 20 50],[0;4]);
[ok,d]=urban500_interuav_pair_check(A,B3,10);
assert(ok&&d.minDistance_m>=20-1e-8, ...
    'The 3D crossing vertical separation must be preserved.');
% Joint coordinator must fix the unscheduled crossing without violating
% dynamic solids (empty in this focused pairwise synthetic test).
sc=struct();sc.dynamic=[];
paths={A.positions_m;B.positions_m};
opt=struct('dynamicRequiredClearance_m',5, ...
    'interUAVRequiredSeparation_m',10, ...
    'coordinationSpeeds_mps',10, ...
    'coordinationDepartureStep_s',1, ...
    'coordinationMaxDeparture_s',12);
[scheduled,stat]=urban500_interuav_coordinate(paths,{A;B},sc,opt);
assert(stat.success,'Coordinator could not resolve two-vehicle crossing.');
audit=urban500_interuav_audit(scheduled,10,false);
assert(audit.success&&audit.minSeparation_m>=10-1e-8, ...
    'Coordinated crossing failed independent pairwise audit.');
fprintf('Urban500 inter-UAV continuous-time and coordination self-test PASSED.\n');

function tr=makeTraj(P,T)
tr=struct('positions_m',P,'times_s',T(:), ...
    'departure_s',0,'arrival_s',T(end),'speed_mps',10, ...
    'localWaitCount',0,'localWaitTime_s',0, ...
    'pathLength_m',sum(vecnorm(diff(P,1,1),2,2)));
end
