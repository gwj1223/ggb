%% RUN_URBAN500_DYNAMIC_MIXED_SELFTEST - All three dynamic solid types.
root=fileparts(mfilename('fullpath'));
addpath(root);
run(fullfile(root,'run_urban500_mixed_dynamic_checks.m'));
base=urban500_scene_mixed_dynamic();
ob=base.dynamic(1);
ob.type='sphere';ob.radius_m=2;ob.p0_m=[0 -10 0];
ob.p1_m=[0 10 0];ob.t0_s=0;ob.t1_s=10;
[ok,d]=urban500_dynamic_segment_check([0 0 0],[0 0 0],0,10,ob,1);
assert(~ok && d.minMargin_m < -2.9, ...
    'Sphere collision should be detected even when UAV hovers.');
[ok,~]=urban500_dynamic_segment_check([12 0 0],[12 0 0],0,10,ob,1);
assert(ok,'Distant fixed point should be safe from sphere.');
ob.type='cylinder';ob.radius_m=3;ob.halfHeight_m=5;
ob.p0_m=[0 0 0];ob.p1_m=[0 0 0];
[ok,~]=urban500_dynamic_segment_check([-10 0 0],[10 0 0],0,10,ob,1);
assert(~ok,'Moving segment through cylinder must be rejected.');
[ok,~]=urban500_dynamic_segment_check([-10 0 15],[10 0 15],0,10,ob,1);
assert(ok,'Segment above cylinder must pass.');
ob.type='box';ob.halfSize_m=[3 4 5];
[ok,~]=urban500_dynamic_segment_check([-10 0 0],[10 0 0],0,10,ob,1);
assert(~ok,'Moving segment through a box must be rejected.');
[ok,~]=urban500_dynamic_segment_check([-10 20 0],[10 20 0],0,10,ob,1);
assert(ok,'Segment away from a box must pass.');
% Timing matters: same exact XY space can be safe if objects arrive later.
ob.type='sphere';ob.radius_m=1;ob.p0_m=[0 0 0];
ob.p1_m=[0 0 0];ob.t0_s=0;ob.t1_s=10;
[ok,~]=urban500_dynamic_segment_check([-10 0 0],[10 0 0],0,10,ob,2);
assert(~ok,'Unscheduled crossing should collide.');
% Create a temporal blockage that must be avoided by delaying launch.
sc=base;
sc.dynamic=ob;
sc.uavSafetyRadius_m=1;
cfg=struct('dynamicRequiredClearance_m',2, ...
    'dynamicSpeeds_mps',4,'dynamicDepartureStep_s',2, ...
    'dynamicMaxDeparture_s',14,'dynamicLocalWaitStep_s',1, ...
    'dynamicMaxLocalWait_s',10,'dynamicMaxTotalWait_s',12);
% Obstacle static at origin makes any traversal impossible, including
% delayed launch. This must be reported as failure, never falsely accepted.
[traj,stat]=urban500_dynamic_schedule([-10 0 0;10 0 0],sc,cfg); %#ok<ASGLU>
assert(~stat.success,'Permanent blocker should not be bypassed in time.');
% Moving blocker crosses the path only in the first few seconds; a delayed
% launch or certified wait makes the same static path safely traversable.
sc.dynamic.p0_m=[0 -10 0];sc.dynamic.p1_m=[0 10 0];
sc.dynamic.t0_s=0;sc.dynamic.t1_s=5;
[traj,stat]=urban500_dynamic_schedule([-10 0 0;10 0 0],sc,cfg);
assert(stat.success,'Scheduler should avoid moving blocker.');
[ok,~]=urban500_dynamic_path_check(traj.positions_m, ...
    traj.times_s,sc,cfg.dynamicRequiredClearance_m,false);
assert(ok,'Final timed route was not independently verified.');
% Reuse original archived V3 five actual spatial trajectories as a fixed
% historical regression fixture. These are NOT the newest MMRA smoothed
% trajectories; the full new run uses the newest radius-repair MAT.
arch=fullfile(root,'results_urban_complex_500_v3_rrtstar', ...
    'Urban500_RRTstar_5U_static.mat');
if exist(arch,'file')==2
    old=load(arch,'paths');
    opts=struct('dynamicRequiredClearance_m',5, ...
        'dynamicSpeeds_mps',[11 9 7], ...
        'dynamicDepartureStep_s',2, 'dynamicMaxDeparture_s',60, ...
        'dynamicLocalWaitStep_s',1, ...
        'dynamicMaxLocalWait_s',40,'dynamicMaxTotalWait_s',120);
    fixedScene=urban500_scene_mixed_dynamic();
    for k=1:5
        [tr,st]=urban500_dynamic_schedule(old.paths{k},fixedScene,opts);
        assert(st.success,'Archived real UAV%d cannot find safe schedule.',k);
        [ok,~]=urban500_dynamic_path_check(tr.positions_m, ...
            tr.times_s,fixedScene,opts.dynamicRequiredClearance_m,false);
        assert(ok,'Archived UAV%d dynamic verification failed.',k);
        fprintf('Archived UAV%d: baseline conflicts=%d, depart=%.1f s, arrival=%.1f s\n', ...
            k,st.baselineConflictingSegments,tr.departure_s,tr.arrival_s);
    end
end
fprintf('Urban500 mixed dynamic geometry / schedule self-test PASSED.\n');
