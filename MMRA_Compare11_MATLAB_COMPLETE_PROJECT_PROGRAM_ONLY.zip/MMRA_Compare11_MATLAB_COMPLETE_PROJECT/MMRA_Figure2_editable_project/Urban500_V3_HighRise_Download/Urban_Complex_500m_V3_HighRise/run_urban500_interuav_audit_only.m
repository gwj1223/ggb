%% RUN_URBAN500_INTERUAV_AUDIT_ONLY - No changes to original schedules.
root=fileparts(mfilename('fullpath'));
addpath(root);
inputFile=fullfile(root,'results_urban_complex_500_v3_dynamic_mixed', ...
    'Urban500_RRTstar_5U_dynamic_mixed.mat');
assert(exist(inputFile,'file')==2, ...
    'Run run_urban500_dynamic_mixed_5u.m first to generate timed paths.');
R=load(inputFile,'scene','opts','timedPaths');
% Same two-sided margin as the 10 m MMRA aircraft separation convention.
dSafe=2*R.opts.dynamicRequiredClearance_m;
fprintf('\n=== URBAN500 five-UAV CONTINUOUS-TIME PAIR AUDIT ===\n');
fprintf('Aircraft minimum centre spacing = %.2f m.\n',dSafe);
audit=urban500_interuav_audit(R.timedPaths,dSafe,true);
if audit.success
    fprintf('PASS: no inter-UAV conflicts in the saved timed polylines.\n');
else
    fprintf(['FOUND %d unsafe UAV pairs. To adjust launch times, run ' ...
        'run_urban500_interuav_5u.m.\n'],audit.conflictPairs);
end
