function run_urban500_interuav_player()
%RUN_URBAN500_DYNAMIC_MIXED_PLAYER Show 6 spheres, 2 cylinders, 2 boxes.
% Also animates FIVE jointly coordinated UAVs if new MAT exists.
% This visualization is based on certified segment-wise timed trajectories,
% not interpolation of arbitrary static routes with invented flight times.
root=fileparts(mfilename('fullpath'));
addpath(root);
file=fullfile(root,'results_urban_complex_500_v3_interuav', ...
    'Urban500_5U_joint_timed.mat');
if exist(file,'file')==2
    d=load(file,'scene','coordinatedTimedPaths','paths');
    scene=d.scene;
    timedPaths=d.coordinatedTimedPaths;
    paths=d.paths;
    limit=max(scene.duration_s,ceil(max(cellfun(@(x)x.arrival_s,timedPaths))+5));
    fprintf('Dynamic results loaded: %s\n',file);
else
    scene=urban500_scene_mixed_dynamic();
    timedPaths={};
    paths={};
    limit=scene.duration_s;
    fprintf('No coordinated route MAT: displaying mixed moving scene only.\n');
end
[fig,ax,h]=urban500_draw(scene,0,'ShowMotionLines',true);
set(fig,'Name','Urban500 V3.3 | mixed obstacles + jointly timed UAVs');
set(ax,'Position',[0.055 0.15 0.84 0.80]);
uavMarkers=gobjects(numel(timedPaths),1);
routeHandles=gobjects(numel(paths),1);
for k=1:numel(paths)
    p=paths{k};c=scene.routeColors(k,:);
    routeHandles(k)=plot3(ax,p(:,1),p(:,2),p(:,3),'-', ...
        'Color',c,'LineWidth',1.9, ...
        'DisplayName',sprintf('UAV %d',k));
    uavMarkers(k)=plot3(ax,NaN,NaN,NaN,'o', ...
        'MarkerSize',11,'MarkerFaceColor',c, ...
        'MarkerEdgeColor','k','LineWidth',1.0, ...
        'HandleVisibility','off');
end
if ~isempty(routeHandles),legend(ax,routeHandles,'Location','eastoutside');end
sld=uicontrol('Parent',fig,'Style','slider','Units','normalized', ...
    'Position',[0.16 0.055 0.65 0.036], ...
    'Min',0,'Max',limit,'Value',0, ...
    'SliderStep',[1/max(limit,1),10/max(limit,1)], ...
    'Callback',@sliderChanged);
btn=uicontrol('Parent',fig,'Style','togglebutton','String','PLAY', ...
    'Units','normalized','Position',[0.035 0.046 0.09 0.050], ...
    'Callback',@togglePlay);
txt=uicontrol('Parent',fig,'Style','text','String','t = 0.0 s', ...
    'BackgroundColor','w','Units','normalized', ...
    'Position',[0.83 0.05 0.12 0.042],'FontSize',11);
playing=false;
updateAt(0);
    function sliderChanged(src,~)
        updateAt(get(src,'Value'));
    end
    function togglePlay(src,~)
        playing=logical(get(src,'Value'));
        if ~playing
            set(src,'String','PLAY');return;
        end
        set(src,'String','STOP');
        if get(sld,'Value')>=limit,set(sld,'Value',0);end
        while playing && isgraphics(fig)
            t=get(sld,'Value');
            if t>=limit,break;end
            t=min(limit,t+0.5);
            set(sld,'Value',t);
            updateAt(t);
            drawnow;
            pause(0.025);
        end
        playing=false;
        if isgraphics(btn),set(btn,'Value',0,'String','PLAY');end
    end
    function updateAt(t)
        if ~isgraphics(fig),return;end
        for i=1:numel(scene.dynamic)
            urban500_dynamic_update_handle(h(i),scene.dynamic(i),t);
        end
        for j=1:numel(timedPaths)
            tr=timedPaths{j};
            if t>tr.arrival_s
                set(uavMarkers(j),'Visible','off');
            else
                pos=positionAt(tr.positions_m,tr.times_s,t);
                set(uavMarkers(j),'XData',pos(1), ...
                    'YData',pos(2),'ZData',pos(3),'Visible','on');
            end
        end
        if isgraphics(txt),set(txt,'String',sprintf('t = %.1f s',t));end
        title(ax,sprintf('Urban500 mixed dynamic scene | %s | t=%.1f s', ...
            urban500_dynamic_count_label(scene),t), ...
            'FontWeight','normal');
        drawnow limitrate;
    end
end

function p=positionAt(P,T,t)
if t<=T(1),p=P(1,:);return;end
if t>=T(end),p=P(end,:);return;end
j=find(T<=t,1,'last');
j=min(j,numel(T)-1);
dt=T(j+1)-T(j);
if dt<=1e-12
    p=P(j+1,:);return;
end
a=(t-T(j))/dt;
p=(1-a)*P(j,:)+a*P(j+1,:);
end
