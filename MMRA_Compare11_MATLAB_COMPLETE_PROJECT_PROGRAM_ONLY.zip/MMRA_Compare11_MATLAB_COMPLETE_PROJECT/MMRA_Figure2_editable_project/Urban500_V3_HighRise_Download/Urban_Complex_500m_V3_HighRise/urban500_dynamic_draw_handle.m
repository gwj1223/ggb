function h = urban500_dynamic_draw_handle(ax, ob, t_s)
%URBAN500_DYNAMIC_DRAW_HANDLE Create a visual with reusable local geometry.
if isfield(ob,'type') && ~isempty(ob.type)
    typ = lower(char(ob.type));
else
    typ = 'sphere';
end
switch typ
    case 'sphere'
        [x,y,z] = sphere(22);
        local = {ob.radius_m*x,ob.radius_m*y,ob.radius_m*z};
        h = surf(ax,local{1},local{2},local{3}, ...
            'FaceColor',[1.00 0.70 0.25],'EdgeColor',[0.50 0.20 0.06], ...
            'FaceAlpha',0.94,'EdgeAlpha',0.5,'LineWidth',0.28, ...
            'HandleVisibility','off');
        set(h,'UserData',struct('kind','surf','xyz',{local}));
    case 'cylinder'
        theta = linspace(0,2*pi,33);
        u = cos(theta);v = sin(theta);
        r = ob.radius_m;
        h2 = ob.halfHeight_m;
        % Four closed rings: bottom centre, bottom rim, top rim, top centre.
        x = r*[zeros(size(u)); u; u; zeros(size(u))];
        y = r*[zeros(size(v)); v; v; zeros(size(v))];
        z = repmat([-h2;-h2;h2;h2],1,numel(theta));
        local = {x,y,z};
        h = surf(ax,x,y,z,'FaceColor',[0.18 0.79 0.84], ...
            'EdgeColor',[0.05 0.32 0.38],'FaceAlpha',0.91, ...
            'EdgeAlpha',0.30,'LineWidth',0.35,'HandleVisibility','off');
        set(h,'UserData',struct('kind','surf','xyz',{local}));
    case 'box'
        e = reshape(ob.halfSize_m,1,3);
        local = [-e(1) -e(2) -e(3); e(1) -e(2) -e(3); ...
            e(1) e(2) -e(3); -e(1) e(2) -e(3); ...
            -e(1) -e(2) e(3); e(1) -e(2) e(3); ...
            e(1) e(2) e(3); -e(1) e(2) e(3)];
        faces = [1 2 3 4;5 6 7 8;1 2 6 5;2 3 7 6;3 4 8 7;4 1 5 8];
        h = patch('Parent',ax,'Vertices',local,'Faces',faces, ...
            'FaceColor',[0.94 0.40 0.68],'EdgeColor',[0.50 0.15 0.32], ...
            'FaceAlpha',0.90,'LineWidth',0.6,'HandleVisibility','off');
        set(h,'UserData',struct('kind','patch','vertices',local));
    otherwise
        error('Unsupported dynamic obstacle type: %s',typ);
end
urban500_dynamic_update_handle(h,ob,t_s);
end
