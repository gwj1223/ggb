function audit = urban500_interuav_audit(timedPaths,required_m,verbose)
%URBAN500_INTERUAV_AUDIT Continuous-time pairwise safety audit for all UAVs.
if nargin<2,required_m=10;end
if nargin<3,verbose=true;end
assert(iscell(timedPaths)&&numel(timedPaths)>=2);
N=numel(timedPaths);
pairs=repmat(struct('i',0,'j',0,'safe',false,'minDistance_m',NaN, ...
    'minMargin_m',NaN,'criticalTime_s',NaN),N*(N-1)/2,1);
count=0;conflicts=0;minDistance=inf;minPair=[NaN NaN];
for i=1:N-1
    for j=i+1:N
        count=count+1;
        [ok,d]=urban500_interuav_pair_check( ...
            timedPaths{i},timedPaths{j},required_m);
        pairs(count)=struct('i',i,'j',j,'safe',ok, ...
            'minDistance_m',d.minDistance_m,'minMargin_m',d.minMargin_m, ...
            'criticalTime_s',d.criticalTime_s);
        conflicts=conflicts+double(~ok);
        if d.minDistance_m<minDistance
            minDistance=d.minDistance_m;minPair=[i,j];
        end
        if verbose
            fprintf('UAV%d-UAV%d: dMin=%.3f m, t=%.2f s | %s\n', ...
                i,j,d.minDistance_m,d.criticalTime_s,ternary(ok,'PASS','CONFLICT'));
        end
    end
end
audit=struct('success',conflicts==0,'conflictPairs',conflicts, ...
    'minSeparation_m',minDistance,'requiredSeparation_m',required_m, ...
    'minPair',minPair,'pairs',pairs);
if verbose
    fprintf('INTER-UAV: %d/%d pairs safe | minimum %.3f m | required %.3f m\n', ...
        count-conflicts,count,minDistance,required_m);
end
end

function x=ternary(test,a,b)
if test,x=a;else,x=b;end
end
