%% RUN_URBAN_COMPLEX_500_CHECKS - Validate Urban500 V3 high-rise geometry.
% Always rebuild the scene so a stale workspace variable cannot mask fields
% or parameters from the current urban500_scene.m file.
root=fileparts(mfilename('fullpath'));
addpath(root);
scene=urban500_scene();

B=scene.buildings_m;
bounds=scene.bounds_m;
assert(size(B,2)==6 && size(B,1)==67, ...
    'Expected 67 buildings in the V3 scene.');
assert(all(B(:,2)>B(:,1)) && all(B(:,4)>B(:,3)) && ...
    all(B(:,6)>B(:,5)),'Malformed building box.');
assert(all(B(:,1)>bounds(1,1)) && all(B(:,2)<bounds(1,2)) && ...
    all(B(:,3)>bounds(2,1)) && all(B(:,4)<bounds(2,2)) && ...
    all(B(:,5)>=bounds(3,1)) && all(B(:,6)<bounds(3,2)), ...
    'A building exceeds city bounds.');

% Check the three intended height bands using each building's radial zone.
for j=1:size(B,1)
    cx=0.5*(B(j,1)+B(j,2));
    cy=0.5*(B(j,3)+B(j,4));
    d=hypot(cx-250,cy-250);
    h=B(j,6);
    if d<150
        assert(h>=90-1e-9 && h<=170+1e-9, ...
            'Core building %d is outside the 90-170 m band.',j);
    elseif d<230
        assert(h>=50-1e-9 && h<=115+1e-9, ...
            'Transition building %d is outside the 50-115 m band.',j);
    else
        assert(h>=25-1e-9 && h<=70+1e-9, ...
            'Outer building %d is outside the 25-70 m band.',j);
    end
end

pts=[scene.starts_m;scene.goals_m];
assert(all(pts(:,1)>=bounds(1,1) & pts(:,1)<=bounds(1,2)) && ...
       all(pts(:,2)>=bounds(2,1) & pts(:,2)<=bounds(2,2)) && ...
       all(pts(:,3)>=bounds(3,1) & pts(:,3)<=bounds(3,2)), ...
       'A mission endpoint is outside city bounds.');
for i=1:size(pts,1)
    p=pts(i,:);
    for j=1:size(B,1)
        b=B(j,:);
        dx=max([b(1)-p(1),0,p(1)-b(2)]);
        dy=max([b(3)-p(2),0,p(2)-b(4)]);
        dz=max([b(5)-p(3),0,p(3)-b(6)]);
        assert(sqrt(dx^2+dy^2+dz^2)>scene.uavSafetyRadius_m+2, ...
            'Mission start/goal overlaps a building.');
    end
end

for i=1:5
    for j=i+1:5
        assert(norm(scene.starts_m(i,:)-scene.starts_m(j,:))>= ...
            scene.minimumPadSpacing_m-1e-9,'Launch pads too close.');
    end
end

% Sample every sphere path at <=1 m centre displacement. This is a sampled
% geometric check, not a formal continuous-time collision proof.
minClearance=inf;
for k=1:numel(scene.dynamic)
    ob=scene.dynamic(k);
    assert(ob.t1_s>ob.t0_s);
    assert(abs(ob.p0_m(3)-ob.p1_m(3))<1e-9, ...
        'Sphere %d must keep a constant altitude on its current track.',k);
    assert(ob.p0_m(3)>=80 && ob.p0_m(3)<=160, ...
        'Sphere %d altitude is not in the elevated 80-160 m band.',k);
    travel=norm(ob.p1_m-ob.p0_m);
    nSamples=max(101,ceil(travel/1.0)+1);
    for a=linspace(0,1,nSamples)
        t=(1-a)*ob.t0_s+a*ob.t1_s;
        p=urban500_obstacle_position(ob,t);
        assert(all(p(1:2)>ob.radius_m) && ...
            all(p(1:2)<500-ob.radius_m) && ...
            p(3)-ob.radius_m>=bounds(3,1) && ...
            p(3)+ob.radius_m<=bounds(3,2), ...
            'Moving sphere %d exceeds city bounds.',k);
        for j=1:size(B,1)
            b=B(j,:);
            dx=max([b(1)-p(1),0,p(1)-b(2)]);
            dy=max([b(3)-p(2),0,p(2)-b(4)]);
            dz=max([b(5)-p(3),0,p(3)-b(6)]);
            clearance=sqrt(dx^2+dy^2+dz^2)-ob.radius_m;
            minClearance=min(minClearance,clearance);
            assert(clearance>1.0, ...
                'Moving sphere %d intersects building %d.',k,j);
        end
    end
end

% Check moving-sphere separation over the full animation interval.
% This is a dense sampled check, not a formal continuous-time proof.
minSpherePairClearance=inf;
for t=linspace(0,scene.duration_s,2001)
    centresNow=zeros(numel(scene.dynamic),3);
    radiiNow=zeros(numel(scene.dynamic),1);
    for k=1:numel(scene.dynamic)
        centresNow(k,:)=urban500_obstacle_position(scene.dynamic(k),t);
        radiiNow(k)=scene.dynamic(k).radius_m;
    end
    for i=1:numel(scene.dynamic)-1
        for j=i+1:numel(scene.dynamic)
            gap=norm(centresNow(i,:)-centresNow(j,:))-radiiNow(i)-radiiNow(j);
            minSpherePairClearance=min(minSpherePairClearance,gap);
        end
    end
end
assert(minSpherePairClearance>5.0, ...
    'Two moving spheres approach closer than the 5 m surface-clearance limit.');

fprintf(['Urban500 V3.1 checks PASSED: %d high-rise buildings, ' ...
    '5 starts, 5 goals, %d elevated moving spheres.\n'], ...
    size(B,1),numel(scene.dynamic));
fprintf('Building height range: %.1f to %.1f m.\n', ...
    min(B(:,6)),max(B(:,6)));
fprintf(['Minimum sphere-to-building clearance on <=1 m sampled tracks: ' ...
    '%.2f m.\n'],minClearance);
fprintf(['Minimum sphere-to-sphere surface clearance on 2001 time samples: ' ...
    '%.2f m.\n'],minSpherePairClearance);
