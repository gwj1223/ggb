function s = urban500_dynamic_count_label(scene)
%URBAN500_DYNAMIC_COUNT_LABEL Short, accurate obstacle counts for scene UI.
a=0;b=0;c=0;
for k=1:numel(scene.dynamic)
    if isfield(scene.dynamic,'type') && ~isempty(scene.dynamic(k).type)
        typ=lower(char(scene.dynamic(k).type));
    else
        typ='sphere';
    end
    switch typ
        case 'sphere', a=a+1;
        case 'cylinder', b=b+1;
        case 'box', c=c+1;
    end
end
s=sprintf('%d spheres, %d cylinders, %d boxes',a,b,c);
end
