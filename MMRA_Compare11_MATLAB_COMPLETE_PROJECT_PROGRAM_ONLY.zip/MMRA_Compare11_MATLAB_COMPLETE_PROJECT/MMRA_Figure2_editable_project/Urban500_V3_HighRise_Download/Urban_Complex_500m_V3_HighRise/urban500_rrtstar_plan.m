function [path, info] = urban500_rrtstar_plan(startPoint, goalPoint, boxes, cfg, seed)
%URBAN500_RRTSTAR_PLAN 3-D RRT* for axis-aligned static building boxes.
% boxes are already inflated by the required centreline clearance.
% No toolbox is required.

startPoint = reshape(double(startPoint),1,3);
goalPoint = reshape(double(goalPoint),1,3);
assert(all(isfinite(startPoint)) && all(isfinite(goalPoint)));
assert(all(startPoint >= cfg.bounds_m(:,1)') && ...
    all(startPoint <= cfg.bounds_m(:,2)'));
assert(all(goalPoint >= cfg.bounds_m(:,1)') && ...
    all(goalPoint <= cfg.bounds_m(:,2)'));

rng(seed, 'twister');
timerStart = tic;
path = [];
info = struct('method','failed','iterations',0,'nodeCount',1, ...
    'firstSolutionIteration',NaN,'goalCost',Inf,'planningTime_s',NaN);

if ~urban500_rrtstar_edge_free(startPoint, startPoint, boxes) || ...
        ~urban500_rrtstar_edge_free(goalPoint, goalPoint, boxes)
    info.planningTime_s = toc(timerStart);
    return;
end

% A clear direct segment is already the shortest possible path.
if urban500_rrtstar_edge_free(startPoint, goalPoint, boxes)
    path = [startPoint; goalPoint];
    info.method = 'direct_clear';
    info.iterations = 0;
    info.nodeCount = 1;
    info.goalCost = norm(goalPoint-startPoint);
    info.planningTime_s = toc(timerStart);
    return;
end

maxNodes = cfg.maxIterations + 1;
nodes = zeros(maxNodes,3);
parent = zeros(maxNodes,1);
cost = inf(maxNodes,1);
children = cell(maxNodes,1);
nodes(1,:) = startPoint;
parent(1) = 0;
cost(1) = 0;
n = 1;
firstSolutionIteration = NaN;

for iter = 1:cfg.maxIterations
    % Mixture sampling: goal bias, high-altitude bias, and uniform samples.
    u = rand();
    if u < cfg.goalBias
        qRand = goalPoint;
    elseif u < cfg.goalBias + cfg.highAltitudeBias
        qRand = [ ...
            cfg.bounds_m(1,1) + rand()*diff(cfg.bounds_m(1,:)), ...
            cfg.bounds_m(2,1) + rand()*diff(cfg.bounds_m(2,:)), ...
            cfg.highAltitudeRange_m(1) + rand()*diff(cfg.highAltitudeRange_m)];
    else
        qRand = [ ...
            cfg.bounds_m(1,1) + rand()*diff(cfg.bounds_m(1,:)), ...
            cfg.bounds_m(2,1) + rand()*diff(cfg.bounds_m(2,:)), ...
            cfg.bounds_m(3,1) + rand()*diff(cfg.bounds_m(3,:))];
    end

    delta = nodes(1:n,:) - qRand;
    d2 = sum(delta.^2,2);
    [~, nearest] = min(d2);
    direction = qRand - nodes(nearest,:);
    distance = norm(direction);
    if distance < 1e-9
        continue;
    end
    qNew = nodes(nearest,:) + direction * ...
        (min(cfg.maxStep_m,distance)/distance);

    if ~urban500_rrtstar_edge_free(nodes(nearest,:), qNew, boxes)
        continue;
    end

    % RRT* neighbourhood radius in 3-D, clamped for practical finite runs.
    radius = cfg.neighborGamma_m * ...
        (log(n+1)/(n+1))^(1/3);
    radius = min(cfg.neighborRadiusMax_m, ...
        max(cfg.neighborRadiusMin_m, radius));
    deltaNew = nodes(1:n,:) - qNew;
    distNew = sqrt(sum(deltaNew.^2,2));
    near = find(distNew <= radius);
    if ~any(near == nearest)
        near(end+1,1) = nearest;
    end

    % Choose the lowest-cost collision-free parent.
    bestParent = nearest;
    bestCost = cost(nearest) + norm(qNew-nodes(nearest,:));
    for ii = 1:numel(near)
        j = near(ii);
        candidateCost = cost(j) + distNew(j);
        if candidateCost + 1e-10 < bestCost && ...
                urban500_rrtstar_edge_free(nodes(j,:), qNew, boxes)
            bestParent = j;
            bestCost = candidateCost;
        end
    end

    % Insert the new node.
    n = n + 1;
    nodes(n,:) = qNew;
    parent(n) = bestParent;
    cost(n) = bestCost;
    children{bestParent}(end+1) = n;

    % Rewire nearby nodes through the new node when cost improves.
    for ii = 1:numel(near)
        j = near(ii);
        if j == 1 || j == bestParent
            continue;
        end
        candidateCost = bestCost + norm(nodes(j,:)-qNew);
        if candidateCost + 1e-10 < cost(j) && ...
                urban500_rrtstar_edge_free(qNew, nodes(j,:), boxes)
            oldParent = parent(j);
            oldChildren = children{oldParent};
            children{oldParent} = oldChildren(oldChildren ~= j);
            parent(j) = n;
            children{n}(end+1) = j;

            deltaCost = candidateCost - cost(j);
            cost(j) = candidateCost;
            % Update all descendant costs after changing this parent.
            stack = children{j};
            while ~isempty(stack)
                child = stack(end);
                stack(end) = [];
                cost(child) = cost(child) + deltaCost;
                if ~isempty(children{child})
                    stack = [stack children{child}]; %#ok<AGROW>
                end
            end
        end
    end

    % Stop a fixed number of iterations after the first feasible solution.
    if isnan(firstSolutionIteration) && ...
            norm(qNew-goalPoint) <= cfg.goalConnectRadius_m && ...
            urban500_rrtstar_edge_free(qNew, goalPoint, boxes)
        firstSolutionIteration = iter;
    end
    if ~isnan(firstSolutionIteration) && ...
            iter >= firstSolutionIteration + cfg.maxIterationsAfterFirstSolution
        break;
    end
end

% Re-evaluate all goal connections because rewiring may have reduced costs.
bestGoalParent = 0;
bestGoalCost = Inf;
for j = 1:n
    dGoal = norm(nodes(j,:)-goalPoint);
    if dGoal <= cfg.goalConnectRadius_m && ...
            cost(j)+dGoal < bestGoalCost && ...
            urban500_rrtstar_edge_free(nodes(j,:), goalPoint, boxes)
        bestGoalParent = j;
        bestGoalCost = cost(j)+dGoal;
    end
end

if bestGoalParent > 0
    chain = zeros(n,1);
    count = 0;
    idx = bestGoalParent;
    while idx ~= 1
        count = count + 1;
        if count > n
            error('RRT* parent chain contains a cycle.');
        end
        chain(count) = idx;
        idx = parent(idx);
        if idx < 1 || idx > n
            error('RRT* parent index is invalid.');
        end
    end
    path = [startPoint; nodes(chain(count:-1:1),:); goalPoint];
    path = removeDuplicateRows(path);
    info.method = 'RRTstar';
    info.goalCost = bestGoalCost;
else
    % Conservative fallback: climb above the tallest inflated building,
    % cruise over the city, then descend at the checked goal location.
    cruiseZ = min(cfg.bounds_m(3,2)-1, max(boxes(:,6))+3);
    candidate = [startPoint; startPoint(1:2) cruiseZ; ...
        goalPoint(1:2) cruiseZ; goalPoint];
    candidate = removeDuplicateRows(candidate);
    clearPath = true;
    for j = 1:size(candidate,1)-1
        if ~urban500_rrtstar_edge_free(candidate(j,:),candidate(j+1,:),boxes)
            clearPath = false;
            break;
        end
    end
    if clearPath
        path = candidate;
        info.method = 'high_altitude_fallback';
        info.goalCost = sum(sqrt(sum(diff(path,1,1).^2,2)));
    end
end

info.iterations = iter;
info.nodeCount = n;
info.firstSolutionIteration = firstSolutionIteration;
info.planningTime_s = toc(timerStart);
end

function P = removeDuplicateRows(P)
if size(P,1) < 2
    return;
end
keep = [true; any(abs(diff(P,1,1)) > 1e-10,2)];
P = P(keep,:);
end
