%% RUN_URBAN500_INTERUAV_5U - Verified 5-UAV offline joint timetable.
% New V3.3 experiment: built ON TOP of certified V3.2 mixed-dynamic output.
% Does not modify the original RRT* routes, buildings, or moving obstacles.
% Checks dynamic solids AND inter-UAV separation on each temporal candidate.
% This script is NOT online replanning or a physical-flight certificate.
root=fileparts(mfilename('fullpath'));
addpath(root);
inputFile=fullfile(root,'results_urban_complex_500_v3_dynamic_mixed', ...
    'Urban500_RRTstar_5U_dynamic_mixed.mat');
assert(exist(inputFile,'file')==2, ...
    'Missing V3.2 time-planned MAT: run run_urban500_dynamic_mixed_5u.m.');
R=load(inputFile,'scene','opts','paths','timedPaths');
scene=R.scene;
assert(numel(R.paths)==5&&numel(R.timedPaths)==5, ...
    'Expected five V3.2 trajectories.');
assert(numel(scene.dynamic)==10,'Mixed obstacle scenario is not the V3.2 ten-solid scene.');
opts=R.opts;
assert(isfield(opts,'dynamicRequiredClearance_m'));
opts.interUAVRequiredSeparation_m=2*opts.dynamicRequiredClearance_m;
opts.coordinationSpeeds_mps=[11 9 7];
opts.coordinationDepartureStep_s=2;
opts.coordinationMaxDeparture_s=120;

fprintf('\n=== URBAN500 V3.3 | JOINT OFFLINE 5-UAV SCHEDULING ===\n');
fprintf('Moving solids = %d | aircraft separation >= %.1f m\n', ...
    numel(scene.dynamic),opts.interUAVRequiredSeparation_m);
% Verified input routes must still satisfy the same static clearances.
B=scene.buildings_m;c=opts.dynamicRequiredClearance_m;
B=bsxfun(@plus,B,[-c c -c c -c c]);
for k=1:5
    P=R.paths{k};
    for j=1:size(P,1)-1
        assert(urban500_rrtstar_edge_free(P(j,:),P(j+1,:),B), ...
            'Input UAV%d violated original static building clearance.',k);
    end
    [ok,~]=urban500_dynamic_path_check( ...
        R.timedPaths{k}.positions_m,R.timedPaths{k}.times_s, ...
        scene,opts.dynamicRequiredClearance_m,false);
    assert(ok,'Input UAV%d not safe relative to moving solids.',k);
end
fprintf('\nOriginal V3.2 schedule (all 10 aircraft pairs):\n');
auditBefore=urban500_interuav_audit( ...
    R.timedPaths,opts.interUAVRequiredSeparation_m,true);
[coordinatedTimedPaths,coordinationReport]=urban500_interuav_coordinate( ...
    R.paths,R.timedPaths,scene,opts);
if ~coordinationReport.success
    error(['No five-UAV joint schedule found within current bounds. ' ...
        'Original results remain unchanged. Increase departure budget ' ...
        'or introduce explicit holds / spatial replanning.']);
end
fprintf('\nFinal V3.3 schedule (all 10 aircraft pairs):\n');
auditAfter=urban500_interuav_audit( ...
    coordinatedTimedPaths,opts.interUAVRequiredSeparation_m,true);
assert(auditAfter.success,'Final inter-UAV audit failed.');
for k=1:5
    tr=coordinatedTimedPaths{k};
    [ok,~]=urban500_dynamic_path_check(tr.positions_m,tr.times_s, ...
        scene,opts.dynamicRequiredClearance_m,false);
    assert(ok,'Final UAV%d collided with a moving obstacle.',k);
    dt=diff(tr.times_s);dist=sqrt(sum(diff(tr.positions_m,1,1).^2,2));
    assert(all(dist(dt<1e-10)<1e-9), ...
        'UAV%d has a nonphysical zero-time positional jump.',k);
    assert(all(dist(dt>1e-10)./dt(dt>1e-10)<= ...
        max(opts.coordinationSpeeds_mps)+1e-8), ...
        'UAV%d exceeded the specified segment-speed ceiling.',k);
    fprintf('UAV%d: %s | depart %.1f s -> %.1f s | arrive %.1f s -> %.1f s\n', ...
        k,coordinationReport.methods{k}, ...
        R.timedPaths{k}.departure_s,tr.departure_s, ...
        R.timedPaths{k}.arrival_s,tr.arrival_s);
end
outDir=fullfile(root,'results_urban_complex_500_v3_interuav');
if exist(outDir,'dir')~=7,mkdir(outDir);end
paths=R.paths;
save(fullfile(outDir,'Urban500_5U_joint_timed.mat'), ...
    'scene','paths','opts','coordinatedTimedPaths','coordinationReport', ...
    'auditBefore','auditAfter','inputFile','-v7');
UAV=(1:5)';
originalDeparture_s=cellfun(@(tr)tr.departure_s,R.timedPaths);
newDeparture_s=cellfun(@(tr)tr.departure_s,coordinatedTimedPaths);
originalArrival_s=cellfun(@(tr)tr.arrival_s,R.timedPaths);
newArrival_s=cellfun(@(tr)tr.arrival_s,coordinatedTimedPaths);
speed_mps=cellfun(@(tr)tr.speed_mps,coordinatedTimedPaths);
method=string(coordinationReport.methods);
metrics=table(UAV,originalDeparture_s,newDeparture_s, ...
    originalArrival_s,newArrival_s,speed_mps,method);
writetable(metrics,fullfile(outDir,'Urban500_5U_joint_metrics.csv'));
for k=1:5
    tr=coordinatedTimedPaths{k};
    time_s=tr.times_s;x_m=tr.positions_m(:,1);
    y_m=tr.positions_m(:,2);z_m=tr.positions_m(:,3);
    writetable(table(time_s,x_m,y_m,z_m),fullfile(outDir, ...
        sprintf('UAV%d_joint_timed.csv',k)));
end
pairI=arrayfun(@(x)x.i,auditAfter.pairs);
pairJ=arrayfun(@(x)x.j,auditAfter.pairs);
minDistance_m=arrayfun(@(x)x.minDistance_m,auditAfter.pairs);
criticalTime_s=arrayfun(@(x)x.criticalTime_s,auditAfter.pairs);
margin_m=minDistance_m-opts.interUAVRequiredSeparation_m;
writetable(table(pairI,pairJ,minDistance_m,margin_m,criticalTime_s), ...
    fullfile(outDir,'Urban500_5U_pair_clearance.csv'));
fprintf('\nV3.3: 5/5 static + mixed-solid + inter-UAV TIMED-POLYLINE checks passed.\n');
fprintf('Saved new results to: %s\n',outDir);
fprintf(['LIMITATIONS: joint scheduler is heuristic; no acceleration/jerk ' ...
    'or true continuous Bezier multi-vehicle certificate.\n']);
