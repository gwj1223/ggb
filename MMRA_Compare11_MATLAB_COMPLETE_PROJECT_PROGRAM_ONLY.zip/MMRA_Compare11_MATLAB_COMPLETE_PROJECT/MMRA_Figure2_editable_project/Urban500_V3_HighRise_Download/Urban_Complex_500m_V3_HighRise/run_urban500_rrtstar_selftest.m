%% RUN_URBAN500_RRTSTAR_SELFTEST - V3 high-rise city
% Small deterministic tests for the collision checker and scene endpoints.
root = fileparts(mfilename('fullpath'));
addpath(root);
scene = urban500_scene();

% A segment crossing a box must be rejected.
box = [10 20 10 20 0 20];
assert(~urban500_rrtstar_edge_free([0 15 10],[30 15 10],box));

% A segment outside the box must be accepted.
assert(urban500_rrtstar_edge_free([0 0 10],[30 0 10],box));

% A point inside the box must be rejected.
assert(~urban500_rrtstar_edge_free([15 15 10],[15 15 10],box));

% A point outside the box must be accepted.
assert(urban500_rrtstar_edge_free([5 5 10],[5 5 10],box));

clearance = scene.uavSafetyRadius_m + 2;
B = scene.buildings_m;
B(:,1) = B(:,1)-clearance; B(:,2) = B(:,2)+clearance;
B(:,3) = B(:,3)-clearance; B(:,4) = B(:,4)+clearance;
B(:,5) = B(:,5)-clearance; B(:,6) = B(:,6)+clearance;
for k = 1:5
    assert(urban500_rrtstar_edge_free(scene.starts_m(k,:),scene.starts_m(k,:),B));
    assert(urban500_rrtstar_edge_free(scene.goals_m(k,:),scene.goals_m(k,:),B));
end

fprintf('Urban500 RRT* self-test PASSED.\n');
fprintf('Collision checker, 5 starts and 5 goals passed.\n');
