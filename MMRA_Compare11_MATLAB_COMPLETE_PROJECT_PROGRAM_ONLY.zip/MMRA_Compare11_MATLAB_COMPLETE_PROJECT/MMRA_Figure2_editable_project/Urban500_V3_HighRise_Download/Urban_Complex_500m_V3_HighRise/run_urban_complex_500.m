%% RUN_URBAN_COMPLEX_500 - Create independent 500 x 500 m V3 high-rise city.
% Add this folder to MATLAB's current path or execute this script directly.
% No toolboxes, external GitHub project, or MMRA project files are needed.
% No invented RRT* routes are shown: this is a scenario/map generator.
root=fileparts(mfilename('fullpath'));
addpath(root);
scene=urban500_scene();
run('run_urban_complex_500_checks.m');
outDir=fullfile(root,'results_urban_complex_500_v3');
if ~exist(outDir,'dir'),mkdir(outDir);end
save(fullfile(outDir,'Urban500_scene.mat'),'scene','-v7');
[fig,~,~]=urban500_draw(scene,40,'ShowMotionLines',false);
try
    exportgraphics(fig,fullfile(outDir,'Urban500_snapshot_t40.png'), ...
        'Resolution',180);
catch
    saveas(fig,fullfile(outDir,'Urban500_snapshot_t40.png'));
end
fprintf('\nURBAN 500 m V3 HIGH-RISE MAP: %d buildings, %d moving spheres, 5 UAV missions.\n', ...
    size(scene.buildings_m,1),numel(scene.dynamic));
fprintf('Mission straight distances (m): ');
for j=1:5
    fprintf('%.1f ',norm(scene.goals_m(j,:)-scene.starts_m(j,:)));
end
fprintf('\nSaved scene and image in: %s\n',outDir);
fprintf('NOTE: obstacle motion is simulated; UAV routes are not planned here.\n');
