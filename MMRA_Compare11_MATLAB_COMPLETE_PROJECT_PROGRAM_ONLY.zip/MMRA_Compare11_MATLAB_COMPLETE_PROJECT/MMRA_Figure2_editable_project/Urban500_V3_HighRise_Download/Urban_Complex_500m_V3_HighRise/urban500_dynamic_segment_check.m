function [safe, detail] = urban500_dynamic_segment_check(p0,p1,t0,t1,obs,required_m,stopEarly)
%URBAN500_DYNAMIC_SEGMENT_CHECK Moving solid vs moving UAV-centre segment.
% Assumptions: the UAV moves linearly in position over [t0,t1] (or hovers),
% every obstacle translates linearly p0->p1 over [ob.t0_s,ob.t1_s], and
% holds its endpoint position outside that interval. Fixed orientations.
% The sphere relative minimum is analytic. For box / finite vertical
% cylinder, distance to convex solids along the relative segment is
% minimized in 1D. Numerically conservative tolerance: 1e-6 m.
% required_m is centre-to-solid clearance = UAV radius + safety margin.
% No UAV acceleration/dynamics or inter-UAV avoidance is modelled here.
if nargin<7, stopEarly=true; end
p0=reshape(double(p0),1,3);
p1=reshape(double(p1),1,3);
assert(isfinite(t0)&&isfinite(t1)&&t1>=t0 && ...
    all(isfinite([p0 p1])) && isfinite(required_m) && required_m>0);
assert(t1>t0 || norm(p1-p0)<1e-10, ...
    'Non-zero UAV movement cannot happen in zero elapsed time.');
detail=struct('minMargin_m',inf,'minSurfaceDistance_m',inf, ...
    'obstacleIndex',0,'criticalTime_s',t0,'checkedPieces',0);
safe=true;
for k=1:numel(obs)
    ob=obs(k);
    cuts=[t0 t1];
    if ob.t0_s>t0 && ob.t0_s<t1, cuts(end+1)=ob.t0_s; end %#ok<AGROW>
    if ob.t1_s>t0 && ob.t1_s<t1, cuts(end+1)=ob.t1_s; end %#ok<AGROW>
    cuts=unique(sort(cuts));
    if numel(cuts)==1, cuts=[t0 t1]; end
    for j=1:numel(cuts)-1
        ta=cuts(j); tb=cuts(j+1);
        if t1>t0
            alpha0=(ta-t0)/(t1-t0);alpha1=(tb-t0)/(t1-t0);
        else
            alpha0=0;alpha1=0;
        end
        a=(1-alpha0)*p0+alpha0*p1-urban500_obstacle_position(ob,ta);
        b=(1-alpha1)*p0+alpha1*p1-urban500_obstacle_position(ob,tb);
        % Entire solid is enclosed in its bounding sphere. If the
        % relative segment cannot touch it, the lower bound is certified.
        R=boundingRadius(ob);
        v=b-a;
        vv=dot(v,v);
        if vv>1e-24
            u=max(0,min(1,-dot(a,v)/vv));
        else
            u=0;
        end
        dBound=norm(a+u*v)-R;
        detail.checkedPieces=detail.checkedPieces+1;
        if dBound>required_m+1e-6
            d=dBound; % conservative bound, may underestimate true gap
        else
            if isfield(ob,'type') && ~isempty(ob.type)
                typ=lower(char(ob.type));
            else
                typ='sphere';
            end
            if strcmp(typ,'sphere')
                % Closest approach of the relative moving centre.
                d=norm(a+u*v)-ob.radius_m;
            else
                % Distance to a convex solid is convex along a straight
                % line; 50-step golden-section minimization is unimodal.
                L=0;H=1;
                gr=(sqrt(5)-1)/2;
                c=H-gr*(H-L);e=L+gr*(H-L);
                fc=urban500_dynamic_shape_distance(a+c*v,ob);
                fe=urban500_dynamic_shape_distance(a+e*v,ob);
                for it=1:50
                    if fc<=fe
                        H=e;e=c;fe=fc;c=H-gr*(H-L);
                        fc=urban500_dynamic_shape_distance(a+c*v,ob);
                    else
                        L=c;c=e;fc=fe;e=L+gr*(H-L);
                        fe=urban500_dynamic_shape_distance(a+e*v,ob);
                    end
                end
                d=min([urban500_dynamic_shape_distance(a,ob), ...
                    urban500_dynamic_shape_distance(b,ob),fc,fe])-1e-6;
                u=(L+H)/2;
            end
        end
        margin=d-required_m;
        if margin<detail.minMargin_m
            detail.minMargin_m=margin;
            detail.minSurfaceDistance_m=d;
            detail.obstacleIndex=k;
            detail.criticalTime_s=ta+u*(tb-ta);
        end
        if margin<=1e-7
            safe=false;
            if stopEarly, return; end
        end
    end
end
end

function R=boundingRadius(ob)
if isfield(ob,'type') && ~isempty(ob.type)
    typ=lower(char(ob.type));
else
    typ='sphere';
end
switch typ
    case 'sphere'
        R=ob.radius_m;
    case 'cylinder'
        R=hypot(ob.radius_m,ob.halfHeight_m);
    case 'box'
        R=norm(ob.halfSize_m);
    otherwise
        error('Unsupported dynamic obstacle type: %s',typ);
end
end
