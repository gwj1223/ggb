function scene = urban500_scene()
%URBAN500_SCENE Reproducible independent 500 x 500 m urban environment.
% No toolboxes or external projects required. MATLAB R2023b compatible.
% Buildings: [xmin xmax ymin ymax zmin zmax] in metres.
% Dynamic spheres: physical radius and time-based centre motion in metres.
% This file defines a TEST ENVIRONMENT, not an RRT* solution.

scene = struct();
scene.name = 'Urban Complex 500 m V3 High-Rise';
scene.bounds_m = [0 500; 0 500; 0 200];
scene.buildingHeightProfile_m = struct( ...
    'core',[90 170], 'transition',[50 115], 'outer',[25 70]);
scene.seed = 20261101;
scene.routeColors = [ ...
    0.14 0.93 0.19; ... % green
    1.00 0.95 0.15; ... % yellow
    1.00 0.17 0.17; ... % red
    0.89 0.45 0.98; ... % purple
    0.84 0.56 0.00];    % orange

% Five *different* launch pads, one common base in the southwest.
scene.starts_m = [ ...
    20 22 12;
    38 22 12;
    20 40 12;
    38 40 12;
    56 22 12];
scene.goals_m = [ ...
    470 470 16;
    465 350 16;
    340 465 16;
    460 180 16;
    180 465 16];
scene.minimumPadSpacing_m = 18;
scene.uavSafetyRadius_m = 3;

% Three open plazas, retained for emergency manoeuvres/replanning.
scene.plazas = [165 165 48; 365 365 48; 385 135 43]; % cx, cy, radius

% All deterministic: 9x9 possible lots, selective omissions for plazas,
% mission pads, and mission goals. Dense core and lower suburban fringe.
centres = 40:50:440;
b = zeros(81,6); n = 0;
for ix=1:numel(centres)
    for iy=1:numel(centres)
        cx=centres(ix); cy=centres(iy);
        wx=26+11*abs(sin(0.83*ix+0.37*iy));
        wy=26+11*abs(cos(0.41*ix+0.77*iy));
        % Keep main NS/EW 22-m avenues and two narrower cross streets free.
        if abs(cx-265)==25, wx=min(wx,28); end
        if abs(cy-265)==25, wy=min(wy,28); end
        if abs(cx-115)==25, wx=min(wx,31); end
        if abs(cy-365)==25, wy=min(wy,31); end
        % Minor facade variety while keeping deterministic city blocks.
        if mod(ix+3*iy,7)==0
            wx=wx-3;
        end
        r=[cx-wx/2 cx+wx/2 cy-wy/2 cy+wy/2];

        isPlaza=false;
        for k=1:size(scene.plazas,1)
            pl=scene.plazas(k,:);
            if hypot(cx-pl(1),cy-pl(2))<pl(3)
                isPlaza=true;
                break;
            end
        end
        if isPlaza, continue; end

        % Do not place a building at or near a take-off / landing location.
        endpoints=[scene.starts_m(:,1:2);scene.goals_m(:,1:2)];
        tooClose=false;
        for k=1:size(endpoints,1)
            q=endpoints(k,:);
            dd=hypot(max([r(1)-q(1),0,q(1)-r(2)]), ...
                     max([r(3)-q(2),0,q(2)-r(4)]));
            if dd<18
                tooClose=true;
                break;
            end
        end
        if tooClose, continue; end

        dist=hypot(cx-250,cy-250);
        if dist<150
            height=90+80*abs(sin(ix*1.31+iy*0.49));
        elseif dist<230
            height=50+65*abs(sin(ix*0.62+iy*1.17));
        else
            height=25+45*abs(cos(ix*1.14+iy*0.81));
        end
        n=n+1;
        b(n,:)=[r(1:2),r(3:4),0,height];
    end
end
scene.buildings_m=b(1:n,:);

% Six independent elevated moving spheres. XY corridors and timing are
% retained, while centre altitudes are raised into the urban flight volume.
% Altitudes [95,125,155,80,110,140] m span several layers above street level.
% Each object moves linearly between t0_s and t1_s, then remains at p1.
p0=[265  35  95; ...
    465 265 125; ...
    265 465 155; ...
     35 265  80; ...
    115  40 110; ...
     40 365 140];
p1=[265 465  95; ...
     35 265 125; ...
    265  35 155; ...
    465 265  80; ...
    115 460 110; ...
    460 365 140];
t0=[0;10;16;5;23;0];
t1=[72;85;94;98;95;88];
radii=[6;6;5.5;5.5;3.5;3.5];
scene.dynamic = repmat(struct('p0_m',[],'p1_m',[], ...
    't0_s',0,'t1_s',0,'radius_m',0),6,1);
for k=1:6
    scene.dynamic(k).p0_m=p0(k,:);
    scene.dynamic(k).p1_m=p1(k,:);
    scene.dynamic(k).t0_s=t0(k);
    scene.dynamic(k).t1_s=t1(k);
    scene.dynamic(k).radius_m=radii(k);
end
scene.duration_s=100;
scene.isPlannerOutput=false;
scene.notes=['V3 high-rise buildings and moving spheres are scenario data. ' ...
    'No UAV route is generated or safety-certified by the map preview.'];
end
