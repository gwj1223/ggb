function [safe,detail]=urban500_dynamic_path_check(P,T,scene,required_m,stopEarly)
%URBAN500_DYNAMIC_PATH_CHECK Full time-stamped trajectory vs all obstacles.
% Returns earliest conflict and conservative minimum clearance margin.
if nargin<5,stopEarly=false;end
assert(isnumeric(P)&&size(P,2)==3&&size(P,1)>=2);
T=T(:);
assert(numel(T)==size(P,1)&&all(isfinite(T)) && ...
    all(diff(T)>=0) && T(1)>=0,'Invalid increasing trajectory timestamps.');
detail=struct('minMargin_m',inf,'segmentIndex',0,'obstacleIndex',0, ...
    'criticalTime_s',NaN,'violatingSegments',0);
safe=true;
for j=1:size(P,1)-1
    [ok,d]=urban500_dynamic_segment_check(P(j,:),P(j+1,:), ...
        T(j),T(j+1),scene.dynamic,required_m,stopEarly);
    if d.minMargin_m<detail.minMargin_m
        detail.minMargin_m=d.minMargin_m;
        detail.segmentIndex=j;
        detail.obstacleIndex=d.obstacleIndex;
        detail.criticalTime_s=d.criticalTime_s;
    end
    if ~ok
        safe=false;
        detail.violatingSegments=detail.violatingSegments+1;
        if stopEarly,return;end
    end
end
end
