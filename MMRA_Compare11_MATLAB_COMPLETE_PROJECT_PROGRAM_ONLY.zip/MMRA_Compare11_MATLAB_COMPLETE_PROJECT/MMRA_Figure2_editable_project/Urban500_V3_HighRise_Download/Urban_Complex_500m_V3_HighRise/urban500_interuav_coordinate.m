function [coordinated,report] = urban500_interuav_coordinate(paths,baseline,scene,opt)
%URBAN500_INTERUAV_COORDINATE Offline priority-based joint departure scheduling.
% Keeps original spatial routes (and any baseline waypoint holds).
% Tests each candidate against ALL moving mixed solids and previously
% scheduled UAVs. Rechecks all 10 UAV pairs before accepting the result.
%
% This is a BOUNDED HEURISTIC, not a complete optimizer or online 4D RRT*.
% If no feasible schedule is found, returns success=false; never silently
% claims an unverified route is safe.
N=numel(paths);
assert(N==numel(baseline)&&N>=2,'Mismatched UAV paths.');
assert(isfield(opt,'dynamicRequiredClearance_m')&& ...
    isfield(opt,'interUAVRequiredSeparation_m'));
sep=opt.interUAVRequiredSeparation_m;
[beforeOK,before]=localAuditNoPrint(baseline,sep);
report=struct('success',false,'baselineSafe',beforeOK, ...
    'baselineAudit',before,'finalAudit',[], ...
    'chosenOrder',[],'makespan_s',NaN,'methods',{{}}, ...
    'failureReason','no_verified_joint_schedule');
coordinated=cell(N,1);
% Try multiple priority permutations; favor first solution with shorter
% mission makespan. For five aircraft this is inexpensive relative to RRT*.
orders=[(1:N); N:-1:1];
[~,rank]=sort(cellfun(@(x)x.arrival_s,baseline),'descend');
orders(end+1,:)=rank(:)';
[~,rank]=sort(cellfun(@(x)x.departure_s,baseline),'descend');
orders(end+1,:)=rank(:)';
orders=unique(orders,'rows','stable');
if beforeOK
    allDynamic=true;
    for k=1:N
        [ok,~]=urban500_dynamic_path_check( ...
            baseline{k}.positions_m,baseline{k}.times_s,scene, ...
            opt.dynamicRequiredClearance_m,true);
        allDynamic=allDynamic && ok;
    end
    if allDynamic
        coordinated=baseline;
        report.success=true;
        report.chosenOrder=1:N;
        report.makespan_s=max(cellfun(@(x)x.arrival_s,coordinated));
        report.finalAudit=before;
        report.methods=repmat({'retained-original-V3.2'},N,1);
        report.failureReason='';
        return;
    end
end
bestMakespan=inf;
for trial=1:size(orders,1)
    order=orders(trial,:);
    scheduled=cell(N,1);
    methods=cell(N,1);
    feasible=true;
    for idx=1:N
        k=order(idx);
        [tr,method]=localFindCandidate( ...
            paths{k},baseline{k},scheduled,scene,opt);
        if isempty(tr)
            feasible=false;break;
        end
        scheduled{k}=tr;
        methods{k}=method;
    end
    if ~feasible,continue;end
    [ok,audit]=localAuditNoPrint(scheduled,sep);
    if ~ok,continue;end
    makespan=max(cellfun(@(x)x.arrival_s,scheduled));
    if makespan<bestMakespan-1e-8
        bestMakespan=makespan;coordinated=scheduled;
        report.success=true;
        report.chosenOrder=order;
        report.makespan_s=makespan;
        report.finalAudit=audit;
        report.methods=methods;
        report.failureReason='';
    end
end
end

function [chosen,method] = localFindCandidate(path,baseline,others,scene,opt)
chosen=[];method='';
% Keep the exact V3.2 flight if it is also safe against other aircraft.
if localCandidateSafe(baseline,others,scene,opt)
    chosen=baseline;method='retained-original-V3.2';return;
end
speeds=opt.coordinationSpeeds_mps(:)';
delays=0:opt.coordinationDepartureStep_s:opt.coordinationMaxDeparture_s;
length_m=sum(sqrt(sum(diff(path,1,1).^2,2)));
rows=zeros(numel(speeds)*numel(delays),3);n=0;
for speed=speeds
    for d=delays
        n=n+1;rows(n,:)=[d+length_m/speed,d,speed];
    end
end
rows=sortrows(rows,[1 2 3]);
for c=1:size(rows,1)
    d=rows(c,2);speed=rows(c,3);
    tr=localRetimed(path,d,speed);
    if localCandidateSafe(tr,others,scene,opt)
        chosen=tr;method='joint-departure-speed-grid';return;
    end
end
end

function yes=localCandidateSafe(tr,others,scene,opt)
yes=true;
% Pair checks first to avoid unnecessarily expensive solid checks.
for j=1:numel(others)
    if isempty(others{j}),continue;end
    [ok,~]=urban500_interuav_pair_check( ...
        tr,others{j},opt.interUAVRequiredSeparation_m);
    if ~ok,yes=false;return;end
end
[yes,~]=urban500_dynamic_path_check( ...
    tr.positions_m,tr.times_s,scene,opt.dynamicRequiredClearance_m,true);
end

function tr=localRetimed(path,d,speed)
L=sqrt(sum(diff(path,1,1).^2,2));
P=path;T=d+[0;cumsum(L)/speed];
if d>0
    P=[path(1,:);P];T=[0;T];
end
tr=struct('positions_m',P,'times_s',T, ...
    'departure_s',d,'arrival_s',T(end),'speed_mps',speed, ...
    'localWaitCount',0,'localWaitTime_s',0,'pathLength_m',sum(L));
end

function [ok,audit]=localAuditNoPrint(paths,sep)
[ok,audit]=deal(false,[]);
if any(cellfun(@isempty,paths)),return;end
audit=urban500_interuav_audit(paths,sep,false);
ok=audit.success;
end
