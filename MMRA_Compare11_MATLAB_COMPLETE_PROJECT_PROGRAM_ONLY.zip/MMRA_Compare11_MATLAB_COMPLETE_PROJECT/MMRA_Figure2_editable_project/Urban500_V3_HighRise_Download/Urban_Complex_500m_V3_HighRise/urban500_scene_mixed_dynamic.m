function scene = urban500_scene_mixed_dynamic()
%URBAN500_SCENE_MIXED_DYNAMIC Opt-in mixed moving obstacles for Urban500 V3.
% Keeps the original V3.1 scene, 67 buildings and all six sphere trajectories.
% Adds two vertical finite cylinders and two axis-aligned translating boxes.
% Each object has a fixed orientation and linear p0->p1 translation; it
% remains at p0 before t0_s and at p1 after t1_s (same legacy convention).
scene = urban500_scene();
scene.name = 'Urban500 V3.2 | mixed moving obstacle benchmark';
scene.notes = ['Independent dynamic-obstacle scheduling benchmark: ' ...
    'six legacy spheres plus two finite cylinders and two AABBs. ' ...
    'No inter-UAV collision prevention or dynamic aircraft model claimed.'];
for k = 1:numel(scene.dynamic)
    scene.dynamic(k).type = 'sphere';
    scene.dynamic(k).name = sprintf('S%d', k);
    scene.dynamic(k).halfHeight_m = 0;
    scene.dynamic(k).halfSize_m = [0 0 0];
end
% B3 runs at z=102 m; the earlier z=115 m intersected S2 near t=50.1 s.
% Each new object is kept in an open roadway corridor. All spatial and
% temporal safety checks are executed by run_urban500_mixed_dynamic_checks.
p0 = [115 65 70; 415 435 135; 50 265 102; 450 415 155];
p1 = [115 435 70; 415 65 135; 450 265 102; 50 415 155];
t0 = [12;0;20;30];
t1 = [90;80;85;100];
types = {'cylinder','cylinder','box','box'};
for j = 1:4
    ob = scene.dynamic(1); % inherit identical field order
    ob.p0_m = p0(j,:);
    ob.p1_m = p1(j,:);
    ob.t0_s = t0(j);
    ob.t1_s = t1(j);
    ob.type = types{j};
    ob.name = sprintf('%s%d', upper(types{j}(1)), j);
    if j <= 2
        ob.radius_m = 4;
        ob.halfHeight_m = 8;
        ob.halfSize_m = [0 0 0];
    else
        ob.radius_m = 0;
        ob.halfHeight_m = 0;
        ob.halfSize_m = [4 4 7];
    end
    scene.dynamic(end+1,1) = ob;
end
scene.dynamicCounts = struct('sphere',6,'cylinder',2,'box',2);
scene.dynamicGeometryVersion = 'mixed_v2_pair_safe';
end
