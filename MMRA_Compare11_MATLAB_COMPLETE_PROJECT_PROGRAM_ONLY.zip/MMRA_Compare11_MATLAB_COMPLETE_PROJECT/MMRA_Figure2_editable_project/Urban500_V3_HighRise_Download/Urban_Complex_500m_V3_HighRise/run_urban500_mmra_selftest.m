%% RUN_URBAN500_MMRA_SELFTEST - integration / regression safety checks
% Validates adaptive corner acceptance, static building certificate,
% collision fallback, turn radius and actual stored 5-UAV Urban500 paths.
root=fileparts(mfilename('fullpath'));
addpath(root);
src=fullfile(fileparts(fileparts(root)),'src');
addpath(src);
assert(exist(fullfile(src,'mmra_bezier.m'),'file')==2, ...
    'Shared MMRA src folder not found.');
run(fullfile(root,'run_urban500_rrtstar_selftest.m'));
testDir=fullfile(fileparts(fileparts(root)),'tests');
addpath(testDir);
mmra_adaptive_smoothing_tests();
run(fullfile(root,'run_urban500_terminal_radius_repair_test.m'));

% Synthetic right-angle path; blocked diagonal prevents over-pruning.
P=[0 0 10;20 0 10;20 20 10];
boxes=[6 14 6 14 0 20];
cfg=struct('bounds_m',[0 60;0 60;0 30], ...
    'mmraPruneMode','shortest_visibility', ...
    'smoothMinRadius_m',3,'smoothMaxPitch_deg',75, ...
    'smoothTrimFraction',0.44, ...
    'smoothMaxChord_m',1,'smoothMaxSagitta_m',0.05);
[sm,st,p]=urban500_mmra_postprocess(P,boxes,cfg);
assert(size(st.pruned,1)==3 && p.roundedCorners==1 && ...
    p.allEligibleCornersSmoothed);
assert(all(sm(1,:)==P(1,:)) && all(sm(end,:)==P(end,:)));
assert(p.minAcceptedCurveRadius_m>=cfg.smoothMinRadius_m-1e-8);
for j=1:size(sm,1)-1
    assert(urban500_rrtstar_edge_free(sm(j,:),sm(j+1,:),boxes));
end

% The exact curve bulges into a thin box even though original L segments
% do not. This must be conservatively rejected, NOT drawn as safe.
cornerBox=[17 19 1 4 0 20];
assert(urban500_rrtstar_edge_free(P(1,:),P(2,:),cornerBox));
assert(urban500_rrtstar_edge_free(P(2,:),P(3,:),cornerBox));
assert(~urban500_bezier_curve_free([11.2 0 10],P(2,:), ...
    [20 8.8 10],cornerBox,15));

% A physically impossible large turn radius must never be falsely claimed.
cfgTight=cfg;
cfgTight.smoothMinRadius_m=1000;
[smTight,~,stTight]=urban500_mmra_postprocess(P,boxes,cfgTight);
assert(stTight.roundedCorners==0 && ...
    ~stTight.allEligibleCornersSmoothed && isequal(smTight,P));

% Test the actual previously archived five UAV routes if available.
arch=fullfile(root,'results_urban_complex_500_v3_rrtstar', ...
    'Urban500_RRTstar_5U_static.mat');
if exist(arch,'file')==2
    saved=load(arch);
    c=saved.cfg;
    c.mmraPruneMode='shortest_visibility';
    c.smoothMinRadius_m=10;
    c.smoothMaxPitch_deg=75;
    c.smoothTrimFraction=0.44;
    c.smoothMaxChord_m=2.5;
    c.smoothMaxSagitta_m=0.10;
    c.smoothMinAngle_deg=2;
    clearance=saved.scene.uavSafetyRadius_m+2;
    B=bsxfun(@plus,saved.scene.buildings_m, ...
        [-clearance clearance -clearance clearance -clearance clearance]);
    for k=1:5
        raw=saved.paths{k};
        [after,~,stat]=urban500_mmra_postprocess(raw,B,c);
        assert(norm(after(1,:)-raw(1,:))<1e-9 && ...
            norm(after(end,:)-raw(end,:))<1e-9);
        assert(stat.staticCollisionVerified && ...
            stat.minAcceptedCurveRadius_m>=c.smoothMinRadius_m-1e-8);
        for j=1:size(after,1)-1
            assert(urban500_rrtstar_edge_free(after(j,:),after(j+1,:),B));
        end
        fprintf('Saved UAV%d: %d/%d corners, %.1f -> %.1f deg\n',k, ...
            stat.roundedCorners,stat.totalCorners, ...
            stat.maxAngleBefore_deg,stat.maxAngleAfter_deg);
    end
else
    fprintf('Saved archive not found: skipped 5-UAV fixture checks.\n');
end
fprintf('Urban500 MMRA postprocess self-test PASSED.\n');
