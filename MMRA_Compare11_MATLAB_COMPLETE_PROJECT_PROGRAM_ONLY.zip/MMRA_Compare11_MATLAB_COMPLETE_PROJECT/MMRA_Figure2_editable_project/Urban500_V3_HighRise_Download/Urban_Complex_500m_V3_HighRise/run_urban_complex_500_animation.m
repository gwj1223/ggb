%% RUN_URBAN_COMPLEX_500_ANIMATION - Animate actual moving spheres.
% This is a SCENE preview, not autonomous UAV guidance or collision control.
root=fileparts(mfilename('fullpath'));
addpath(root);
scene=urban500_scene();
[fig,ax,h]=urban500_draw(scene,0,'ShowMotionLines',true);
[sx,sy,sz]=sphere(22);
dt=0.5;
% Change the pause duration to control on-screen playback speed.
for t=0:dt:scene.duration_s
    if ~isgraphics(fig), break; end
    for k=1:numel(scene.dynamic)
        ob=scene.dynamic(k);
        p=urban500_obstacle_position(ob,t);
        r=ob.radius_m;
        if isgraphics(h(k))
            set(h(k),'XData',p(1)+r*sx, ...
                'YData',p(2)+r*sy,'ZData',p(3)+r*sz);
        end
    end
    title(ax,sprintf('500 x 500 m V3 high-rise dynamic scene | t = %.1f s',t), ...
        'FontWeight','normal');
    drawnow limitrate;
    pause(0.025);
end
fprintf('Urban500 V3 high-rise moving-sphere preview finished.\n');
