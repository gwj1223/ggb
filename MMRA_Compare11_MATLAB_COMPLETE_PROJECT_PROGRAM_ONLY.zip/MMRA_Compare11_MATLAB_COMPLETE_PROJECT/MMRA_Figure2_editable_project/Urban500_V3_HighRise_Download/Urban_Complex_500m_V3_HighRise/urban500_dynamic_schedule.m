function [traj,stat] = urban500_dynamic_schedule(path,scene,cfg)
%URBAN500_DYNAMIC_SCHEDULE Time-aware scheduling of an MMRA spatial route.
% 1. Try departures and cruise speeds in arrival-time order.
% 2. If none is feasible, insert limited certified hover waits at actual
%    waypoints and recheck every segment over continuous time.
% 3. Return explicit failure if no time schedule can be verified.
% Any subsequently attempted spatial replan belongs to the calling script.
path=double(path);
assert(size(path,2)==3 && size(path,1)>1 && ...
    all(isfinite(path(:))),'Invalid spatial route.');
assert(isfield(cfg,'dynamicRequiredClearance_m') && ...
    cfg.dynamicRequiredClearance_m>0);
segLen=sqrt(sum(diff(path,1,1).^2,2));
assert(all(segLen>=0));
length_m=sum(segLen);
speeds=cfg.dynamicSpeeds_mps(:)';
delays=0:cfg.dynamicDepartureStep_s:cfg.dynamicMaxDeparture_s;
assert(all(speeds>0)&&~isempty(speeds));
% Baseline is the unmodified route, launched immediately at reference speed.
[baseP,baseT]=straightTimes(path,0,speeds(1));
[baseOK,base]=urban500_dynamic_path_check(baseP,baseT,scene, ...
    cfg.dynamicRequiredClearance_m,false);
stat=struct('success',false,'baselineSafe',baseOK, ...
    'baselineMinMargin_m',base.minMargin_m, ...
    'baselineConflictingSegments',base.violatingSegments, ...
    'baselineCriticalObstacle',base.obstacleIndex, ...
    'baselineCriticalTime_s',base.criticalTime_s, ...
    'candidatesTried',0,'method','not-found', ...
    'minCertifiedMargin_m',NaN);
traj=struct('positions_m',zeros(0,3),'times_s',zeros(0,1), ...
    'departure_s',NaN,'arrival_s',NaN,'speed_mps',NaN, ...
    'localWaitCount',0,'localWaitTime_s',0,'pathLength_m',length_m);
% Exhaustively score the small discrete set, fastest arrival first.
cand=zeros(numel(delays)*numel(speeds),3);
n=0;
for s=speeds
    for d=delays
        n=n+1;
        cand(n,:)=[d+length_m/s,d,s];
    end
end
cand=sortrows(cand,[1 2]);
for c=1:size(cand,1)
    d=cand(c,2);s=cand(c,3);
    [P,T]=straightTimes(path,d,s);
    stat.candidatesTried=stat.candidatesTried+1;
    [ok,det]=urban500_dynamic_path_check(P,T,scene, ...
        cfg.dynamicRequiredClearance_m,true);
    if ok
        % Recompute all intervals for recorded, conservative min margin.
        [ok,det]=urban500_dynamic_path_check(P,T,scene, ...
            cfg.dynamicRequiredClearance_m,false);
        assert(ok,'Inconsistent dynamic trajectory collision verification.');
        traj=takeResult(traj,P,T,d,s,0,0);
        stat.success=true;
        stat.method='departure-speed-search';
        stat.minCertifiedMargin_m=det.minMargin_m;
        return;
    end
end
% Local hover repair at existing waypoints; no invalid geometry changes.
for s=speeds
    for d=delays
        [ok,P,T,nW,totalW]=planLocalWaits(path,segLen,d,s,scene,cfg);
        if ~ok,continue;end
        [ok,det]=urban500_dynamic_path_check(P,T,scene, ...
            cfg.dynamicRequiredClearance_m,false);
        if ok
            traj=takeResult(traj,P,T,d,s,nW,totalW);
            stat.success=true;
            stat.method='waypoint-hold-repair';
            stat.minCertifiedMargin_m=det.minMargin_m;
            return;
        end
    end
end
end

function [P,T]=straightTimes(path,delay,speed)
len=sqrt(sum(diff(path,1,1).^2,2));
P=path;
T=delay+[0;cumsum(len)/speed];
if delay>0
    P=[path(1,:);P];
    T=[0;T];
end
end

function out=takeResult(out,P,T,d,s,nW,totalW)
out.positions_m=P;
out.times_s=T;
out.departure_s=d;
out.arrival_s=T(end);
out.speed_mps=s;
out.localWaitCount=nW;
out.localWaitTime_s=totalW;
end

function [ok,P,T,numWait,totalWait]=planLocalWaits(path,segLen,d,s,scene,cfg)
P=path(1,:);T=0;numWait=0;totalWait=0;ok=true;
if d>0
    [safe,~]=urban500_dynamic_segment_check(P(end,:),P(end,:),0,d, ...
        scene.dynamic,cfg.dynamicRequiredClearance_m,true);
    if ~safe
        ok=false;return;
    end
    P(end+1,:)=P(end,:);T(end+1,1)=d;
end
for j=1:numel(segLen)
    p=path(j,:);q=path(j+1,:);
    t=T(end);dt=segLen(j)/s;
    found=false;
    for wait=0:cfg.dynamicLocalWaitStep_s:cfg.dynamicMaxLocalWait_s
        if wait>0
            [safe,~]=urban500_dynamic_segment_check(p,p,t,t+wait, ...
                scene.dynamic,cfg.dynamicRequiredClearance_m,true);
            if ~safe,continue;end
        end
        [safe,~]=urban500_dynamic_segment_check(p,q,t+wait,t+wait+dt, ...
            scene.dynamic,cfg.dynamicRequiredClearance_m,true);
        if safe
            if wait>0
                P(end+1,:)=p;T(end+1,1)=t+wait; %#ok<AGROW>
                numWait=numWait+1;totalWait=totalWait+wait;
            end
            P(end+1,:)=q;T(end+1,1)=t+wait+dt; %#ok<AGROW>
            found=true;
            break;
        end
    end
    if ~found || totalWait>cfg.dynamicMaxTotalWait_s
        ok=false;return;
    end
end
end
