function p = urban500_obstacle_position(ob,t_s)
%URBAN500_OBSTACLE_POSITION Centre of translating sphere/cylinder/box at time t_s (metres).
assert(isnumeric(t_s) && isscalar(t_s) && isfinite(t_s));
assert(ob.t1_s>ob.t0_s,'Moving obstacle must have t1_s > t0_s.');
a=max(0,min(1,(t_s-ob.t0_s)/(ob.t1_s-ob.t0_s)));
p=(1-a)*ob.p0_m+a*ob.p1_m;
end
