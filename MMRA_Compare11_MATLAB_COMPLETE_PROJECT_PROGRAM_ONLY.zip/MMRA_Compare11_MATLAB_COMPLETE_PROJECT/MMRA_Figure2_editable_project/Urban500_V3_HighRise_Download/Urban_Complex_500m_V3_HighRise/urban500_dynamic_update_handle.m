function urban500_dynamic_update_handle(h, ob, t_s)
%URBAN500_DYNAMIC_UPDATE_HANDLE Move existing sphere, cylinder or box.
if ~isgraphics(h), return; end
c = urban500_obstacle_position(ob,t_s);
local = get(h,'UserData');
switch local.kind
    case 'surf'
        xyz = local.xyz;
        set(h,'XData',c(1)+xyz{1},'YData',c(2)+xyz{2}, ...
            'ZData',c(3)+xyz{3});
    case 'patch'
        set(h,'Vertices',bsxfun(@plus,local.vertices,c));
end
end
