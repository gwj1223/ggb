%% RUN_URBAN500_MMRA_REPAIR_SAVED - controlled A/B on SAME raw RRT* paths
% Re-run only MMRA prune/smooth postprocessing on saved 5-UAV RRT* results.
% Does NOT call RRT* search, does NOT change buildings or safety margins,
% and does NOT overwrite the input MAT. Use to compare terminal radius fix
% with the exact routes that produced warnings on your MATLAB installation.
root=fileparts(mfilename('fullpath'));
addpath(root);
src=fullfile(fileparts(fileparts(root)),'src');
addpath(src);
oldMAT=fullfile(root,'results_urban_complex_500_v3_rrtstar_mmra', ...
    'Urban500_RRTstar_5U_static.mat');
assert(exist(oldMAT,'file')==2, ...
    'Baseline MAT file missing. Run old planning first or place the baseline MAT in results_urban_complex_500_v3_rrtstar_mmra.');
old=load(oldMAT);
assert(isfield(old,'rawPaths') && isfield(old,'scene') && ...
    isfield(old,'cfg') && isfield(old,'postprocessStats'), ...
    'Baseline MAT lacks rawPaths, scene, cfg or postprocessStats.');
scene=old.scene;
cfg=old.cfg;
assert(numel(old.rawPaths)==5,'Expected five saved raw RRT* paths.');
clearance=scene.uavSafetyRadius_m+cfg.extraClearance_m;
B=scene.buildings_m;
B=bsxfun(@plus,B,[-clearance clearance -clearance clearance ...
    -clearance clearance]);
repairedPaths=cell(5,1);
repairedStages=cell(5,1);
repairedStats=cell(5,1);
uav=(1:5)';
roundedBefore=zeros(5,1); eligibleBefore=zeros(5,1);
roundedAfter=zeros(5,1); eligibleAfter=zeros(5,1);
maxTurnBefore_deg=zeros(5,1); maxTurnAfter_deg=zeros(5,1);
terminalRepairAttempted=false(5,1); terminalRepairSucceeded=false(5,1);
terminalRepairCandidatesTested=zeros(5,1);
curveRadiusAfter_m=nan(5,1);
fprintf('\n=== CONTROLLED TEST: EXACT SAME SAVED FIVE RAW PATHS ===\n');
for k=1:5
    raw=old.rawPaths{k};
    assert(~isempty(raw),'Saved raw path UAV%d is empty.',k);
    baseline=old.postprocessStats{k};
    [route,st,post]=urban500_mmra_postprocess(raw,B,cfg);
    repairedPaths{k}=route; repairedStages{k}=st;
    repairedStats{k}=post;
    roundedBefore(k)=baseline.roundedCorners;
    eligibleBefore(k)=baseline.totalCorners;
    roundedAfter(k)=post.roundedCorners;
    eligibleAfter(k)=post.totalCorners;
    maxTurnBefore_deg(k)=baseline.maxAngleAfter_deg;
    maxTurnAfter_deg(k)=post.maxAngleAfter_deg;
    terminalRepairAttempted(k)=post.terminalRepair.attempted;
    terminalRepairSucceeded(k)=post.terminalRepair.succeeded;
    terminalRepairCandidatesTested(k)=post.terminalRepair.candidatesTested;
    curveRadiusAfter_m(k)=post.minAcceptedCurveRadius_m;
    for j=1:size(route,1)-1
        assert(urban500_rrtstar_edge_free(route(j,:),route(j+1,:),B), ...
            'UAV%d repaired chord %d collides.',k,j);
    end
    fprintf(['UAV%d: rounded %d/%d -> %d/%d; max chord-turn %.1f -> %.1f deg; ' ...
        'terminal repair=%s; fullySmoothed=%d\n'],k,roundedBefore(k), ...
        eligibleBefore(k),roundedAfter(k),eligibleAfter(k), ...
        maxTurnBefore_deg(k),maxTurnAfter_deg(k), ...
        post.terminalRepair.status,post.allEligibleCornersSmoothed);
    if ~isempty(post.failedCornerIndices)
        fprintf('  Still unresolved at nodes:');
        fprintf(' %d',post.failedCornerIndices);
        fprintf('\n');
    end
end
outDir=fullfile(root, ...
    'results_urban_complex_500_v3_rrtstar_mmra_radius_repair');
if ~isfolder(outDir), mkdir(outDir); end
save(fullfile(outDir,'Urban500_RRTstar_5U_repair_only.mat'), ...
    'oldMAT','cfg','repairedPaths','repairedStages','repairedStats','-v7');
comparison=table(uav,roundedBefore,eligibleBefore,roundedAfter, ...
    eligibleAfter,maxTurnBefore_deg,maxTurnAfter_deg, ...
    terminalRepairAttempted,terminalRepairSucceeded, ...
    terminalRepairCandidatesTested,curveRadiusAfter_m);
writetable(comparison,fullfile(outDir, ...
    'Urban500_RRTstar_5U_repair_only_metrics.csv'));
fprintf('Controlled static-building checks: 5/5 passed.\n');
fprintf('Compare results saved under: %s\n',outDir);
