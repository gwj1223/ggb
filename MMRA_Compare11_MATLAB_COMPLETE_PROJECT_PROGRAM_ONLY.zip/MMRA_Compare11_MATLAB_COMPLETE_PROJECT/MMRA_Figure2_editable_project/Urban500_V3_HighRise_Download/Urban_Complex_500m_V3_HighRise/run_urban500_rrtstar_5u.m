%% RUN_URBAN500_RRTSTAR_5U - V3 high-rise city
% Static-obstacle-aware 3-D RRT* + SHARED MMRA safe postprocessing.
% This add-on does not overwrite the original map or dynamic-scene scripts.
% Dynamic spheres and inter-UAV separation are intentionally not included
% in this first planning stage; they are handled in later experiments.

root = fileparts(mfilename('fullpath'));
addpath(root);
mmraSrc=fullfile(fileparts(fileparts(root)),'src');
assert(exist(fullfile(mmraSrc,'mmra_bezier.m'),'file')==2, ...
    'MMRA shared src missing: keep the full bundled project structure.');
addpath(mmraSrc);

scene = urban500_scene();

% Reuse the existing scene checks before planning.
run(fullfile(root, 'run_urban_complex_500_checks.m'));

cfg = struct();
cfg.bounds_m = [5 495; 5 495; 5 scene.bounds_m(3,2)-5];
cfg.maxIterations = 6500;
cfg.maxIterationsAfterFirstSolution = 700;
cfg.maxStep_m = 24;
cfg.goalConnectRadius_m = 36;
cfg.goalBias = 0.12;
cfg.highAltitudeBias = 0.30;
% Sample a clear cruise band above the tallest inflated high-rise roof.
B = scene.buildings_m;
maxInflatedRoof_m = max(B(:,6)) + scene.uavSafetyRadius_m + 2;
cfg.highAltitudeRange_m = [maxInflatedRoof_m+7, scene.bounds_m(3,2)-6];
assert(cfg.highAltitudeRange_m(1)<cfg.highAltitudeRange_m(2), ...
    'No free high-altitude sampling band remains above the buildings.');
cfg.neighborGamma_m = 170;
cfg.neighborRadiusMin_m = 22;
cfg.neighborRadiusMax_m = 55;
cfg.extraClearance_m = 2;
cfg.uavRadius_m = scene.uavSafetyRadius_m;
cfg.centerlineClearance_m = cfg.uavRadius_m + cfg.extraClearance_m;
% Shared MMRA pruning and locally adaptive, collision-certified Bezier.
% Old Urban500 random shortcut is retained as a separate legacy function
% but is no longer the final postprocessor.
cfg.mmraPruneMode='shortest_visibility';
cfg.smoothMinRadius_m=10;     % minimum radius of accepted corner arcs
cfg.smoothMaxPitch_deg=75;    % tangent pitch limit for accepted arcs
cfg.smoothTrimFraction=0.44;  % ordinary interior corners
cfg.smoothTerminalTrimFraction=0.96;  % final corner: use available goal leg
cfg.mmraTerminalRepair=true;  % use alternative raw RRT* waypoint if needed
cfg.mmraTerminalRepairMaxCandidates=40;
cfg.mmraTerminalRepairMaxExtra_m=35;  % detour budget; never relax safety
cfg.smoothMaxChord_m=2.5;     % output sampling interval, in metres
cfg.smoothMaxSagitta_m=0.10;  % heuristic sampling tolerance, in metres
cfg.smoothMinAngle_deg=2.0;
cfg.seedBase = scene.seed + 1000;
cfg.verbose = true;

% Inflate each axis-aligned building box by the UAV radius plus buffer.
% A path centreline outside these inflated boxes has at least the requested
% centreline clearance from the original building boxes.
inflatedB = B;
inflatedB(:,1) = inflatedB(:,1) - cfg.centerlineClearance_m;
inflatedB(:,2) = inflatedB(:,2) + cfg.centerlineClearance_m;
inflatedB(:,3) = inflatedB(:,3) - cfg.centerlineClearance_m;
inflatedB(:,4) = inflatedB(:,4) + cfg.centerlineClearance_m;
inflatedB(:,5) = inflatedB(:,5) - cfg.centerlineClearance_m;
inflatedB(:,6) = inflatedB(:,6) + cfg.centerlineClearance_m;

% Validate the five launch and goal points against the inflated geometry.
for k = 1:5
    assert(urban500_rrtstar_edge_free(scene.starts_m(k,:), ...
        scene.starts_m(k,:), inflatedB), ...
        'UAV %d start is inside an inflated building.', k);
    assert(urban500_rrtstar_edge_free(scene.goals_m(k,:), ...
        scene.goals_m(k,:), inflatedB), ...
        'UAV %d goal is inside an inflated building.', k);
end

paths = cell(5,1);
rawPaths = cell(5,1);
prunedPaths = cell(5,1);
pathStages = cell(5,1);
postprocessStats = cell(5,1);
records = repmat(struct('uav',0,'success',false,'method','', ...
    'iterations',0,'nodeCount',0,'waypoints',0,'pathLength_m',NaN, ...
    'planningTime_s',NaN,'postprocessTime_s',NaN, ...
    'totalTime_s',NaN,'maxAltitude_m',NaN, ...
    'guaranteedCenterlineClearance_m',NaN, ...
    'guaranteedVehicleSurfaceClearance_m',NaN, ...
    'rawWaypoints',0,'prunedWaypoints',0,'roundedCorners',0, ...
    'eligibleCorners',0,'maxTurnBefore_deg',NaN,'maxTurnAfter_deg',NaN, ...
    'minimumAcceptedCurveRadius_m',NaN, ...
    'allEligibleCornersSmoothed',false, ...
    'terminalRepairAttempted',false,'terminalRepairSucceeded',false, ...
    'terminalRepairCandidatesTested',0), 5, 1);

fprintf('\n=== URBAN500: FIVE-UAV 3-D RRT* (STATIC BUILDINGS) ===\n');
fprintf('Building count: %d | centreline clearance: %.1f m\n', ...
    size(B,1), cfg.centerlineClearance_m);
fprintf('Dynamic spheres are displayed in the scene but are not yet used by this planner.\n');
fprintf('Inter-UAV collision avoidance is not part of this first stage.\n\n');

for k = 1:5
    fprintf('Planning UAV %d ...\n', k);
    [path, info] = urban500_rrtstar_plan( ...
        scene.starts_m(k,:), scene.goals_m(k,:), inflatedB, cfg, ...
        cfg.seedBase + k);

    if isempty(path)
        error(['UAV %d planning failed. No result cache was written. ' ...
            'Increase maxIterations or inspect the scene geometry.'], k);
    end

    % Reuse MMRA SHARED prune + upgraded adaptive Bezier. The adapter
    % injects Urban500's EXACT inflated-AABB oracle and conservative
    % continuous-curve certificate, then verifies every output edge.
    postStart=tic;
    [path,stage,post] = urban500_mmra_postprocess(path,inflatedB,cfg);
    postTime=toc(postStart);
    rawPaths{k}=stage.raw;
    prunedPaths{k}=stage.pruned;
    pathStages{k}=stage;
    postprocessStats{k}=post;

    % Final independent edge-by-edge verification.
    for j = 1:size(path,1)-1
        assert(urban500_rrtstar_edge_free(path(j,:), path(j+1,:), inflatedB), ...
            'UAV %d final path failed collision verification at edge %d.', k, j);
    end

    paths{k} = path;
    seg = diff(path,1,1);
    pathLength = sum(sqrt(sum(seg.^2,2)));

    records(k).uav = k;
    records(k).success = true;
    records(k).method = info.method;
    records(k).iterations = info.iterations;
    records(k).nodeCount = info.nodeCount;
    records(k).waypoints = size(path,1);
    records(k).pathLength_m = pathLength;
    records(k).planningTime_s = info.planningTime_s;  % search only
    records(k).postprocessTime_s = postTime;
    records(k).totalTime_s = info.planningTime_s+postTime;
    records(k).maxAltitude_m = max(path(:,3));
    records(k).guaranteedCenterlineClearance_m = cfg.centerlineClearance_m;
    records(k).guaranteedVehicleSurfaceClearance_m = cfg.extraClearance_m;
    records(k).rawWaypoints=post.rawWaypoints;
    records(k).prunedWaypoints=post.prunedWaypoints;
    records(k).roundedCorners=post.roundedCorners;
    records(k).eligibleCorners=post.totalCorners;
    records(k).maxTurnBefore_deg=post.maxAngleBefore_deg;
    records(k).maxTurnAfter_deg=post.maxAngleAfter_deg;
    records(k).minimumAcceptedCurveRadius_m=post.minAcceptedCurveRadius_m;
    records(k).allEligibleCornersSmoothed=post.allEligibleCornersSmoothed;
    records(k).terminalRepairAttempted=post.terminalRepair.attempted;
    records(k).terminalRepairSucceeded=post.terminalRepair.succeeded;
    records(k).terminalRepairCandidatesTested=post.terminalRepair.candidatesTested;

    fprintf(['UAV %d: success=1, method=%s, length=%.1f m, ' ...
        'waypoints=%d, nodes=%d, iterations=%d, time=%.2f s, maxZ=%.1f m\n'], ...
        k, info.method, pathLength, size(path,1), info.nodeCount, ...
        info.iterations, info.planningTime_s, max(path(:,3)));
    fprintf('  MMRA: prune=%d->%d nodes | rounded=%d/%d corners | max turn %.1f->%.1f deg\n', ...
        post.rawWaypoints,post.prunedWaypoints, ...
        post.roundedCorners,post.totalCorners, ...
        post.maxAngleBefore_deg,post.maxAngleAfter_deg);
    if post.terminalRepair.attempted
        fprintf('  Terminal radius repair: %s | candidates=%d | extra path=%.2f m\n', ...
            post.terminalRepair.status,post.terminalRepair.candidatesTested, ...
            post.terminalRepair.extraLength_m);
    end
    if ~isempty(post.failedCornerIndices)
        for jj=1:numel(post.failedCornerIndices)
            fprintf('  UNRESOLVED corner %d: %s | maximum feasible trim radius %.2f m\n', ...
                post.failedCornerIndices(jj),post.failedCornerReasons{jj}, ...
                post.failedCornerMaxRadius_m(jj));
        end
    end
    fprintf('  Search %.2f s | MMRA postprocessing %.2f s\n', ...
        info.planningTime_s,postTime);
end

% Save to a new result directory. Existing map results are untouched.
outDir = fullfile(root, 'results_urban_complex_500_v3_rrtstar_mmra_radius_repair');
if ~exist(outDir, 'dir')
    mkdir(outDir);
end
resultFile = fullfile(outDir, 'Urban500_RRTstar_5U_static.mat');
save(resultFile, 'scene', 'cfg', 'paths', 'rawPaths', 'prunedPaths', ...
    'records', 'postprocessStats', '-v7');

uav = (1:5)';
method = string({records.method})';
pathLength_m = [records.pathLength_m]';
planningTime_s = [records.planningTime_s]';
postprocessTime_s = [records.postprocessTime_s]';
totalTime_s = [records.totalTime_s]';
waypoints = [records.waypoints]';
maxAltitude_m = [records.maxAltitude_m]';
centerlineClearance_m = [records.guaranteedCenterlineClearance_m]';
vehicleSurfaceClearance_m = [records.guaranteedVehicleSurfaceClearance_m]';
rawWaypoints=[records.rawWaypoints]';
prunedWaypoints=[records.prunedWaypoints]';
roundedCorners=[records.roundedCorners]';
eligibleCorners=[records.eligibleCorners]';
maxTurnBefore_deg=[records.maxTurnBefore_deg]';
maxTurnAfter_deg=[records.maxTurnAfter_deg]';
minAcceptedCurveRadius_m=[records.minimumAcceptedCurveRadius_m]';
allEligibleCornersSmoothed=[records.allEligibleCornersSmoothed]';
terminalRepairAttempted=[records.terminalRepairAttempted]';
terminalRepairSucceeded=[records.terminalRepairSucceeded]';
terminalRepairCandidatesTested=[records.terminalRepairCandidatesTested]';
metrics = table(uav, method, pathLength_m, planningTime_s, ...
    postprocessTime_s,totalTime_s, ...
    waypoints, maxAltitude_m, centerlineClearance_m, ...
    vehicleSurfaceClearance_m,rawWaypoints,prunedWaypoints, ...
    roundedCorners,eligibleCorners,maxTurnBefore_deg,maxTurnAfter_deg, ...
    minAcceptedCurveRadius_m,allEligibleCornersSmoothed, ...
    terminalRepairAttempted,terminalRepairSucceeded, ...
    terminalRepairCandidatesTested);
writetable(metrics, fullfile(outDir, 'Urban500_RRTstar_5U_metrics.csv'));

% Draw the actual planned paths over the existing city geometry.
[fig, ax] = urban500_draw(scene, 0, 'ShowMotionLines', true);
hold(ax, 'on');
routeHandles = gobjects(5,1);
for k = 1:5
    p = paths{k};
    c = scene.routeColors(k,:);
    routeHandles(k) = plot3(ax, p(:,1), p(:,2), p(:,3), '-', ...
        'Color', c, 'LineWidth', 2.6, ...
        'DisplayName', sprintf('UAV %d', k));
end
legend(ax, routeHandles, 'Location', 'eastoutside');
title(ax, 'Urban500 V3 | MMRA safe smoothed 3-D routes | static buildings');
set(fig,'Name','Urban500 V3 | RRT* + MMRA safe smoothing');
try
    exportgraphics(fig, fullfile(outDir, ...
        'Urban500_RRTstar_5U_MMRA_smoothed_paths.png'), 'Resolution', 220);
catch
    saveas(fig, fullfile(outDir, 'Urban500_RRTstar_5U_MMRA_smoothed_paths.png'));
end

% Before / after overlay; may be rotated interactively in MATLAB.
urban500_mmra_comparison_plot(scene,pathStages, ...
    fullfile(outDir,'Urban500_RRTstar_5U_MMRA_before_after.png'));
fprintf('\nV3+MMRA: 5/5 routes passed static-building checks.\n');
fprintf('MAT result: %s\n', resultFile);
fprintf('CSV metrics: %s\n', fullfile(outDir, 'Urban500_RRTstar_5U_metrics.csv'));
fprintf('Path figure: %s\n', fullfile(outDir, 'Urban500_RRTstar_5U_MMRA_smoothed_paths.png'));
fprintf(['NOTE: This is static-building-aware independent planning. ' ...
    'Dynamic-obstacle avoidance and inter-UAV deconfliction are not yet claimed.\n']);
