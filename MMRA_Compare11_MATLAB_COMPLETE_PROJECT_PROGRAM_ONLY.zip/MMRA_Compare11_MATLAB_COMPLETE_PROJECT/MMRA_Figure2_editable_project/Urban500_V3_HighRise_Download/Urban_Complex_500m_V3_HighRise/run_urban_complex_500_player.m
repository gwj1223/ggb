function run_urban_complex_500_player()
%RUN_URBAN_COMPLEX_500_PLAYER Interactive urban 500 m moving-sphere preview.
% MATLAB R2023b: playback + time slider. No toolbox required.
root=fileparts(mfilename('fullpath'));
addpath(root);
scene=urban500_scene();
[fig,ax,h]=urban500_draw(scene,0,'ShowMotionLines',true);
set(fig,'Name','500 m V3 high-rise city - interactive moving obstacles');
set(ax,'Position',[0.055 0.15 0.88 0.80]);

sld=uicontrol('Parent',fig,'Style','slider','Units','normalized', ...
    'Position',[0.15 0.055 0.66 0.037], ...
    'Min',0,'Max',scene.duration_s,'Value',0, ...
    'SliderStep',[0.005 0.05],'Callback',@sliderChanged);
btn=uicontrol('Parent',fig,'Style','togglebutton', ...
    'String','PLAY','Units','normalized', ...
    'Position',[0.035 0.047 0.09 0.05], ...
    'Callback',@togglePlay);
txt=uicontrol('Parent',fig,'Style','text', ...
    'String','t = 0.0 s','BackgroundColor','w', ...
    'Units','normalized','Position',[0.83 0.05 0.12 0.042], ...
    'FontSize',11);
playing=false;
[sx,sy,sz]=sphere(22);

    function sliderChanged(src,~)
        updateAt(get(src,'Value'));
    end

    function togglePlay(src,~)
        playing=logical(get(src,'Value'));
        if ~playing
            set(src,'String','PLAY');
            return;
        end
        set(src,'String','STOP');
        if get(sld,'Value')>=scene.duration_s
            set(sld,'Value',0);
        end
        while playing && isgraphics(fig)
            t=get(sld,'Value');
            if t>=scene.duration_s, break; end
            t=min(scene.duration_s,t+0.6);
            set(sld,'Value',t);
            updateAt(t);
            pause(0.025);
            drawnow;
        end
        playing=false;
        if isgraphics(btn)
            set(btn,'Value',0,'String','PLAY');
        end
    end

    function updateAt(t)
        if ~isgraphics(fig), return; end
        for k=1:numel(scene.dynamic)
            ob=scene.dynamic(k);
            p=urban500_obstacle_position(ob,t);
            r=ob.radius_m;
            if isgraphics(h(k))
                set(h(k),'XData',p(1)+r*sx, ...
                    'YData',p(2)+r*sy,'ZData',p(3)+r*sz);
            end
        end
        if isgraphics(txt)
            set(txt,'String',sprintf('t = %.1f s',t));
        end
        title(ax,sprintf('500 x 500 m V3 high-rise city | %d buildings | 6 moving spheres | t = %.1f s', ...
            size(scene.buildings_m,1),t),'FontWeight','normal');
        drawnow limitrate;
    end
end
