function fig = urban500_mmra_comparison_plot(scene,stages,filename)
%URBAN500_MMRA_COMPARISON_PLOT Dashed pruning vs solid MMRA smoothing.
[fig,ax]=urban500_draw(scene,0,'ShowMotionLines',false);
set(fig,'Name','Urban500 V3 | before / after MMRA smoothing');
hold(ax,'on');
handles=gobjects(numel(stages),1);
for k=1:numel(stages)
    before=stages{k}.pruned;
    after=stages{k}.smoothed;
    col=scene.routeColors(k,:);
    % Gray dashed: original sharp-corner pruned path.
    plot3(ax,before(:,1),before(:,2),before(:,3),'--', ...
        'Color',[0.40 0.40 0.40],'LineWidth',0.85, ...
        'HandleVisibility','off');
    handles(k)=plot3(ax,after(:,1),after(:,2),after(:,3),'-', ...
        'Color',col,'LineWidth',2.7, ...
        'DisplayName',sprintf('UAV %d smooth',k));
end
legend(ax,handles,'Location','eastoutside');
title(ax,'Urban500 V3 | MMRA: dashed=pruned, solid=smoothed | static buildings');
if nargin>=3 && ~isempty(filename)
    try
        exportgraphics(fig,filename,'Resolution',200);
    catch
        saveas(fig,filename);
    end
end
end
