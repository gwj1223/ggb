function [safe,info] = urban500_interuav_pair_check(A,B,required_m)
%URBAN500_INTERUAV_PAIR_CHECK Exact closest approach of two timed polylines.
% A and B contain .positions_m (Nx3) and .times_s (Nx1), in seconds.
% Piecewise-linear motion; holds at initial pads and terminal goals.
% Checks continuous time, not just sampled/synchronized timestamps.
% The guarantee covers the timed POLYLINES, not unsampled Bezier curves.
if nargin<3,required_m=10;end
assert(isfinite(required_m) && required_m>0,'Invalid pair separation.');
validate(A);validate(B);
PA=double(A.positions_m);TA=double(A.times_s(:));
PB=double(B.positions_m);TB=double(B.times_s(:));
% A one-second postarrival tail also checks simultaneous terminal holding.
events=unique(sort([0;TA;TB;max(TA(end),TB(end))+1]));
best=inf;tbest=NaN;posA=[NaN NaN NaN];posB=posA;
for q=1:numel(events)-1
    t0=events(q);t1=events(q+1);
    if t1-t0<1e-12,continue;end
    a0=positionAt(PA,TA,t0);a1=positionAt(PA,TA,t1);
    b0=positionAt(PB,TB,t0);b1=positionAt(PB,TB,t1);
    r0=a0-b0;v=(a1-a0)-(b1-b0);
    vv=dot(v,v);
    if vv<1e-22
        u=0;
    else
        u=max(0,min(1,-dot(r0,v)/vv));
    end
    d=norm(r0+u*v);
    if d<best
        best=d;tbest=t0+u*(t1-t0);
        posA=a0+u*(a1-a0);posB=b0+u*(b1-b0);
    end
end
info=struct('minDistance_m',best,'minMargin_m',best-required_m, ...
    'criticalTime_s',tbest,'positionA_m',posA,'positionB_m',posB, ...
    'requiredSeparation_m',required_m);
safe=isfinite(best) && best>=required_m-1e-8;
end

function validate(tr)
assert(isstruct(tr)&&isfield(tr,'positions_m')&&isfield(tr,'times_s'), ...
    'Each UAV needs timestamped positions and times.');
P=tr.positions_m;T=tr.times_s(:);
assert(size(P,1)>=2&&size(P,2)==3&&size(P,1)==numel(T) && ...
    all(isfinite(P(:)))&&all(isfinite(T)) && ...
    abs(T(1))<1e-10&&all(diff(T)>=0), ...
    'Invalid timed UAV trajectory; its clock must begin at t=0.');
for j=1:numel(T)-1
    assert(T(j+1)>T(j)+1e-12 || norm(P(j+1,:)-P(j,:))<1e-9, ...
        'Zero-time movement is not allowed.');
end
end

function p=positionAt(P,T,t)
if t<=T(1),p=P(1,:);return;end
if t>=T(end),p=P(end,:);return;end
j=find(T<=t,1,'last');
j=min(j,numel(T)-1);
dt=T(j+1)-T(j);
assert(dt>1e-12,'Zero-duration trajectory segment.');
u=(t-T(j))/dt;
p=P(j,:)+u*(P(j+1,:)-P(j,:));
end
