function path = urban500_rrtstar_shortcut(path, boxes, attempts, seed)
%URBAN500_RRTSTAR_SHORTCUT Collision-checked random shortcut smoothing.
% Every accepted shortcut is verified against the same inflated boxes.
if size(path,1) <= 2 || attempts <= 0
    return;
end
rng(seed, 'twister');
for k = 1:attempts
    n = size(path,1);
    if n <= 2
        break;
    end
    i = randi(n-2);
    j = randi([i+2 n]);
    if urban500_rrtstar_edge_free(path(i,:),path(j,:),boxes)
        path = [path(1:i,:); path(j:end,:)];
    end
end
end
