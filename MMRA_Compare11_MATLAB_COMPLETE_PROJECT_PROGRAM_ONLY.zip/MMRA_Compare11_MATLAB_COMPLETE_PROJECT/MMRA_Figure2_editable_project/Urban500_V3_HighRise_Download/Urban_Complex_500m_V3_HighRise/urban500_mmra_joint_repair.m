function [Qbest,Pbest,stBest,audit] = ...
    urban500_mmra_joint_repair(Q,P,st,postCfg,cfg)
%URBAN500_MMRA_JOINT_REPAIR Fail-closed geometric repair after old MMRA.
% V2. User-provided Urban500 source is unchanged unless installed using the
% separate installer. This algorithm is opt-in via cfg.mmraJointRepair=true.
%
% Search scope: an unrounded original waypoint i and its *immediate* wing
% waypoints i-1 and i+1. First try single moves, then simultaneous pair
% moves. It is deterministic, seed-agnostic, and never changes endpoints.
% Intermediate proposals are merely screened and are NOT published.
% Only a whole-path, analytic G1/curvature/pitch-certified, strictly
% collision-free curve with unchanged endpoints can replace the input.
%
% This verifies STATIC buildings + geometric trajectory limits only. Fleet
% separation, traffic timing and physical dynamics remain distinct checks.
Qbest=Q; Pbest=P; stBest=st;
nFailure=numel(st.failedCornerIndices);
audit=struct('attempted',false,'succeeded',false, ...
    'status','not-needed','initialFailures',nFailure, ...
    'remainingFailures',nFailure,'proposalsGenerated',0, ...
    'candidatesEvaluated',0,'callbackErrors',0, ...
    'singleProposals',0,'pairProposals',0, ...
    'modifiedWaypointIndices',zeros(0,1), ...
    'oldWaypoints',zeros(0,3),'newWaypoints',zeros(0,3), ...
    'originalLength_m',routeLen(P), ...
    'repairedLength_m',routeLen(P), ...
    'certificateStatus','NOT_RUN','lastError','');
if nFailure==0 || st.fullySmoothed
    return;
end
if ~getField(postCfg,'mmraJointRepair',false)
    audit.status='disabled';return;
end
if ~isfield(postCfg,'edgeFreeFcn') || ...
        ~isa(postCfg.edgeFreeFcn,'function_handle') || ...
        ~isfield(postCfg,'curveFreeFcn') || ...
        ~isa(postCfg.curveFreeFcn,'function_handle') || ...
        exist('mmra_compare11_turnradius_validate','file')~=2
    audit.status='MISSING_REQUIRED_STRICT_ORACLE';return;
end
if ~isnumeric(Q) || size(Q,2)~=3 || size(Q,1)<3 || ...
        any(~isfinite(Q(:))) || ~isnumeric(P) || ...
        size(P,2)~=3 || size(P,1)<2 || any(~isfinite(P(:)))
    audit.status='INVALID_INPUT';return;
end
maxExtra=getField(postCfg,'mmraJointRepairMaxExtra_m',55);
maxProposals=getField(postCfg,'mmraJointRepairMaxProposals',30000);
maxEvaluations=getField(postCfg,'mmraJointRepairMaxEvaluations',500);
steps=getField(postCfg,'mmraJointRepairSteps_m', ...
    [1 2 3 5 7 10 14 20 28 38]);
assert(isscalar(maxExtra) && isfinite(maxExtra) && maxExtra>=0, ...
    'Joint repair extra length must be nonnegative.');
assert(isscalar(maxProposals) && isfinite(maxProposals) && ...
    maxProposals>=1 && maxProposals==floor(maxProposals));
assert(isscalar(maxEvaluations) && isfinite(maxEvaluations) && ...
    maxEvaluations>=1 && maxEvaluations==floor(maxEvaluations));
assert(isnumeric(steps) && isvector(steps) && ...
    all(isfinite(steps(:))) && all(steps(:)>0));
steps=unique(steps(:)','stable');
minRadius=max(10,getField(postCfg,'smoothMinRadius_m',10));
maxPitch=min(75,getField(postCfg,'smoothMaxPitch_deg',75));
trimFraction=getField(postCfg,'smoothTrimFraction',0.44);
terminalFraction=getField(postCfg,'smoothTerminalTrimFraction',trimFraction);
baseline=routeLen(P); qLength=routeLen(Q); n=size(Q,1);
startPoint=Q(1,:); endPoint=Q(end,:);
audit.attempted=true;
audit.status='NO_CERTIFIED_CANDIDATE';
budgetStop=false;
targets=unique(st.failedCornerIndices(:)','stable');
for idx=targets
    if idx<=1 || idx>=n,continue;end
    % Single corner and wing adjustments; changing the failed index alone
    % cannot repair every narrow corridor or mixed radius/pitch failure.
    for step=steps
        for j=[idx idx-1 idx+1]
            if j<=1 || j>=n,continue;end
            dirs=localDirections(Q,j);
            for d=1:size(dirs,1)
                trial=Q;
                trial(j,:)=trial(j,:)+step*dirs(d,:);
                if testProposal(trial,j,false),return;end
                if budgetStop,break;end
            end
            if budgetStop,break;end
        end
        if budgetStop,break;end
    end
    if budgetStop,break;end
    % Deterministically prioritize smaller coordinated movement totals.
    pairs=[idx-1 idx; idx idx+1; idx-1 idx+1];
    pairSteps=zeros(numel(steps)^2,4); t=0;
    for aa=1:numel(steps)
        for bb=1:numel(steps)
            t=t+1;
            pairSteps(t,:)=[steps(aa)+steps(bb), ...
                max(steps(aa),steps(bb)),steps(aa),steps(bb)];
        end
    end
    pairSteps=sortrows(pairSteps,[1 2 3]);
    for whichPair=1:size(pairs,1)
        j1=pairs(whichPair,1);j2=pairs(whichPair,2);
        if j1<=1 || j2>=n,continue;end
        dirs1=localDirections(Q,j1);
        dirs2=localDirections(Q,j2);
        for ss=1:size(pairSteps,1)
            step1=pairSteps(ss,3);step2=pairSteps(ss,4);
            for a=1:size(dirs1,1)
                for b=1:size(dirs2,1)
                    trial=Q;
                    trial(j1,:)=trial(j1,:)+step1*dirs1(a,:);
                    trial(j2,:)=trial(j2,:)+step2*dirs2(b,:);
                    if testProposal(trial,[j1 j2],true),return;end
                    if budgetStop,break;end
                end
                if budgetStop,break;end
            end
            if budgetStop,break;end
        end
        if budgetStop,break;end
    end
    if budgetStop,break;end
end
if budgetStop
    audit.status='SEARCH_BUDGET_EXHAUSTED_UNCERTIFIED';
end
% No candidate passed every check. Inputs are returned UNMODIFIED.

    function yes=testProposal(trial,changed,isPair)
        yes=false;
        if budgetStop,return;end
        if audit.proposalsGenerated>=maxProposals || ...
                audit.candidatesEvaluated>=maxEvaluations
            budgetStop=true;return;
        end
        audit.proposalsGenerated=audit.proposalsGenerated+1;
        if isPair
            audit.pairProposals=audit.pairProposals+1;
        else
            audit.singleProposals=audit.singleProposals+1;
        end
        if ~insideBounds(trial,cfg) || ...
                routeLen(trial)>qLength+maxExtra+5
            return;
        end
        if norm(trial(1,:)-startPoint)>1e-9 || ...
                norm(trial(end,:)-endPoint)>1e-9
            return;
        end
        % Radius and pitch feasibility at the ORIGINAL failed corner.
        % Using max trim can reject candidates that cannot possibly pass.
        if ~localCornerPotential(trial,idx,trimFraction, ...
                terminalFraction,minRadius,maxPitch)
            return;
        end
        % Check all altered edges against the REAL inflated urban boxes.
        affected=unique([changed(:)-1;changed(:)]);
        for edge=affected(:)'
            if edge<1 || edge>=n || ...
                    ~postCfg.edgeFreeFcn(trial(edge,:),trial(edge+1,:))
                return;
            end
        end
        audit.candidatesEvaluated=audit.candidatesEvaluated+1;
        try
            [smoothed,~,newSt]=mmra_bezier(trial,[],postCfg);
            if ~newSt.fullySmoothed || ...
                    ~isempty(newSt.failedCornerIndices) || ...
                    ~insideBounds(smoothed,cfg) || ...
                    routeLen(smoothed)>baseline+maxExtra+1e-8 || ...
                    ~mmra_postprocess_path_free(smoothed,[],postCfg)
                return;
            end
            if norm(smoothed(1,:)-startPoint)>1e-8 || ...
                    norm(smoothed(end,:)-endPoint)>1e-8
                return;
            end
            % Recheck EVERY analytic curve, not only sampled chords.
            controls=newSt.curveControls;
            for k=1:size(controls,1)
                if ~postCfg.curveFreeFcn(controls(k,1:3), ...
                        controls(k,4:6),controls(k,7:9))
                    return;
                end
            end
            cert=mmra_compare11_turnradius_validate( ...
                smoothed,controls,minRadius,maxPitch);
            audit.certificateStatus=cert.status;
            if ~cert.certified,return;end
            Qbest=trial; Pbest=smoothed; stBest=newSt;
            audit.succeeded=true;
            audit.remainingFailures=0;
            audit.modifiedWaypointIndices=changed(:);
            audit.oldWaypoints=Q(changed,:);
            audit.newWaypoints=trial(changed,:);
            audit.repairedLength_m=routeLen(smoothed);
            audit.status='CERTIFIED_STATIC_G1_RADIUS_PITCH_PENDING_FLEET';
            yes=true;
        catch ME
            % Fail closed on any geometry/validator exception.
            audit.callbackErrors=audit.callbackErrors+1;
            audit.lastError=ME.message;
        end
    end
end

function D=localDirections(Q,j)
a=Q(j,:)-Q(j-1,:);
b=Q(j+1,:)-Q(j,:);
la=norm(a);lb=norm(b);
if la<1e-10 || lb<1e-10
    D=[eye(3);-eye(3)];return;
end
u=a/la;v=b/lb;
base=[1 0 0;0 1 0;0 0 1;u;v;u+v;u-v;v-u; ...
    u(2) -u(1) 0;v(2) -v(1) 0];
D=zeros(0,3);
for k=1:size(base,1)
    t=base(k,:);
    if norm(t)<1e-8,continue;end
    t=t/norm(t);
    for sg=[1 -1]
        w=sg*t;
        if isempty(D) || all(sqrt(sum(bsxfun(@minus,D,w).^2,2))>1e-4)
            D(end+1,:)=w; %#ok<AGROW>
        end
    end
end
end

function good=localCornerPotential(Q,i,frac,terminalFrac,minRadius,maxPitch)
good=false;
if i<2 || i>=size(Q,1),return;end
a=Q(i-1,:);c=Q(i,:);b=Q(i+1,:);
vin=c-a;vout=b-c;
l1=norm(vin);l2=norm(vout);
if l1<1e-9 || l2<1e-9,return;end
u=vin/l1;v=vout/l2;
d=frac*min(l1,l2);
if i==size(Q,1)-1 && terminalFrac>frac
    d=terminalFrac*min(l1,l2);
end
S=c-d*u;E=c+d*v;
% Compute exact 3-D quadratic curvature and tangent pitch at maximum trim.
r=quadraticMinR(S,c,E);
if isnan(r) || r+1e-8<minRadius,return;end
if quadraticPitch(S,c,E)>maxPitch+1e-8,return;end
good=true;
end

function r=quadraticMinR(S,C,E)
u=C-S;v=E-C;w=v-u;
den=dot(w,w);
if den<1e-20,r=inf;return;end
t=max(0,min(1,-dot(u,w)/den));
speed=norm(u+t*w);
if speed<1e-10*max(norm(u),norm(v))
    r=0;return;
end
mag=norm(cross(u,w));
if mag<1e-14,r=inf;else,r=2*speed^3/mag;end
end

function p=quadraticPitch(S,C,E)
u=C-S;w=E-C-u;
a=dot(u(1:2),u(1:2));
b=dot(u(1:2),w(1:2));
c=dot(w(1:2),w(1:2));
z=u(3);wz=w(3);
t=[0;1];den=wz*b-z*c;
if abs(den)>1e-15
    root=(z*b-wz*a)/den;
    if root>0 && root<1,t(end+1,1)=root;end
end
if c>1e-15
    root=-b/c;
    if root>0 && root<1,t(end+1,1)=root;end
end
V=bsxfun(@plus,u,bsxfun(@times,t,w));
p=max(atan2d(abs(V(:,3)),sqrt(sum(V(:,1:2).^2,2))));
end

function valid=insideBounds(P,cfg)
valid=isnumeric(P) && size(P,2)==3 && size(P,1)>=2 && ...
    all(isfinite(P(:)));
if ~valid,return;end
if isfield(cfg,'bounds_m') && ~isempty(cfg.bounds_m)
    B=cfg.bounds_m;
    valid=isequal(size(B),[3 2]) && ...
        all(all(bsxfun(@ge,P,B(:,1)'-1e-8) & ...
                bsxfun(@le,P,B(:,2)'+1e-8)));
end
end

function d=routeLen(P)
d=0;
if isnumeric(P) && size(P,1)>1
    d=sum(sqrt(sum(diff(P,1,1).^2,2)));
end
end

function v=getField(s,name,defaultValue)
v=defaultValue;
if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
    v=s.(name);
end
end
