function [prunedBest,smoothedBest,statsBest,audit] = ...
    urban500_mmra_terminal_repair(rawPath,pruned,smoothed,stats,postCfg,cfg)
%URBAN500_MMRA_TERMINAL_REPAIR Radius-aware local post-pruning repair.
% When the LAST interior kink cannot meet the requested curve minimum
% radius, test alternative penultimate waypoints from the ORIGINAL RRT*
% path, not arbitrary fabricated points. Never relax clearance/radius.
% Each candidate must (1) lie between the same path-order anchors,
% (2) have collision-free connecting edges and stay in bounds,
% (3) smooth ALL eligible corners with the standard MMRA curvature gate,
% and (4) pass the same conservative STATIC continuous-curve certificate.
% If no feasible alternative exists, retain the certified but kinked path
% and let the caller report that it is NOT fully curvature-feasible.
prunedBest=pruned; smoothedBest=smoothed; statsBest=stats;
audit=struct('attempted',false,'succeeded',false,'candidatesTested',0, ...
    'rawIndexSelected',NaN,'originalVertex',zeros(1,3), ...
    'replacementVertex',zeros(1,3),'extraLength_m',0, ...
    'status','not-needed');
if ~fieldOr(postCfg,'mmraTerminalRepair',false)
    audit.status='disabled'; return;
end
if size(pruned,1)<3 || size(rawPath,1)<4 || stats.fullySmoothed
    return;
end
lastCorner=size(pruned,1)-1;
failed=stats.failedCornerIndices;
if numel(failed)~=1 || failed(1)~=lastCorner || ...
        ~strcmp(stats.failedCornerReasons{1},'radius')
    audit.status='not-single-terminal-radius-failure'; return;
end
audit.attempted=true;
audit.status='no-certified-alternative';
audit.originalVertex=pruned(end-1,:);
anchor=pruned(end-2,:); goal=pruned(end,:);
delta=sqrt(sum(bsxfun(@minus,rawPath,anchor).^2,2));
prevRawIdx=find(delta<1e-7,1,'last');
if isempty(prevRawIdx) || prevRawIdx>=size(rawPath,1)-1
    audit.status='missing-raw-interval'; return;
end
ids=(prevRawIdx+1:size(rawPath,1)-1)';
baseLen=pathLength(pruned);
% Prefer the shortest candidate detours, not the closest-to-goal alone.
estLen=zeros(numel(ids),1);
for j=1:numel(ids)
    q=rawPath(ids(j),:);
    estLen(j)=pathLength(pruned(1:end-2,:))+ ...
        norm(q-anchor)+norm(goal-q);
end
[~,ord]=sort(estLen);
maxCandidates=fieldOr(postCfg,'mmraTerminalRepairMaxCandidates',40);
maxExtra=fieldOr(postCfg,'mmraTerminalRepairMaxExtra_m',35);
assert(isfinite(maxCandidates) && maxCandidates>=1 && ...
    maxCandidates==floor(maxCandidates),'Invalid terminal repair candidates.');
assert(isfinite(maxExtra) && maxExtra>=0,'Invalid terminal repair budget.');
maxLen=baseLen+maxExtra;
bestScore=Inf;
for j=1:min(numel(ord),maxCandidates)
    id=ids(ord(j));
    q=rawPath(id,:);
    if norm(q-pruned(end-1,:))<1e-7 || estLen(ord(j))>maxLen+1e-9
        continue;
    end
    % Confirm both newly introduced edges with the SAME inflated-AABB
    % collision oracle (this is not an unconstrained spline shortcut).
    if ~postCfg.edgeFreeFcn(anchor,q) || ~postCfg.edgeFreeFcn(q,goal)
        continue;
    end
    trial=[pruned(1:end-2,:);q;goal];
    if ~insideBounds(trial,cfg) || ...
            ~mmra_postprocess_path_free(trial,[],postCfg)
        continue;
    end
    audit.candidatesTested=audit.candidatesTested+1;
    [curve,~,trialStats]=mmra_bezier(trial,[],postCfg);
    if ~trialStats.fullySmoothed || ...
            ~mmra_postprocess_path_free(curve,[],postCfg) || ...
            ~insideBounds(curve,cfg) || norm(curve(1,:)-rawPath(1,:))>1e-8 || ...
            norm(curve(end,:)-rawPath(end,:))>1e-8
        continue;
    end
    score=pathLength(curve);
    if score<bestScore-1e-10
        bestScore=score;
        prunedBest=trial;
        smoothedBest=curve;
        statsBest=trialStats;
        audit.succeeded=true;
        audit.rawIndexSelected=id;
        audit.replacementVertex=q;
        audit.extraLength_m=score-pathLength(smoothed);
        audit.status='certified-terminal-repair';
    end
end
end

function b=insideBounds(P,cfg)
b=true;
if isfield(cfg,'bounds_m') && ~isempty(cfg.bounds_m)
    lim=cfg.bounds_m;
    b=all(all(bsxfun(@ge,P,lim(:,1)'-1e-8) & ...
        bsxfun(@le,P,lim(:,2)'+1e-8)));
end
end

function val=fieldOr(cfg,name,defaultVal)
val=defaultVal;
if isfield(cfg,name) && ~isempty(cfg.(name)), val=cfg.(name); end
end

function len=pathLength(P)
len=0;
if size(P,1)>=2, len=sum(sqrt(sum(diff(P,1,1).^2,2))); end
end
