function [Qbest,Pbest,stBest,audit] = ...
    urban500_mmra_local_repair(Q,P,st,postCfg,cfg)
%URBAN500_MMRA_LOCAL_REPAIR Reposition failed corners; certify entire route.
% Only invoked AFTER standard MMRA pruning, adaptive Bezier smoothing and
% terminal repair. No changes to building boxes, safety margin, endpoints,
% 10 m min radius, 75 deg pitch limit, or RRT* search.
%
% Candidate vertex positions are deterministic offsets from an existing
% failed vertex; each new incident EDGE is checked against the original
% inflated AABBs before the whole path is re-smoothed and verified.
% Candidate is accepted only if the number of unroundable corners drops.
% The FINAL route must pass an independent analytic curvature/G1/pitch
% check. If not, the ORIGINAL input is returned unchanged (fail closed).
%
% This is an ADDITIONAL waypoint repair method and must be reported as
% such, not retroactively attributed to the original MMRA baseline.
Qbest=Q;Pbest=P;stBest=st;
n0=numel(st.failedCornerIndices);
audit=struct('attempted',false,'succeeded',false, ...
    'initialFailures',n0,'remainingFailures',n0, ...
    'candidatesEvaluated',0,'cornersRelocated',zeros(0,1), ...
    'originalWaypoints',zeros(0,3), ...
    'newWaypoints',zeros(0,3),'oldLength_m',pathLength(P), ...
    'newLength_m',pathLength(P),'independentCertificate','not-run', ...
    'status','not-needed');
if n0==0 || st.fullySmoothed,return;end
if ~getOpt(postCfg,'mmraLocalRepair',true)
    audit.status='disabled';return;
end
if ~isfield(postCfg,'edgeFreeFcn') || ...
        isempty(postCfg.edgeFreeFcn) || ...
        ~isfield(postCfg,'curveFreeFcn') || isempty(postCfg.curveFreeFcn)
    audit.status='missing-strict-collision-oracle';return;
end
% Independent validator is required before modifying the returned path.
if exist('mmra_compare11_turnradius_validate','file')~=2
    audit.status='independent-validator-unavailable';return;
end
maxExtra=getOpt(postCfg,'mmraLocalRepairMaxExtra_m',55);
maxPasses=getOpt(postCfg,'mmraLocalRepairMaxPasses',2);
maxCandidates=getOpt(postCfg,'mmraLocalRepairMaxCandidates',550);
assert(isfinite(maxExtra) && maxExtra>=0);
assert(isfinite(maxPasses) && maxPasses==floor(maxPasses) && maxPasses>=1);
assert(isfinite(maxCandidates) && maxCandidates==floor(maxCandidates) && ...
    maxCandidates>=1);
audit.attempted=true;
audit.status='no-fully-certified-repair';
maxLen=pathLength(P)+maxExtra;
oldStart=Q(1,:);oldGoal=Q(end,:);
for pass=1:maxPasses
    if stBest.fullySmoothed,break;end
    targets=unique(stBest.failedCornerIndices(:)','stable');
    progress=false;
    for ii=1:numel(targets)
        i=targets(ii);
        if i<=1 || i>=size(Qbest,1),continue;end
        nFail=numel(stBest.failedCornerIndices);
        candidates=generateCandidates(Qbest,i);
        bestFail=nFail;bestLength=inf;bestQ=[];bestP=[];bestSt=[];
        nToTry=min(size(candidates,1),maxCandidates);
        for k=1:nToTry
            q=candidates(k,:);
            if norm(q-Qbest(i,:))<1e-7 || ~withinBounds(q,cfg),continue;end
            if ~postCfg.edgeFreeFcn(Qbest(i-1,:),q) || ...
               ~postCfg.edgeFreeFcn(q,Qbest(i+1,:))
                continue;
            end
            trial=Qbest;trial(i,:)=q;
            % These two modified edges are free; previous unaffected edges
            % remain from the certified original pruned route.
            if pathLength(trial)>maxLen+maxExtra,continue;end
            audit.candidatesEvaluated=audit.candidatesEvaluated+1;
            [candidate,~,newStats]=mmra_bezier(trial,[],postCfg);
            nf=numel(newStats.failedCornerIndices);
            if nf>=nFail,continue;end
            if ~withinBounds(candidate,cfg) || ...
                    ~mmra_postprocess_path_free(candidate,[],postCfg) || ...
                    pathLength(candidate)>maxLen+1e-8
                continue;
            end
            if newStats.fullySmoothed
                v=mmra_compare11_turnradius_validate(candidate, ...
                    newStats.curveControls, ...
                    getOpt(postCfg,'smoothMinRadius_m',10), ...
                    getOpt(postCfg,'smoothMaxPitch_deg',75));
                if ~v.certified,continue;end
            end
            % Lexicographic: fewer unroundable corners, then shorter
            % pruned path. This removes a failure without a large detour.
            candidateLength=pathLength(trial);
            if nf<bestFail || (nf==bestFail && ...
                    candidateLength<bestLength-1e-9)
                bestFail=nf;bestLength=candidateLength;
                bestQ=trial;bestP=candidate;bestSt=newStats;
            end
        end
        if ~isempty(bestQ)
            audit.cornersRelocated(end+1,1)=i; %#ok<AGROW>
            audit.originalWaypoints(end+1,:)=Qbest(i,:); %#ok<AGROW>
            audit.newWaypoints(end+1,:)=bestQ(i,:); %#ok<AGROW>
            Qbest=bestQ;Pbest=bestP;stBest=bestSt;
            progress=true;
        end
    end
    if ~progress,break;end
end
% A partial repair must never be published as a full geometric success.
if stBest.fullySmoothed && all(abs(Qbest(1,:)-oldStart)<1e-9) && ...
        all(abs(Qbest(end,:)-oldGoal)<1e-9) && ...
        withinBounds(Pbest,cfg) && ...
        mmra_postprocess_path_free(Pbest,[],postCfg) && ...
        pathLength(Pbest)<=maxLen+1e-8
    independent=mmra_compare11_turnradius_validate(Pbest, ...
        stBest.curveControls, ...
        getOpt(postCfg,'smoothMinRadius_m',10), ...
        getOpt(postCfg,'smoothMaxPitch_deg',75));
    audit.independentCertificate=independent.status;
    if independent.certified
        audit.succeeded=true;
        audit.status='VERIFIED_10M_G1_PITCH_LOCAL_REPAIR';
        audit.remainingFailures=0;
        audit.newLength_m=pathLength(Pbest);
        return;
    end
end
% Fail closed: retain the exactly original route/metadata if unsuccessful.
Qbest=Q;Pbest=P;stBest=st;
audit.remainingFailures=n0;
audit.newLength_m=pathLength(P);
audit.cornersRelocated=zeros(0,1);
audit.originalWaypoints=zeros(0,3);
audit.newWaypoints=zeros(0,3);
end

function C=generateCandidates(Q,i)
% Fixed deterministic search lattice in the local turn frame and XY axes.
a=Q(i-1,:);c=Q(i,:);b=Q(i+1,:);
u=(c-a)/norm(c-a);v=(b-c)/norm(b-c);
base=[u(1:2);v(1:2);u(1:2)+v(1:2); ...
    u(1:2)-v(1:2);v(1:2)-u(1:2); ...
    1 0;0 1;1 1;1 -1];
dirs=zeros(0,2);
for j=1:size(base,1)
    t=base(j,:);n=norm(t);
    if n<1e-8,continue;end
    t=t/n;
    for sg=[-1 1]
        q=sg*t;
        if isempty(dirs) || all(sqrt(sum(bsxfun(@minus,dirs,q).^2,2))>1e-4)
            dirs(end+1,:)=q; %#ok<AGROW>
        end
    end
end
C=zeros(0,3);
for distance=[5 10 15 25 40 60 90 130]
    for zFraction=[0 .5 -.5 1 -1]
        horizontal=distance*sqrt(max(0,1-zFraction^2));
        if horizontal<1e-12
            C(end+1,:)=c+[0 0 distance*zFraction]; %#ok<AGROW>
        else
            xyz=horizontal*dirs;
            C=[C;[bsxfun(@plus,xyz,c(1:2)), ...
                repmat(c(3)+distance*zFraction,size(dirs,1),1)]]; %#ok<AGROW>
        end
    end
end
end

function ok=withinBounds(P,cfg)
ok=all(isfinite(P(:))) && size(P,2)==3;
if ~ok,return;end
if isfield(cfg,'bounds_m') && ~isempty(cfg.bounds_m)
    B=cfg.bounds_m;
    ok=all(all(bsxfun(@ge,P,B(:,1)'-1e-8) & ...
        bsxfun(@le,P,B(:,2)'+1e-8)));
end
end

function d=pathLength(P)
d=0;
if size(P,1)>1,d=sum(sqrt(sum(diff(P,1,1).^2,2)));end
end
function x=getOpt(s,key,defaultValue)
x=defaultValue;
if isfield(s,key) && ~isempty(s.(key)),x=s.(key);end
end
