Urban500 3-D RRT* Add-on
========================

This add-on adds a first-stage static-building-aware 3-D RRT* planner.
It does not replace or edit any original Urban_Complex_500m_V2 file.

Install
-------
Copy these four .m files into the existing Urban_Complex_500m_V3_HighRise folder:

  run_urban500_rrtstar_5u.m
  urban500_rrtstar_plan.m
  urban500_rrtstar_edge_free.m
  urban500_rrtstar_shortcut.m
  run_urban500_rrtstar_selftest.m

Run from MATLAB R2023b with the Urban_Complex_500m_V3_HighRise folder as current folder:

  run('run_urban500_rrtstar_selftest.m')
  run('run_urban500_rrtstar_5u.m')

The planner reads the existing urban500_scene.m and urban500_draw.m.
It uses all 67 axis-aligned building boxes and inflates them by 5 m:
3 m UAV safety radius plus 2 m additional buffer.
The segment collision test uses a 3-D slab intersection test against the
inflated boxes. Shortcut smoothing only accepts collision-free segments.

Outputs are written to a NEW directory:

  results_urban_complex_500_v3_rrtstar/

Files:
  Urban500_RRTstar_5U_static.mat
  Urban500_RRTstar_5U_metrics.csv
  Urban500_RRTstar_5U_static_paths.png

Scope and limitations
---------------------
This first stage plans each UAV independently around static buildings.
The six moving spheres remain visible in the map, but are NOT included in
this first-stage planner. Inter-UAV separation, launch scheduling, dynamic
obstacle prediction, speed control and local dynamic replanning are NOT
implemented in this add-on. Do not describe this result as a completed
multi-UAV dynamic-avoidance experiment.

The planner reports whether a route came from RRT*, a clear direct segment,
or a conservative high-altitude fallback. These methods are kept distinct
in the saved metrics.

The source was statically reviewed and a Python geometry/algorithm prototype
was exercised against the supplied scene data. MATLAB R2023b execution is
still required to confirm local runtime and rendering.

2026-11 MMRA shared postprocess upgrade
---------------------------------------
The updated full project now links Urban500 V3 to the EXACT shared MMRA
src/mmra_prune.m and src/mmra_bezier.m. These are NOT stand-alone V3 files:
keep the entire MMRA_Figure2_editable_project root with its src folder.

For fast comparison of the archived five routes:
  run('run_urban500_mmra_selftest.m')
  run('run_urban500_mmra_saved_demo.m')
For complete RRT* search and MMRA postprocessing:
  run('run_urban500_rrtstar_5u.m')

New output folders:
  results_urban_complex_500_v3_rrtstar_mmra_demo/
  results_urban_complex_500_v3_rrtstar_mmra/

The old random shortcut remains available for legacy study, but is no
longer the main postprocessor. The city now uses a recursive convex-hull
certificate for continuous quadratic curves versus static inflated AABBs.
Dynamic spheres, multi-UAV conflicts, accelerations and flight control
are explicitly out of scope. If a corner cannot be safely rounded, it
remains sharp and allEligibleCornersSmoothed is false.
