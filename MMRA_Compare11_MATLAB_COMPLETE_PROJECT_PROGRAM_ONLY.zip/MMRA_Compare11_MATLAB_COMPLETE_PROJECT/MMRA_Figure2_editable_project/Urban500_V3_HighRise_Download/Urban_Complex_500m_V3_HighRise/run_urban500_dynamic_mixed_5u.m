%% RUN_URBAN500_DYNAMIC_MIXED_5U - dynamic-aware Urban500 V3.2 experiment.
% Keep the original static RRT* + MMRA-Bezier as spatial route generator.
% This new, opt-in experiment adds ten moving SOLID obstacles and true
% time-dependent collision checks, followed by speed, launch-delay, hover,
% and (if needed) conflict-informed spatial replanning.
%
% IMPORTANT: no inter-UAV coordination, trajectory acceleration limits,
% rotating obstacles, sensor uncertainty or online closed-loop control.
root=fileparts(mfilename('fullpath'));
addpath(root);
mmraSrc=fullfile(fileparts(fileparts(root)),'src');
assert(exist(fullfile(mmraSrc,'mmra_bezier.m'),'file')==2, ...
    'MMRA source code missing: keep full project folder structure.');
addpath(mmraSrc);
run(fullfile(root,'run_urban500_mixed_dynamic_checks.m'));
scene=urban500_scene_mixed_dynamic();

% Prefer most recent verified static routes. If missing, generate them using
% the original and unmodified static-planning entry point.
staticFile=fullfile(root, ...
    'results_urban_complex_500_v3_rrtstar_mmra_radius_repair', ...
    'Urban500_RRTstar_5U_static.mat');
if exist(staticFile,'file')~=2
    fprintf('No upgraded static result found. Running RRT* + MMRA first ...\n');
    run(fullfile(root,'run_urban500_rrtstar_5u.m'));
end
assert(exist(staticFile,'file')==2,'Upgraded static MAT result not found.');
base=load(staticFile,'paths','cfg');
% The legacy RRT* script executes in this workspace and resets 'scene' to
% its six-sphere static benchmark. Restore the opt-in mixed scene ALWAYS.
scene=urban500_scene_mixed_dynamic();
assert(numel(scene.dynamic)==10,'Mixed obstacle scene was not restored.');
assert(numel(base.paths)==5,'Expected five planned static routes.');
oldCfg=base.cfg;
B=scene.buildings_m;
clearance=scene.uavSafetyRadius_m+oldCfg.extraClearance_m;
inflatedB=bsxfun(@plus,B,[-clearance clearance -clearance clearance ...
    -clearance clearance]);

opts=struct();
opts.dynamicRequiredClearance_m=clearance; % UAV radius + 2 m buffer
opts.dynamicSpeeds_mps=[11 9 7];
opts.dynamicDepartureStep_s=2;
opts.dynamicMaxDeparture_s=60;
opts.dynamicLocalWaitStep_s=1;
opts.dynamicMaxLocalWait_s=40;
opts.dynamicMaxTotalWait_s=120;
opts.dynamicMaxSpatialReroutes=4;
opts.seedBase=oldCfg.seedBase+30000;

paths=cell(5,1);
timedPaths=cell(5,1);
dynamicStats=cell(5,1);
spatialSource=cell(5,1);
spatialInfo=cell(5,1);

fprintf('\n=== URBAN500 V3.2 | 5 UAVs | MOVING MIXED OBSTACLES ===\n');
fprintf('%s; UAV centreline-to-solid requirement %.1f m.\n', ...
    urban500_dynamic_count_label(scene),clearance);
fprintf('Scheduling is independent for each UAV; inter-UAV avoidance is NOT enabled.\n');
for k=1:5
    fprintf('\nScheduling UAV %d ...\n',k);
    path=base.paths{k};
    assert(norm(path(1,:)-scene.starts_m(k,:))<1e-8 && ...
        norm(path(end,:)-scene.goals_m(k,:))<1e-8, ...
        'Loaded static route %d does not match current mission.',k);
    verifyStatic(path,inflatedB,k);
    [traj,stat]=urban500_dynamic_schedule(path,scene,opts);
    source='existing-MMRA-smoothed';
    info=struct('spatialReroutes',0,'proxyObstacle',0, ...
        'allSpatialCornersSmoothed',true);
    if ~stat.success
        fprintf('  No safe departure/speed/hold schedule: trying conflict-informed reroutes.\n');
        for trial=1:opts.dynamicMaxSpatialReroutes
            % A local stationary proxy of the colliding SOLID at its
            % conflict time biases the *static* RRT* away from the dynamic
            % hazard. Candidate still requires exact timed verification.
            j=stat.baselineCriticalObstacle;
            if j<1,break;end
            ob=scene.dynamic(j);
            c=urban500_obstacle_position(ob,stat.baselineCriticalTime_s);
            R=dynamicBoundRadius(ob)+clearance+2;
            proxy=[c(1)-R c(1)+R c(2)-R c(2)+R c(3)-R c(3)+R];
            % Slight variation allows distinct spatial corridor choices.
            pad=(trial-1)*2;
            proxy=proxy+[-pad pad -pad pad -pad pad];
            testBoxes=[inflatedB;proxy]; %#ok<AGROW>
            if ~urban500_rrtstar_edge_free(scene.starts_m(k,:), ...
                    scene.starts_m(k,:),testBoxes) || ...
                    ~urban500_rrtstar_edge_free(scene.goals_m(k,:), ...
                    scene.goals_m(k,:),testBoxes)
                continue;
            end
            [raw,~]=urban500_rrtstar_plan(scene.starts_m(k,:), ...
                scene.goals_m(k,:),testBoxes,oldCfg, ...
                opts.seedBase+100*k+trial);
            if isempty(raw),continue;end
            [candidate,~,post]=urban500_mmra_postprocess(raw,testBoxes,oldCfg);
            if ~post.allEligibleCornersSmoothed
                fprintf('  Reroute %d skipped: an unsafe corner remained.\n',trial);
                continue;
            end
            [candidateTraj,candidateStats]=urban500_dynamic_schedule( ...
                candidate,scene,opts);
            if candidateStats.success
                path=candidate;
                traj=candidateTraj;
                stat=candidateStats;
                source=sprintf('dynamic-conflict-spatial-reroute-%d',trial);
                info.spatialReroutes=trial;
                info.proxyObstacle=j;
                info.allSpatialCornersSmoothed=post.allEligibleCornersSmoothed;
                break;
            end
        end
    end
    if ~stat.success
        error(['UAV %d: no certified dynamic schedule found. ' ...
            'Do not interpret a static-only route as safe. ' ...
            'Adjust temporal planning budget or introduce a full 4D RRT*.'],k);
    end
    % Independent final verification of *every* space-time segment.
    verifyStatic(path,inflatedB,k);
    [allSafe,cert]=urban500_dynamic_path_check( ...
        traj.positions_m,traj.times_s,scene,clearance,false);
    assert(allSafe,'UAV %d failed continuous-time dynamic recheck.',k);
    assert(max(vecnorm(diff(traj.positions_m,1,1),2,2)./ ...
        max(diff(traj.times_s),eps))<=max(opts.dynamicSpeeds_mps)+1e-7, ...
        'UAV %d violated speed ceiling.',k);
    paths{k}=path;
    timedPaths{k}=traj;
    dynamicStats{k}=stat;
    spatialSource{k}=source;
    spatialInfo{k}=info;
    if stat.baselineConflictingSegments>0
        ob=scene.dynamic(stat.baselineCriticalObstacle);
        fprintf('  conflict driver: %s (%s) near t=%.1f s\n', ...
            ob.name,ob.type,stat.baselineCriticalTime_s);
    end
    fprintf(['  baseline: %d conflicting segments | min margin LB %.2f m\n' ...
        '  accepted: %s | launch %.1f s | speed %.1f m/s | ' ...
        'holds %d (%.1f s) | arrival %.1f s | margin LB %.2f m\n'], ...
        stat.baselineConflictingSegments,stat.baselineMinMargin_m, ...
        stat.method,traj.departure_s,traj.speed_mps, ...
        traj.localWaitCount,traj.localWaitTime_s, ...
        traj.arrival_s,cert.minMargin_m);
end
outDir=fullfile(root,'results_urban_complex_500_v3_dynamic_mixed');
if exist(outDir,'dir')~=7,mkdir(outDir);end
resultFile=fullfile(outDir,'Urban500_RRTstar_5U_dynamic_mixed.mat');
save(resultFile,'scene','opts','paths','timedPaths', ...
    'dynamicStats','spatialSource','spatialInfo','staticFile','-v7');
ids=(1:5)';
source=string(spatialSource);
method=string(cellfun(@(x)x.method,dynamicStats,'UniformOutput',false));
departure_s=cellfun(@(x)x.departure_s,timedPaths);
arrival_s=cellfun(@(x)x.arrival_s,timedPaths);
speed_mps=cellfun(@(x)x.speed_mps,timedPaths);
pathLength_m=cellfun(@(x)x.pathLength_m,timedPaths);
localWaitCount=cellfun(@(x)x.localWaitCount,timedPaths);
localWaitTime_s=cellfun(@(x)x.localWaitTime_s,timedPaths);
baselineConflictingSegments=cellfun(@(x)x.baselineConflictingSegments,dynamicStats);
minimumCertifiedMarginLowerBound_m=cellfun(@(x)x.minCertifiedMargin_m,dynamicStats);
metrics=table(ids,source,method,departure_s,arrival_s,speed_mps, ...
    pathLength_m,localWaitCount,localWaitTime_s, ...
    baselineConflictingSegments,minimumCertifiedMarginLowerBound_m);
writetable(metrics,fullfile(outDir,'Urban500_dynamic_mixed_metrics.csv'));
% Timestamped flight routes for post-hoc inspection and animation outside
% MATLAB. These CSVs are the actual time-planned polylines used in checks.
for k=1:5
    tr=timedPaths{k};
    time_s=tr.times_s;
    x_m=tr.positions_m(:,1);
    y_m=tr.positions_m(:,2);
    z_m=tr.positions_m(:,3);
    flightTable=table(time_s,x_m,y_m,z_m);
    writetable(flightTable,fullfile(outDir, ...
        sprintf('UAV%d_timed_trajectory.csv',k)));
end


[fig,ax]=urban500_draw(scene,35,'ShowMotionLines',false);
hold(ax,'on');
h=gobjects(5,1);
for k=1:5
    P=paths{k};
    h(k)=plot3(ax,P(:,1),P(:,2),P(:,3),'-', ...
        'Color',scene.routeColors(k,:),'LineWidth',2.4, ...
        'DisplayName',sprintf('UAV %d',k));
end
legend(ax,h,'Location','eastoutside');
title(ax,'Urban500 V3.2 | mixed moving solids | certified timed 5-UAV routes');
set(fig,'Name','Urban500 V3.2 | mixed dynamic obstacle planning');
try
    exportgraphics(fig,fullfile(outDir,'Urban500_dynamic_mixed_paths_t35.png'), ...
        'Resolution',200);
catch
    saveas(fig,fullfile(outDir,'Urban500_dynamic_mixed_paths_t35.png'));
end
fprintf('\nUrban500 V3.2: 5/5 routes passed STATIC + TIME-DEPENDENT DYNAMIC checks.\n');
fprintf('MAT: %s\nCSV: %s\n',resultFile, ...
    fullfile(outDir,'Urban500_dynamic_mixed_metrics.csv'));
fprintf(['NOTE: Independent schedules, fixed-orientation moving solids; ' ...
    'NO inter-UAV collision avoidance or acceleration/jerk constraints.\n']);

function verifyStatic(P,B,k)
for jj=1:size(P,1)-1
    assert(urban500_rrtstar_edge_free(P(jj,:),P(jj+1,:),B), ...
        'UAV %d static collision at spatial edge %d.',k,jj);
end
end

function r=dynamicBoundRadius(ob)
switch lower(ob.type)
    case 'sphere',r=ob.radius_m;
    case 'cylinder',r=hypot(ob.radius_m,ob.halfHeight_m);
    case 'box',r=norm(ob.halfSize_m);
end
end
