%% RUN_URBAN500_MIXED_DYNAMIC_CHECKS - Opt-in 10-obstacle geometry checks.
% Preserves original V3.1 checks, with extra validation for moving boxes and
% finite vertical cylinders. Pair separation uses conservative enclosing
% spheres and exact relative linear-motion closest approach.
root=fileparts(mfilename('fullpath'));
addpath(root);
scene=urban500_scene_mixed_dynamic();
assert(size(scene.buildings_m,1)==67);
assert(numel(scene.dynamic)==10);
assert(strcmp(urban500_dynamic_count_label(scene), ...
    '6 spheres, 2 cylinders, 2 boxes'));
B=scene.buildings_m;
minNewBuildingGap=inf;
for k=1:numel(scene.dynamic)
    ob=scene.dynamic(k);
    assert(ob.t1_s>ob.t0_s,'Invalid moving-obstacle timestamps.');
    assert(all(isfinite([ob.p0_m ob.p1_m])));
    travel=norm(ob.p1_m-ob.p0_m);
    samples=max(101,ceil(travel/0.5)+1);
    for a=linspace(0,1,samples)
        t=ob.t0_s+a*(ob.t1_s-ob.t0_s);
        c=urban500_obstacle_position(ob,t);
        r=shapeBoundRadius(ob);
        assert(c(1)-r>0 && c(1)+r<500 && ...
            c(2)-r>0 && c(2)+r<500 && ...
            c(3)-r>=0 && c(3)+r<=200, ...
            'Moving object %d left the city bounding sphere.',k);
        for j=1:size(B,1)
            gap=solidBuildingGap(c,ob,B(j,:));
            if k<=6
                assert(gap>1.0-1e-8, ...
                    'Original sphere %d intersects building %d.',k,j);
            else
                minNewBuildingGap=min(minNewBuildingGap,gap);
                assert(gap>5-1e-6, ...
                    'New dynamic object %d is too close to building %d.',k,j);
            end
        end
    end
end
% Exact (up to floating-point arithmetic) closest relative CENTRE approach
% of two piecewise-linear motions. Their enclosing radii are a conservative
% lower bound for true finite-cylinder/box surface separation.
minPairLower=inf;
worstPair=[0 0];
worstTime_s=NaN;
for i=1:numel(scene.dynamic)-1
    a=scene.dynamic(i);
    ra=shapeBoundRadius(a);
    for j=i+1:numel(scene.dynamic)
        b=scene.dynamic(j);
        rb=shapeBoundRadius(b);
        cuts=unique(sort([0 scene.duration_s a.t0_s a.t1_s ...
            b.t0_s b.t1_s]));
        cuts=cuts(cuts>=0 & cuts<=scene.duration_s);
        for ii=1:numel(cuts)-1
            tA=cuts(ii);tB=cuts(ii+1);
            qA=urban500_obstacle_position(a,tA)-urban500_obstacle_position(b,tA);
            qB=urban500_obstacle_position(a,tB)-urban500_obstacle_position(b,tB);
            v=qB-qA;
            vv=dot(v,v);
            if vv>1e-24
                u=max(0,min(1,-dot(qA,v)/vv));
            else
                u=0;
            end
            gap=norm(qA+u*v)-ra-rb;
            if gap < minPairLower
                minPairLower=gap;
                worstPair=[i j];
                worstTime_s=tA+u*(tB-tA);
            end
        end
    end
end
if minPairLower<=2
    error('Urban500:MixedPairClearance', ...
        ['Moving obstacles #%d (%s) and #%d (%s) fail the ' ...
         'conservative 2 m pair-clearance check near t=%.2f s: ' ...
         'bounding-sphere lower bound %.3f m. ' ...
         'Check the two trajectories before running the planner.'], ...
        worstPair(1),scene.dynamic(worstPair(1)).name, ...
        worstPair(2),scene.dynamic(worstPair(2)).name, ...
        worstTime_s,minPairLower);
end
fprintf(['Urban500 V3.2 MIXED checks PASSED: %d buildings, %s.\n' ...
    'New solids to building min sampled clearance = %.3f m.\n' ...
    'Pair clearance conservative continuous lower bound = %.3f m.\n'], ...
    size(B,1),urban500_dynamic_count_label(scene), ...
    minNewBuildingGap,minPairLower);

function r=shapeBoundRadius(ob)
switch lower(ob.type)
    case 'sphere',r=ob.radius_m;
    case 'cylinder',r=hypot(ob.radius_m,ob.halfHeight_m);
    case 'box',r=norm(ob.halfSize_m);
end
end

function d=solidBuildingGap(c,ob,b)
lo=b([1 3 5]);hi=b([2 4 6]);
switch lower(ob.type)
    case 'sphere'
        outside=max(max(lo-c, c-hi),0);
        d=norm(outside)-ob.radius_m;
    case 'cylinder'
        dx=max([lo(1)-c(1),0,c(1)-hi(1)]);
        dy=max([lo(2)-c(2),0,c(2)-hi(2)]);
        dz=max([lo(3)-(c(3)+ob.halfHeight_m),0, ...
            (c(3)-ob.halfHeight_m)-hi(3)]);
        d=hypot(max(hypot(dx,dy)-ob.radius_m,0),dz);
    case 'box'
        e=ob.halfSize_m;
        outside=max(max(lo-(c+e),(c-e)-hi),0);
        d=norm(outside);
end
end
