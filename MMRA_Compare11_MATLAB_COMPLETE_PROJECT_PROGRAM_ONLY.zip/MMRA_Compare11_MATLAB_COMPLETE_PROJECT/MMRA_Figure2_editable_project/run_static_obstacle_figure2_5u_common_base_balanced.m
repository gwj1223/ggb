%RUN_STATIC_OBSTACLE_FIGURE2_5U_COMMON_BASE_BALANCED
% Five UAVs from one common base, with longer, more balanced missions.
% Extend ONLY goals 1 and 5; preserve goals 2, 3 and 4.
% The new goal candidates are checked against SAVED terrain and static NFZs.
% Route figure explicitly shows the five launch pads and all five goals,
% independent of SHOW UAV POINTS, WITHOUT dotted assignment lines.
% This is a NEW experiment; the earlier source scripts remain unchanged.
% Downstream cache is updated only when all five paths succeed.
%
% Place this script in the project ROOT beside run_static_dynamic_figure2_5u.m.

root = fileparts(mfilename('fullpath'));
addpath(fullfile(root, 'src'));

[env, cfg, sched] = mmra_defaults('mountain_cluster_figure2_custom_5km');
env = mmra_figure2_add_static_obstacles(env);

% The old generator supplies the five *existing* target positions.
[oldStarts, goals, meta] = mmra_5km_mission(env, 5, 24001, 'cross_center');

% The previous UAV 3 start has already been used successfully as a start.
% Nearby pads still need independent terrain and no-fly checks (below).
baseCenter_m = oldStarts(3, :);
padSpacing_m = 45;
padOffsets_m = padSpacing_m * [ ...
     0  0  0; ...  % UAV 1: base center
     1  0  0; ...  % UAV 2: east
    -1  0  0; ...  % UAV 3: west
     0  1  0; ...  % UAV 4: north
     0 -1  0];    % UAV 5: south
starts = repmat(baseCenter_m, 5, 1) + padOffsets_m;

% The old cross-center mission had goals 1 and 5 close to the new base.
% Candidate XY points are ordered by preference (metres). They are NOT
% blindly accepted: each goal gets a terrain-aware altitude and is checked
% using exactly the same environment and collision checker as RRT*.
originalGoals_m = goals;
longGoalIds = [1 5];
goalCandidatesXY = cell(5,1);
goalCandidatesXY{1} = [ ...
    3300  650; ...
    3400  800; ...
    3000  500; ...
    3700  850; ...
    3100  950; ...
    3900 1150];
goalCandidatesXY{5} = [ ...
    1500 4600; ...
    1200 4600; ...
    1800 4300; ...
    2100 4400; ...
    1050 4750; ...
    1650 4400];

for changeIdx = 1:numel(longGoalIds)
    i = longGoalIds(changeIdx);
    candidates = goalCandidatesXY{i};
    selected = false;
    for c = 1:size(candidates,1)
        xy = candidates(c,:);
        h = mmra_terrain(xy,env);
        if ~isscalar(h) || ~isfinite(h)
            continue;
        end
        % Match the mission generator's 150 m extra terrain margin.
        z = max([900, originalGoals_m(i,3), ...
                 h + env.safetyMargin + 150]);
        proposedGoal = [xy z];
        directDistance = norm(proposedGoal-starts(i,:));
        if directDistance < 2500 || directDistance > 3800 || ...
                z > env.boundsHi(3)-10
            continue;
        end
        % Check the goal and a one-metre neighbouring segment so both
        % endpoint and edge safety, airspace and static NFZs are enforced.
        probe = [proposedGoal; proposedGoal+[1 0 0]];
        if ~mmra_path_free(probe,env,cfg.guardFineResolution) || ...
                ~all(mmra_no_fly_free(probe,env))
            continue;
        end
        otherIds = setdiff(1:5,i);
        dOther = sqrt(sum(bsxfun(@minus, ...
            goals(otherIds,:),proposedGoal).^2,2));
        if any(dOther < 200)
            continue;
        end
        goals(i,:) = proposedGoal;
        selected = true;
        fprintf('Extended UAV %d goal: [%.1f %.1f %.1f] m, direct %.1f m\n', ...
            i,proposedGoal,directDistance);
        break;
    end
    assert(selected, ...
        ['No valid long-distance goal found for UAV %d under the current ' ...
         'saved map/NFZ. Old downstream cache remains unchanged. ' ...
         'Please inspect the proposed goal region.'],i);
end

fprintf('\nFive common-base missions (straight-line lower bounds):\n');
for i=1:5
    fprintf('  UAV%d: start -> goal %.1f m; goal=[%.1f %.1f %.1f] m\n', ...
        i,norm(starts(i,:)-goals(i,:)),goals(i,:));
end

% Preserve and identify the actual task without relying on unknown fields
% of the original meta returned by mmra_5km_mission.
missionInfo = struct();
missionInfo.name = 'five_uav_common_base_balanced';
missionInfo.originalGoalSource = 'cross_center seed=24001 (goals 2-4 retained)';
missionInfo.originalGoals_m = originalGoals_m;
missionInfo.extendedGoalIds = longGoalIds;
missionInfo.baseCenter_m = baseCenter_m;
missionInfo.padSpacing_m = padSpacing_m;
missionInfo.oldStarts_m = oldStarts;
missionInfo.starts_m = starts;
missionInfo.goals_m = goals;
missionInfo.minPadSeparation_m = NaN;

fprintf('\n=== FIGURE 2 / BALANCED COMMON BASE: 5 UAVs ===\n');
fprintf('Base center: [%.1f, %.1f, %.1f] m\n', baseCenter_m);

% Validate launch pads BEFORE attempting RRT*. A short nonzero segment is
% used so the same path/edge collision checker tests each pad.
minPadSep_m = inf;
for i = 1:5
    for j = i+1:5
        minPadSep_m = min(minPadSep_m, norm(starts(i,:) - starts(j,:)));
    end

    q = [starts(i,:); starts(i,:) + [1, 0, 0]]; % 1-m local probe
    terrainAndStaticOK = mmra_path_free(q, env, cfg.guardFineResolution);
    noFlyCheck = mmra_no_fly_free(q, env);
    localClearance_m = mmra_path_clearance(q, env, cfg.guardFineResolution);

    fprintf('UAV %d start=[%.1f %.1f %.1f] m, local terrain clearance=%.1f m\n', ...
        i, starts(i,1), starts(i,2), starts(i,3), localClearance_m);

    assert(isscalar(terrainAndStaticOK) && logical(terrainAndStaticOK) && ...
           all(noFlyCheck(:)) && isfinite(localClearance_m), ...
        ['UAV %d launch pad fails terrain, boundary or static-NFZ ' ...
         'validation. Move baseCenter_m or raise the common altitude ' ...
         'after checking the Figure 2 map.'], i);
end
missionInfo.minPadSeparation_m = minPadSep_m;
% The mission generator returned metadata for the OLD cross-center task.
% Keep its provenance, but synchronize common start/goal fields where they
% exist and explicitly identify the new task for downstream readers.
if isstruct(meta) && isscalar(meta)
    if isfield(meta, 'starts'),   meta.starts = starts; end
    if isfield(meta, 'starts_m'), meta.starts_m = starts; end
    if isfield(meta, 'goals'),    meta.goals = goals; end
    if isfield(meta, 'goals_m'),  meta.goals_m = goals; end
    if isfield(meta, 'mode'),     meta.mode = 'common_base_balanced'; end
    if isfield(meta, 'layout'),   meta.layout = 'common_base_balanced'; end
    meta.commonBaseMission = missionInfo;
end
assert(minPadSep_m > 10, ...
    'Launch pads are too close for the 10-m initial UAV-separation rule.');
fprintf('Minimum launch-pad separation: %.1f m\n', minPadSep_m);

% Keep the original 3-objective cost and planning budget for comparison.
cfg.rrtStopMode = 'terrain_adaptive';
cfg.maxIter = 1200;
assert(strcmp(cfg.costMode, 'length_risk_climb'));

paths = cell(5,1);
records = struct('success',{},'reason',{}, ...
    'length_m',{},'risk_m',{},'climb_m',{},'objective_m',{}, ...
    'minTerrainClearance_m',{},'elapsed_s',{});

rng(24001, 'twister');
for i = 1:5
    [p, st] = mmra_plan_single(starts(i,:), goals(i,:), env, cfg, true);
    paths{i} = p;
    records(i).success = logical(st.success);
    records(i).reason = char(st.reason);
    records(i).elapsed_s = st.total_s;
    records(i).length_m = NaN;
    records(i).risk_m = NaN;
    records(i).climb_m = NaN;
    records(i).objective_m = NaN;
    records(i).minTerrainClearance_m = NaN;

    if st.success
        assert(size(p,2) == 3 && size(p,1) >= 2, ...
            'UAV %d returned a malformed path.', i);
        assert(norm(p(1,:) - starts(i,:)) < 1 && ...
               norm(p(end,:) - goals(i,:)) < 1, ...
            'UAV %d returned a path with unexpected endpoints.', i);
        assert(mmra_path_free(p, env, cfg.guardFineResolution), ...
            'UAV %d path intersects the terrain or a buffered exclusion.', i);
        assert(all(mmra_no_fly_free(p, env)), ...
            'UAV %d path intersects a static no-fly zone.', i);
        records(i).length_m = mmra_path_length(p);
        records(i).risk_m = mmra_path_risk(p, env, ...
            cfg.riskCostBand_m, cfg.riskCostResolution_m);
        records(i).climb_m = mmra_path_ascent(p);
        records(i).objective_m = st.finalObjective_m;
        records(i).minTerrainClearance_m = ...
            mmra_path_clearance(p, env, cfg.guardFineResolution);
    end

    fprintf(['UAV %d: success=%d, reason=%s, length=%.1f m, ' ...
             'J=%.2f, time=%.2f s\n'], ...
        i, st.success, st.reason, records(i).length_m, ...
        records(i).objective_m, st.total_s);
end

% ALWAYS archive this new experiment independently of cross_center.
archiveDir = fullfile(root, 'results_common_base_balanced_dev');
if ~exist(archiveDir, 'dir'), mkdir(archiveDir); end
archiveMat = fullfile(archiveDir, 'Figure2_common_base_balanced_rrt_5u.mat');
save(archiveMat, 'env','cfg','sched','starts','goals','meta', ...
    'missionInfo','paths','records','-v7');

% Hide the old dotted start-to-goal assignment lines in THIS route
% figure, but always overlay the actual five launch/goal markers.
% This does NOT modify the persisted SHOW UAV POINTS preference.
fig = mmra_plot_single_main_map(env, starts, goals, false);
ax = get(fig,'CurrentAxes');
assert(isgraphics(ax,'axes'),'Could not find the Figure 2 3-D axes.');
hold(ax,'on');
colors = lines(5);
for i=1:5
    p = paths{i};
    if ~isempty(p)
        plot3(ax,p(:,1)/1000, p(:,2)/1000, p(:,3)/1000, '-', ...
            'Color',colors(i,:), 'LineWidth',2, ...
            'HandleVisibility','off');
    end
end
% Five small green circles are the five real launch pads (45 m apart).
for i=1:5
    plot3(ax,starts(i,1)/1000,starts(i,2)/1000,starts(i,3)/1000, ...
        'o','LineStyle','none','MarkerSize',7, ...
        'MarkerFaceColor',[.12 .68 .27], ...
        'MarkerEdgeColor',[.02 .25 .07], ...
        'HandleVisibility','off');
    % Square orange terminal markers with individual goal labels.
    plot3(ax,goals(i,1)/1000,goals(i,2)/1000,goals(i,3)/1000, ...
        's','LineStyle','none','MarkerSize',9, ...
        'MarkerFaceColor',[1.00 .48 .10], ...
        'MarkerEdgeColor',[.32 .16 .04], ...
        'HandleVisibility','off');
    text(ax,goals(i,1)/1000+.045,goals(i,2)/1000+.035, ...
        goals(i,3)/1000+.04,sprintf('G%d',i), ...
        'Color',colors(i,:),'FontWeight','bold','FontSize',10, ...
        'HandleVisibility','off');
end
% Label the shared base instead of overlapping five S1-S5 labels.
text(ax,baseCenter_m(1)/1000+.08,baseCenter_m(2)/1000+.06, ...
    baseCenter_m(3)/1000+.09,'BASE (5 UAVs)', ...
    'Color',[.02 .30 .10],'FontWeight','bold','FontSize',11, ...
    'HandleVisibility','off');
title(ax,'Figure 2 | common base (5 UAVs) | green = starts, orange = goals');
archivePng = fullfile(archiveDir, ...
    'Figure2_common_base_balanced_planned_paths_5u.png');
saveas(fig, archivePng);

nSuccess = sum([records.success]);
fprintf('\nBalanced common-base RRT*: %d/5 successful.\n', nSuccess);
fprintf('Independent archive: %s\n', archiveDir);

% Only fully successful tasks may replace the cache read downstream.
if nSuccess == 5
    downstreamDir = fullfile(root, 'results_static_obstacles_dev');
    if ~exist(downstreamDir, 'dir'), mkdir(downstreamDir); end
    downstreamMat = fullfile(downstreamDir, 'Figure2_static_obstacle_rrt_5u.mat');
    downstreamPng = fullfile(downstreamDir, ...
        'Figure2_static_obstacle_planned_paths_5u.png');

    stamp = datestr(now, 'yyyymmdd_HHMMSS');
    if exist(downstreamMat, 'file')
        backupMat = fullfile(downstreamDir, ...
            ['Figure2_static_obstacle_rrt_5u_before_balanced_' stamp '.mat']);
        assert(~exist(backupMat, 'file'), 'Backup name already exists. Rerun later.');
        [ok,msg] = copyfile(downstreamMat, backupMat);
        assert(ok, 'Unable to back up original mission MAT: %s', msg);
        fprintf('Old mission MAT backed up: %s\n', backupMat);
    end
    if exist(downstreamPng, 'file')
        backupPng = fullfile(downstreamDir, ...
            ['Figure2_static_obstacle_planned_paths_5u_before_balanced_' ...
             stamp '.png']);
        assert(~exist(backupPng, 'file'), 'PNG backup name already exists.');
        [ok,msg] = copyfile(downstreamPng, backupPng);
        assert(ok, 'Unable to back up original mission PNG: %s', msg);
    end

    [ok,msg] = copyfile(archiveMat, downstreamMat, 'f');
    assert(ok, 'Failed to update downstream path MAT: %s', msg);
    [ok,msg] = copyfile(archivePng, downstreamPng, 'f');
    assert(ok, 'Failed to update downstream path PNG: %s', msg);
    fprintf('Downstream path cache UPDATED to BALANCED COMMON BASE: %s\n', downstreamMat);
    fprintf('Next: run(''run_static_dynamic_figure2_5u.m'')\n');
else
    warning(['Only %d/5 planned successfully. The original downstream ' ...
        'path cache was NOT touched. Check failed reasons, base safety, ' ...
        'and RRT* budget before rerunning.'], nSuccess);
end

fprintf('Saved Figure 2 map/NFZ/dynamic-obstacle/display settings were NOT modified.\n');
