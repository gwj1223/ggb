%RUN_FIGURE2_WHITE_SCREEN_DIAGNOSIS Three isolated, non-destructive graphics checks.
% Install next to run_main_map.m, run from the MMRA project root.
% Does NOT write terrain/NFZ/dynamic obstacle settings or modify algorithms.
root = fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
fprintf('\n=== MMRA FIGURE 2 WHITE-SCREEN DIAGNOSIS ===\n');
fprintf('Project root: %s\n',root);
fprintf('MATLAB version: %s\n',version);
for key={'mmra_plot_single_main_map','mmra_figure2_plot_dynamic_overlay', ...
        'mmra_figure2_dynamic_obstacles'}
    f=which(key{1});
    fprintf('Function %-40s : %s\n',key{1},f);
end
outDir=fullfile(root,'results_display_diagnostic');
if ~exist(outDir,'dir'),mkdir(outDir);end
fprintf('Diagnostic output folder: %s\n',outDir);
% Fresh figures. Save any unsaved editor settings BEFORE starting.
close all force;

% STEP 1: MATLAB's own unrelated, tiny 3-D plot; verifies basic rendering.
fprintf('\n[STEP 1] Basic MATLAB 3-D surf test\n');
try
    fBasic=figure(99);
    set(fBasic,'Name','MMRA graphics test: basic surf','NumberTitle','off', ...
        'Color','w','Visible','on');
    axBasic=axes('Parent',fBasic);
    surf(axBasic,peaks(35),'EdgeColor','none');
    colormap(axBasic,parula(64)); view(axBasic,3); grid(axBasic,'off');
    title(axBasic,'Basic 3-D surface rendering test');
    drawnow;
    fprintf('  Figure visible=%s, renderer=%s, axes=%d, surfaces=%d\n', ...
        get(fBasic,'Visible'),get(fBasic,'Renderer'), ...
        numel(findall(fBasic,'Type','axes')), ...
        numel(findall(fBasic,'Type','surface')));
    try
        saveas(fBasic,fullfile(outDir,'01_basic_surface.png'));
        fprintf('  PNG saved: 01_basic_surface.png\n');
    catch ME1
        fprintf('  PNG save FAILED: %s\n',ME1.message);
    end
catch ME
    fprintf(2,'  BASIC SURF FAILED: %s\n',ME.message);
end

% STEP 2: Existing proven terrain + static obstacles rendering, no moving objects.
fprintf('\n[STEP 2] Saved Figure 2 terrain + static exclusion volumes\n');
mapOK=false; fMap=[]; axMap=[];
try
    [env,~,~]=mmra_defaults('mountain_cluster_figure2_custom_5km');
    env=mmra_figure2_add_static_obstacles(env);
    [starts,goals]=mmra_5km_mission(env,20,24001,'cross_center');
    fMap=mmra_plot_single_main_map(env,starts,goals);
    drawnow;
    mapAxes=findall(fMap,'Type','axes');
    mapSurfs=findall(fMap,'Type','surface');
    fprintf('  Figure visible=%s, renderer=%s, axes=%d, surfaces=%d\n', ...
        get(fMap,'Visible'),get(fMap,'Renderer'),numel(mapAxes),numel(mapSurfs));
    for k=1:numel(mapAxes)
        a=mapAxes(k);
        fprintf('  Axis %d: visible=%s, children=%d, position=[%s]\n', ...
            k,get(a,'Visible'),numel(allchild(a)),mat2str(get(a,'Position'),3));
    end
    mapOK=~isempty(mapAxes) && ~isempty(mapSurfs);
    axMap=gca;
    try
        saveas(fMap,fullfile(outDir,'02_static_map.png'));
        fprintf('  PNG saved: 02_static_map.png\n');
    catch ME1
        fprintf('  PNG save FAILED: %s\n',ME1.message);
    end
catch ME
    fprintf(2,'  STATIC MAP FAILED: %s\n',ME.message);
    try, fprintf('%s\n',getReport(ME,'extended','hyperlinks','off')); catch, end
end

% STEP 3: Draw moving obstacles ON TOP of STEP 2 without clf/figure reuse.
fprintf('\n[STEP 3] Moving-obstacle overlay on SAME static-map axes\n');
if mapOK && isgraphics(fMap) && isgraphics(axMap)
    try
        [obs,info]=mmra_figure2_dynamic_obstacles(env);
        fprintf('  Moving obstacles: %d, source=%s\n',numel(obs),info.source);
        hh=mmra_figure2_plot_dynamic_overlay(axMap,obs,120,[]);
        title(axMap,'Figure 2 | static + dynamic obstacles | t=120 s');
        drawnow;
        s=findall(fMap,'Type','surface');
        fprintf('  After overlay: axes=%d, surfaces=%d, sphere handles=%d\n', ...
            numel(findall(fMap,'Type','axes')),numel(s),numel(hh.sphere));
        nVisible=0;
        for k=1:numel(s)
            if strcmp(get(s(k),'Visible'),'on'),nVisible=nVisible+1;end
        end
        fprintf('  Visible surfaces: %d\n',nVisible);
        try
            saveas(fMap,fullfile(outDir,'03_static_plus_dynamic.png'));
            fprintf('  PNG saved: 03_static_plus_dynamic.png\n');
        catch ME1
            fprintf('  PNG save FAILED: %s\n',ME1.message);
        end
    catch ME
        fprintf(2,'  DYNAMIC OVERLAY FAILED: %s\n',ME.message);
        try, fprintf('%s\n',getReport(ME,'extended','hyperlinks','off')); catch, end
    end
else
    fprintf('  SKIPPED: static map did not create usable graphics objects.\n');
end
fprintf('\n=== END OF DIAGNOSIS ===\n');
fprintf('Please send this Command Window output, and tell me which figures/PNGs are blank.\n');
fprintf('Settings files were not modified.\n');
