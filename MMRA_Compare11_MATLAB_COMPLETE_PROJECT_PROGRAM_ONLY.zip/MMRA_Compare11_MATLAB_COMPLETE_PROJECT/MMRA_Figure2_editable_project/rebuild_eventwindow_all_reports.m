%REBUILD_EVENTWINDOW_ALL_REPORTS Zero planning and zero scheduling; saved CSV only.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'examples'));
mmra_sched_event_report(root,false);
