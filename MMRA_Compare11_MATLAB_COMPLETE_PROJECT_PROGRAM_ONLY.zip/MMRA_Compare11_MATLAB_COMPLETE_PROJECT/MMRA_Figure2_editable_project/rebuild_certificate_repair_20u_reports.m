%REBUILD_CERTIFICATE_REPAIR_20U_REPORTS Read CSV checkpoints ONLY.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'examples'));
mmra_certificate_repair_report(root,true);
