%RUN_CHECK_NFZ_EDITOR_INSTALL Check scripts and source resolution.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'tests'));
req={'run_main_map_editor','mmra_figure2_add_static_obstacles', ...
    'mmra_figure2_nfz_defaults','mmra_figure2_validate_nfz', ...
    'mmra_no_fly_segment_free','mmra_figure2_nfz_editor_tests', ...
    'run_main_map_static_obstacles','run_static_obstacle_figure2_5u'};
for k=1:numel(req)
    f=which(req{k});
    assert(~isempty(f), 'Missing file on MATLAB path: %s',req{k});
    fprintf('FOUND %-42s %s\n',req{k},f);
end
fprintf('NFZ editor install: source files found (slider UI not yet tested).\n');
