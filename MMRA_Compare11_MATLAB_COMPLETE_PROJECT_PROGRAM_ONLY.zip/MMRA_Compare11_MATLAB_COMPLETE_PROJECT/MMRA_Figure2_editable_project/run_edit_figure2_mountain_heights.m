%RUN_EDIT_FIGURE2_MOUNTAIN_HEIGHTS Backup saved terrain then open editor.
% Edit *real* peak contributions; no changes to the flight-planning cache.
% This launcher does not alter terrain unless you click SAVE MAP in editor.

root = fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
settingsFile = fullfile(root,'results_main_map', ...
    'Figure2_user_settings.mat');

if isfile(settingsFile)
    backupDir = fullfile(root,'results_main_map','terrain_backups');
    if ~exist(backupDir,'dir'), mkdir(backupDir); end
    backupFile = fullfile(backupDir, ...
        ['Figure2_user_settings_before_edit_' ...
         datestr(now,'yyyymmdd_HHMMSSFFF') '.mat']);
    assert(~isfile(backupFile),'Existing backup filename collision.');
    [ok,msg] = copyfile(settingsFile,backupFile);
    assert(ok,'Terrain backup failed: %s',msg);
    fprintf('Current terrain backup: %s\n',backupFile);
else
    fprintf('No saved terrain settings found: using profile defaults.\n');
end

[env,~,~] = mmra_defaults('mountain_cluster_figure2_custom_5km');
fprintf('\n=== FIGURE 2: CURRENT MOUNTAIN PARAMETERS ===\n');
fprintf('Peak | contribution(m) | global X(m) | global Y(m) | height at peak center(m)\n');
for i = 1:size(env.peaks,1)
    pk = env.peaks(i,:);
    z = mmra_terrain(pk(2:3),env);
    fprintf('%4d | %15.1f | %11.1f | %11.1f | %24.1f\n', ...
        i,pk(1),pk(2),pk(3),z);
end
fprintf('\nIn editor: EDIT TERRAIN -> Peak XX -> Peak height contribution (m).\n');
fprintf('Use SAVE MAP to persist your terrain changes.\n');
fprintf('After saving, REPLAN all 5 routes and rerun V3.\n\n');

run_main_map_editor;
