%RUN_STATIC_OBSTACLE_TESTS Independent geometric and integration checks.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'tests'));
run(fullfile(root,'run_check_static_obstacle_install.m'));
mmra_static_obstacle_tests();
