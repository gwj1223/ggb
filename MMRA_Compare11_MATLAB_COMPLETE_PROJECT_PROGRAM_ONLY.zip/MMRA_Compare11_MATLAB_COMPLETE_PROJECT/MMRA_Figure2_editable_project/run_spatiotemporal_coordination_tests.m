%RUN_SPATIOTEMPORAL_COORDINATION_TESTS V2 and backward-compatibility tests.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'tests'));
mmra_speed_feedback_tests();
mmra_coordination_tests();
mmra_spatiotemporal_coordination_tests();
