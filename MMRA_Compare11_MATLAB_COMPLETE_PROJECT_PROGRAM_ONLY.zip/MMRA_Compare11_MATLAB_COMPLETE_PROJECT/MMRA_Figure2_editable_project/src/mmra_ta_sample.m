function [q,kind,tag,d] = mmra_ta_sample( ...
    startPos,goalPos,env,cfg,opt,bestPath,bestObjective_m,guided,collectDiag)
%MMRA_TA_SAMPLE Mixture of global, terrain-scored and incumbent-corridor samples.
% Mixture retains >=15%% global support (outside goal bias) when enabled.
% The candidate score steers EXPLORATION only; edge/path cost is unchanged.
% The straight-line length lower bound is used only to RANK candidates,
% not to reject all exploration outside the incumbent informed set.
if nargin<9,collectDiag=false;end
if nargin<8,guided=true;end
q=zeros(1,3);tag='';kind='uniform';
d=struct('valid',false);
hasCorridor=opt.useCorridor && size(bestPath,1)>=2;
hasTerrain=opt.useTerrain;
if ~hasCorridor && ~hasTerrain
    [q,tag,d]=global_sample(goalPos,env,cfg,guided,collectDiag);
    return;
end
u=rand;
corrShare=double(hasCorridor)*opt.corridorShare;
terrainShare=double(hasTerrain)*opt.terrainShare;
if u<corrShare
    [q,valid]=corridor_sample(bestPath,startPos,goalPos, ...
        env,cfg,opt,bestObjective_m);
    if valid
        kind='corridor';tag='ta_corridor';return;
    end
elseif u<corrShare+terrainShare
    [q,valid]=terrain_sample(startPos,goalPos, ...
        env,cfg,opt,bestObjective_m);
    if valid
        kind='terrain';tag='ta_terrain';return;
    end
end
[q,tag,d]=global_sample(goalPos,env,cfg,guided,collectDiag);
end

function [q,tag,d]=global_sample(goalPos,env,cfg,guided,collectDiag)
q=env.boundsLo+rand(1,3).*(env.boundsHi-env.boundsLo);
if collectDiag
    [q,tag,d]=mmra_guided_sample(q,goalPos,env,cfg,guided);
else
    [q,tag]=mmra_guided_sample(q,goalPos,env,cfg,guided);
    d=struct('valid',false);
end
end

function [q,valid]=terrain_sample(startPos,goalPos,env,cfg,opt,Cbest)
K=opt.candidateCount;
xy=bsxfun(@plus,env.boundsLo(1:2), ...
    bsxfun(@times,rand(K,2),env.boundsHi(1:2)-env.boundsLo(1:2)));
[h,hx,hy]=mmra_terrain(xy,env);
v=goalPos(1:2)-startPos(1:2);
v2=sum(v.^2);
if v2<=eps
    t=0.5*ones(K,1);
else
    t=sum(bsxfun(@times,bsxfun(@minus,xy,startPos(1:2)),v),2)/v2;
    t=max(0,min(1,t));
end
zReference=startPos(3)+t*(goalPos(3)-startPos(3));
zFloor=h+env.safetyMargin+opt.minTerrainExtra_m;
zWant=zReference+opt.altitudeJitter_m*(2*rand(K,1)-1);
z=max(zFloor,zWant);
z=min(z,env.boundsHi(3)-1e-4);
pts=[xy z];
validRows=mmra_is_free(pts,env);
if ~any(validRows)
    valid=false;q=zeros(1,3);return;
end
LB=sqrt(sum(bsxfun(@minus,pts,startPos).^2,2))+ ...
    sqrt(sum(bsxfun(@minus,pts,goalPos).^2,2));
risk=mmra_risk_density(pts,env,cfg.riskCostBand_m,h);
slope=hypot(hx,hy);
score=LB+opt.riskScore_m*risk+ ...
    opt.slopeScore_m*min(slope,3)+ ...
    opt.altitudeScoreWeight*max(0,z-zReference);
if opt.useInformedRanking && isfinite(Cbest)
    % J >= L; points with LB > incumbent cost are poor post-solution
    % candidates, but global uniform exploration remains enabled.
    score(LB>Cbest+1e-7)=score(LB>Cbest+1e-7)+1e5;
end
score(~validRows)=Inf;
[scoreBest,k]=min(score);
valid=isfinite(scoreBest);
if valid
    q=pts(k,:);
else
    q=zeros(1,3);
end
end

function [q,valid]=corridor_sample(path,startPos,goalPos,env,cfg,opt,Cbest)
segments=diff(path,1,1);
lengths=sqrt(sum(segments.^2,2));
total=sum(lengths);
if total<=1e-10
    q=zeros(1,3);valid=false;return;
end
s=rand*total;
cumulative=cumsum(lengths);
k=find(cumulative>=s,1,'first');
if isempty(k),k=numel(lengths);end
s0=0;if k>1,s0=cumulative(k-1);end
f=(s-s0)/max(lengths(k),eps);
base=path(k,:)+f*segments(k,:);
tangent=segments(k,:)/max(lengths(k),eps);
% Two orthogonal directions reduce the chance of following the existing
% polyline exactly, while perturbing it mostly in its cross-section.
e1=cross(tangent,[0 0 1]);
if norm(e1)<1e-8,e1=cross(tangent,[1 0 0]);end
e1=e1/max(norm(e1),eps);
e2=cross(tangent,e1);
q=base+opt.corridorRadius_m*((2*rand-1)*e1+(2*rand-1)*e2);
for attempt=1:4
    q=min(max(q,env.boundsLo),env.boundsHi);
    h=mmra_terrain(q,env);
    q(3)=max(q(3),h+env.safetyMargin+max(0.01, ...
        min(opt.minTerrainExtra_m,0.5*cfg.riskCostBand_m)));
    if mmra_is_free(q,env)
        LB=norm(q-startPos)+norm(q-goalPos);
        if ~opt.useInformedRanking || ~isfinite(Cbest) || ...
                LB<=Cbest+1e-7
            valid=true;return;
        end
    end
    q=0.5*(base+q);
end
valid=logical(mmra_is_free(q,env));
end
