function out=mmra_schedule_spatiotemporal_coordination(paths,opt)
%MMRA_SCHEDULE_SPATIOTEMPORAL_COORDINATION Offline time-aware coordination V2.
% Three explicit modules: (1) nominal continuous-time route conflict
% screening, (2) search INDIVIDUAL launch times and priority orders, and
% (3) opt-in encounter-level dynamic ETA/fairness-based priority. Every
% candidate is RERUN under the original controlled-speed simulator and
% accepted only if its independent continuous-time audit passes.
%
% This is an OFFLINE whole-mission optimizer with speed-feedback execution,
% NOT an online replanner or guaranteed deadlock-free flight controller.
% Repairs here mean trying alternative full release/priority schedules after
% a failed full trace; no airborne UAV is teleported or instant-replanned.
%
% opt.coordinationV2MaxTrials = 30 (includes the baseline)
% opt.coordinationV2UniformGaps_s = [0 .5 1 2] (also checks original gap)
% opt.coordinationV2MaxLaunch_s = speedFeedbackMaxTime_s by default
% opt.coordinationV2MeanFinishWeight = 1
% opt.coordinationV2MakespanWeight = 1
% opt.coordinationV2YieldPenalty = 0.2 seconds penalty/s of yield
% opt.coordinationV2ShieldPenalty_s = 0.1 seconds/action
% opt.coordinationV2MinImprovement = 0.01 weighted seconds
% opt.coordinationV2PriorityPolicy = 'dynamic_eta' or 'static'
% opt.coordinationOverridePresetTimes=false (respect explicit release)
clock=tic;
U=numel(paths);
assert(U>=1,'At least one UAV path is required.');
maxTrials=localVal(opt,'coordinationV2MaxTrials',30);
assert(isfinite(maxTrials) && maxTrials==floor(maxTrials) && maxTrials>=1);
maxLaunch=localVal(opt,'coordinationV2MaxLaunch_s', ...
    localVal(opt,'speedFeedbackMaxTime_s',180));
headway=localVal(opt,'coordinationHeadway_s',2);
minGain=localVal(opt,'coordinationV2MinImprovement',0.01);
assert(all(isfinite([maxLaunch headway minGain])) && ...
    maxLaunch>=0 && headway>0 && minGain>=0);
policy='dynamic_eta';
if isfield(opt,'coordinationV2PriorityPolicy') && ...
        ~isempty(opt.coordinationV2PriorityPolicy)
    policy=lower(char(opt.coordinationV2PriorityPolicy));
end
assert(any(strcmp(policy,{'static','dynamic_eta'})));
spatial=mmra_coordination_conflict_graph(paths,opt);
L=spatial.pathLengths_m(:);
if isfield(opt,'speedFeedbackPriorityOrder') && ...
        ~isempty(opt.speedFeedbackPriorityOrder)
    staticOrder=reshape(opt.speedFeedbackPriorityOrder,1,[]);
else
    [~,ix]=sortrows([-L,(1:U)'],[1 2]);staticOrder=ix(:)';
end
if isfield(opt,'speedFeedbackLaunchOrder') && ...
        ~isempty(opt.speedFeedbackLaunchOrder)
    launchOrder=reshape(opt.speedFeedbackLaunchOrder,1,[]);
else
    launchOrder=staticOrder;
end
assert(isequal(sort(staticOrder),1:U));
assert(isequal(sort(launchOrder),1:U));
fixedPriority=isfield(opt,'speedFeedbackPriorityOrder') && ...
    ~isempty(opt.speedFeedbackPriorityOrder);
locked=isfield(opt,'speedFeedbackLaunchTimes_s') && ...
    ~isempty(opt.speedFeedbackLaunchTimes_s) && ...
    ~logical(localVal(opt,'coordinationOverridePresetTimes',0));
% Preserve original baseline without modifying its policy or release times.
base=mmra_schedule_speed_feedback(paths,opt);
tauBase=base.plannedLaunchTimes_s(:);
if numel(tauBase)~=U
    gap=localVal(opt,'speedFeedbackLaunchInterval_s',0);
    tauBase=zeros(U,1);tauBase(launchOrder)=gap*(0:U-1);
end
nominalBase=mmra_coordination_temporal_conflicts( ...
    paths,opt,tauBase,spatial);
trials=localTrial(base,'baseline',tauBase,staticOrder, ...
    base.priorityPolicy,nominalBase,opt);
visited=struct('tau',tauBase,'priority',staticOrder, ...
    'mode',base.priorityPolicy);
best=base;bestIndex=0;
if trials(1).feasible,bestIndex=1;end
bestScore=trials(1).score;

% Use a deterministic set of acyclic TOTAL orders as tie breakers. Each
% crossing remains individually prioritized at first hazard appearance.
orders=localOrders(spatial,staticOrder);
if fixedPriority,orders={staticOrder};end
if ~locked && maxTrials>1
    interval=localVal(opt,'speedFeedbackLaunchInterval_s',0);
    intervals=[localList(opt,'coordinationV2UniformGaps_s',[0 0.5 1 2]),interval];
    intervals=unique(max(0,intervals),'stable');
    for k=1:numel(intervals)
        if numel(trials)>=maxTrials,break;end
        tau=localUniform(launchOrder,U,intervals(k));
        evaluate('compact_uniform',tau,staticOrder,policy);
    end
    for a=1:numel(orders)
        if numel(trials)>=maxTrials,break;end
        order=orders{a};
        % Conflict-aware proposals are per-UAV, NOT a uniform gap.
        evaluate('individual_windows', ...
            localWindows(order,spatial,headway),order,policy);
        if numel(trials)>=maxTrials,break;end
        evaluate('nominal_conflict_repair', ...
            localRepair(paths,opt,spatial,order,headway,maxLaunch), ...
            order,policy);
    end
    % Coordinate descent: perturb ONE UAV's launch time at a time, holding
    % all other departures fixed. This is the main per-UAV adaptive step.
    % Improvements are accepted only after a complete independently
    % verified speed-feedback mission (not from the nominal predictor).
    moves=localList(opt,'coordinationV2IndividualMoves_s', ...
        [-2 -1 -0.5 0.5 1 2]);
    while numel(trials)<maxTrials
        if bestIndex>0
            center=trials(bestIndex).launchTimes_s;
            centerOrder=trials(bestIndex).priorityOrder;
        else
            center=tauBase;centerOrder=staticOrder;
        end
        [~,rankImpact]=sort(spatial.weightedDegree(:),'descend');
        trialsBefore=numel(trials);
        bestIndexBefore=bestIndex;
        for z=1:U
            if numel(trials)>=maxTrials,break;end
            i=rankImpact(z);
            for h=1:numel(moves)
                if numel(trials)>=maxTrials,break;end
                tau=center;
                tau(i)=max(0,center(i)+moves(h));
                evaluate('individual_adjust',tau,centerOrder,policy);
            end
        end
        % No further distinct candidates or no accepted improvement.
        if numel(trials)==trialsBefore || bestIndex==bestIndexBefore
            break;
        end
    end
end
out=best;
out.mode='spatiotemporal_coordination_speed_feedback';
meta=struct();
meta.algorithm='offline_temporal_conflict_individual_launch_dynamic_eta_v2';
meta.spatialGraph=spatial;
meta.baselineNominal=nominalBase;
if bestIndex>0
    meta.selectedNominal=mmra_coordination_temporal_conflicts(paths,opt, ...
        trials(bestIndex).launchTimes_s,spatial);
else
    meta.selectedNominal=nominalBase;
end
meta.trials=trials;
meta.numTrials=numel(trials);
meta.numFeasible=sum([trials.feasible]);
meta.numStalled=sum(strcmp({trials.reason},'all_aircraft_stalled'));
meta.baselineScore=trials(1).score;
meta.baselineMeanFinish_s=trials(1).meanFinish_s;
meta.baselineMakespan_s=trials(1).makespan_s;
meta.selectedTrial=bestIndex;
meta.selectedScore=bestScore;
meta.selectedPolicy='no_verified_candidate';
meta.selectedLaunchTimes_s=[];
meta.selectedPriorityOrder=[];
meta.selectedPriorityMode='';
if bestIndex>0
    meta.selectedPolicy=trials(bestIndex).policy;
    meta.selectedLaunchTimes_s=trials(bestIndex).launchTimes_s;
    meta.selectedPriorityOrder=trials(bestIndex).priorityOrder;
    meta.selectedPriorityMode=trials(bestIndex).priorityMode;
end
meta.fixedPresetTimes=locked;
meta.objective='makespan + mean_finish + yield_seconds + shield_penalty';
meta.offlineOnly=true;
meta.deadlockFreedomGuaranteed=false;
meta.searchWall_s=toc(clock);
out.coordination=meta;
out.schedule_s=meta.searchWall_s;
if bestIndex==0
    out.success=false;
    out.reason=['spatiotemporal_no_verified_complete_schedule__' base.reason];
end

    function evaluate(name,tau,priority,mode)
        % Nested helper holds a stable deterministic trial ledger.
        if numel(trials)>=maxTrials,return;end
        tau=double(tau(:));
        if numel(tau)~=U || any(~isfinite(tau)) || ...
                any(tau<0) || max(tau)>maxLaunch+1e-9
            return;
        end
        if localDuplicate(visited,tau,priority,mode),return;end
        visited(end+1)=struct('tau',tau,'priority',priority, ...
            'mode',mode); %#ok<AGROW>
        o=opt;
        o.speedFeedbackLaunchTimes_s=tau;
        o.speedFeedbackPriorityOrder=priority;
        o.speedFeedbackPriorityPolicy=mode;
        if strcmp(mode,'dynamic_eta')
            o.speedFeedbackConflictArc_m=spatial.arcAtApproach_m;
        end
        prediction=mmra_coordination_temporal_conflicts( ...
            paths,opt,tau,spatial);
        result=mmra_schedule_speed_feedback(paths,o);
        rec=localTrial(result,name,tau,priority,mode,prediction,opt);
        trials(end+1,1)=rec; %#ok<AGROW>
        if rec.feasible && rec.score<bestScore-minGain-1e-9
            bestScore=rec.score;
            best=result;
            bestIndex=numel(trials);
        end
    end
end

function tau=localUniform(order,U,gap)
tau=zeros(U,1);tau(order)=gap*(0:U-1);
end

function tau=localWindows(order,g,headway)
% Only delay a crossing when nominal arrival windows overlap. A spatial
% graph edge alone does not mandate staggering.
U=numel(order);tau=zeros(U,1);
for k=2:U
    j=order(k);
    for a=1:k-1
        i=order(a);
        if ~g.edge(i,j),continue;end
        ti=tau(i)+g.arcAtApproach_m(i,j)/g.speedCaps_mps(i);
        tj=tau(j)+g.arcAtApproach_m(j,i)/g.speedCaps_mps(j);
        if abs(ti-tj)<headway-1e-10
            tau(j)=max(tau(j),ti+headway- ...
                g.arcAtApproach_m(j,i)/g.speedCaps_mps(j));
        end
    end
end
end

function tau=localRepair(paths,opt,g,order,headway,maxLaunch)
% Nominal conflict-directed, per-UAV release-time repair. This is only
% proposal generation. Safety and successful completion depend on full
% independent trace verification by the speed-feedback scheduler.
U=numel(order);tau=zeros(U,1);rank=zeros(U,1);rank(order)=1:U;
for k=1:min(3*U,20)
    risk=mmra_coordination_temporal_conflicts(paths,opt,tau,g);
    if risk.numUnsafePairs==0,break;end
    when=risk.firstUnsafeTime_s;
    when(~risk.unsafeEdge)=inf;
    [earliest,index]=min(when(:));
    if ~isfinite(earliest),break;end
    [i,j]=ind2sub([U U],index);
    if rank(i)<rank(j),loser=j;else,loser=i;end
    tau(loser)=tau(loser)+max(0.5,headway);
    if max(tau)>maxLaunch,break;end
end
end

function list=localOrders(g,base)
U=numel(base);ids=(1:U)';
[~,w]=sortrows([-g.weightedDegree(:),-g.pathLengths_m(:),ids],[1 2 3]);
[~,s]=sortrows([-g.pathLengths_m(:),ids],[1 2]);
first=inf(U,1);
for i=1:U
    nb=find(g.edge(i,:));
    if ~isempty(nb)
        tt=g.arcAtApproach_m(i,nb)/g.speedCaps_mps(i);
        first(i)=min(tt);
    end
end
[~,e]=sortrows([first,-g.weightedDegree(:),ids],[1 2 3]);
candidates={base(:)',ids(w)',ids(s)',ids(e)',fliplr(base(:)')};
list={};
for k=1:numel(candidates)
    match=false;
    for j=1:numel(list)
        if isequal(list{j},candidates{k}),match=true;break;end
    end
    if ~match,list{end+1}=candidates{k};end %#ok<AGROW>
end
end

function tf=localDuplicate(visited,tau,priority,mode)
tf=false;
for i=1:numel(visited)
    if isequal(visited(i).priority,priority) && ...
            strcmp(visited(i).mode,mode) && ...
            all(abs(visited(i).tau(:)-tau(:))<1e-9)
        tf=true;return;
    end
end
end

function v=localVal(s,k,def)
if isfield(s,k) && ~isempty(s.(k)),v=double(s.(k));else,v=def;end
assert(isnumeric(v) && isscalar(v),'%s must be numeric scalar.',k);
end
function v=localList(s,k,def)
if isfield(s,k) && ~isempty(s.(k)),v=double(s.(k));else,v=def;end
v=v(:)';
assert(~isempty(v) && all(isfinite(v)));
end
function rec=localTrial(result,name,tau,priority,mode,pred,opt)
feasible=result.success && isfield(result,'validation') && ...
    isfield(result.validation,'safe') && ...
    isfield(result.validation,'complete') && ...
    result.validation.safe && result.validation.complete && ...
    isfield(result,'completionTimes_s') && ...
    all(isfinite(result.completionTimes_s(:))) && ...
    result.minSeparation>=opt.dSafe-opt.tol-1e-8;
if feasible
    meanFinish=mean(result.completionTimes_s(:));
    makespan=result.makespan;
    score=localVal(opt,'coordinationV2MakespanWeight',1)*makespan + ...
        localVal(opt,'coordinationV2MeanFinishWeight',1)*meanFinish + ...
        localVal(opt,'coordinationV2YieldPenalty',0.2)* ...
        result.yieldSteps*result.trace.dt_s + ...
        localVal(opt,'coordinationV2ShieldPenalty_s',0.1)* ...
        result.shieldAdjustments;
else
    meanFinish=NaN;score=inf;makespan=result.makespan;
end
rec=struct('policy',name,'priorityMode',mode, ...
    'priorityOrder',priority,'launchTimes_s',tau(:), ...
    'feasible',feasible,'reason',result.reason, ...
    'score',score,'makespan_s',makespan,'meanFinish_s',meanFinish, ...
    'minSeparation_m',result.minSeparation, ...
    'yieldSteps',result.yieldSteps, ...
    'shieldAdjustments',result.shieldAdjustments, ...
    'predictedUnsafePairs',pred.numUnsafePairs, ...
    'predictedAlertPairs',pred.numAlertPairs, ...
    'dynamicPriorityDecisions',result.dynamicPriorityDecisions, ...
    'fairnessSelections',result.priorityFairnessSelections, ...
    'schedulerWall_s',result.schedule_s);
end
