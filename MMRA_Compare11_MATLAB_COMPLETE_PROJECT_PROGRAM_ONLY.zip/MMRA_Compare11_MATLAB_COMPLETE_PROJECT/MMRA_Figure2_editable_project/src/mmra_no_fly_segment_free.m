function safe=mmra_no_fly_segment_free(a,b,env)
%MMRA_NO_FLY_SEGMENT_FREE Exact line-segment vs finite cylinders AND boxes.
% Terrain safety is still sampled by mmra_edge_free/mmra_edge_eval.
% Box intersection uses an analytic 3D slab test; no sample-gap misses.
safe=true;
a=reshape(a,1,3);b=reshape(b,1,3);
if ~all(isfinite([a b])),safe=false;return;end
d=b-a;
if isfield(env,'noFlyCylinders') && ~isempty(env.noFlyCylinders)
    buffer=0;
    if isfield(env,'noFlyBuffer_m'),buffer=env.noFlyBuffer_m;end
    for k=1:size(env.noFlyCylinders,1)
        c=env.noFlyCylinders(k,:);
        if abs(d(3))<1e-12
            if a(3)<c(4) || a(3)>c(5),continue;end
            lo=0;hi=1;
        else
            z0=(c(4)-a(3))/d(3);
            z1=(c(5)-a(3))/d(3);
            lo=max(0,min(z0,z1));
            hi=min(1,max(z0,z1));
            if lo>hi,continue;end
        end
        q=a(1:2)-c(1:2);
        dxy=d(1:2);
        denom=dot(dxy,dxy);
        if denom>1e-18
            t=min(hi,max(lo,-dot(q,dxy)/denom));
        else
            t=lo;
        end
        rxy=q+t*dxy;
        if dot(rxy,rxy)<=(c(3)+buffer)^2
            safe=false;return;
        end
    end
end
if isfield(env,'staticBoxes') && ~isempty(env.staticBoxes)
    buffer=0;
    if isfield(env,'staticBoxBuffer_m'),buffer=env.staticBoxBuffer_m;end
    for k=1:size(env.staticBoxes,1)
        bRow=env.staticBoxes(k,:);
        lower=[bRow(1) bRow(3) bRow(5)]-buffer;
        upper=[bRow(2) bRow(4) bRow(6)]+buffer;
        tEnter=0;tExit=1;
        missesBox=false;
        for axis=1:3
            if abs(d(axis))<=1e-12
                if a(axis)<lower(axis) || a(axis)>upper(axis)
                    missesBox=true;break;
                end
            else
                t0=(lower(axis)-a(axis))/d(axis);
                t1=(upper(axis)-a(axis))/d(axis);
                tEnter=max(tEnter,min(t0,t1));
                tExit=min(tExit,max(t0,t1));
                if tEnter>tExit
                    missesBox=true;break;
                end
            end
        end
        if ~missesBox && tEnter<=tExit
            safe=false;return;
        end
    end
end
end
