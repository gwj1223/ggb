function fig = mmra_plot_single_main_map(env, starts, goals, showUavPoints)
%MMRA_PLOT_SINGLE_MAIN_MAP Only the revised Figure 2 terrain scene.
%   Keeps the single selected Multi-peak complex terrain view:
%   parula colors, optional starts/goals/dotted assignments,
%   NO blue ceiling frame and NO axes grid. Dots are assignments, NOT RRT* flight paths.
%   Optional 4th arg overrides saved Figure2_display_settings.mat for this plot.
%   The numerical terrain is read from mmra_terrain, exactly as planning.
assert(any(strcmp(env.profile,{'mountain_cluster_figure2_v28_5km', ...
    'mountain_cluster_figure2_custom_5km'})), ...
    'This renderer is reserved for the single revised Figure 2 map.');
% Default display preference is independent of the actual UAV missions.
if nargin < 4 || isempty(showUavPoints)
    showUavPoints=mmra_figure2_uav_display_settings();
end
assert((islogical(showUavPoints) || isnumeric(showUavPoints)) && ...
    isscalar(showUavPoints) && isreal(showUavPoints) && ...
    isfinite(double(showUavPoints)) && ...
    any(double(showUavPoints)==[0 1]), ...
    'showUavPoints must be a logical scalar.');
if showUavPoints, uavDisplayState='on'; else, uavDisplayState='off'; end
assert(size(starts,1)==size(goals,1) && size(starts,2)==3 && ...
    size(goals,2)==3, 'Invalid mission start/goal arrays.');

x = linspace(0,5000,151); y = linspace(0,5000,151);
[X,Y] = meshgrid(x,y);
H = reshape(mmra_terrain([X(:),Y(:)],env),size(X));

% The user selected the single original Figure 2; keep that MATLAB number.
fig = figure(2); clf(fig);
set(fig,'Color','w','Name','Multi-peak complex terrain', ...
    'NumberTitle','on');
hTerrain = surf(X/1000,Y/1000,H/1000, ...
    'EdgeColor','none','FaceAlpha',0.94);
hold on;
shading interp;
colormap(parula(128));
cb=colorbar; ylabel(cb,'Terrain elevation (km)');
% Show opt-in static airspace exclusions, using the same env as planning.
% The red/gray overlays do not modify the parula terrain colors.
hNFZ=[];hBox=[];
if isfield(env,'noFlyCylinders') && ~isempty(env.noFlyCylinders)
    theta=linspace(0,2*pi,73);
    for k=1:size(env.noFlyCylinders,1)
        c=env.noFlyCylinders(k,:);
        ringX=(c(1)+c(3)*cos(theta))/1000;
        ringY=(c(2)+c(3)*sin(theta))/1000;
        xx=[ringX;ringX];yy=[ringY;ringY];
        zz=[c(4)*ones(1,numel(theta)); ...
            c(5)*ones(1,numel(theta))]/1000;
        h=surf(xx,yy,zz,'FaceColor',[.89 .16 .20], ...
            'FaceAlpha',.17,'EdgeColor','none','HandleVisibility','off');
        if isempty(hNFZ),hNFZ=h;set(h,'HandleVisibility','on');end
        plot3(ringX,ringY,c(5)/1000*ones(size(theta)), ...
            'Color',[.70 .13 .16],'LineWidth',.65, ...
            'HandleVisibility','off');
    end
end
if isfield(env,'staticBoxes') && ~isempty(env.staticBoxes)
    faces=[1 2 3 4;5 6 7 8;1 2 6 5;2 3 7 6; ...
           3 4 8 7;4 1 5 8];
    for k=1:size(env.staticBoxes,1)
        b=env.staticBoxes(k,:)/1000;
        vertices=[b(1) b(3) b(5);b(2) b(3) b(5); ...
            b(2) b(4) b(5);b(1) b(4) b(5); ...
            b(1) b(3) b(6);b(2) b(3) b(6); ...
            b(2) b(4) b(6);b(1) b(4) b(6)];
        h=patch('Vertices',vertices,'Faces',faces, ...
            'FaceColor',[.38 .29 .27], ...
            'FaceAlpha',.42,'EdgeColor',[.35 .24 .23], ...
            'LineWidth',.5,'HandleVisibility','off');
        if isempty(hBox),hBox=h;set(h,'HandleVisibility','on');end
    end
end
hStarts=scatter3(starts(:,1)/1000,starts(:,2)/1000, ...
    starts(:,3)/1000,32,[0.12 0.65 0.28],'filled', ...
    'Visible',uavDisplayState,'Tag','MMRA_UAV_STARTS');
hGoals=scatter3(goals(:,1)/1000,goals(:,2)/1000, ...
    goals(:,3)/1000,32,[0.95 0.35 0.12],'filled', ...
    'Visible',uavDisplayState,'Tag','MMRA_UAV_GOALS');
for i=1:size(starts,1)
    plot3([starts(i,1) goals(i,1)]/1000, ...
        [starts(i,2) goals(i,2)]/1000, ...
        [starts(i,3) goals(i,3)]/1000,':', ...
        'Color',[0.45 0.45 0.45], 'LineWidth',0.55, ...
        'HandleVisibility','off','Visible',uavDisplayState, ...
        'Tag','MMRA_UAV_ASSIGNMENT');
end
xlabel('X (km)');ylabel('Y (km)');zlabel('Altitude (km)');
if showUavPoints
    title('Multi-peak complex terrain | 5 x 5 x 2 km | Dotted lines = mission assignments');
else
    title('Multi-peak complex terrain | 5 x 5 x 2 km');
end
if showUavPoints
    legHandles=[hTerrain hStarts hGoals];
    legLabels={'Terrain','Starts','Goals'};
else
    legHandles=hTerrain;
    legLabels={'Terrain'};
end
if ~isempty(hNFZ)
    legHandles=[legHandles hNFZ];
    legLabels=[legLabels {'No-fly cylinders'}];
end
if ~isempty(hBox)
    legHandles=[legHandles hBox];
    legLabels=[legLabels {'Static buildings'}];
end
legend(legHandles,legLabels,'Location','northeastoutside');
xlim([0 5]);ylim([0 5]);zlim([0 2]);
daspect([1 1 0.55]); view(42,29); grid off;
% Remove axis tick marks only; retain numeric tick labels and colorbar.
ax = gca;
set(ax,'TickLength',[0 0]);
end
