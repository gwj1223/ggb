function [integral_m, length_m] = mmra_edge_risk(a,b,env,band_m,resolution_m)
%MMRA_EDGE_RISK Nonnegative terrain and opt-in no-fly risk integral.
% Original scenes use r(q)=min(1,max(0,1-c(q)/band))^2,
% c(q)=z-H(x,y)-env.safetyMargin. New NFZ scenes use max(r, halo).
% Integral has units of metres.
% Trapezoid quadrature is used separately on EVERY edge. It is not a
% collision checker, nor a continuous-path safety certificate.
assert(isnumeric(a) && isnumeric(b) && numel(a)==3 && numel(b)==3);
assert(isscalar(band_m) && isfinite(band_m) && band_m>0);
assert(isscalar(resolution_m) && isfinite(resolution_m) && resolution_m>0);
a=reshape(a,1,3); b=reshape(b,1,3);
assert(all(isfinite([a b])), 'Risk integral requires finite coordinates');
length_m=norm(b-a);
if length_m==0
    integral_m=0;
    return;
end
n=max(1,ceil(length_m/resolution_m));
t=linspace(0,1,n+1).';
pts=bsxfun(@plus,a,bsxfun(@times,t,b-a));
h=mmra_terrain(pts,env);
r=mmra_risk_density(pts,env,band_m,h);
integral_m=(length_m/n)*(sum(r)-0.5*(r(1)+r(end)));
assert(isfinite(integral_m) && integral_m>=-1e-10 && ...
    integral_m<=length_m+1e-10,'Invalid terrain risk integral');
integral_m=max(0,integral_m);
end
