function candidates=mmra_dynamic_local_rrt_detour(path,center,protectedRadius,env,cfg)
%MMRA_DYNAMIC_LOCAL_RRT_DETOUR Conservative local RRT* geometry proposals.
% Offline / pre-flight only. Treat a predicted obstacle encounter position
% as a temporary finite static exclusion region when GENERATING candidate
% bypasses. A candidate is NEVER accepted without a subsequent full
% dynamic speed-schedule and independent moving-obstacle safety audit.
% It does not claim to optimize motion in four-dimensional space-time.

candidates={};
center=reshape(center,1,3);
[pts,cum,L]=mmra_arc(path);
[distance,s0]=mmra_point_polyline_distance(pts,center);
if distance>protectedRadius+30 || L<2*protectedRadius+1
    return;
end
spans=[max(110,4*protectedRadius),max(180,7*protectedRadius)];
for q=1:numel(spans)
    span=spans(q);
    sA=max(0,s0-span);
    sB=min(L,s0+span);
    if sA<=1e-7 || sB>=L-1e-7 || sB-sA<50
        continue;  % Keep original start and goal outside local patch.
    end
    a=localAtArc(pts,cum,sA);
    b=localAtArc(pts,cum,sB);
    localEnv=env;
    boxPad=max(170,4*protectedRadius);
    range=[a;b;center];
    localEnv.boundsLo=max(env.boundsLo, ...
        min(range,[],1)-[boxPad boxPad max(110,2*protectedRadius)]);
    localEnv.boundsHi=min(env.boundsHi, ...
        max(range,[],1)+[boxPad boxPad max(110,2*protectedRadius)]);
    cyl=[center(1:2),protectedRadius+6, ...
        center(3)-protectedRadius-6,center(3)+protectedRadius+6];
    if ~isfield(localEnv,'noFlyCylinders') || isempty(localEnv.noFlyCylinders)
        localEnv.noFlyCylinders=cyl;
    else
        localEnv.noFlyCylinders=[localEnv.noFlyCylinders;cyl];
    end
    localCfg=cfg;
    localCfg.step=min(65,max(25,cfg.step/2));
    localCfg.rewireRadius=max(110,2*localCfg.step);
    localCfg.goalRadius=max(50,localCfg.step*1.3);
    localCfg.maxIter=550;
    localCfg.wallBudget_s=3.0;
    localCfg.prune=false;
    localCfg.smooth=false;
    [part,stat]=mmra_plan_single(a,b,localEnv,localCfg,false);
    if ~stat.success || size(part,1)<2
        continue;
    end
    patched=[pts(cum<sA-1e-9,:);part;pts(cum>sB+1e-9,:)];
    lengths=sqrt(sum(diff(patched,1,1).^2,2));
    patched=patched([true;lengths>1e-9],:);
    if norm(patched(1,:)-path(1,:))>1e-7 || ...
            norm(patched(end,:)-path(end,:))>1e-7
        continue;
    end
    candidates{end+1,1}=patched; %#ok<AGROW>
end
end

function q=localAtArc(p,c,s)
if s<=0,q=p(1,:);return;end
if s>=c(end),q=p(end,:);return;end
i=find(c<=s,1,'last');i=min(i,numel(c)-1);
w=(s-c(i))/(c(i+1)-c(i));
q=(1-w)*p(i,:)+w*p(i+1,:);
end
