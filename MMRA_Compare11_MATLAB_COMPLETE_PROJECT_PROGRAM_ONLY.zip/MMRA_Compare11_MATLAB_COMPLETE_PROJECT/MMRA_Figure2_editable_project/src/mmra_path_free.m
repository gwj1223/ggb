function ok = mmra_path_free(path,env,resolution)
%MMRA_PATH_FREE Endpoints + every straight interpolated chord checked.
if nargin<3, resolution=1.5; end
ok=false;
if isempty(path) || size(path,2)~=3 || size(path,1)<2, return; end
if ~all(mmra_is_free(path,env)), return; end
for i=1:size(path,1)-1
    if ~mmra_edge_free(path(i,:),path(i+1,:),env,resolution), return; end
end
ok=true;
end
