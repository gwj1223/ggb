function env=mmra_5km_scenery_profile(env,scene)
%MMRA_5KM_SCENERY_PROFILE Opt-in synthetic terrain scenes, physical metres.
% Gaussian rows: [height_m, x_m, y_m, sigma_x_m, sigma_y_m].
% NoFly rows: [cx_m, cy_m, radius_m, z_min_m, z_max_m].
% These are SYNTHETIC designed scenarios, NOT a surveyed terrain DEM.
assert(isequal(env.boundsHi,[5000 5000 2000]), ...
    'Optimized scenery requires 5km x 5km x 2km domain.');
env.profile=char(scene);
env.terrainCoordinateScaleXY=1;
env.terrainAmplitudeScaleZ=1;
env.useRipples=false;
env.safetyMargin=50;
env.noFlyCylinders=zeros(0,5);
env.noFlyBuffer_m=35; % mandatory radial obstacle buffer
% Soft-cost buffer beyond the HARD no-fly boundary.
env.noFlyRiskBand_m=180;
switch lower(char(scene))
    case 'ridge_pass_5km'
        env.sceneTitle='Ridge / valley saddle';
        env.baseHeight=80;
        % North-south ridge with lower saddle near y=2500.
        env.peaks=[ ...
          790 2440  420  450 420;
          910 2370 1190  400 440;
          420 2440 1840  370 255;
          360 2500 3110  385 255;
          930 2460 3880  405 425;
          650 2500 4640  435 385;
          310 1040 3150  520 435;
          390 3950 1660  550 480;
          210 3700 3850  340 480];
    case 'mountain_cluster_5km'
        env.sceneTitle='Multi-peak complex terrain';
        env.baseHeight=75;
        env.peaks=[ ...
          780 1000  940 450 520;
          510 1640 1550 370 300;
          680 3000  850 520 390;
          690 4180 1230 390 490;
          570  960 2970 460 440;
          740 1870 3610 380 440;
          920 3210 2740 475 390;
          600 4250 3820 430 370;
          520 2700 4560 430 380;
          430 3680 4500 310 380;
          260  430 4360 320 340;
          310 2400 2040 330 270];
    case 'mountain_cluster_figure2_custom_5km'
        % Dedicated user-editable version of the selected Figure 2.
        % Geometry is read from an on-disk MAT file; RRT*/APF and plots
        % all use the same resulting terrain oracle.
        env=mmra_5km_scenery_profile(env,'mountain_cluster_figure2_v28_5km');
        env.profile=char(scene);
        env.sceneTitle='Multi-peak complex terrain (user editable)';
        env=mmra_figure2_custom_env(env);
    case 'mountain_cluster_figure2_v28_5km'
        % Figure 2, revised relief ONLY. Keep original Figure 2 mountain
        % locations, physical xyz bounds and parula color styling.
        % This is a NEW terrain profile; original mountain_cluster_5km
        % is deliberately unchanged for historical reproducibility.
        env=mmra_5km_scenery_profile(env,'mountain_cluster_5km');
        env.profile=char(scene);
        env.sceneTitle='Multi-peak complex terrain (staggered relief)';
        % Broad underlying mountain masses, mostly the original 12 peaks.
        % Each row [amplitude_m centerX_m centerY_m sigmaX_m sigmaY_m].
        env.peaks=[ ...
          470 1000  940 485 465;
          255 1640 1550 370 300;
          320 3000  850 510 390;
          350 4180 1230 415 480;
          250  960 2970 460 410;
          405 1870 3610 420 425;
          480 3210 2740 455 405;
          275 4250 3820 450 380;
          205 2700 4560 425 350;
          160 3680 4500 330 365;
          130  430 4360 310 330;
          190 2400 2040 330 270;
          % Three unequal elevated summits on those existing mountains.
          % Unlike an axis/visual stretch these affect collision and cost.
          590  990  940 195 225;
          700 3210 2740 190 200;
          450 1870 3610 225 235;
          % Six lower asymmetric summit shoulders at different elevations.
          230 4150 1220 220 220;
          230 3000  850 250 200;
          260 4250 3820 225 220;
          235 2700 4560 250 220;
          220  960 2970 245 235;
          210 3680 4500 220 180];
        % Rotated (not axis-aligned) connected ridge shoulders.
        % [amplitude centerX centerY alongSigma crossSigma angleDeg]
        env.terrainRidges=[ ...
          160 1330 1260 720 170  41;
          175 2600 2360 850 155 -43;
          110 3650 3270 720 180  47;
          120 1800 3910 720 145  18;
          105 3640 4140 620 160 -30;
          110 1000 2570 720 190  85];
        % Continuous erosion corridors make real lower-altitude passes.
        % [attenuation centerX centerY alongSigma crossSigma angleDeg]
        % These multiply relief: h remains above regional base height.
        env.terrainErosionGullies=[ ...
          0.55 2380 1600 1100 155 -22;
          0.50 2680 3520 1100 165  37;
          0.38 1160 2370  880 150  74;
          0.30 3550 2070  830 120 -38];
        % Smooth, deterministic micro-relief (same oracle in RRT* and plot).
        % [amplitude_m kx_rad/m ky_rad/m phase_rad]
        env.terrainMicroWaves=[ ...
          8.0  0.0070  0.0040 0.20;
          6.5 -0.0050  0.0100 1.00;
          4.2  0.0120 -0.0090 2.10];
        env.terrainMicroReliefScale_m=230;
    case 'mountain_cluster_refined_5km'
        % v2.5: irregular multi-scale mountain network. Keep the v2.4
        % mountain_cluster_5km exactly unchanged for paired comparisons.
        env.sceneTitle='Refined multi-peak mountains and connected valleys';
        env.baseHeight=95;
        % Broad terrain masses, metres: [amplitude x y sigma_x sigma_y].
        env.peaks=[ ...
          590  950  990  530 520;
          370 1580 1620  400 340;
          480 2900  900  540 435;
          540 4170 1310  480 490;
          430  960 2990  540 465;
          555 1950 3650  455 480;
          690 3230 2670  510 430;
          465 4280 3770  510 440;
          390 2680 4530  520 410;
          360 3600 4560  390 410;
          225  550 4340  360 390;
          265 2490 2120  370 330];
        % Anisotropic ROTATED ridges connect nearby peaks. Each row is
        % [height_m x_center y_center sigma_along sigma_cross angle_deg].
        env.terrainRidges=[ ...
          245 1450 1370  960 205  41;
          250 2490 2300 1170 200 -47;
          195 3710 3060  850 195  39;
          180 1710 3750 1010 225 -17;
          180 3540 4280  880 175 -38;
          155  990 2730  780 160  77];
        % Erosion corridors attenuate the positive relief rather than
        % subtracting terrain below the regional base elevation.
        % Rows: [fraction x_center y_center sigma_along sigma_cross angle].
        env.terrainErosionGullies=[ ...
          0.62 2440 1580 1150 190  -17;
          0.53 2870 3660 1310 175   28;
          0.40 1360 2740  990 155   72;
          0.37 3860 2380 1040 150  -33];
        % Small, smooth relief-dependent undulation; no stochastic noise.
        % Each row: [amplitude_m kx_rad_per_m ky_rad_per_m phase_rad].
        env.terrainMicroWaves=[ ...
          13.0  0.0072  0.0034 0.25;
          10.0 -0.0043  0.0099 1.21;
           6.0  0.0140 -0.0082 2.37;
           4.0 -0.0170 -0.0105 0.83];
        env.terrainMicroReliefScale_m=230;
    case 'mountain_cluster_parula_v26_5km'
        % v2.6 main research terrain. All underlying v2.5/v2.4
        % environment profiles remain unchanged. Build from the v2.5
        % height oracle (not from a rendering-only displacement mesh).
        env=mmra_5km_scenery_profile(env,'mountain_cluster_refined_5km');
        env.profile=char(scene);
        env.sceneTitle='Connected multi-peak mountain terrain (v2.6)';
        % Retain the original twelve primary summits, add four lower
        % asymmetric secondary shoulders for more realistic relief.
        % Row definition [amplitude_m cx_m cy_m sx_m sy_m].
        env.peaks=[env.peaks; ...
             115 1350  710 230 320;
              94 3670 1840 260 225;
              83 1150 3890 240 265;
              98 2860 3440 280 225];
        % Six original connecting ridges + five branching spurs. The
        % narrow cross-ridge widths preserve viable valleys and passes.
        % [amp_m x_m y_m sigma_along_m sigma_across_m angle_deg]
        env.terrainRidges=[env.terrainRidges; ...
             108 1010 1940 610 125  81;
              96 2880 1310 690 118 -64;
             106 3110 3470 670 138  62;
              81 4110 2710 640 130 -79;
              82 1950 4310 560 115  19];
        % Four existing erosion valleys + three weaker distributaries.
        % Multiplicative attenuation never drives relief below baseHeight.
        env.terrainErosionGullies=[env.terrainErosionGullies; ...
             0.27 1970 2690 910 128 -34;
             0.24 3460 2030 900 122  47;
             0.21 1680 4300 690 117 -13];
        % Added low-amplitude high-frequency texture is analytically
        % differentiable and vanishes on low-relief regions.
        env.terrainMicroWaves=[env.terrainMicroWaves; ...
              2.8  0.020  0.013 0.53;
              2.5 -0.023  0.017 2.04;
              1.8  0.029 -0.009 1.39];
        env.terrainMicroReliefScale_m=230;
    case 'mountain_cluster_staggered_v27_5km'
        % v2.7: multi-scale STAGGERED summit heights and asymmetric
        % short mountain cores. This is NEW geometry, not a recolor.
        % v2.6 terrain and all older scene profiles remain unchanged.
        % Mathematically all geometry is evaluated by mmra_terrain,
        % including planner clearance, terrain-risk and APF gradient.
        env=mmra_5km_scenery_profile(env, ...
            'mountain_cluster_parula_v26_5km');
        env.profile=char(scene);
        env.sceneTitle='Staggered-height multi-peak mountain terrain (v2.7)';
        % Broad regional mountain masses (16 rows). Give different major
        % basins very different heights. Each row is
        % [amplitude_m centerX_m centerY_m sx_m sy_m]. The amplitudes are
        % component contributions, NOT absolute summit elevations.
        env.peaks=[ ...
           430  900  980  500 465;
           260 1580 1450  385 325;
           345 2910  900  515 405;
           345 4130 1230  435 455;
           255  970 3020  520 475;
           325 1950 3650  435 445;
           475 3220 2700  470 400;
           290 4290 3770  480 405;
           225 2680 4560  485 390;
           190 3580 4510  375 400;
           145  530 4350  355 360;
           210 2480 2100  350 300;
           125 1330  730  265 285;
            90 3670 1830  270 225;
            90 1170 3930  270 245;
           115 2870 3430  280 235;
           % Three prominent, sharp but smooth principal summits.
           % [high peak / high peak / isolated high peak]
           665  920  980  185 215;
           735 3230 2760  190 210;
           525 4240 3760  205 185;
           % Six unequal medium summits: no identical width or height.
           340 2880  900  230 190;
           355 1920 3660  205 250;
           315  920 3010  195 235;
           295 4150 1250  185 250;
           270 2680 4560  190 220;
           250 3560 4420  220 200];
        % Four extra branching ridge shoulders. The 11 older continuous
        % ridges remain, but narrow ridge axes protect visible valleys.
        env.terrainRidges=[env.terrainRidges; ...
            132 1150 1470  520 110  57;
            148 2980 2250  690 128 -63;
            113 4010 3260  680 108  63;
             98 2600 4050  585 100  14];
        % Two further gullies deepen the gaps between medium summits.
        % Multiplicative erosion never takes h below regional baseHeight.
        env.terrainErosionGullies=[env.terrainErosionGullies; ...
            0.38 2520 2820 1100 155 -22;
            0.32 1320 2330  770 130  64];
        % Keep v2.6's seven smooth micro-relief components unchanged.
        % This avoids the unnaturally noisy high-frequency spikes.
    case 'restricted_corridor_5km'
        env.sceneTitle='Airspace-restricted mountain corridor';
        env.baseHeight=90;
        env.peaks=[ ...
          670 1170 1300 530 630;
          710 1110 3630 510 540;
          810 3900 1500 510 490;
          710 3920 3600 480 590;
          250 2550  550 540 370;
          275 2500 4520 560 400;
          330 1800 2640 350 350;
          270 3270 2430 340 350];
        % Physical volume restrictions, NOT just plotted annotations.
        % Vehicles may cross ABOVE z_max if terrain clearance permits.
        env.noFlyCylinders=[ ...
          2370 1960 210 0 1475;
          2810 3060 230 0 1475;
          2170 3420 155 0 1360];
    otherwise
        error('MMRA:UnknownScenery','Unknown 5 km scene: %s',scene);
end
assert(size(env.peaks,2)==5 && all(env.peaks(:,4)>0) && ...
    all(env.peaks(:,5)>0),'Malformed Gaussian terrain peaks');
assert(all(env.noFlyCylinders(:,3)>0));
if isfield(env,'terrainRidges')
    assert(size(env.terrainRidges,2)==6 && ...
           all(all(env.terrainRidges(:,4:5)>0)));
    assert(size(env.terrainErosionGullies,2)==6 && ...
           all(env.terrainErosionGullies(:,1)>=0) && ...
           all(env.terrainErosionGullies(:,1)<1));
    assert(size(env.terrainMicroWaves,2)==4);
end
end
