function row=mmra_sc_buffer_trial(profile,seed,apfMode,buffer_m,scParams)
%MMRA_SC_BUFFER_TRIAL Development-only planning-buffer trial.
% Both APFs have the SAME physical clearance requirement and are evaluated
% on the ORIGINAL terrain safety margin. Only the PLANNING environment uses
% a stricter margin (+buffer_m). The buffer is NOT a continuous certificate.
% This routine deliberately uses already-seen DEVELOPMENT seeds only.
if nargin<5 || isempty(scParams)
    scParams=struct('scSafeBand',4,'scSoftWidth',4,'scKRep',30);
end
assert(isscalar(buffer_m) && isfinite(buffer_m) && buffer_m>=0, ...
    'Planning buffer must be a finite nonnegative number of meters');
assert(strcmp(apfMode,'legacy') || strcmp(apfMode,'sc_apf'), ...
    'APF mode must be legacy or sc_apf');
[physicalEnv,cfg,startPos,goalPos]=mmra_sc_case(profile,false);
params=fieldnames(scParams);
for i=1:numel(params)
    cfg.(params{i})=scParams.(params{i});
end
cfg.apfMode=apfMode;
cfg.collectApfDiagnostics=false; % no diagnostic logging in timing trials
planningEnv=physicalEnv;
planningEnv.safetyMargin=physicalEnv.safetyMargin+buffer_m;
assert(mmra_is_free(startPos,planningEnv) && ...
    mmra_is_free(goalPos,planningEnv), ...
    'Buffered environment has invalid start/goal: %s, buffer %.2fm', ...
    profile,buffer_m);
% Seed reset for EACH mode/buffer: paired stochastic input conditions.
rng(seed,'twister');
[path,st]=mmra_rrtstar(startPos,goalPos,planningEnv,cfg,true);
fineMin=NaN;fineMean=NaN;planFineMin=NaN;
if st.success
    % Evaluation is ALWAYS relative to the original safety margin.
    [fineMin,fineMean]=mmra_path_clearance(path,physicalEnv,0.10);
    [planFineMin,~]=mmra_path_clearance(path,planningEnv,0.10);
    % A constant change to the safety margin changes sample clearance
    % by precisely the buffer, holding the same path fixed.
    assert(abs((fineMin-planFineMin)-buffer_m)<1e-7, ...
        'Planning/physical clearance accounting mismatch');
end
den=st.accepted+st.rejected;
rejectFrac=NaN;
if den>0, rejectFrac=st.rejected/den; end
if strcmp(apfMode,'legacy'),variant='MMRA_legacy_APF';
else,variant='MMRA_SC_APF';end
row=struct('Terrain',profile,'Variant',variant, ...
    'PlanBuffer_m',buffer_m,'Seed',seed, ...
    'Success',logical(st.success),'Path_m',st.pathLength, ...
    'Search_s',st.elapsed_s,'FirstIter',st.firstIter, ...
    'Accepted',st.accepted,'Rejected',st.rejected, ...
    'RejectFraction',rejectFrac, ...
    'MinClearFine_m',fineMin,'MeanClearFine_m',fineMean, ...
    'PlannerMinClearFine_m',planFineMin, ...
    'TreeCostError',st.treeCostError);
end
