function [path,st] = mmra_guarded_plan_single(startPos,goalPos,env,cfg)
%MMRA_GUARDED_PLAN_SINGLE Safe path-selection wrapper around existing MMRA.
% Run original legacy APF and SC-APF from IDENTICAL initial RNG state.
% After both, restore the RNG state reached by legacy (stable downstream
% random stream in multi-UAV planning). Every output path is fine-checked.
% Two searches + validations are counted in the reported wall-clock time.
assert(strcmpi(cfg.apfMode,'guarded_sc'), ...
    'Guarded wrapper requires cfg.apfMode=guarded_sc');
wholeTimer=tic;
stateBefore=rng;
legacyCfg=cfg;legacyCfg.apfMode='legacy';
scCfg=cfg;scCfg.apfMode='sc_apf';
legacyCfg.collectApfDiagnostics=false;
scCfg.collectApfDiagnostics=false;
[legacyPath,legacySt]=mmra_plan_single(startPos,goalPos,env,legacyCfg,true);
stateAfterLegacy=rng;
% onCleanup also restores the state on MATLAB exceptions.
restoreStream=onCleanup(@() rng(stateAfterLegacy));
rng(stateBefore);
[scPath,scSt]=mmra_plan_single(startPos,goalPos,env,scCfg,true);
clear restoreStream;
selectionClock=tic;
[path,st,detail]=mmra_guarded_select(legacyPath,legacySt,scPath,scSt,env,cfg);
selection_s=toc(selectionClock);
% Keep chosen original stats (firstIter, accepted, rejected) but NEVER hide
% the extra runtime of executing both planners. Selected search time is
% available separately as ChosenSearch_s.
chosenSearch=st.search_s;
st.ChosenSearch_s=chosenSearch;
st.LegacySearch_s=legacySt.search_s;
st.SCSearch_s=scSt.search_s;
st.search_s=legacySt.search_s+scSt.search_s;
st.post_s=legacySt.post_s+scSt.post_s+selection_s;
st.Selection_s=selection_s;
st.total_s=toc(wholeTimer);
st.elapsed_s=st.total_s; % full actual wall-clock time, not single search
st.chosenMode=detail.ChosenMode;
st.guardDecision=detail.Decision;
st.fineMinClear_m=detail.ChosenFineMinClear_m;
st.guardDetails=detail;
st.guarded=true;
if st.success
    if norm(path(1,:)-reshape(startPos,1,3))>1e-8 || ...
            norm(path(end,:)-reshape(goalPos,1,3))>1e-8
        error('Guarded planner returned a path with wrong endpoints');
    end
    st.pathLength=mmra_path_length(path);
else
    path=zeros(0,3);
    st.pathLength=NaN;
end
end
