function [Pout,stOut,report] = mmra_figure2_local_repair(Q,Pold,stOld,env,cfg)
%MMRA_FIGURE2_LOCAL_REPAIR Optional, fail-closed local waypoint relocation.
%   Input Q is the PRUNED polyline before Bezier smoothing. Pold and stOld
%   are the actual mmra_bezier outputs. Only invoked if smoothing failed.
%   Generic across case/seed/corner: never branches on fixed fixture IDs.
%   Try small vertical clearance adjustments first, then bounded XY/Z moves.
%   A candidate is accepted only after full-path resmoothing, fine terrain
%   and obstacle checking, and INDEPENDENT continuous curvature/G1/pitch
%   certification. If no candidate passes, return the exact old failure.
%
%   Turning is certified geometrically, NOT a flight-dynamics certificate.
%   Terrain collision is rechecked on 1 m or finer line-segment samples;
%   this does NOT claim a continuous terrain clearance proof between samples.
Pout=Pold;stOut=stOld;
report=struct('attempted',false,'succeeded',false, ...
    'reason','NOT_REQUIRED','numCandidatesTested',0, ...
    'cornersRelocated',zeros(0,1), ...
    'waypointShifts_m',zeros(0,3), ...
    'certifiedRadius_m',nan,'originalFailedCorners',zeros(0,1), ...
    'newPathLength_m',nan,'originalPathLength_m',pathLen(Pold));
if ~isnumeric(Q) || size(Q,2)~=3 || size(Q,1)<3 || ...
        isempty(Pold) || ~isstruct(stOld) || ...
        ~isfield(stOld,'fullySmoothed') || stOld.fullySmoothed
    return;
end
if ~isfield(stOld,'failedCornerIndices') || ...
        isempty(stOld.failedCornerIndices)
    report.reason='NO_IDENTIFIED_FAILED_CORNER';return;
end
report.attempted=true;
report.originalFailedCorners=stOld.failedCornerIndices(:);
% Do not silently drop the independent validator dependency.
if exist('mmra_compare11_turnradius_validate','file')~=2
    report.reason='INDEPENDENT_VALIDATOR_MISSING';return;
end
maxTrials=max(1,round(option(cfg,'figure2RepairMaxCandidates',120)));
maxPasses=max(1,round(option(cfg,'figure2RepairMaxPasses',3)));
maxAddedLength=option(cfg,'figure2RepairMaxAddedLength_m',55);
maxZ=option(cfg,'figure2RepairMaxRaise_m',30);
maxXY=option(cfg,'figure2RepairMaxXY_m',15);
radiusRequirement=option(cfg,'smoothMinRadius_m',10);
pitchRequirement=option(cfg,'smoothMaxPitch_deg',75);
assert(isfinite(maxTrials) && isfinite(maxPasses) && ...
    isfinite(maxAddedLength) && maxAddedLength>=0 && ...
    isfinite(maxZ) && maxZ>=0 && ...
    isfinite(maxXY) && maxXY>=0, ...
    'Figure2 local repair configuration must be finite/nonnegative.');
Qwork=Q;stWork=stOld;pathWork=Pold;
originalLength=pathLen(Pold);
shifts=zeros(0,3);moved=zeros(0,1);
report.reason='NO_VERIFIED_LOCAL_REPAIR';
% A strictly finer checker than the search/smoothing default.
cfgFine=cfg;
if isfield(cfgFine,'edgeResolution') && ...
        isfinite(cfgFine.edgeResolution) && cfgFine.edgeResolution>0
    cfgFine.edgeResolution=min(1.0,cfgFine.edgeResolution);
else
    cfgFine.edgeResolution=1.0;
end
for pass=1:maxPasses
    oldFailed=unique(stWork.failedCornerIndices(:),'stable');
    progressed=false;
    for jj=1:numel(oldFailed)
        k=oldFailed(jj);
        if k<2 || k>size(Qwork,1)-1,continue;end
        shiftsToTry=makeOffsets(maxZ,maxXY);
        for t=1:size(shiftsToTry,1)
            if report.numCandidatesTested>=maxTrials
                report.reason='CANDIDATE_BUDGET_EXHAUSTED';return;
            end
            report.numCandidatesTested=report.numCandidatesTested+1;
            delta=shiftsToTry(t,:);
            Qt=Qwork;Qt(k,:)=Qt(k,:)+delta;
            % Never move either task endpoint; reject unsafe polylines.
            if ~mmra_postprocess_path_free(Qt,env,cfgFine)
                continue;
            end
            try
                [Pt,~,candidateStats]=mmra_bezier(Qt,env,cfg);
            catch
                % Some candidate geometries may be numerically invalid.
                continue;
            end
            if ~isfinite(pathLen(Pt)) || ...
                    pathLen(Pt)>originalLength+maxAddedLength
                continue;
            end
            if candidateStats.fullySmoothed
                cert=mmra_compare11_turnradius_validate( ...
                    Pt,candidateStats.curveControls, ...
                    radiusRequirement,pitchRequirement);
                if ~cert.certified || ...
                        ~mmra_postprocess_path_free(Pt,env,cfgFine) || ...
                        norm(Pt(1,:)-Q(1,:))>1e-6 || ...
                        norm(Pt(end,:)-Q(end,:))>1e-6
                    continue;
                end
                Pout=Pt;stOut=candidateStats;
                report.succeeded=true;
                report.reason='VERIFIED_LOCAL_WAYPOINT_REPAIR';
                report.cornersRelocated=[moved;k];
                report.waypointShifts_m=[shifts;delta];
                report.certifiedRadius_m=cert.minPathTurnRadius_m;
                report.newPathLength_m=pathLen(Pt);
                return;
            end
            % For multiple failed corners, permit ONLY monotonic progress.
            % Partial candidates are not returned unless ultimately certified.
            if numel(candidateStats.failedCornerIndices)<numel(oldFailed)
                Qwork=Qt;stWork=candidateStats;pathWork=Pt; %#ok<NASGU>
                moved(end+1,1)=k; %#ok<AGROW>
                shifts(end+1,:)=delta; %#ok<AGROW>
                progressed=true;
                break;
            end
        end
        if progressed,break;end
    end
    if ~progressed
        report.reason='NO_IMPROVING_VERIFIED_CANDIDATE';
        return;
    end
end
report.reason='PASS_BUDGET_EXHAUSTED';
end

function offsets=makeOffsets(maxZ,maxXY)
% Begin with experimentally supported up-clearance perturbations, but use
% no case/corner/seed-specific values. The +/-XY and combined directions
% also permit no-fly obstacle clearance repairs.
raises=[1 0.5 2 3 5 8 10 15 20 30];
raises=raises(raises<=maxZ);
offsets=[zeros(numel(raises),2) raises(:)];
if maxXY<=0,return;end
directions=[1 0;0 1;-1 0;0 -1;1 1;-1 1;-1 -1;1 -1];
directions=bsxfun(@rdivide,directions, ...
    sqrt(sum(directions.^2,2)));
for d=[1 2 4 8 15]
    if d>maxXY,continue;end
    for dz=[0 1 3 5]
        if dz>maxZ,continue;end
        offsets=[offsets; d*directions dz*ones(size(directions,1),1)]; %#ok<AGROW>
    end
end
end

function v=option(cfg,key,defaultVal)
v=defaultVal;
if isfield(cfg,key) && ~isempty(cfg.(key))
    v=cfg.(key);
end
end

function len=pathLen(P)
len=nan;
if isnumeric(P) && isreal(P) && size(P,2)==3 && ...
        size(P,1)>=2 && all(isfinite(P(:)))
    len=sum(sqrt(sum(diff(P,1,1).^2,2)));
end
end
