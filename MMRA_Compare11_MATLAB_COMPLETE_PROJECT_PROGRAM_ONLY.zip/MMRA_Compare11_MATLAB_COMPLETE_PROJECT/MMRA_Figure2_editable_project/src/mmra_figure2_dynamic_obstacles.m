function [obstacles,info]=mmra_figure2_dynamic_obstacles(env,settingsFile)
%MMRA_FIGURE2_DYNAMIC_OBSTACLES Load saved user-editable moving spheres.
% The stored file is INDEPENDENT of Figure2_user_settings.mat and of
% Figure2_static_obstacles_settings.mat. Use this SAME returned obstacles
% struct for Figure 2 rendering, predictive speed control and V3 planner.
% Environments must already carry the saved static exclusions.
assert(strcmp(env.profile,'mountain_cluster_figure2_custom_5km'), ...
    'Moving obstacle editing supports only saved custom Figure 2.');
if nargin<2 || isempty(settingsFile)
    root=fileparts(fileparts(mfilename('fullpath')));
    settingsFile=fullfile(root,'results_main_map', ...
        'Figure2_dynamic_obstacles_settings.mat');
end
info=struct('source','defaults','revision','default_v1', ...
    'file',settingsFile);
obstacles=mmra_figure2_dynamic_defaults();
if isfile(settingsFile)
    d=load(settingsFile,'dynamicParams');
    assert(isfield(d,'dynamicParams') && isstruct(d.dynamicParams) ...
        && isfield(d.dynamicParams,'obstacles'), ...
        'Invalid moving obstacle MAT: expected dynamicParams.obstacles.');
    obstacles=d.dynamicParams.obstacles;
    info.source='saved';
    if isfield(d.dynamicParams,'revision')
        info.revision=char(d.dynamicParams.revision);
    else
        info.revision='unknown';
    end
end
obstacles=mmra_dynamic_obstacles_prepare(obstacles);
mmra_figure2_validate_dynamic_obstacles(obstacles,env,true);
end
