function [forbidden,detail] = mmra_sched_pair_windows(pathA,pathB,opt)
%MMRA_SCHED_PAIR_WINDOWS Relative launch-delay conflict lookup on FIXED grid.
% forbidden(k+K+1) means delta=tauB-tauA=k*delayStep is conservatively
% forbidden, for -K<=k<=K and tauA,tauB both in [0,maxDelay].
%
% Rather than rerunning full-flight pair collision detection at every delay,
% project the safety tube between each pair of AFFINE trajectory pieces
% onto their relative start-time axis. For each pair of pieces the unsafe
% time differences form one interval (convex quadratic sublevel projection).
% Piecewise-constant prelaunch/postarrival HOLD states are explicitly added.
% Interval endpoints are located by monotone bisection of the EXACT minimum
% distance on that pair of pieces, then rounded OUTWARD onto the delay grid.
%
% Grid lookup is conservative near endpoints. Every accepted full schedule
% MUST be verified by mmra_pair_minsep with the original continuous-time
% model; this helper is not a new flight-safety certificate.
%
% All functions use core MATLAB only; no Optimization/Robotics toolbox.
assert(opt.speed>0 && opt.dSafe>0 && opt.delayStep>0 && opt.maxDelay>=0);
K=round(opt.maxDelay/opt.delayStep);
assert(abs(K*opt.delayStep-opt.maxDelay)<1e-7, ...
    'Window scheduler requires maxDelay to be a multiple of delayStep.');
forbidden=false(1,2*K+1);
detail=struct('spatialPiecePairs',0,'closePiecePairs',0, ...
    'forbiddenOffsets',0,'forbiddenRuns',0,'staticEndpointNoGo',false);
if opt.dSafe-opt.tol<=0,return;end
[pa,ca,la]=mmra_arc(pathA);
[pb,cb,lb]=mmra_arc(pathB);
assert(la>1e-10 && lb>1e-10,'Nonzero paths required');
threshold=opt.dSafe-opt.tol;
if (strcmpi(opt.startPolicy,'hold') && norm(pa(1,:)-pb(1,:))<threshold) || ...
   (strcmpi(opt.endPolicy,'hold') && norm(pa(end,:)-pb(end,:))<threshold)
    forbidden(:)=true;
    detail.staticEndpointNoGo=true;
    detail.forbiddenOffsets=numel(forbidden);
    detail.forbiddenRuns=1;
    return;
end
% For |tauB-tauA|<=maxDelay, all potentially unsafe interactions (apart
% from harmless simultaneous start/start or goal/goal holds) occur within
% this finite truncation of the otherwise infinite stationary pieces.
H=max(la,lb)/opt.speed+2*opt.maxDelay+2;
A=localPieces(pa,ca/opt.speed,opt,H);
B=localPieces(pb,cb/opt.speed,opt,H);
threshold2=threshold^2;
% Numerical padding for outward rounding only, not a change to dSafe.
pad_s=max(1e-7,1e-9*opt.delayStep);
for ia=1:numel(A)
    a=A(ia);
    amin=min(a.p0,a.p1);amax=max(a.p0,a.p1);
    for ib=1:numel(B)
        b=B(ib);
        detail.spatialPiecePairs=detail.spatialPiecePairs+1;
        low=a.t0-b.t1;high=a.t1-b.t0;
        if high < -opt.maxDelay-1e-9 || low > opt.maxDelay+1e-9
            continue;
        end
        bmin=min(b.p0,b.p1);bmax=max(b.p0,b.p1);
        gap=max(0,max(amin-bmax,bmin-amax));
        if dot(gap,gap)>=threshold2
            continue; % axis-aligned bounding boxes are safely separated
        end
        [dist2,x,y]=localSpatialClosest(a.p0,a.p1,b.p0,b.p1);
        if dist2>=threshold2
            continue;
        end
        detail.closePiecePairs=detail.closePiecePairs+1;
        delta0=(a.t0+x*(a.t1-a.t0))-(b.t0+y*(b.t1-b.t0));
        % The set {delta: minimum piece-pair separation < threshold}
        % is an interval; delta0 is a known violating member.
        if localRelativeDist2(a,b,delta0)>=threshold2
            error('Segment projection inconsistency in conflict windows.');
        end
        if localRelativeDist2(a,b,low)<threshold2
            left=low;
        else
            L=low;R=delta0;
            for it=1:37
                m=0.5*(L+R);
                if localRelativeDist2(a,b,m)<threshold2
                    R=m;
                else
                    L=m;
                end
            end
            left=R;
        end
        if localRelativeDist2(a,b,high)<threshold2
            right=high;
        else
            L=delta0;R=high;
            for it=1:37
                m=0.5*(L+R);
                if localRelativeDist2(a,b,m)<threshold2
                    L=m;
                else
                    R=m;
                end
            end
            right=L;
        end
        if right < -opt.maxDelay-pad_s || left > opt.maxDelay+pad_s
            continue;
        end
        k0=max(-K,ceil((left-pad_s)/opt.delayStep));
        k1=min(K,floor((right+pad_s)/opt.delayStep));
        if k0<=k1
            forbidden(k0+K+1:k1+K+1)=true;
        end
    end
end
detail.forbiddenOffsets=nnz(forbidden);
detail.forbiddenRuns=nnz(forbidden & ~[false forbidden(1:end-1)]);
end

function stages=localPieces(p,t,opt,H)
% Each stage has local clock [t0,t1] and AFFINE position p(t).
stages=struct('t0',{},'t1',{},'p0',{},'p1',{},'v',{});
if strcmpi(opt.startPolicy,'hold')
    stages(end+1)=localStage(-H,0,p(1,:),p(1,:)); %#ok<AGROW>
end
for k=1:size(p,1)-1
    stages(end+1)=localStage(t(k),t(k+1),p(k,:),p(k+1,:)); %#ok<AGROW>
end
if strcmpi(opt.endPolicy,'hold')
    stages(end+1)=localStage(t(end),H,p(end,:),p(end,:)); %#ok<AGROW>
end
end

function s=localStage(t0,t1,p0,p1)
assert(t1>t0,'Expected strictly increasing waypoint times');
s=struct('t0',t0,'t1',t1,'p0',reshape(p0,1,3), ...
    'p1',reshape(p1,1,3),'v',(p1-p0)/(t1-t0));
end

function [best,xBest,yBest]=localSpatialClosest(a0,a1,b0,b1)
% Exact minimum of ||a0+x*(a1-a0)-b0-y*(b1-b0)||^2,
% with x,y in [0,1]. Corners and four box boundaries always suffice
% unless the unique stationary point is strictly inside the box.
u=a1-a0;v=b1-b0;c=a0-b0;
uu=dot(u,u);vv=dot(v,v);uv=dot(u,v);
best=inf;xBest=0;yBest=0;
for x=[0 1]
    if vv>1e-22
        y=max(0,min(1,dot(c+x*u,v)/vv));
    else
        y=0;
    end
    r=c+x*u-y*v;d2=dot(r,r);
    if d2<best,best=d2;xBest=x;yBest=y;end
end
for y=[0 1]
    if uu>1e-22
        x=max(0,min(1,dot(y*v-c,u)/uu));
    else
        x=0;
    end
    r=c+x*u-y*v;d2=dot(r,r);
    if d2<best,best=d2;xBest=x;yBest=y;end
end
detG=uu*vv-uv*uv;
if detG>1e-12*max(uu*vv,1e-18)
    x=(-vv*dot(c,u)+uv*dot(c,v))/detG;
    y=(-uv*dot(c,u)+uu*dot(c,v))/detG;
    if x>=0 && x<=1 && y>=0 && y<=1
        r=c+x*u-y*v;d2=dot(r,r);
        if d2<best,best=d2;xBest=x;yBest=y;end
    end
end
end

function d2=localRelativeDist2(a,b,delta)
% Optimize distance over the simultaneous portion of these two pieces.
lo=max(a.t0,b.t0+delta);
hi=min(a.t1,b.t1+delta);
if lo>hi+1e-9,d2=inf;return;end
hi=max(lo,hi);
r0=(a.p0+a.v*(lo-a.t0))-(b.p0+b.v*(lo-delta-b.t0));
dr=(a.v-b.v)*(hi-lo);
den=dot(dr,dr);
if den<1e-24
    z=0;
else
    z=max(0,min(1,-dot(r0,dr)/den));
end
r=r0+z*dr;
d2=dot(r,r);
end
