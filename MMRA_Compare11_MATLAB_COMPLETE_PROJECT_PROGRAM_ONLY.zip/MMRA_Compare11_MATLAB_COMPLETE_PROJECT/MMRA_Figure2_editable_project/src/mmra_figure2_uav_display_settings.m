function showUavPoints=mmra_figure2_uav_display_settings(newValue,settingsFile)
%MMRA_FIGURE2_UAV_DISPLAY_SETTINGS Read/write display-only UAV markers flag.
%   SHOW=mmra_figure2_uav_display_settings() returns the saved preference.
%   If no preference has been saved, the default is FALSE (clean map).
%   mmra_figure2_uav_display_settings(TRUE/FALSE) immediately persists it.
%   Optional settingsFile is for isolated unit testing; NEVER touches map data.
root=fileparts(fileparts(mfilename('fullpath')));
if nargin<2 || isempty(settingsFile)
    settingsFile=fullfile(root,'results_main_map', ...
        'Figure2_display_settings.mat');
end
if nargin>=1 && ~isempty(newValue)
    assert((islogical(newValue)||isnumeric(newValue)) && ...
        isscalar(newValue) && isreal(newValue) && ...
        isfinite(double(newValue)) && any(double(newValue)==[0 1]), ...
        'SHOW UAV POINTS requires logical true or false.');
    showUavPoints=logical(newValue);
    displaySettings=struct('showUavPoints',showUavPoints);
    parent=fileparts(settingsFile);
    if ~exist(parent,'dir'),mkdir(parent);end
    save(settingsFile,'displaySettings','-v7');
    return;
end
showUavPoints=false;
if exist(settingsFile,'file')==2
    content=load(settingsFile,'displaySettings');
    if isfield(content,'displaySettings') && ...
            isstruct(content.displaySettings) && ...
            isfield(content.displaySettings,'showUavPoints')
        candidate=content.displaySettings.showUavPoints;
        assert((islogical(candidate)||isnumeric(candidate)) && ...
            isscalar(candidate) && isreal(candidate) && ...
            isfinite(double(candidate)) && any(double(candidate)==[0 1]), ...
            'Invalid showUavPoints value in display settings.');
        showUavPoints=logical(candidate);
    end
end
end
