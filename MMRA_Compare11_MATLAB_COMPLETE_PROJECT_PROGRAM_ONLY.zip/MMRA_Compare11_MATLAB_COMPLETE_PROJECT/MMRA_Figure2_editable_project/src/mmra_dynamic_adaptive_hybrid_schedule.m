function [best,usedPaths,report] = mmra_dynamic_adaptive_hybrid_schedule(paths,env,cfg,opt)
%MMRA_DYNAMIC_ADAPTIVE_HYBRID_SCHEDULE Innovation 3 - offline prototype.
% Compare predicted-obstacle speed-only control with locally rerouted paths.
% All motion is replayed with the EXISTING speed-feedback controller and
% independently audited against UAV-UAV and moving-obstacle constraints.
% Unlike the legacy hybrid, the decision considers terrain-risk integral,
% positive climb, mean completion time, obstacle-yield time and a nonzero
% route-change penalty. Optional bounded prediction error inflates the
% obstacle radius for BOTH candidate scheduling and verification.
%
% IMPORTANT LIMITATION: This is a PRE-FLIGHT optimizer with known future
% obstacle tracks and a sampled-speed-setpoint model. It does not observe
% new obstacles or replan an aircraft already in flight. It does not prove
% deadlock freedom or real-world robustness without a justified error bound.
%
% Configurable opt fields (all optional):
% dynamicAdaptivePredictionBound_m = 0       (center error bound, metres)
% dynamicAdaptiveProbeDelay_s = 3             (nominal makespan overhead)
% dynamicAdaptiveProbeYield_s = 2             (sum of obstacle yield ticks*dt)
% dynamicAdaptiveForceCompare = false
% dynamicAdaptiveMaxCandidates = 12
% dynamicAdaptiveMaxLengthRatio = 1.20
% dynamicAdaptiveTryLocalRRT = true
% dynamicAdaptiveMakespanWeight = 1
% dynamicAdaptiveMeanFinishWeight = 0.20
% dynamicAdaptiveYieldWeight = 0.05
% dynamicAdaptivePathObjectiveWeight = 0.5
% dynamicAdaptiveSwitchPenalty_s = 1
% dynamicAdaptiveMinScoreGain_s = 0.01
%
% Output score uses seconds, with delta path 3-objective in metres / speed.
% HARD SAFETY constraints are NOT softened by the weighted score.

clock=tic;
assert(iscell(paths) && ~isempty(paths),'Supply a nonempty cell array of paths.');
assert(isstruct(env) && isstruct(cfg) && isstruct(opt), ...
    'env, cfg and opt must be structures.');
assert(isfield(opt,'speedFeedbackDynamicObstacles') && ...
    ~isempty(opt.speedFeedbackDynamicObstacles), ...
    'Set opt.speedFeedbackDynamicObstacles to known/predicted obstacle tracks.');
assert(isfield(opt,'speed') && opt.speed>0 && ...
    isfield(opt,'dSafe') && opt.dSafe>0 && ...
    isfield(opt,'tol') && opt.tol>=0,'Invalid speed-feedback constraints.');

errorBound=localNum(opt,'dynamicAdaptivePredictionBound_m',0,0,Inf);
probeDelay=localNum(opt,'dynamicAdaptiveProbeDelay_s',3,0,Inf);
probeYield=localNum(opt,'dynamicAdaptiveProbeYield_s',2,0,Inf);
maxCandidates=localNum(opt,'dynamicAdaptiveMaxCandidates',12,1,Inf);
maxRatio=localNum(opt,'dynamicAdaptiveMaxLengthRatio',1.20,1,Inf);
minGain=localNum(opt,'dynamicAdaptiveMinScoreGain_s',0.01,0,Inf);
tryRRT=logical(localNum(opt,'dynamicAdaptiveTryLocalRRT',1,0,1));
forceCompare=logical(localNum(opt,'dynamicAdaptiveForceCompare',0,0,1));
wMake=localNum(opt,'dynamicAdaptiveMakespanWeight',1,0,Inf);
wMean=localNum(opt,'dynamicAdaptiveMeanFinishWeight',.20,0,Inf);
wYield=localNum(opt,'dynamicAdaptiveYieldWeight',.05,0,Inf);
wPath=localNum(opt,'dynamicAdaptivePathObjectiveWeight',.5,0,Inf);
switchPenalty=localNum(opt,'dynamicAdaptiveSwitchPenalty_s',1,0,Inf);
assert(maxCandidates==floor(maxCandidates),'Candidate count must be an integer.');
assert(wMake+wMean+wYield+wPath>0,'At least one score weight must be positive.');
[wr,wa]=mmra_cost_weights(cfg);

rawObstacles=mmra_dynamic_obstacles_prepare(opt.speedFeedbackDynamicObstacles);
conservativeObs=rawObstacles;
for m=1:numel(conservativeObs)
    conservativeObs(m).radius_m=rawObstacles(m).radius_m+errorBound;
end
% The predictor, shield and independent verifier ALL see the same
% protected radius. This is not a hidden post-hoc clearance adjustment.
protectedOpt=opt;
protectedOpt.speedFeedbackDynamicObstacles=conservativeObs;
withoutObs=protectedOpt;
withoutObs=rmfield(withoutObs,'speedFeedbackDynamicObstacles');

nominal=mmra_schedule_speed_feedback(paths,withoutObs);
speedOnly=mmra_schedule_speed_feedback(paths,protectedOpt);
best=speedOnly;usedPaths=paths;
validSpeed=localVerified(speedOnly,protectedOpt);
speedScore=Inf;
if validSpeed
    speedScore=localScore(speedOnly,0,0,protectedOpt, ...
        wMake,wMean,wYield,wPath,switchPenalty);
end
report=struct( ...
    'algorithm','offline_predictive_multicriteria_speed_or_detour_v3', ...
    'strategy','speed_only','decisionReason','not_evaluated', ...
    'offlineOnly',true,'predictionBound_m',errorBound, ...
    'nominalCompleted',nominal.success,'speedOnlyCompleted',validSpeed, ...
    'speedOnlyReason',speedOnly.reason,'nominalMakespan_s',nominal.makespan, ...
    'speedOnlyMakespan_s',speedOnly.makespan,'speedOnlyScore_s',speedScore, ...
    'nominalObstacleClearance_m',NaN, ...
    'candidateProposals',0,'terrainValidCandidates',0, ...
    'simulatedCandidates',0,'completedCandidates',0, ...
    'selectedUAV',NaN,'selectedObstacle',NaN, ...
    'selectedExtraLength_m',0,'selectedDeltaRisk_m',0, ...
    'selectedDeltaAscent_m',0,'selectedDeltaPathObjective_m',0, ...
    'selectedScore_s',speedScore, ...
    'chosenProtectedClearance_m',NaN, ...
    'chosenNominalRadiusClearance_m',NaN, ...
    'chosenUAVMinSeparation_m',NaN, ...
    'scoreWeights',struct('makespan',wMake,'meanFinish',wMean, ...
         'obstacleYieldTime',wYield,'pathObjective',wPath, ...
         'routeChangePenalty_s',switchPenalty), ...
    'trials',struct('mode',{},'feasible',{},'score_s',{}, ...
         'makespan_s',{},'meanFinish_s',{},'yieldTime_s',{}, ...
         'extraLength_m',{},'deltaRisk_m',{},'deltaAscent_m',{}, ...
         'deltaPathObjective_m',{},'minObstacleClearance_m',{}, ...
         'minUAVDistance_m',{},'reason',{}), ...
    'elapsedWall_s',NaN);
report.trials(1,1)=localRecord('speed_only',speedOnly,validSpeed, ...
    speedScore,0,0,0,0,protectedOpt);

if ~nominal.success
    report.decisionReason='obstacle_free_nominal_did_not_complete';
    report=localFinish(report,best,usedPaths,rawObstacles,opt,clock);
    return;
end
if strcmp(speedOnly.reason,'obstacle_prediction_extends_past_max_time')
    report.decisionReason='prediction_horizon_exceeds_available_simulation_time';
    report=localFinish(report,best,usedPaths,rawObstacles,opt,clock);
    return;
end
if strcmp(speedOnly.reason,'unsafe_initial_dynamic_obstacle_overlap')
    report.decisionReason='unsafe_held_start_cannot_be_repaired_by_departure_detour';
    report=localFinish(report,best,usedPaths,rawObstacles,opt,clock);
    return;
end
%% Under HOLD/HOLD, all completed UAVs still occupy their endpoints.
% Extend nominal progress to the LAST predicted obstacle knot so a late
% arrival near an occupied goal is not missed by the pre-flight screen.
nominalTrace=nominal.trace;
lastObsTime=max(arrayfun(@(x)x.time_s(end),conservativeObs));
if lastObsTime>nominalTrace.time_s(end)+1e-9
    nominalTrace.time_s(end+1,1)=lastObsTime;
    nominalTrace.progress_m(end+1,:)=nominalTrace.progress_m(end,:);
    nominalTrace.position_m(end+1,:,:)=nominalTrace.position_m(end,:,:);
end
nominalAudit=mmra_verify_dynamic_obstacles( ...
    paths,nominalTrace,protectedOpt,conservativeObs);
report.nominalObstacleClearance_m=nominalAudit.minClearance_m;
if nominalAudit.safe
    report.decisionReason='no_nominal_obstacle_conflict_no_detour_needed';
    report=localFinish(report,best,usedPaths,rawObstacles,opt,clock);
    return;
end
if validSpeed
    overhead=speedOnly.makespan-nominal.makespan;
    yieldSec=localYieldSeconds(speedOnly,protectedOpt);
    if ~forceCompare && overhead<=probeDelay && yieldSec<=probeYield
        report.decisionReason='safe_speed_control_below_switch_threshold';
        report=localFinish(report,best,usedPaths,rawObstacles,opt,clock);
        return;
    end
end

% Locate the most problematic UAV/obstacle pair on the *original*
% nominal trace. The instant is a proposal hint, never the final audit.
i=nominalAudit.closestUAV;
m=nominalAudit.closestObstacle;
if ~isfinite(i) || ~isfinite(m) || i<1 || m<1 || ...
        i>numel(paths) || m>numel(conservativeObs)
    report.decisionReason='no_violation_pair_found_for_local_replanning';
    report=localFinish(report,best,usedPaths,rawObstacles,opt,clock);
    return;
end
report.selectedUAV=i;report.selectedObstacle=m;
ob=conservativeObs(m);
xyz=squeeze(nominalTrace.position_m(:,:,i));
centerTraj=mmra_dynamic_obstacle_position(ob,nominalTrace.time_s);
[~,nearIndex]=min(sqrt(sum((xyz-centerTraj).^2,2)));
blockCenter=centerTraj(nearIndex,:);
required=ob.radius_m+localNum(opt,'speedFeedbackDroneRadius_m',1,0,Inf)+ ...
    localNum(opt,'speedFeedbackObstacleGuard_m',2,0,Inf);

proposeOpt=protectedOpt;
proposeOpt.dSafe=max(opt.dSafe,required+2);
proposeOpt.spatialRepairSpan_m=[max(80,4*required),max(140,7*required)];
proposeOpt.spatialRepairOffset_m=[max(45,2*required),max(75,3.5*required)];
proposeOpt.spatialRepairLift_m=[0 35];
[dogs,~]=mmra_spatial_detour_candidates(paths{i},blockCenter,env,proposeOpt);
report.candidateProposals=numel(dogs);
oldLength=mmra_path_length(paths{i});
oldRisk=localRisk(paths{i},env,cfg,wr);
oldAscent=localAscent(paths{i});
resolution=2;
if isfield(cfg,'guardFineResolution') && cfg.guardFineResolution>0
    resolution=cfg.guardFineResolution;
elseif isfield(cfg,'edgeResolution') && cfg.edgeResolution>0
    resolution=cfg.edgeResolution;
end
for j=1:numel(dogs)
    if report.simulatedCandidates>=maxCandidates,break;end
    localEvaluate(dogs{j},'dogleg');
end
% Use the existing local RRT* ONLY if geometry proposals did not produce
% any independently verified complete candidate. The full speed schedule
% is always replayed against ALL moving obstacles (not just the selected).
if tryRRT && report.completedCandidates==0 && ...
        report.simulatedCandidates<maxCandidates
    patches=mmra_dynamic_local_rrt_detour( ...
        paths{i},blockCenter,required,env,cfg);
    report.candidateProposals=report.candidateProposals+numel(patches);
    for j=1:numel(patches)
        if report.simulatedCandidates>=maxCandidates,break;end
        localEvaluate(patches{j},'local_rrt');
    end
end
if strcmp(report.strategy,'speed_only')
    if validSpeed
        report.decisionReason='speed_control_lower_multicriteria_cost';
    else
        report.decisionReason='no_verified_complete_detour_found';
    end
else
    report.decisionReason='verified_detour_lower_cost_or_speed_failed';
end
report=localFinish(report,best,usedPaths,rawObstacles,opt,clock);

    function localEvaluate(candidate,mode)
        if isempty(candidate) || size(candidate,2)~=3 || size(candidate,1)<2 || ...
                any(~isfinite(candidate(:)))
            return;
        end
        if norm(candidate(1,:)-paths{i}(1,:))>1e-7 || ...
                norm(candidate(end,:)-paths{i}(end,:))>1e-7
            return;
        end
        candidateLength=mmra_path_length(candidate);
        if candidateLength>oldLength*maxRatio+1e-8 || ...
                ~mmra_path_free(candidate,env,resolution)
            return;
        end
        report.terrainValidCandidates=report.terrainValidCandidates+1;
        r=localRisk(candidate,env,cfg,wr);
        a=localAscent(candidate);
        dl=candidateLength-oldLength;
        dr=r-oldRisk;da=a-oldAscent;
        dj=dl+wr*dr+wa*da;
        trialPaths=paths;
        trialPaths{i}=candidate;
        controlled=mmra_schedule_speed_feedback(trialPaths,protectedOpt);
        report.simulatedCandidates=report.simulatedCandidates+1;
        feasible=localVerified(controlled,protectedOpt);
        score=Inf;
        if feasible
            report.completedCandidates=report.completedCandidates+1;
            score=localScore(controlled,dj,1,protectedOpt, ...
                wMake,wMean,wYield,wPath,switchPenalty);
            if score < report.selectedScore_s-minGain
                best=controlled;
                usedPaths=trialPaths;
                report.selectedScore_s=score;
                report.selectedExtraLength_m=dl;
                report.selectedDeltaRisk_m=dr;
                report.selectedDeltaAscent_m=da;
                report.selectedDeltaPathObjective_m=dj;
                report.strategy='local_detour_then_speed_feedback';
            end
        end
        n=numel(report.trials)+1;
        report.trials(n,1)=localRecord(mode,controlled,feasible,score, ...
            dl,dr,da,dj,protectedOpt);
    end
end

function score=localScore(sched,deltaJ,hasDetour,opt,wMake,wMean,wYield,wPath,penalty)
score=wMake*sched.makespan+ ...
    wMean*mean(sched.completionTimes_s)+ ...
    wYield*localYieldSeconds(sched,opt)+ ...
    wPath*deltaJ/opt.speed+hasDetour*penalty;
end

function r=localRisk(path,env,cfg,w)
if w>0
    r=mmra_path_risk(path,env,cfg.riskCostBand_m,cfg.riskCostResolution_m);
else
    r=0;
end
end

function a=localAscent(p)
a=sum(max(0,diff(p(:,3))));
end

function isValid=localVerified(s,opt)
isValid=isfield(s,'success') && s.success && ...
    isfield(s,'validation') && isstruct(s.validation) && ...
    isfield(s.validation,'safe') && s.validation.safe && ...
    isfield(s.validation,'complete') && s.validation.complete && ...
    isfield(s.validation,'dynamicObstacles') && ...
    s.validation.dynamicObstacles.safe && ...
    isfield(s,'minSeparation') && ...
    s.minSeparation>=opt.dSafe-opt.tol-1e-8 && ...
    isfield(s,'obstacleMinClearance_m') && ...
    s.obstacleMinClearance_m>=-opt.tol-1e-8 && ...
    all(isfinite(s.completionTimes_s));
end

function seconds=localYieldSeconds(s,opt)
dt=localNum(opt,'speedFeedbackDt_s',0.2,eps,Inf);
if isfield(s,'trace') && isfield(s.trace,'dt_s')
    dt=s.trace.dt_s;
end
seconds=s.obstacleYieldSteps*dt;
end

function rec=localRecord(mode,s,feasible,score,dl,dr,da,dj,opt)
rec=struct('mode',mode,'feasible',feasible,'score_s',score, ...
    'makespan_s',NaN,'meanFinish_s',NaN, ...
    'yieldTime_s',localYieldSeconds(s,opt), ...
    'extraLength_m',dl,'deltaRisk_m',dr,'deltaAscent_m',da, ...
    'deltaPathObjective_m',dj,'minObstacleClearance_m',NaN, ...
    'minUAVDistance_m',NaN,'reason',s.reason);
if feasible
    rec.makespan_s=s.makespan;
    rec.meanFinish_s=mean(s.completionTimes_s);
end
if isfield(s,'obstacleMinClearance_m')
    rec.minObstacleClearance_m=s.obstacleMinClearance_m;
end
if isfield(s,'minSeparation')
    rec.minUAVDistance_m=s.minSeparation;
end
end

function report=localFinish(report,best,paths,rawOb,opt,clock)
report.elapsedWall_s=toc(clock);
if isfield(best,'minSeparation')
    report.chosenUAVMinSeparation_m=best.minSeparation;
end
if isfield(best,'obstacleMinClearance_m')
    report.chosenProtectedClearance_m=best.obstacleMinClearance_m;
end
% Clearance against nominal obstacle geometry is informative only. The
% actual safety acceptance uses the *inflated* radius when requested.
if isfield(best,'trace') && isfield(best.trace,'time_s') && ...
        numel(best.trace.time_s)>=2
    nominalClear=mmra_verify_dynamic_obstacles(paths,best.trace,opt,rawOb);
    report.chosenNominalRadiusClearance_m=nominalClear.minClearance_m;
end
end

function x=localNum(opt,key,defaultVal,lo,hi)
if isfield(opt,key) && ~isempty(opt.(key))
    x=opt.(key);
else
    x=defaultVal;
end
assert(isnumeric(x) || islogical(x),['Invalid parameter: ' key]);
assert(isscalar(x) && isreal(x) && isfinite(double(x)) && ...
    x>=lo && x<=hi,['Invalid range for parameter: ' key]);
end
