function [loser,cause]=mmra_coordination_dynamic_yielder( ...
    i,j,geom,s,pos,rank,caps,arc,waitCredit,tieSeconds)
%MMRA_COORDINATION_DYNAMIC_YIELDER Decide a NEW encounter's right-of-way.
% This per-conflict priority can change BETWEEN distinct encounters. The
% speed controller LATCHES an active encounter's decision until it clears.
% Earliest predicted arrival at a geometric conflict point wins; near-ties
% favor the UAV with more previously accrued yield time (fairness credit).
% Head-on/crossing conflicts use this scheme. Close same-direction convoys
% still let the front UAV proceed. Acyclic global priority/deadlock-freedom
% is NOT mathematically guaranteed; shield verification remains mandatory.
U=numel(s);
assert(i>=1 && i<=U && j>=1 && j<=U && i~=j);
assert(numel(rank)==U && numel(caps)==U && numel(waitCredit)==U);
assert(isfinite(tieSeconds) && tieSeconds>=0);
if s(i)>=geom{i}.length-1e-8,loser=j;cause='completed_owner';return;end
if s(j)>=geom{j}.length-1e-8,loser=i;cause='completed_owner';return;end
ui=localTangent(geom{i},s(i));uj=localTangent(geom{j},s(j));
if dot(ui,uj)>0.75
    along=dot(pos(i,:)-pos(j,:),ui);
    lateral=norm((pos(i,:)-pos(j,:))-along*ui);
    if lateral<15 && abs(along)>1.0
        if along>0,loser=j;else,loser=i;end
        cause='convoy_front';return;
    end
end
if ~isempty(arc) && all(size(arc)==[U U]) && ...
        all(isfinite([arc(i,j),arc(j,i)])) && ...
        arc(i,j)>=s(i)-1.0 && arc(j,i)>=s(j)-1.0
    etaI=max(0,(arc(i,j)-s(i))/caps(i));
    etaJ=max(0,(arc(j,i)-s(j))/caps(j));
    if etaI+tieSeconds<etaJ
        loser=j;cause='eta_priority';return;
    elseif etaJ+tieSeconds<etaI
        loser=i;cause='eta_priority';return;
    end
end
% Fairness credit is only used when the geometric ETA does not decide.
if waitCredit(i)>waitCredit(j)+0.3
    loser=j;cause='yield_age';return;
elseif waitCredit(j)>waitCredit(i)+0.3
    loser=i;cause='yield_age';return;
end
if rank(i)<rank(j),loser=j;else,loser=i;end
cause='total_order_tiebreak';
end

function u=localTangent(g,s)
k=find(g.cumulative<=s+1e-10,1,'last');
k=min(k,size(g.points,1)-1);
q=g.points(k+1,:)-g.points(k,:);
u=q/max(norm(q),1e-12);
end
