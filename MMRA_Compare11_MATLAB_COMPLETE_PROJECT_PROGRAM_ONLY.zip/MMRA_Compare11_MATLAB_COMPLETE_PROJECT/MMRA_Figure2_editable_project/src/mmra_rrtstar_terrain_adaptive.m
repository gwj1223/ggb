function [path,st] = mmra_rrtstar_terrain_adaptive(startPos,goalPos,env,cfg,guided)
%MMRA_RRTSTAR_TERRAIN_ADAPTIVE Three-objective anytime search with
% terrain-ranked candidate sampling, incumbent-corridor refinement and
% clearance/slope-sensitive steering. Independent of the frozen baseline.
% Retains original edge checks, parent selection and descendant rewiring.
% Goal is NOT added to the growth tree: feasible goal edges are tracked
% separately, and their root-to-goal costs are recomputed after rewiring.
% Fixed-iteration best-so-far objective is monotone; a finite budget is
% NOT a proof of asymptotic optimality or a global optimum.
if nargin<5, guided=true; end
% v2.1: fixed-step RRT* with optional risk and positive ascent cost.
% Resolve weight fields ONCE, not for every candidate edge.
[riskWeight,ascentWeight,costMode]=mmra_cost_weights(cfg);
useComposite=(riskWeight>0 || ascentWeight>0);
cfg.activeRiskWeight=riskWeight;
cfg.activeAscentWeight=ascentWeight;
evalMode='fused';
if isfield(cfg,'costEvalMode') && ~isempty(cfg.costEvalMode)
    evalMode=char(cfg.costEvalMode);
end
assert(any(strcmpi(evalMode,{'fused','separate'})), ...
    'cfg.costEvalMode must be fused or separate');
clockBudget=Inf;
if isfield(cfg,'wallBudget_s') && ~isempty(cfg.wallBudget_s)
    clockBudget=cfg.wallBudget_s;
end
assert(isnumeric(clockBudget) && isscalar(clockBudget) && ...
    ~isnan(clockBudget) && clockBudget>0, 'Invalid search clock budget');
limitByClock=isfinite(clockBudget);
startPos=reshape(startPos,1,3); goalPos=reshape(goalPos,1,3);
ta=mmra_ta_options(cfg);
emptyDiag=struct('samples',0,'active',0,'nearSafety',0, ...
    'belowSafety',0,'repulsionDominant',0,'clipped',0, ...
    'ratioSum',0,'angleToAttractionSum',0, ...
    'angleFromLegacySum',0,'angleToAttractionCount',0, ...
    'angleFromLegacyCount',0,'activeFraction',NaN, ...
    'nearSafetyFraction',NaN,'belowSafetyFraction',NaN, ...
    'clippedFraction',NaN,'dominantFraction',NaN, ...
    'meanRepulsiveToAttractiveRatio',NaN, ...
    'meanAngleToAttractionDeg',NaN,'meanAngleFromLegacyDeg',NaN);
collectDiag=guided && isfield(cfg,'collectApfDiagnostics') ...
    && cfg.collectApfDiagnostics;
st=struct('success',false,'reason','','iterations',0,'firstIter',NaN, ...
    'elapsed_s',0,'nodes',1,'rejected',0,'accepted',0, ...
    'pathLength',NaN,'treeCostError',NaN,'guidedSamples',0, ...
    'uniformSamples',0,'zeroGradientSamples',0, 'apfDiag',emptyDiag, ...
    'costMode',costMode,'riskCostWeight',riskWeight, ...
    'ascentCostWeight',ascentWeight,'costEvalMode',evalMode, ...
    'pathRiskIntegral_m',NaN,'pathAscent_m',NaN, ...
    'pathObjective_m',NaN,'edgeCostEvaluations',0, ...
    'fusedRiskEvaluations',0,'timedOut',false, ...
    'rrtStopMode','terrain_adaptive','firstObjective_m',NaN, ...
    'firstPathLength_m',NaN,'firstPathRiskIntegral_m',NaN, ...
    'firstPathAscent_m',NaN,'firstFeasiblePath',zeros(0,3), ...
    'improvementCount',0,'improvementPct',NaN, ...
    'bestCostByIteration_m',zeros(0,1), ...
    'taConfig',ta,'taTerrainSamples',0,'taCorridorSamples',0, ...
    'taUniformSamples',0,'taAdaptedSteps',0, ...
    'taMeanSteerStep_m',NaN,'taMinSteerStep_m',NaN, ...
    'taMaxSteerStep_m',NaN,'taSteerPressureSum',0);
path=zeros(0,3);
if ~(mmra_is_free(startPos,env) && mmra_is_free(goalPos,env))
    st.reason='invalid_start_or_goal'; return;
end
if norm(startPos-goalPos) < 1e-10
    st.success=true; st.reason='same_start_goal'; st.iterations=0;
    path=[startPos; goalPos]; st.pathLength=0; st.treeCostError=0;
    st.pathRiskIntegral_m=0; st.pathAscent_m=0; st.pathObjective_m=0;
    st.firstIter=0; st.firstObjective_m=0; st.firstPathLength_m=0;
    st.firstPathRiskIntegral_m=0; st.firstPathAscent_m=0;
    st.firstFeasiblePath=path; st.improvementPct=0;
    return;
end
if cfg.maxIter<1, st.reason='iteration_budget_exhausted'; return; end

nodes=zeros(cfg.maxIter+2,3); parents=zeros(cfg.maxIter+2,1);
costs=inf(cfg.maxIter+2,1);
nodes(1,:)=startPos; costs(1)=0; n=1;
% Keep all feasible goal connections. Rewiring may improve a candidate's
% root-to-goal cost even when its connecting edge is unchanged.
goalParents=zeros(0,1); goalEdgeCosts=zeros(0,1);
bestGoalCost=Inf;
bestGoalParent=0;
bestGoalEdgeCost=Inf;
bestHistory=NaN(cfg.maxIter,1);
bestGoalPath=zeros(0,3);
steerStepSum=0;steerStepCount=0;
tStart=tic;
for it=1:cfg.maxIter
    % A common search-core budget includes all multi-objective evaluations.
    if limitByClock && toc(tStart)>=clockBudget
        st.timedOut=true;
        break;
    end
    st.iterations=it;
    % Carry the incumbent through rejected/duplicate samples too.
    if isfinite(bestGoalCost),bestHistory(it)=bestGoalCost;end
    if rand<cfg.goalBias
        q=goalPos;
    else
        [q,kind,tag,d]=mmra_ta_sample( ...
            startPos,goalPos,env,cfg,ta,bestGoalPath, ...
            bestGoalCost,guided,collectDiag);
        switch kind
            case 'terrain'
                st.taTerrainSamples=st.taTerrainSamples+1;
            case 'corridor'
                st.taCorridorSamples=st.taCorridorSamples+1;
            otherwise
                st.taUniformSamples=st.taUniformSamples+1;
        end
        if collectDiag && d.valid
            a=st.apfDiag;
            a.samples=a.samples+1;
            a.active=a.active+double(d.active);
            a.nearSafety=a.nearSafety+double(d.nearSafety);
            a.belowSafety=a.belowSafety+double(d.belowSafety);
            a.repulsionDominant=a.repulsionDominant+double(d.repulsionDominant);
            a.clipped=a.clipped+double(d.clipped);
            a.ratioSum=a.ratioSum+d.ratio;
            if isfinite(d.angleToAttractionDeg)
                a.angleToAttractionSum=a.angleToAttractionSum+d.angleToAttractionDeg;
                a.angleToAttractionCount=a.angleToAttractionCount+1;
            end
            if isfinite(d.angleFromLegacyDeg)
                a.angleFromLegacySum=a.angleFromLegacySum+d.angleFromLegacyDeg;
                a.angleFromLegacyCount=a.angleFromLegacyCount+1;
            end
            st.apfDiag=a;
        end
        if strcmp(tag,'guided'), st.guidedSamples=st.guidedSamples+1; end
        if strcmp(tag,'uniform_mix') || strcmp(tag,'plain')
            st.uniformSamples=st.uniformSamples+1;
        end
        if strcmp(tag,'zero_gradient_fallback')
            st.zeroGradientSamples=st.zeroGradientSamples+1;
        end
    end

    distances=sqrt(sum(bsxfun(@minus,nodes(1:n,:),q).^2,2));
    [~,j]=min(distances);
    d=q-nodes(j,:); mag=norm(d);
    if mag<=1e-12, continue; end
    [steerStep,steerPressure]=mmra_ta_steering_step( ...
        nodes(j,:),env,cfg,ta);
    if steerStep<cfg.step-1e-9
        st.taAdaptedSteps=st.taAdaptedSteps+1;
    end
    st.taSteerPressureSum=st.taSteerPressureSum+steerPressure;
    steerStepSum=steerStepSum+steerStep;
    steerStepCount=steerStepCount+1;
    if isnan(st.taMinSteerStep_m)
        st.taMinSteerStep_m=steerStep;
        st.taMaxSteerStep_m=steerStep;
    else
        st.taMinSteerStep_m=min(st.taMinSteerStep_m,steerStep);
        st.taMaxSteerStep_m=max(st.taMaxSteerStep_m,steerStep);
    end
    qNew=nodes(j,:)+min(steerStep,mag)*d/mag;
    nearestEdgeCost=NaN;
    if useComposite
        [edgeOK,nearestEdgeCost,fused]=mmra_edge_eval( ...
            nodes(j,:),qNew,env,cfg);
        st.edgeCostEvaluations=st.edgeCostEvaluations+1;
        st.fusedRiskEvaluations=st.fusedRiskEvaluations+double(fused);
    else
        edgeOK=mmra_edge_free(nodes(j,:),qNew,env,cfg.edgeResolution);
    end
    if ~edgeOK
        st.rejected=st.rejected+1; continue;
    end

    nearDist=sqrt(sum(bsxfun(@minus,nodes(1:n,:),qNew).^2,2));
    neigh=find(nearDist<=cfg.rewireRadius);
    bestParent=j; bestCost=costs(j)+nearDist(j);
    if useComposite
        % Reuse the cost of the nearest edge already collision checked.
        bestCost=costs(j)+nearestEdgeCost;
    end
    for aa=1:numel(neigh)
        k=neigh(aa);
        if ~useComposite
            % v1.7 length-only parent selection is unchanged.
            c=costs(k)+nearDist(k);
            if c+1e-10<bestCost && ...
                    mmra_edge_free(nodes(k,:),qNew,env,cfg.edgeResolution)
                bestParent=k; bestCost=c;
            end
        else
            % Nonnegative risk and ascent yield a stronger safe lower bound.
            edgeLB=nearDist(k)+ascentWeight* ...
                max(0,qNew(3)-nodes(k,3));
            if costs(k)+edgeLB+1e-10>=bestCost, continue; end
            [ok,edgeJ,fused]=mmra_edge_eval(nodes(k,:),qNew,env,cfg);
            st.edgeCostEvaluations=st.edgeCostEvaluations+1;
            st.fusedRiskEvaluations=st.fusedRiskEvaluations+double(fused);
            if ~ok,continue;end
            c=costs(k)+edgeJ;
            if c+1e-10<bestCost
                bestParent=k; bestCost=c;
            end
        end
    end
    n=n+1; nodes(n,:)=qNew; parents(n)=bestParent;
    costs(n)=bestCost; st.accepted=st.accepted+1;

    % Forbid creating a parent cycle by rewiring an ancestor of bestParent.
    ancestor=false(n,1); z=bestParent;
    while z>0
        ancestor(z)=true; z=parents(z);
    end
    for aa=1:numel(neigh)
        k=neigh(aa);
        if k==1 || k==bestParent || ancestor(k), continue; end
        if ~useComposite
            % Preserve old length-only rewiring behavior and cost deltas.
            c=bestCost+nearDist(k);
            qualifies=c+1e-10<costs(k) && ...
                mmra_edge_free(qNew,nodes(k,:),env,cfg.edgeResolution);
        else
            qualifies=false;
            edgeLB=nearDist(k)+ascentWeight* ...
                max(0,nodes(k,3)-qNew(3));
            if bestCost+edgeLB+1e-10<costs(k)
                [ok,edgeJ,fused]=mmra_edge_eval(qNew,nodes(k,:),env,cfg);
                st.edgeCostEvaluations=st.edgeCostEvaluations+1;
                st.fusedRiskEvaluations=st.fusedRiskEvaluations+double(fused);
                if ok
                    c=bestCost+edgeJ;
                    qualifies=c+1e-10<costs(k);
                end
            end
        end
        if qualifies
            delta=c-costs(k);
            parents(k)=n; costs(k)=c;
            % Additive edge objective: descendants all shift by SAME delta.
            stack=k;
            while ~isempty(stack)
                curr=stack(end); stack(end)=[];
                children=find(parents(1:n)==curr);
                if ~isempty(children)
                    costs(children)=costs(children)+delta;
                    stack=[stack; children(:)]; %#ok<AGROW>
                end
            end
        end
    end

    % Record feasible connections to the GOAL without inserting a goal
    % node into the growing tree. A goal node in the tree would distort
    % nearest-neighbor selection and may create spurious branches.
    if norm(qNew-goalPos)<=cfg.goalRadius
        goalEdgeJ=NaN;
        if useComposite
            [goalEdgeOK,goalEdgeJ,fused]=mmra_edge_eval( ...
                qNew,goalPos,env,cfg);
            st.edgeCostEvaluations=st.edgeCostEvaluations+1;
            st.fusedRiskEvaluations=st.fusedRiskEvaluations+double(fused);
        else
            goalEdgeOK=mmra_edge_free(qNew,goalPos,env,cfg.edgeResolution);
            if goalEdgeOK,goalEdgeJ=norm(qNew-goalPos);end
        end
        if goalEdgeOK
            goalParents(end+1,1)=n; %#ok<AGROW>
            goalEdgeCosts(end+1,1)=goalEdgeJ; %#ok<AGROW>
        end
    end
    % Re-evaluate ALL previously valid goal edges using CURRENT tree costs
    % after this iteration's descendant rewiring; they can improve even
    % when the newest sample does not connect to the goal.
    if ~isempty(goalParents)
        [candidateCost,ix]=min(costs(goalParents)+goalEdgeCosts);
        if ~st.success || candidateCost+1e-9<bestGoalCost
            firstFound=~st.success;
            bestGoalCost=candidateCost;
            bestGoalParent=goalParents(ix);
            bestGoalEdgeCost=goalEdgeCosts(ix);
            st.success=true;
            bestGoalPath=mmra_rrtstar_terrain_adaptive_reconstruct( ...
                nodes,parents,bestGoalParent,goalPos);
            if firstFound
                st.firstIter=it;
                st.firstObjective_m=candidateCost;
                firstPath=mmra_rrtstar_terrain_adaptive_reconstruct( ...
                    nodes,parents,bestGoalParent,goalPos);
                st.firstFeasiblePath=firstPath;
                st.firstPathLength_m=mmra_path_length(firstPath);
                st.firstPathAscent_m=mmra_path_ascent(firstPath);
                if isfield(cfg,'riskCostBand_m') && ...
                        isfield(cfg,'riskCostResolution_m')
                    st.firstPathRiskIntegral_m=mmra_path_risk( ...
                        firstPath,env,cfg.riskCostBand_m, ...
                        cfg.riskCostResolution_m);
                end
            else
                st.improvementCount=st.improvementCount+1;
            end
        end
        bestHistory(it)=bestGoalCost;
    end
end
% Aggregate diagnostic measurements from the ACTUAL non-goal RRT* samples.
% Diagnostic run times include instrument overhead and are NOT benchmark times.
a=st.apfDiag;
if a.samples>0
    a.activeFraction=a.active/a.samples;
    a.nearSafetyFraction=a.nearSafety/a.samples;
    a.belowSafetyFraction=a.belowSafety/a.samples;
    a.clippedFraction=a.clipped/a.samples;
    a.dominantFraction=a.repulsionDominant/a.samples;
    a.meanRepulsiveToAttractiveRatio=a.ratioSum/a.samples;
    if a.angleToAttractionCount>0
        a.meanAngleToAttractionDeg=a.angleToAttractionSum/a.angleToAttractionCount;
    end
    if a.angleFromLegacyCount>0
        a.meanAngleFromLegacyDeg=a.angleFromLegacySum/a.angleFromLegacyCount;
    end
end
st.apfDiag=a;
if steerStepCount>0
    st.taMeanSteerStep_m=steerStepSum/steerStepCount;
end
st.elapsed_s=toc(tStart);
st.nodes=n;
st.bestCostByIteration_m=bestHistory(1:st.iterations);
if ~st.success
    if st.timedOut
        st.reason='wall_clock_budget_exhausted';
    else
        st.reason='iteration_budget_exhausted';
    end
    return;
end
if st.timedOut
    st.reason='anytime_wall_budget_reached';
else
    st.reason='anytime_iteration_budget_reached';
end
% Re-evaluate the cheapest goal connection from the FINAL tree. Costs
% cannot increase because rewiring accepts improvements only.
[finalCost,bestIdx]=min(costs(goalParents)+goalEdgeCosts);
assert(finalCost<=st.firstObjective_m+1e-7, ...
    'RRT* tree rewiring increased the best feasible objective');
bestGoalParent=goalParents(bestIdx);
bestGoalEdgeCost=goalEdgeCosts(bestIdx);
path=mmra_rrtstar_terrain_adaptive_reconstruct( ...
    nodes,parents,bestGoalParent,goalPos);
st.improvementPct=100*(st.firstObjective_m-finalCost)/ ...
    max(st.firstObjective_m,eps);
st.pathLength=mmra_path_length(path);
st.pathAscent_m=mmra_path_ascent(path);
% Report all metrics for EVERY successful raw path, even length-only mode.
% Raw path only: post-pruning/smoothing has different objective values.
if isfield(cfg,'riskCostBand_m') && isfield(cfg,'riskCostResolution_m')
    st.pathRiskIntegral_m=mmra_path_risk(path,env, ...
        cfg.riskCostBand_m,cfg.riskCostResolution_m);
end
st.pathObjective_m=costs(bestGoalParent)+bestGoalEdgeCost;
assert(abs(st.pathObjective_m-finalCost)<1e-7, ...
    'Best goal connection differs from recorded cost');
% Verify stored COMPOSITE cumulative costs against every edge and parent.
errors=zeros(n,1);
for i=2:n
    if useComposite
        edgeCost=mmra_edge_objective(nodes(parents(i),:), ...
            nodes(i,:),env,cfg);
    else
        edgeCost=norm(nodes(i,:)-nodes(parents(i),:));
    end
    errors(i)=abs(costs(i)-(costs(parents(i))+edgeCost));
end
st.treeCostError=max(errors);
if isfinite(st.pathRiskIntegral_m)
    expected=st.pathLength+riskWeight*st.pathRiskIntegral_m+ ...
        ascentWeight*st.pathAscent_m;
    assert(abs(st.pathObjective_m-expected)<1e-6, ...
        'Goal cumulative objective is inconsistent with returned path');
end
if ~mmra_path_free(path,env,cfg.edgeResolution)
    error('RRT* returned a geometrically invalid path');
end
end

function path=mmra_rrtstar_terrain_adaptive_reconstruct(nodes,parents,lastIdx,goalPos)
% Reconstruct a non-cyclic tree path and append the independent goal edge.
n=size(nodes,1);
ids=zeros(n,1);cnt=0;idx=lastIdx;visited=false(n,1);
while idx>0
    assert(idx<=n && ~visited(idx), 'Parent cycle in anytime RRT*');
    visited(idx)=true;
    cnt=cnt+1;ids(cnt)=idx;idx=parents(idx);
end
path=nodes(flipud(ids(1:cnt)),:);
if norm(path(end,:)-goalPos)>1e-12
    path=[path;goalPos];
end
end
