function out=mmra_coordination_temporal_conflicts(paths,opt,launchTimes,spatial)
%MMRA_COORDINATION_TEMPORAL_CONFLICTS Space-TIME conflict screening.
% Nominal model: each UAV is HELD at start until its individually assigned
% launch time, then travels at its capped constant speed, and HOLDS its
% final waypoint.  Within this nominal model, the closest separation is
% analytically minimized over affine subintervals split at ALL path and
% launch/arrival knots, including times between sample points.
%
% This is a PROPOSAL HEURISTIC, NOT an execution safety certificate:
% actual speed-feedback traces accelerate/brake, so their timing differs.
% An independently verified full speed trace is ALWAYS required before a
% candidate can be reported feasible.
%
% out.unsafeEdge: predicted nominal closest distance < opt.dSafe.
% out.alertEdge: predicted nominal closest distance <= alert threshold.
% out.firstUnsafeTime_s: first nominal unsafe interval start (conservative).
% out.minDistance_m / tClosest_s: full held-start/held-end nominal motion.
U=numel(paths);
if nargin<4 || isempty(spatial)
    spatial=mmra_coordination_conflict_graph(paths,opt);
end
if nargin<3 || isempty(launchTimes),launchTimes=zeros(U,1);end
tau=double(launchTimes(:));
assert(numel(tau)==U && all(isfinite(tau)) && all(tau>=0), ...
    'Launch times must be a finite, nonnegative per-UAV vector.');
assert(strcmpi(opt.startPolicy,'hold') && strcmpi(opt.endPolicy,'hold'), ...
    'Temporal predictor requires HOLD/HOLD occupancy.');
cap=spatial.speedCaps_mps(:);
assert(numel(cap)==U && all(cap>0));
alert=localVal(opt,'coordinationTemporalAlert_m', ...
    opt.dSafe+localVal(opt,'speedFeedbackGuard_m',1)+3);
assert(isscalar(alert) && isfinite(alert) && alert>=opt.dSafe);
geom=cell(U,1);
arrivals=zeros(U,1);
for i=1:U
    [p,c,L]=mmra_arc(paths{i});
    geom{i}=struct('points',p,'cumulative',c,'length',L);
    arrivals(i)=tau(i)+L/cap(i);
end
endTime=max(arrivals);
distance=inf(U,U);closest=NaN(U,U);
firstUnsafe=inf(U,U);firstAlert=inf(U,U);
for i=1:U
    distance(i,i)=0;
end
for i=1:U-1
    for j=i+1:U
        % Geometrically separated routes cannot collide at any time.
        if ~spatial.edge(i,j) && ...
                spatial.distance_m(i,j)>alert+1e-9
            distance(i,j)=spatial.distance_m(i,j);
            distance(j,i)=distance(i,j);
            continue;
        end
        knots=[0;endTime; tau(i)+geom{i}.cumulative/cap(i); ...
            tau(j)+geom{j}.cumulative/cap(j)];
        knots=unique(sort(max(0,min(endTime,knots))));
        pairMin=inf;atTime=NaN;unsafeAt=inf;alertAt=inf;
        for k=1:numel(knots)-1
            t0=knots(k);t1=knots(k+1);
            if t1-t0<1e-12,continue;end
            ai0=localProgress(t0,tau(i),cap(i),geom{i}.length);
            ai1=localProgress(t1,tau(i),cap(i),geom{i}.length);
            bj0=localProgress(t0,tau(j),cap(j),geom{j}.length);
            bj1=localProgress(t1,tau(j),cap(j),geom{j}.length);
            [d,rel]=mmra_speed_interval_minsep(geom{i},geom{j}, ...
                ai0,ai1,bj0,bj1,t1-t0);
            if d<pairMin,pairMin=d;atTime=t0+rel;end
            if d<opt.dSafe-opt.tol && isinf(unsafeAt),unsafeAt=t0;end
            if d<=alert+1e-9 && isinf(alertAt),alertAt=t0;end
        end
        if isinf(pairMin)
            p1=mmra_speed_arc_position(geom{i},0);
            p2=mmra_speed_arc_position(geom{j},0);
            pairMin=norm(p1-p2);atTime=0;
        end
        distance(i,j)=pairMin;distance(j,i)=pairMin;
        closest(i,j)=atTime;closest(j,i)=atTime;
        firstUnsafe(i,j)=unsafeAt;firstUnsafe(j,i)=unsafeAt;
        firstAlert(i,j)=alertAt;firstAlert(j,i)=alertAt;
    end
end
unsafe=distance<opt.dSafe-opt.tol;
alertEdge=distance<=alert+1e-9;
unsafe(1:U+1:end)=false;
alertEdge(1:U+1:end)=false;
out=struct('launchTimes_s',tau,'arrivalTimes_s',arrivals, ...
    'alertThreshold_m',alert,'minDistance_m',distance, ...
    'tClosest_s',closest,'unsafeEdge',unsafe, ...
    'alertEdge',alertEdge,'numUnsafePairs',nnz(triu(unsafe,1)), ...
    'numAlertPairs',nnz(triu(alertEdge,1)), ...
    'firstUnsafeTime_s',firstUnsafe, ...
    'firstAlertTime_s',firstAlert, ...
    'model','nominal_constant_speed_hold_hold__screening_only');
end

function s=localProgress(t,tau,v,L)
s=max(0,min(L,(t-tau)*v));
end
function v=localVal(s,key,def)
if isfield(s,key) && ~isempty(s.(key)),v=double(s.(key));else,v=def;end
end
