function obstacles = mmra_dynamic_obstacles_prepare(obstacles)
%MMRA_DYNAMIC_OBSTACLES_PREPARE Validate moving spherical obstacles.
% Each element must contain:
%   time_s       : N x 1 strictly increasing ABSOLUTE times in seconds
%   position_m   : N x 3 XYZ centers in metres at those times
%   radius_m     : scalar physical radius in metres
%   name         : optional descriptive label
% Between time knots: linear interpolation. Before first/after last knot:
% the center is stationary at the first/last position (HOLD/HOLD).
% Obstacle trajectories are assumed KNOWN/PREDICTED and do not react to UAVs.
% Derived field maxSpeed_mps is populated for conservative broad phases.
if nargin<1 || isempty(obstacles)
    obstacles=struct('time_s',{},'position_m',{},'radius_m',{}, ...
        'name',{},'maxSpeed_mps',{});
    return;
end
assert(isstruct(obstacles) && isvector(obstacles), ...
    'Dynamic obstacles must be a 1D struct array.');
for m=1:numel(obstacles)
    ob=obstacles(m);
    assert(isfield(ob,'time_s') && isfield(ob,'position_m') && ...
        isfield(ob,'radius_m'), ...
        'Each obstacle needs time_s, position_m, and radius_m.');
    t=double(ob.time_s(:));
    p=double(ob.position_m);
    r=double(ob.radius_m);
    assert(numel(t)>=2 && all(isfinite(t)) && all(diff(t)>0), ...
        'Obstacle time knots must be finite and strictly increasing.');
    assert(size(p,1)==numel(t) && size(p,2)==3 && ...
        isreal(p) && all(isfinite(p(:))), ...
        'Obstacle position_m must be finite N-by-3 XYZ metres.');
    assert(isscalar(r) && isfinite(r) && r>=0, ...
        'Obstacle radius_m must be a nonnegative finite scalar.');
    obstacles(m).time_s=t;
    obstacles(m).position_m=p;
    obstacles(m).radius_m=r;
    if ~isfield(ob,'name') || isempty(ob.name)
        obstacles(m).name=sprintf('moving_obstacle_%d',m);
    end
    velocity=sqrt(sum(diff(p,1,1).^2,2))./diff(t);
    obstacles(m).maxSpeed_mps=max(velocity);
end
end
