function out = mmra_schedule_conflict_aware(paths,opt)
%MMRA_SCHEDULE_CONFLICT_AWARE Two-candidate priority scheduling with fallback.
% (1) Evaluate ORIGINAL length-descending priority, unchanged.
% (2) Build the initial pairwise conflict graph for simultaneous starts;
%     evaluate conflict-degree-descending priority, ties by path length.
% (3) Choose the FEASIBLE schedule with smaller mission makespan;
%     ties choose the original for deterministic backwards compatibility.
%
% With the SAME fixed paths, collision checker, delay limits and mission
% model: if baseline is feasible, selected makespan <= baseline makespan.
% Scheduling CPU time is NOT guaranteed to improve (usually increases).
% Conflict-aware priorities are a heuristic, not an optimality proof.
startAll=tic;
originalOpt=opt;
if isfield(originalOpt,'priorityOrder')
    originalOpt=rmfield(originalOpt,'priorityOrder');
end
baseline=mmra_schedule(paths,originalOpt);
U=numel(paths);
degrees=zeros(U,1); conflictEdges=0;
optBase_s=baseline.schedule_s;
optCA_s=NaN;
ca=baseline;
strategy='original_length';
attempted=false;

if baseline.success && baseline.preConflicts == 0
    % No pair conflicts: a second priority trial cannot improve on the
    % all-zero delays of the original greedy scheduler.
    strategy='original_no_initial_conflicts';
elseif isfinite(baseline.preConflicts)
    lens=zeros(U,1);
    for i=1:U
        [~,~,lens(i)]=mmra_arc(paths{i});
    end
    for i=1:U-1
        for j=i+1:U
            [~,~,isConflict]=mmra_pair_minsep(paths{i},paths{j},0,0,originalOpt);
            if isConflict
                degrees(i)=degrees(i)+1;
                degrees(j)=degrees(j)+1;
                conflictEdges=conflictEdges+1;
            end
        end
    end
    % Stable, reproducible ranking: conflict degree -> length -> UAV ID.
    [~,order]=sortrows([-degrees,-lens,(1:U)'],[1 2 3]);
    order=reshape(order,1,[]);
    if ~isequal(order,reshape(baseline.priorityOrder,1,[]))
        caOpt=originalOpt;
        caOpt.priorityOrder=order;
        ca=mmra_schedule(paths,caOpt);
        attempted=true;
        optCA_s=ca.schedule_s;
        if ca.success && (~baseline.success || ...
                ca.makespan < baseline.makespan - 1e-9)
            strategy='conflict_degree';
        elseif baseline.success
            strategy='original_length_fallback';
        else
            strategy='both_failed';
        end
    else
        strategy='same_priority_order';
    end
else
    strategy='invalid_spatial_input';
end

if strcmp(strategy,'conflict_degree')
    out=ca;
else
    out=baseline;
end
out.mode='conflict_aware';
out.chosenStrategy=strategy;
out.baselineSuccess=baseline.success;
out.baselineMakespan_s=baseline.makespan;
out.baselineSchedule_s=optBase_s;
out.altAttempted=attempted;
out.alternativeSuccess=attempted && ca.success;
out.alternativeMakespan_s=NaN;
if attempted
    out.alternativeMakespan_s=ca.makespan;
end
out.alternativeSchedule_s=optCA_s;
out.conflictDegrees=degrees;
out.conflictGraphEdges=conflictEdges;
% The original scheduler time denotes ONE attempt. For end-to-end timing,
% report the actual total time for BOTH candidate evaluations and selection.
out.schedule_s=toc(startAll);
if baseline.success
    assert(out.success && out.makespan <= baseline.makespan + 1e-8, ...
        'Fallback regression: original feasible schedule was lost');
end
end
