function [objective_m,length_m,riskIntegral_m,ascent_m] = mmra_edge_objective(a,b,env,cfg)
%MMRA_EDGE_OBJECTIVE Additive directed edge cost: L + lambda R + mu A.
% R: sampled terrain-risk integral; A=max(0,z_b-z_a), asymmetric.
% Zero-weight modes preserve the original Euclidean distance exactly.
a=reshape(a,1,3); b=reshape(b,1,3);
length_m=norm(b-a);
ascent_m=max(0,b(3)-a(3));
if isfield(cfg,'activeRiskWeight') && isfield(cfg,'activeAscentWeight')
    riskW=cfg.activeRiskWeight;
    ascentW=cfg.activeAscentWeight;
else
    [riskW,ascentW]=mmra_cost_weights(cfg);
end
riskIntegral_m=0;
if riskW>0
    riskIntegral_m=mmra_edge_risk(a,b,env, ...
        cfg.riskCostBand_m,cfg.riskCostResolution_m);
end
objective_m=length_m+riskW*riskIntegral_m+ascentW*ascent_m;
assert(isfinite(objective_m) && objective_m>=length_m-1e-9, ...
    'Invalid additive edge objective');
end
