function [dMin,tMin] = mmra_dynamic_obstacle_interval_minsep(g,s0,s1,t0,t1,obstacle)
%MMRA_DYNAMIC_OBSTACLE_INTERVAL_MINSEP Exact model-based minimum center gap.
% UAV travels constant ARC SPEED along its existing polyline on [t0,t1].
% Obstacle center follows piecewise-linear, time-stamped waypoints.
% Split at both UAV vertices AND obstacle time knots, then analytically
% minimize distance of the two affine motions over each subinterval.
assert(isfinite(t0) && isfinite(t1) && t1>t0);
assert(s1>=s0-1e-9 && s0>=-1e-9 && s1<=g.length+1e-6);
if s1-s0<=1e-13
    uU=[];
else
    x=g.cumulative(g.cumulative>s0+1e-10 & ...
        g.cumulative<s1-1e-10);
    uU=(x-s0)/(s1-s0);
end
x=obstacle.time_s(obstacle.time_s>t0+1e-10 & ...
    obstacle.time_s<t1-1e-10);
uO=(x-t0)/(t1-t0);
cut=unique(sort([0;uU(:);uO(:);1]));
dMin=inf;tMin=t0;
for k=1:numel(cut)-1
    a=cut(k);b=cut(k+1);
    if b-a<1e-13,continue;end
    pa=mmra_speed_arc_position(g,s0+(s1-s0)*a);
    pb=mmra_speed_arc_position(g,s0+(s1-s0)*b);
    oa=mmra_dynamic_obstacle_position(obstacle,t0+(t1-t0)*a);
    ob=mmra_dynamic_obstacle_position(obstacle,t0+(t1-t0)*b);
    r=pa-oa;dr=(pb-ob)-r;
    den=dot(dr,dr);
    if den<1e-20,q=0;
    else,q=max(0,min(1,-dot(r,dr)/den));end
    z=norm(r+q*dr);
    if z<dMin
        dMin=z;tMin=t0+(t1-t0)*(a+q*(b-a));
    end
end
if ~isfinite(dMin)
    dMin=norm(mmra_speed_arc_position(g,s0)- ...
        mmra_dynamic_obstacle_position(obstacle,t0));
end
end
