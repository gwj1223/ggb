function tf = mmra_is_free(points, env)
%MMRA_IS_FREE Terrain, hard no-fly regions, bounds, and clearance.
% Returns a logical column vector, one per point.
if isempty(points), tf=false(0,1); return; end
assert(size(points,2)==3,'Points must be N-by-3');
bounds = all(bsxfun(@ge,points,env.boundsLo),2) & ...
         all(bsxfun(@le,points,env.boundsHi),2);
h = mmra_terrain(points,env);
tf = bounds & all(isfinite(points),2) & ...
    points(:,3) > h + env.safetyMargin & mmra_no_fly_free(points,env);
end
