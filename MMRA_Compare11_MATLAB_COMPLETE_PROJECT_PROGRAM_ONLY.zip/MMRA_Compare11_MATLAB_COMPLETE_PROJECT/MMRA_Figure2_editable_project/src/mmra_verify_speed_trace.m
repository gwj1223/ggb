function audit = mmra_verify_speed_trace(paths,trace,opt)
%MMRA_VERIFY_SPEED_TRACE Independently check variable-speed polyline flights.
% Rebuilds the per-interval motion from recorded progress and time, not
% controller decisions or its near-miss broad-phase. Splits time at every
% geometry vertex crossing, then analytically minimizes squared distance
% between two affine segments. Checks all held starts and terminal goals.
% Exact only for ideal piecewise-constant-speed execution of the polyline;
% real acceleration, wind, navigation error, vehicle size, and corner
% dynamics require additional modeling/margins.
U=numel(paths);
audit=struct('safe',false,'complete',false,'reason','invalid_trace', ...
    'minSeparation',NaN,'postConflicts',NaN,'maxSpeed_mps',NaN, ...
    'maxSpeedSlewViolation_mps',NaN,'checkedPairIntervals',0, ...
    'firstConflictTime_s',NaN);
if ~isfield(trace,'time_s') || ~isfield(trace,'progress_m'),return;end
t=double(trace.time_s(:));s=double(trace.progress_m);
if size(s,1)~=numel(t) || size(s,2)~=U || isempty(t) || ...
        abs(t(1))>1e-8 || any(~isfinite(t)) || any(~isfinite(s(:))) || ...
        any(diff(t)<=0) || any(s(:)<-1e-7)
    return;
end
if ~strcmpi(opt.startPolicy,'hold') || ~strcmpi(opt.endPolicy,'hold')
    audit.reason='unsupported_occupancy';return;
end
p=cell(U,1);cum=cell(U,1);L=zeros(U,1);
for i=1:U
    [p{i},cum{i},L(i)]=mmra_arc(paths{i});
end
if any(any(s>repmat(L',size(s,1),1)+1e-6)) || ...
        any(abs(s(1,:))>1e-6) || any(any(diff(s,1,1)<-1e-7))
    audit.reason='invalid_progress';return;
end
cap=opt.speed*ones(U,1);
if isfield(trace,'speedCaps_mps') && numel(trace.speedCaps_mps)==U
    cap=trace.speedCaps_mps(:);
end
aUp=localField(opt,'speedFeedbackAccel_mps2',3);
aDown=localField(opt,'speedFeedbackDecel_mps2',6);
v=zeros(numel(t)-1,U);
for k=1:numel(t)-1
    v(k,:)=(s(k+1,:)-s(k,:))/(t(k+1)-t(k));
end
if isempty(v),peak=0;else,peak=max(v(:));end
audit.maxSpeed_mps=peak;
if any(any(v>repmat(cap',size(v,1),1)+1e-5))
    audit.reason='speed_cap_violated';return;
end
prev=zeros(1,U);worst=0;
for k=1:size(v,1)
    up=v(k,:)-prev;down=prev-v(k,:);
    allowedUp=aUp*(t(k+1)-t(k));
    allowedDown=aDown*(t(k+1)-t(k));
    worst=max(worst,max([up-allowedUp,down-allowedDown,0]));
    prev=v(k,:);
end
audit.maxSpeedSlewViolation_mps=worst;
if worst>1e-5
    audit.reason='speed_slew_bound_violated';return;
end
seen=false(U,U);best=inf;first=NaN;checked=0;
% The following reconstruction is intentionally separate from
% mmra_speed_interval_minsep. It uses only trace distances and paths.
for k=1:numel(t)-1
    step=t(k+1)-t(k);
    for i=1:U-1
        a=localPos(p{i},cum{i},s(k,i));
        for j=i+1:U
            b=localPos(p{j},cum{j},s(k,j));
            % Provable lower bound for skipping irrelevant FAR pairs when
            % they cannot beat the current known global minimum.
            relativeTravel=(s(k+1,i)-s(k,i))+(s(k+1,j)-s(k,j));
            if norm(a-b)-relativeTravel>=max(best,opt.dSafe)-1e-12
                continue;
            end
            checked=checked+1;
            di=localPair(p{i},cum{i},s(k,i),s(k+1,i), ...
                p{j},cum{j},s(k,j),s(k+1,j),step);
            if di<best,best=di;end
            if di<opt.dSafe-opt.tol
                seen(i,j)=true;
                if isnan(first),first=t(k);end
            end
        end
    end
end
% Include occupied stationary positions at the final recorded time.
for i=1:U-1
    a=localPos(p{i},cum{i},s(end,i));
    for j=i+1:U
        b=localPos(p{j},cum{j},s(end,j));
        di=norm(a-b);
        if di<best,best=di;end
        if di<opt.dSafe-opt.tol
            seen(i,j)=true;
            if isnan(first),first=t(end);end
        end
    end
end
audit.minSeparation=best;
audit.postConflicts=nnz(seen);
audit.checkedPairIntervals=checked;
audit.firstConflictTime_s=first;
audit.complete=all(abs(s(end,:)-L')<=1e-6);
audit.safe=audit.postConflicts==0 && best>=opt.dSafe-opt.tol-1e-9;
if ~audit.safe
    audit.reason='continuous_time_separation_violation';
elseif ~audit.complete
    audit.reason='safe_partial_trace';
else
    audit.reason='verified_complete';
end
end

function z=localField(s,k,defaultValue)
if isfield(s,k) && ~isempty(s.(k)),z=s.(k);
else,z=defaultValue;end
end

function position=localPos(pts,cum,x)
x=max(0,min(cum(end),x));
if x<=0,position=pts(1,:);return;end
if x>=cum(end),position=pts(end,:);return;end
idx=find(cum>=x,1,'first');
idx=max(2,idx);
r=(x-cum(idx-1))/(cum(idx)-cum(idx-1));
position=pts(idx-1,:)+(pts(idx,:)-pts(idx-1,:))*r;
end

function best=localPair(pa,ca,a0,a1,pb,cb,b0,b1,step)
ua=localCrossingFractions(ca,a0,a1);
ub=localCrossingFractions(cb,b0,b1);
breaks=unique(sort([0;ua(:);ub(:);1]));
best=inf;
for m=1:numel(breaks)-1
    q0=breaks(m);q1=breaks(m+1);
    if q1-q0<=1e-14,continue;end
    r0=localPos(pa,ca,a0+(a1-a0)*q0)- ...
        localPos(pb,cb,b0+(b1-b0)*q0);
    r1=localPos(pa,ca,a0+(a1-a0)*q1)- ...
        localPos(pb,cb,b0+(b1-b0)*q1);
    delta=r1-r0;
    denom=sum(delta.^2);
    if denom<1e-22,frac=0;
    else,frac=max(0,min(1,-sum(r0.*delta)/denom));end
    best=min(best,norm(r0+frac*delta));
end
if ~isfinite(best),best=norm(localPos(pa,ca,a0)-localPos(pb,cb,b0));end
end

function u=localCrossingFractions(cum,lo,hi)
if hi-lo<1e-13,u=[];return;end
middle=cum(cum>lo+1e-12 & cum<hi-1e-12);
u=(middle-lo)/(hi-lo);
end
