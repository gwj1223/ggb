function [dMin,tMin,conflict] = mmra_pair_minsep(pathA,pathB,delayA,delayB,opt)
%MMRA_PAIR_MINSEP Exact continuous minimum separation of polygonal flights.
% For FIXED piecewise-linear trajectories at constant arc-length speed,
% relative motion is affine on intervals separated by waypoint events.
% Stationary prelaunch/postarrival occupancy is configurable and included.
% This does NOT prove safety for a true continuous Bezier curve, vehicle
% controller tracking errors, terrain between edge samples, or disturbances.
[ptsA,cumA,LA]=mmra_arc(pathA);[ptsB,cumB,LB]=mmra_arc(pathB);
tA=delayA+cumA/opt.speed;tB=delayB+cumB/opt.speed;
finish=max(tA(end),tB(end));
% A positive tail detects held terminal-goal collisions.
times=unique(sort([0; tA(:); tB(:); finish+1]));
dMin=inf;tMin=NaN;
for k=1:numel(times)-1
    t0=times(k);t1=times(k+1);
    if t1-t0<=1e-12,continue;end
    mid=(t0+t1)/2;
    if ~active(mid,delayA,tA(end),opt.startPolicy,opt.endPolicy) || ...
       ~active(mid,delayB,tB(end),opt.startPolicy,opt.endPolicy)
        continue;
    end
    a0=posAt(t0,ptsA,cumA,LA,delayA,opt.speed);
    a1=posAt(t1,ptsA,cumA,LA,delayA,opt.speed);
    b0=posAt(t0,ptsB,cumB,LB,delayB,opt.speed);
    b1=posAt(t1,ptsB,cumB,LB,delayB,opt.speed);
    r0=a0-b0;dr=(a1-b1)-r0;
    if dot(dr,dr)<1e-20,u=0;
    else,u=max(0,min(1,-dot(r0,dr)/dot(dr,dr)));end
    d=norm(r0+u*dr);
    if d<dMin,dMin=d;tMin=t0+u*(t1-t0);end
end
conflict=dMin<opt.dSafe-opt.tol;
end

function yes=active(t,delay,finish,startPolicy,endPolicy)
if t<delay,yes=strcmpi(startPolicy,'hold');
elseif t>finish,yes=strcmpi(endPolicy,'hold');
else,yes=true;
end
end

function p=posAt(t,pts,cum,L,delay,v)
if t<=delay,p=pts(1,:);return;end
if t>=delay+L/v,p=pts(end,:);return;end
s=max(0,min(L,(t-delay)*v));
k=find(cum<=s,1,'last');
if k>=size(pts,1),p=pts(end,:);return;end
u=(s-cum(k))/(cum(k+1)-cum(k));
p=(1-u)*pts(k,:)+u*pts(k+1,:);
end
