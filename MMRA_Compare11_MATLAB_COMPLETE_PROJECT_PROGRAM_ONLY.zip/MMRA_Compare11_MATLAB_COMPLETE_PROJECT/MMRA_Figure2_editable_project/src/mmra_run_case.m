function result = mmra_run_case(starts,goals,relays,env,cfg,sched,guided)
%MMRA_RUN_CASE Complete spatial paths then selected temporal schedule.
% relays=[] for direct paths; otherwise N-by-3 mandatory waypoints.
% No automatic terrain-height correction; invalid start/goal returns failure.
% Relay traversal is preserved by processing each stage independently.
% No hover/dwell at relay is modeled in this version.
if nargin<7, guided=true; end
assert(size(starts,2)==3 && isequal(size(starts),size(goals)), ...
    'Starts/goals must be same-size N-by-3 arrays');
U=size(starts,1);
if ~isempty(relays), assert(isequal(size(relays),size(starts))); end
result=struct(); result.paths=cell(U,1);
result.individual=cell(U,1); result.success=false;
result.failureUAV=[]; result.reason=''; result.spatialTime_s=0;
result.scheduler=[]; result.profile=env.profile;
for i=1:U
    tStart=tic;
    if isempty(relays)
        [p,st]=mmra_plan_single(starts(i,:),goals(i,:),env,cfg,guided);
    else
        [p1,s1]=mmra_plan_single(starts(i,:),relays(i,:),env,cfg,guided);
        if s1.success
            [p2,s2]=mmra_plan_single(relays(i,:),goals(i,:),env,cfg,guided);
        else
            p2=[]; s2=struct('success',false,'reason','first_stage_failed');
        end
        if s1.success && s2.success
            p=[p1;p2(2:end,:)];
            st=struct('success',mmra_path_free(p,env,cfg.edgeResolution), ...
                'reason','two_stage_completed','stage1',s1,'stage2',s2, ...
                'pathLength',mmra_path_length(p));
        else
            p=[];
            st=struct('success',false,'reason','two_stage_search_failed', ...
                'stage1',s1,'stage2',s2,'pathLength',NaN);
        end
    end
    result.spatialTime_s=result.spatialTime_s+toc(tStart);
    result.paths{i}=p; result.individual{i}=st;
    if ~st.success, result.failureUAV(end+1)=i; end %#ok<AGROW>
end
if ~isempty(result.failureUAV)
    result.reason='spatial_planning_failed';
    return;
end
if isfield(sched,'mode') && strcmpi(sched.mode,'speed_feedback_spatial_fallback')
    result.originalPaths=result.paths;
    [result.scheduler,result.paths]=mmra_schedule_speed_with_spatial_fallback( ...
        result.paths,env,cfg,sched);
elseif isfield(sched,'mode') && strcmpi(sched.mode,'speed_feedback')
    result.scheduler=mmra_schedule_speed_feedback(result.paths,sched);
elseif isfield(sched,'mode') && strcmpi(sched.mode,'eventwindow_repair')
    result.scheduler=mmra_schedule_eventwindow(result.paths,sched);
elseif isfield(sched,'mode') && strcmpi(sched.mode,'bottleneck_repair')
    result.scheduler=mmra_schedule_bottleneck(result.paths,sched);
elseif isfield(sched,'mode') && strcmpi(sched.mode,'conflict_aware')
    result.scheduler=mmra_schedule_conflict_aware(result.paths,sched);
else
    result.scheduler=mmra_schedule(result.paths,sched);
end
result.success=result.scheduler.success;
if result.success, result.reason='completed';
else, result.reason=['scheduler_' result.scheduler.reason]; end
end
