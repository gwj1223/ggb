function ok = mmra_edge_free(a,b,env,resolution)
%MMRA_EDGE_FREE Identical segment checker for planner and postprocessing.
% Terrain is sampled; optional no-fly cylinders are tested analytically.
% The terrain check is not a formal continuous
% terrain/obstacle avoidance guarantee between sampled points.
if nargin<4 || isempty(resolution), resolution=1.5; end
assert(resolution>0 && isfinite(resolution),'Invalid edge resolution');
assert(numel(a)==3 && numel(b)==3,'Endpoints must have 3 coordinates');
a=reshape(a,1,3); b=reshape(b,1,3);
if ~all(isfinite([a b])), ok=false; return; end
n=max(1,ceil(norm(b-a)/resolution));
t=linspace(0,1,n+1).';
pts=bsxfun(@plus,a,bsxfun(@times,t,b-a));
ok=mmra_no_fly_segment_free(a,b,env) && ...
    all(mmra_is_free(pts,env));
end
