function [candidates,metadata] = mmra_spatial_detour_candidates(path,blocker,env,opt)
%MMRA_SPATIAL_DETOUR_CANDIDATES Fixed-start/goal local dogleg proposals.
% Proposals are geometry only and MUST be independently terrain/temporal
% validated by the caller. No endpoint, UAV speed, occupancy rule, or
% safety distance may be changed. Designed for a path passing close to
% another UAV's persistently occupied start or goal position.
[pts,cum,L]=mmra_arc(path);
[d,s0]=mmra_point_polyline_distance(pts,blocker);
candidates={};
metadata=struct('side',{},'span_m',{},'offset_m',{},'lift_m',{});
if d >= opt.dSafe+0.01 || L<=1e-8,return;end
if ~isfield(opt,'spatialRepairSpan_m')
    spans=[18 28 38];
else
    spans=opt.spatialRepairSpan_m;
end
if ~isfield(opt,'spatialRepairOffset_m')
    offsets=[18 26];
else
    offsets=opt.spatialRepairOffset_m;
end
if ~isfield(opt,'spatialRepairLift_m')
    lifts=[0 6];
else
    lifts=opt.spatialRepairLift_m;
end
for span=spans(:)'
    sA=max(0,s0-span);sB=min(L,s0+span);
    if sB-sA<0.2*span,continue;end
    a=localAtArc(pts,cum,sA);
    b=localAtArc(pts,cum,sB);
    bearing=b(1:2)-a(1:2);
    if norm(bearing)<1e-8
        closestSeg=find(cum>=s0,1,'first');
        if isempty(closestSeg),closestSeg=2;end
        closestSeg=max(2,closestSeg);
        bearing=pts(closestSeg,1:2)-pts(closestSeg-1,1:2);
    end
    if norm(bearing)<1e-8,continue;end
    normal=[-bearing(2) bearing(1)]/norm(bearing);
    s1=sA+0.28*(sB-sA);
    s2=sA+0.72*(sB-sA);
    w1base=localAtArc(pts,cum,s1);
    w2base=localAtArc(pts,cum,s2);
    for offset=offsets(:)'
        for side=[-1 1]
            w1=w1base; w2=w2base;
            w1(1:2)=w1(1:2)+side*offset*normal;
            w2(1:2)=w2(1:2)+side*offset*normal;
            if any(w1(1:2)<env.boundsLo(1:2)) || ...
                    any(w2(1:2)<env.boundsLo(1:2)) || ...
                    any(w1(1:2)>env.boundsHi(1:2)) || ...
                    any(w2(1:2)>env.boundsHi(1:2))
                continue;
            end
            terrainFloor=mmra_terrain([w1(1:2);w2(1:2)],env) + ...
                env.safetyMargin + 1.0;
            for lift=lifts(:)'
                u1=w1;u2=w2;
                u1(3)=max(w1(3)+lift,terrainFloor(1));
                u2(3)=max(w2(3)+lift,terrainFloor(2));
                if u1(3)>env.boundsHi(3) || u2(3)>env.boundsHi(3)
                    continue;
                end
                % Existing vertices are untouched outside [sA,sB].
                % Include exactly the two anchor interpolates plus two
                % route-offset waypoints. 0-length edges are dropped.
                p=[pts(cum<sA-1e-9,:);a;u1;u2;b; ...
                    pts(cum>sB+1e-9,:)];
                edge=sqrt(sum(diff(p,1,1).^2,2));
                p=p([true;edge>1e-9],:);
                if size(p,1)<2,continue;end
                if norm(p(1,:)-pts(1,:))>1e-8 || ...
                        norm(p(end,:)-pts(end,:))>1e-8
                    continue;
                end
                candidates{end+1,1}=p; %#ok<AGROW>
                metadata(end+1,1)=struct('side',side,'span_m',span, ...
                    'offset_m',offset,'lift_m',lift); %#ok<AGROW>
            end
        end
    end
end
end

function q=localAtArc(p,c,s)
if s<=0,q=p(1,:);return;end
if s>=c(end),q=p(end,:);return;end
i=find(c<=s,1,'last');
i=min(i,numel(c)-1);
w=(s-c(i))/(c(i+1)-c(i));
q=(1-w)*p(i,:)+w*p(i+1,:);
end
