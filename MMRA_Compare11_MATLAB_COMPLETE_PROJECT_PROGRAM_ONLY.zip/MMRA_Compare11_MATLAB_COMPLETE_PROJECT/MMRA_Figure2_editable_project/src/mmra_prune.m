function result = mmra_prune(path,env,cfg)
%MMRA_PRUNE Collision-checked shortcut pruning for MMRA and adapted scenes.
% cfg.pruneMode: 'greedy' (historical default) or 'shortest_visibility'.
% Both modes use mmra_postprocess_edge_free, allowing Urban500 to reuse
% this exact MMRA module with its analytic inflated-building checker.
result=path;
if isempty(path) || size(path,1)<=2, return; end
assert(size(path,2)==3 && all(isfinite(path(:))),'Invalid 3-D path');
mode='greedy';
if isfield(cfg,'pruneMode') && ~isempty(cfg.pruneMode)
    mode=lower(char(cfg.pruneMode));
end
switch mode
    case 'greedy'
        % Original greedy farthest-visible algorithm, preserved by default.
        out=path(1,:); i=1;
        while i<size(path,1)
            j=size(path,1);
            while j>i+1 && ...
                    ~mmra_postprocess_edge_free(path(i,:),path(j,:),env,cfg)
                j=j-1;
            end
            out(end+1,:)=path(j,:); %#ok<AGROW>
            i=j;
        end
    case 'shortest_visibility'
        % DAG dynamic programming: minimum Euclidean length among all
        % straight, collision-free connections between input waypoints.
        n=size(path,1);
        D=inf(n,1); prev=zeros(n,1); D(1)=0;
        for j=2:n
            for i=1:j-1
                if ~isfinite(D(i)), continue; end
                cand=D(i)+norm(path(j,:)-path(i,:));
                if cand<D(j)-1e-10 && ...
                        mmra_postprocess_edge_free(path(i,:),path(j,:),env,cfg)
                    D(j)=cand;
                    prev(j)=i;
                end
            end
        end
        if prev(end)==0
            warning('Visibility prune found no valid graph route; retaining input.');
            return;
        end
        inds=n;
        while inds(1)>1
            inds=[prev(inds(1)) inds]; %#ok<AGROW>
        end
        out=path(inds,:);
    otherwise
        error('Unknown cfg.pruneMode: %s',mode);
end
if mmra_postprocess_path_free(out,env,cfg)
    result=out;
else
    warning('Pruned path invalid: keeping original path');
end
end
