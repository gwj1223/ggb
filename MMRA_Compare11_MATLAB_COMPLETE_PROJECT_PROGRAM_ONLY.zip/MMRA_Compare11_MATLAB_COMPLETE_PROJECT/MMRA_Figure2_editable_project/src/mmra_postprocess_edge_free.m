function ok = mmra_postprocess_edge_free(a,b,env,cfg)
%MMRA_POSTPROCESS_EDGE_FREE Shared postprocessor collision oracle adapter.
% Ordinary MMRA terrain/NFZ experiments keep their original edge checker.
% A scene-specific planner may inject cfg.edgeFreeFcn(a,b) to use exactly
% its OWN collision geometry (e.g., Urban500 inflated 3-D building boxes).
if isfield(cfg,'edgeFreeFcn') && ~isempty(cfg.edgeFreeFcn)
    ok = cfg.edgeFreeFcn(a,b);
    assert(isscalar(ok) && (islogical(ok) || isnumeric(ok)), ...
        'cfg.edgeFreeFcn must return one logical scalar.');
    ok = logical(ok);
else
    resolution = 1.5;
    if isfield(cfg,'edgeResolution') && ~isempty(cfg.edgeResolution)
        resolution = cfg.edgeResolution;
    end
    ok = mmra_edge_free(a,b,env,resolution);
end
end
