function p = mmra_dynamic_obstacle_position(obstacle,t_s)
%MMRA_DYNAMIC_OBSTACLE_POSITION Center position at absolute time(s).
% Piecewise-linear waypoints; stationary before first and after final knot.
% Returns Nx3 for a column of query times, or 1x3 for scalar time.
assert(isnumeric(t_s) && isreal(t_s) && all(isfinite(t_s(:))));
t=obstacle.time_s(:);
q=min(t(end),max(t(1),double(t_s(:))));
p=interp1(t,obstacle.position_m,q,'linear');
end
