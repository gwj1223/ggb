function [ok,objective_m,usedFusion] = mmra_edge_eval(a,b,env,cfg)
%MMRA_EDGE_EVAL Collision check plus additive cost for one directed edge.
% When collision and risk quadrature resolutions match, the SAME terrain
% samples serve both operations, avoiding a duplicate GMM evaluation.
% With costEvalMode='separate', reproduce the v2.0 double-call algorithm.
% Neither mode provides a continuous collision certificate.
a=reshape(a,1,3);b=reshape(b,1,3);
objective_m=Inf;usedFusion=false;
if ~all(isfinite([a b])),ok=false;return;end
riskW=0;ascentW=0;
if isfield(cfg,'activeRiskWeight') && isfield(cfg,'activeAscentWeight')
    riskW=cfg.activeRiskWeight; ascentW=cfg.activeAscentWeight;
else
    [riskW,ascentW]=mmra_cost_weights(cfg);
end
fusion=true;
if isfield(cfg,'costEvalMode') && ~isempty(cfg.costEvalMode)
    fusion=strcmpi(cfg.costEvalMode,'fused');
end
% When steps differ, revert to the EXACT original two independent grids.
if ~fusion || riskW<=0 || abs(cfg.edgeResolution- ...
        cfg.riskCostResolution_m)>1e-12
    ok=mmra_edge_free(a,b,env,cfg.edgeResolution);
    if ok
        objective_m=mmra_edge_objective(a,b,env,cfg);
    end
    return;
end
usedFusion=true;
length_m=norm(b-a);
n=max(1,ceil(length_m/cfg.edgeResolution));
t=linspace(0,1,n+1).';
pts=bsxfun(@plus,a,bsxfun(@times,t,b-a));
% Replicate mmra_is_free's strict inequalities on the SAME samples.
bounds=all(bsxfun(@ge,pts,env.boundsLo),2) & ...
       all(bsxfun(@le,pts,env.boundsHi),2);
h=mmra_terrain(pts,env);
ok=mmra_no_fly_segment_free(a,b,env) && ...
    all(bounds & all(isfinite(pts),2) & ...
    pts(:,3)>h+env.safetyMargin & mmra_no_fly_free(pts,env));
if ~ok,return;end
r=mmra_risk_density(pts,env,cfg.riskCostBand_m,h);
riskIntegral_m=(length_m/n)*(sum(r)-0.5*(r(1)+r(end)));
riskIntegral_m=max(0,riskIntegral_m);
ascent_m=max(0,b(3)-a(3));
objective_m=length_m+riskW*riskIntegral_m+ascentW*ascent_m;
assert(isfinite(objective_m) && objective_m>=length_m-1e-9, ...
    'Invalid fused edge objective');
end
