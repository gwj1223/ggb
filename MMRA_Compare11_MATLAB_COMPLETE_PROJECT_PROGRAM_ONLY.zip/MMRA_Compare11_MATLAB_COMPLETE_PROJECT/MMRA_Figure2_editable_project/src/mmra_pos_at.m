function [p,occupied] = mmra_pos_at(path,delay,speed,t,startPolicy,endPolicy)
%MMRA_POS_AT Piecewise-linear, constant cruise speed along polyline arc.
% If inactive, position is still returned for interval end calculations,
% but occupied=false outside the active flight interval.
[pts,cum,L]=mmra_arc(path);
finish=delay+L/speed;
if t<delay
    p=pts(1,:); occupied=strcmpi(startPolicy,'hold'); return;
end
if t>finish
    p=pts(end,:); occupied=strcmpi(endPolicy,'hold'); return;
end
occupied=true;
if L<1e-12, p=pts(end,:); return; end
s=max(0,min(L,(t-delay)*speed));
i=find(cum<=s,1,'last');
if i>=size(pts,1), p=pts(end,:); return; end
u=(s-cum(i))/(cum(i+1)-cum(i));
p=(1-u)*pts(i,:)+u*pts(i+1,:);
end
