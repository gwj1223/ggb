function p = mmra_speed_arc_position(geom,s)
%MMRA_SPEED_ARC_POSITION Interpolate a point on a precomputed 3D polyline.
% geom.points, geom.cumulative and geom.length come from mmra_arc.
assert(isfinite(s) && isscalar(s),'Progress must be a finite scalar.');
s=max(0,min(geom.length,s));
if s<=0,p=geom.points(1,:);return;end
if s>=geom.length,p=geom.points(end,:);return;end
k=find(geom.cumulative<=s,1,'last');
k=min(k,size(geom.points,1)-1);
denom=geom.cumulative(k+1)-geom.cumulative(k);
if denom<=0,p=geom.points(k,:);return;end
r=(s-geom.cumulative(k))/denom;
p=geom.points(k,:)+r*(geom.points(k+1,:)-geom.points(k,:));
end
