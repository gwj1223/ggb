function [out,usedPaths] = mmra_schedule_speed_with_spatial_fallback(paths,env,cfg,opt)
%MMRA_SCHEDULE_SPEED_WITH_SPATIAL_FALLBACK Optional experimental two-stage mode.
% First dynamically coordinate ORIGINAL polylines. If this fails, the
% existing certificate-guided geometry repair may try detours, and the new
% speed controller is rerun on those repaired paths. No geometry is ever
% changed in the source dataset. IMPORTANT: original geometry repair was
% tuned for a FIXED-SPEED departure-grid certificate, so improvement in
% variable-speed success is NOT guaranteed.
start=tic;usedPaths=paths;
first=mmra_schedule_speed_feedback(paths,opt);
out=first;
out.spatialFallbackTried=false;
out.spatialFallbackAccepted=false;
out.spatialFallbackModifiedPaths=0;
out.originalSpeedSuccess=first.success;
out.originalSpeedReason=first.reason;
if first.success,out.schedule_s=toc(start);return;end
if nargin<4 || isempty(env) || isempty(cfg)
    out.reason='spatial_fallback_requires_environment';
    out.schedule_s=toc(start);return;
end
out.spatialFallbackTried=true;
repair=mmra_certificate_guided_spatial_repair(paths,env,cfg,opt);
out.spatialFallbackAccepted=repair.acceptedRepairs>0;
out.spatialFallbackModifiedPaths=repair.repairedPathCount;
if repair.acceptedRepairs>0
    retry=mmra_schedule_speed_feedback(repair.paths,opt);
    if retry.success
        out=retry;
        out.spatialFallbackTried=true;
        out.spatialFallbackAccepted=true;
        out.spatialFallbackModifiedPaths=repair.repairedPathCount;
        out.originalSpeedSuccess=false;
        out.originalSpeedReason=first.reason;
        out.mode='speed_feedback_spatial_fallback';
        out.reason='spatial_repair_then_speed_feedback_verified';
        usedPaths=repair.paths;
    end
end
out.schedule_s=toc(start);
end
