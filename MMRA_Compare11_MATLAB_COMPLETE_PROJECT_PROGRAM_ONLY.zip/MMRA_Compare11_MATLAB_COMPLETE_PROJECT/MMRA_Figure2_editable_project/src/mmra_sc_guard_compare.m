function r=mmra_sc_guard_compare(baseline,candidate,g)
%MMRA_SC_GUARD_COMPARE Compare fixed-seed APF data against predeclared guards.
% Input tables MUST have Seed, Success, Path_m, Search_s, MinClearFine_m.
% Pair path and clearance metrics only on seeds where BOTH methods succeed.
% Compare success counts over ALL seeds; compare timings over ALL seeds.
% Uses a local deterministic quantile, without Statistics Toolbox.
if nargin<3 || isempty(g), g=mmra_sc_guard_defaults(); end
required={'Seed','Success','Path_m','Search_s','MinClearFine_m'};
assert(all(ismember(required,baseline.Properties.VariableNames)) && ...
    all(ismember(required,candidate.Properties.VariableNames)), ...
    'SC safety comparison needs seed, success, path, time and fine clearance');
B=sortrows(baseline,'Seed'); C=sortrows(candidate,'Seed');
assert(height(B)==height(C) && isequal(B.Seed,C.Seed) && ...
    numel(unique(B.Seed))==height(B),'Expected unique aligned seeds');
baseOK=logical(B.Success);candOK=logical(C.Success);
paired=baseOK & candOK;
r=struct();
r.N=height(B);r.BaseSuccess=sum(baseOK);r.CandSuccess=sum(candOK);
r.PairedSuccess=sum(paired);
r.SuccessOK=(r.CandSuccess>=r.BaseSuccess);
r.PairedCountOK=(r.PairedSuccess>=g.minPaired);
r.PathRatio=Inf;r.TimeRatio=Inf;
r.PairedMeanPathDelta_m=NaN;
r.BaseMeanClear_m=NaN;r.CandMeanClear_m=NaN;
r.BaseP10Clear_m=NaN;r.CandP10Clear_m=NaN;
r.BaseWorstClear_m=NaN;r.CandWorstClear_m=NaN;
r.MeanClearDelta_m=NaN;r.P10ClearDelta_m=NaN;
r.WorstClearDelta_m=NaN;
r.PathOK=false;r.TimeOK=false;r.MeanClearOK=false;
r.P10ClearOK=false;r.WorstClearOK=false;r.AbsoluteClearOK=false;
r.PairedDataOK=false;
validTime=all(isfinite(B.Search_s)) && all(isfinite(C.Search_s)) ...
    && all(B.Search_s>=0) && all(C.Search_s>=0) ...
    && mean(B.Search_s)>0;
if validTime
    r.TimeRatio=mean(C.Search_s)/mean(B.Search_s);
    r.TimeOK=(r.TimeRatio<=g.maxTimeRatio);
end
allFine=C.MinClearFine_m(candOK);
r.AbsoluteClearOK=all(isfinite(allFine)) && ...
    all(allFine>=g.minAbsoluteClear_m) && ~isempty(allFine);
if r.PairedSuccess>0
    bp=B.Path_m(paired); cp=C.Path_m(paired);
    bc=B.MinClearFine_m(paired); cc=C.MinClearFine_m(paired);
    r.PairedDataOK=all(isfinite(bp)) && all(isfinite(cp)) ...
        && all(bp>=0) && all(cp>=0) ...
        && all(isfinite(bc)) && all(isfinite(cc));
    if r.PairedDataOK && mean(bp)>0
        r.PathRatio=mean(cp)/mean(bp);
        r.PairedMeanPathDelta_m=mean(cp-bp);
        r.PathOK=(r.PathRatio<=g.maxPathRatio);
        r.BaseMeanClear_m=mean(bc);
        r.CandMeanClear_m=mean(cc);
        r.BaseP10Clear_m=local_percentile(bc,10);
        r.CandP10Clear_m=local_percentile(cc,10);
        r.BaseWorstClear_m=min(bc);
        r.CandWorstClear_m=min(cc);
        r.MeanClearDelta_m=r.CandMeanClear_m-r.BaseMeanClear_m;
        r.P10ClearDelta_m=r.CandP10Clear_m-r.BaseP10Clear_m;
        r.WorstClearDelta_m=r.CandWorstClear_m-r.BaseWorstClear_m;
        r.MeanClearOK=(r.MeanClearDelta_m>=-g.meanClearSlack_m);
        r.P10ClearOK=(r.P10ClearDelta_m>=-g.p10ClearSlack_m);
        r.WorstClearOK=(r.WorstClearDelta_m>=-g.worstClearSlack_m);
    end
end
checks={'SuccessOK','PairedCountOK','PairedDataOK','PathOK','TimeOK', ...
    'MeanClearOK','P10ClearOK','WorstClearOK','AbsoluteClearOK'};
failed={};
for i=1:numel(checks)
    if ~r.(checks{i}), failed{end+1}=checks{i}; end %#ok<AGROW>
end
r.Eligible=isempty(failed);
if r.Eligible, r.Reason='PASS'; else, r.Reason=strjoin(failed,'|'); end
end

function q=local_percentile(x,p)
% Linear-interpolated finite sample quantile, no toolbox dependency.
x=sort(x(:));n=numel(x);
assert(n>0 && all(isfinite(x)) && p>=0 && p<=100);
pos=1+(n-1)*p/100;
lo=floor(pos);hi=ceil(pos);w=pos-lo;
q=(1-w)*x(lo)+w*x(hi);
end
