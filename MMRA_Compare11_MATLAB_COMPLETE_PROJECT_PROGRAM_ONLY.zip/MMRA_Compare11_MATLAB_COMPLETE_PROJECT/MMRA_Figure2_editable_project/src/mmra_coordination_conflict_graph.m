function graph=mmra_coordination_conflict_graph(paths,opt)
%MMRA_COORDINATION_CONFLICT_GRAPH Geometric conflict graph for FIXED 3D routes.
% Undirected edge: the two continuous polylines approach within a selected
% threshold. Edge weight also considers their approximate zero-launch-time
% encounter offset. An edge is a scheduling HEURISTIC, not a collision
% verdict. Only mmra_verify_speed_trace certifies the executed ideal trace.
%
% graph.arcAtApproach_m(i,j) is UAV i's arc distance at its closest point
% to UAV j (so it is not necessarily equal to graph.arcAtApproach_m(j,i)).
U=numel(paths);
assert(U>=1,'At least one route is required.');
assert(isfield(opt,'speed') && isfield(opt,'dSafe'));
assert(opt.speed>0 && opt.dSafe>0);
threshold=opt.dSafe+localField(opt,'speedFeedbackGuard_m',1)+ ...
    localField(opt,'coordinationGraphExtra_m',25);
assert(isfinite(threshold) && threshold>opt.dSafe);
cap=opt.speed*ones(U,1);
if isfield(opt,'speedFeedbackSpeedCaps_mps') && ...
        ~isempty(opt.speedFeedbackSpeedCaps_mps)
    v=opt.speedFeedbackSpeedCaps_mps;
    if isscalar(v),cap(:)=v;else,cap=v(:);end
end
assert(numel(cap)==U && all(isfinite(cap)) && ...
    all(cap>0) && all(cap<=opt.speed+1e-9));
geom=cell(U,1);
lens=zeros(U,1);
for i=1:U
    [p,c,L]=mmra_arc(paths{i});
    assert(L>0,'A nonzero route length is required.');
    geom{i}=struct('p',p,'c',c);
    lens(i)=L;
end
distance=inf(U,U);
arcs=NaN(U,U);
weights=zeros(U,U);
edges=false(U,U);
headway=localField(opt,'coordinationHeadway_s',2);
assert(isscalar(headway) && isfinite(headway) && headway>0);
for i=1:U-1
    for j=i+1:U
        [d,a,b]=localPolylineClosest(geom{i},geom{j},threshold);
        distance(i,j)=d;distance(j,i)=d;
        arcs(i,j)=a;arcs(j,i)=b;
        if d<=threshold
            edges(i,j)=true;edges(j,i)=true;
            encounterOffset=abs(a/cap(i)-b/cap(j));
            severity=(threshold-d)/threshold;
            % Never use weights as a substitute for independent validation.
            w=max(1e-6,severity)* ...
                (0.25+0.75*exp(-encounterOffset/max(1,2*headway)));
            weights(i,j)=w;weights(j,i)=w;
        end
    end
end
graph=struct('distance_m',distance, ...
    'arcAtApproach_m',arcs, ...
    'edge',edges, ...
    'weight',weights, ...
    'degree',sum(edges,2), ...
    'weightedDegree',sum(weights,2), ...
    'numEdges',nnz(triu(edges,1)), ...
    'threshold_m',threshold, ...
    'pathLengths_m',lens, ...
    'speedCaps_mps',cap);
end

function [best,sAlong,tAlong]=localPolylineClosest(a,b,cutoff)
% Exact shortest distance between two piecewise linear 3D curves, apart
% from roundoff. A midpoint-ball lower bound skips obviously distant edges.
best=inf;sAlong=NaN;tAlong=NaN;
pa=a.p;pb=b.p;
for ia=1:size(pa,1)-1
    p=pa(ia,:);r=pa(ia+1,:);
    da=r-p;la=norm(da);
    ca=(p+r)/2;
    for ib=1:size(pb,1)-1
        q=pb(ib,:);z=pb(ib+1,:);
        db=z-q;lb=norm(db);
        if norm(ca-(q+z)/2)>0.5*(la+lb)+min(best,cutoff)+1e-9
            continue;
        end
        [d,x,y]=localSegmentClosest(p,r,q,z);
        if d<best
            best=d;
            sAlong=a.c(ia)+la*x;
            tAlong=b.c(ib)+lb*y;
        end
    end
end
end

function [best,xBest,yBest]=localSegmentClosest(p,r,q,z)
% Convex quadratic on [0,1]^2: optimum is interior or on a boundary.
% Check the four boundaries and the unconstrained interior stationary point.
u=r-p;v=z-q;w=p-q;
a=dot(u,u);b=dot(u,v);c=dot(v,v);
d=dot(u,w);e=dot(v,w);
xs=zeros(5,1);ys=zeros(5,1);
ys(1)=localClamp(e/max(c,eps));   % p to [q,z]
xs(2)=1;ys(2)=localClamp((b+e)/max(c,eps)); % r to [q,z]
xs(3)=localClamp(-d/max(a,eps)); % q to [p,r]
xs(4)=localClamp((b-d)/max(a,eps));ys(4)=1; % z to [p,r]
num=4;
D=a*c-b*b;
if D>1e-12*max(a*c,1)
    xx=(b*e-c*d)/D;
    yy=(a*e-b*d)/D;
    if xx>=0 && xx<=1 && yy>=0 && yy<=1
        num=5;xs(5)=xx;ys(5)=yy;
    end
end
best=inf;xBest=0;yBest=0;
for k=1:num
    dr=w+xs(k)*u-ys(k)*v;
    dd=dot(dr,dr);
    if dd<best
        best=dd;xBest=xs(k);yBest=ys(k);
    end
end
best=sqrt(max(0,best));
end

function t=localClamp(t)
t=max(0,min(1,t));
end

function x=localField(opt,key,defaultValue)
if isfield(opt,key) && ~isempty(opt.(key))
    x=double(opt.(key));
else
    x=defaultValue;
end
end
