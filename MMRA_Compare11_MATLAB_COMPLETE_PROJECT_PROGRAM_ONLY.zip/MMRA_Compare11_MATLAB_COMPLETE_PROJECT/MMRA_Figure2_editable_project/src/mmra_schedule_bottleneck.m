function out = mmra_schedule_bottleneck(paths,opt)
%MMRA_SCHEDULE_BOTTLENECK Bounded bottleneck-driven priority-repair scheduler.
% Uses EXACTLY the same fixed polygonal paths, cruise speed, delay grid,
% occupancy policies and continuous-time pair checker as mmra_schedule.
%
% 1) Evaluate the existing conflict-aware scheduler, which itself retains
%    the original length-order fallback.
% 2) Test a few severity/degree-weighted orders.
% 3) Reinsert the aircraft determining the current mission makespan at
%    selected positions in the priority list; always re-run the original
%    feasible-delay search and post-schedule collision verification.
% 4) Accept a candidate ONLY if it recovers feasibility or strictly lowers
%    makespan. Never replace a feasible schedule with an infeasible one.
%
% This is a deterministic, bounded HEURISTIC, not a global optimum. As it
% evaluates extra orders, CPU time may increase significantly. Endpoints
% remain physically occupied for startPolicy/endPolicy='hold'.
startAll=tic;
baseOpt=opt;
if isfield(baseOpt,'priorityOrder')
    baseOpt=rmfield(baseOpt,'priorityOrder');
end
maxExtra=8;
if isfield(baseOpt,'repairMaxCandidates')
    maxExtra=baseOpt.repairMaxCandidates;
end
maxRounds=2;
if isfield(baseOpt,'repairMaxRounds')
    maxRounds=baseOpt.repairMaxRounds;
end
assert(isnumeric(maxExtra) && isscalar(maxExtra) && isfinite(maxExtra) && ...
    maxExtra>=0 && maxExtra==floor(maxExtra), ...
    'repairMaxCandidates must be a nonnegative integer');
assert(isnumeric(maxRounds) && isscalar(maxRounds) && isfinite(maxRounds) && ...
    maxRounds>=0 && maxRounds==floor(maxRounds), ...
    'repairMaxRounds must be a nonnegative integer');

reference=mmra_schedule_conflict_aware(paths,baseOpt);
out=reference;
out.mode='bottleneck_repair';
out.repairAttempted=false;
out.repairCandidates=0;
out.repairAccepted=0;
out.repairPairChecks=0;
out.repairStrategy='conflict_aware_incumbent';
out.referenceCASuccess=reference.success;
out.referenceCAMakespan_s=reference.makespan;
out.referenceCASchedule_s=reference.schedule_s;
out.repairMaxCandidates=maxExtra;
out.repairMaxRounds=maxRounds;
U=numel(paths);
if U<2 || maxExtra==0 || ~isfinite(reference.preConflicts) || ...
        (reference.success && reference.preConflicts==0)
    out.schedule_s=toc(startAll);
    return;
end

lens=zeros(U,1);
for i=1:U
    [~,~,lens(i)]=mmra_arc(paths{i});
end
deg=reference.conflictDegrees;
severity=zeros(U,1);
for i=1:U-1
    for j=i+1:U
        [d,~,isConflict]=mmra_pair_minsep(paths{i},paths{j},0,0,baseOpt);
        if isConflict
            % The sum of safety-distance deficits is used for ranking
            % only; no change is made to the hard separation constraint.
            amount=max(0,baseOpt.dSafe-d);
            severity(i)=severity(i)+amount;
            severity(j)=severity(j)+amount;
        end
    end
end

% Do not re-evaluate the two orders already explored by the incumbent.
[~,lengthOrder]=sortrows([-lens,(1:U)'],[1 2]);
[~,degreeOrder]=sortrows([-deg,-lens,(1:U)'],[1 2 3]);
visited={reshape(lengthOrder,1,[]),reshape(degreeOrder,1,[])};
best=reference;
bestTag='conflict_aware_incumbent';
trials=0; accepted=0; pairChecks=0;

% Severity-based and blended priority scores are exploratory candidates.
[~,weightedOrder]=sortrows([-severity,-deg,-lens,(1:U)'],[1 2 3 4]);
blend=deg/max(1,max(deg))+lens/max(1,max(lens));
[~,blendOrder]=sortrows([-blend,-severity,(1:U)'],[1 2 3]);
initial={reshape(weightedOrder,1,[]),reshape(blendOrder,1,[])};
for k=1:numel(initial)
    if trials>=maxExtra,break;end
    tryOrder(initial{k},'graph_rank');
end

% Move each of the two latest-finishing UAVs through selected positions.
% A successful change restarts the search from the improved schedule.
for roundID=1:maxRounds
    if trials>=maxExtra,break;end
    before=best;
    if best.success
        finishes=best.delays+lens/baseOpt.speed;
        [~,ranked]=sortrows([-finishes,-best.delays,(1:U)'],[1 2 3]);
        focus=reshape(ranked(1:min(2,U)),1,[]);
    else
        focus=[];
        if isfinite(best.failedUAV) && best.failedUAV>=1 && best.failedUAV<=U
            focus=best.failedUAV;
        end
        [~,ranked]=sortrows([-deg,-lens,(1:U)'],[1 2 3]);
        ranked=reshape(ranked,1,[]);
        focus=unique([focus,ranked(1:min(2,U))],'stable');
    end
    order=reshape(best.priorityOrder,1,[]);
    for f=focus
        if trials>=maxExtra,break;end
        pos=find(order==f,1,'first');
        if isempty(pos),continue;end
        % Place bottleneck earlier, later, or halfway. One UAV is moved
        % per candidate so it is easy to interpret each revision.
        positions=unique(max(1,min(U, ...
            [1,pos-1,pos+1,U,round(pos/2),round((pos+U)/2)])),'stable');
        for target=positions
            if trials>=maxExtra,break;end
            if target==pos,continue;end
            remainder=order(order~=f);
            proposed=[remainder(1:target-1),f,remainder(target:end)];
            tryOrder(proposed,'bottleneck_reinsert');
        end
    end
    if best.success && before.success && ...
            best.makespan>=before.makespan-1e-9
        break;
    end
    if ~best.success && ~before.success,break;end
end

out=best;
out.mode='bottleneck_repair';
out.repairAttempted=trials>0;
out.repairCandidates=trials;
out.repairAccepted=accepted;
out.repairPairChecks=pairChecks;
out.repairStrategy=bestTag;
out.chosenStrategy=bestTag;
out.baselineSuccess=reference.baselineSuccess;
out.baselineMakespan_s=reference.baselineMakespan_s;
out.conflictDegrees=deg;
out.conflictGraphEdges=reference.conflictGraphEdges;
out.referenceCASuccess=reference.success;
out.referenceCAMakespan_s=reference.makespan;
out.referenceCASchedule_s=reference.schedule_s;
out.repairMaxCandidates=maxExtra;
out.repairMaxRounds=maxRounds;
% Include EVERY search, conflict graph construction, and postcheck.
out.schedule_s=toc(startAll);
if reference.success
    assert(out.success && out.makespan<=reference.makespan+1e-8, ...
        'Bottleneck scheduler violated conflict-aware fallback guarantee');
end
if out.success
    assert(out.postConflicts==0 && ...
        out.minSeparation>=baseOpt.dSafe-baseOpt.tol-1e-8, ...
        'Bottleneck scheduler failed continuous-time postcheck');
end

    function tryOrder(candidate,tag)
        if any(cellfun(@(x) isequal(x,candidate),visited))
            return;
        end
        visited{end+1}=candidate; %#ok<AGROW>
        localOpt=baseOpt;
        localOpt.priorityOrder=candidate;
        trial=mmra_schedule(paths,localOpt);
        trials=trials+1;
        pairChecks=pairChecks+trial.pairChecks;
        better=trial.success && (~best.success || ...
            trial.makespan<best.makespan-1e-9);
        if better
            best=trial;
            bestTag=tag;
            accepted=accepted+1;
        end
    end
end
