function audit = mmra_verify_dynamic_obstacles(paths,trace,opt,obstacles)
%MMRA_VERIFY_DYNAMIC_OBSTACLES Independent obstacle/trace safety audit.
% Independently reconstructs progress from the trace and analytically
% tests every UAV-obstacle pair between controller ticks. The moving
% obstacle trajectory is PIECEWISE LINEAR with held endpoints. This audit
% intentionally does NOT call the controller's obstacle safety shield or
% mmra_dynamic_obstacle_interval_minsep.
% Modeled safety is conditional on known obstacle predictions, exact
% tracking of ideal polyline speed setpoints, and the configured radius.
if nargin<4,obstacles=[];end
obstacles=mmra_dynamic_obstacles_prepare(obstacles);
U=numel(paths);M=numel(obstacles);
audit=struct('safe',false,'reason','invalid_trace', ...
    'numObstacles',M,'checkedIntervals',0,'conflictingPairs',0, ...
    'minCenterDistance_m',NaN,'minClearance_m',NaN, ...
    'firstConflictTime_s',NaN,'closestUAV',NaN,'closestObstacle',NaN);
if ~isstruct(trace) || ~isfield(trace,'time_s') || ...
        ~isfield(trace,'progress_m'),return;end
t=double(trace.time_s(:));s=double(trace.progress_m);
if isempty(t) || size(s,1)~=numel(t) || size(s,2)~=U || ...
        ~isreal(t) || ~isreal(s) || any(~isfinite(t)) || ...
        any(~isfinite(s(:))) || any(diff(t)<=0) || ...
        any(s(:)<-1e-8)
    return;
end
if M==0
    audit.safe=true;audit.reason='no_dynamic_obstacles';
    audit.minCenterDistance_m=inf;audit.minClearance_m=inf;
    return;
end
droneRadius=localNum(opt,'speedFeedbackDroneRadius_m',1);
obGuard=localNum(opt,'speedFeedbackObstacleGuard_m',2);
assert(droneRadius>=0 && obGuard>=0, ...
    'Drone radius and obstacle guard must be nonnegative.');
geom=cell(U,1);L=zeros(U,1);
for i=1:U
    if size(paths{i},2)~=3 || size(paths{i},1)<2,return;end
    [p,cum,L(i)]=mmra_arc(paths{i});
    geom{i}=struct('points',p,'cumulative',cum,'length',L(i));
end
if any(any(s>repmat(L',numel(t),1)+1e-6)) || ...
        any(any(diff(s,1,1)<-1e-8))
    return;
end
best=inf;bestCenter=inf;first=NaN;who=[NaN NaN];seen=false(U,M);checked=0;
for k=1:numel(t)-1
    for i=1:U
        g=geom{i};
        sa=s(k,i);sb=s(k+1,i);
        p0=mmra_speed_arc_position(g,sa);
        for m=1:M
            ob=obstacles(m);req=ob.radius_m+droneRadius+obGuard;
            o0=localPosition(ob,t(k));
            lowerBound=norm(p0-o0)-(sb-sa)- ...
                ob.maxSpeed_mps*(t(k+1)-t(k))-req;
            % Skip only when incapable of reducing the CURRENT global
            % minimum clearance, or creating an as-yet-unknown conflict.
            if lowerBound>=0 && lowerBound>=best-1e-12 && ...
                    lowerBound+req>=bestCenter-1e-12
                continue;
            end
            checked=checked+1;
            [d,when]=localExact(g,sa,sb,t(k),t(k+1),ob);
            margin=d-req;
            bestCenter=min(bestCenter,d);
            if margin<best
                best=margin;who=[i m];
            end
            if margin<-localTol(opt)
                seen(i,m)=true;
                if isnan(first) || when<first,first=when;end
            end
        end
    end
end
% Include the final recorded instant even when the trace has one tick.
for i=1:U
    p=mmra_speed_arc_position(geom{i},s(end,i));
    for m=1:M
        ob=obstacles(m);
        req=ob.radius_m+droneRadius+obGuard;
        d=norm(p-localPosition(ob,t(end)));
        if d-req<best,best=d-req;who=[i m];end
        bestCenter=min(bestCenter,d);
        if d-req<-localTol(opt)
            seen(i,m)=true;
            if isnan(first),first=t(end);end
        end
    end
end
audit.checkedIntervals=checked;
audit.minCenterDistance_m=bestCenter;
audit.minClearance_m=best;
audit.closestUAV=who(1);
audit.closestObstacle=who(2);
audit.conflictingPairs=nnz(seen);
audit.firstConflictTime_s=first;
audit.safe=(audit.conflictingPairs==0) && best>=-localTol(opt)-1e-9;
if audit.safe
    audit.reason='verified_dynamic_obstacle_clearance';
else
    audit.reason='dynamic_obstacle_separation_violation';
end
end

function [dMin,tMin]=localExact(g,sa,sb,t0,t1,ob)
% Separate implementation of analytical segment-segment closest approach.
alpha=[0;1];
if sb-sa>1e-12
    mid=g.cumulative(g.cumulative>sa+1e-10 & ...
        g.cumulative<sb-1e-10);
    alpha=[alpha;(mid(:)-sa)/(sb-sa)];
end
knots=ob.time_s(ob.time_s>t0+1e-10 & ob.time_s<t1-1e-10);
alpha=unique(sort([alpha;(knots(:)-t0)/(t1-t0)]));
dMin=inf;tMin=t0;
for h=1:numel(alpha)-1
    a=alpha(h);b=alpha(h+1);
    p0=mmra_speed_arc_position(g,sa+(sb-sa)*a);
    p1=mmra_speed_arc_position(g,sa+(sb-sa)*b);
    o0=localPosition(ob,t0+(t1-t0)*a);
    o1=localPosition(ob,t0+(t1-t0)*b);
    delta=(p1-p0)-(o1-o0);
    relative=p0-o0;
    denom=sum(delta.*delta);
    if denom<=1e-20,q=0;
    else,q=max(0,min(1,-dot(relative,delta)/denom));end
    d=norm(relative+q*delta);
    if d<dMin
        dMin=d;tMin=t0+(t1-t0)*(a+(b-a)*q);
    end
end
end

function p=localPosition(ob,t)
% Independent clamped, piecewise-linear interpolation (not the shield helper).
tm=ob.time_s;xyz=ob.position_m;
if t<=tm(1),p=xyz(1,:);return;end
if t>=tm(end),p=xyz(end,:);return;end
j=find(tm<=t,1,'last');j=min(j,numel(tm)-1);
f=(t-tm(j))/(tm(j+1)-tm(j));
p=xyz(j,:)+(xyz(j+1,:)-xyz(j,:))*f;
end

function v=localNum(s,k,d)
if isfield(s,k) && ~isempty(s.(k)),v=s.(k);else,v=d;end
assert(isnumeric(v) && isscalar(v) && isreal(v) && isfinite(v));
end

function t=localTol(opt)
if isfield(opt,'tol'),t=opt.tol;else,t=1e-8;end
end
