function out = mmra_certificate_guided_spatial_repair(paths,env,cfg,opt)
%MMRA_CERTIFICATE_GUIDED_SPATIAL_REPAIR Bounded spatial feedback prototype.
% DEVELOPMENT ONLY: examine pairwise departure-grid incompatibility, deform
% small path subsegments around other UAV's occupied endpoints, and rerun
% the UNCHANGED temporal schedule on verified terrain-free fixed paths.
%
% Deliberately does NOT modify endpoints, speed, start/end HOLD policy,
% departure time grid or required separation; no guaranteed recovery.
% A repaired geometry without a valid GLOBAL schedule is a diagnostic
% candidate, NEVER a successful cooperative flight plan.
clock=tic;
assert(iscell(paths) && numel(paths)>=2);
assert(strcmpi(cfg.costMode,'length_risk_climb'), ...
    'Spatial-repair experiment requires the frozen three-objective cost.');
assert(strcmpi(opt.startPolicy,'hold') && strcmpi(opt.endPolicy,'hold'), ...
    'This pilot is locked to hold/hold occupancy.');
assert(opt.speed==15 && opt.dSafe==10 && opt.delayStep==0.25 && ...
    opt.maxDelay==60,'Pilot physical constraints were changed.');
S=localSpec(opt);
U=numel(paths); original=paths; current=paths;
baseLen=zeros(U,1);baseRisk=zeros(U,1);baseAsc=zeros(U,1);
for i=1:U
    assert(mmra_path_free(paths{i},env,S.fineResolution_m), ...
        'Original path %d did not pass fine terrain validation.',i);
    [cl,~]=mmra_path_clearance(paths{i},env,S.fineResolution_m);
    assert(isfinite(cl) && cl>=S.minFineClear_m, ...
        'Original UAV %d has insufficient sampled terrain clearance.',i);
    baseLen(i)=mmra_path_length(paths{i});
    baseRisk(i)=mmra_path_risk(paths{i},env,cfg.riskCostBand_m, ...
        cfg.riskCostResolution_m);
    baseAsc(i)=mmra_path_ascent(paths{i});
end

initialCache=mmra_sched_window_cache(paths,opt);
cache=initialCache;
[initialCertified,oracleStartCalls]=localCountCertificates( ...
    paths,initialCache,opt,S.oracleMaxPairChecks);
modified=false(U,1);
acceptN=0;triedN=0;terrainN=0;oracleWitnessN=0;
rounds=0;reason='no_unresolved_pair_certificates';
repairedPairs=zeros(0,2);
for roundIdx=1:S.maxRepairRounds
    if cache.noCompatiblePairCount<=0
        reason='all_cached_pair_obstructions_cleared';break;
    end
    if toc(clock)>=S.maxRepairWall_s
        reason='repair_wall_budget_reached';break;
    end
    rounds=roundIdx;
    roundTried=0;
    [ii,jj]=find(triu(cache.forbiddenPairAll,1));
    if isempty(ii),break;end
    pairDeg=sum(cache.forbiddenPairAll,2);
    pairRank=-pairDeg(ii)-pairDeg(jj);
    [~,rankOrder]=sortrows([pairRank,double(ii),double(jj)],[1 2 3]);
    ii=ii(rankOrder);jj=jj(rankOrder);
    best=struct('score',0,'deltaJ',inf,'paths',{{}}, ...
        'focus',NaN,'other',NaN,'newNoGo',inf);
    budgetReached=false;
    for pid=1:numel(ii)
        i=ii(pid);j=jj(pid);
        % Target the geometric obstruction, not a random path segment.
        % For each orientation use other UAV's held GOAL first, then START.
        work=[i j 2; j i 2; i j 1; j i 1];
        for fi=1:size(work,1)
            focus=work(fi,1);other=work(fi,2);endpointIndex=work(fi,3);
            if endpointIndex==2
                blocker=current{other}(end,:);
            else
                blocker=current{other}(1,:);
            end
            [d,~]=mmra_point_polyline_distance(current{focus},blocker);
            if d >= opt.dSafe+0.01,continue;end
            [proposals,~]=mmra_spatial_detour_candidates( ...
                current{focus},blocker,env,opt);
            nf=min(numel(proposals),S.maxProposalsPerFocus);
            for vi=1:nf
                if roundTried>=S.maxCandidateEvaluations || ...
                        toc(clock)>=S.maxRepairWall_s
                    budgetReached=true;break;
                end
                candidate=proposals{vi};triedN=triedN+1;
                roundTried=roundTried+1;
                len=mmra_path_length(candidate);
                if len>baseLen(focus)*(1+S.maxPathInflation)+1e-8
                    continue;
                end
                if ~mmra_path_free(candidate,env,S.fineResolution_m)
                    continue;
                end
                [fineClear,~]=mmra_path_clearance(candidate,env, ...
                    S.fineResolution_m);
                if ~isfinite(fineClear) || fineClear<S.minFineClear_m
                    continue;
                end
                terrainN=terrainN+1;
                risk=mmra_path_risk(candidate,env,cfg.riskCostBand_m, ...
                    cfg.riskCostResolution_m);
                asc=mmra_path_ascent(candidate);
                oldJ=baseLen(focus)+cfg.riskCostWeight*baseRisk(focus)+ ...
                    cfg.ascentCostWeight*baseAsc(focus);
                newJ=len+cfg.riskCostWeight*risk+cfg.ascentCostWeight*asc;
                deltaJ=newJ-oldJ;
                if deltaJ>S.maxAddedObjective_m,continue;end
                % First check the offending pair: if it remains impossible,
                % this is not a certificate-targeted repair candidate.
                [v,~]=mmra_sched_pair_windows(candidate,current{other},opt);
                safe=find(~v,1,'first');
                if isempty(safe),continue;end
                K=round(opt.maxDelay/opt.delayStep);
                dt=(safe-K-1)*opt.delayStep;
                [~,~,bad]=mmra_pair_minsep(candidate,current{other}, ...
                    max(0,-dt),max(0,dt),opt);
                oracleWitnessN=oracleWitnessN+1;
                if bad,continue;end
                % A path change can create OTHER impossible pairs. Retest
                % every pair incident to the changed UAV before acceptance.
                oldIncident=sum(cache.forbiddenPairAll(focus,:));
                newIncident=0;
                for otherID=1:U
                    if otherID==focus,continue;end
                    if otherID==other
                        w=v;
                    else
                        [w,~]=mmra_sched_pair_windows( ...
                            candidate,current{otherID},opt);
                    end
                    newIncident=newIncident+double(all(w));
                end
                newNoGo=cache.noCompatiblePairCount-oldIncident+newIncident;
                gain=cache.noCompatiblePairCount-newNoGo;
                if gain<=0,continue;end
                if gain>best.score || ...
                        (gain==best.score && deltaJ<best.deltaJ-1e-8)
                    best.score=gain;best.deltaJ=deltaJ;
                    best.paths=candidate;best.focus=focus;
                    best.other=other;best.newNoGo=newNoGo;
                end
            end
            if budgetReached,break;end
        end
        if budgetReached,break;end
    end
    if best.score<=0
        if budgetReached
            reason='repair_budget_no_accepted_candidate';
        else
            reason='no_terrain_valid_pairwise_improvement';
        end
        break;
    end
    % COMMIT only a genuine reduction in all-grid cached no-go pairs.
    current{best.focus}=best.paths;
    modified(best.focus)=true;
    acceptN=acceptN+1;
    repairedPairs(end+1,:)=[best.focus,best.other]; %#ok<AGROW>
    cache=mmra_sched_window_cache(current,opt);
    assert(cache.noCompatiblePairCount<=best.newNoGo, ...
        'Cache pair count increased after a claimed positive repair.');
    assert(cache.noCompatiblePairCount < initialCache.noCompatiblePairCount, ...
        'Repair failed to reduce the initial incompatibilities.');
    reason='bounded_repair_completed';
end

% Audit only the *new* candidate routes; original routes were already
% validated. Independently recompute the remaining oracle certificates.
pathOK=true;minClear=inf;
newLen=0;newRisk=0;newAsc=0;
for i=1:U
    q=current{i};
    if norm(q(1,:)-original{i}(1,:))>1e-8 || ...
            norm(q(end,:)-original{i}(end,:))>1e-8 || ...
            ~mmra_path_free(q,env,S.fineResolution_m)
        pathOK=false;break;
    end
    [c,~]=mmra_path_clearance(q,env,S.fineResolution_m);
    minClear=min(minClear,c);
    if ~isfinite(c) || c<S.minFineClear_m
        pathOK=false;break;
    end
    newLen=newLen+mmra_path_length(q);
    newRisk=newRisk+mmra_path_risk(q,env, ...
        cfg.riskCostBand_m,cfg.riskCostResolution_m);
    newAsc=newAsc+mmra_path_ascent(q);
end
assert(pathOK,'Spatial feedback output failed independent fine validation.');
[postCertified,oraclePostCalls]=localCountCertificates( ...
    current,cache,opt,S.oracleMaxPairChecks);

% The event-window scheduler and its original continuous-time final oracle
% remain unchanged. If any EXACT pair certificate persists, a global
% launch-only schedule on the grid is mathematically impossible. Skip the
% wasted scheduling work in that case, report failure, never fake success.
schedule=struct('success',false,'makespan',NaN, ...
    'minSeparation',NaN,'postConflicts',NaN, ...
    'reason','remaining_pair_grid_certificate','schedule_s',0);
if postCertified==0
    schedule=mmra_schedule_eventwindow(current,opt);
end
if schedule.success
    assert(schedule.postConflicts==0 && ...
        schedule.minSeparation>=opt.dSafe-opt.tol-1e-8, ...
        'Repaired multi-UAV schedule failed exact temporal safety.');
end
out=struct();
out.success=logical(schedule.success);
out.reason=reason;
out.paths=current;out.scheduler=schedule;
out.originalNoGoPairs=initialCache.noCompatiblePairCount;
out.finalNoGoPairs=cache.noCompatiblePairCount;
out.originalOracleCertificates=initialCertified;
out.finalOracleCertificates=postCertified;
out.oracleCalls=oracleStartCalls+oraclePostCalls;
out.oracleSafeWitnessChecks=oracleWitnessN;
out.repairedPathCount=sum(modified);
out.repairedPathIDs=find(modified);
out.acceptedRepairs=acceptN;
out.modifiedPairs=repairedPairs;
out.candidatesTried=triedN;
out.terrainValidCandidates=terrainN;
out.repairRounds=rounds;
out.fineClearanceMin_m=minClear;
out.pathLengthDelta_m=newLen-sum(baseLen);
out.riskDelta_m=newRisk-sum(baseRisk);
out.ascentDelta_m=newAsc-sum(baseAsc);
out.repairWall_s=toc(clock);
out.makespan=NaN;out.minSeparation=NaN;
if out.success
    out.makespan=schedule.makespan;
    out.minSeparation=schedule.minSeparation;
end
end

function s=localSpec(opt)
s=struct('maxRepairRounds',3,'maxCandidateEvaluations',48, ...
    'maxProposalsPerFocus',10,'maxRepairWall_s',12, ...
    'maxPathInflation',0.25,'maxAddedObjective_m',65, ...
    'fineResolution_m',0.10,'minFineClear_m',1e-6, ...
    'oracleMaxPairChecks',inf);
names=fieldnames(s);
for k=1:numel(names)
    name=names{k}; f=['spatialRepair' upper(name(1)) name(2:end)];
    if isfield(opt,f),s.(name)=opt.(f);end
end
assert(s.maxRepairRounds>=0 && s.maxCandidateEvaluations>=0 && ...
    s.maxProposalsPerFocus>=1 && s.maxRepairWall_s>0 && ...
    s.fineResolution_m>0 && s.maxPathInflation>=0);
end

function [n,checks]=localCountCertificates(paths,cache,opt,maxPairs)
[ii,jj]=find(triu(cache.forbiddenPairAll,1));
n=0;checks=0;
for k=1:min(numel(ii),maxPairs)
    [proof,~,m]=mmra_pair_grid_certificate(paths{ii(k)}, ...
        paths{jj(k)},opt);
    checks=checks+m;
    n=n+double(proof);
end
end
