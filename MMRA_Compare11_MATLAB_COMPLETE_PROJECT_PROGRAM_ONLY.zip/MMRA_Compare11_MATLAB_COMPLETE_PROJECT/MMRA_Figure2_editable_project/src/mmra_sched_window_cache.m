function cache=mmra_sched_window_cache(paths,opt)
%MMRA_SCHED_WINDOW_CACHE Pairwise relative start-delay lookup and endpoint graph.
% Same fixed polyline, speed, delay grid and hold/inactive semantics as MMRA.
% NO safety policy is relaxed. Window entries are conservative at boundaries.
U=numel(paths);
K=round(opt.maxDelay/opt.delayStep);
cache=struct();
cache.U=U;cache.K=K;cache.delayStep=opt.delayStep;
cache.forbid=cell(U,U);
cache.forbiddenPairAll=false(U,U);
cache.forbiddenZero=false(U,U);
cache.forbiddenOffsetsTotal=0;
cache.closePiecePairsTotal=0;
cache.noCompatiblePairCount=0;
cache.endpointScore=zeros(U,1);
cache.routeNearOtherGoalN=0;
cache.routeNearOtherStartN=0;
cache.nearGoals=false(U,U);
cache.nearStarts=false(U,U);
cache.lens=zeros(U,1);
cache.flightTimes=zeros(U,1);
for i=1:U
    [~,~,L]=mmra_arc(paths{i});
    cache.lens(i)=L;
    cache.flightTimes(i)=L/opt.speed;
end
for i=1:U-1
    for j=i+1:U
        [v,d]=mmra_sched_pair_windows(paths{i},paths{j},opt);
        cache.forbid{i,j}=v;
        cache.forbid{j,i}=v(end:-1:1);
        cache.forbiddenZero(i,j)=v(K+1);
        cache.forbiddenZero(j,i)=v(K+1);
        cache.forbiddenOffsetsTotal=cache.forbiddenOffsetsTotal+nnz(v);
        cache.closePiecePairsTotal=cache.closePiecePairsTotal+d.closePiecePairs;
        if all(v)
            cache.forbiddenPairAll(i,j)=true;
            cache.forbiddenPairAll(j,i)=true;
            cache.noCompatiblePairCount=cache.noCompatiblePairCount+1;
        end
    end
end
% Endpoint occupancy is not just a priority hint: these spatial
% intersections also enter the forbidden delay windows (via held pieces).
% The directed graph is used only for search ordering and diagnostics.
for i=1:U
    for j=1:U
        if i==j,continue;end
        cache.nearGoals(i,j)=localPointPolylineDist(paths{i}, ...
            paths{j}(end,:)) < opt.dSafe-opt.tol;
        cache.nearStarts(i,j)=localPointPolylineDist(paths{i}, ...
            paths{j}(1,:)) < opt.dSafe-opt.tol;
    end
end
cache.routeNearOtherGoalN=nnz(cache.nearGoals);
cache.routeNearOtherStartN=nnz(cache.nearStarts);
% Positive score: prioritize flying BEFORE other held goals become occupied;
% and prioritize vacating a start another route will cross.
G=double(cache.nearGoals);S=double(cache.nearStarts);
cache.endpointScore=sum(G,2)-sum(G,1)' + ...
                    sum(S,1)'-sum(S,2);
cache.conflictDegree=sum(cache.forbiddenZero,2);
end

function d=localPointPolylineDist(path,q)
a=path(1:end-1,:);v=diff(path,1,1);
den=sum(v.^2,2);
w=bsxfun(@minus,reshape(q,1,3),a);
t=zeros(size(den));good=den>1e-20;
t(good)=sum(w(good,:).*v(good,:),2)./den(good);
t=max(0,min(1,t));
r=a+bsxfun(@times,t,v);
r=bsxfun(@minus,r,reshape(q,1,3));
d=sqrt(min(sum(r.^2,2)));
end
