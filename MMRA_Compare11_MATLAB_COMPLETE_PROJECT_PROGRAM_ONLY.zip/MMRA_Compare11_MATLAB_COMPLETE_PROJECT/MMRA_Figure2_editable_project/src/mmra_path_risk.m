function integral_m = mmra_path_risk(path,env,band_m,resolution_m)
%MMRA_PATH_RISK Sum of the SAME per-edge trapezoid risk integrals as RRT*.
% Do not integrate once over total arc length: each tree edge has its own
% quadrature; consistency is needed for rewiring/descendant-cost auditing.
integral_m=NaN;
if isempty(path) || size(path,2)~=3 || size(path,1)<2
    return;
end
integral_m=0;
for k=1:size(path,1)-1
    integral_m=integral_m+mmra_edge_risk( ...
        path(k,:),path(k+1,:),env,band_m,resolution_m);
end
end
