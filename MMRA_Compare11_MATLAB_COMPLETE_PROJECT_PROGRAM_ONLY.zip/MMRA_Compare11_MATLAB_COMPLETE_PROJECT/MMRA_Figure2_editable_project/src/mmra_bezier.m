function [result,wasAccepted,stats] = mmra_bezier(path,env,cfg)
%MMRA_BEZIER Shared, obstacle-checked path curve smoother.
% cfg.smoothMode='legacy_midpoint' (DEFAULT): retain MMRA historical
%   quadratic midpoint scheme and whole-path fallback for reproducibility.
% cfg.smoothMode='adaptive_safe' (opt-in): G1 corner rounding with
%   independent corner rollback, curvature radius / pitch gates, adaptive
%   trimming and chord samples. Every output chord uses the same planner
%   collision oracle; optionally cfg.curveFreeFcn(S,C,E) can supply a
%   CONSERVATIVE continuous-curve collision certificate (Urban500 does).
%
% Useful opt-in fields (all optional):
%   cfg.edgeFreeFcn(a,b)          planner-specific edge checker
%   cfg.curveFreeFcn(S,C,E)       conservative continuous Bezier checker
%   cfg.smoothMinRadius_m        minimum radius ON ACCEPTED CURVES [m]
%   cfg.smoothMaxPitch_deg       maximum |tangent pitch| ON CURVES [deg]
%   cfg.smoothTrimFraction       max fraction of adjacent edge (0,0.5)
%   cfg.smoothTerminalTrimFraction  optional > trimFraction and < 1:
%       allow larger rounding at LAST interior vertex, where no following
%       corner can overlap. Defaults to smoothTrimFraction (legacy safe).
%   cfg.smoothMaxChord_m         nominal sampling interval [m]
%   cfg.smoothMaxSagitta_m       approximate chord-deviation budget [m]
%   cfg.smoothMinAngle_deg       don't alter almost straight vertices
%
% IMPORTANT: An obstructed/too-tight corner is left as the ORIGINAL kink;
% such a path is static-collision-safe but is NOT curvature-certified as
% an entire flight path. stats.fullySmoothed reports that distinction.
result=path; wasAccepted=false;
stats=struct('mode','','inputWaypoints',size(path,1), ...
    'outputWaypoints',size(path,1),'cornersConsidered',0, ...
    'roundedCorners',0,'collisionRejected',0,'radiusRejected',0, ...
    'pitchRejected',0,'resolutionRejected',0,'minAcceptedRadius_m',Inf, ...
    'maxInputTurn_deg',0,'maxOutputTurn_deg',0,'fullySmoothed',true, ...
    'inputLength_m',pathLength(path),'outputLength_m',pathLength(path), ...
    'failedCornerIndices',zeros(0,1),'failedCornerMaxRadius_m',zeros(0,1), ...
    'failedCornerMaxTrim_m',zeros(0,1),'failedCornerReasons',{{}});
% Preserve the mathematical quadratic controls separately from its output
% sampled polyline. Downstream control should follow these continuous arcs,
% not assume sampled waypoints themselves carry a curvature guarantee.
stats.curveControls=zeros(0,9); % each row: [Sx Sy Sz Cx Cy Cz Ex Ey Ez]
stats.curveCornerIndices=zeros(0,1);
stats.curveRadii_m=zeros(0,1);
if isempty(path) || size(path,1)<3, return; end
if size(path,2)~=3 || ~all(isfinite(path(:)))
    error('mmra_bezier requires an Nx3 finite path.');
end
mode='legacy_midpoint';
if isfield(cfg,'smoothMode') && ~isempty(cfg.smoothMode)
    mode=lower(char(cfg.smoothMode));
end
stats.mode=mode;
stats.maxInputTurn_deg=maxTurn(path);
switch mode
    case {'legacy_midpoint','legacy'}
        % Keep original midpoint construction and original all-or-nothing
        % acceptance; this is the baseline of existing MMRA experiments.
        n=size(path,1); mids=(path(1:end-1,:)+path(2:end,:))/2;
        candidate=path(1,:);
        candidate(end+1,:)=mids(1,:);
        for i=2:n-1
            A=mids(i-1,:); C=path(i,:); B=mids(i,:);
            t=linspace(0,1,cfg.bezierSamples+1).'; t=t(2:end);
            curve=bsxfun(@times,(1-t).^2,A)+ ...
                bsxfun(@times,2*t.*(1-t),C)+ ...
                bsxfun(@times,t.^2,B);
            candidate=[candidate;curve]; %#ok<AGROW>
        end
        candidate(end+1,:)=path(end,:);
        if mmra_postprocess_path_free(candidate,env,cfg)
            result=candidate; wasAccepted=true;
            stats.roundedCorners=n-2;
        else
            stats.collisionRejected=n-2;
        end
        stats.cornersConsidered=n-2;
        stats.fullySmoothed=wasAccepted;
    case 'adaptive_safe'
        if ~mmra_postprocess_path_free(path,env,cfg)
            error('Adaptive smoothing input fails the planner collision oracle.');
        end
        [result,stats]=adaptiveCorners(path,env,cfg,stats);
        wasAccepted=stats.roundedCorners>0;
    otherwise
        error('Unknown cfg.smoothMode: %s',mode);
end
stats.outputWaypoints=size(result,1);
stats.maxOutputTurn_deg=maxTurn(result);
stats.outputLength_m=pathLength(result);
end

function [out,st]=adaptiveCorners(P,env,cfg,st)
trimFrac=opt(cfg,'smoothTrimFraction',0.43);
terminalFrac=opt(cfg,'smoothTerminalTrimFraction',trimFrac);
minRadius=opt(cfg,'smoothMinRadius_m',0);
maxPitch=opt(cfg,'smoothMaxPitch_deg',90);
angleThreshold=opt(cfg,'smoothMinAngle_deg',2);
maxChord=opt(cfg,'smoothMaxChord_m',2.5);
maxSagitta=opt(cfg,'smoothMaxSagitta_m',0.10);
minSamples=opt(cfg,'bezierSamples',8);
maxSamples=opt(cfg,'smoothMaxSamples',1000);
assert(isfinite(trimFrac) && trimFrac>0 && trimFrac<0.5, ...
    'smoothTrimFraction must be in (0,0.5).');
assert(isfinite(terminalFrac) && terminalFrac>=trimFrac && terminalFrac<1, ...
    'smoothTerminalTrimFraction must be in [trimFraction,1).');
assert(isfinite(minRadius) && minRadius>=0, ...
    'smoothMinRadius_m must be nonnegative.');
assert(isfinite(maxPitch) && maxPitch>0 && maxPitch<=90, ...
    'smoothMaxPitch_deg must be in (0,90].');
assert(isfinite(angleThreshold) && angleThreshold>=0 && angleThreshold<180);
assert(isfinite(maxChord) && maxChord>0 && ...
    isfinite(maxSagitta) && maxSagitta>0);
assert(isfinite(minSamples) && minSamples>=2 && ...
    isfinite(maxSamples) && maxSamples>=minSamples);

out=P(1,:);
% Each trim is less than half the adjacent segment. Therefore selected
% curves cannot overlap; gaps remain on the input's certified straight
% edges, with tangent directions matching the quadratic at each endpoint.
for i=2:size(P,1)-1
    a=P(i-1,:); c=P(i,:); b=P(i+1,:);
    vin=c-a; vout=b-c;
    L1=norm(vin); L2=norm(vout);
    if L1<1e-10 || L2<1e-10
        out=appendUnique(out,c); continue;
    end
    unitIn=vin/L1; unitOut=vout/L2;
    ang=acosd(max(-1,min(1,dot(unitIn,unitOut))));
    if ang<=angleThreshold
        out=appendUnique(out,c); continue;
    end
    st.cornersConsidered=st.cornersConsidered+1;
    maxTrim=trimFrac*min(L1,L2);
    % Terminal-corner exception: the final waypoint is a GOAL, not an
    % upcoming corner. Reserving >50% of its short final edge is needless.
    % Keep a gap behind any previous rounded corner on the incoming edge.
    % This changes neither the original waypoints nor obstacle margins.
    if i==size(P,1)-1 && terminalFrac>trimFrac
        remainingIncoming=dot(c-out(end,:),unitIn);
        if remainingIncoming>1e-8
            maxTrim=max(maxTrim,min(terminalFrac*min(L1,L2), ...
                0.97*remainingIncoming));
        end
    end
    accepted=false;
    sawRadius=false; sawPitch=false; sawCollision=false;
    sawResolution=false;
    % Prefer the broadest turn, then shrink only where obstacles force it.
    scales=[1 0.85 0.70 0.55 0.42 0.32 0.24 0.17 0.12 0.08];
    for f=scales
        d=maxTrim*f;
        S=c-d*unitIn; E=c+d*unitOut;
        radius=quadraticMinRadius(S,c,E);
        if radius<1e-9 || radius+1e-8<minRadius
            % Includes a degenerate exact 180-degree reversal/cusp.
            sawRadius=true; continue;
        end
        if quadraticMaxPitch(S,c,E)>maxPitch+1e-8
            sawPitch=true; continue;
        end
        % Ensure the actual quadratic (not just its drawn chords) avoids
        % Urban500 boxes, when the scene supplies a curve certificate.
        if isfield(cfg,'curveFreeFcn') && ~isempty(cfg.curveFreeFcn)
            if ~cfg.curveFreeFcn(S,c,E)
                sawCollision=true; continue;
            end
        end
        h=min(maxChord,sqrt(8*maxSagitta*max(radius,1e-9)));
        n=max(ceil(minSamples),ceil((2*d)/h));
        if n>maxSamples
            sawResolution=true; continue;
        end
        t=linspace(0,1,n+1).';
        curve=bsxfun(@times,(1-t).^2,S) + ...
            bsxfun(@times,2*t.*(1-t),c) + ...
            bsxfun(@times,t.^2,E);
        if ~mmra_postprocess_path_free(curve,env,cfg)
            sawCollision=true; continue;
        end
        out=appendUnique(out,S);
        out=[out;curve(2:end,:)]; %#ok<AGROW>
        st.roundedCorners=st.roundedCorners+1;
        st.minAcceptedRadius_m=min(st.minAcceptedRadius_m,radius);
        st.curveControls(end+1,:)=[S c E]; %#ok<AGROW>
        st.curveCornerIndices(end+1,1)=i; %#ok<AGROW>
        st.curveRadii_m(end+1,1)=radius; %#ok<AGROW>
        accepted=true;
        break;
    end
    if ~accepted
        % Retain the original certified corner; do NOT silently force an
        % unsafe curve just to make the plot look smoother.
        out=appendUnique(out,c);
        if sawCollision
            st.collisionRejected=st.collisionRejected+1;
            failReason='collision';
        elseif sawRadius
            st.radiusRejected=st.radiusRejected+1;
            failReason='radius';
        elseif sawPitch
            st.pitchRejected=st.pitchRejected+1;
            failReason='pitch';
        elseif sawResolution
            st.resolutionRejected=st.resolutionRejected+1;
            failReason='resolution';
        else
            failReason='unknown';
        end
        st.failedCornerIndices(end+1,1)=i; %#ok<AGROW>
        st.failedCornerMaxTrim_m(end+1,1)=maxTrim; %#ok<AGROW>
        st.failedCornerMaxRadius_m(end+1,1)=quadraticMinRadius( ...
            c-maxTrim*unitIn,c,c+maxTrim*unitOut); %#ok<AGROW>
        st.failedCornerReasons{end+1,1}=failReason; %#ok<AGROW>
    end
end
out=appendUnique(out,P(end,:));
if ~mmra_postprocess_path_free(out,env,cfg)
    warning('Adaptive result failed final recheck. Keeping original path.');
    out=P;
    st.roundedCorners=0;
    st.minAcceptedRadius_m=Inf;
    st.curveControls=zeros(0,9);
    st.curveCornerIndices=zeros(0,1);
    st.curveRadii_m=zeros(0,1);
    st.failedCornerIndices=zeros(0,1);
    st.failedCornerMaxRadius_m=zeros(0,1);
    st.failedCornerMaxTrim_m=zeros(0,1);
    st.failedCornerReasons={};
end
st.fullySmoothed=(st.roundedCorners==st.cornersConsidered);
end

function out=appendUnique(out,p)
if isempty(out) || norm(out(end,:)-p)>1e-9
    out(end+1,:)=p;
end
end

function r=quadraticMinRadius(A,C,B)
% Quadratic Bezier: derivative 2*(u+t*(v-u)), second derivative 2*(v-u).
% ||B' x B''|| is constant; max curvature occurs at min ||B'||.
u=C-A; v=B-C; w=v-u;
den=dot(w,w);
if den<1e-20
    r=Inf; return;
end
t=max(0,min(1,-dot(u,w)/den));
speed=norm(u+t*w);
crossMag=norm(cross(u,w));
if speed<1e-10*max(norm(u),norm(v))
    % A reversal with a zero-speed tangent is a cusp, NOT an infinite
    % feasible turning radius even when its cross product vanishes.
    r=0; return;
end
if crossMag<1e-14
    r=Inf;
else
    r=2*speed^3/crossMag;
end
end

function p=quadraticMaxPitch(A,C,B)
% EXACT extremum of absolute geometric pitch for an affine tangent v(t).
% tan^2(pitch) = (uz+t*wz)^2 / (a+2*b*t+c*t^2).
% The only interior candidates are the root of its linear derivative and
% any zero-horizontal-velocity point, plus both endpoints. This is a
% geometric pitch check, NOT an acceleration or thrust feasibility test.
u=C-A; w=B-C-u;
a=dot(u(1:2),u(1:2));
b=dot(u(1:2),w(1:2));
c=dot(w(1:2),w(1:2));
z=u(3); wz=w(3);
t=[0;1];
den=wz*b-z*c;
if abs(den)>1e-15
    crit=(z*b-wz*a)/den;
    if crit>0 && crit<1, t(end+1,1)=crit; end
end
if c>1e-15
    crit=-b/c;
    if crit>0 && crit<1, t(end+1,1)=crit; end
end
vel=bsxfun(@plus,u,bsxfun(@times,t,w));
angles=atan2d(abs(vel(:,3)),sqrt(sum(vel(:,1:2).^2,2)));
p=max(angles);
end

function a=maxTurn(P)
a=0;
if isempty(P) || size(P,1)<3, return; end
D=diff(P,1,1);
for i=1:size(D,1)-1
    l1=norm(D(i,:)); l2=norm(D(i+1,:));
    if l1>1e-12 && l2>1e-12
        a=max(a,acosd(max(-1,min(1,dot(D(i,:),D(i+1,:))/(l1*l2)))));
    end
end
end

function d=pathLength(P)
d=0;
if isempty(P) || size(P,1)<2, return; end
d=sum(sqrt(sum(diff(P,1,1).^2,2)));
end

function val=opt(cfg,name,defaultVal)
val=defaultVal;
if isfield(cfg,name) && ~isempty(cfg.(name))
    val=cfg.(name);
end
end
