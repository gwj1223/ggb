function L = mmra_path_length(path)
%MMRA_PATH_LENGTH Euclidean polyline arc length.
if isempty(path) || size(path,1)<2, L=NaN; return; end
L = sum(sqrt(sum(diff(path,1,1).^2,2)));
end
