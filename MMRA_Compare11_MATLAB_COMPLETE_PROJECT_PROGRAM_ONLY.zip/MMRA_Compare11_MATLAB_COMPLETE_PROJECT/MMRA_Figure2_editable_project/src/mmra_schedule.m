function out = mmra_schedule(paths,opt)
%MMRA_SCHEDULE Priority-based bounded start delay with exact polyline checks.
% No synthetic 'success' on timeout, and no ignoring start/goal occupancy.
% A 'hold' terminal policy with a shared destination can be infeasible.
U=numel(paths);
out=struct('success',false,'reason','','delays',NaN(U,1), ...
    'preConflicts',NaN,'postConflicts',NaN,'minSeparation',NaN, ...
    'makespan',NaN,'schedule_s',0,'pairChecks',0,'failedUAV',NaN, ...
    'priorityOrder',[],'dSafe',opt.dSafe);
assert(opt.speed>0 && opt.dSafe>0 && opt.delayStep>0 && opt.maxDelay>=0);
assert(ismember(lower(opt.startPolicy),{'hold','inactive'}));
assert(ismember(lower(opt.endPolicy),{'hold','inactive'}));
if U<1, out.reason='no_paths'; return; end
lens=zeros(U,1);
for i=1:U
    if isempty(paths{i}) || size(paths{i},2)~=3 || size(paths{i},1)<2
        out.reason='missing_path'; out.failedUAV=i; return;
    end
    [~,~,lens(i)]=mmra_arc(paths{i});
    if lens(i)<=1e-10
        out.reason='zero_length_path'; out.failedUAV=i; return;
    end
end
out.preConflicts=0;
for i=1:U-1
    for j=i+1:U
        [~,~,conflict]=mmra_pair_minsep(paths{i},paths{j},0,0,opt);
        out.preConflicts=out.preConflicts+double(conflict);
    end
end
% Explicit priority override for a controlled A/B comparison.  With no
% override, retain the v1.0 length-descending behavior exactly.
if isfield(opt,'priorityOrder') && ~isempty(opt.priorityOrder)
    order=reshape(opt.priorityOrder,1,[]);
    assert(isnumeric(order) && isequal(sort(order),1:U), ...
        'priorityOrder must be a permutation of UAV indices 1:U');
else
    [~,order]=sort(lens,'descend');
end
out.priorityOrder=order;
delays=zeros(U,1); placed=[];
stepCount=floor(opt.maxDelay/opt.delayStep+1e-10);
tStart=tic;
for r=1:U
    i=order(r); success=false;
    for step=0:stepCount
        candidate=step*opt.delayStep;
        valid=true;
        for j=placed
            out.pairChecks=out.pairChecks+1;
            [~,~,conflict]=mmra_pair_minsep(paths{i},paths{j},candidate,delays(j),opt);
            if conflict
                valid=false; break;
            end
        end
        if valid, delays(i)=candidate; success=true; break; end
    end
    if ~success
        out.reason='delay_bound_exceeded_or_infeasible';
        out.failedUAV=i; out.schedule_s=toc(tStart);
        return; % no postConflicts=0, no misleading successful result
    end
    placed(end+1)=i; %#ok<AGROW>
end
out.schedule_s=toc(tStart);
out.delays=delays;
out.postConflicts=0; out.minSeparation=inf;
for i=1:U-1
    for j=i+1:U
        [d,~,conflict]=mmra_pair_minsep(paths{i},paths{j},delays(i),delays(j),opt);
        out.postConflicts=out.postConflicts+double(conflict);
        out.minSeparation=min(out.minSeparation,d);
    end
end
out.makespan=max(delays+lens/opt.speed);
out.success=out.postConflicts==0;
if out.success, out.reason='scheduled'; else, out.reason='postcheck_conflict'; end
end
