function [qOut,tag,diag] = mmra_guided_sample(qRand,goal,env,cfg,guided)
%MMRA_GUIDED_SAMPLE APF-normalized sample correction; diagnostic is OPTIONAL.
% Diagnostic mode does not call rand and does not change sample decisions.
% Do not use timing measurements with cfg.collectApfDiagnostics=true.
if nargin<5, guided=true; end
qOut=reshape(qRand,1,3); goal=reshape(goal,1,3);
tag='plain';
diag=struct('valid',false,'active',false,'nearSafety',false, ...
    'belowSafety',false,'repulsionDominant',false,'clipped',false, ...
    'ratio',NaN,'angleToAttractionDeg',NaN, ...
    'angleFromLegacyDeg',NaN,'clearance',NaN);
if ~guided, return; end
if cfg.uniformMix>0 && rand < cfg.uniformMix
    tag='uniform_mix'; return;
end
wantDiag = nargout>=3 && isfield(cfg,'collectApfDiagnostics') ...
    && cfg.collectApfDiagnostics;
if wantDiag
    [~,g,info] = mmra_apf_field(qOut,goal,env,cfg);
    diag.valid=true;
    diag.active=info.repulsiveGradientNorm>1e-12;
    diag.clearance=info.clearanceToSafety;
    diag.nearSafety=diag.clearance<=cfg.scSafeBand;
    diag.belowSafety=diag.clearance<=0;
    diag.ratio=info.repulsiveGradientNorm / ...
        max(info.attractiveGradientNorm,1e-12);
    diag.repulsionDominant=info.repulsiveGradientNorm>info.attractiveGradientNorm;
    gAtt=cfg.kAtt*(qOut-goal);
    diag.angleToAttractionDeg=local_angle(g,gAtt);
    % Compare both potential fields at the SAME sampled position. This is a
    % diagnostic difference, not a claim of novelty or trajectory safety.
    legacyCfg=cfg; legacyCfg.apfMode='legacy';
    [~,gLegacy]=mmra_apf_field(qOut,goal,env,legacyCfg);
    diag.angleFromLegacyDeg=local_angle(g,gLegacy);
else
    [~,g] = mmra_apf_field(qOut,goal,env,cfg);
end
ng=norm(g);
if all(isfinite(g)) && ng>cfg.gradientEps
    raw=qOut-cfg.lambdaG*cfg.step*g/ng;
    qOut=min(max(raw,env.boundsLo),env.boundsHi);
    if wantDiag, diag.clipped=any(abs(qOut-raw)>1e-12); end
    tag='guided';
else
    tag='zero_gradient_fallback';
end
end

function angle=local_angle(a,b)
if norm(a)<=1e-12 || norm(b)<=1e-12
    angle=NaN;
else
    c=dot(a,b)/(norm(a)*norm(b));
    angle=acosd(min(1,max(-1,c)));
end
end
