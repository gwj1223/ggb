function [path,st,meta] = mmra_guarded_select(basePath,baseSt,scPath,scSt,env,cfg)
%MMRA_GUARDED_SELECT Deterministic, path-level safety and quality fallback.
% All decisions use final paths (after pruning/smoothing), original env,
% and one common fine-resolution check, not the coarse planner metric.
% 1) A route is usable only if it passes dense sampled collision checking.
% 2) With a usable legacy path, SC can win only if no longer and its
%    minimum sampled clearance >= legacy clearance - guardMaxClearLoss_m.
% 3) Otherwise use the usable baseline; no checked route -> FAILURE.
% These are deterministic output invariants, NOT statistical improvements,
% continuous collision certification, or guarantees about compute time.
required={'guardFineResolution','guardAbsoluteClear_m', ...
          'guardMaxClearLoss_m','guardPathTolerance_m'};
for i=1:numel(required)
    assert(isfield(cfg,required{i}), 'Missing cfg.%s',required{i});
end
assert(isfinite(cfg.guardFineResolution) && cfg.guardFineResolution>0);
assert(isfinite(cfg.guardAbsoluteClear_m) && cfg.guardAbsoluteClear_m>=0);
assert(isfinite(cfg.guardMaxClearLoss_m) && cfg.guardMaxClearLoss_m>=0);
assert(isfinite(cfg.guardPathTolerance_m) && cfg.guardPathTolerance_m>=0);

[bGood,bClear,bLength] = local_check(basePath,baseSt,env,cfg);
[sGood,sClear,sLength] = local_check(scPath,scSt,env,cfg);
meta=struct('LegacyFineValid',bGood,'SCFineValid',sGood, ...
    'LegacyFineMinClear_m',bClear,'SCFineMinClear_m',sClear, ...
    'LegacyPath_m',bLength,'SCPath_m',sLength, ...
    'ChosenMode','none','Decision','no_fine_valid_candidate', ...
    'ChosenFineMinClear_m',NaN,'SelectionFineResolution_m', ...
    cfg.guardFineResolution);

if bGood
    if sGood && sLength <= bLength+cfg.guardPathTolerance_m && ...
            sClear >= bClear-cfg.guardMaxClearLoss_m
        % If path lengths tie to numerical precision, prefer baseline.
        if sLength < bLength-cfg.guardPathTolerance_m
            path=scPath;st=scSt;
            meta.ChosenMode='sc_apf';meta.Decision='sc_shorter_and_safe';
            meta.ChosenFineMinClear_m=sClear;
        else
            path=basePath;st=baseSt;
            meta.ChosenMode='legacy';meta.Decision='baseline_not_longer';
            meta.ChosenFineMinClear_m=bClear;
        end
    else
        path=basePath;st=baseSt;
        meta.ChosenMode='legacy';meta.ChosenFineMinClear_m=bClear;
        if ~sGood
            meta.Decision='sc_failed_or_not_fine_valid';
        elseif sLength>bLength+cfg.guardPathTolerance_m
            meta.Decision='sc_longer_than_baseline';
        else
            meta.Decision='sc_clearance_loss_exceeds_guard';
        end
    end
elseif sGood
    path=scPath;st=scSt;
    meta.ChosenMode='sc_apf';meta.Decision='baseline_not_fine_valid';
    meta.ChosenFineMinClear_m=sClear;
else
    path=zeros(0,3);st=baseSt;
    st.success=false;st.reason='no_fine_valid_candidate';
    st.pathLength=NaN;
end
end

function [valid,minClear,pathLength] = local_check(path,st,env,cfg)
valid=false; minClear=NaN; pathLength=NaN;
if isempty(path) || size(path,2)~=3 || size(path,1)<2 || ...
        ~isfield(st,'success') || ~logical(st.success) || ...
        ~all(isfinite(path(:)))
    return;
end
if ~mmra_path_free(path,env,cfg.guardFineResolution), return; end
[minClear,~]=mmra_path_clearance(path,env,cfg.guardFineResolution);
pathLength=mmra_path_length(path);
valid=isfinite(minClear) && minClear>=cfg.guardAbsoluteClear_m && ...
    isfinite(pathLength) && pathLength>=0;
end
