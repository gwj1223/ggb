function [points,cumulative,L] = mmra_arc(path)
%MMRA_ARC Remove zero-length edges; construct exact polyline arc length.
assert(size(path,2)==3 && size(path,1)>=2,'Path must be N-by-3, N>=2');
assert(all(isfinite(path(:))),'Nonfinite path coordinates');
d=vecnorm(diff(path,1,1),2,2);
keep=[true;d>1e-10]; points=path(keep,:);
if size(points,1)<2
    points=[path(1,:);path(end,:)];
end
cumulative=[0;cumsum(vecnorm(diff(points,1,1),2,2))];
L=cumulative(end);
end
