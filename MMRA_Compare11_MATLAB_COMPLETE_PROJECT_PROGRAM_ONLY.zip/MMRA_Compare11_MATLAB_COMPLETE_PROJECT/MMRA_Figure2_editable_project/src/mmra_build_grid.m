function map = mmra_build_grid(env,res)
%MMRA_BUILD_GRID Optional grid-map adapter using the SAME terrain oracle.
% Grid baseline occupancy depends on resolution, but continuous collision
% validation must still use mmra_edge_free/MMRA_PATH_FREE on returned paths.
assert(res>0);
% Prevent accidental multi-gigabyte voxel allocations in new 5 km scenes.
% For wide-area 3D terrain use mmra_terrain with sampled polyline checks.
dimensions=floor((env.boundsHi-env.boundsLo)/res)+1;
if prod(double(dimensions))>3e7
    error('MMRA:GridTooLarge', ...
        ['3D voxel grid requires %g cells; use mmra_terrain and ', ...
         'mmra_edge_free instead of a full 3D grid.'], ...
        prod(double(dimensions)));
end
map.bounds=[env.boundsLo(1) env.boundsHi(1) ...
            env.boundsLo(2) env.boundsHi(2) env.boundsLo(3) env.boundsHi(3)];
map.origin=env.boundsLo;
map.res=res;
[X,Y,Z]=ndgrid(env.boundsLo(1):res:env.boundsHi(1), ...
                env.boundsLo(2):res:env.boundsHi(2), ...
                env.boundsLo(3):res:env.boundsHi(3));
h=mmra_terrain([X(:),Y(:)],env);
blocked=~mmra_no_fly_free([X(:),Y(:),Z(:)],env);
map.occ=Z<=reshape(h,size(Z))+env.safetyMargin | ...
    reshape(blocked,size(Z));
end
