function [starts,goals,meta]=mmra_5km_mission(env,U,seed,layout)
%MMRA_5KM_MISSION Synthetic, geometry-controlled missions in 5x5x2 km.
% 'distributed' deliberately reduces the all-to-center bottleneck.
% 'cross_center' reproduces the oppositely directed ring stress pattern.
% All xyz coordinates are physical METRES. The 2 km dimension is the
% available ceiling, not a requirement for each mission to reach 2 km.
if nargin<4 || isempty(layout),layout='distributed';end
assert(isscalar(U) && U>=2 && U<=40 && U==floor(U), ...
    'Mission supports 2..40 UAVs.');
assert(isequal(env.boundsLo,[0 0 0]) && ...
       isequal(env.boundsHi,[5000 5000 2000]), ...
       'Call mmra_defaults(''paper_gmm_5km'') first.');
prev=rng;
restore=onCleanup(@()rng(prev)); %#ok<NASGU>
rng(seed,'twister');
phase=0.15+2*pi*rand;
angle=phase+2*pi*(0:U-1)'/U;
startR=1930;
goalR=1370;
switch lower(char(layout))
    case 'distributed'
        offset=0.92+0.08*rand;
    case 'cross_center'
        offset=pi+0.12+0.08*rand;
    otherwise
        error('Unknown mission layout: %s',layout);
end
ctr=[2500 2500];
startXY=[ctr(1)+startR*cos(angle),ctr(2)+startR*sin(angle)];
goalXY=[ctr(1)+goalR*cos(angle+offset), ...
        ctr(2)+goalR*sin(angle+offset)];
% Four nominal cruise-height layers add 3D variety; actual endpoint
% altitudes always retain 50 m mandatory synthetic terrain clearance.
layer=(0:U-1)';
nominal=750+75*mod(layer,4);
startH=mmra_terrain(startXY,env);
goalH=mmra_terrain(goalXY,env);
startZ=max(startH+env.safetyMargin+150,nominal);
goalZ=max(goalH+env.safetyMargin+150,nominal);
starts=[startXY,startZ];goals=[goalXY,goalZ];
assert(all(all(isfinite([starts;goals]))));
assert(all(all(bsxfun(@ge,[starts;goals],env.boundsLo))) && ...
       all(all(bsxfun(@le,[starts;goals],env.boundsHi))), ...
       'Generated endpoint is outside 5 km airspace ceiling.');
assert(all(mmra_is_free(starts,env)) && ...
       all(mmra_is_free(goals,env)), ...
       'One or more mission endpoints violate terrain clearance.');
% Even with HOLD/HOLD, all endpoints must have safe mutual separation.
dSafe=10;
for i=1:U-1
    for j=i+1:U
        assert(norm(starts(i,:)-starts(j,:))>=dSafe && ...
               norm(goals(i,:)-goals(j,:))>=dSafe, ...
               'Generated held endpoints violate aircraft separation.');
    end
end
meta=struct('layout',char(layout),'seed',seed,'numUAV',U, ...
    'domain_m',[5000 5000 2000],'startRadius_m',startR, ...
    'goalRadius_m',goalR,'goalAngleOffset_rad',offset, ...
    'minSafety_m',dSafe, ...
    'note','Synthetic ring mission, not measured real-world coordinates');
end
