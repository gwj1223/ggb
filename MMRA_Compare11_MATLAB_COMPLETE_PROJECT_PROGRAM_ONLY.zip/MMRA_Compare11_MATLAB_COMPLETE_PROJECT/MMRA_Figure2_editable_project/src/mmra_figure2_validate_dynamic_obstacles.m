function report=mmra_figure2_validate_dynamic_obstacles(obstacles,env,checkMission)
%MMRA_FIGURE2_VALIDATE_DYNAMIC_OBSTACLES Validate 3 moving-sphere tracks.
% Checks body radius, time range, airspace bounds, sampled terrain-clearance
% and the physical sphere against buffered STATIC NFZ/boxes. Static-edge
% check analytically inflates exclusion volumes by sphere radius.
% This is not a real-world sensor, uncertainty or flight-dynamics proof.
if nargin<3,checkMission=true;end
obstacles=mmra_dynamic_obstacles_prepare(obstacles);
assert(strcmp(env.profile,'mountain_cluster_figure2_custom_5km') ...
    && isequal(env.boundsHi,[5000 5000 2000]), ...
    'Dynamic obstacles require the 5 x 5 x 2 km custom Figure 2 env.');
assert(numel(obstacles)==3,'Editor expects exactly 3 moving spheres.');
assert(isfield(env,'noFlyCylinders') && isfield(env,'staticBoxes'), ...
    'Load saved Figure 2 static obstacles BEFORE dynamic validation.');
if checkMission
    [starts,goals]=mmra_5km_mission(env,20,24001,'cross_center');
    endpoints=[starts;goals];
else
    endpoints=zeros(0,3);
end
for k=1:numel(obstacles)
    ob=obstacles(k);
    assert(numel(ob.time_s)==2 && size(ob.position_m,1)==2, ...
        'Editor supports one straight movement with 2 time/position knots.');
    assert(ob.time_s(1)>=0 && ob.time_s(2)<=420 && ...
        ob.time_s(2)-ob.time_s(1)>=1, ...
        'Movement times must lie in [0,420] seconds with at least 1 s duration.');
    r=ob.radius_m;
    assert(r>=10 && r<=200,'Sphere radius must lie in [10,200] metres.');
    p=ob.position_m;
    assert(all(all(bsxfun(@ge,p,env.boundsLo+r))) && ...
           all(all(bsxfun(@le,p,env.boundsHi-r))), ...
        'The complete sphere must remain inside the 5 km map boundaries.');
    % A straight segment between points in the rectangular domain is
    % also in the domain. Sample terrain, including the sphere BOTTOM.
    N=max(2,ceil(norm(diff(p,1,1))/8)+1);
    q=bsxfun(@plus,p(1,:),linspace(0,1,N)'*(p(2,:)-p(1,:)));
    h=mmra_terrain(q(:,1:2),env);
    assert(all(q(:,3)-r>h(:)+env.safetyMargin), ...
        'Moving sphere intersects terrain or the 50 m terrain guard.');
    % Conservative analytic check: inflate static volumes by the sphere
    % radius, then check its continuous center segment (not only ticks).
    enlarged=env;
    if ~isempty(env.noFlyCylinders)
        enlarged.noFlyCylinders(:,3)=env.noFlyCylinders(:,3)+r;
        enlarged.noFlyCylinders(:,4)=env.noFlyCylinders(:,4)-r;
        enlarged.noFlyCylinders(:,5)=env.noFlyCylinders(:,5)+r;
    end
    if ~isempty(env.staticBoxes)
        b=env.staticBoxes;
        b(:,[1 3 5])=b(:,[1 3 5])-r;
        b(:,[2 4 6])=b(:,[2 4 6])+r;
        enlarged.staticBoxes=b;
    end
    assert(mmra_no_fly_segment_free(p(1,:),p(2,:),enlarged), ...
        'Moving sphere crosses a buffered static NFZ or building.');
    if ~isempty(endpoints)
        % HOLD/HOLD means moving obstacles occupy both end positions even
        % when not travelling. Do not allow a sphere to sit on any of the
        % reference mission starting or arrival coordinates.
        delta=zeros(size(endpoints,1),1);
        d=p(2,:)-p(1,:);denom=dot(d,d);
        if denom>1e-12
            frac=max(0,min(1,(endpoints-p(1,:))*d'/denom));
        else
            frac=zeros(size(endpoints,1),1);
        end
        closest=bsxfun(@plus,p(1,:),frac*d);
        delta=sqrt(sum((endpoints-closest).^2,2));
        assert(all(delta>r+3+1e-7), ...
            'Moving obstacle overlaps a held mission start or goal.');
    end
end
report=struct('count',numel(obstacles),'missionEndpointsChecked', ...
    logical(checkMission),'model','piecewise_linear_hold_hold');
end
