function g=mmra_sc_guard_defaults()
%MMRA_SC_GUARD_DEFAULTS Predeclared training and final-test safety rules.
% All clearance values are METERS ABOVE the mandatory terrain safety margin.
% A tolerance is a permitted reduction in spare clearance, not evidence of
% improved safety. Do not change guards after inspecting final holdout data.
g=struct();
g.maxPathRatio=1.02;       % paired successful mean path <= 102% of legacy
g.maxTimeRatio=1.35;       % mean RRT* timing <= 135% of legacy
g.meanClearSlack_m=0.25;   % paired mean per-path minimum clearance
g.p10ClearSlack_m=0.25;    % paired 10th percentile minimum clearance
g.worstClearSlack_m=0.25;  % paired worst-case minimum clearance
g.minAbsoluteClear_m=1e-6; % sampled clearance must be strictly positive
g.minPaired=10;            % require enough paired successful cases
end
