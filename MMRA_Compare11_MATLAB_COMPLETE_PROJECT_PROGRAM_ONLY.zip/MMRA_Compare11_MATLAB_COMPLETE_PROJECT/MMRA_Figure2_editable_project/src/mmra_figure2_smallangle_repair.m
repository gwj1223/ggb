function [Pout,stOut,report] = mmra_figure2_smallangle_repair(Q,Pold,stOld,env,cfg)
%MMRA_FIGURE2_SMALLANGLE_REPAIR Fail-closed, validator-triggered G1 recovery.
% The adaptive smoother normally ignores angles <= 2 degrees; the strict
% continuous G1 verifier accepts at most 0.001 degree of numerical error.
% In Figure2 repair-ON mode only, retry smoothing with a smaller threshold
% if the independent verifier discovers a missed nonzero junction.
% No raw search is rerun and no endpoint/obstacle/radius limits are relaxed.
Pout=Pold;stOut=stOld;
report=struct('attempted',false,'succeeded',false, ...
    'reason','NOT_REQUIRED','numCandidatesTested',0, ...
    'cornersRelocated',zeros(0,1),'waypointShifts_m',zeros(0,3), ...
    'certifiedRadius_m',NaN,'originalFailedCorners',zeros(0,1), ...
    'originalWorstJunctionAngle_deg',NaN, ...
    'newPathLength_m',NaN,'originalPathLength_m',pathLen(Pold));
if ~isnumeric(Q) || size(Q,2)~=3 || size(Q,1)<3 || ...
        ~isstruct(stOld) || ~isfield(stOld,'fullySmoothed') || ...
        ~stOld.fullySmoothed || ...
        ~isfield(stOld,'curveControls') || ...
        ~isfield(stOld,'cornersConsidered') || ...
        stOld.cornersConsidered>=size(Q,1)-2 || ...
        isempty(Pold)
    return;
end
if exist('mmra_compare11_turnradius_validate','file')~=2
    report.reason='INDEPENDENT_VALIDATOR_MISSING';return;
end
rReq=option(cfg,'smoothMinRadius_m',10);
pReq=option(cfg,'smoothMaxPitch_deg',75);
certOld=mmra_compare11_turnradius_validate( ...
    Pold,stOld.curveControls,rReq,pReq);
if certOld.certified,return;end
if ~strcmp(certOld.status,'SHARP_JUNCTION')
    report.reason='NON_G1_FAILURE';return;
end
threshold=option(cfg,'smoothMinAngle_deg',2);
report.originalWorstJunctionAngle_deg=certOld.maxJunctionAngle_deg;
% Restrict this retry to the disagreement between the old smoother skip
% threshold and the independent continuous G1 tolerance.
if ~isfinite(certOld.maxJunctionAngle_deg) || ...
        certOld.maxJunctionAngle_deg<=1e-3 || ...
        certOld.maxJunctionAngle_deg>threshold+1e-6
    report.reason='NOT_A_SKIPPED_SMALL_ANGLE';return;
end
report.attempted=true;
report.reason='NO_CERTIFIED_SMALL_ANGLE_RESMMOOTH';
report.numCandidatesTested=1;
cfgTry=cfg;
% Deliberately BELOW the validator's 0.001 degree numerical G1 tolerance;
% never alter the independent validator itself.
cfgTry.smoothMinAngle_deg=5e-4;
try
    [Ptry,~,stTry]=mmra_bezier(Q,env,cfgTry);
catch
    report.reason='RESMMOOTH_ERROR';return;
end
if ~isfield(stTry,'fullySmoothed') || ~stTry.fullySmoothed
    report.reason='RESMMOOTH_UNFINISHED';return;
end
if ~isfinite(pathLen(Ptry)) || ...
        pathLen(Ptry)>pathLen(Pold)+option(cfg,'figure2RepairMaxAddedLength_m',55)
    report.reason='RESMMOOTH_LENGTH_BUDGET';return;
end
if norm(Ptry(1,:)-Q(1,:))>1e-6 || ...
        norm(Ptry(end,:)-Q(end,:))>1e-6
    report.reason='RESMMOOTH_ENDPOINT_CHANGED';return;
end
certNew=mmra_compare11_turnradius_validate( ...
    Ptry,stTry.curveControls,rReq,pReq);
if ~certNew.certified
    report.reason=['RESMMOOTH_' certNew.status];return;
end
cfgFine=cfg;
if isfield(cfgFine,'edgeResolution') && ...
        isfinite(cfgFine.edgeResolution) && cfgFine.edgeResolution>0
    cfgFine.edgeResolution=min(1,cfgFine.edgeResolution);
else
    cfgFine.edgeResolution=1;
end
if ~mmra_postprocess_path_free(Ptry,env,cfgFine)
    report.reason='RESMMOOTH_FINE_COLLISION';return;
end
Pout=Ptry;stOut=stTry;
report.succeeded=true;
report.reason='VERIFIED_SMALL_ANGLE_G1_RESMMOOTH';
report.certifiedRadius_m=certNew.minPathTurnRadius_m;
report.newPathLength_m=pathLen(Ptry);
end

function v=option(cfg,key,defaultValue)
v=defaultValue;
if isfield(cfg,key) && ~isempty(cfg.(key)),v=cfg.(key);end
end

function len=pathLen(P)
len=NaN;
if isnumeric(P) && isreal(P) && size(P,2)==3 && ...
        size(P,1)>=2 && all(isfinite(P(:)))
    len=sum(sqrt(sum(diff(P,1,1).^2,2)));
end
end
