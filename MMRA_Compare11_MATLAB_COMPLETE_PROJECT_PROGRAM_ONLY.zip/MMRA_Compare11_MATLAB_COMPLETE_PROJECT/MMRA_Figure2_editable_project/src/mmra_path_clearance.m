function [minClear,meanClear] = mmra_path_clearance(path,env,resolution)
%MMRA_PATH_CLEARANCE Sampled path margin above mandatory terrain clearance.
% This matches the finite-resolution geometric checks, and is NOT an
% inter-sample or continuous-time separation guarantee.
if nargin<3 || isempty(resolution), resolution=1.5; end
assert(resolution>0 && isfinite(resolution));
minClear=NaN; meanClear=NaN;
if isempty(path) || size(path,2)~=3 || size(path,1)<2, return; end
samples=zeros(0,3);
for k=1:size(path,1)-1
    a=path(k,:);b=path(k+1,:);
    n=max(1,ceil(norm(b-a)/resolution));
    t=linspace(0,1,n+1).';
    p=bsxfun(@plus,a,bsxfun(@times,t,b-a));
    if k>1, p=p(2:end,:); end
    samples=[samples;p]; %#ok<AGROW>
end
h=mmra_terrain(samples,env);
clearance=samples(:,3)-h-env.safetyMargin;
minClear=min(clearance);meanClear=mean(clearance);
end
