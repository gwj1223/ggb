function ok = mmra_postprocess_path_free(path,env,cfg)
%MMRA_POSTPROCESS_PATH_FREE Recheck EVERY output chord and both endpoints.
% For legacy MMRA the historical mmra_path_free is used unchanged.
ok = false;
if ~isnumeric(path) || size(path,2)~=3 || size(path,1)<2 || ...
        ~all(isfinite(path(:)))
    return;
end
if ~isfield(cfg,'edgeFreeFcn') || isempty(cfg.edgeFreeFcn)
    resolution = 1.5;
    if isfield(cfg,'edgeResolution') && ~isempty(cfg.edgeResolution)
        resolution = cfg.edgeResolution;
    end
    ok = mmra_path_free(path,env,resolution);
    return;
end
for i=1:size(path,1)-1
    if ~mmra_postprocess_edge_free(path(i,:),path(i+1,:),env,cfg)
        return;
    end
end
ok = true;
end
