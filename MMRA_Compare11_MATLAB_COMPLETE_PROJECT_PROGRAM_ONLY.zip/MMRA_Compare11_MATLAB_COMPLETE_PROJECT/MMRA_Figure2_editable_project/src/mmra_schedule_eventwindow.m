function out=mmra_schedule_eventwindow(paths,opt)
%MMRA_SCHEDULE_EVENTWINDOW Endpoint-aware conflict-window temporal search.
% All path, speed, occupancy, safety and delay-grid inputs are unchanged.
% The incumbent is ALWAYS mmra_schedule_conflict_aware(paths,opt); a new
% result is accepted ONLY if mmra_pair_minsep re-verifies every pair AND
% recovers feasibility or strictly reduces makespan.
%
% Novel experimental mechanisms vs bottleneck reordering:
%   (1) pairwise forbidden relative-delay windows incl held endpoints;
%   (2) direct grid-domain propagation, not 0:step:60 repeated path checks;
%   (3) endpoint-graph-guided orders + bounded beam search with forward
%       checking over launch-time assignments (not only priority orders).
% This is a bounded, conservative, heuristic CSP, NOT a complete solver and
% has no global optimality guarantee. CPU overhead may be significant.
allClock=tic;
originalOpt=opt;
if isfield(originalOpt,'priorityOrder')
    originalOpt=rmfield(originalOpt,'priorityOrder');
end
best=mmra_schedule_conflict_aware(paths,originalOpt);
reference=best;
U=numel(paths);
maxBeam=localIntegerOpt(opt,'eventBeamWidth',12,1);
maxNodes=localIntegerOpt(opt,'eventMaxExpandedNodes',450,0);
maxChoices=localIntegerOpt(opt,'eventMaxDelayChoices',8,1);
varChoices=localIntegerOpt(opt,'eventMaxVariableChoices',2,1);
maxVerify=localIntegerOpt(opt,'eventMaxVerifyCandidates',12,1);
cache=struct();
searchExpansions=0;searchGenerated=0;greedyAttempts=0;
checked=0;falseSafe=0;successFromSearch=0;
bestSource='conflict_aware_incumbent';
cache_s=0;search_s=0;

if U>1 && isfinite(reference.preConflicts) && ...
        ~(reference.success && reference.preConflicts==0)
    cacheClock=tic;
    cache=mmra_sched_window_cache(paths,opt);
    cache_s=toc(cacheClock);
    if cache.noCompatiblePairCount==0
        % Candidate orders require zero full-pair rechecks until a complete
        % time assignment has been found by the lookup-table scheduler.
        [~,endpointOrder]=sortrows([-cache.endpointScore, ...
            -cache.conflictDegree,-cache.lens,(1:U)'],[1 2 3 4]);
        [~,degreeOrder]=sortrows([-cache.conflictDegree, ...
            -cache.endpointScore,-cache.lens,(1:U)'],[1 2 3 4]);
        [~,lengthOrder]=sortrows([-cache.lens,(1:U)'],[1 2]);
        orderSet={reshape(endpointOrder,1,[]), ...
            reshape(degreeOrder,1,[]),reshape(lengthOrder,1,[])};
        seen={};
        for oi=1:numel(orderSet)
            order=orderSet{oi};
            if any(cellfun(@(x)isequal(x,order),seen)),continue;end
            seen{end+1}=order; %#ok<AGROW>
            greedyAttempts=greedyAttempts+1;
            k=localGreedy(order,cache);
            if isempty(k),continue;end
            candidate=mmra_sched_verify_delays(paths,k*opt.delayStep,opt, ...
                reference.preConflicts);
            checked=checked+1;
            if ~candidate.success,falseSafe=falseSafe+1;continue;end
            if ~best.success || candidate.makespan<best.makespan-1e-9
                candidate.priorityOrder=order;
                best=candidate;bestSource='event_endpoint_greedy';
                successFromSearch=successFromSearch+1;
            end
        end
        searchClock=tic;
        if maxNodes>0
            [fullCandidates,searchExpansions,searchGenerated]= ...
                localBeamSearch(cache,best,maxBeam,maxNodes,maxChoices,varChoices);
            if ~isempty(fullCandidates)
                peaks=zeros(numel(fullCandidates),1);
                for k=1:numel(fullCandidates)
                    z=fullCandidates{k};
                    peaks(k)=max(z*opt.delayStep+cache.flightTimes);
                end
                [~,ranking]=sort(peaks);
                for kk=1:min(numel(ranking),maxVerify)
                    z=fullCandidates{ranking(kk)};
                    if best.success && ...
                            peaks(ranking(kk))>=best.makespan-1e-9
                        break;
                    end
                    candidate=mmra_sched_verify_delays(paths, ...
                        z*opt.delayStep,opt,reference.preConflicts);
                    checked=checked+1;
                    if ~candidate.success
                        falseSafe=falseSafe+1;continue;
                    end
                    if ~best.success || candidate.makespan<best.makespan-1e-9
                        best=candidate;bestSource='event_beam_temporal_repair';
                        successFromSearch=successFromSearch+1;
                    end
                end
            end
        end
        search_s=toc(searchClock);
    else
        bestSource='conflict_aware_fallback_pairwise_grid_nogo';
    end
end

out=best;
out.mode='eventwindow_repair';
out.chosenStrategy=bestSource;
out.eventStrategy=bestSource;
out.eventReferenceCASuccess=reference.success;
out.eventReferenceCAMakespan_s=reference.makespan;
out.eventReferenceCAWall_s=reference.schedule_s;
% Preserve baseline diagnostic fields even when a new verified schedule wins.
out.baselineSuccess=reference.baselineSuccess;
out.baselineMakespan_s=reference.baselineMakespan_s;
out.conflictDegrees=reference.conflictDegrees;
out.conflictGraphEdges=reference.conflictGraphEdges;
out.eventSearchAccepted=successFromSearch;
out.eventCacheWall_s=cache_s;
out.eventSearchWall_s=search_s;
out.eventGreedyAttempts=greedyAttempts;
out.eventExpandedNodes=searchExpansions;
out.eventGeneratedNodes=searchGenerated;
out.eventVerifiedSchedules=checked;
out.eventCacheFalseSafeN=falseSafe;
out.eventNoCompatiblePairs=0;
out.eventRouteNearGoalN=NaN;
out.eventRouteNearStartN=NaN;
out.eventForbiddenOffsets=NaN;
if ~isempty(fieldnames(cache))
    out.eventNoCompatiblePairs=cache.noCompatiblePairCount;
    out.eventRouteNearGoalN=cache.routeNearOtherGoalN;
    out.eventRouteNearStartN=cache.routeNearOtherStartN;
    out.eventForbiddenOffsets=cache.forbiddenOffsetsTotal;
end
out.schedule_s=toc(allClock);
if reference.success
    assert(out.success && out.makespan<=reference.makespan+1e-8, ...
        'Event window fallback lost a feasible reference schedule.');
end
if out.success
    assert(out.postConflicts==0 && ...
        out.minSeparation>=opt.dSafe-opt.tol-1e-8, ...
        'Event-window output was not independently collision safe.');
end
end

function x=localIntegerOpt(opt,field,defaultValue,minimumValue)
x=defaultValue;
if isfield(opt,field),x=opt.(field);end
assert(isnumeric(x) && isscalar(x) && isfinite(x) && ...
    x>=minimumValue && x==floor(x), ...
    '%s must be an integer >= %d.',field,minimumValue);
x=double(x);
end

function result=localGreedy(order,cache)
U=cache.U;K=cache.K;
result=-ones(U,1);
allowed=true(1,K+1);
for r=1:U
    i=order(r);
    allowed(:)=true;
    for j=order(1:r-1)
        % delta=tau_i-tau_j. Cache orientation (j,i) is intentional.
        deltaIdx=(0:K)-result(j)+K+1;
        forbidden=cache.forbid{j,i};
        allowed=allowed & ~forbidden(deltaIdx);
        if ~any(allowed),break;end
    end
    idx=find(allowed,1,'first');
    if isempty(idx),result=[];return;end
    result(i)=idx-1;
end
end

function [completed,expanded,generated]=localBeamSearch(cache,incumbent, ...
        beamWidth,maxExpanded,maxDelayChoices,maxVariables)
% Iterative beam of partial launch-time constraint assignments.
% Each state retains feasible delay DOMAINS for all unassigned aircraft.
% All operations inside the search use the precomputed windows, never
% repeated continuous-time pairwise collision checks.
U=cache.U;K=cache.K;
root=struct('assigned',false(U,1),'k',-ones(U,1), ...
    'domains',true(U,K+1),'peak',0,'score',0);
front={root};completed={};
expanded=0;generated=0;
if incumbent.success,maxMake=incumbent.makespan-1e-9;
else,maxMake=inf;end
for depth=1:U
    next={};nextScores=[];
    for stateID=1:numel(front)
        if expanded>=maxExpanded,break;end
        state=front{stateID};expanded=expanded+1;
        unassigned=find(~state.assigned);
        domainCount=sum(state.domains(unassigned,:),2);
        ranking=[domainCount, ...
            -cache.endpointScore(unassigned), ...
            -cache.conflictDegree(unassigned), ...
            -cache.lens(unassigned),double(unassigned)];
        [~,order]=sortrows(ranking,[1 2 3 4 5]);
        focus=unassigned(order(1:min(maxVariables,numel(order))));
        for i=reshape(focus,1,[])
            choices=localDelayChoices(state.domains(i,:), ...
                cache.delayStep,maxDelayChoices);
            for k=reshape(choices,1,[])
                futurePeak=max(state.peak, ...
                    k*cache.delayStep+cache.flightTimes(i));
                if futurePeak>=maxMake,continue;end
                child=state;
                child.assigned(i)=true;
                child.k(i)=k;
                child.domains(i,:)=false;
                child.domains(i,k+1)=true;
                left=find(~child.assigned);
                valid=true;lower=futurePeak;
                for jj=reshape(left,1,[])
                    deltaIdx=(0:K)-k+K+1;
                    forbidden=cache.forbid{i,jj};
                    child.domains(jj,:)=child.domains(jj,:) & ...
                        ~forbidden(deltaIdx);
                    if isfinite(maxMake)
                        admissible=(0:K)*cache.delayStep+ ...
                            cache.flightTimes(jj)<maxMake;
                        child.domains(jj,:)=child.domains(jj,:) & admissible;
                    end
                    first=find(child.domains(jj,:),1,'first');
                    if isempty(first),valid=false;break;end
                    lower=max(lower,(first-1)*cache.delayStep+ ...
                        cache.flightTimes(jj));
                end
                if ~valid || lower>=maxMake,continue;end
                child.peak=futurePeak;
                generated=generated+1;
                if isempty(left)
                    completed{end+1}=child.k; %#ok<AGROW>
                    continue;
                end
                % Search score favours both a short completion-time lower
                % bound and preservation of flexible remaining domains.
                counts=sum(child.domains(left,:),2);
                shrink=sum(1-counts/(K+1));
                child.score=lower+0.05*shrink;
                next{end+1}=child; %#ok<AGROW>
                nextScores(end+1,1)=child.score; %#ok<AGROW>
            end
        end
    end
    if depth==U || isempty(next),break;end
    [~,ix]=sort(nextScores,'ascend');
    ix=ix(1:min(numel(ix),beamWidth));
    front=next(ix);
end
if numel(completed)>1
    M=zeros(numel(completed),U);
    for row=1:numel(completed)
        M(row,:)=reshape(completed{row},1,[]);
    end
    [~,ia]=unique(M,'rows','stable');
    completed=completed(sort(ia));
end
end

function picks=localDelayChoices(mask,step,maxN)
% Event boundaries are the first allowed grid entry of every interval.
% For a long initial interval, also branch on a few later grid events so
% the search is not restricted to the always-earliest delay assignment.
idx=find(mask);
if isempty(idx),picks=[];return;end
boundary=find(mask & ~[false mask(1:end-1)]);
base=boundary(1);
offsets=round([0 0.5 2 6 14 30 50]/step);
extra=base+offsets;
extra=extra(extra<=numel(mask));
extra=extra(mask(extra));
% Include every early allowed interval start before using long-block probes.
firsts=boundary(1:min(5,numel(boundary)));
options=unique([firsts,extra],'stable');
[~,rank]=sort(options,'ascend');
options=options(rank);
if numel(options)>maxN
    options=options(1:maxN);
end
picks=options-1;
end
