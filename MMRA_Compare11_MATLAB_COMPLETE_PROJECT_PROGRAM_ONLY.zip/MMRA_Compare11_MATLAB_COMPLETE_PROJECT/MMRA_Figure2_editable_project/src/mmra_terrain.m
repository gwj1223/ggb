function [h, hx, hy] = mmra_terrain(points, env)
%MMRA_TERRAIN Single terrain oracle for search, collision, grid & plots.
% points is N-by-2 or N-by-3; outputs N-by-1. Analytic derivatives provided.
% Profile paper_gmm uses only Gaussian components, exactly as manuscript.
% Profile legacy20_sine includes original six sine terms and max(h,0).
if isempty(points)
    h=[]; hx=[]; hy=[]; return;
end
assert(size(points,2)>=2, 'Points must contain x,y coordinates');
x = points(:,1); y = points(:,2);
% A scaled 5 km profile samples the SAME differentiable synthetic surface
% at physical coordinates. Derivatives must be scaled by chain rule.
xyScale=1; zScale=1;
if isfield(env,'terrainCoordinateScaleXY')
    xyScale=env.terrainCoordinateScaleXY;
end
if isfield(env,'terrainAmplitudeScaleZ')
    zScale=env.terrainAmplitudeScaleZ;
end
assert(xyScale>0 && zScale>0 && isfinite(xyScale) && isfinite(zScale));
x=x/xyScale; y=y/xyScale;
h = env.baseHeight + zeros(size(x));
hx = zeros(size(x)); hy = zeros(size(x));
for k = 1:size(env.peaks,1)
    pk=env.peaks(k,:); a=pk(1); mx=pk(2); my=pk(3); sx=pk(4); sy=pk(5);
    e = a .* exp(-0.5*((x-mx).^2/sx^2+(y-my).^2/sy^2));
    h = h+e;
    hx = hx-e.*(x-mx)/sx^2;
    hy = hy-e.*(y-my)/sy^2;
end
% v2.5 OPTIONAL refined multi-peak geometry: rotated ridges,
% smooth relief-proportional erosion, and small-scale relief texture.
% The original 100 m, v2.3 and v2.4 terrain formulas are unchanged.
if isfield(env,'terrainRidges') && ~isempty(env.terrainRidges)
    for k=1:size(env.terrainRidges,1)
        [v,dx,dy]=mmra_refined_oriented_gaussian( ...
            x,y,env.terrainRidges(k,:));
        h=h+v; hx=hx+dx; hy=hy+dy;
    end
    base=env.baseHeight;
    relief=h-base;
    reliefX=hx;reliefY=hy;
    atten=ones(size(x));attenX=zeros(size(x));attenY=zeros(size(x));
    for k=1:size(env.terrainErosionGullies,1)
        [cut,cutX,cutY]=mmra_refined_oriented_gaussian( ...
            x,y,env.terrainErosionGullies(k,:));
        % Product rule: attenuation := attenuation*(1-cut).
        nextX=attenX.*(1-cut)-atten.*cutX;
        nextY=attenY.*(1-cut)-atten.*cutY;
        atten=atten.*(1-cut);
        attenX=nextX;attenY=nextY;
    end
    h=base+relief.*atten;
    hx=reliefX.*atten+relief.*attenX;
    hy=reliefY.*atten+relief.*attenY;
    % Reduce texture to zero as mountain relief vanishes. Derivatives are
    % analytical and are used by APF and obstacle-clearance calculations.
    scale=env.terrainMicroReliefScale_m;
    mask=1-exp(-relief/scale);
    maskX=exp(-relief/scale).*reliefX/scale;
    maskY=exp(-relief/scale).*reliefY/scale;
    wave=zeros(size(x));waveX=wave;waveY=wave;
    for k=1:size(env.terrainMicroWaves,1)
        a=env.terrainMicroWaves(k,1);
        kx=env.terrainMicroWaves(k,2);
        ky=env.terrainMicroWaves(k,3);
        phase=env.terrainMicroWaves(k,4);
        w=kx*x+ky*y+phase;
        wave=wave+a*sin(w);
        waveX=waveX+a*kx*cos(w);
        waveY=waveY+a*ky*cos(w);
    end
    h=h+mask.*wave;
    hx=hx+maskX.*wave+mask.*waveX;
    hy=hy+maskY.*wave+mask.*waveY;
end
if env.useRipples
    A=x/20+0.3; B=y/24+0.7;
    h=h+4.*sin(A).*cos(B);
    hx=hx+(4/20).*cos(A).*cos(B);
    hy=hy-(4/24).*sin(A).*sin(B);
    A=x/16+y/18+1;
    h=h+3.5.*sin(A);
    hx=hx+(3.5/16).*cos(A); hy=hy+(3.5/18).*cos(A);
    A=x/9+0.5; B=y/10+1;
    h=h+2.*sin(A).*sin(B);
    hx=hx+(2/9).*cos(A).*sin(B);
    hy=hy+(2/10).*sin(A).*cos(B);
    A=x/2.8+y/3+0.5; B=x/3.2-y/3.4;
    h=h+sin(A).*cos(B);
    hx=hx+(1/2.8).*cos(A).*cos(B)-(1/3.2).*sin(A).*sin(B);
    hy=hy+(1/3).*cos(A).*cos(B)+(1/3.4).*sin(A).*sin(B);
    A=x/2+1; B=y/2.2+0.8;
    h=h+0.8.*sin(A).*cos(B);
    hx=hx+0.4.*cos(A).*cos(B);
    hy=hy-(0.8/2.2).*sin(A).*sin(B);
    A=x/1.7-y/1.8+1.5;
    h=h+0.6.*cos(A);
    hx=hx-(0.6/1.7).*sin(A);
    hy=hy+(0.6/1.8).*sin(A);
    % Legacy floor is nondifferentiable at the zero level.
    below = h < 0;
    h(below)=0; hx(below)=0; hy(below)=0;
end
% H_phys(X,Y)=zScale*H_original(X/xyScale,Y/xyScale).
h=zScale*h;
hx=(zScale/xyScale)*hx;
hy=(zScale/xyScale)*hy;
end
