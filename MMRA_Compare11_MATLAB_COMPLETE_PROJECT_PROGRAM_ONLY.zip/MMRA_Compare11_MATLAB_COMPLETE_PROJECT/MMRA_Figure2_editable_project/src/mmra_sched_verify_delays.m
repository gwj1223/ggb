function out=mmra_sched_verify_delays(paths,delays,opt,preConflicts)
%MMRA_SCHED_VERIFY_DELAYS Independent exact fixed-polyline schedule check.
% Uses the UNCHANGED mmra_pair_minsep on EVERY pair, including held endpoints.
U=numel(paths);
out=struct('success',false,'reason','invalid_delays', ...
    'delays',reshape(delays,[],1),'preConflicts',preConflicts, ...
    'postConflicts',NaN,'minSeparation',NaN,'makespan',NaN, ...
    'schedule_s',NaN,'pairChecks',0,'failedUAV',NaN, ...
    'priorityOrder',[],'dSafe',opt.dSafe);
if numel(delays)~=U || any(~isfinite(delays)) || ...
        any(delays < -1e-9) || any(delays>opt.maxDelay+1e-9)
    return;
end
lengths=zeros(U,1);
for i=1:U
    [~,~,lengths(i)]=mmra_arc(paths{i});
    if lengths(i)<=1e-10,return;end
end
out.postConflicts=0;out.minSeparation=inf;
for i=1:U-1
    for j=i+1:U
        [d,~,isConflict]=mmra_pair_minsep(paths{i},paths{j}, ...
            delays(i),delays(j),opt);
        out.pairChecks=out.pairChecks+1;
        out.minSeparation=min(out.minSeparation,d);
        out.postConflicts=out.postConflicts+double(isConflict);
    end
end
out.makespan=max(delays(:)+lengths/opt.speed);
out.success=(out.postConflicts==0) && ...
    (out.minSeparation>=opt.dSafe-opt.tol-1e-8);
if out.success,out.reason='scheduled_window_verified';
else,out.reason='postcheck_conflict';end
end
