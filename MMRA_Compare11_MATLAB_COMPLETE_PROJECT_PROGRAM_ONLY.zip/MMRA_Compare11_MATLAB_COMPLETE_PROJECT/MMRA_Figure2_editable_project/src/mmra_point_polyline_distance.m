function [dMin,sClosest,qClosest] = mmra_point_polyline_distance(path,point)
%MMRA_POINT_POLYLINE_DISTANCE Exact Euclidean point-to-3D-polyline distance.
% Returns closest arc-length position and point; no trajectory timing.
[pts,cum,~]=mmra_arc(path);
q=reshape(point,1,3);
a=pts(1:end-1,:);v=diff(pts,1,1);
vv=sum(v.^2,2);
w=bsxfun(@minus,q,a);
t=zeros(size(vv));valid=vv>1e-20;
t(valid)=sum(w(valid,:).*v(valid,:),2)./vv(valid);
t=max(0,min(1,t));
proj=a+bsxfun(@times,t,v);
d2=sum(bsxfun(@minus,proj,q).^2,2);
[best,idx]=min(d2);
dMin=sqrt(best);
sClosest=cum(idx)+t(idx)*(cum(idx+1)-cum(idx));
qClosest=proj(idx,:);
end
