function risk=mmra_risk_density(points,env,band_m,terrainHeight)
%MMRA_RISK_DENSITY Shared nonnegative 0..1 terrain / NFZ exposure.
% Existing scenes without NFZs exactly retain their old terrain-risk model.
assert(band_m>0 && isfinite(band_m));
if nargin<4 || isempty(terrainHeight)
    terrainHeight=mmra_terrain(points,env);
end
clearance=points(:,3)-terrainHeight-env.safetyMargin;
risk=min(1,max(0,1-clearance/band_m)).^2;
buf=0;halo=180;
if isfield(env,'noFlyBuffer_m'),buf=env.noFlyBuffer_m;end
if isfield(env,'noFlyRiskBand_m'),halo=env.noFlyRiskBand_m;end
assert(halo>0 && isfinite(halo));
if isfield(env,'noFlyCylinders') && ~isempty(env.noFlyCylinders)
for k=1:size(env.noFlyCylinders,1)
    c=env.noFlyCylinders(k,:);
    radial=hypot(points(:,1)-c(1),points(:,2)-c(2))-(c(3)+buf);
    vertical=max(0,max(c(4)-points(:,3),points(:,3)-c(5)));
    distance=hypot(max(0,radial),vertical);
    near=min(1,max(0,1-distance/halo)).^2;
    risk=max(risk,near);
end
end
% Optional static AABB proximity penalty, evaluated outside buffered boxes.
if isfield(env,'staticBoxes') && ~isempty(env.staticBoxes)
    boxBuffer=0;boxHalo=180;
    if isfield(env,'staticBoxBuffer_m'),boxBuffer=env.staticBoxBuffer_m;end
    if isfield(env,'staticBoxRiskBand_m'),boxHalo=env.staticBoxRiskBand_m;end
    assert(isfinite(boxHalo) && boxHalo>0);
    for k=1:size(env.staticBoxes,1)
        b=env.staticBoxes(k,:);
        lo=[b(1) b(3) b(5)]-boxBuffer;
        hi=[b(2) b(4) b(6)]+boxBuffer;
        pLo=bsxfun(@minus,lo,points);
        pHi=bsxfun(@minus,points,hi);
        distance=sqrt(sum(max(0,max(pLo,pHi)).^2,2));
        near=min(1,max(0,1-distance/boxHalo)).^2;
        risk=max(risk,near);
    end
end
end
