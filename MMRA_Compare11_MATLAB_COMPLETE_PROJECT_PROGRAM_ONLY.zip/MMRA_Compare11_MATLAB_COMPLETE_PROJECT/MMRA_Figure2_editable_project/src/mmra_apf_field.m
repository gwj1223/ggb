function [U,g,info] = mmra_apf_field(q,goal,env,cfg)
%MMRA_APF_FIELD Scalar potential and analytical 3-D gradient for one sample.
% APF modes:
%   legacy  : identical repulsive GRADIENT to v1.1 (including rhoFloor).
%   sc_apf  : smooth safety-clearance-aware terrain repulsion (v1.2).
%
% c(q) = z - H(x,y) - env.safetyMargin,  a=max(0,scSafeBand-c).
% Urep = scKRep*scSoftWidth*log(cosh(a/scSoftWidth)).
% grad Urep = -scKRep*tanh(a/scSoftWidth)*[-Hx -Hy 1].
% The log(cosh(.)) is evaluated stably for large inputs, so below-ground
% samples do not produce a pole. Urep is C1 across the activation boundary
% for differentiable terrain; GMM is smooth. This does NOT certify RRT*
% optimality, continuous edge safety, or flight dynamic feasibility.
q=reshape(q,1,3); goal=reshape(goal,1,3);
assert(all(isfinite([q goal])), 'APF needs finite sample/goal coordinates');
[h,hx,hy]=mmra_terrain(q,env);
rho=q(3)-h;
nClear=[-hx -hy 1];
gAtt=cfg.kAtt*(q-goal);
uAtt=0.5*cfg.kAtt*sum((q-goal).^2);

if isfield(cfg,'apfMode') && ~isempty(cfg.apfMode)
    mode=lower(char(cfg.apfMode));
else
    mode='legacy'; % support old cfg structures
end
uRep=0;gRep=zeros(1,3);repCoefficient=0;
switch mode
    case 'legacy'
        assert(cfg.rhoFloor>0 && cfg.rhoFloor<cfg.rho0, ...
            'Legacy APF requires 0<rhoFloor<rho0');
        if rho <= cfg.rho0
            rr=max(rho,cfg.rhoFloor);
            repCoefficient=-cfg.kRep*(1/rr-1/cfg.rho0)/rr^2;
            gRep=repCoefficient*nClear;
            if rho >= cfg.rhoFloor
                uRep=0.5*cfg.kRep*(1/rho-1/cfg.rho0)^2;
            else
                % Linearly continue potential below floor. Its derivative
                % equals the original v1.1 finite gradient extension.
                uFloor=0.5*cfg.kRep*(1/cfg.rhoFloor-1/cfg.rho0)^2;
                uRep=uFloor+repCoefficient*(rho-cfg.rhoFloor);
            end
        end
    case 'sc_apf'
        assert(isfield(cfg,'scSafeBand') && isfield(cfg,'scSoftWidth') ...
            && isfield(cfg,'scKRep'), 'Missing SC-APF configuration');
        assert(isfinite(cfg.scSafeBand) && cfg.scSafeBand>=0 ...
            && isfinite(cfg.scSoftWidth) && cfg.scSoftWidth>0 ...
            && isfinite(cfg.scKRep) && cfg.scKRep>=0, ...
            'SC-APF requires safeBand>=0, softWidth>0, kRep>=0');
        c=rho-env.safetyMargin;
        a=max(0,cfg.scSafeBand-c);
        u=a/cfg.scSoftWidth;
        % Stable logcosh(u); direct cosh(u) overflows at large u.
        au=abs(u);
        logCosh=au+log1p(exp(-2*au))-log(2);
        uRep=cfg.scKRep*cfg.scSoftWidth*logCosh;
        repCoefficient=-cfg.scKRep*tanh(u);
        gRep=repCoefficient*nClear;
    otherwise
        error('Unknown APF mode: %s',mode);
end
U=uAtt+uRep;
g=gAtt+gRep;
if nargout>=3
    info=struct('mode',mode,'rho',rho, ...
        'clearanceToSafety',rho-env.safetyMargin, ...
        'attractiveGradientNorm',norm(gAtt), ...
        'repulsiveGradientNorm',norm(gRep), ...
        'repulsiveCoefficient',repCoefficient, ...
        'totalGradientNorm',norm(g));
end
end
