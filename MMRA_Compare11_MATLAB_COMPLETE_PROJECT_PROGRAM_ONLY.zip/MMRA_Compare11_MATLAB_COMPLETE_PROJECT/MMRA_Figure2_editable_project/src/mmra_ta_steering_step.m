function [step_m,pressure] = mmra_ta_steering_step(node,env,cfg,opt)
%MMRA_TA_STEERING_STEP Shorter steering near steep/low-clearance terrain.
% The minimum step is strictly positive, preserving exploratory ability.
if ~opt.useAdaptiveStep
    step_m=cfg.step;pressure=0;return;
end
[h,hx,hy]=mmra_terrain(node,env);
extra=node(3)-h-env.safetyMargin;
risk=mmra_risk_density(node,env,cfg.riskCostBand_m,h);
slopePressure=min(1,hypot(hx,hy)/opt.slopeScale);
clearancePressure=max(0,min(1,1-extra/opt.clearanceScale_m));
pressure=max([risk slopePressure clearancePressure]);
step_m=cfg.step*(1-(1-opt.minStepFraction)*pressure);
step_m=min(cfg.step,max(cfg.step*opt.minStepFraction,step_m));
end
