function [env, cfg, sched] = mmra_defaults(profile)
%MMRA_DEFAULTS One explicit source of terrain/planner/scheduler parameters.
% profile: 'paper_gmm' (default, paper independent ablation) or
%          'legacy20_sine' (legacy uav.m terrain with 20 peaks + six ripples).
% The profiles are DIFFERENT environments. Do not merge their statistics.
if nargin < 1 || isempty(profile), profile = 'paper_gmm'; end
% New 5 km x 5 km x 2 km profiles are OPT-IN. Original 100 m experimental
% profiles are unchanged, so prior v2.1/v2.2 results remain reproducible.
largeProfile=lower(char(profile));
% v2.4 scenery-only opt-in: same domain, new 3D terrain and optional NFZs.
% These synthetic scenarios are separate from all frozen v2.1-v2.3 data.
if any(strcmp(largeProfile, {'ridge_pass_5km', ...
        'mountain_cluster_5km','mountain_cluster_refined_5km', ...
        'mountain_cluster_figure2_v28_5km', ...
        'mountain_cluster_figure2_custom_5km', ...
        'mountain_cluster_parula_v26_5km', ...
        'mountain_cluster_staggered_v27_5km', ...
        'restricted_corridor_5km'}))
    [env,cfg,sched]=mmra_defaults('paper_gmm_5km');
    env=mmra_5km_scenery_profile(env,largeProfile);
    % Terrain plus optional NFZ proximity share one common risk oracle.
    cfg.riskCostBand_m=75;
    cfg.riskCostResolution_m=5;
    cfg.edgeResolution=5;
    cfg.guardFineResolution=2;
    return;
end
if strcmp(largeProfile,'paper_gmm_5km') || ...
        strcmp(largeProfile,'legacy20_sine_5km')
    if strcmp(largeProfile,'paper_gmm_5km')
        base='paper_gmm';
    else
        base='legacy20_sine';
    end
    [env,cfg,sched]=mmra_defaults(base);
    env.profile=largeProfile;
    env.boundsLo=[0 0 0];
    env.boundsHi=[5000 5000 2000];
    % Analytic terrain stays geometrically similar to its original profile:
    % H_large(X,Y)=20*H_base(X/50,Y/50). This is SYNTHETIC terrain,
    % not a real 5 km DEM or independently validated field survey.
    env.terrainCoordinateScaleXY=50;
    env.terrainAmplitudeScaleZ=20;
    env.safetyMargin=50;              % terrain clearance, in physical m
    cfg.step=175;                      % RRT* step in physical m
    cfg.rewireRadius=350;
    cfg.goalRadius=210;
    cfg.maxIter=1800;
    cfg.goalBias=0.14;
    cfg.uniformMix=0.05;
    cfg.costMode='length_risk_climb';
    cfg.riskCostWeight=0.50;
    cfg.ascentCostWeight=0.50;
    cfg.edgeResolution=5.0;          % sampled terrain check, in m
    cfg.riskCostResolution_m=5.0;     % match for fused edge evaluation
    cfg.riskCostBand_m=40.0;
    cfg.guardFineResolution=2.0;     % separate sampled audit
    cfg.rho0=150;
    cfg.rhoFloor=5;
    cfg.scSafeBand=50;
    cfg.scSoftWidth=20;
    cfg.prune=false;
    cfg.smooth=false;
    % v2.3 development: planned sequential release + in-flight feedback.
    % No change to the 10 m aircraft separation or 15 m/s cruise limit.
    sched.mode='speed_feedback';
    sched.speedFeedbackLaunchInterval_s=3.0;
    sched.speedFeedbackLaunchOrder=[];
    sched.speedFeedbackDt_s=0.5;
    sched.speedFeedbackPredictionStep_s=0.5;
    sched.speedFeedbackMaxTime_s=900;
    sched.speedFeedbackMaxStall_s=30;
    sched.speedFeedbackGuard_m=2.0;
    sched.speedFeedbackRelease_m=3.0;
    sched.maxDelay=120;
    return;
end
switch lower(profile)
    case 'paper_gmm'
        env.profile = 'paper_gmm';
        env.boundsLo = [0 0 5]; env.boundsHi = [100 100 80];
        env.baseHeight = 2;
        env.peaks = [42 35 42 12 10; 38 62 55 10 14; ...
                     30 50 76 14 8; 28 76 30 9 12; 18 22 70 11 11];
        env.useRipples = false;
        env.safetyMargin = 7;
    case 'legacy20_sine'
        env.profile = 'legacy20_sine';
        env.boundsLo = [0 0 0]; env.boundsHi = [100 100 100];
        env.baseHeight = 0;
        env.peaks = [38 40 40 12 14;42 75 25 13 11;48 50 50 4 8; ...
            36 70 80 7 9;32 25 75 10 7;33 15 15 9 9; ...
            25 85 55 8 10;28 60 15 10 6;22 30 50 6 12; ...
            18 90 90 7 7;20 55 75 9 5;15 20 35 5 8; ...
            12 45 20 6 4;10 80 45 4 5;14 35 85 5 6; ...
            11 65 65 4 4;13 10 60 5 5;9 95 15 4 4; ...
            8 5 45 3 4;10 48 92 4 3];
        env.useRipples = true;
        env.safetyMargin = 8;
    otherwise
        error('Unknown environment profile: %s', profile);
end

% Spatial parameters. RRT* stops at FIRST feasible goal path; there is no
% asymptotic-optimality claim for this implementation.
cfg.step = 8.0;
cfg.rewireRadius = 20.0;
% v2.0 experimental, NOT enabled by default: weighted length + GMM risk.
% A path risk integral has units of metres, so weight is dimensionless.
% riskCostWeight=0 under length_risk must reproduce length-only geometry.
cfg.costMode = 'length';          % length / length_risk / length_climb / length_risk_climb
cfg.riskCostWeight = 0.50;       % initial fixed risk weight (dimensionless)
cfg.ascentCostWeight = 0.50;     % initial fixed ascent weight (dimensionless)
cfg.costEvalMode = 'fused';      % 'fused' vs v2.0 'separate' benchmark
cfg.riskCostBand_m = 2.0;       % spare clearance above mandatory margin
cfg.riskCostResolution_m = 0.25; % cost quadrature, not collision certificate
cfg.wallBudget_s = Inf;         % optional single-search clock limit for ablation
cfg.goalRadius = 8.0;
cfg.maxIter = 900;
cfg.goalBias = 0.10;
cfg.lambdaG = 0.75;
cfg.gradientEps = 1e-9;
cfg.uniformMix = 0.0; % match manuscript Eq.(14); optional exploratory 0.15
cfg.collectApfDiagnostics = false; % v1.3 optional sampling diagnostics; off for timings
cfg.kAtt = 1.5;
cfg.kRep = 80;
cfg.rho0 = 25;
cfg.rhoFloor = 0.8; % legacy finite gradient extension for rho<=0
% v1.2: APF mode is explicit. Legacy is DEFAULT for backwards reproducibility.
% Use cfg.apfMode='sc_apf' to activate safety-clearance-aware smooth repulsion.
% New parameters are preliminary candidates, NOT optimized or validated gains.
cfg.apfMode = 'legacy'; % 'legacy', 'sc_apf', or 'guarded_sc' (v1.7)
cfg.scSafeBand = 8.0; % m above the mandatory terrain-clearance boundary
cfg.scSoftWidth = 4.0; % m, smooth transition scale; must be positive
cfg.scKRep = 30.0; % fixed developmental Candidate #3, not post-hoc retuned
cfg.edgeResolution = 0.25; % common spatial edge check; sampled only
% v1.7: post-planning path-level guard. Used by mmra_plan_single when
% cfg.apfMode='guarded_sc'. It compares SC against SAME-SEED legacy APF.
% Both searches are actually executed; runtime increases.
cfg.guardFineResolution = 0.10; % independent sampled validation [m]
cfg.guardAbsoluteClear_m = 1e-6; % each selected path must stay above this
cfg.guardMaxClearLoss_m = 0.25; % SC can lose at most this vs legacy [m]
cfg.guardPathTolerance_m = 1e-7; % SC is selected only when no longer
cfg.bezierSamples = 8; % reference post-processing sampling density
cfg.smooth = true;
cfg.prune = true;

% Scheduler. Positions are piecewise-linear and arc-length timed.
% Default HOLD occupancy is conservative, including waiting at start and
% remaining at the terminal waypoint. Common held final goals can be
% infeasible, in which case schedule.success is false (never zero conflicts).
sched.speed = 15;
sched.dSafe = 10;
sched.delayStep = 0.25;
sched.maxDelay = 60;
sched.startPolicy = 'hold';  % 'hold' or 'inactive'
sched.endPolicy = 'hold';    % 'hold' or 'inactive'
sched.tol = 1e-8;
sched.mode = 'length'; % legacy / conflict_aware / bottleneck_repair / eventwindow_repair / speed_feedback / speed_feedback_spatial_fallback
sched.repairMaxCandidates = 8; % extra order trials; bounded, deterministic
sched.repairMaxRounds = 2;     % bottleneck-reinsertion passes
% Experimental endpoint-aware forbidden-window scheduling (disabled by default).
sched.eventBeamWidth = 12;
sched.eventMaxExpandedNodes = 450;
sched.eventMaxDelayChoices = 8;
sched.eventMaxVariableChoices = 2;
sched.eventMaxVerifyCandidates = 12;
% v2.2 EXPERIMENTAL: predictable, variable-speed collision avoidance.
% To use it set sched.mode='speed_feedback'. This DOES NOT replace frozen
% v2.1 fixed-speed benchmarks or claim physical acceleration guarantees.
sched.speedFeedbackDt_s = 0.20;
sched.speedFeedbackAccel_mps2 = 3.0;
sched.speedFeedbackDecel_mps2 = 6.0;
sched.speedFeedbackHorizon_s = 8.0;
sched.speedFeedbackPredictionStep_s = 0.40;
sched.speedFeedbackGuard_m = 1.0;
sched.speedFeedbackRelease_m = 2.0;
sched.speedFeedbackMaxTime_s = 180;
sched.speedFeedbackMaxStall_s = 15;
sched.speedFeedbackMaxShieldIterations = 80;
sched.speedFeedbackSpeedCaps_mps = [];
sched.speedFeedbackPriorityOrder = [];
% v2.3 optional planned staggered launches. Defaults to 0, so legacy
% v2.2 profiles retain identical simultaneous-launch behavior.
sched.speedFeedbackLaunchInterval_s = 0;
sched.speedFeedbackLaunchOrder = [];
end
