function [value,dx,dy]=mmra_refined_oriented_gaussian(x,y,row)
%MMRA_REFINED_ORIENTED_GAUSSIAN Rotated elliptical Gaussian and derivatives.
% row=[amplitude centreX centreY sigmaAlong sigmaAcross angleDeg].
% x,y must already have undergone the terrain oracle coordinate scaling.
assert(numel(row)==6 && row(4)>0 && row(5)>0);
a=row(1); theta=row(6)*pi/180;
c=cos(theta);ss=sin(theta);
u=c*(x-row(2))+ss*(y-row(3));
v=-ss*(x-row(2))+c*(y-row(3));
value=a*exp(-0.5*((u/row(4)).^2+(v/row(5)).^2));
du=-u/(row(4)^2);dv=-v/(row(5)^2);
dx=value.*(c*du-ss*dv);
dy=value.*(ss*du+c*dv);
end
