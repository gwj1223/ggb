function safe=mmra_no_fly_free(points,env)
%MMRA_NO_FLY_FREE Outside finite cylinders and axis-aligned static boxes.
% Cylinder rows: [cx cy radius zmin zmax], buffer noFlyBuffer_m (radial).
% Box rows: [xmin xmax ymin ymax zmin zmax], buffer staticBoxBuffer_m
% (in all three dimensions). Boundaries and buffer boundaries are forbidden.
assert(size(points,2)==3,'Expected N-by-3 xyz coordinates');
safe=true(size(points,1),1);
if isfield(env,'noFlyCylinders') && ~isempty(env.noFlyCylinders)
    zones=env.noFlyCylinders;
    buffer=0;
    if isfield(env,'noFlyBuffer_m'),buffer=env.noFlyBuffer_m;end
    for k=1:size(zones,1)
        c=zones(k,:);
        radial=(points(:,1)-c(1)).^2+(points(:,2)-c(2)).^2;
        inside=radial<=(c(3)+buffer)^2 & ...
            points(:,3)>=c(4) & points(:,3)<=c(5);
        safe=safe & ~inside;
    end
end
if isfield(env,'staticBoxes') && ~isempty(env.staticBoxes)
    boxes=env.staticBoxes;
    buffer=0;
    if isfield(env,'staticBoxBuffer_m'),buffer=env.staticBoxBuffer_m;end
    for k=1:size(boxes,1)
        b=boxes(k,:);
        inside=points(:,1)>=b(1)-buffer & ...
            points(:,1)<=b(2)+buffer & ...
            points(:,2)>=b(3)-buffer & ...
            points(:,2)<=b(4)+buffer & ...
            points(:,3)>=b(5)-buffer & ...
            points(:,3)<=b(6)+buffer;
        safe=safe & ~inside;
    end
end
end
