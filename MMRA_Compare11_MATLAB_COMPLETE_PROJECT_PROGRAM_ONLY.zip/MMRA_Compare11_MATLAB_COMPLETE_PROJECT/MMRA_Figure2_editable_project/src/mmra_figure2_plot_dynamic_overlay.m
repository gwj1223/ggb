function handles = mmra_figure2_plot_dynamic_overlay(ax, obstacles, t_s, handles)
%MMRA_FIGURE2_PLOT_DYNAMIC_OVERLAY Render moving obstacles as round spheres.
% Appearance-only fix for Figure 2's vertically exaggerated axes:
%   daspect(ax,[1 1 0.55]) makes an ordinary sphere look vertically oval.
% Compensate the drawn sphere radii using the axes DataAspectRatio, so the
% spheres LOOK round from any 3-D viewing angle without changing the saved
% mountain rendering, obstacle trajectories, or collision radii.
%
% Positions/radii are metres; plot coordinates are kilometres.
% visualScale changes DISPLAY SIZE ONLY. Physical collision checking still
% uses the unmodified ob.radius_m field.
%
% Compatible with MATLAB R2023b editor, snapshot and moving preview.

obstacles = mmra_dynamic_obstacles_prepare(obstacles);
assert(isgraphics(ax,'axes'), 'ax must be a valid axes handle.');
assert(isscalar(t_s) && isnumeric(t_s) && isfinite(t_s) && t_s>=0, ...
    'Preview time must be a nonnegative, finite scalar.');

% Same pure surface and mesh colors for D1 / D2 / D3.
faceColor = [1.00 0.73 0.36];      % Soft orange
edgeColor = [0.47 0.25 0.12];      % Dark brown
visualScale = 2.0;               % Display ONLY; physical radii are intact
[sx,sy,sz] = sphere(24);         % Clean spherical mesh, no stripe texture

% Figure 2 deliberately uses an unequal Z data scale. Read, rather than
% overwrite, its data-aspect ratio to keep the original mountains' shape.
dar = double(get(ax,'DataAspectRatio'));
assert(numel(dar)==3 && all(isfinite(dar)) && all(dar>0), ...
    'Invalid axes DataAspectRatio.');

% One equal-length sphere in *display space* requires XYZ data radii to
% scale with the axes DataAspectRatio. For [1 1 0.55], zRadius=0.55*r.
% This is a DRAWING correction only. The true hazard is still a sphere of
% radius ob.radius_m (metres), unaffected by how the terrain is displayed.
viewScale = dar / dar(1);

% Orthographic projection avoids perspective turning the appearance of a
% sphere into a view-dependent silhouette. It does not change camera angle.
set(ax,'Projection','orthographic');

needsInit = (nargin<4 || isempty(handles) || ~isstruct(handles) || ...
    ~isfield(handles,'sphere') || numel(handles.sphere)~=numel(obstacles));
if ~needsInit
    needsInit = any(~cellfun(@(h)isgraphics(h,'surface'), handles.sphere));
end

if needsInit
    handles=struct('sphere',{{}},'trail',{{}},'start',{{}}, ...
        'finish',{{}},'center',{{}},'tag',{{}});
    palette = [0.69 0.19 0.77; ...
               0.20 0.54 0.83; ...
               0.98 0.53 0.11];
    hold(ax,'on');
    for k=1:numel(obstacles)
        c=palette(mod(k-1,size(palette,1))+1,:);
        handles.trail{k}=plot3(ax,NaN,NaN,NaN,'--', ...
            'Color',c,'LineWidth',1.8,'HandleVisibility','off');
        handles.start{k}=plot3(ax,NaN,NaN,NaN,'o', ...
            'Color',c,'MarkerSize',5,'MarkerFaceColor',c, ...
            'HandleVisibility','off');
        handles.finish{k}=plot3(ax,NaN,NaN,NaN,'s', ...
            'Color',c,'MarkerSize',5,'MarkerFaceColor',c, ...
            'HandleVisibility','off');
        handles.sphere{k}=surf(ax,sx,sy,sz, ...
            'FaceColor',faceColor,'EdgeColor',edgeColor, ...
            'FaceAlpha',1,'EdgeAlpha',1,'LineWidth',0.32, ...
            'FaceLighting','none','HandleVisibility','off');
        handles.center{k}=scatter3(ax,NaN,NaN,NaN,16,c,'filled', ...
            'HandleVisibility','off');
        handles.tag{k}=text(ax,NaN,NaN,NaN,sprintf('D%d',k), ...
            'Color',c,'FontSize',10,'FontWeight','bold', ...
            'HorizontalAlignment','center','HandleVisibility','off');
    end
end

for k=1:numel(obstacles)
    ob=obstacles(k);
    centerKm=mmra_dynamic_obstacle_position(ob,t_s)/1000;
    q=ob.position_m/1000;
    rKm=visualScale*ob.radius_m/1000;
    rx=rKm*viewScale(1);
    ry=rKm*viewScale(2);
    rz=rKm*viewScale(3);

    set(handles.trail{k},'XData',q(:,1),'YData',q(:,2), ...
        'ZData',q(:,3));
    set(handles.start{k},'XData',q(1,1),'YData',q(1,2), ...
        'ZData',q(1,3));
    set(handles.finish{k},'XData',q(end,1),'YData',q(end,2), ...
        'ZData',q(end,3));
    set(handles.center{k},'XData',centerKm(1), ...
        'YData',centerKm(2),'ZData',centerKm(3));
    set(handles.tag{k},'Position', ...
        [centerKm(1),centerKm(2),centerKm(3)+rz+0.035]);
    set(handles.sphere{k}, ...
        'XData',centerKm(1)+rx*sx, ...
        'YData',centerKm(2)+ry*sy, ...
        'ZData',centerKm(3)+rz*sz, ...
        'FaceColor',faceColor,'EdgeColor',edgeColor, ...
        'FaceAlpha',1,'EdgeAlpha',1,'LineWidth',0.32, ...
        'FaceLighting','none');
end
end
