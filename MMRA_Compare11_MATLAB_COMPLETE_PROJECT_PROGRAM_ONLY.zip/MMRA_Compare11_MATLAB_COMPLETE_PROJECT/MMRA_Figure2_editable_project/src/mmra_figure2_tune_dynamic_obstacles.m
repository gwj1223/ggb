function [tuned,report]=mmra_figure2_tune_dynamic_obstacles(obstacles,env)
%MMRA_FIGURE2_TUNE_DYNAMIC_OBSTACLES Lower and enlarge when physically safe.
% Does NOT alter XY coordinates or movement times, and does NOT save files.
% Radius and altitude are genuine collision geometry, not a visual scale.
% If enlargement AND lowering cannot be achieved on a track, preserve it.
% The validator protects terrain, static NFZ, map bounds and mission ends.
obstacles=mmra_dynamic_obstacles_prepare(obstacles);
mmra_figure2_validate_dynamic_obstacles(obstacles,env,true);
tuned=obstacles;
N=numel(obstacles);
report.changed=false(1,N);
report.oldRadius_m=[obstacles.radius_m];
report.newRadius_m=report.oldRadius_m;
report.drop_m=zeros(1,N);
report.note=repmat({''},1,N);
report.changedCount=0;
targetRadius=[160 150 150];
dropOptions=[120 100 80 60 40 20 10];
for k=1:N
    base=obstacles(k);
    target=min(200,max(targetRadius(min(k,numel(targetRadius))), ...
        ceil((base.radius_m+20)/10)*10));
    % Prefer a clearly larger radius, then the largest safe lowering.
    radii=target:-10:(base.radius_m+9);
    if isempty(radii)
        report.note{k}='Already at radius limit; use sliders.';
        continue;
    end
    success=false;
    for radius=radii
        for drop=dropOptions
            candidate=tuned;
            candidate(k).radius_m=radius;
            candidate(k).position_m(:,3)=base.position_m(:,3)-drop;
            try
                mmra_figure2_validate_dynamic_obstacles( ...
                    candidate,env,true);
                tuned=candidate;
                report.changed(k)=true;
                report.newRadius_m(k)=radius;
                report.drop_m(k)=drop;
                report.note{k}='Validated, pending SAVE DYNAMIC';
                success=true;
                break;
            catch
                % Try less enlargement or less lowering.
            end
        end
        if success,break;end
    end
    if ~success
        report.note{k}=['No safe lower+larger combination at the current ' ...
            'XY route. Move it to a lower open area first.'];
    end
end
report.changedCount=sum(report.changed);
tuned=mmra_dynamic_obstacles_prepare(tuned);
mmra_figure2_validate_dynamic_obstacles(tuned,env,true);
end
