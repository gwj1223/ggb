function env=mmra_figure2_add_static_obstacles(env,settingsFile)
%MMRA_FIGURE2_ADD_STATIC_OBSTACLES OPT-IN, editable Figure 2 NFZ only.
% This routine NEVER edits Figure2_user_settings.mat or the terrain oracle.
% Use this SAME env for both plotting and path planning; the old default
% mmra_defaults(...) remains unchanged for reproducible prior studies.
assert(strcmp(env.profile,'mountain_cluster_figure2_custom_5km'), ...
    'Static obstacle overlay is reserved for the saved custom Figure 2.');
assert(isequal(env.boundsHi,[5000 5000 2000]));
% Three editable finite-height cylinders [cx cy radius zmin zmax] [m].
% The defaults avoid the existing cross_center endpoints (U=20, seed=24001).
env.noFlyCylinders=mmra_figure2_nfz_defaults();
env.noFlyBuffer_m=35;            % hard radial exclusion margin [m]
env.noFlyRiskBand_m=180;        % soft external penalty region [m]
% NFZ settings are separate from the user's terrain-only settings.
% Optional settingsFile is for isolated round-trip tests (no live writes).
if nargin<2 || isempty(settingsFile)
    root=fileparts(fileparts(mfilename('fullpath')));
    settingsFile=fullfile(root,'results_main_map', ...
        'Figure2_static_obstacles_settings.mat');
end
nfzRevision='default_v1';
if isfile(settingsFile)
    s=load(settingsFile,'noFlyParams');
    assert(isfield(s,'noFlyParams') && isstruct(s.noFlyParams) && ...
           isfield(s.noFlyParams,'cylinders'), ...
           'Invalid saved NFZ file: expected noFlyParams.cylinders.');
    env.noFlyCylinders=s.noFlyParams.cylinders;
    if isfield(s.noFlyParams,'revision') && ...
            ~isempty(s.noFlyParams.revision)
        nfzRevision=char(s.noFlyParams.revision);
    else
        nfzRevision='saved_unknown';
    end
end
% No box-shaped buildings in the current Figure 2 environment.
% Keep an EMPTY N-by-6 array so rendering, point/segment collision checks,
% RRT* and risk density all skip the old gray buildings. The editable red
% cylindrical NFZs remain unchanged and fully enforced.
env.staticBoxes=zeros(0,6);
env.staticBoxBuffer_m=20;        % retained for schema compatibility
env.staticBoxRiskBand_m=150;    % ignored because staticBoxes is empty
% A distinct revision invalidates cached routes planned with gray boxes.
env.staticObstaclesRevision=['figure2_nfz_only_' nfzRevision];
mmra_figure2_validate_nfz(env,false);
% Validate geometry configuration without silently relocating obstacles.
assert(all(isfinite(env.noFlyCylinders(:))));
assert(all(env.noFlyCylinders(:,3)>0) && ...
       all(env.noFlyCylinders(:,4)<env.noFlyCylinders(:,5)));
assert(isequal(size(env.staticBoxes),[0 6]), ...
    'No rectangular obstacles should remain in this scene.');
end
