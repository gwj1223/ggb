function out=mmra_schedule_conflict_graph_coordination(paths,opt)
%MMRA_SCHEDULE_CONFLICT_GRAPH_COORDINATION Offline multi-UAV coordination.
% Stage 2 (DEVELOPMENT), no moving-obstacle replanning and no online repair.
% 1) Keep the unmodified fixed-stagger speed-feedback result as baseline.
% 2) Build an undirected spatial conflict graph from the fixed 3D routes.
% 3) Try deterministic globally consistent crossing-priority orders and
%    uniform/nonuniform launch-time proposals. The directed priority from
%    each total order has no STATIC cycles; dynamic convoy priority can
%    still change and completion/deadlock freedom is NOT guaranteed.
% 4) Execute each proposal with the original predictive speed scheduler;
%    accept ONLY complete independently verified safe traces.
% 5) Select the minimum completion-time + waiting penalty among feasible
%    proposals, never worse under that metric than a feasible baseline.
%
% Important: each trial is a whole-mission OFFLINE rerun. This is NOT a
% real-time or flight-dynamics-certified controller. Existing static paths,
% map, dynamic obstacle model and speed safety supervisor are unchanged.
%
% opt.coordinationMaxTrials       default 12, includes the baseline
% opt.coordinationGraphExtra_m    default 25 m beyond dSafe+speed guard
% opt.coordinationHeadway_s       default 2 s, predicted crossing spacing
% opt.coordinationMinLaunchGap_s  default 0, may co-launch distant routes
% opt.coordinationYieldPenalty    default 0.15 (s/s of yield ticks)
% opt.coordinationShieldPenalty_s default 0.1 (s per shield action)
% opt.coordinationImprovement_s   default 0.05 s (tie preference: baseline)
% opt.coordinationMaxLaunchTime_s optional explicit bound
% opt.coordinationOverridePresetTimes=false: fixed custom per-UAV release
% times are respected; with those, only the baseline is evaluated.
clock=tic;
U=numel(paths);
assert(U>=1,'At least one path is required.');
maxTrials=localVal(opt,'coordinationMaxTrials',12);
assert(isscalar(maxTrials) && isfinite(maxTrials) && ...
    maxTrials==floor(maxTrials) && maxTrials>=1);
minGap=localVal(opt,'coordinationMinLaunchGap_s',0);
headway=localVal(opt,'coordinationHeadway_s',2);
improvement=localVal(opt,'coordinationImprovement_s',0.05);
assert(all(isfinite([minGap headway improvement])) && ...
    minGap>=0 && headway>0 && improvement>=0);
baseInterval=localVal(opt,'speedFeedbackLaunchInterval_s',0);
assert(isfinite(baseInterval) && baseInterval>=0);
base=mmra_schedule_speed_feedback(paths,opt);
% Keep input errors as errors, not as an unvalidated success/fallback.
graph=mmra_coordination_conflict_graph(paths,opt);
L=graph.pathLengths_m;
if ~isempty(base.priorityOrder)
    basePriority=base.priorityOrder(:)';
else
    [~,idx]=sortrows([-L(:),(1:U)'],[1 2]);
    basePriority=idx(:)';
end
if isfield(opt,'speedFeedbackLaunchOrder') && ...
        ~isempty(opt.speedFeedbackLaunchOrder)
    baseLaunch=opt.speedFeedbackLaunchOrder(:)';
else
    baseLaunch=basePriority;
end
baselineTimes=base.plannedLaunchTimes_s(:);
if numel(baselineTimes)~=U
    baselineTimes=zeros(U,1);
    baselineTimes(baseLaunch)=baseInterval*(0:U-1);
end
report=localSummary(base,'baseline',basePriority,baselineTimes,opt);
visited={struct('order',basePriority,'launchTimes_s',baselineTimes)};
best=base;bestIndex=0;
if report(1).feasible,bestIndex=1;end
bestScore=report(1).score;
lockedTimes=isfield(opt,'speedFeedbackLaunchTimes_s') && ...
    ~isempty(opt.speedFeedbackLaunchTimes_s) && ...
    ~logical(localVal(opt,'coordinationOverridePresetTimes',0));
if ~lockedTimes && maxTrials>1
    rankList=localOrders(graph,baseLaunch);
    % If custom priority is specified, honor it (only launch-order search).
    fixedPriority=isfield(opt,'speedFeedbackPriorityOrder') && ...
        ~isempty(opt.speedFeedbackPriorityOrder);
    if fixedPriority
        assert(isequal(sort(opt.speedFeedbackPriorityOrder(:)'),1:U));
    end
    maxTime=localVal(opt,'speedFeedbackMaxTime_s',180);
    maxLaunch=localVal(opt,'coordinationMaxLaunchTime_s',maxTime);
    assert(isfinite(maxLaunch) && maxLaunch>=0);
    for k=1:numel(rankList)
        order=rankList{k};
        if fixedPriority
            priority=opt.speedFeedbackPriorityOrder(:)';
        else
            priority=order;
        end
        for variant=1:3
            if numel(report)>=maxTrials,break;end
            if variant==1
                policy='graph_window';
                tau=localWindows(order,graph,minGap,headway);
            elseif variant==2
                policy='uniform_stagger';
                tau=localUniform(order,U,baseInterval);
            else
                policy='expanded_stagger';
                tau=localUniform(order,U,max(baseInterval*1.6,headway));
            end
            if max(tau)>maxLaunch+1e-8
                continue;
            end
            if localDuplicate(visited,priority,tau)
                continue;
            end
            visited{end+1}=struct('order',priority,'launchTimes_s',tau); %#ok<AGROW>
            candidateOpt=opt;
            candidateOpt.speedFeedbackLaunchOrder=order;
            candidateOpt.speedFeedbackPriorityOrder=priority;
            candidateOpt.speedFeedbackLaunchTimes_s=tau;
            trial=mmra_schedule_speed_feedback(paths,candidateOpt);
            entry=localSummary(trial,policy,priority,tau,opt);
            report(end+1,1)=entry; %#ok<AGROW>
            if entry.feasible && entry.score<bestScore-improvement-1e-9
                bestScore=entry.score;
                best=trial;
                bestIndex=numel(report);
            end
        end
        if numel(report)>=maxTrials,break;end
    end
end
out=best;
out.mode='conflict_graph_coordination_speed_feedback';
meta=struct();
meta.algorithm='offline_conflict_graph_priority_launch_search_v1';
meta.graph=graph;
meta.trials=report;
meta.numTrials=numel(report);
meta.numFeasible=sum([report.feasible]);
meta.numStalled=sum(strcmp({report.reason},'all_aircraft_stalled'));
meta.baselineFeasible=report(1).feasible;
meta.baselineScore=report(1).score;
meta.baselineMakespan_s=report(1).makespan_s;
meta.selectedTrial=bestIndex;
meta.selectedScore=bestScore;
if bestIndex>0
    meta.selectedPolicy=report(bestIndex).policy;
    meta.selectedPriorityOrder=report(bestIndex).priorityOrder;
    meta.selectedLaunchTimes_s=report(bestIndex).launchTimes_s;
    meta.selectedSchedulerWall_s=report(bestIndex).schedulerWall_s;
else
    meta.selectedPolicy='no_valid_complete_candidate';
    meta.selectedPriorityOrder=[];
    meta.selectedLaunchTimes_s=[];
    meta.selectedSchedulerWall_s=NaN;
end
meta.fixedPresetTimes=lockedTimes;
meta.offlineOnly=true;
meta.noDeadlockFreedomGuarantee=true;
meta.totalSearchWall_s=toc(clock);
out.coordination=meta;
out.schedule_s=meta.totalSearchWall_s;
% No feasible trace? Propagate a genuine failure, never fabricate success.
if bestIndex==0
    out.success=false;
    out.reason=['coordination_no_verified_complete_schedule__' base.reason];
end
end

function rankList=localOrders(g,base)
U=numel(base);idx=(1:U)';
[~,a]=sortrows([-g.weightedDegree(:),-g.pathLengths_m(:),idx],[1 2 3]);
[~,b]=sortrows([g.weightedDegree(:),-g.pathLengths_m(:),idx],[1 2 3]);
first=inf(U,1);
for i=1:U
    neighbors=find(g.edge(i,:));
    if ~isempty(neighbors)
        first(i)=min(g.arcAtApproach_m(i,neighbors))/g.speedCaps_mps(i);
    end
end
[~,c]=sortrows([first,-g.weightedDegree(:),idx],[1 2 3]);
list={base(:)',idx(a)',idx(b)',idx(c)',fliplr(base(:)')};
rankList={};
for k=1:numel(list)
    found=false;
    for j=1:numel(rankList)
        if isequal(list{k},rankList{j}),found=true;break;end
    end
    if ~found,rankList{end+1}=list{k};end %#ok<AGROW>
end
end

function tau=localUniform(order,U,interval)
tau=zeros(U,1);
tau(order)=interval*(0:U-1);
end

function tau=localWindows(order,g,minGap,headway)
U=numel(order);tau=zeros(U,1);
for k=2:U
    j=order(k);
    tau(j)=tau(order(k-1))+minGap;
    for a=1:k-1
        i=order(a);
        if ~g.edge(i,j),continue;end
        encounterI=g.arcAtApproach_m(i,j)/g.speedCaps_mps(i);
        encounterJ=g.arcAtApproach_m(j,i)/g.speedCaps_mps(j);
        % i's nominal passage precedes j's by at least `headway`.
        tau(j)=max(tau(j),tau(i)+encounterI-encounterJ+headway);
    end
end
end

function tf=localDuplicate(visited,order,tau)
tf=false;
for k=1:numel(visited)
    if isequal(visited{k}.order,order) && ...
            numel(tau)==numel(visited{k}.launchTimes_s) && ...
            all(abs(visited{k}.launchTimes_s(:)-tau(:))<=1e-9)
        tf=true;return;
    end
end
end

function trial=localSummary(result,policy,priority,tau,opt)
feasible=result.success && isfield(result.validation,'safe') && ...
    isfield(result.validation,'complete') && ...
    result.validation.safe && result.validation.complete;
penaltyYield=localVal(opt,'coordinationYieldPenalty',0.15);
penaltyShield=localVal(opt,'coordinationShieldPenalty_s',0.1);
assert(all(isfinite([penaltyYield penaltyShield])) && ...
    penaltyYield>=0 && penaltyShield>=0);
if feasible
    dt=result.trace.dt_s;
    score=result.makespan + penaltyYield*result.yieldSteps*dt + ...
        penaltyShield*result.shieldAdjustments;
else
    score=inf;
end
trial=struct('policy',policy,'priorityOrder',priority, ...
    'launchTimes_s',tau(:),'feasible',feasible, ...
    'success',result.success,'reason',result.reason, ...
    'score',score,'makespan_s',result.makespan, ...
    'minSeparation_m',result.minSeparation, ...
    'yieldSteps',result.yieldSteps, ...
    'shieldAdjustments',result.shieldAdjustments, ...
    'schedulerWall_s',result.schedule_s);
end

function v=localVal(opt,key,defaultValue)
if isfield(opt,key) && ~isempty(opt.(key))
    v=double(opt.(key));
else
    v=defaultValue;
end
assert(isscalar(v) && isnumeric(v),'%s must be numeric scalar.',key);
end
