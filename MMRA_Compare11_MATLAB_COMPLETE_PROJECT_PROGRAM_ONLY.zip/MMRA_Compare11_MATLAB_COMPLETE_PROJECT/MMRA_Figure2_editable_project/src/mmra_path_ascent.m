function ascent_m = mmra_path_ascent(path)
%MMRA_PATH_ASCENT Cumulative positive altitude increments (metres).
% This is an energy proxy, NOT a validated aircraft energy model.
ascent_m=NaN;
if isempty(path) || size(path,2)~=3 || size(path,1)<2
    return;
end
assert(all(isfinite(path(:))), 'Path must be finite');
ascent_m=sum(max(0,diff(path(:,3))));
end
