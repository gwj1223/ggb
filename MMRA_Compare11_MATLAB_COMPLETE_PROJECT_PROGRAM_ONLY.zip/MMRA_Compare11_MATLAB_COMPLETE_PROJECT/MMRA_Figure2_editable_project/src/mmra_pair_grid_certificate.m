function [allUnsafe,safeDelta,checks] = mmra_pair_grid_certificate(pathA,pathB,opt)
%MMRA_PAIR_GRID_CERTIFICATE Oracle check over ALL allowed relative delays.
% Returns true only if every delta in -K:K causes a conflict according to
% the original continuous-time mmra_pair_minsep, for HOLD/HOLD as supplied.
% Proof is for the 0.25-s delay GRID, NOT real-valued departure times.
K=round(opt.maxDelay/opt.delayStep);
assert(abs(K*opt.delayStep-opt.maxDelay)<1e-8);
allUnsafe=true;safeDelta=NaN;checks=0;
for k=-K:K
    delta=k*opt.delayStep;
    da=max(0,-delta);db=max(0,delta);
    [~,~,conflict]=mmra_pair_minsep(pathA,pathB,da,db,opt);
    checks=checks+1;
    if ~conflict
        allUnsafe=false;safeDelta=delta;return;
    end
end
end
