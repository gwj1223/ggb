function [best, chosenPaths, report] = mmra_hybrid_dynamic_obstacle_schedule(paths, env, cfg, opt)
%MMRA_HYBRID_DYNAMIC_OBSTACLE_SCHEDULE Development-stage hybrid planner.
% Offline / pre-flight prototype only. Given known future obstacle tracks,
% compare the existing speed-only avoidance controller with validated local
% geometry detours (doglegs and optional local RRT*). ALL aircraft are
% rescheduled after each geometry candidate; no original path is overwritten.
% This does not perform mid-flight replanning or guarantee physical safety.
% Call: [schedule, pathsUsed, diagnosis] =
%       mmra_hybrid_dynamic_obstacle_schedule(paths,env,cfg,opt);
%
% Optional controls: hybridWaitTrigger_s (default 5),
% hybridMaxCandidates (default 12), hybridMaxLengthRatio (default 1.20),
% hybridExtraLengthWeight (default .25), hybridTryLocalRRT (default true).
% A candidate is chosen ONLY if the existing independent UAV-UAV and
% UAV-moving-obstacle verifiers certify a COMPLETE trace for the given model.

clock=tic;
assert(iscell(paths) && ~isempty(paths), 'paths must be a nonempty cell array');
assert(isfield(opt,'speedFeedbackDynamicObstacles') && ...
    ~isempty(opt.speedFeedbackDynamicObstacles), ...
    'Provide known/predicted moving obstacles in opt.speedFeedbackDynamicObstacles.');
obstacles=mmra_dynamic_obstacles_prepare(opt.speedFeedbackDynamicObstacles);
waitTrigger=localOption(opt,'hybridWaitTrigger_s',5);
maxCandidates=localOption(opt,'hybridMaxCandidates',12);
maxLengthRatio=localOption(opt,'hybridMaxLengthRatio',1.20);
lengthWeight=localOption(opt,'hybridExtraLengthWeight',.25);
tryLocalRRT=logical(localOption(opt,'hybridTryLocalRRT',true));
assert(waitTrigger>=0 && maxCandidates>=1 && maxCandidates==floor(maxCandidates) && ...
    maxLengthRatio>=1 && lengthWeight>=0, 'Invalid hybrid parameters');

% Keep both baseline scenarios and their failures in the report. The
% obstacle-free nominal trace is ONLY for identifying would-be conflicts.
noObs=opt;
noObs=rmfield(noObs,'speedFeedbackDynamicObstacles');
nominal=mmra_schedule_speed_feedback(paths,noObs);
speedOnly=mmra_schedule_speed_feedback(paths,opt);
best=speedOnly;
chosenPaths=paths;
report=struct('mode','hybrid_speed_or_local_detour_offline', ...
    'strategy','speed_only','nominalCompleted',nominal.success, ...
    'speedOnlyCompleted',speedOnly.success,'speedOnlyReason',speedOnly.reason, ...
    'originalNominalObstacleClearance_m',NaN, ...
    'detoursProposed',0,'detoursTerrainValid',0,'detoursSimulated',0, ...
    'detoursCompleted',0,'selectedUAV',NaN,'selectedObstacle',NaN, ...
    'selectedExtraLength_m',0,'selectedScore_s',Inf, ...
    'speedOnlyMakespan_s',speedOnly.makespan, ...
    'nominalMakespan_s',nominal.makespan, ...
    'chosenMinObstacleClearance_m',NaN,'chosenMinUAVSeparation_m',NaN, ...
    'elapsedWall_s',NaN,'note','Pre-flight prototype: no mid-flight replanning');

if speedOnly.success
    report.selectedScore_s=speedOnly.makespan;
end
if ~nominal.success
    report.note='Nominal schedule did not complete: cannot locate a nominal obstacle conflict.';
    report=localFinish(report,best,clock);
    return;
end
if strcmp(speedOnly.reason,'unsafe_initial_dynamic_obstacle_overlap')
    report.note='Unsafe starting state: rerouting cannot repair an initially overlapping held start.';
    report=localFinish(report,best,clock);
    return;
end
originalAudit=mmra_verify_dynamic_obstacles(paths,nominal.trace,opt,obstacles);
report.originalNominalObstacleClearance_m=originalAudit.minClearance_m;
if originalAudit.safe
    report.note='No dynamic obstacle conflict on the nominal trace: no local detour triggered.';
    report=localFinish(report,best,clock);
    return;
end
if speedOnly.success && speedOnly.makespan-nominal.makespan<=waitTrigger
    report.note='A safe speed-only schedule exists within the waiting-time trigger.';
    report=localFinish(report,best,clock);
    return;
end

% Pick the modeled UAV/obstacle pair with lowest nominal clearance.
i=originalAudit.closestUAV;
m=originalAudit.closestObstacle;
if ~isfinite(i) || ~isfinite(m) || i<1 || m<1
    report.note='Could not identify a violating UAV/obstacle pair.';
    report=localFinish(report,best,clock);
    return;
end
report.selectedUAV=i;
report.selectedObstacle=m;
ob=obstacles(m);
trace=nominal.trace;
xyz=squeeze(trace.position_m(:,:,i));
centers=mmra_dynamic_obstacle_position(ob,trace.time_s);
req=ob.radius_m+localOption(opt,'speedFeedbackDroneRadius_m',1) + ...
    localOption(opt,'speedFeedbackObstacleGuard_m',2);
[~,k]=min(sqrt(sum((xyz-centers).^2,2)));
blockCenter=centers(k,:);

% Reuse the previously tested fixed-endpoint dogleg generator, but set
% spatial scales from the moving obstacle's PROTECTED effective radius.
proposalOpt=opt;
proposalOpt.dSafe=max(opt.dSafe,req+2);
proposalOpt.spatialRepairSpan_m=[max(80,4*req),max(140,7*req)];
proposalOpt.spatialRepairOffset_m=[max(45,2*req),max(75,3.5*req)];
proposalOpt.spatialRepairLift_m=[0 35];
[candidates,~]=mmra_spatial_detour_candidates( ...
    paths{i},blockCenter,env,proposalOpt);
report.detoursProposed=numel(candidates);
oldLen=mmra_path_length(paths{i});
if isfield(cfg,'guardFineResolution') && cfg.guardFineResolution>0
    checkStep=cfg.guardFineResolution;
elseif isfield(cfg,'edgeResolution') && cfg.edgeResolution>0
    checkStep=cfg.edgeResolution;
else
    checkStep=2;
end

% Evaluate geometry candidates on the ORIGINAL 3D map and the ORIGINAL
% dynamic obstacle trajectories, then independently verify full traces.
for j=1:numel(candidates)
    if report.detoursSimulated>=maxCandidates,break;end
    candidate=candidates{j};
    [best,chosenPaths,report]=localTryCandidate(candidate,i,paths,env, ...
        checkStep,oldLen,maxLengthRatio,lengthWeight,opt,best,chosenPaths,report);
end

% Optional TRUE local RRT* attempt, with a conservative TEMPORARY spatial
% exclusion cylinder near the predicted obstruction. The cylinder is only
% used to propose geometry; final approval uses true time-varying tracks.
if tryLocalRRT && report.detoursCompleted==0 && ...
        report.detoursSimulated<maxCandidates
    proposed=mmra_dynamic_local_rrt_detour( ...
        paths{i},blockCenter,req,env,cfg);
    report.detoursProposed=report.detoursProposed+numel(proposed);
    for j=1:numel(proposed)
        if report.detoursSimulated>=maxCandidates,break;end
        [best,chosenPaths,report]=localTryCandidate(proposed{j},i,paths,env, ...
            checkStep,oldLen,maxLengthRatio,lengthWeight,opt, ...
            best,chosenPaths,report);
    end
end
report=localFinish(report,best,clock);
end

function [best,chosenPaths,report]=localTryCandidate(candidate,i,paths,env, ...
    resolution,oldLen,lengthRatio,weight,opt,best,chosenPaths,report)
if isempty(candidate) || size(candidate,2)~=3 || size(candidate,1)<2
    return;
end
if norm(candidate(1,:)-paths{i}(1,:))>1e-7 || ...
        norm(candidate(end,:)-paths{i}(end,:))>1e-7
    return;
end
newLen=mmra_path_length(candidate);
if newLen>oldLen*lengthRatio+1e-8 || ...
        ~mmra_path_free(candidate,env,resolution)
    return;
end
report.detoursTerrainValid=report.detoursTerrainValid+1;
trialPaths=paths;
trialPaths{i}=candidate;
trial=mmra_schedule_speed_feedback(trialPaths,opt);
report.detoursSimulated=report.detoursSimulated+1;
if ~trial.success || ~isfield(trial.validation,'dynamicObstacles') || ...
        ~trial.validation.safe || ~trial.validation.complete || ...
        ~trial.validation.dynamicObstacles.safe || ...
        trial.obstacleMinClearance_m < -opt.tol || ...
        trial.minSeparation < opt.dSafe-opt.tol
    return;
end
report.detoursCompleted=report.detoursCompleted+1;
extraLength=max(0,newLen-oldLen);
score=trial.makespan+weight*extraLength/opt.speed;
if score+1e-7<report.selectedScore_s
    best=trial;
    chosenPaths=trialPaths;
    report.selectedScore_s=score;
    report.selectedExtraLength_m=newLen-oldLen;
    report.strategy='local_detour_then_speed_feedback';
end
end

function report=localFinish(report,best,clock)
report.elapsedWall_s=toc(clock);
report.chosenMinUAVSeparation_m=best.minSeparation;
if isfield(best,'obstacleMinClearance_m')
    report.chosenMinObstacleClearance_m=best.obstacleMinClearance_m;
end
end

function v=localOption(s,name,defaultValue)
if isfield(s,name) && ~isempty(s.(name))
    v=s.(name);
else
    v=defaultValue;
end
assert(isnumeric(v) || islogical(v), 'Expected numeric hybrid parameter');
assert(isscalar(v) && isfinite(double(v)), 'Expected finite scalar hybrid parameter');
end
