function out = mmra_schedule_speed_feedback(paths,opt)
%MMRA_SCHEDULE_SPEED_FEEDBACK Predictive, priority-aware speed coordination.
%
% Receding-horizon heuristic: aircraft follow FIXED RRT* polylines. A UAV
% that is ahead on a shared corridor keeps priority; for crossing routes,
% a deterministic order breaks ties. The yielding UAV rate-limits its
% speed toward zero, then resumes cruise after the predicted conflict
% clears. Every EXECUTED control interval is shielded using exact
% continuous-time separation of its piecewise-linear motion. No unsafe
% step is accepted; a failed schedule may have an independently safe
% partial trace. No completeness or physical tracking guarantee is made.
%
% Dynamics: arc distance is LINEAR during each dt; speed command can
% change at control ticks, with bounded change per tick. This is a
% sampled speed-setpoint model, NOT a continuous-acceleration model.
% Optional predicted moving SPHERICAL obstacles are handled by the
% same speed-command shield (no spatial route change). Dynamic obstacle
% specification: opt.speedFeedbackDynamicObstacles, a struct array with
% time_s, position_m, radius_m. Exact modeled clearance is independently
% checked until at least the last obstacle trajectory knot. If speed-only
% avoidance is infeasible, return failure; NEVER mask a collision.
% Only hold/hold occupancy (used in the v2.1 20-UAV study) is supported.
%
% New opt fields (all optional):
% speedFeedbackDt_s=0.20, speedFeedbackAccel_mps2=3,
% speedFeedbackDecel_mps2=6, speedFeedbackHorizon_s=8,
% speedFeedbackPredictionStep_s=0.4, speedFeedbackGuard_m=1.0,
% speedFeedbackRelease_m=2.0, speedFeedbackMaxTime_s=180,
% speedFeedbackMaxStall_s=15, speedFeedbackSpeedCaps_mps=opt.speed,
% speedFeedbackPriorityOrder=[] (default longest-first crossing tie),
% speedFeedbackMaxShieldIterations=80; optionally
% speedFeedbackLaunchInterval_s=0 and speedFeedbackLaunchOrder=[].
clock=tic;
U=numel(paths);
out=struct('success',false,'reason','not_started', ...
    'mode','speed_feedback','schedule_s',NaN,'makespan',NaN, ...
    'minSeparation',NaN,'postConflicts',NaN,'preConflicts',NaN, ...
    'dSafe',opt.dSafe,'delays',zeros(U,1),'priorityOrder',[], ...
    'completedUAVs',0,'yieldSteps',0,'shieldAdjustments',0, ...
    'priorityPolicy','static','dynamicPriorityDecisions',0, ...
    'priorityFairnessSelections',0, ...
    'completionTimes_s',NaN(U,1), ...
    'plannedLaunchTimes_s',zeros(U,1), ...
    'actualLaunchTimes_s',NaN(U,1), ...
    'paths',{paths},'trace',struct(), ...
    'obstacleYieldSteps',0,'obstacleShieldAdjustments',0, ...
    'obstacleMinClearance_m',NaN,'obstaclePostConflicts',NaN, ...
    'validation',struct());
assert(U>0,'At least one path is required.');
assert(opt.speed>0 && opt.dSafe>0 && opt.tol>=0, ...
    'Invalid cruise speed or separation requirement.');
assert(strcmpi(opt.startPolicy,'hold') && strcmpi(opt.endPolicy,'hold'), ...
    'Speed feedback supports HOLD/HOLD only (inactive not modeled).');
dt=localOpt(opt,'speedFeedbackDt_s',0.2);
aUp=localOpt(opt,'speedFeedbackAccel_mps2',3);
aDown=localOpt(opt,'speedFeedbackDecel_mps2',6);
H=localOpt(opt,'speedFeedbackHorizon_s',8);
predDt=localOpt(opt,'speedFeedbackPredictionStep_s',0.4);
guard=localOpt(opt,'speedFeedbackGuard_m',1.0);
release=localOpt(opt,'speedFeedbackRelease_m',2.0);
maxTime=localOpt(opt,'speedFeedbackMaxTime_s',180);
maxStall=localOpt(opt,'speedFeedbackMaxStall_s',15);
maxShield=localOpt(opt,'speedFeedbackMaxShieldIterations',max(40,4*U));
% NEW OPTIONAL moving-obstacle extension. Old v2.2/v2.3 runs without
% speedFeedbackDynamicObstacles execute the same UAV-to-UAV controller.
if isfield(opt,'speedFeedbackDynamicObstacles') && ...
        ~isempty(opt.speedFeedbackDynamicObstacles)
    obstacles=mmra_dynamic_obstacles_prepare(opt.speedFeedbackDynamicObstacles);
else
    obstacles=mmra_dynamic_obstacles_prepare([]);
end
hasObstacles=~isempty(obstacles);
if hasObstacles,out.mode='speed_feedback_moving_obstacles';end
droneRadius=localOpt(opt,'speedFeedbackDroneRadius_m',1);
obGuard=localOpt(opt,'speedFeedbackObstacleGuard_m',2);
assert(droneRadius>=0 && obGuard>=0, ...
    'Dynamic-obstacle geometry margins must be nonnegative.');
if hasObstacles
    obsLastTime=max(arrayfun(@(x)x.time_s(end),obstacles));
    if obsLastTime>maxTime+1e-9
        out.reason='obstacle_prediction_extends_past_max_time';
        out.schedule_s=toc(clock);return;
    end
else
    obsLastTime=-inf;
end
assert(all(isfinite([dt aUp aDown H predDt guard release maxTime maxStall maxShield])));
assert(all([dt aUp aDown H predDt maxTime maxStall maxShield]>0) && ...
    guard>=0 && release>=0,'Invalid feedback configuration.');
assert(maxShield==floor(maxShield));
caps=opt.speed*ones(U,1);
if isfield(opt,'speedFeedbackSpeedCaps_mps') && ...
        ~isempty(opt.speedFeedbackSpeedCaps_mps)
    cc=opt.speedFeedbackSpeedCaps_mps;
    if isscalar(cc),caps(:)=cc;
    else,caps=cc(:);end
end
assert(numel(caps)==U && all(caps>0) && ...
    all(caps<=opt.speed+1e-9) && all(isfinite(caps)), ...
    'Speed caps must be positive and no greater than cruise opt.speed.');
geom=cell(U,1);lens=zeros(U,1);
for i=1:U
    if isempty(paths{i}) || size(paths{i},2)~=3 || size(paths{i},1)<2
        out.reason='missing_path';out.schedule_s=toc(clock);return;
    end
    [pts,cum,L]=mmra_arc(paths{i});
    if L<=1e-9
        out.reason='zero_length_path';out.schedule_s=toc(clock);return;
    end
    geom{i}=struct('points',pts,'cumulative',cum,'length',L);
    lens(i)=L;
end
if isfield(opt,'speedFeedbackPriorityOrder') && ...
        ~isempty(opt.speedFeedbackPriorityOrder)
    order=reshape(opt.speedFeedbackPriorityOrder,1,[]);
    assert(isequal(sort(order),1:U),'Priority must be permutation 1:U.');
else
    [~,order]=sortrows([-lens,(1:U)'],[1 2]);
    order=reshape(order,1,[]);
end
out.priorityOrder=order;
% Static planned release times (not a promise of immediate takeoff).
% Waiting aircraft continue to occupy their start position under HOLD.
launchInterval=localOpt(opt,'speedFeedbackLaunchInterval_s',0);
assert(isfinite(launchInterval) && launchInterval>=0, ...
    'Staggered launch interval must be nonnegative.');
if isfield(opt,'speedFeedbackLaunchOrder') && ...
        ~isempty(opt.speedFeedbackLaunchOrder)
    launchOrder=reshape(opt.speedFeedbackLaunchOrder,1,[]);
    assert(isequal(sort(launchOrder),1:U), ...
        'Launch order must be permutation 1:U.');
else
    launchOrder=order;
end
launchTimes=zeros(U,1);
launchTimes(launchOrder)=launchInterval*(0:U-1);
% Optional nonuniform per-UAV release times for conflict-graph scheduling.
% If omitted, the original uniform stagger and results are unchanged.
if isfield(opt,'speedFeedbackLaunchTimes_s') && ...
        ~isempty(opt.speedFeedbackLaunchTimes_s)
    requested=double(opt.speedFeedbackLaunchTimes_s(:));
    assert(numel(requested)==U && all(isfinite(requested)) && ...
        all(requested>=0), ...
        'speedFeedbackLaunchTimes_s must be a nonnegative U-vector.');
    launchTimes=requested;
end
out.plannedLaunchTimes_s=launchTimes;
out.delays=launchTimes;
rank=zeros(U,1);rank(order)=1:U;
% Opt-in dynamic crossing priority: recompute who gets right of way when
% a NEW crossing hazard is first seen, then hold that pair's assignment
% until it clears.  The default 'static' path is byte-for-byte equivalent
% in control decisions to the preceding fixed-priority implementation.
priorityPolicy='static';
if isfield(opt,'speedFeedbackPriorityPolicy') && ...
        ~isempty(opt.speedFeedbackPriorityPolicy)
    priorityPolicy=lower(char(opt.speedFeedbackPriorityPolicy));
end
assert(any(strcmp(priorityPolicy,{'static','dynamic_eta'})), ...
    'speedFeedbackPriorityPolicy must be static or dynamic_eta.');
out.priorityPolicy=priorityPolicy;
dynamicPriority=strcmp(priorityPolicy,'dynamic_eta');
priorityTie=localOpt(opt,'speedFeedbackPriorityTie_s',0.6);
assert(isfinite(priorityTie) && priorityTie>=0);
if dynamicPriority
    if isfield(opt,'speedFeedbackConflictArc_m') && ...
            ~isempty(opt.speedFeedbackConflictArc_m)
        conflictArc=double(opt.speedFeedbackConflictArc_m);
        assert(isequal(size(conflictArc),[U U]), ...
            'speedFeedbackConflictArc_m must be a U-by-U matrix.');
    else
        priorityGeom=mmra_coordination_conflict_graph(paths,opt);
        conflictArc=priorityGeom.arcAtApproach_m;
    end
else
    conflictArc=[];
end
waitCredit=zeros(U,1);
initial=zeros(U,3);terminal=zeros(U,3);
for i=1:U
    initial(i,:)=geom{i}.points(1,:);
    terminal(i,:)=geom{i}.points(end,:);
end
for i=1:U-1
    for j=i+1:U
        if norm(initial(i,:)-initial(j,:))<opt.dSafe-opt.tol
            out.reason='unsafe_initial_held_positions';
            out.schedule_s=toc(clock);return;
        end
        if norm(terminal(i,:)-terminal(j,:))<opt.dSafe-opt.tol
            out.reason='incompatible_held_terminal_goals';
            out.schedule_s=toc(clock);return;
        end
    end
end
N=ceil(maxTime/dt);
s=zeros(U,1);v=zeros(U,1);time=zeros(N+1,1);
progress=zeros(N+1,U);speed=zeros(N,U);
yieldHistory=false(N,U);obsYieldHistory=false(N,U);
positions=zeros(N+1,3,U);
for i=1:U,positions(1,:,i)=initial(i,:);end
finishTimes=NaN(U,1);
settleStart=NaN;
% A moving obstacle may intersect an occupied UAV starting point.
% Refuse to run from an initially unsafe state.
for m=1:numel(obstacles)
    req=obstacles(m).radius_m+droneRadius+obGuard;
    ob0=mmra_dynamic_obstacle_position(obstacles(m),0);
    for i=1:U
        if norm(initial(i,:)-ob0)<req-opt.tol
            out.reason='unsafe_initial_dynamic_obstacle_overlap';
            out.schedule_s=toc(clock);return;
        end
    end
end
pairLatch=zeros(U,U);  % pairwise yielding hysteresis, reset when clear
steps=0;reason='time_limit';
for k=1:N
    if all(lens-s<=1e-8) && ...
            (~hasObstacles || (k-1)*dt>=obsLastTime-1e-9)
        reason='completed';break;
    end
    t=(k-1)*dt;
    vmax=zeros(U,1);vFloor=zeros(U,1);
    for i=1:U
        [vmax(i),vFloor(i),ok]=localGoalBound( ...
            v(i),lens(i)-s(i),dt,aUp,aDown,caps(i));
        if ~ok
            reason='speed_braking_infeasible';break;
        end
    end
    if ~strcmp(reason,'time_limit'),break;end
    posNow=zeros(U,3);
    for i=1:U,posNow(i,:)=mmra_speed_arc_position(geom{i},s(i));end
    % Forecast all aircraft at nominal acceleration to cruise. A safety
    % threshold enlarged by half the sample interval's maximum relative
    % displacement prevents missing a between-samples close approach.
    future=localForecast(geom,s,v,caps,aUp,H,predDt,t,launchTimes);
    nominalYield=false(U,1);
    for i=1:U-1
        for j=i+1:U
            gap=sqrt(sum((future(:,:,i)-future(:,:,j)).^2,2));
            dFuture=min(gap);
            dCurrent=norm(posNow(i,:)-posNow(j,:));
            threshold=opt.dSafe+guard+0.5*(caps(i)+caps(j))*predDt;
            % A close, perfectly parallel convoy is allowed when its
            % clearance is not SHRINKING (no pointless braking).
            closing=dFuture<dCurrent-0.10 || dFuture<opt.dSafe+0.5;
            hazard=closing && dFuture<threshold;
            if hazard
                if dynamicPriority
                    if pairLatch(i,j)>0
                        % An active conflict keeps its established right
                        % of way; do not alternate yielders each tick.
                        loser=pairLatch(i,j);
                    else
                        [loser,priorityCause]= ...
                            mmra_coordination_dynamic_yielder(i,j, ...
                            geom,s,posNow,rank,caps,conflictArc, ...
                            waitCredit,priorityTie);
                        out.dynamicPriorityDecisions= ...
                            out.dynamicPriorityDecisions+1;
                        if strcmp(priorityCause,'yield_age')
                            out.priorityFairnessSelections= ...
                                out.priorityFairnessSelections+1;
                        end
                    end
                else
                    loser=localYielder(i,j,geom,s,v,posNow,rank,lens);
                end
                winner=i+j-loser;
                % If the chosen yielder is stationary at its START and
                % the winner would run into that occupied start, let
                % the start owner clear its occupied takeoff point first.
                if s(loser)<1e-8 && v(loser)<1e-8 && ...
                        lens(winner)-s(winner)>1e-8
                    dStationary=sqrt(sum( ...
                        (future(:,:,winner)-posNow(loser,:)).^2,2));
                    if min(dStationary)<opt.dSafe+guard
                        loser=winner;
                    end
                end
                pairLatch(i,j)=loser;
            elseif dFuture>=threshold+release
                pairLatch(i,j)=0; % safe predicted clearance restored
            end
            if pairLatch(i,j)>0
                nominalYield(pairLatch(i,j))=true;
            end
        end
    end
    % Dynamic obstacles are not other UAVs: they keep their prescribed
    % motion. Forecast each center, then ask only the affected UAV to
    % yield. Forecast is a trigger, NOT a safety proof; the shield below
    % handles exact within-tick closest approach.
    obstacleYield=false(U,1);
    if hasObstacles
        forecastTimes=(0:predDt:H)';
        if forecastTimes(end)<H-1e-9,forecastTimes(end+1)=H;end
        for m=1:numel(obstacles)
            ob=obstacles(m);
            center=mmra_dynamic_obstacle_position(ob,t+forecastTimes);
            for i=1:U
                delta=future(:,:,i)-center;
                dFuture=min(sqrt(sum(delta.^2,2)));
                dCurrent=norm(posNow(i,:)- ...
                    mmra_dynamic_obstacle_position(ob,t));
                required=ob.radius_m+droneRadius+obGuard;
                % Conservative sampling expansion (used only as trigger).
                trigger=required+guard+ ...
                    0.5*(caps(i)+ob.maxSpeed_mps)*predDt;
                closing=dFuture<dCurrent-0.10 || ...
                    dFuture<required+guard+0.5;
                if closing && dFuture<trigger
                    obstacleYield(i)=true;
                end
            end
        end
    end
    vCommand=vmax;
    vCommand(nominalYield | obstacleYield)= ...
        vFloor(nominalYield | obstacleYield);
    % A not-yet-released UAV is stationary, but remains collision-active at
    % its held start site. It can never be shield-accelerated before release.
    waitingLaunch=t+1e-9<launchTimes;
    vCommand(waitingLaunch)=0;
    % Exact (within modeled polyline kinematics) one-step safety shield.
    % When a candidate is unsafe, reduce a conflicting aircraft to its
    % fastest dynamically permitted braking action. If no safe action is
    % found, TERMINATE with a failed result; never commit the unsafe step.
    safe=false;numAdjust=0;numObsAdjust=0;unsafeObstacle=false;
    for attempt=1:maxShield
        [badA,badB]=localUnsafePair(geom,s,vCommand,dt,opt.dSafe,opt.tol);
        if badA>0
            % Original UAV-UAV shield; exactly unchanged when no obstacle
            % is present. A previous reduction must be rechecked against
            % all UAV pairs and against all moving obstacles.
            if dynamicPriority && pairLatch(badA,badB)>0
                loser=pairLatch(badA,badB);
            elseif dynamicPriority
                [loser,priorityCause]=mmra_coordination_dynamic_yielder( ...
                    badA,badB,geom,s,posNow,rank,caps,conflictArc, ...
                    waitCredit,priorityTie);
                out.dynamicPriorityDecisions=out.dynamicPriorityDecisions+1;
                if strcmp(priorityCause,'yield_age')
                    out.priorityFairnessSelections= ...
                        out.priorityFairnessSelections+1;
                end
            else
                loser=localYielder(badA,badB,geom,s,v,posNow,rank,lens);
            end
            other=badA+badB-loser;
            candidates=[loser other];
            changed=false;
            for index=1:2
                ii=candidates(index);
                if vCommand(ii)>vFloor(ii)+1e-10
                    vCommand(ii)=vFloor(ii);
                    changed=true;numAdjust=numAdjust+1;
                    break;
                end
            end
            if ~changed,break;end
            continue;
        end
        badObsU=0;
        if hasObstacles
            badObsU=localUnsafeObstacle(geom,s,vCommand,t,dt, ...
                obstacles,droneRadius,obGuard,opt.tol);
        end
        if badObsU==0
            safe=true;break;
        end
        unsafeObstacle=true;
        if vCommand(badObsU)>vFloor(badObsU)+1e-10
            vCommand(badObsU)=vFloor(badObsU);
            numObsAdjust=numObsAdjust+1;
        else
            % Do not move into a moving obstacle when maximum feasible
            % braking cannot secure the NEXT commanded interval.
            break;
        end
    end
    if ~safe
        if unsafeObstacle
            reason='no_safe_dynamic_obstacle_step_under_braking_limits';
        else
            reason='no_safe_speed_step_under_braking_limits';
        end
        break;
    end
    sNext=min(lens,s+dt*vCommand);
    steps=k;time(k+1)=t+dt;
    progress(k+1,:)=sNext';speed(k,:)=vCommand';
    yieldHistory(k,:)=(nominalYield | obstacleYield)';
    obsYieldHistory(k,:)=obstacleYield';
    for i=1:U
        positions(k+1,:,i)=mmra_speed_arc_position(geom{i},sNext(i));
        if isnan(finishTimes(i)) && sNext(i)>=lens(i)-1e-8
            finishTimes(i)=t+dt;
        end
    end
    % Fairness credit accumulates only for already-released aircraft
    % that had to yield; pre-launch waiting is NOT a yielding penalty.
    if dynamicPriority
        waitCredit=waitCredit+dt*double(nominalYield & ~waitingLaunch);
    end
    out.yieldSteps=out.yieldSteps+sum(nominalYield | obstacleYield);
    out.obstacleYieldSteps=out.obstacleYieldSteps+sum(obstacleYield);
    out.shieldAdjustments=out.shieldAdjustments+numAdjust;
    out.obstacleShieldAdjustments=out.obstacleShieldAdjustments+numObsAdjust;
    moved=sum(sNext-s);
    if all(lens-sNext<=1e-8)
        % If every UAV is already at its goal, stationary holding is NOT
        % a deadlock. Continue protecting the occupied goals until the
        % final moving-obstacle waypoint has occurred.
        settleStart=NaN;
    elseif moved<1e-8
        % Do not misdiagnose a deliberately scheduled gap as deadlock.
        % Once all pending launches are released, regular stall detection
        % continues unchanged.
        pendingRelease=any(lens-sNext>1e-8 & launchTimes>t+dt+1e-9);
        if pendingRelease
            settleStart=NaN;
        else
            if isnan(settleStart),settleStart=t;end
            if t-settleStart>=maxStall
                reason='all_aircraft_stalled';
                s=sNext;v=vCommand;break;
            end
        end
    else
        settleStart=NaN;
    end
    s=sNext;v=vCommand;
end
if steps==N && all(lens-s<=1e-8),reason='completed';end
trace=struct();
trace.time_s=time(1:steps+1);
trace.progress_m=progress(1:steps+1,:);
trace.speed_mps=speed(1:steps,:);
trace.yieldFlags=yieldHistory(1:steps,:);
trace.obstacleYieldFlags=obsYieldHistory(1:steps,:);
trace.position_m=positions(1:steps+1,:,:);
trace.plannedLaunchTimes_s=launchTimes;
trace.pathLengths_m=lens;
trace.speedCaps_mps=caps;
trace.dt_s=dt;
trace.model='piecewise_constant_arc_speed_with_per_tick_slew';
trace.dynamicObstacles=obstacles;
out.trace=trace;
actualLaunchTimes=NaN(U,1);
for i=1:U
    firstMoving=find(trace.progress_m(:,i)>1e-9,1,'first');
    if ~isempty(firstMoving)
        actualLaunchTimes(i)=trace.time_s(firstMoving);
    end
end
out.actualLaunchTimes_s=actualLaunchTimes;
out.completionTimes_s=finishTimes;
out.completedUAVs=sum(lens-s<=1e-8);
% Independent re-derivation from trace progress; even partial traces are
% audited and unsafe motion is NEVER advertised as success.
out.validation=mmra_verify_speed_trace(paths,trace,opt);
if hasObstacles
    obstacleAudit=mmra_verify_dynamic_obstacles(paths,trace,opt,obstacles);
    out.validation.dynamicObstacles=obstacleAudit;
    out.validation.safe=out.validation.safe && obstacleAudit.safe;
    out.obstacleMinClearance_m=obstacleAudit.minClearance_m;
    out.obstaclePostConflicts=obstacleAudit.conflictingPairs;
    if ~obstacleAudit.safe
        out.validation.reason=obstacleAudit.reason;
    end
end
out.minSeparation=out.validation.minSeparation;
out.postConflicts=out.validation.postConflicts;
out.success=strcmp(reason,'completed') && out.validation.safe && ...
    out.validation.complete;
if out.success
    out.reason='completed_speed_feedback_verified';
    out.makespan=max(finishTimes);
else
    out.reason=reason;
    if strcmp(reason,'completed')
        out.reason=['independent_validation_' out.validation.reason];
    end
end
out.schedule_s=toc(clock);
end

function [hi,lo,valid]=localGoalBound(prev,remaining,dt,aUp,aDown,cap)
% Maintain a recoverable discrete-time braking envelope near the endpoint.
if remaining<=1e-8
    hi=0;lo=0;valid=prev<=aDown*dt+1e-7;return;
end
lo=max(0,prev-aDown*dt);
hi=min([cap,prev+aUp*dt,remaining/dt]);
valid=hi+1e-8>=lo && ...
    lo*dt+localStopDistance(lo,dt,aDown)<=remaining+1e-7;
if ~valid,hi=0;return;end
if hi*dt+localStopDistance(hi,dt,aDown)>remaining+1e-9
    a=lo;b=hi;
    for j=1:30
        mid=(a+b)/2;
        if mid*dt+localStopDistance(mid,dt,aDown)<=remaining
            a=mid;
        else
            b=mid;
        end
    end
    hi=a;
end
hi=max(lo,hi);
end

function d=localStopDistance(v,dt,brake)
% Remaining travel if future tick speeds decrease by brake*dt each tick.
n=max(0,ceil(v/(brake*dt)-1e-11)-1);
d=max(0,dt*(n*v-brake*dt*n*(n+1)/2));
end

function f=localForecast(geom,s,v,caps,aUp,H,predDt,tNow,launchTimes)
U=numel(s);times=(0:predDt:H)';
if times(end)<H-1e-10,times(end+1)=H;end
f=zeros(numel(times),3,U);
for i=1:U
    for q=1:numel(times)
        t=times(q);
        if tNow+t<=launchTimes(i)
            ds=0;
        else
            % Before release, forecast remains at the occupied start;
            % after release accelerate from rest. Already released UAVs
            % forecast from their present actual speed.
            activeT=t;
            speed0=v(i);
            if tNow<launchTimes(i)
                activeT=tNow+t-launchTimes(i);
                speed0=0;
            end
            tCap=max(0,(caps(i)-speed0)/aUp);
            if activeT<=tCap
                ds=speed0*activeT+0.5*aUp*activeT*activeT;
            else
                ds=speed0*tCap+0.5*aUp*tCap*tCap+ ...
                    caps(i)*(activeT-tCap);
            end
        end
        f(q,:,i)=mmra_speed_arc_position(geom{i},min(geom{i}.length,s(i)+ds));
    end
end
end

function loser=localYielder(i,j,geom,s,v,p,rank,lens)
% High-priority agent at an encounter keeps moving. For roughly parallel
% same-direction paths, the geometrically AHEAD agent wins.
if s(i)>=lens(i)-1e-8,loser=j;return;end
if s(j)>=lens(j)-1e-8,loser=i;return;end
ui=localTangent(geom{i},s(i));uj=localTangent(geom{j},s(j));
if dot(ui,uj)>0.75
    along=dot(p(i,:)-p(j,:),ui);
    lateral=norm((p(i,:)-p(j,:))-along*ui);
    if lateral<15 && abs(along)>1.0
        if along>0,loser=j;else,loser=i;end
        return;
    end
end
if rank(i)<rank(j),loser=j;else,loser=i;end
end

function u=localTangent(g,s)
k=find(g.cumulative<=s+1e-10,1,'last');
k=min(k,size(g.points,1)-1);
q=g.points(k+1,:)-g.points(k,:);
u=q/max(norm(q),1e-12);
end

function [a,b]=localUnsafePair(geom,s,v,dt,dSafe,tol)
U=numel(s);a=0;b=0;
for i=1:U-1
    p=mmra_speed_arc_position(geom{i},s(i));
    for j=i+1:U
        q=mmra_speed_arc_position(geom{j},s(j));
        % For any two moving particles, their separation can shrink by
        % no more than the SUM of their travelled distances in this step.
        if norm(p-q)>dSafe+(v(i)+v(j))*dt+1e-8
            continue;
        end
        [d,~]=mmra_speed_interval_minsep(geom{i},geom{j}, ...
            s(i),min(geom{i}.length,s(i)+v(i)*dt), ...
            s(j),min(geom{j}.length,s(j)+v(j)*dt),dt);
        if d<dSafe-tol,a=i;b=j;return;end
    end
end
end

function badU=localUnsafeObstacle(geom,s,vCommand,t,dt,obstacles,droneRadius,guard,tol)
% No unsafe ideal modeled control interval is ever executed. The broad
% phase uses a certified max relative displacement bound; narrow phase
% splits at BOTH geometry vertices and obstacle time knots.
U=numel(geom);badU=0;
for i=1:U
    p0=mmra_speed_arc_position(geom{i},s(i));
    sNext=min(geom{i}.length,s(i)+vCommand(i)*dt);
    for m=1:numel(obstacles)
        ob=obstacles(m);
        required=ob.radius_m+droneRadius+guard;
        center=mmra_dynamic_obstacle_position(ob,t);
        if norm(p0-center)>(required+(sNext-s(i))+ ...
                ob.maxSpeed_mps*dt+1e-9)
            continue;
        end
        [d,~]=mmra_dynamic_obstacle_interval_minsep( ...
            geom{i},s(i),sNext,t,t+dt,ob);
        if d<required-tol
            badU=i;return;
        end
    end
end
end

function v=localOpt(opt,key,defaultValue)
if isfield(opt,key) && ~isempty(opt.(key)),v=double(opt.(key));
else,v=defaultValue;end
assert(isscalar(v) && isnumeric(v),'%s must be numeric scalar.',key);
end
