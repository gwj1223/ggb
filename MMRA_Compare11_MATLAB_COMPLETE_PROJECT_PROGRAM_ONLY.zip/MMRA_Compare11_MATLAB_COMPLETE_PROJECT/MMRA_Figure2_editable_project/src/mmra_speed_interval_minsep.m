function [dMin,tMin] = mmra_speed_interval_minsep(ga,gb,sa0,sa1,sb0,sb1,dt)
%MMRA_SPEED_INTERVAL_MINSEP Exact pair separation for ONE commanded time step.
% Both progress coordinates change linearly during [0,dt].  A crossing of
% any polyline vertex is split into its own affine interval. Therefore the
% minimum is continuous-time exact for the IDEAL piecewise-constant-speed
% motion model (not a physical acceleration/turning/tracking certificate).
assert(dt>0 && isfinite(dt));
assert(sa1>=sa0-1e-9 && sb1>=sb0-1e-9, ...
    'Reverse movement is not supported.');
ua=localBreaks(ga.cumulative,sa0,sa1);
ub=localBreaks(gb.cumulative,sb0,sb1);
u=unique(sort([0;1;ua(:);ub(:)]));
dMin=inf;tMin=0;
for k=1:numel(u)-1
    left=u(k);right=u(k+1);
    if right-left<1e-13,continue;end
    a0=mmra_speed_arc_position(ga,sa0+left*(sa1-sa0));
    b0=mmra_speed_arc_position(gb,sb0+left*(sb1-sb0));
    a1=mmra_speed_arc_position(ga,sa0+right*(sa1-sa0));
    b1=mmra_speed_arc_position(gb,sb0+right*(sb1-sb0));
    r=a0-b0;dr=(a1-b1)-r;
    denom=dot(dr,dr);
    if denom<1e-20,q=0;else,q=max(0,min(1,-dot(r,dr)/denom));end
    d=norm(r+q*dr);
    if d<dMin,dMin=d;tMin=dt*(left+q*(right-left));end
end
end

function u=localBreaks(cum,a,b)
if b-a<=1e-13,u=[];return;end
v=cum(cum>a+1e-12 & cum<b-1e-12);
u=(v-a)/(b-a);
end
