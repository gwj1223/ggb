function [env,cfg,startPos,goalPos] = mmra_sc_case(profile,hard)
%MMRA_SC_CASE Reuse the same paper benchmark and optional constrained variant.
% "hard" is a designed stress test, NOT the original manuscript benchmark.
if nargin<2, hard=false; end
[env,cfg,~]=mmra_defaults(profile);
if hard
    cfg.maxIter=200;
    if strcmp(profile,'paper_gmm')
        env.peaks(end+1,:)=[21 48 51 6 17];
        env.boundsHi(3)=65;
        env.safetyMargin=10;
    elseif strcmp(profile,'legacy20_sine')
        env.boundsHi(3)=65;
        env.safetyMargin=12;
    else
        error('Unsupported hard scenario: %s',profile);
    end
end
if strcmp(profile,'paper_gmm')
    startPos=[5 7 24]; goalPos=[94 93 25];
else
    startXY=[6 8];goalXY=[94 90];
    startPos=[startXY mmra_terrain(startXY,env)+env.safetyMargin+12];
    goalPos=[goalXY mmra_terrain(goalXY,env)+env.safetyMargin+12];
end
assert(mmra_is_free(startPos,env) && mmra_is_free(goalPos,env), ...
    'Invalid case endpoints: %s hard=%d',profile,hard);
cfg.prune=false;cfg.smooth=false;
end
