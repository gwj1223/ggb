%RUN_MAIN_MAP Display ONLY the screenshot-selected Figure 2.
% One 5 km x 5 km x 2 km synthetic mountain-cluster map, no other figures.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
close all;
scene='mountain_cluster_figure2_custom_5km';
[env,cfg,sched]=mmra_defaults(scene);
[starts,goals,meta]=mmra_5km_mission(env,20,24001,'cross_center');
fig=mmra_plot_single_main_map(env,starts,goals);
outDir=fullfile(root,'results_main_map');
if ~exist(outDir,'dir'),mkdir(outDir);end
pngFile=fullfile(outDir,'Figure2_Multi_peak_complex_terrain.png');
saveas(fig,pngFile);
save(fullfile(outDir,'Figure2_Multi_peak_complex_terrain_data.mat'), ...
    'env','cfg','sched','starts','goals','meta','-v7');
fprintf('ONE map displayed and saved: %s\n',pngFile);
fprintf('Scene: %s. These dotted connectors are NOT planned flight paths.\n',scene);
