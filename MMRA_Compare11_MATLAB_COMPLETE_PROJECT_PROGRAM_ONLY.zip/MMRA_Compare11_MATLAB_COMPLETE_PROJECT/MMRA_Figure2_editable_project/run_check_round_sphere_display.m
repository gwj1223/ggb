%RUN_CHECK_ROUND_SPHERE_DISPLAY Self-contained Figure 2 roundness check.
% Tests the same data-aspect ratio as the original mountain renderer.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
fig=figure('Name','Figure 2 round sphere geometry check','Color','w');
ax=axes('Parent',fig);
hold(ax,'on');
xlim(ax,[0 5]);ylim(ax,[0 5]);zlim(ax,[0 2]);
daspect(ax,[1 1 0.55]);
view(ax,42,29);
ob=struct('time_s',[0;10],'position_m',[2000 2000 1400; ...
    3000 2000 1400],'radius_m',150,'name','diagnostic');
h=mmra_figure2_plot_dynamic_overlay(ax,ob,5,[]);
dar=get(ax,'DataAspectRatio');
x=get(h.sphere{1},'XData');
y=get(h.sphere{1},'YData');
z=get(h.sphere{1},'ZData');
visualHalfExtents=([max(x(:))-min(x(:)), ...
    max(y(:))-min(y(:)),max(z(:))-min(z(:))]/2)./dar;
assert(max(abs(visualHalfExtents-visualHalfExtents(1)))<1e-8, ...
    'Sphere is not round under the Figure 2 axes data aspect ratio.');
assert(strcmpi(get(ax,'Projection'),'orthographic'), ...
    'Camera projection must be orthographic.');
fprintf('Round-sphere display CHECK PASSED.\n');
fprintf('Axes DAR=[%.2f %.2f %.2f], normalized half extents=[%.4f %.4f %.4f].\n', ...
    dar,visualHalfExtents);
for v=[42 29;110 25;190 35]'
    view(ax,v(1),v(2));
    drawnow;
end
fprintf('Try rotating this diagnostic sphere. Physical collision radius unchanged.\n');
