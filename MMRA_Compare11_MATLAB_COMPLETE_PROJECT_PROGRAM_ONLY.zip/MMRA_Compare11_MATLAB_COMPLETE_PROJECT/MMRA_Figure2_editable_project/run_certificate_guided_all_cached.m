%RUN_CERTIFICATE_GUIDED_ALL_CACHED Optional 180-case extension after 20-UAV.
% Reuses existing checkpoints. Does NOT rerun RRT*.
pathCasesFolder='';
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'tests'),fullfile(root,'examples'));
fprintf('=== MMRA certificate-guided spatial feedback 180-case DEV pilot ===\n');
run(fullfile(root,'run_tests.m'));
mmra_rrt_threeobjective_tests();
mmra_sched_repair_tests();
mmra_sched_window_tests();
mmra_certificate_repair_tests();
mmra_certificate_repair_driver(root,false,pathCasesFolder);
