%RUN_MAIN_MAP_USER_TESTS Verify exactly the currently saved Figure 2.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
[env,~,sched]=mmra_defaults('mountain_cluster_figure2_custom_5km');
stats=mmra_figure2_user_validate(env,true);
assert(sched.dSafe==10 && sched.speed==15 && ...
    sched.speedFeedbackLaunchInterval_s==3);
% Terrain gradient must match independently sampled derivatives.
pts=[990 940;3210 2740;1870 3610;4150 1220; ...
    1200 2500;2450 3300;4200 4200];
dx=0.05;
for i=1:size(pts,1)
    q=pts(i,:);
    [~,gx,gy]=mmra_terrain(q,env);
    nx=(mmra_terrain(q+[dx 0],env)- ...
        mmra_terrain(q-[dx 0],env))/(2*dx);
    ny=(mmra_terrain(q+[0 dx],env)- ...
        mmra_terrain(q-[0 dx],env))/(2*dx);
    assert(abs(gx-nx)<1e-4 && abs(gy-ny)<1e-4, ...
        'Gradient mismatch.');
end
fprintf('Custom Figure 2 checks passed; sampled elevation %.1f-%.1f m.\n', ...
    stats.minHeight_m,stats.maxHeight_m);
