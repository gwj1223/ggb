%RUN_CHECK_DYNAMIC_ADAPTIVE_INSTALL Show V3 files in this project root.
root = fileparts(mfilename('fullpath'));
fprintf('Current V3 project root: %s\n',root);
files = { ...
    fullfile(root,'run_dynamic_adaptive_tests.m'), ...
    fullfile(root,'src','mmra_dynamic_adaptive_hybrid_schedule.m'), ...
    fullfile(root,'tests','mmra_dynamic_adaptive_tests.m')};
ready=true;
for k = 1:numel(files)
    if exist(files{k},'file') == 2
        fprintf('FOUND   %s\n', files{k});
    else
        fprintf(2,'MISSING %s\n', files{k});
        ready=false;
    end
end
if ready
    addpath(fullfile(root,'src'),fullfile(root,'tests'),'-begin');
    rehash;
    fprintf('MATLAB resolves test: %s\n',which('mmra_dynamic_adaptive_tests'));
    fprintf('MATLAB resolves algorithm: %s\n',which('mmra_dynamic_adaptive_hybrid_schedule'));
    fprintf('V3 installation: source files present (MATLAB tests not yet executed).\n');
else
    fprintf(2,'V3 installation incomplete. Unzip FIX to folder containing run_main_map.m.\n');
end
