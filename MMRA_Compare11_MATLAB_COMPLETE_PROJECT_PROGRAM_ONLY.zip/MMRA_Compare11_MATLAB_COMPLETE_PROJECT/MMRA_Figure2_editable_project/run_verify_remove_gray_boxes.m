%RUN_VERIFY_REMOVE_GRAY_BOXES Verify gray buildings are absent from Figure 2.
% No MAT settings, prior paths, figures or saved results are overwritten.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
[env,~,~]=mmra_defaults('mountain_cluster_figure2_custom_5km');
env=mmra_figure2_add_static_obstacles(env);
assert(isequal(size(env.staticBoxes),[0 6]), ...
    'Gray buildings are still active in the current Figure 2 environment.');
assert(size(env.noFlyCylinders,1)==3, ...
    'Expected the three saved red no-fly cylinders to remain.');
% Test that the old buildings do not secretly constrain new trajectories.
freeEnv=env;freeEnv.noFlyCylinders=zeros(0,5);
assert(all(mmra_no_fly_free([1050 2000 1800;3350 3150 1800],freeEnv)), ...
    'Box collision restrictions unexpectedly remain active.');
assert(mmra_no_fly_segment_free([850 2000 1800],[1300 2000 1800],freeEnv), ...
    'Old building A still blocks the segment collision checker.');
assert(mmra_no_fly_segment_free([3100 3150 1800],[3600 3150 1800],freeEnv), ...
    'Old building B still blocks the segment collision checker.');
% Check cylinder blocking remains enabled in the actual environment.
c=env.noFlyCylinders(1,:);
assert(~mmra_no_fly_free([c(1) c(2) mean(c(4:5))],env), ...
    'Saved red no-fly cylinder unexpectedly stopped blocking paths.');
fprintf('Figure 2 checks PASSED: NFZ=%d, gray boxes=%d.\n', ...
    size(env.noFlyCylinders,1),size(env.staticBoxes,1));
fprintf('Terrain and moving-sphere settings were not modified.\n');
fprintf('Re-run run_static_obstacle_figure2_5u.m before combined avoidance.\n');
