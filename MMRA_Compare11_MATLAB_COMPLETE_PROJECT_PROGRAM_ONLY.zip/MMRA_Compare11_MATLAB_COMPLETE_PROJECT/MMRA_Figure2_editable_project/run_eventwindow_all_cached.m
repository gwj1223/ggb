%RUN_EVENTWINDOW_ALL_CACHED Expanded 5-,10-,20-UAV development pilot.
% Reuses 20-UAV checkpoints if run_eventwindow_20u_cached was already run.
% Uses 180 previous saved path cases; NEVER reruns RRT*.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'tests'),fullfile(root,'examples'));
fprintf('=== MMRA v2.1 endpoint-aware window scheduler: all 180 cached cases ===\n');
run(fullfile(root,'run_tests.m'));
mmra_rrt_threeobjective_tests();
mmra_sched_repair_tests();
mmra_sched_window_tests();
mmra_sched_event_driver(root,false);
