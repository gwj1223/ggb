%RUN_STATIC_OBSTACLE_FIGURE2_5U_LONGRANGE
% LONG-RANGE five-UAV missions from the same saved Figure 2 corner base.
% Preserves 85-m spaced starts, terrain, NFZ, dynamic spheres and local frame.
%
% IMPORTANT FRAME CONVENTION (metres):
%   Global = original, unchanged MMRA terrain/NFZ/dynamic coordinates.
%   Local X = Global Y - 200
%   Local Y = 4766.67 - Global X
%   Local Z = Global Z (absolute elevation, unchanged)
% This is a 90-degree rotation plus translation, NOT a terrain rewrite.
% The clicked ground site is local XY = (0,0); the RRT* STARTS are
% airborne waypoints above the site. Ground takeoff dynamics are not modeled.
%
% Safe installation: NEW script in project root. Old scripts/settings untouched.
% The downstream MAT is changed only after all 5 paths pass checks, and its
% prior version is backed up before replacement.

root = fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
[env,cfg,sched] = mmra_defaults('mountain_cluster_figure2_custom_5km');
env = mmra_figure2_add_static_obstacles(env);

% Global map point chosen by the user, in metres (not kilometres).
originWorldXY_m = [4766.67 200.00];
baseGroundZ_m = mmra_terrain(originWorldXY_m,env);
assert(isscalar(baseGroundZ_m) && isfinite(baseGroundZ_m));

% Positive local X/Y point toward the inside of the 5 km square.
% Five distinct airborne starting waypoints in the same small base area.
% At the whole-map scale, 45-m spacing made the markers overlap visually;
% 85-m minimum spacing remains a compact 170 x 85 m base footprint.
% Change ONLY this parameter to adjust the separation in later runs.
padSpacing_m = 85;  % [m] real geometric separation, not display-only jitter
padsLocalXY_m = [ ...
    0                0;  % S1, exactly at the clicked (0,0) site in local XY
    0                padSpacing_m;  % S2
    padSpacing_m     0;             % S3
    padSpacing_m     padSpacing_m;  % S4
    padSpacing_m/2   2*padSpacing_m]; % S5, slightly farther inside map

% This is the AIRBORNE planning start altitude, not the surface elevation.
% It is purposely exposed as one experiment parameter. For near-ground
% takeoff studies, add a verified ascent phase rather than changing Z to
% the terrain height (which violates the current safety-margin oracle).
flightStartAltitude_m = 900;

% Inverse local-to-global XY mapping:
%   Global X = 4766.67 - Local Y, Global Y = 200 + Local X.
startsXY = [originWorldXY_m(1)-padsLocalXY_m(:,2), ...
            originWorldXY_m(2)+padsLocalXY_m(:,1)];
starts = [startsXY,flightStartAltitude_m*ones(5,1)];

% Far-side task goals: about 5.3--6.0 km HORIZONTAL separation.
% The actual RRT* routes are often longer owing to terrain/NFZ avoidance.
% All candidates are checked against the CURRENT saved map and NFZs.
% Each row is [local X, local Y], metres; the first row is preferred.
goalCandidatesLocalXY_m = cell(5,1);
goalCandidatesLocalXY_m{1} = [4650 2600; 4550 2800; 4450 3000; 4350 3200];
goalCandidatesLocalXY_m{2} = [4500 3450; 4400 3650; 4300 3500; 4550 3300];
goalCandidatesLocalXY_m{3} = [4250 4300; 4400 4100; 4050 4400; 4450 3950];
goalCandidatesLocalXY_m{4} = [3350 4550; 3100 4550; 3550 4500; 2950 4650];
goalCandidatesLocalXY_m{5} = [3850 4650; 3950 4550; 3750 4600; 4050 4450];
minGoalDistance_m = 5100;       % from each actual launch waypoint (3D)
maxGoalDistance_m = 6900;       % avoid overly long/artificial tasks
mapEdgeMargin_m = 75;          % goal XY must be inside the map
minGoalSeparation_m = 350;     % distinct mission targets
goals = zeros(5,3);
selectedGoalsLocalXY_m = zeros(5,2);

cfg.rrtStopMode = 'terrain_adaptive';
cfg.maxIter = 1200;
assert(strcmp(cfg.costMode,'length_risk_climb'));

% Launch-pad safety and spacing, using SAME environment as the planner.
allTerrain_m = mmra_terrain(starts(:,1:2),env);
minSep_m = inf;
for i=1:5
    probe = [starts(i,:); starts(i,:)+[0 1 0]];
    assert(mmra_path_free(probe,env,cfg.guardFineResolution) && ...
           all(mmra_no_fly_free(probe,env)), ...
           'Launch pad %d fails terrain/boundary/NFZ checks.',i);
    for j=i+1:5
        minSep_m = min(minSep_m,norm(starts(i,:)-starts(j,:)));
    end
end
assert(minSep_m>10,'Initial UAV separation violates 10-m constraint.');

fprintf('\n=== FIGURE 2: LONG-RANGE LOCAL-ORIGIN / FIVE UAV ===\n');
fprintf('Site global XY = [%.2f %.2f] m; local XY = [0 0] m\n',originWorldXY_m);
fprintf('Site ground elevation = %.2f m; flight start elevation = %.2f m\n', ...
    baseGroundZ_m,flightStartAltitude_m);
fprintf('Launch-pad minimum spacing = %.1f m\n',minSep_m);
for i=1:5
    fprintf('UAV%d local pad=[%5.0f %5.0f] m, global start=[%8.2f %8.2f %5.0f] m, terrain clearance=%.1f m\n', ...
       i,padsLocalXY_m(i,:),starts(i,:),flightStartAltitude_m-allTerrain_m(i));
end

for i=1:5
    candidates = goalCandidatesLocalXY_m{i};
    found = false;
    for j=1:size(candidates,1)
        lxy = candidates(j,:);
        wxy = [originWorldXY_m(1)-lxy(2), ...
               originWorldXY_m(2)+lxy(1)];
        if any(wxy<env.boundsLo(1:2)+mapEdgeMargin_m) || ...
           any(wxy>env.boundsHi(1:2)-mapEdgeMargin_m)
            continue;
        end
        h = mmra_terrain(wxy,env);
        if ~isscalar(h) || ~isfinite(h), continue; end
        zGoal = max(900,ceil((h+env.safetyMargin+150)/10)*10);
        if zGoal>=env.boundsHi(3)-10, continue; end
        candidateGoal = [wxy zGoal];
        direct_m = norm(candidateGoal-starts(i,:));
        if direct_m<minGoalDistance_m || ...
           direct_m>maxGoalDistance_m, continue; end
        probe = [candidateGoal;candidateGoal+[0 1 0]];
        if ~mmra_path_free(probe,env,cfg.guardFineResolution) || ...
           ~all(mmra_no_fly_free(probe,env))
            continue;
        end
        if i>1
            distanceToOldGoals_m = sqrt(sum((goals(1:i-1,:) - candidateGoal).^2,2));
            if any(distanceToOldGoals_m<minGoalSeparation_m), continue; end
        end
        goals(i,:) = candidateGoal;
        selectedGoalsLocalXY_m(i,:) = lxy;
        found = true;
        fprintf('UAV%d goal local=[%5.0f %5.0f] m, world=[%7.1f %7.1f %6.1f] m, straight=%.1f m\n', ...
            i,lxy,candidateGoal,direct_m);
        break;
    end
    assert(found, ...
      'No valid goal for UAV%d in saved map/NFZ. Old cache is unchanged.',i);
end

% Save both coordinate systems for reproducible paper figures.
missionInfo = struct();
missionInfo.name = 'corner_base_local_origin_5u';  % keep plotter compatible
missionInfo.variant = 'five_far_side_goals_longrange_v1';
missionInfo.goalDistanceRange_m = [minGoalDistance_m maxGoalDistance_m];
missionInfo.seed = 24001;
missionInfo.originWorldXY_m = originWorldXY_m;
missionInfo.originGroundZ_m = baseGroundZ_m;
missionInfo.coordinateConvention = ...
    'localX=worldY-200; localY=4766.67-worldX; localZ=worldZ';
missionInfo.startAltitude_m = flightStartAltitude_m;
missionInfo.localStartsXY_m = padsLocalXY_m;
missionInfo.launchLayout = 'five_spaced_launch_pads_85m';
missionInfo.padSpacing_m = padSpacing_m;
missionInfo.localGoalsXY_m = selectedGoalsLocalXY_m;
missionInfo.minPadSeparation_m = minSep_m;
missionInfo.airborneStartOnly = true;
meta = struct('mode','corner_base_local_origin','missionInfo',missionInfo, ...
    'starts_m',starts,'goals_m',goals);

paths = cell(5,1);
records = struct('success',{},'reason',{},'length_m',{}, ...
    'risk_m',{},'climb_m',{},'objective_m',{}, ...
    'minTerrainClearance_m',{},'elapsed_s',{});
rng(24001,'twister');
for i=1:5
    [p,st] = mmra_plan_single(starts(i,:),goals(i,:),env,cfg,true);
    paths{i} = p;
    records(i).success = logical(st.success);
    records(i).reason = char(st.reason);
    records(i).elapsed_s = st.total_s;
    records(i).length_m = NaN;
    records(i).risk_m = NaN;
    records(i).climb_m = NaN;
    records(i).objective_m = NaN;
    records(i).minTerrainClearance_m = NaN;
    if st.success
        assert(~isempty(p) && size(p,2)==3 && size(p,1)>1);
        assert(norm(p(1,:)-starts(i,:))<1 && ...
               norm(p(end,:)-goals(i,:))<1, ...
               'UAV%d path endpoints differ from the actual mission.',i);
        assert(mmra_path_free(p,env,cfg.guardFineResolution) && ...
               all(mmra_no_fly_free(p,env)), ...
               'UAV%d path failed static collision audit.',i);
        records(i).length_m = mmra_path_length(p);
        records(i).risk_m = mmra_path_risk(p,env, ...
            cfg.riskCostBand_m,cfg.riskCostResolution_m);
        records(i).climb_m = mmra_path_ascent(p);
        records(i).objective_m = st.finalObjective_m;
        records(i).minTerrainClearance_m = ...
            mmra_path_clearance(p,env,cfg.guardFineResolution);
    end
    fprintf('UAV%d: success=%d, reason=%s, length=%.1f m, J=%.2f, time=%.2f s\n', ...
        i,st.success,st.reason,records(i).length_m, ...
        records(i).objective_m,st.total_s);
end

archiveDir = fullfile(root,'results_common_base_origin_dev');
if ~exist(archiveDir,'dir'), mkdir(archiveDir); end
archiveFile = fullfile(archiveDir,'Figure2_corner_origin_rrt_5u_longrange.mat');
save(archiveFile,'env','cfg','sched','starts','goals','meta', ...
    'missionInfo','paths','records','-v7');

nSuccess = sum([records.success]);
fprintf('\nLONG-RANGE corner-origin RRT*: %d/5 successful.\n',nSuccess);
fprintf('Independent archive: %s\n',archiveFile);
if nSuccess ~= 5
    fprintf('Downstream path cache was NOT modified.\n');
    fprintf('Review failures and current terrain/NFZ before trying again.\n');
else
    downstreamDir = fullfile(root,'results_static_obstacles_dev');
    if ~exist(downstreamDir,'dir'), mkdir(downstreamDir); end
    downstreamFile = fullfile(downstreamDir, ...
        'Figure2_static_obstacle_rrt_5u.mat');
    if isfile(downstreamFile)
        stamp = datestr(now,'yyyymmdd_HHMMSSFFF');
        backupFile = fullfile(downstreamDir, ...
            ['Figure2_static_obstacle_rrt_5u_before_longrange_' stamp '.mat']);
        assert(~isfile(backupFile),'Backup exists, refusing overwrite.');
        [ok,msg] = copyfile(downstreamFile,backupFile);
        assert(ok,'Backup failed: %s',msg);
        fprintf('Previous mission backup: %s\n',backupFile);
    end
    [ok,msg] = copyfile(archiveFile,downstreamFile,'f');
    assert(ok,'Failed to update downstream cache: %s',msg);
    fprintf('Downstream path cache UPDATED to LONG-RANGE TASK: %s\n',downstreamFile);
    fprintf('Next: run(''run_static_dynamic_figure2_5u.m'')\n');
    fprintf('Then: run(''run_plot_figure2_corner_origin.m'')\n');
end
fprintf('Figure2 terrain/NFZ/dynamic/display settings were NOT modified.\n');
fprintf('Long-range experiment: keep the actual selected goals/seed fixed for controls.\n');
