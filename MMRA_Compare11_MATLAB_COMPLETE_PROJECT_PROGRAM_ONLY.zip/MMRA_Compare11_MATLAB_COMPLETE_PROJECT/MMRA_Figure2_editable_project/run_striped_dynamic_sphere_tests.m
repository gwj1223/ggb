%RUN_STRIPED_DYNAMIC_SPHERE_TESTS Checks graphics and safe enlargement.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
addpath(fullfile(root,'tests'));
mmra_figure2_striped_sphere_tests();
