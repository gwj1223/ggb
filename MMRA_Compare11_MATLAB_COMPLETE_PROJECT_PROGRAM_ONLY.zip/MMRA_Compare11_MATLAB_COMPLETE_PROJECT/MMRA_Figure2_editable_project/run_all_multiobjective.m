%RUN_ALL_MULTIOBJECTIVE MMRA v2.0, ONE-COMMAND RRT* cost-function pilot.
% MATLAB: run('run_all_multiobjective.m') from v2.0 root.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
addpath(fullfile(root,'tests'));
fprintf('=== MMRA v2.0 length + terrain-risk RRT* pilot ===\n');
run(fullfile(root,'run_tests.m'));
run(fullfile(root,'examples','run_rrt_multiobjective_ablation.m'));
fprintf('=== Done. Results in results_rrt_multiobjective_v20/ ===\n');
