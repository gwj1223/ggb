function mmra_figure2_nfz_editor_tests()
%MMRA_FIGURE2_NFZ_EDITOR_TESTS Isolated persisted NFZ geometry tests.
% Never writes the user's terrain/NFZ settings. UI must be checked in MATLAB.
fprintf('MMRA Figure 2 NFZ slider persistence tests: starting...\n');
root=fileparts(fileparts(mfilename('fullpath')));
terrainFile=fullfile(root,'results_main_map','Figure2_user_settings.mat');
terrainFileCopy=[];
if isfile(terrainFile)
    terrainFileCopy=fileread_bytes(terrainFile);
end
[env,~,~]=mmra_defaults('mountain_cluster_figure2_custom_5km');
tmpDir=tempname;
mkdir(tmpDir);
cleanup=onCleanup(@()cleanup_temp(tmpDir)); %#ok<NASGU>
file=fullfile(tmpDir,'Figure2_static_obstacles_settings.mat');

% Without saved settings, the old three cylinders must be identical.
orig=mmra_figure2_nfz_defaults();
defaultEnv=mmra_figure2_add_static_obstacles(env,file);
assert(isequal(defaultEnv.noFlyCylinders,orig));
mmra_figure2_validate_nfz(defaultEnv,true);

% Round-trip modified center, radius, bottom and top via an isolated MAT.
new=orig;
new(1,:)=[2505 2495 220 0 1100];
new(2,3)=200;
new(3,4)=100;
noFlyParams=struct('cylinders',new,'revision','sandbox_test');
save(file,'noFlyParams','-v7');
changed=mmra_figure2_add_static_obstacles(env,file);
assert(isequal(changed.noFlyCylinders,new));
assert(strcmp(changed.staticObstaclesRevision, ...
    'figure2_nfz_only_sandbox_test'));
assert(isequal(size(changed.staticBoxes),[0 6]));
assert(isequal(changed.peaks,env.peaks) && ...
       isequal(changed.terrainRidges,env.terrainRidges));
mmra_figure2_validate_nfz(changed,true);
assert(~mmra_no_fly_segment_free([2200 2495 1000], ...
    [2900 2495 1000],changed), ...
    'New radius/center was not used by planner edge collision.');
assert(mmra_no_fly_segment_free([2200 2495 1250], ...
    [2900 2495 1250],changed), ...
    'Segment above edited top must be allowed.');
assert(~mmra_no_fly_free([2505 2495 1000],changed));
assert(mmra_no_fly_free([2505 2495 1250],changed));

% A buffered cylinder reaching out of the map must be rejected.
bad=new;bad(1,1)=20;
checked=changed;checked.noFlyCylinders=bad;
assert_fails(@()mmra_figure2_validate_nfz(checked,true));

% A new cylinder engulfing a fixed mission endpoint must be rejected.
missionEnv=env;
[starts,~]=mmra_5km_mission(missionEnv,20,24001,'cross_center');
bad=new;bad(1,:)=[starts(1,1:2) 160 0 2000];
checked.noFlyCylinders=bad;
assert_fails(@()mmra_figure2_validate_nfz(checked,true));

% Persistence loader must reject malformed/corrupted array shape.
noFlyParams.cylinders=ones(2,5);
save(file,'noFlyParams','-v7');
assert_fails(@()mmra_figure2_add_static_obstacles(env,file));

% Independent NFZ persistence does not modify terrain saved in another MAT.
if ~isempty(terrainFileCopy)
    assert(isequal(terrainFileCopy,fileread_bytes(terrainFile)), ...
        'The user terrain parameter MAT unexpectedly changed.');
end
fprintf('MMRA Figure 2 NFZ slider persistence tests: all assertions passed.\n');
end

function assert_fails(f)
failed=false;
try
    f();
catch
    failed=true;
end
assert(failed,'Invalid saved cylinder configuration was accepted.');
end

function bytes=fileread_bytes(path)
fid=fopen(path,'rb');
assert(fid>0,'Could not open terrain file for read-only test.');
c=onCleanup(@()fclose(fid)); %#ok<NASGU>
bytes=fread(fid,Inf,'*uint8');
end

function cleanup_temp(folder)
if exist(folder,'dir'),rmdir(folder,'s');end
end
