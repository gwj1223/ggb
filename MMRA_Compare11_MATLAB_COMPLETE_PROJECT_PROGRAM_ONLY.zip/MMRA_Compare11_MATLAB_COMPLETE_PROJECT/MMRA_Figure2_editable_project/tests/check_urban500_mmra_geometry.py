"""Independent Python numerical cross-check of archived Urban500 V3 routes.

This is a reference geometry check, NOT execution of the MATLAB .m files.
Requires numpy/scipy; matplotlib is optional for a preview.
Run from anywhere: python tests/check_urban500_mmra_geometry.py
"""
from pathlib import Path
from math import acos, degrees, ceil, sqrt
import csv
import numpy as np
from scipy.io import loadmat

ROOT = Path(__file__).resolve().parents[1]
CITY = ROOT / 'Urban500_V3_HighRise_Download' / 'Urban_Complex_500m_V3_HighRise'
MATFILE = CITY / 'results_urban_complex_500_v3_rrtstar' / 'Urban500_RRTstar_5U_static.mat'
OUT = ROOT / 'docs' / 'urban500_mmra_numerical_QA'
OUT.mkdir(parents=True, exist_ok=True)
S=loadmat(MATFILE, squeeze_me=True, struct_as_record=False)
scene=S['scene']
B=np.asarray(scene.buildings_m, dtype=float)
clearance=float(scene.uavSafetyRadius_m)+2
B_inflated=B+np.array([-clearance,clearance,-clearance,clearance,-clearance,clearance])
archived=[np.asarray(p, dtype=float) for p in S['paths']]


def edge_free(a,b,boxes):
    """Independent 3-D line / AABB slab test; boundary contact is collision."""
    delta=b-a
    for q in boxes:
        lower=q[[0,2,4]];upper=q[[1,3,5]]
        t0,t1=0.0,1.0
        for ax in range(3):
            if abs(delta[ax])<1e-12:
                if a[ax]<lower[ax] or a[ax]>upper[ax]:
                    t0=2.0
                    break
            else:
                aa=(lower[ax]-a[ax])/delta[ax]
                bb=(upper[ax]-a[ax])/delta[ax]
                t0=max(t0,min(aa,bb));t1=min(t1,max(aa,bb))
                if t0>t1:
                    break
        if t0<=t1 and t1>=0 and t0<=1:
            return False
    return True


def path_free(p,boxes):
    return all(edge_free(a,b,boxes) for a,b in zip(p[:-1],p[1:]))


def certify_curve(control,boxes,depth=15):
    """Quadratic curve contained in its convex hull; recursive AABB separation."""
    if len(boxes)==0: return True
    low=control.min(axis=0);high=control.max(axis=0)
    candidates=((high[0]>=boxes[:,0]-1e-10)&(low[0]<=boxes[:,1]+1e-10)&
                (high[1]>=boxes[:,2]-1e-10)&(low[1]<=boxes[:,3]+1e-10)&
                (high[2]>=boxes[:,4]-1e-10)&(low[2]<=boxes[:,5]+1e-10))
    if not candidates.any():return True
    if depth==0: return False
    midA=(control[0]+control[1])/2
    midB=(control[1]+control[2])/2
    middle=(midA+midB)/2
    return (certify_curve(np.array([control[0],midA,middle]),boxes[candidates],depth-1)
            and certify_curve(np.array([middle,midB,control[2]]),boxes[candidates],depth-1))


def path_length(p):
    return np.linalg.norm(np.diff(p,axis=0),axis=1).sum()


def max_turn(p):
    d=np.diff(p,axis=0)
    if len(d)<2:return 0
    l=np.linalg.norm(d,axis=1)
    return degrees(max([acos(np.clip(np.dot(d[i],d[i+1])/(l[i]*l[i+1]),-1,1))
                        for i in range(len(d)-1)]))


def prune_visibility(p,boxes):
    n=len(p);D=np.full(n,np.inf);parent=np.zeros(n,dtype=int);D[0]=0
    for j in range(1,n):
        for i in range(j):
            proposal=D[i]+np.linalg.norm(p[j]-p[i])
            if proposal<D[j]-1e-10 and edge_free(p[i],p[j],boxes):
                D[j]=proposal;parent[j]=i
    assert np.isfinite(D[-1]), 'No path in visibility graph'
    inds=[n-1]
    while inds[-1]!=0:inds.append(parent[inds[-1]])
    result=p[inds[::-1]]
    assert path_free(result,boxes)
    return result


def min_curve_radius(start,corner,end):
    u=corner-start;v=end-corner;w=v-u
    if np.dot(w,w)<1e-20:return np.inf
    t=np.clip(-np.dot(u,w)/np.dot(w,w),0,1)
    numerator=2*np.linalg.norm(u+t*w)**3
    d=np.linalg.norm(np.cross(u,w))
    return numerator/d if d>1e-14 else np.inf


def max_pitch(start,corner,end):
    u=corner-start;w=end-corner-u
    a=np.dot(u[:2],u[:2]);b=np.dot(u[:2],w[:2]);c=np.dot(w[:2],w[:2]);z=u[2];wz=w[2]
    ts=[0,1]
    den=wz*b-z*c
    if abs(den)>1e-15:
        t=(z*b-wz*a)/den
        if 0<t<1:ts.append(t)
    if c>1e-15:
        t=-b/c
        if 0<t<1:ts.append(t)
    return max(np.rad2deg(np.arctan2(abs((u+t*w)[2]),np.linalg.norm((u+t*w)[:2]))) for t in ts)


def adaptive_smooth(p,boxes,minimum_radius=10):
    out=[p[0]];stats={'eligible':0,'rounded':0,'curves':[],'unrounded':0}
    for i in range(1,len(p)-1):
        prev=p[i-1];corner=p[i];nxt=p[i+1]
        inp=corner-prev;outp=nxt-corner
        li=np.linalg.norm(inp);lo=np.linalg.norm(outp)
        if li<1e-10 or lo<1e-10:
            out.append(corner);continue
        inp=inp/li;outp=outp/lo
        theta=degrees(acos(np.clip(np.dot(inp,outp),-1,1)))
        if theta<=2:
            out.append(corner);continue
        stats['eligible']+=1
        rounded=False
        for f in [1,.85,.70,.55,.42,.32,.24,.17,.12,.08]:
            trim=.44*min(li,lo)*f
            start=corner-trim*inp;end=corner+trim*outp
            radius=min_curve_radius(start,corner,end)
            if radius+1e-8<minimum_radius or max_pitch(start,corner,end)>75+1e-8:
                continue
            if not certify_curve(np.array([start,corner,end]),boxes):
                continue
            h=min(2.5,sqrt(8*.10*max(radius,1e-9)))
            n=max(8,ceil(2*trim/h))
            if n>1000:continue
            tt=np.linspace(0,1,n+1)[:,None]
            curve=(1-tt)**2*start+2*tt*(1-tt)*corner+tt**2*end
            if not path_free(curve,boxes):continue
            out.append(start)
            out.extend(curve[1:])
            stats['rounded']+=1
            stats['curves'].append((start,corner,end,radius))
            rounded=True
            break
        if not rounded:
            stats['unrounded']+=1
            out.append(corner)
    out.append(p[-1])
    r=np.asarray(out)
    assert path_free(r,boxes) and np.allclose(r[0],p[0]) and np.allclose(r[-1],p[-1])
    return r,stats


def main():
    # Thin box enters the actual continuous curve but not the original L.
    obstacle=np.array([[17,19,1,4,0,20]],dtype=float)
    testpath=np.array([[0,0,10],[20,0,10],[20,20,10]],dtype=float)
    assert path_free(testpath,obstacle)
    assert not certify_curve(np.array([[11.2,0,10],[20,0,10],[20,8.8,10]]),obstacle)
    rows=[];after_all=[];before_all=[]
    for k,p in enumerate(archived,1):
        assert path_free(p,B_inflated)
        pruned=prune_visibility(p,B_inflated)
        smooth,stats=adaptive_smooth(pruned,B_inflated)
        assert all(certify_curve(np.array([x[0],x[1],x[2]]),B_inflated) for x in stats['curves'])
        assert all(x[3]+1e-8>=10 for x in stats['curves'])
        assert stats['rounded']==stats['eligible'], (k,stats)
        assert max_turn(smooth)<max_turn(pruned)
        rows.append({
            'UAV':k,'archived_nodes':len(p),'MMRA_pruned_nodes':len(pruned),
            'smoothed_polyline_nodes':len(smooth),
            'pruned_length_m':round(path_length(pruned),2),
            'smoothed_length_m':round(path_length(smooth),2),
            'before_max_turn_deg':round(max_turn(pruned),2),
            'after_max_turn_deg':round(max_turn(smooth),2),
            'rounded_corners':stats['rounded'],
            'eligible_corners':stats['eligible'],
            'minimum_accepted_arc_radius_m':round(min(x[3] for x in stats['curves']),2),
            'building_AABB_verified':True,
            'continuous_Bezier_certified':True,
        })
        before_all.append(pruned)
        after_all.append(smooth)
    csvfile=OUT/'urban500_v3_mmra_python_geometry_QA.csv'
    with csvfile.open('w',newline='',encoding='utf-8') as fd:
        writer=csv.DictWriter(fd,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    for r in rows:print(r)

    # Optional simple reference-only geometry preview, NOT MATLAB output.
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        from matplotlib.patches import Rectangle
        fig,axs=plt.subplots(1,2,figsize=(16,7),layout='constrained')
        colors=['#1ba83a','#c8a800','#ec3338','#aa43cf','#b37005']
        for ax,results,title in zip(axs,[before_all,after_all],
                                    ['Archived V3 paths + MMRA pruning','Enhanced MMRA adaptive Bezier']):
            for box in B:
                ax.add_patch(Rectangle((box[0],box[2]),box[1]-box[0],box[3]-box[2],
                                       facecolor='#aab2bf',edgecolor='#6c7684',lw=.4,alpha=.7))
            for k,p in enumerate(results):
                ax.plot(p[:,0],p[:,1],color=colors[k],lw=2.2,label=f'UAV {k+1}',zorder=10)
                ax.plot(p[0,0],p[0,1],'o',color=colors[k],markersize=5)
                ax.plot(p[-1,0],p[-1,1],'s',color=colors[k],markersize=5)
            ax.set_xlim(0,500);ax.set_ylim(0,500);ax.set_aspect('equal')
            ax.set_xlabel('X (m)');ax.set_ylabel('Y (m)');ax.set_title(title)
            ax.grid(alpha=.15)
        axs[1].legend(loc='upper left',fontsize=9)
        fig.suptitle('Urban500 V3 saved-path reprocessing | geometry reference (NOT MATLAB run)')
        fig.savefig(OUT/'urban500_v3_mmra_python_preview.png',dpi=170)
        plt.close(fig)
    except ImportError:
        print('matplotlib absent; skipping preview image')
    print('Independent geometry QA PASS: five archived paths, static AABB segments + certified quadratic arcs')

if __name__=='__main__':main()
