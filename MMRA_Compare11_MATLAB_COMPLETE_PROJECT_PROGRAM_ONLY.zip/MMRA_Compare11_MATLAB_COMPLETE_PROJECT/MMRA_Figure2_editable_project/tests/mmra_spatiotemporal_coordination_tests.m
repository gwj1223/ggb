function mmra_spatiotemporal_coordination_tests()
%MMRA_SPATIOTEMPORAL_COORDINATION_TESTS V2 offline safe coordination tests.
fprintf('MMRA spatiotemporal priority/individual-launch tests: starting...\n');
[~,~,opt]=mmra_defaults('paper_gmm');
opt.speed=15;opt.dSafe=10;
opt.startPolicy='hold';opt.endPolicy='hold';
opt.speedFeedbackMaxTime_s=70;
opt.speedFeedbackMaxStall_s=12;
opt.speedFeedbackDt_s=0.2;
opt.speedFeedbackPredictionStep_s=0.4;
opt.coordinationV2MaxTrials=17;
opt.speedFeedbackLaunchInterval_s=3;

% 1) Space-only intersection != time-conflict. Continuous nominal time
% screening must distinguish simultaneous from sufficiently offset releases.
paths={[-40 0 20;40 0 20],[0 -40 20;0 40 20]};
spatial=mmra_coordination_conflict_graph(paths,opt);
now=mmra_coordination_temporal_conflicts(paths,opt,[0;0],spatial);
later=mmra_coordination_temporal_conflicts(paths,opt,[0;3],spatial);
assert(now.numUnsafePairs==1 && now.minDistance_m(1,2)<1e-8, ...
    'Simultaneous perpendicular crossing should be nominally unsafe.');
assert(later.numUnsafePairs==0 && later.minDistance_m(1,2)>opt.dSafe, ...
    'A 3-second offset should remove the ideal constant-speed crossing.');
assert(now.numAlertPairs>=1 && ...
    ~strcmp(now.model,'verified_complete'), ...
    'Nominal predictor must never masquerade as a safety certificate.');

% 2) Direct priority-decision unit tests: faster predicted arrival gets
% right-of-way, with previously accumulated yielding resolving near-ties.
geom=cell(2,1);
for i=1:2
    [p,c,L]=mmra_arc(paths{i});
    geom{i}=struct('points',p,'cumulative',c,'length',L);
end
arc=spatial.arcAtApproach_m;
progress=[10;25];pos=zeros(2,3);
for i=1:2,pos(i,:)=mmra_speed_arc_position(geom{i},progress(i));end
[loser,cause]=mmra_coordination_dynamic_yielder( ...
    1,2,geom,progress,pos,[1;2],[15;15],arc,[0;0],0.5);
assert(loser==1 && strcmp(cause,'eta_priority'), ...
    'Earliest-to-conflict UAV must receive crossing priority.');
progress=[20;20];
for i=1:2,pos(i,:)=mmra_speed_arc_position(geom{i},progress(i));end
[loser,cause]=mmra_coordination_dynamic_yielder( ...
    1,2,geom,progress,pos,[2;1],[15;15],arc,[2;0],0.5);
assert(loser==2 && strcmp(cause,'yield_age'), ...
    'Near-tied ETA should credit previously yielding UAV.');

% 3) Full speed-feedback controller must accept the optional dynamic
% priority policy and still pass its independent exact interval audit.
dynamic=opt;dynamic.speedFeedbackLaunchTimes_s=[0;0];
dynamic.speedFeedbackPriorityPolicy='dynamic_eta';
dynamic.speedFeedbackConflictArc_m=arc;
r=mmra_schedule_speed_feedback(paths,dynamic);
assert(strcmp(r.priorityPolicy,'dynamic_eta') && ...
    r.dynamicPriorityDecisions>=1, ...
    'Dynamic priority must actually be evaluated at a crossing.');
if r.success
    assert(r.validation.safe && r.validation.complete && ...
        r.minSeparation>=dynamic.dSafe-dynamic.tol-1e-8, ...
        'Dynamic-priority trace was accepted without a safety audit.');
end

% 4) The new optimizer must never make a feasible legacy baseline WORSE
% under the fully defined V2 score; it may legitimately retain baseline.
base=mmra_schedule_speed_feedback(paths,opt);
answer=mmra_schedule_spatiotemporal_coordination(paths,opt);
assert(answer.coordination.numTrials>1 && ...
    answer.coordination.baselineNominal.numUnsafePairs==0, ...
    'V2 did not evaluate time-aware alternatives.');
if base.success
    assert(answer.success && answer.validation.safe && ...
        answer.validation.complete && ...
        answer.coordination.selectedScore<= ...
        answer.coordination.baselineScore+1e-8, ...
        'V2 selected a worse or unverified schedule than baseline.');
end

% 5) Completely disjoint parallel routes should launch together; the
% 3-second baseline stagger is unnecessary. Average completion is part
% of the objective even when all makespans are identical.
parallel={[-40 -30 20;40 -30 20],[-40 30 20;40 30 20]};
p=opt;
p.speedFeedbackLaunchInterval_s=3;
orig=mmra_schedule_speed_feedback(parallel,p);
co=mmra_schedule_spatiotemporal_coordination(parallel,p);
assert(orig.success && co.success && ...
    co.validation.safe && co.validation.complete && ...
    co.coordination.baselineNominal.numAlertPairs==0 && ...
    co.coordination.selectedScore<co.coordination.baselineScore-1e-6 && ...
    mean(co.completionTimes_s)<mean(orig.completionTimes_s)-1e-6, ...
    'V2 should avoid needless waits on disjoint air routes.');

% 6) Explicit user release times are locked unless override is requested.
p.speedFeedbackLaunchTimes_s=[2;6];
locked=mmra_schedule_spatiotemporal_coordination(parallel,p);
assert(locked.coordination.numTrials==1 && ...
    locked.coordination.fixedPresetTimes && ...
    isequal(locked.plannedLaunchTimes_s,[2;6]), ...
    'Explicit launch vector must be respected.');

% 7) Incompatible HOLD/HOLD common goals must never be marked feasible.
bad={[-40 0 20;40 0 20],[0 -40 20;40 0 20]};
invalid=mmra_schedule_spatiotemporal_coordination(bad,opt);
assert(~invalid.success && invalid.coordination.numFeasible==0 && ...
    invalid.coordination.selectedTrial==0, ...
    'Impossible occupied common goals were misclassified safe.');

fprintf(['MMRA spatiotemporal coordination tests: all assertions passed. ' ...
    'nominal_conflict=%d, dynamic_decisions=%d, ' ...
    'parallel_mean_finish=%.2f->%.2f s\n'], ...
    now.numUnsafePairs,r.dynamicPriorityDecisions, ...
    mean(orig.completionTimes_s),mean(co.completionTimes_s));
end
