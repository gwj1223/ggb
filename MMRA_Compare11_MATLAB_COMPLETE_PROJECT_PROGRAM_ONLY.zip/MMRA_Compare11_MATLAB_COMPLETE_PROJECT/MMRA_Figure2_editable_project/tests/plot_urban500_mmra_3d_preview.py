import check_urban500_mmra_geometry as q
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from matplotlib.colors import Normalize
B=q.B
fig=plt.figure(figsize=(16.8,8.5),facecolor='white')
colors=['#00b82e','#eac800','#ff2937','#bc48d8','#bd8000']
results=[]
for P in q.archived:
    pp=q.prune_visibility(P,q.B_inflated)
    sp,stat=q.adaptive_smooth(pp,q.B_inflated)
    results.append((pp,sp))
for j,label in enumerate(['BEFORE  |  RRT* + line shortcut','AFTER  |  Shared MMRA + adaptive Bezier']):
    ax=fig.add_subplot(1,2,j+1,projection='3d')
    ax.view_init(elev=29,azim=-68)
    for b in B:
        x0,x1,y0,y1,z0,z1=b
        v=np.array([[x0,y0,0],[x1,y0,0],[x1,y1,0],[x0,y1,0],
                    [x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1]])
        faces=[[v[k] for k in ids] for ids in [[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7],[4,5,6,7]]]
        c=plt.cm.viridis((z1-20)/155)
        ax.add_collection3d(Poly3DCollection(faces,facecolors=c,edgecolors=(.25,.28,.35,.4),linewidths=.2,alpha=.42))
    for k,(pr,sm) in enumerate(results):
        p=(pr if j==0 else sm)
        ax.plot(p[:,0],p[:,1],p[:,2],color=colors[k],lw=2.15 if j==0 else 2.6,alpha=1,label=f'UAV {k+1}')
        ax.scatter(p[0,0],p[0,1],p[0,2],s=22,c=colors[k],edgecolors='black',depthshade=False)
        ax.scatter(p[-1,0],p[-1,1],p[-1,2],s=22,marker='s',c=colors[k],edgecolors='black',depthshade=False)
    ax.set(xlim=(0,500),ylim=(0,500),zlim=(0,200),xlabel='X (m)',ylabel='Y (m)',zlabel='Z (m)')
    ax.set_box_aspect((1,1,.47))
    ax.set_title(label,fontsize=12,pad=18)
    if j==1: ax.legend(loc='upper right',bbox_to_anchor=(1.06,1),fontsize=9)
fig.suptitle('Urban500 V3 | saved routes | independent 3D geometry reference (NOT MATLAB execution)',fontsize=14)
fig.subplots_adjust(left=.01,right=.97,bottom=.02,top=.87,wspace=.0)
q.OUT.mkdir(parents=True,exist_ok=True)
fig.savefig(q.OUT/'urban500_v3_mmra_python_3d_comparison.png',dpi=185)
print(q.OUT/'urban500_v3_mmra_python_3d_comparison.png')
