function mmra_main_mountain_v26_tests()
%MMRA_MAIN_MOUNTAIN_V26_TESTS Regression + analytic-gradient checks.
fprintf('MMRA v2.6 parula main mountain tests: starting...\n');
[env,cfg,sched]=mmra_defaults('mountain_cluster_parula_v26_5km');
assert(isequal(env.boundsLo,[0 0 0]));
assert(isequal(env.boundsHi,[5000 5000 2000]));
assert(env.safetyMargin==50 && sched.dSafe==10 && ...
    sched.speed==15 && sched.speedFeedbackLaunchInterval_s==3);
assert(cfg.edgeResolution==cfg.riskCostResolution_m);
assert(size(env.peaks,1)==16 && size(env.peaks,2)==5);
assert(size(env.terrainRidges,1)==11 && ...
    size(env.terrainRidges,2)==6);
assert(size(env.terrainErosionGullies,1)==7 && ...
    size(env.terrainErosionGullies,2)==6);
assert(size(env.terrainMicroWaves,1)==7 && ...
    size(env.terrainMicroWaves,2)==4);
[x,y]=meshgrid(linspace(0,5000,101));
P=[x(:) y(:)];
[h,hx,hy]=mmra_terrain(P,env);
assert(all(isfinite(h)) && all(isfinite(hx)) && all(isfinite(hy)));
assert(min(h)>0 && max(h)+env.safetyMargin<2000, ...
    'Terrain needs to remain below the 2km ceiling with clearance.');
% Three finite-difference perturbation lengths across random map sites.
samples=[700 1100; 1850 1300; 2790 2110; 3940 3030; ...
         1090 3600; 4220 4100; 2450 2550];
for k=1:size(samples,1)
    p=samples(k,:);
    [~,px,py]=mmra_terrain(p,env);
    dh=0.05;
    fdX=(mmra_terrain(p+[dh 0],env)- ...
         mmra_terrain(p-[dh 0],env))/(2*dh);
    fdY=(mmra_terrain(p+[0 dh],env)- ...
         mmra_terrain(p-[0 dh],env))/(2*dh);
    assert(abs(px-fdX)<5e-5 && abs(py-fdY)<5e-5, ...
        'Terrain gradient differs from independent finite differences.');
end
% Collision queries MUST use the same oracle as the visual surface.
mid=[2440 1930]; hm=mmra_terrain(mid,env);
assert(~mmra_is_free([mid hm+env.safetyMargin-1],env));
assert(mmra_is_free([mid hm+env.safetyMargin+100],env));
for n=[5 10 20]
    [s,g]=mmra_5km_mission(env,n,26001,'cross_center');
    assert(all(mmra_is_free(s,env)) && all(mmra_is_free(g,env)), ...
        'Generated mission endpoints are not flyable.');
end
% Original baseline environments must be frozen for fair comparisons.
[old,~,~]=mmra_defaults('mountain_cluster_refined_5km');
[older,~,~]=mmra_defaults('mountain_cluster_5km');
assert(size(old.peaks,1)==12 && size(old.terrainRidges,1)==6);
assert(size(older.peaks,1)==12 && ...
    ~isfield(older,'terrainRidges'));
assert(norm(mmra_terrain(P,env)-mmra_terrain(P,old))>50);
fprintf('MMRA v2.6 tests passed. Elevation range: %.1f to %.1f m.\n', ...
    min(h),max(h));
end
