function mmra_rrt_threeobjective_tests()
%MMRA_RRT_THREEOBJECTIVE_TESTS Directed ascent, fused cost, tree consistency.
fprintf('MMRA v2.1 three-objective tests: starting...\n');
[~,cfg,~]=mmra_defaults('paper_gmm');
assert(strcmp(cfg.costMode,'length') && cfg.step==8 && ...
    cfg.edgeResolution==0.25,'Stable default must remain length/fixed8');
flat=struct('profile','fixture_flat','boundsLo',[0 0 0], ...
    'boundsHi',[60 60 30],'baseHeight',0,'peaks',zeros(0,5), ...
    'useRipples',false,'safetyMargin',5);
a=[0 0 6];b=[10 0 8];
test=cfg;test.costMode='length_risk_climb';
test.riskCostWeight=0.5;test.ascentCostWeight=0.5;
[j,L,r,A]=mmra_edge_objective(a,b,flat,test);
assert(abs(L-hypot(10,2))<1e-12 && abs(A-2)<1e-12);
assert(abs(j-(L+0.5*r+1))<1e-10);
[down,~,rDown,ADown]=mmra_edge_objective(b,a,flat,test);
assert(ADown==0 && abs(rDown-r)<1e-10);
assert(abs((j-down)-1)<1e-10, ...
    'Ascent is directed, unlike length and risk');
path=[0 0 6;5 0 9;10 0 7];
assert(mmra_path_ascent(path)==3);
assert(mmra_path_ascent(flipud(path))==2);
[ok,jFused,fused]=mmra_edge_eval(a,b,flat,test);
assert(ok && fused && abs(jFused-j)<1e-10);
old=test;old.costEvalMode='separate';
[ok2,jOld,fusedOld]=mmra_edge_eval(a,b,flat,old);
assert(ok2 && ~fusedOld && abs(jOld-jFused)<1e-10);
stepMismatch=test;stepMismatch.riskCostResolution_m=0.20;
[ok3,jStep,fusedStep]=mmra_edge_eval(a,b,flat,stepMismatch);
assert(ok3 && ~fusedStep);
assert(abs(jStep-mmra_edge_objective(a,b,flat,stepMismatch))<1e-10);
[bad,~,~]=mmra_edge_eval([0 0 4],b,flat,test);
assert(~bad,'Fused checker must not accept invalid start');
% No terrain sampling when objective is length-only or climb-only.
zero=test;zero.riskCostWeight=0;zero.ascentCostWeight=0;
base=cfg;base.maxIter=500;base.goalRadius=6;
base.prune=false;base.smooth=false;
qStart=[2 2 8];qGoal=[48 46 8];
rng(22001,'twister');[p0,s0]=mmra_rrtstar(qStart,qGoal,flat,base,false);
for i=1:3
    z=zero;
    if i==1,z.costMode='length_risk_climb';
    elseif i==2,z.costMode='length_risk';
    else,z.costMode='length_climb';end
    rng(22001,'twister');[pz,sz]=mmra_rrtstar( ...
        qStart,qGoal,flat,z,false);
    assert(s0.success && sz.success);
    assert(isequaln(p0,pz) && s0.firstIter==sz.firstIter && ...
        s0.accepted==sz.accepted && s0.rejected==sz.rejected, ...
        'Zero-weight modes must preserve v1.7 fixed8 geometry');
end
% Same-seed fused and v2.0 separate terrain sampling should yield same tree.
for i=1:2
    t=test;
    if i==1,t.costMode='length_risk';end
    t.maxIter=500;t.goalRadius=6;t.prune=false;t.smooth=false;
    rng(22001,'twister');[pf,sf]=mmra_rrtstar(qStart,qGoal,flat,t,false);
    t.costEvalMode='separate';
    rng(22001,'twister');[ps,ss]=mmra_rrtstar(qStart,qGoal,flat,t,false);
    assert(sf.success && ss.success && ...
        isequaln(pf,ps) && sf.firstIter==ss.firstIter, ...
        'Fusing check/integral changed path geometry');
    assert(sf.treeCostError<1e-7 && ss.treeCostError<1e-7);
    assert(abs(sf.pathObjective_m-(sf.pathLength+ ...
        sf.riskCostWeight*sf.pathRiskIntegral_m+ ...
        sf.ascentCostWeight*sf.pathAscent_m))<1e-7);
    assert(abs(sf.pathObjective_m-ss.pathObjective_m)<1e-7);
    assert(sf.fusedRiskEvaluations>0 && ss.fusedRiskEvaluations==0);
end
% Climb-only mode must be supported independently and checked after rewire.
c=cfg;c.costMode='length_climb';c.ascentCostWeight=0.5;
c.maxIter=500;c.goalRadius=6;c.prune=false;c.smooth=false;
rng(22001,'twister');[pc,sc]=mmra_rrtstar(qStart,qGoal,flat,c,false);
assert(sc.success && sc.treeCostError<1e-7);
assert(abs(sc.pathObjective_m-(sc.pathLength+ ...
    c.ascentCostWeight*sc.pathAscent_m))<1e-7);
assert(mmra_path_free(pc,flat,c.edgeResolution));
% Post-processed values must be recomputed for the FINAL output.
c.costMode='length_risk_climb';c.riskCostWeight=0.5;
c.prune=true;c.smooth=true;
rng(22001,'twister');[post,st]=mmra_plan_single( ...
    qStart,qGoal,flat,c,false);
assert(st.success && ~isempty(post));
assert(abs(st.finalAscent_m-mmra_path_ascent(post))<1e-10);
assert(abs(st.finalObjective_m-(st.pathLength+ ...
    c.riskCostWeight*st.finalRiskIntegral_m+ ...
    c.ascentCostWeight*st.finalAscent_m))<1e-7);
fprintf('MMRA v2.1 three-objective tests: all assertions passed.\n');
end
