function mmra_staggered_mountain_v27_tests()
%MMRA_STAGGERED_MOUNTAIN_V27_TESTS Geometry, safety and regression checks.
% Synthetic terrain regression; RRT* flight success still requires pilots.
fprintf('MMRA v2.7 staggered mountain terrain tests: starting...\n');
[env,cfg,sched]=mmra_defaults('mountain_cluster_staggered_v27_5km');
assert(isequal(env.boundsLo,[0 0 0]) && isequal(env.boundsHi,[5000 5000 2000]));
assert(env.safetyMargin==50 && sched.speed==15 && sched.dSafe==10);
assert(sched.speedFeedbackLaunchInterval_s==3);
assert(strcmp(cfg.costMode,'length_risk_climb'));
assert(size(env.peaks,1)==25 && size(env.peaks,2)==5);
assert(size(env.terrainRidges,1)==15 && size(env.terrainRidges,2)==6);
assert(size(env.terrainErosionGullies,1)==9 && ...
    size(env.terrainErosionGullies,2)==6);
assert(size(env.terrainMicroWaves,1)==7);
assert(all(env.terrainErosionGullies(:,1)>0) && ...
    all(env.terrainErosionGullies(:,1)<1));
assert(isequal(env.noFlyCylinders,zeros(0,5)));
[x,y]=meshgrid(linspace(0,5000,151));P=[x(:),y(:)];
[h,hx,hy]=mmra_terrain(P,env);
assert(all(isfinite(h)) && all(isfinite(hx)) && all(isfinite(hy)));
assert(min(h)>0 && max(h)+env.safetyMargin<2000, ...
    'Sampled terrain too high or below domain bottom.');
assert(max(h)>1250 && max(h)-median(h)>600, ...
    'The staggered map lost its prominent summit hierarchy.');
centerHeights=mmra_terrain([920 980; 3230 2760; 4240 3760],env);
assert(max(centerHeights)-min(centerHeights)>200, ...
    'Three primary summits do not differ sufficiently in altitude.');
% Check derivatives independently by symmetric finite differences.
samples=[700 1100;1850 1300;2790 2110;3940 3030; ...
    1090 3600;4220 4100;2450 2550;922 980;3240 2760];
for k=1:size(samples,1)
    pt=samples(k,:);dh=0.05;
    [~,px,py]=mmra_terrain(pt,env);
    dx=(mmra_terrain(pt+[dh 0],env)- ...
        mmra_terrain(pt-[dh 0],env))/(2*dh);
    dy=(mmra_terrain(pt+[0 dh],env)- ...
        mmra_terrain(pt-[0 dh],env))/(2*dh);
    assert(abs(px-dx)<5e-5 && abs(py-dy)<5e-5, ...
        'Analytic terrain gradient does not match finite differences.');
end
% The terrain oracle must also feed the original safety checker.
xy=[920 980];hh=mmra_terrain(xy,env);
assert(~mmra_is_free([xy hh+env.safetyMargin-1],env));
assert(mmra_is_free([xy hh+env.safetyMargin+50],env));
for U=[5 10 20]
    [starts,goals]=mmra_5km_mission(env,U,26001,'cross_center');
    assert(all(mmra_is_free(starts,env)) && ...
        all(mmra_is_free(goals,env)));
end
% All earlier profiles stay intact for repeatable comparison.
[v26,~,~]=mmra_defaults('mountain_cluster_parula_v26_5km');
[v25,~,~]=mmra_defaults('mountain_cluster_refined_5km');
assert(size(v26.peaks,1)==16 && size(v26.terrainRidges,1)==11);
assert(size(v25.peaks,1)==12 && size(v25.terrainRidges,1)==6);
assert(norm(mmra_terrain(P,env)-mmra_terrain(P,v26))>500);
fprintf('MMRA v2.7 terrain checks passed; sampled heights %.1f to %.1f m.\n', ...
    min(h),max(h));
end
