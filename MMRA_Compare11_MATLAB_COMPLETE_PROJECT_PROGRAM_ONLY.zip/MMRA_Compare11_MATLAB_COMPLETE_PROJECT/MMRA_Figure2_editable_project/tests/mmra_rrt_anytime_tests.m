function mmra_rrt_anytime_tests()
%MMRA_RRT_ANYTIME_TESTS Legacy regression + opt-in best-so-far invariants.
fprintf('MMRA RRT* anytime tests: starting...\n');
[~,cfg,~]=mmra_defaults('paper_gmm');
assert(~isfield(cfg,'rrtStopMode'), ...
    'Legacy defaults must not opt into the new planner');
flat=struct('profile','fixture_flat','boundsLo',[0 0 0], ...
    'boundsHi',[60 60 30],'baseHeight',0,'peaks',zeros(0,5), ...
    'useRipples',false,'safetyMargin',5);
a=[2 2 6.3];b=[48 46 6.3];
cfg.maxIter=320;
cfg.goalRadius=6;
cfg.prune=false;
cfg.smooth=false;
cfg.costMode='length_risk_climb';
cfg.riskCostBand_m=2;
cfg.riskCostResolution_m=0.25;
cfg.riskCostWeight=0.5;
cfg.ascentCostWeight=0.5;
cfg.wallBudget_s=Inf;

% An explicit legacy mode must reproduce the original default exactly.
rng(22001,'twister');
[legacy,old]=mmra_plan_single(a,b,flat,cfg,false);
explicit=cfg;explicit.rrtStopMode='first_feasible';
rng(22001,'twister');
[legacy2,old2]=mmra_plan_single(a,b,flat,explicit,false);
assert(isequaln(legacy,legacy2) && old.firstIter==old2.firstIter ...
    && old.pathObjective_m==old2.pathObjective_m && ...
    old.accepted==old2.accepted, ...
    'Opt-in switch changed default first-feasible behavior');
assert(old.success && old.treeCostError<1e-6, ...
    'Fixture did not produce a valid legacy path');

% Same-seed history up to first feasibility must be EXACTLY identical.
anycfg=cfg;anycfg.rrtStopMode='anytime';
rng(22001,'twister');
[better,st]=mmra_plan_single(a,b,flat,anycfg,false);
assert(st.success && st.firstIter==old.firstIter && ...
    isequaln(st.firstFeasiblePath,legacy), ...
    'Anytime search does not reproduce the first feasible baseline');
assert(abs(st.firstObjective_m-old.pathObjective_m)<1e-6, ...
    'The first feasible objective differs from the legacy planner');
assert(st.iterations==cfg.maxIter && st.firstIter<st.iterations, ...
    'Anytime planner stopped before its full iteration budget');
assert(st.pathObjective_m<=st.firstObjective_m+1e-7 && ...
    st.treeCostError<1e-6, ...
    'Anytime planner worsened objective or invalidated tree costs');
assert(mmra_path_free(better,flat,cfg.edgeResolution));
assert(abs(st.pathObjective_m-(st.pathLength+ ...
    cfg.riskCostWeight*st.pathRiskIntegral_m+ ...
    cfg.ascentCostWeight*st.pathAscent_m))<1e-6);
assert(numel(st.bestCostByIteration_m)==cfg.maxIter);
assert(all(isnan(st.bestCostByIteration_m(1:st.firstIter-1))));
curve=st.bestCostByIteration_m(st.firstIter:end);
assert(all(isfinite(curve)) && all(diff(curve)<=1e-7), ...
    'Best objective history is not monotone non-increasing');
assert(abs(curve(1)-st.firstObjective_m)<1e-7 && ...
    abs(curve(end)-st.pathObjective_m)<1e-7);

% Exactly the same budget as the first feasible iteration: no improvement
% should be fabricated, and the path should still match legacy.
shortcfg=anycfg;shortcfg.maxIter=old.firstIter;
rng(22001,'twister');
[pShort,sShort]=mmra_plan_single(a,b,flat,shortcfg,false);
assert(sShort.success && isequaln(pShort,legacy) && ...
    abs(sShort.pathObjective_m-old.pathObjective_m)<1e-6);

% Repeating the fixed-iteration search with the same seed is deterministic.
rng(22001,'twister');
[pRepeat,sRepeat]=mmra_plan_single(a,b,flat,anycfg,false);
assert(isequaln(better,pRepeat) && ...
    isequaln(st.bestCostByIteration_m,sRepeat.bestCostByIteration_m) ...
    && st.improvementCount==sRepeat.improvementCount, ...
    'Fixed-seed anytime RRT* was not reproducible');

% No fake route on an exhausted iteration budget.
none=anycfg;none.maxIter=0;
[pNone,sNone]=mmra_plan_single(a,b,flat,none,false);
assert(isempty(pNone) && ~sNone.success && ...
    strcmp(sNone.reason,'iteration_budget_exhausted'));
fprintf(['MMRA RRT* anytime tests: all assertions passed. ' ...
    'first=%d final=%d gain=%.2f%%\n'], ...
    st.firstIter,st.iterations,st.improvementPct);
end
