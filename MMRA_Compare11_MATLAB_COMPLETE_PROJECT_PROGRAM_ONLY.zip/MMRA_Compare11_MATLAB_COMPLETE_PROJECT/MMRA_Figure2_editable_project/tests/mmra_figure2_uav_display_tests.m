function mmra_figure2_uav_display_tests()
%MMRA_FIGURE2_UAV_DISPLAY_TESTS Non-destructive display-only checks.
fprintf('MMRA Figure 2 UAV markers visibility tests: starting...\n');
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'));
tempMat=[tempname '.mat'];
cleanupFile=onCleanup(@()deleteIfExists(tempMat));
assert(~mmra_figure2_uav_display_settings([],tempMat));
mmra_figure2_uav_display_settings(true,tempMat);
assert(mmra_figure2_uav_display_settings([],tempMat));
mmra_figure2_uav_display_settings(false,tempMat);
assert(~mmra_figure2_uav_display_settings([],tempMat));

[env,~,~]=mmra_defaults('mountain_cluster_figure2_custom_5km');
[starts,goals]=mmra_5km_mission(env,5,24001,'cross_center');
originalStarts=starts;originalGoals=goals;
for flag=[false,true]
    fig=mmra_plot_single_main_map(env,starts,goals,flag);
    ax=findall(fig,'Type','axes');
    assert(~isempty(ax),'Terrain axes missing.');
    s=findall(fig,'Tag','MMRA_UAV_STARTS');
    g=findall(fig,'Tag','MMRA_UAV_GOALS');
    lines=findall(fig,'Tag','MMRA_UAV_ASSIGNMENT');
    assert(numel(s)==1 && numel(g)==1 && numel(lines)==5);
    expected='off';if flag,expected='on';end
    assert(strcmp(get(s,'Visible'),expected));
    assert(strcmp(get(g,'Visible'),expected));
    assert(all(arrayfun(@(h)strcmp(get(h,'Visible'),expected),lines)));
    assert(isequal(starts,originalStarts) && isequal(goals,originalGoals), ...
        'Display must not alter mission data.');
    close(fig);
end
clear cleanupFile;
fprintf('MMRA Figure 2 UAV markers visibility tests: PASSED.\n');
end

function deleteIfExists(file)
if exist(file,'file')==2,delete(file);end
end
