function mmra_sched_window_tests()
%MMRA_SCHED_WINDOW_TESTS Independent geometry/grid/fallback regressions.
fprintf('MMRA endpoint-aware conflict-window tests: starting...\n');
[~,~,opt]=mmra_defaults('paper_gmm');
opt.speed=10;opt.dSafe=2;opt.tol=1e-8;
opt.maxDelay=5;opt.delayStep=0.5;
opt.startPolicy='inactive';opt.endPolicy='inactive';
A=[0 0 5;10 0 5];B=[5 -5 5;5 5 5];
[f,detail]=mmra_sched_pair_windows(A,B,opt);
K=round(opt.maxDelay/opt.delayStep);
assert(f(K+1) && detail.closePiecePairs>=1);
assert(~f(1) && ~f(end),'Distant flight starts must be safe');
for k=-K:K
    tauA=max(0,-k*opt.delayStep);
    tauB=max(0,k*opt.delayStep);
    [~,~,conflict]=mmra_pair_minsep(A,B,tauA,tauB,opt);
    assert(~conflict || f(k+K+1), ...
        'Forbidden windows missed a real continuous-time collision.');
end
% HOLD includes terminal occupancy; asymmetric forbidden windows capture
% a route crossing another vehicle's occupied arrival point.
opt.startPolicy='hold';opt.endPolicy='hold';
C=[5 20 5;5 0 5];
[fw,~]=mmra_sched_pair_windows(A,C,opt);
assert(fw(K+1-4),'Landing before another route passes can be unsafe');
assert(~fw(K+1+4),'Landing after the other route passes can be safe');
for k=-K:K
    tauA=max(0,-k*opt.delayStep);
    tauC=max(0,k*opt.delayStep);
    [~,~,conflict]=mmra_pair_minsep(A,C,tauA,tauC,opt);
    assert(~conflict || fw(k+K+1), ...
        'Endpoint hold safety was omitted from forbidden windows.');
end
% Shared held destination is a genuine impossibility for all delays.
D=[20 0 5;10 10 5]; E=[0 20 5;10 10 5];
[g,detail]=mmra_sched_pair_windows(D,E,opt);
assert(all(g) && detail.staticEndpointNoGo);
notPossible=mmra_schedule_eventwindow({D,E},opt);
assert(~notPossible.success && ...
    notPossible.eventNoCompatiblePairs>=1);
% Independent randomized polyline checks: every TRUE collision at a grid
% offset must be present in the conservative window cache.
rng(73241,'twister');
for rep=1:8
    u=rand(4,3)*16;v=rand(4,3)*16;
    u(:,3)=4+u(:,3)*0.2;v(:,3)=4+v(:,3)*0.2;
    if mod(rep,2)==0
        opt.startPolicy='inactive';opt.endPolicy='inactive';
    else
        opt.startPolicy='hold';opt.endPolicy='hold';
    end
    [g,~]=mmra_sched_pair_windows(u,v,opt);
    for k=-K:K
        da=max(0,-k*opt.delayStep);db=max(0,k*opt.delayStep);
        [~,~,collide]=mmra_pair_minsep(u,v,da,db,opt);
        assert(~collide || g(k+K+1), ...
            'Randomized pair has a missed forbidden offset.');
    end
end
% Regret-free fallback on the original scheduler under EXACT same rules.
opt.startPolicy='inactive';opt.endPolicy='inactive';
paths={A,B,[0 10 5;10 10 5]};
base=mmra_schedule_conflict_aware(paths,opt);
new=mmra_schedule_eventwindow(paths,opt);
assert(~base.success || (new.success && ...
    new.makespan<=base.makespan+1e-8));
if new.success
    assert(new.postConflicts==0 && ...
        new.minSeparation>=opt.dSafe-opt.tol-1e-8);
end
assert(new.eventExpandedNodes<=opt.eventMaxExpandedNodes);
assert(strcmp(new.mode,'eventwindow_repair'));
% Direct opt-in branch inside end-to-end engine, no extra RRT* changes.
env=struct('profile','paper_gmm','boundsLo',[0 0 0], ...
    'boundsHi',[30 30 30],'baseHeight',0,'peaks',zeros(0,5), ...
    'useRipples',false,'safetyMargin',0);
[~,cfg,~]=mmra_defaults('paper_gmm');
cfg.maxIter=400;cfg.prune=false;cfg.smooth=false;
opt.mode='eventwindow_repair';
rng(23,'twister');res=mmra_run_case([2 2 7],[27 27 7],[], ...
    env,cfg,opt,false);
assert(res.success && strcmp(res.scheduler.mode,'eventwindow_repair'));
fprintf('MMRA endpoint-aware conflict-window tests: all assertions passed.\n');
end
