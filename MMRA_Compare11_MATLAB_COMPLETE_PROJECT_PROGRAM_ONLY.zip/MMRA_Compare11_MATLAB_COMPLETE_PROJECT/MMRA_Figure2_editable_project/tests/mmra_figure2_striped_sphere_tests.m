function mmra_figure2_striped_sphere_tests()
%MMRA_FIGURE2_STRIPED_SPHERE_TESTS Model and graphics regression checks.
fprintf('Figure 2 large striped moving-sphere tests: starting...\n');
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'src'));
[env,~,~]=mmra_defaults('mountain_cluster_figure2_custom_5km');
env=mmra_figure2_add_static_obstacles(env);
[original,~]=mmra_figure2_dynamic_obstacles(env);
[tuned,report]=mmra_figure2_tune_dynamic_obstacles(original,env);
assert(numel(tuned)==3 && report.changedCount==sum(report.changed));
assert(all([tuned.radius_m]>=10 & [tuned.radius_m]<=200));
for k=1:3
    assert(isequal(tuned(k).position_m(:,1:2), ...
        original(k).position_m(:,1:2)), ...
        'Auto tune changed XY trajectory.');
    assert(isequal(tuned(k).time_s,original(k).time_s), ...
        'Auto tune changed absolute movement times.');
    if report.changed(k)
        assert(tuned(k).radius_m>original(k).radius_m, ...
            'Adjusted sphere radius did not increase.');
        assert(all(tuned(k).position_m(:,3)<original(k).position_m(:,3)), ...
            'Adjusted sphere was not lowered.');
    end
end
mmra_figure2_validate_dynamic_obstacles(tuned,env,true);
fig=figure('Visible','off');
cleanup=onCleanup(@()close(fig)); %#ok<NASGU>
ax=axes('Parent',fig);
hold(ax,'on');
h=mmra_figure2_plot_dynamic_overlay(ax,tuned,120,[]);
assert(numel(h.sphere)==3);
for k=1:3
    assert(ishandle(h.sphere{k}),'Missing striped sphere surface.');
    rgb=get(h.sphere{k},'CData');
    assert(ndims(rgb)==3 && size(rgb,3)==3, ...
        'Sphere must have truecolor RGB stripes.');
    assert(max(rgb(:))<=1 && min(rgb(:))>=0);
    assert(any(abs(diff(rgb(:,:,1),1,1))>0.1,'all'), ...
        'Sphere is not visibly striped.');
    x=get(h.sphere{k},'XData');
    assert(abs((max(x(:))-min(x(:)))-2*tuned(k).radius_m/1000)<.002, ...
        'Rendered sphere size does not match collision radius.');
end
% Verify time changes move the center without losing stripe colors.
rgb1=get(h.sphere{1},'CData');
h=mmra_figure2_plot_dynamic_overlay(ax,tuned,150,h);
assert(isequal(get(h.sphere{1},'CData'),rgb1), ...
    'Stripe pattern was erased when updating the animation.');
fprintf('Striped sphere tests: PASSED, adjusted=%d/3.\n', ...
    report.changedCount);
end
