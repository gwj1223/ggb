#!/usr/bin/env python3
"""Static/mathematical QA only; does NOT run or parse MATLAB semantics."""
from pathlib import Path
import math
import re
import random

root=Path(__file__).resolve().parents[1]
src=root/'src'
files=list(src.glob('*.m'))
assert len(files)>=16
# MATLAB first function name should match filename.
for p in files:
    raw=p.read_text('utf-8')
    m=re.search(r'^function\s+(?:\[[^]]+\]|[A-Za-z_]\w*)\s*=\s*([A-Za-z_]\w*)\s*\(|^function\s+([A-Za-z_]\w*)\s*\(',raw,re.M)
    assert m, f'No visible top-level function: {p.name}'
    assert (m.group(1) or m.group(2))==p.stem, f'Wrong function name: {p.name}'
    assert raw.rstrip().endswith('end'),f'File missing trailing end: {p.name}'

assert 'getTerrainHeight(' not in '\n'.join(x.read_text('utf-8') for x in files)
assert 'costs(children)=costs(children)+delta;' in (src/'mmra_rrtstar.m').read_text('utf-8')
assert 'out.reason=\'delay_bound_exceeded_or_infeasible\'' in (src/'mmra_schedule.m').read_text('utf-8')
assert "'postConflicts',NaN" in (src/'mmra_schedule.m').read_text('utf-8')

P=[(42,35,42,12,10),(38,62,55,10,14),(30,50,76,14,8),
   (28,76,30,9,12),(18,22,70,11,11)]
def terrain(x,y):
    h=2.;gx=0.;gy=0.
    for a,mx,my,sx,sy in P:
        e=a*math.exp(-0.5*((x-mx)**2/sx**2+(y-my)**2/sy**2))
        h+=e;gx-=e*(x-mx)/sx**2;gy-=e*(y-my)/sy**2
    return h,gx,gy
random.seed(2026)
maxdiff=0.
for _ in range(200):
    x=random.uniform(2,98);y=random.uniform(2,98);h,gx,gy=terrain(x,y)
    eps=1e-5
    numx=(terrain(x+eps,y)[0]-terrain(x-eps,y)[0])/(2*eps)
    numy=(terrain(x,y+eps)[0]-terrain(x,y-eps)[0])/(2*eps)
    maxdiff=max(maxdiff,abs(gx-numx),abs(gy-numy))
assert maxdiff<1e-7

# Exact relative-minimum test: paths collide at t=.5; sampling at t=0,.9
# misses a conflict under a 1-m threshold.
a0=(0.,0.);a1=(10.,0.);b0=(5.,-5.);b1=(5.,5.)
def dist(t):
    return math.hypot((a0[0]+(a1[0]-a0[0])*t)-(b0[0]+(b1[0]-b0[0])*t),
                      (a0[1]+(a1[1]-a0[1])*t)-(b0[1]+(b1[1]-b0[1])*t))
assert dist(0.5)==0
assert dist(0)>1 and dist(0.9)>1
r0=(a0[0]-b0[0],a0[1]-b0[1])
dr=((a1[0]-b1[0])-r0[0],(a1[1]-b1[1])-r0[1])
tstar=max(0,min(1,-(r0[0]*dr[0]+r0[1]*dr[1])/(dr[0]**2+dr[1]**2)))
assert abs(tstar-.5)<1e-12 and dist(tstar)<1e-12

print(f'PASS static function naming checks: {len(files)} core MATLAB files')
print(f'PASS independent GMM gradient finite-difference check (max error {maxdiff:.2e})')
print('PASS continuous polygonal crossing example; coarse 0.9 s grid misses collision')
print('NOT RUN: MATLAB interpreter, MATLAB regression tests, paper experiments')
