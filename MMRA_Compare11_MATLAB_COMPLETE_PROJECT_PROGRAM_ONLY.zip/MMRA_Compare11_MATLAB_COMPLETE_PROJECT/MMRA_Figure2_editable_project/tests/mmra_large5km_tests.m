function mmra_large5km_tests()
%MMRA_LARGE5KM_TESTS Unit checks without running an entire 20-UAV RRT*.
fprintf('MMRA v2.3 5 km domain tests: starting...\n');
[b,oldCfg,oldOpt]=mmra_defaults('paper_gmm'); %#ok<ASGLU>
[e,c,o]=mmra_defaults('paper_gmm_5km');
assert(isequal(e.boundsLo,[0 0 0]));
assert(isequal(e.boundsHi,[5000 5000 2000]));
assert(c.step>oldCfg.step && c.edgeResolution>oldCfg.edgeResolution);
assert(o.speed==15 && o.dSafe==10 && ...
    o.speedFeedbackLaunchInterval_s>0);
assert(oldOpt.speedFeedbackLaunchInterval_s==0);
assert(isequal(b.boundsHi,[100 100 80]));
P=[10 20;50 60;90 80];
[h0,hx0,hy0]=mmra_terrain(P,b);
[h,hx,hy]=mmra_terrain(P*50,e);
assert(max(abs(h-20*h0))<1e-8);
assert(max(abs(hx-(20/50)*hx0))<1e-8);
assert(max(abs(hy-(20/50)*hy0))<1e-8);
[starts,goals]=mmra_5km_mission(e,20,23001,'distributed');
assert(size(starts,1)==20 && size(goals,2)==3);
assert(all(mmra_is_free(starts,e)) && all(mmra_is_free(goals,e)));
[se,ge]=mmra_5km_mission(e,20,23001,'cross_center');
assert(all(mmra_is_free(se,e)) && all(mmra_is_free(ge,e)));
[e2,~,~]=mmra_defaults('legacy20_sine_5km');
assert(all(e2.boundsHi==[5000 5000 2000]));
% Prove the new scheduled release actually holds a UAV at its start while
% permitting another to move, without disabling occupied-start checks.
q=o;q.speedFeedbackMaxTime_s=60;
paths={[0 0 900; 150 0 900], ...
       [0 100 900; 150 100 900]};
z=mmra_schedule_speed_feedback(paths,q);
assert(z.success && z.validation.safe && z.validation.complete);
assert(isequal(sort(z.plannedLaunchTimes_s),[0;3]));
[~,waiting]=max(z.plannedLaunchTimes_s);
early=z.trace.time_s<3-1e-9;
assert(all(abs(z.trace.progress_m(early,waiting))<1e-8));
assert(z.validation.minSeparation>=o.dSafe-o.tol-1e-8);
assert(all(z.actualLaunchTimes_s>=z.plannedLaunchTimes_s-1e-8));
% Fail early, not with an out-of-memory allocation of 5 km voxels.
caught=false;
try
    mmra_build_grid(e,5);
catch ex
    caught=strcmp(ex.identifier,'MMRA:GridTooLarge');
end
assert(caught,'Wide-area voxel grid must be safely rejected.');
fprintf('MMRA v2.3 5 km domain tests: all assertions passed.\n');
end
