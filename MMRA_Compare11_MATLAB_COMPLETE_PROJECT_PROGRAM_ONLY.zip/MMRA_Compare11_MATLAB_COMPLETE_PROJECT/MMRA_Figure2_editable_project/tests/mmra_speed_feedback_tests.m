function mmra_speed_feedback_tests()
%MMRA_SPEED_FEEDBACK_TESTS Deterministic DEVELOPMENT regressions.
% Success asserts are about ideal fixed-polyline speed commands, NOT real
% UAV flight certification or 20-UAV success claims.
fprintf('MMRA v2.2 speed-feedback tests: starting...\n');
[~,~,o]=mmra_defaults('paper_gmm');
o.mode='speed_feedback';o.speed=15;o.dSafe=10;
o.startPolicy='hold';o.endPolicy='hold';
o.speedFeedbackMaxTime_s=140;

% Two orthogonal routes would collide at the center if both accelerate.
a=[-40 0 20;40 0 20];b=[0 -40 20;0 40 20];
x=mmra_schedule_speed_feedback({a,b},o);
assert(x.success, 'Predictive controller failed a simple two-way crossing.');
assert(x.validation.safe && x.validation.complete && ...
    x.validation.postConflicts==0 && ...
    x.validation.minSeparation>=o.dSafe-o.tol-1e-8);
assert(x.yieldSteps>0, 'Crossing must activate predictive yielding.');
assert(all(abs(x.trace.progress_m(end,:) - [80 80])<1e-5));

% Convoy: front UAV is capped at 5 m/s, behind UAV at 15 m/s. Dynamic
% yielding must handle closing distance without changing either path.
y=o;y.speedFeedbackSpeedCaps_mps=[5;15];
lead=[15 0 20;105 0 20];follow=[0 0 20;75 0 20];
f=mmra_schedule_speed_feedback({lead,follow},y);
assert(f.success, 'Rear-aircraft feedback failed a solvable convoy.');
assert(f.yieldSteps>0 && f.validation.minSeparation>=o.dSafe-1e-7);

% No conflict: never yield and reach all endpoints.
c={[0 -25 20;65 -25 20], ...
   [0 0 20;65 0 20], ...
   [0 25 20;65 25 20]};
z=mmra_schedule_speed_feedback(c,o);
assert(z.success && z.yieldSteps==0 && z.validation.safe);

% Already unsafe stationary launch sites must fail without pretending to
% execute a safe trace. Holding shared terminal goal is also impossible.
badStarts={[-20 0 20;40 0 20],[-17 0 20;40 20 20]};
bad=mmra_schedule_speed_feedback(badStarts,o);
assert(~bad.success && strcmp(bad.reason,'unsafe_initial_held_positions'));
badGoals={[-40 0 20;40 0 20],[0 -40 20;40 0 20]};
bad=mmra_schedule_speed_feedback(badGoals,o);
assert(~bad.success && strcmp(bad.reason,'incompatible_held_terminal_goals'));

% Independent verifier MUST reject a mid-step collision that both endpoint
% snapshots would miss. Test with acceleration/slew limits deliberately
% large enough that ONLY the separation check should fail.
p=o;p.dSafe=1;p.speedFeedbackAccel_mps2=100;
p.speedFeedbackDecel_mps2=100;
trace=struct('time_s',[0;1], ...
    'progress_m',[0 0;10 10], ...
    'speedCaps_mps',[15;15]);
q=mmra_verify_speed_trace({[-5 0 20;5 0 20], ...
    [0 -5 20;0 5 20]},trace,p);
assert(~q.safe && q.postConflicts==1 && q.minSeparation<1e-7, ...
    'Continuous-time crossing escaped independent verification.');

% Verification also splits a control tick at intermediate polyline vertex.
q2=mmra_verify_speed_trace({[0 0 20;5 0 20;5 5 20], ...
    [5 3 20;5 -3 20]},struct('time_s',[0;1], ...
    'progress_m',[0 0;10 6], ...
    'speedCaps_mps',[15;15]),p);
assert(~q2.safe && q2.minSeparation<1e-7, ...
    'Geometry vertex crossing escaped independent verification.');
% Scalar-condition regression: multi-UAV progress is a 2D matrix.
% A NaN anywhere must be rejected cleanly instead of crashing a || test.
badTrace=struct('time_s',[0;1], ...
    'progress_m',[0 0;NaN 0], ...
    'speedCaps_mps',[15;15]);
badAudit=mmra_verify_speed_trace({a,b},badTrace,o);
assert(~badAudit.safe && strcmp(badAudit.reason,'invalid_trace'), ...
    'Nonfinite two-UAV progress must return invalid_trace.');

fprintf('MMRA v2.2 speed-feedback tests: all assertions passed.\n');
end
