function mmra_static_obstacle_tests()
%MMRA_STATIC_OBSTACLE_TESTS Exact crossing, tangency, overflight, map checks.
fprintf('MMRA static NFZ + box geometry tests: starting...\n');
[env,cfg,~]=mmra_defaults('mountain_cluster_figure2_custom_5km');
% Analytic box tests with no cylinder: a long chord crosses a thin box.
env.noFlyCylinders=zeros(0,5);
env.staticBoxes=[900 1200 1800 2150 0 1650];
env.staticBoxBuffer_m=20;
a=[500 2000 1500];b=[1500 2000 1500];
assert(all(mmra_no_fly_free([a;b],env)), ...
    'Both chord endpoints should be outside the obstacle.');
assert(~mmra_no_fly_segment_free(a,b,env), ...
    'Analytic box intersection missed an interior segment crossing.');
assert(~mmra_edge_free(a,b,env,500), ...
    'Planner edge rejected only at sampled points, not exact crossing.');
[ok,~,~]=mmra_edge_eval(a,b,env,cfg);
assert(~ok,'Fused edge evaluation missed the box.');
assert(mmra_no_fly_segment_free([500 2000 1750], ...
    [1500 2000 1750],env),'Overflight should be allowed.');
assert(~mmra_no_fly_segment_free([880 1700 1400], ...
    [880 2250 1400],env), 'Box margin tangency must be forbidden.');
assert(mmra_no_fly_segment_free([500 1700 1400], ...
    [700 1700 1400],env),'Distant chord false positive.');
% Original cylinder checking must remain exact without any boxes.
env.staticBoxes=zeros(0,6);
env.noFlyCylinders=[2500 2500 320 0 2000];
env.noFlyBuffer_m=35;
assert(~mmra_no_fly_segment_free([2000 2500 1600], ...
    [3000 2500 1600],env));
assert(mmra_no_fly_segment_free([2000 3000 1600], ...
    [3000 3000 1600],env));
% Current saved Figure 2 scene has 3 NFZs and NO buildings.
[env,~,~]=mmra_defaults('mountain_cluster_figure2_custom_5km');
base=env;
env=mmra_figure2_add_static_obstacles(env);
assert(numel(env.noFlyCylinders)==15 && ...
    isequal(size(env.staticBoxes),[0 6]));
assert(isequal(env.peaks,base.peaks) && ...
    isequal(env.terrainRidges,base.terrainRidges), ...
    'Obstacle overlay must not change saved terrain.');
[st,go]=mmra_5km_mission(env,20,24001,'cross_center');
assert(all(mmra_is_free([st;go],env)), ...
    'A mission endpoint is placed inside a static exclusion.');
assert(mmra_risk_density([2500 2500 1500],env,75)>=0);
fprintf('Static exclusions: 3 cylinders, 0 boxes; 20-UAV endpoints safe.\n');
fprintf('MMRA static obstacle tests: all assertions passed.\n');
end
