#!/usr/bin/env python3
"""Independent static/fixture QA; DOES NOT execute MATLAB programs."""
from pathlib import Path
import re
import hashlib
import numpy as np
root=Path(__file__).resolve().parent.parent
files={
    'guard':root/'src/mmra_guarded_select.m',
    'wrapper':root/'src/mmra_guarded_plan_single.m',
    'plan':root/'src/mmra_plan_single.m',
    'script':root/'examples/run_guarded_sc_final_eval.m',
    'test':root/'tests/mmra_run_tests.m'
}
for name,p in files.items():
    assert p.exists(),(name,p)
    assert 'end' in p.read_text(encoding='utf-8'),name
select=files['guard'].read_text(encoding='utf-8')
for important in ['mmra_path_free(path,env,cfg.guardFineResolution)',
                  'sClear >= bClear-cfg.guardMaxClearLoss_m',
                  'sLength < bLength-cfg.guardPathTolerance_m',
                  'st.success=false',
                  'meta.ChosenMode=\'legacy\'']:
    assert important in select,important
wrap=files['wrapper'].read_text(encoding='utf-8')
for important in ["legacyCfg.apfMode='legacy'", "scCfg.apfMode='sc_apf'", 
                  'stateBefore=rng','stateAfterLegacy=rng',
                  'rng(stateBefore)','rng(stateAfterLegacy)',
                  'st.total_s=toc(wholeTimer)']:
    assert important in wrap,important
entry=files['script'].read_text(encoding='utf-8')
for important in ['16001:16050','19001:19030','mmra_plan_single(',
                  'guarded_sc_trials.csv','guarded_sc_invariant_checks.csv',
                  'callWall_s=toc(perCall)', 'SUCCESS: ALL INVARIANTS CHECKED']:
    assert important in entry,important
# Mathematical spot checks for test fixtures, independent from MATLAB.
def metrics(path,peaks=(),resolution=0.1):
    path=np.asarray(path,dtype=float)
    pts=[]
    for a,b in zip(path[:-1],path[1:]):
        n=max(1,int(np.ceil(np.linalg.norm(b-a)/resolution)))
        t=np.linspace(0,1,n+1)[:,None]
        pts.append(a+t*(b-a))
    pts=np.vstack(pts)
    h=np.zeros(len(pts))
    for A,mx,my,sx,sy in peaks:
        h+=A*np.exp(-.5*((pts[:,0]-mx)**2/sx**2+(pts[:,1]-my)**2/sy**2))
    return float(np.min(pts[:,2]-h)),float(np.linalg.norm(np.diff(path,axis=0),axis=1).sum())
base_short=[(2,2,7),(15,8,7),(27,27,7)]
sc_short=[(2,2,7),(27,27,7)]
bm,bl=metrics(base_short);sm,sl=metrics(sc_short)
assert sm>=bm-0.25 and sl<bl-1e-7
base_detour=[(2,2,7),(2,20,7),(27,27,7)]
sc_invalid=[(2,2,7),(15,15,1),(27,27,7)]
_,_=metrics(base_detour,[(5,15,15,1,1)])
assert metrics(sc_invalid,[(5,15,15,1,1)])[0]<0
base_long=[(2,2,7),(2,27,7),(27,27,7)]
sc_low=[(2,2,7),(15,15,6),(27,27,7)]
bm,bl=metrics(base_long);sm,sl=metrics(sc_low)
assert sl<bl and sm<bm-0.25
print('PASS v1.7 static wiring and independent geometric fixture calculations')
print('NOT RUN: MATLAB function execution and full planning experiments')
