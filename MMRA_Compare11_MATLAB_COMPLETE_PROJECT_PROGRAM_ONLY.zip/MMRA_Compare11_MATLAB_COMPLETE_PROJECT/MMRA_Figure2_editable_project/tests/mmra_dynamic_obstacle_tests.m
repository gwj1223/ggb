function mmra_dynamic_obstacle_tests()
%MMRA_DYNAMIC_OBSTACLE_TESTS Deterministic, model-level DEV regressions.
% Run in MATLAB: run('run_dynamic_obstacle_tests.m').
% This is NOT a real-flight safety certificate.
fprintf('MMRA predicted moving-obstacle tests: starting...\n');
[~,~,o]=mmra_defaults('paper_gmm');
o.speedFeedbackMaxTime_s=120;
o.speedFeedbackMaxStall_s=25;
o.speedFeedbackLaunchInterval_s=0;
o.speedFeedbackDroneRadius_m=1;
o.speedFeedbackObstacleGuard_m=2;
P={[-90 0 200;90 0 200]};
ob=struct('name','crossing_obstacle', ...
    'time_s',[0;2;14], ...
    'position_m',[0 -60 200;0 -60 200;0 60 200], ...
    'radius_m',10);
ob=mmra_dynamic_obstacles_prepare(ob);
assert(abs(ob.maxSpeed_mps-10)<1e-9);
assert(norm(mmra_dynamic_obstacle_position(ob,8)-[0 0 200])<1e-10);
assert(norm(mmra_dynamic_obstacle_position(ob,20)-[0 60 200])<1e-10);

% Without moving-obstacle control, the NOMINAL trajectory would collide.
base=mmra_schedule_speed_feedback(P,o);
assert(base.success && base.validation.safe);
a0=mmra_verify_dynamic_obstacles(P,base.trace,o,ob);
assert(~a0.safe && a0.conflictingPairs==1 && a0.minClearance_m<0, ...
    'The unprotected nominal flight must encounter the moving obstacle.');

% Same path; moving-obstacle prediction + speed yielding + exact shield.
o.speedFeedbackDynamicObstacles=ob;
y=mmra_schedule_speed_feedback(P,o);
assert(y.success, ...
    ['The moving-obstacle yielding test failed: ' y.reason]);
assert(y.obstacleYieldSteps>0, ...
    'The dynamic obstacle must trigger actual predictive yielding.');
assert(y.validation.safe && y.validation.complete && ...
    isfield(y.validation,'dynamicObstacles') && ...
    y.validation.dynamicObstacles.safe && ...
    y.obstaclePostConflicts==0 && y.obstacleMinClearance_m>=-o.tol, ...
    'A completed dynamic-obstacle flight must have verified clearance.');
assert(y.makespan>=base.makespan, ...
    'Yielding should not finish before the nominal max-speed flight.');

% Analytical closest approach MUST catch a BETWEEN-TICK collision that
% both endpoint snapshots miss. The obstacle center crosses at t=0.5.
opt2=o;opt2.speedFeedbackDroneRadius_m=0;
opt2.speedFeedbackObstacleGuard_m=0;
mid=struct('name','mid_tick','time_s',[0;1], ...
    'position_m',[0 -5 200;0 5 200],'radius_m',0.5);
trace=struct('time_s',[0;1],'progress_m',[0;10]);
a1=mmra_verify_dynamic_obstacles({[-5 0 200;5 0 200]},trace,opt2,mid);
assert(~a1.safe && a1.conflictingPairs==1 && ...
    a1.minCenterDistance_m<1e-8 && ...
    abs(a1.firstConflictTime_s-0.5)<1e-8, ...
    'Independent verifier missed a between-tick obstacle collision.');

% Static unavoidable obstruction: controller must fail SAFE; no fabricated
% completion and no executed unsafe step.
blocked=struct('name','permanent_block', ...
    'time_s',[0;20], ...
    'position_m',[0 0 200;0 0 200],'radius_m',15);
b=o;b.speedFeedbackDynamicObstacles=blocked;
b.speedFeedbackMaxTime_s=50;b.speedFeedbackMaxStall_s=4;
z=mmra_schedule_speed_feedback({[-50 0 200;50 0 200]},b);
assert(~z.success && z.validation.safe && ...
    z.validation.dynamicObstacles.safe && ...
    z.obstaclePostConflicts==0, ...
    'Permanently blocked path must fail safely, without crossing sphere.');

% Unrecoverably unsafe held start is detected before any movement.
startOb=struct('name','start_overlap', ...
    'time_s',[0;2],'position_m',[-50 0 200;-50 0 200], ...
    'radius_m',5);
b.speedFeedbackDynamicObstacles=startOb;
q=mmra_schedule_speed_feedback({[-50 0 200;50 0 200]},b);
assert(~q.success && strcmp(q.reason, ...
    'unsafe_initial_dynamic_obstacle_overlap'));

% Legacy mode with empty dynamic obstacles must remain reproducible.
unset=o;unset=rmfield(unset,'speedFeedbackDynamicObstacles');
old=mmra_schedule_speed_feedback(P,unset);
assert(old.success && abs(old.makespan-base.makespan)<1e-8, ...
    'Opt-in mode changed historical obstacle-free scheduling.');
fprintf('MMRA predicted moving-obstacle tests: all assertions passed.\n');
end
