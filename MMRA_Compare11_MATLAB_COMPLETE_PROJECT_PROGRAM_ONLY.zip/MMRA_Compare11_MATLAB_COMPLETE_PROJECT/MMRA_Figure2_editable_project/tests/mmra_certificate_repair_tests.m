function mmra_certificate_repair_tests()
%MMRA_CERTIFICATE_REPAIR_TESTS Geometry, oracle and no-change fallback.
fprintf('MMRA certificate-guided spatial feedback tests: starting...\n');
[env,cfg,opt]=mmra_defaults('paper_gmm');
env.boundsLo=[-60 -60 0];env.boundsHi=[60 60 80];
env.peaks=zeros(0,5);env.baseHeight=0;env.safetyMargin=3;
opt.speed=15;opt.dSafe=10;opt.maxDelay=60;opt.delayStep=0.25;
opt.startPolicy='hold';opt.endPolicy='hold';
opt.spatialRepairSpan_m=[18 28 38];
opt.spatialRepairOffset_m=[18 26];
opt.spatialRepairLift_m=[0 6];
cfg.costMode='length_risk_climb';
cfg.riskCostWeight=0.5;cfg.ascentCostWeight=0.5;
% A route passes exactly through another craft's held terminal point.
route=[-40 0 12;40 0 12];blockedGoal=[0 0 12];
[d,along,q]=mmra_point_polyline_distance(route,blockedGoal);
assert(abs(d)<1e-10 && abs(along-40)<1e-8 && ...
    norm(q-blockedGoal)<1e-8);
[proposals,meta]=mmra_spatial_detour_candidates(route,blockedGoal,env,opt);
assert(~isempty(proposals) && numel(proposals)==numel(meta));
found=false;
for k=1:numel(proposals)
    p=proposals{k};
    assert(norm(p(1,:)-route(1,:))<1e-8 && ...
        norm(p(end,:)-route(end,:))<1e-8, ...
        'Repair is not allowed to change original endpoints.');
    assert(mmra_path_free(p,env,0.10));
    [dd,~,~]=mmra_point_polyline_distance(p,blockedGoal);
    if dd>opt.dSafe+0.1
        found=true;
    end
end
assert(found, 'Dogleg repairs could not clear the blocking goal sphere.');
% A truly identical held destination is impossible for ANY launch delay.
X=[-45 -10 12;35 20 12];
Y=[45 -20 12;35 20 12];
[proof,witness,calls]=mmra_pair_grid_certificate(X,Y,opt);
assert(proof && isnan(witness) && calls==481);
% Two parallel, well-separated paths: no spatial modification required.
A=[-35 -20 12;35 -20 12];B=[-35 20 12;35 20 12];
opt.spatialRepairMaxRepairRounds=2;
opt.spatialRepairMaxCandidateEvaluations=8;
opt.spatialRepairMaxRepairWall_s=4;
r=mmra_certificate_guided_spatial_repair({A,B},env,cfg,opt);
% Regression for the driver/result schema: source exposes Oracle fields.
assert(isfield(r,'originalOracleCertificates') && ...
    isfield(r,'finalOracleCertificates') && ...
    r.finalOracleCertificates<=r.originalOracleCertificates, ...
    'Certificate repair result schema is inconsistent.');
assert(r.success && r.acceptedRepairs==0 && ...
    r.originalNoGoPairs==0 && r.finalNoGoPairs==0 && ...
    isequal(r.paths{1},A) && isequal(r.paths{2},B));
assert(r.scheduler.postConflicts==0 && ...
    r.minSeparation>=opt.dSafe-opt.tol-1e-8);
fprintf('MMRA certificate-guided spatial feedback tests: all assertions passed.\n');
end
