function mmra_optimized_scenery_tests()
%MMRA_OPTIMIZED_SCENERY_TESTS New terrain, exact NFZ edge, and risk tests.
fprintf('MMRA optimized 5km scenery tests: starting...\n');
[old,oc,~]=mmra_defaults('paper_gmm_5km');
assert(isequal(old.boundsHi,[5000 5000 2000]));
scenes={'ridge_pass_5km','mountain_cluster_5km', ...
    'restricted_corridor_5km'};
for k=1:numel(scenes)
    [env,cfg,opt]=mmra_defaults(scenes{k});
    assert(strcmp(env.profile,scenes{k}));
    assert(isequal(env.boundsHi,[5000 5000 2000]));
    assert(opt.dSafe==10 && opt.speed==15 && ...
        opt.speedFeedbackLaunchInterval_s==3);
    assert(cfg.edgeResolution==cfg.riskCostResolution_m);
    [x,y]=meshgrid(linspace(50,4950,39));
    P=[x(:),y(:)];
    [h,hx,hy]=mmra_terrain(P,env);
    assert(all(isfinite([h;hx;hy])) && min(h)>=0 && ...
        max(h)<env.boundsHi(3)-env.safetyMargin);
    [starts,goals]=mmra_5km_mission(env,20,24001,'cross_center');
    assert(all(mmra_is_free([starts;goals],env)));
    assert(all(starts(:,3)<=2000) && all(goals(:,3)<=2000));
    % Finite-difference derivative oracle at a non-peak location.
    q=[1290 2230];d=0.025;
    [~,gx,gy]=mmra_terrain(q,env);
    dx=(mmra_terrain(q+[d 0],env)- ...
        mmra_terrain(q-[d 0],env))/(2*d);
    dy=(mmra_terrain(q+[0 d],env)- ...
        mmra_terrain(q-[0 d],env))/(2*d);
    assert(abs(gx-dx)<1e-5 && abs(gy-dy)<1e-5);
end
[env,cfg,~]=mmra_defaults('restricted_corridor_5km');
c=env.noFlyCylinders(1,:);
z=(c(4)+c(5))/2;
% Segment endpoints lie outside the forbidden volume; interior cuts it.
a=[c(1)-700 c(2) z];b=[c(1)+700 c(2) z];
assert(all(mmra_no_fly_free([a;b],env)));
assert(~mmra_no_fly_segment_free(a,b,env));
assert(~mmra_edge_free(a,b,env,1000));
[ok,~,~]=mmra_edge_eval(a,b,env,cfg);
assert(~ok,'Fused collision checker must reject exact cylinder crossing');
% Passing above the finite cylinder is legal if terrain clearance holds.
a=[c(1)-700 c(2) 1850];b=[c(1)+700 c(2) 1850];
assert(mmra_no_fly_segment_free(a,b,env));
assert(mmra_edge_free(a,b,env,cfg.guardFineResolution));
[ok,fc,~]=mmra_edge_eval(a,b,env,cfg);
assert(ok && isfinite(fc));
sep=mmra_edge_objective(a,b,env,cfg);
assert(abs(fc-sep)<1e-6,'Fused/separate risk costs must agree.');
% Probe the 3D risk halo: close to the cylinder is more risky.
z=1100;rr=c(3)+env.noFlyBuffer_m;
near=[c(1)+rr+10,c(2),z];
far=[c(1)+rr+500,c(2),z];
assert(mmra_risk_density(near,env,cfg.riskCostBand_m) > ...
    mmra_risk_density(far,env,cfg.riskCostBand_m));
% Original 5km synthetic scaled terrain must be unchanged.
[after,cc,~]=mmra_defaults('paper_gmm_5km');
assert(isequal(after,old) && isequal(cc,oc));
fprintf('MMRA optimized 5km scenery tests: all assertions passed.\n');
end
