function mmra_v21_holdout_statistics_tests()
%MMRA_V21_HOLDOUT_STATISTICS_TESTS Small artificial data only, NOT results.
fprintf('MMRA v2.1 holdout report tests: starting...\n');
s=mmra_v21_holdout_spec();
assert(numel(s.normalSeeds)==100 && numel(s.hardSeeds)==100);
assert(numel(s.budgetModes)*numel(s.terrains)* ...
       numel(s.hardGroups)*numel(s.variants)*100==3200);
[lo,hi]=mmra_v21_holdout_ci(2*ones(5,1),100);
assert(abs(lo-2)<1e-12 && abs(hi-2)<1e-12);
[lo,hi]=mmra_v21_holdout_wilson(100,100);
assert(lo>0.95 && hi<=1 && hi>=lo);
[lo,hi]=mmra_v21_holdout_wilson(0,100);
assert(lo>=0 && hi<0.05);
[lo,hi]=mmra_v21_holdout_ci([],100);
assert(isnan(lo) && isnan(hi));
s.bootstrapB=100; % statistics TEST only, real analysis uses 2000
records=struct([]);
for ib=1:numel(s.budgetModes)
 for ih=1:numel(s.hardGroups)
  hard=s.hardGroups(ih);
  if hard,seeds=s.hardSeeds;else,seeds=s.normalSeeds;end
  for ie=1:numel(s.terrains)
   for seed=reshape(seeds,1,[])
    for iv=1:numel(s.variants)
     pathVals=[150 150.5 150.4 150.8];
     riskVals=[4 3 4 3.3];
     ascVals=[20 20.1 18 18];
     clearVals=[1.2 1.4 1.2 1.3];
     wallVals=[.020 .023 .021 .025];
     r=struct('ProtocolID',s.protocolID, ...
       'BudgetMode',s.budgetModes{ib}, ...
       'Terrain',s.terrains{ie},'Hard',logical(hard), ...
       'APF','legacyAPF','Variant',s.variants{iv}, ...
       'Seed',double(seed), ...
       'RiskWeight',s.riskWeights(iv), ...
       'AscentWeight',s.ascentWeights(iv), ...
       'Success',true,'FineValid',true,'TimedOut',false, ...
       'Reason','artificial_test_only', ...
       'Path_m',pathVals(iv),'RiskIntegral_m',riskVals(iv), ...
       'Ascent_m',ascVals(iv),'MinClearFine_m',clearVals(iv), ...
       'CommonJref_m',0,'FirstIter',30,'Search_s',.01, ...
       'FullWall_s',wallVals(iv),'Validation_s',.001, ...
       'TreeCostError',0);
     if isempty(records),records=r;else,records(end+1,1)=r;end %#ok<AGROW>
    end
   end
  end
 end
end
T=struct2table(records);
assert(height(T)==3200);
[S,P,G]=mmra_v21_holdout_analyze(T,s);
assert(height(S)==32 && height(P)==32 && height(G)==16);
assert(all(G.GatePass),'Artificial success case should pass all gates');
assert(all(abs(P.PairedFineValidRateDelta_pp)<1e-9));
assert(all(P.PairedPathDelta95Lo_m<=P.PairedPathDelta95Hi_m));
ix=strcmp(T.BudgetMode,s.budgetModes{1}) & ...
 strcmp(T.Terrain,s.terrains{1}) & ~T.Hard;
mmra_v21_holdout_validate_part(T(ix,:),s,s.budgetModes{1}, ...
 s.terrains{1},false,s.normalSeeds);
% Invalidate one three-objective path: reliability gate MUST reject it.
j=find(ix & strcmp(T.Variant,'length_risk_climb'),1);
T.FineValid(j)=false;
[~,~,G2]=mmra_v21_holdout_analyze(T,s);
assert(nnz(~G2.GatePass)>=2 && ...
    nnz(G2.GatePass)<height(G2), ...
    'Artificial lost successful path must fail reliability gate.');
fprintf('MMRA v2.1 holdout report tests: all assertions passed.\n');
end
