function mmra_adaptive_smoothing_tests()
%MMRA_ADAPTIVE_SMOOTHING_TESTS Opt-in shared smoothing regression checks.
% Standalone; adds shared modules and Urban500 adapter for cross-scene QA.
projectRoot=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(projectRoot,'src'));
addpath(fullfile(projectRoot,'Urban500_V3_HighRise_Download', ...
    'Urban_Complex_500m_V3_HighRise'));
[env,cfg]=mmra_defaults('paper_gmm');
flat=env;flat.peaks=zeros(0,5);flat.baseHeight=0;
flat.safetyMargin=0;
poly=[2 2 7;12 2 7;12 12 7];

% Historical default is still the old midpoint, whole-path scheme.
[legacy,accepted]=mmra_bezier(poly,flat,cfg);
assert(accepted && mmra_path_free(legacy,flat,cfg.edgeResolution));
expected=[poly(1,:);(poly(1,:)+poly(2,:))/2];
A=(poly(1,:)+poly(2,:))/2;
B=(poly(2,:)+poly(3,:))/2;
t=linspace(0,1,cfg.bezierSamples+1).';t=t(2:end);
expected=[expected;bsxfun(@times,(1-t).^2,A)+ ...
    bsxfun(@times,2*t.*(1-t),poly(2,:))+ ...
    bsxfun(@times,t.^2,B);poly(end,:)];
assert(max(abs(legacy(:)-expected(:)))<1e-12, ...
    'Existing MMRA legacy Bezier output was changed.');

% New module makes G1 rounded curves and checks accepted arc radius.
modern=cfg;
modern.smoothMode='adaptive_safe';
modern.smoothMinRadius_m=2;
modern.smoothMaxPitch_deg=60;
modern.smoothTrimFraction=0.44;
modern.smoothMaxChord_m=0.75;
modern.smoothMaxSagitta_m=0.05;
[smooth,ok,stats]=mmra_bezier(poly,flat,modern);
assert(ok && stats.fullySmoothed && stats.roundedCorners==1);
assert(stats.minAcceptedRadius_m>=modern.smoothMinRadius_m-1e-8);
assert(norm(smooth(1,:)-poly(1,:))<1e-12 && ...
    norm(smooth(end,:)-poly(end,:))<1e-12);
assert(mmra_path_free(smooth,flat,modern.edgeResolution));

% MMRA shortest visibility is opt-in, default greedy unchanged.
modern.pruneMode='shortest_visibility';
reduced=mmra_prune(poly,flat,modern);
assert(size(reduced,1)==2 && ...
    mmra_path_free(reduced,flat,modern.edgeResolution));

% Scene-specific edge and exact curve callbacks: one impossible corner
% is left sharp while a second viable corner is rounded safely.
city=[0 0 10;20 0 10;20 20 10;40 20 10];
box=[17 19 1 4 0 20];
modern.edgeFreeFcn=@(a,b)urban500_rrtstar_edge_free(a,b,box);
modern.curveFreeFcn=@(a,c,b)urban500_bezier_curve_free(a,c,b,box);
modern.smoothMinRadius_m=5;
[adaptive,ok,st]=mmra_bezier(city,[],modern);
assert(ok && st.roundedCorners==1 && ~st.fullySmoothed && ...
    st.collisionRejected>=1);
assert(mmra_postprocess_path_free(adaptive,[],modern));

fprintf('MMRA adaptive smoothing tests PASSED.\n');
end
