#!/usr/bin/env python3
"""Self-contained STATIC checks for v1.5; does not execute MATLAB."""
from pathlib import Path
import hashlib
import re

root=Path(__file__).resolve().parents[1]
read=lambda rel:(root/rel).read_text(encoding='utf-8')
expected={'src/mmra_rrtstar.m': '641a1ebd38509dc0ba1c2f351030b81e358690c0343cf3f1d8e84f1eb13ecbb7', 'src/mmra_apf_field.m': '53536ff7fe6471aa90cf916dd62731da6976f44c9570f82cf0f51c39fbbc79b2', 'src/mmra_guided_sample.m': '53cdfe3d7ff79e1b0acff1e236d180d914e05af1c867d0e66fcf4b6a4db99bd3'}
for rel,digest in expected.items():
    assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==digest, rel

defaults=read('src/mmra_defaults.m')
trial=read('src/mmra_sc_trial.m')
select=read('examples/run_sc_apf_safety_holdout.m')
guard=read('src/mmra_sc_guard_compare.m')
rules=read('src/mmra_sc_guard_defaults.m')
reg=read('tests/mmra_run_tests.m')
assert 'cfg.edgeResolution = 0.25;' in defaults
assert 'fineResolution=0.10' in trial
assert 'mmra_edge_free(aThin,bThin,thin,1.5)' in reg
assert '~mmra_edge_free(aThin,bThin,thin,cfg.edgeResolution)' in reg
for key in ('meanClearSlack_m','p10ClearSlack_m','worstClearSlack_m',
            'minAbsoluteClear_m','minPaired'):
    assert key in guard and key in rules
assert "'results_sc_apf_v15'" in select
assert '17001:17030' in select and '16001:16050' in select
assert 'if isempty(allowed)' in select and 'return;' in select
assert 'NO holdout was run' in select
assert 'mmra_sc_guard_compare(baseline,candidate,g)' in select
assert re.search(r'allFine>=g\.minAbsoluteClear_m',guard)
for rel in ('examples/run_edge_resolution_audit.m',
            'examples/run_sc_apf_safety_holdout.m',
            'examples/run_sc_apf_selected_diagnostics.m',
            'examples/run_sc_apf_safety_stress.m'):
    assert (root/rel).exists()
print('PASS: v1.5 self-contained static checks; MATLAB not executed')
