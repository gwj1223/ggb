function mmra_refined_mountain_tests()
%MMRA_REFINED_MOUNTAIN_TESTS Geometry, derivatives, domains, compatibility.
fprintf('MMRA v2.5 refined mountain tests: starting...\n');
[env,cfg,sched]=mmra_defaults('mountain_cluster_refined_5km');
assert(isequal(env.boundsLo,[0 0 0]) && ...
    isequal(env.boundsHi,[5000 5000 2000]));
assert(env.safetyMargin==50 && sched.dSafe==10 && ...
    sched.speed==15 && sched.speedFeedbackLaunchInterval_s==3);
assert(cfg.edgeResolution==cfg.riskCostResolution_m);
assert(size(env.peaks,1)==12 && size(env.terrainRidges,2)==6);
assert(size(env.terrainErosionGullies,2)==6);
[x,y]=meshgrid(linspace(0,5000,81));
P=[x(:) y(:)];
[h,gx,gy]=mmra_terrain(P,env);
assert(all(isfinite(h)) && all(isfinite(gx)) && all(isfinite(gy)));
assert(min(h)>0 && max(h)+env.safetyMargin<env.boundsHi(3));
% Full domain collision interface sees the SAME refined terrain.
q=[2280 1970];z=mmra_terrain(q,env);
assert(~mmra_is_free([q z+env.safetyMargin-1],env));
assert(mmra_is_free([q z+env.safetyMargin+100],env));
% Analytic gradients used by APF match independent finite differences.
queries=[1200 2300; 2525 1625; 3240 3150; 4120 4210; ...
         700 1000; 4700 600];
d=0.05;
for i=1:size(queries,1)
    p=queries(i,:);
    [~,hx,hy]=mmra_terrain(p,env);
    dx=(mmra_terrain(p+[d 0],env)- ...
        mmra_terrain(p-[d 0],env))/(2*d);
    dy=(mmra_terrain(p+[0 d],env)- ...
        mmra_terrain(p-[0 d],env))/(2*d);
    assert(abs(hx-dx)<3e-5 && abs(hy-dy)<3e-5, ...
        'Refined terrain derivatives do not match finite differences.');
end
for U=[5 20]
    [starts,goals]=mmra_5km_mission(env,U,25001,'cross_center');
    assert(all(mmra_is_free([starts;goals],env)));
end
% No inadvertent changes to frozen v2.4 original 12-Gaussian scene.
[legacy,~,~]=mmra_defaults('mountain_cluster_5km');
assert(~isfield(legacy,'terrainRidges') && ...
    legacy.baseHeight==75 && size(legacy.peaks,1)==12);
assert(norm(mmra_terrain(P,env)-mmra_terrain(P,legacy))>10);
fprintf('MMRA v2.5 refined mountain tests: all assertions passed.\n');
end
