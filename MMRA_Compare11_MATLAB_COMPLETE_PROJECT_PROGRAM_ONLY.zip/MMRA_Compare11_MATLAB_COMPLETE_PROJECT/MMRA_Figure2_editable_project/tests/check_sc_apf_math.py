#!/usr/bin/env python3
"""Independent SC-APF formula sanity tests (NOT a MATLAB execution)."""
import math, random
random.seed(2026)
peaks=[(42,35,42,12,10),(38,62,55,10,14),(30,50,76,14,8),
       (28,76,30,9,12),(18,22,70,11,11)]
def gmm(x,y):
    z=2.;hx=0.;hy=0.
    for a,mx,my,sx,sy in peaks:
        w=a*math.exp(-.5*((x-mx)/sx)**2-.5*((y-my)/sy)**2)
        z+=w;hx-=w*(x-mx)/sx**2;hy-=w*(y-my)/sy**2
    return z,hx,hy

def field(q,goal,margin=7.,band=8.,width=4.,krep=30.,katt=1.5):
    x,y,z=q;h,hx,hy=gmm(x,y)
    c=z-h-margin;a=max(0.,band-c);u=a/width
    logcosh=abs(u)+math.log1p(math.exp(-2*abs(u)))-math.log(2.)
    potential=.5*katt*sum((p-g)**2 for p,g in zip(q,goal))+krep*width*logcosh
    gattr=[katt*(p-g) for p,g in zip(q,goal)]
    gscalar=-krep*math.tanh(u)
    g=[gattr[j]+gscalar*v for j,v in enumerate((-hx,-hy,1.))]
    return potential,g,gscalar
max_err=0.
for i in range(600):
    x=random.uniform(4.,96.);y=random.uniform(4.,96.)
    h,_,_=gmm(x,y)
    z=h+7.+random.uniform(-30,30)
    q=[x,y,z];goal=[93.,92.,27.]
    p,g,fac=field(q,goal)
    assert math.isfinite(p) and all(math.isfinite(a) for a in g)
    assert abs(fac)<=30.+1e-12
    # Avoid the activation transition itself for finite differences.
    if abs(z-h-7.-8.)<1e-3:continue
    for j in range(3):
        qp=q.copy();qm=q.copy();qp[j]+=1e-5;qm[j]-=1e-5
        fd=(field(qp,goal)[0]-field(qm,goal)[0])/(2e-5)
        max_err=max(max_err,abs(fd-g[j]))
assert max_err<1e-6,(max_err,'finite difference error')
x,y=30.,39.;h,_,_=gmm(x,y)
q=[x,y,h+7.+8.]
ql=q.copy();qr=q.copy();ql[-1]-=1e-7;qr[-1]+=1e-7
a,ga,_=field(ql,[90,90,30]);b,gb,_=field(qr,[90,90,30])
assert abs(a-b)<1e-3 and math.dist(ga,gb)<1e-4
pot,grad,fac=field([30.,39.,-1000.],[90.,90.,30.])
assert math.isfinite(pot) and all(map(math.isfinite,grad)) and abs(fac)<=30.
print(f'PASS independent SC-APF potential/gradient FD checks; max err={max_err:.3g}')
print('PASS C1 transition check and extreme infeasible clearance stability')
print('NOT RUN: MATLAB M-file behavior, RRT* experiments, scheduler experiments')
