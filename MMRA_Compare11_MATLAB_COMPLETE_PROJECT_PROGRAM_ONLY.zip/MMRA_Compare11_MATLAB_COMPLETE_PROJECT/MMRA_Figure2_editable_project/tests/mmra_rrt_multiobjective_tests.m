function mmra_rrt_multiobjective_tests()
%MMRA_RRT_MULTIOBJECTIVE_TESTS Determinism, edge math and tree consistency.
fprintf('MMRA v2.0 multiobjective tests: starting...\n');
[env,cfg,~]=mmra_defaults('paper_gmm');
assert(strcmp(cfg.costMode,'length') && cfg.step==8 && ...
    cfg.edgeResolution==0.25, 'Stable defaults were modified');
flat=struct('profile','fixture_flat','boundsLo',[0 0 0], ...
    'boundsHi',[60 60 30],'baseHeight',0,'peaks',zeros(0,5), ...
    'useRipples',false,'safetyMargin',5);
a=[0 0 6]; b=[10 0 6];
% c=1 m, band=2 m: risk is constant 0.25 along 10-m edge.
I=mmra_edge_risk(a,b,flat,2,0.25);
assert(abs(I-2.5)<1e-12);
test=cfg;test.costMode='length_risk';test.riskCostBand_m=2;
test.riskCostResolution_m=0.25;test.riskCostWeight=0.5;
[j,L,r]=mmra_edge_objective(a,b,flat,test);
assert(abs(L-10)<1e-12 && abs(r-2.5)<1e-12);
assert(abs(j-11.25)<1e-12);
assert(abs(mmra_edge_objective(b,a,flat,test)-j)<1e-10, ...
    'Edge objective should be symmetric on straight edges');
% More expensive length can win when it avoids the terrain-risk band.
test.riskCostWeight=2.0;
near=[0 0 6;10 0 6];
far=[0 0 6;0 0 8;10 0 8;10 0 6];
assert(mmra_path_length(far)>mmra_path_length(near));
jn=0;jf=0;
for k=1:size(near,1)-1
    jn=jn+mmra_edge_objective(near(k,:),near(k+1,:),flat,test);
end
for k=1:size(far,1)-1
    jf=jf+mmra_edge_objective(far(k,:),far(k+1,:),flat,test);
end
assert(jf<jn, 'Risk objective must permit longer, safer routes');
assert(abs(mmra_path_risk(near,flat,2,0.25)-2.5)<1e-12);
% Weight=0 MUST preserve random draws, parent selection and all geometry.
test=cfg;test.maxIter=500;test.goalRadius=6;
test.prune=false;test.smooth=false;
qStart=[2 2 8];qGoal=[48 46 8];
rng(22001,'twister');[p0,s0]=mmra_rrtstar(qStart,qGoal,flat,test,false);
zero=test;zero.costMode='length_risk';zero.riskCostWeight=0;
rng(22001,'twister');[pz,sz]=mmra_rrtstar(qStart,qGoal,flat,zero,false);
assert(s0.success && sz.success);
assert(isequaln(p0,pz) && s0.firstIter==sz.firstIter && ...
    s0.accepted==sz.accepted && s0.rejected==sz.rejected, ...
    'Zero-weight objective changed legacy fixed8 geometry');
assert(s0.treeCostError<1e-8 && sz.treeCostError<1e-8);
% In positive-weight mode, all parent/descendant costs and goal edge must
% agree with the independently recomputed sum on the returned path.
pos=test;pos.costMode='length_risk';pos.riskCostWeight=0.5;
flatRisk=flat;flatRisk.boundsLo=[0 0 5.6];
flatRisk.boundsHi=[60 60 6.5];
qRiskStart=[2 2 6.2];qRiskGoal=[48 46 6.2];
rng(22001,'twister');[pp,sp]=mmra_rrtstar( ...
    qRiskStart,qRiskGoal,flatRisk,pos,false);
assert(sp.success && sp.treeCostError<1e-7);
assert(mmra_path_free(pp,flatRisk,pos.edgeResolution));
assert(sp.pathRiskIntegral_m>0,'Test did not exercise nonzero risk');
assert(abs(sp.pathObjective_m-(sp.pathLength+ ...
    pos.riskCostWeight*sp.pathRiskIntegral_m))<1e-7);
assert(sp.pathObjective_m>=sp.pathLength-1e-9);
% Varying terrain means edge-risk values are NOT just path length proxies.
q=[43 42];h=mmra_terrain(q,env);
low=[q h+env.safetyMargin+0.5];
high=[q h+env.safetyMargin+4];
assert(mmra_edge_risk(low,low+[3 0 0],env,2,0.25)> ...
    mmra_edge_risk(high,high+[3 0 0],env,2,0.25));
% Guarded SC-APF remains callable; its original output rule is unchanged.
guard=test;guard.apfMode='guarded_sc';guard.wallBudget_s=Inf;
rng(22002,'twister');[gp,gs]=mmra_plan_single( ...
    qStart,qGoal,flat,guard,true);
assert(gs.success && gs.guarded && ...
    mmra_path_free(gp,flat,guard.guardFineResolution));
% No fabricated answer on zero-iteration search.
stop=pos;stop.maxIter=0;
[empty,fs]=mmra_rrtstar(qStart,qGoal,flat,stop,false);
assert(isempty(empty) && ~fs.success);
fprintf('MMRA v2.0 multiobjective tests: all assertions passed.\n');
