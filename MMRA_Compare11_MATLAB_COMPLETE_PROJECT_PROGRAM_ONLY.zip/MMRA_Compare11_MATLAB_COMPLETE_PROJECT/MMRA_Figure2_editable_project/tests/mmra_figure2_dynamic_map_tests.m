function mmra_figure2_dynamic_map_tests()
%MMRA_FIGURE2_DYNAMIC_MAP_TESTS Isolated dynamic sphere tests.
% Does not write original saved terrain, NFZ or dynamic settings.
fprintf('MMRA Figure2 moving-sphere persistence/geometry tests: starting...\n');
root=fileparts(fileparts(mfilename('fullpath')));
settingsFiles={fullfile(root,'results_main_map','Figure2_user_settings.mat'), ...
    fullfile(root,'results_main_map','Figure2_static_obstacles_settings.mat'), ...
    fullfile(root,'results_main_map','Figure2_dynamic_obstacles_settings.mat')};
before=cell(size(settingsFiles));
for j=1:numel(settingsFiles)
    if isfile(settingsFiles{j}),before{j}=readBytes(settingsFiles{j});end
end
tempDir=tempname;mkdir(tempDir);
clean=onCleanup(@()rmdir(tempDir,'s')); %#ok<NASGU>
[terrain,~,~]=mmra_defaults('mountain_cluster_figure2_custom_5km');
% Use fresh NFZ defaults in a missing sandbox file, never the live NFZ MAT.
env=mmra_figure2_add_static_obstacles(terrain, ...
    fullfile(tempDir,'nonexistent_nfz.mat'));
config=fullfile(tempDir,'dynamic_settings.mat');
[ob,info]=mmra_figure2_dynamic_obstacles(env,config);
assert(numel(ob)==3 && strcmp(info.source,'defaults'));
mmra_figure2_validate_dynamic_obstacles(ob,env,true);
% Midpoint interpolation and HOLD/HOLD outside specified time knots.
a=ob(1);t=a.time_s;
p=mmra_dynamic_obstacle_position(a,[t(1)-10;(t(1)+t(2))/2;t(2)+50]);
assert(all(abs(p(1,:)-a.position_m(1,:))<1e-9));
assert(all(abs(p(2,:)-mean(a.position_m,1))<1e-9));
assert(all(abs(p(3,:)-a.position_m(2,:))<1e-9));
% Changed radius, XYZ and times really reach the same reloaded obstacle.
modified=ob;
modified(1).position_m(:,1)=modified(1).position_m(:,1)+35;
modified(1).radius_m=24;
modified(1).time_s=[75;180];
mmra_figure2_validate_dynamic_obstacles(modified,env,true);
dynamicParams=struct('obstacles',modified,'revision','sandbox_test');
save(config,'dynamicParams','-v7');
[loaded,meta]=mmra_figure2_dynamic_obstacles(env,config);
assert(strcmp(meta.source,'saved') && strcmp(meta.revision,'sandbox_test'));
assert(isequal(loaded(1).position_m,modified(1).position_m));
assert(isequal(loaded(1).time_s,modified(1).time_s));
assert(loaded(1).radius_m==modified(1).radius_m);
% Detect hard NFZ overlap (including its cylinder buffer).
bad=ob;cx=env.noFlyCylinders(1,1);cy=env.noFlyCylinders(1,2);
bad(1).position_m=[cx cy 1700;cx cy 1700];
assertFails(@()mmra_figure2_validate_dynamic_obstacles(bad,env,false));
% Detect map bounds, terrain intrusion and time-order errors.
bad=ob;bad(1).position_m(1,1)=5;
assertFails(@()mmra_figure2_validate_dynamic_obstacles(bad,env,false));
bad=ob;bad(1).position_m(:,3)=70;
assertFails(@()mmra_figure2_validate_dynamic_obstacles(bad,env,false));
bad=ob;bad(1).time_s=[150;150];
assertFails(@()mmra_figure2_validate_dynamic_obstacles(bad,env,false));
% A corrupt saved file must NOT silently fall back to defaults.
dynamicParams.obstacles=struct('bad',1);
save(config,'dynamicParams','-v7');
assertFails(@()mmra_figure2_dynamic_obstacles(env,config));
% The whole test must leave all user's live MAT bytes intact.
for j=1:numel(settingsFiles)
    if ~isempty(before{j})
        assert(isequal(before{j},readBytes(settingsFiles{j})), ...
            'A live Figure 2 user setting was modified by tests.');
    else
        assert(~isfile(settingsFiles{j}), ...
            'A live Figure 2 setting was created by tests.');
    end
end
fprintf('MMRA Figure2 moving-sphere persistence/geometry tests: PASSED.\n');
end
function assertFails(f)
failed=false;
try,f();catch,failed=true;end
assert(failed,'An invalid moving sphere was incorrectly accepted.');
end
function bytes=readBytes(file)
fid=fopen(file,'rb');assert(fid>0);
c=onCleanup(@()fclose(fid)); %#ok<NASGU>
bytes=fread(fid,inf,'uint8=>uint8');
end
