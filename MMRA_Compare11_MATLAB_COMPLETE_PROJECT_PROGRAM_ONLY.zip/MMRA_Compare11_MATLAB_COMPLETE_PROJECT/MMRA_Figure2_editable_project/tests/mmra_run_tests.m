function mmra_run_tests()
%MMRA_RUN_TESTS Regression tests for core failure cases (MATLAB R2023b).
fprintf('MMRA tests: starting...\n');
[env,cfg,s] = mmra_defaults('paper_gmm');
assert(abs(cfg.edgeResolution-0.25)<1e-12, ...
    'v1.5 planning edge resolution should be 0.25m');

% Same analytical terrain used by ALL planners and collision tests.
p=[30 39 45]; [h,gx,gy]=mmra_terrain(p,env); epsv=1e-5;
hx1=mmra_terrain(p+[epsv 0 0],env);
hx0=mmra_terrain(p-[epsv 0 0],env);
hy1=mmra_terrain(p+[0 epsv 0],env);
hy0=mmra_terrain(p-[0 epsv 0],env);
assert(abs((hx1-hx0)/(2*epsv)-gx)<1e-5);
assert(abs((hy1-hy0)/(2*epsv)-gy)<1e-5);
assert(~mmra_is_free([p(1:2) h+env.safetyMargin],env));
assert(mmra_is_free([p(1:2) h+env.safetyMargin+1],env));

% Below-ground samples should NOT throw, nor produce NaN gradient changes.
[point,~]=mmra_guided_sample([35 42 0],[90 93 50],env,cfg,true);
assert(all(isfinite(point)) && all(point>=env.boundsLo) && all(point<=env.boundsHi));

% Zero-gradient explicit fallback.
flat=env; flat.peaks=zeros(0,5); flat.baseHeight=0; flat.safetyMargin=0;
cfgZero=cfg; cfgZero.kAtt=0; cfgZero.kRep=0; cfgZero.uniformMix=0;
[q,tag]=mmra_guided_sample([2 3 6],[9 9 6],flat,cfgZero,true);
assert(norm(q-[2 3 6])<1e-12);
assert(strcmp(tag,'zero_gradient_fallback'));

% Segment endpoints feasible, but segment crossing a hill is not.
ob=flat; ob.peaks=[35 50 50 8 8]; ob.safetyMargin=2;
assert(mmra_is_free([30 50 10],ob) && mmra_is_free([70 50 10],ob));
assert(~mmra_edge_free([30 50 10],[70 50 10],ob,1.0));

% v1.6: an explicit planning buffer adds conservatism only when asked.
% All evaluation metrics must remain relative to the ORIGINAL safety margin.
baseH=mmra_terrain([5 7],env);
near=[5 7 baseH+env.safetyMargin+0.25];
withBuffer=env;withBuffer.safetyMargin=env.safetyMargin+0.5;
assert(mmra_is_free(near,env) && ~mmra_is_free(near,withBuffer), ...
    'Additional planning margin did not reject marginal terrain clearance');

% v1.5 regression: coarse 1.5m sampling can skip a narrow terrain crest,
% while the shared 0.25m planner check must reject the same edge.
% This synthetic hill is a numerical regression fixture, not field data.
thin=flat; thin.peaks=[10 4.5 0 0.2 0.2];
aThin=[0 0 5]; bThin=[8 0 5];
assert(mmra_is_free(aThin,thin) && mmra_is_free(bThin,thin));
assert(mmra_edge_free(aThin,bThin,thin,1.5), ...
    'Synthetic coarse-sampling miss was not reproduced');
assert(~mmra_edge_free(aThin,bThin,thin,cfg.edgeResolution), ...
    'Shared 0.25m planner check must catch the synthetic hill');

% Shared grid representation uses the same terrain oracle.
gridEnv=flat; gridEnv.boundsLo=[0 0 0];
map=mmra_build_grid(gridEnv,5);
assert(map.occ(1,1,1) && ~map.occ(1,1,2));

% Bezier smoothing returns only a fully rechecked path.
poly=[2 2 7;12 2 7;12 12 7];
[sm,accepted]=mmra_bezier(poly,flat,cfg);
assert(accepted && norm(sm(1,:)-poly(1,:))<1e-12 && ...
    norm(sm(end,:)-poly(end,:))<1e-12);
assert(mmra_path_free(sm,flat,cfg.edgeResolution));

% RRT* goal feasibility, path validity, and parent/descendant cost integrity.
rng(2026,'twister'); easy=flat; easy.boundsLo=[0 0 0];easy.boundsHi=[30 30 20];
cfgEasy=cfg; cfgEasy.maxIter=400; cfgEasy.goalRadius=5;
[raw,st]=mmra_rrtstar([2 2 7],[27 27 7],easy,cfgEasy,false);
assert(st.success,'Unguided RRT* should solve easy open space');
assert(norm(raw(1,:)-[2 2 7])<1e-10);
assert(norm(raw(end,:)-[27 27 7])<1e-10);
assert(mmra_path_free(raw,easy,cfgEasy.edgeResolution));
assert(st.treeCostError<1e-7,'Rewiring left stale descendant costs');

% No fabricated straight-line path when iteration budget is zero.
noIter=cfgEasy; noIter.maxIter=0;
[missing,status]=mmra_plan_single([2 2 7],[27 27 7],easy,noIter,false);
assert(isempty(missing) && ~status.success);

% Cross at t=0.5, potentially missed by coarse discrete-time checks.
a=[0 0 5;10 0 5]; b=[5 -5 5;5 5 5];
s.speed=10;s.dSafe=1;s.startPolicy='inactive';s.endPolicy='inactive';
[d,t,clash]=mmra_pair_minsep(a,b,0,0,s);
assert(clash && abs(t-0.5)<1e-10 && d<1e-10);

% With shared held terminal goal, waiting cannot create a safe schedule.
s.startPolicy='hold';s.endPolicy='hold';s.maxDelay=2;s.delayStep=0.5;
paths={[0 0 5;10 10 5],[20 0 5;10 10 5]};
sch=mmra_schedule(paths,s);
assert(~sch.success && isnan(sch.postConflicts));

% Separate paths, real schedule success with pair minimum separation.
s.endPolicy='inactive';s.startPolicy='inactive';s.maxDelay=3;
paths={a,b}; sch=mmra_schedule(paths,s);
assert(sch.success && sch.postConflicts==0 && sch.minSeparation>=s.dSafe-s.tol);

% Successful pipeline produces no unchecked fallback and measures times.
rng(22,'twister'); res=mmra_run_case([2 2 7],[27 27 7],[],easy,cfgEasy,s,false);
assert(res.success && all(mmra_is_free(res.paths{1},easy)));

% Conflict-aware scheduler is an OPTIONAL, fully backed-up extension.
% Original mode must remain bit-for-bit deterministic for fixed paths.
cmp= s; cmp.speed=10; cmp.dSafe=1.5;cmp.maxDelay=10;cmp.delayStep=0.25;
cmp.startPolicy='inactive';cmp.endPolicy='inactive';
three={[0 0 5;20 0 5], [10 -10 5;10 10 5], ...
       [0 3 5;20 3 5]};
baseline3=mmra_schedule(three,cmp);
new3=mmra_schedule_conflict_aware(three,cmp);
assert(new3.success || ~baseline3.success);
if baseline3.success
    assert(new3.makespan <= baseline3.makespan+1e-8);
end
assert(new3.conflictGraphEdges>=1);
assert(new3.schedule_s>=0);
if new3.success
    assert(new3.postConflicts==0 && new3.minSeparation>=cmp.dSafe-cmp.tol);
end
% A non-symmetric 4-UAV regression case (found with an independent
% straight-line geometry check) must actually exercise the new ordering.
% This is a code regression fixture, NOT publication experimental data.
imp=cmp; imp.dSafe=2.0;imp.maxDelay=6.0;imp.delayStep=0.5;
imp.speed=10.0; imp.startPolicy='inactive';imp.endPolicy='inactive';
regPaths={
  [19.0006291 16.2473412 5;-13.86414471 -8.45571115 5], ...
  [-0.023249851 24.9999892 5;8.89146583 -18.63774506 5], ...
  [-22.3499691 11.2017356 5;19.43242487 -16.07608746 5], ...
  [-1.4231956 -24.9594574 5;6.17041794 23.98241599 5]};
origImp=mmra_schedule(regPaths,imp);
newImp=mmra_schedule_conflict_aware(regPaths,imp);
assert(origImp.success && newImp.success);
assert(strcmp(newImp.chosenStrategy,'conflict_degree'), ...
    'Conflict-degree ordering must improve the constructed case');
assert(newImp.makespan < origImp.makespan-0.5, ...
    'Constructed test no longer shows an improvement');
assert(newImp.minSeparation>=imp.dSafe-imp.tol);

% When no conflicts exist, skip unnecessary alternative scheduling.
separate={[0 0 5;10 0 5],[0 10 5;10 10 5]};
a=mmra_schedule_conflict_aware(separate,cmp);
assert(a.success && ~a.altAttempted && a.conflictGraphEdges==0);
% HOLD terminal occupancy at a shared goal must still fail, not be reported safe.
hold=s;hold.startPolicy='hold';hold.endPolicy='hold';
hold.maxDelay=2;hold.delayStep=0.5;
holdRes=mmra_schedule_conflict_aware({[0 0 5;10 10 5], ...
                  [20 0 5;10 10 5]},hold);
assert(~holdRes.success && isnan(holdRes.postConflicts));
% End-to-end interface switch does not affect underlying spatial paths.
sel=s;sel.mode='conflict_aware';sel.startPolicy='inactive';
sel.endPolicy='inactive';sel.maxDelay=3;sel.delayStep=0.25;
rng(22,'twister'); outCA=mmra_run_case([2 2 7],[27 27 7],[],easy,cfgEasy,sel,false);
assert(outCA.success && strcmp(outCA.scheduler.mode,'conflict_aware'));

% v1.2: the new APF is OPTIONAL and must not change legacy behavior.
modeLegacy=cfg;modeLegacy.apfMode='legacy';modeLegacy.uniformMix=0;
qTest=[45 43 17];goalTest=[94 93 25];
[hxv,gxv,gyv]=mmra_terrain(qTest,env);
rhoOld=qTest(3)-hxv;
gExpected=cfg.kAtt*(qTest-goalTest);
if rhoOld<=cfg.rho0
    rrOld=max(rhoOld,cfg.rhoFloor);
    dOld=-cfg.kRep*(1/rrOld-1/cfg.rho0)/rrOld^2;
    gExpected=gExpected+dOld*[-gxv -gyv 1];
end
[uOld,gOld,~]=mmra_apf_field(qTest,goalTest,env,modeLegacy);
assert(isfinite(uOld) && norm(gOld-gExpected)<1e-11, ...
    'Legacy gradient changed unexpectedly');
[qOld,~]=mmra_guided_sample(qTest,goalTest,env,modeLegacy,true);
qExpected=qTest;
if norm(gExpected)>cfg.gradientEps
    qExpected=qTest-cfg.lambdaG*cfg.step*gExpected/norm(gExpected);
    qExpected=min(max(qExpected,env.boundsLo),env.boundsHi);
end
assert(norm(qOld-qExpected)<1e-10, ...
    'Legacy corrected sample changed unexpectedly');

% SC-APF analytical gradient agrees with potential finite differences.
modeSC=cfg; modeSC.apfMode='sc_apf'; modeSC.uniformMix=0;
baseXY=[30 39]; baseHeight=mmra_terrain(baseXY,env);
qSC=[baseXY baseHeight+env.safetyMargin+3];
[usc,gsc,infoSC]=mmra_apf_field(qSC,goalTest,env,modeSC);
assert(isfinite(usc) && all(isfinite(gsc)) && ...
    infoSC.repulsiveGradientNorm>0);
for ax=1:3
    qP=qSC;qM=qSC;hstep=1e-5;
    qP(ax)=qP(ax)+hstep;qM(ax)=qM(ax)-hstep;
    up=mmra_apf_field(qP,goalTest,env,modeSC);
    um=mmra_apf_field(qM,goalTest,env,modeSC);
    assert(abs((up-um)/(2*hstep)-gsc(ax))<1e-4, ...
        'SC-APF potential gradient finite-difference check failed');
end
% No singularity below ground (unlike reciprocal repulsion).
qBelow=[30 39 -1e3];
[ub,gb,ib]=mmra_apf_field(qBelow,goalTest,env,modeSC);
assert(isfinite(ub) && all(isfinite(gb)) && ...
    abs(ib.repulsiveCoefficient)<=modeSC.scKRep+1e-12);
[qProjected,~]=mmra_guided_sample(qBelow,goalTest,env,modeSC,true);
assert(all(isfinite(qProjected)) && ...
    all(qProjected>=env.boundsLo) && all(qProjected<=env.boundsHi));
% Repulsion is 0 outside safety band; attraction remains unchanged.
qOuter=[baseXY baseHeight+env.safetyMargin+modeSC.scSafeBand+1];
[~,gOuter,infoOuter]=mmra_apf_field(qOuter,goalTest,env,modeSC);
assert(infoOuter.repulsiveGradientNorm==0 && ...
    norm(gOuter-modeSC.kAtt*(qOuter-goalTest))<1e-11);
% Continuity of field and gradient at the activation boundary.
qBoundary=[baseXY baseHeight+env.safetyMargin+modeSC.scSafeBand];
qLeft=qBoundary;qRight=qBoundary;
qLeft(3)=qLeft(3)-1e-7;qRight(3)=qRight(3)+1e-7;
[uLeft,gLeft]=mmra_apf_field(qLeft,goalTest,env,modeSC);
[uRight,gRight]=mmra_apf_field(qRight,goalTest,env,modeSC);
assert(abs(uLeft-uRight)<1e-3 && norm(gLeft-gRight)<1e-4);
% Zero full gradient: no numerical division by zero in SC mode.
flatSC=flat;zeroSC=modeSC;zeroSC.kAtt=0;zeroSC.scKRep=0;
[qZeroSC,tagZeroSC]=mmra_guided_sample([2 3 6], ...
    [9 9 6],flatSC,zeroSC,true);
assert(norm(qZeroSC-[2 3 6])<1e-12 && ...
    strcmp(tagZeroSC,'zero_gradient_fallback'));
% APF mode must not affect the unguided RRT* baseline with fixed RNG.
rng(2424,'twister');[unOld,statOld]=mmra_rrtstar([2 2 7], ...
    [27 27 7],easy,cfgEasy,false);
newEasy=cfgEasy;newEasy.apfMode='sc_apf';
rng(2424,'twister');[unNew,statNew]=mmra_rrtstar([2 2 7], ...
    [27 27 7],easy,newEasy,false);
assert(statOld.success==statNew.success && ...
    statOld.iterations==statNew.iterations && ...
    isequal(unOld,unNew));
% Path clearance helper uses common terrain-clearance boundary.
[clearMin,clearMean]=mmra_path_clearance(raw,easy,cfgEasy.edgeResolution);
assert(clearMin>0 && clearMean>=clearMin);

% v1.3: optional SC diagnostics MUST NOT alter the actual random search.
probe=modeSC;probe.collectApfDiagnostics=true;probe.maxIter=300;
probeNo=probe;probeNo.collectApfDiagnostics=false;
rng(14001,'twister');[pDiag,sDiag]=mmra_rrtstar([5 7 24], ...
    [94 93 25],env,probe,true);
rng(14001,'twister');[pPlain,sPlain]=mmra_rrtstar([5 7 24], ...
    [94 93 25],env,probeNo,true);
assert(isequaln(pDiag,pPlain) && sDiag.success==sPlain.success ...
    && sDiag.iterations==sPlain.iterations ...
    && sDiag.accepted==sPlain.accepted && sDiag.rejected==sPlain.rejected, ...
    'Diagnostics altered the RRT* search results');
assert(sDiag.apfDiag.samples==sDiag.guidedSamples+ ...
    sDiag.zeroGradientSamples, 'APF diagnostic accounting mismatch');
assert(sPlain.apfDiag.samples==0 && sDiag.apfDiag.samples>0);
assert(sDiag.apfDiag.activeFraction>=0 && sDiag.apfDiag.activeFraction<=1);
assert(isfinite(sDiag.apfDiag.meanRepulsiveToAttractiveRatio));

% v1.4: deterministic safety selection guardrails, no toolbox required.
guard=mmra_sc_guard_defaults();
smallSeeds=(1:12).';
baselineT=table(smallSeeds,true(12,1),100*ones(12,1), ...
    0.01*ones(12,1),2*ones(12,1), ...
    'VariableNames',{'Seed','Success','Path_m','Search_s','MinClearFine_m'});
candidateT=baselineT;
candidateT.Path_m(:)=98;
candidateT.MinClearFine_m(:)=1.85;
guardPass=mmra_sc_guard_compare(baselineT,candidateT,guard);
assert(guardPass.Eligible && guardPass.PairedSuccess==12 ...
    && abs(guardPass.PathRatio-0.98)<1e-12);
% Faster/shorter alone must NOT override loss of safety reserve.
candidateT.MinClearFine_m(:)=1.5;
guardFail=mmra_sc_guard_compare(baselineT,candidateT,guard);
assert(~guardFail.Eligible && ~guardFail.MeanClearOK ...
    && ~guardFail.P10ClearOK && ~guardFail.WorstClearOK);
% More failure events than legacy always disqualifies a candidate.
candidateT=baselineT;candidateT.Success(2)=false;
guardFail=mmra_sc_guard_compare(baselineT,candidateT,guard);
assert(~guardFail.Eligible && ~guardFail.SuccessOK);
% A successful planning trial must expose the independent fine-resolution check.
fineRow=mmra_sc_trial('paper_gmm',12001,'MMRA_SC_APF',struct(),false,false);
assert(fineRow.Success && isfinite(fineRow.MinClearFine_m) ...
    && abs(fineRow.FineResolution_m-0.10)<1e-12);

% v1.7 deterministic route-level guardian. Does not alter either APF.
% Fixture with same endpoints: SC shorter, same clearance, should be used.
gConfig=cfgEasy;
gConfig.guardFineResolution=0.10;
gConfig.guardAbsoluteClear_m=1e-6;
gConfig.guardMaxClearLoss_m=0.25;
gConfig.guardPathTolerance_m=1e-7;
sta=struct('success',true,'reason','fixture','pathLength',NaN);
baseFixture=[2 2 7;15 8 7;27 27 7];
scFixture=[2 2 7;27 27 7];
[chosen,~,decision]=mmra_guarded_select(baseFixture,sta, ...
    scFixture,sta,easy,gConfig);
assert(strcmp(decision.ChosenMode,'sc_apf') && ...
    isequal(chosen,scFixture), 'Safe short SC candidate not selected');
% A no-longer SC route can still be unsafe: reject it and keep baseline.
under=easy; under.peaks=[5 15 15 1 1];under.safetyMargin=0;
baseDetour=[2 2 7;2 20 7;27 27 7];
shortUnsafe=[2 2 7;15 15 1;27 27 7];
[kept,~,decision]=mmra_guarded_select(baseDetour,sta, ...
    shortUnsafe,sta,under,gConfig);
assert(strcmp(decision.ChosenMode,'legacy') && ...
    ~decision.SCFineValid && isequal(kept,baseDetour), ...
    'Terrain-unsafe SC route did not trigger original APF fallback');
% An invalid legacy route must not prevent a valid SC route from being used.
[rescued,~,dRescue]=mmra_guarded_select(shortUnsafe,sta, ...
    baseDetour,sta,under,gConfig);
assert(strcmp(dRescue.ChosenMode,'sc_apf') && ...
    strcmp(dRescue.Decision,'baseline_not_fine_valid') && ...
    isequal(rescued,baseDetour), 'Valid SC rescue was incorrectly rejected');
% A safe but longer SC route is also rejected in favour of the legacy path.
[shortKept,~,dLong]=mmra_guarded_select(scFixture,sta, ...
    baseFixture,sta,easy,gConfig);
assert(strcmp(dLong.ChosenMode,'legacy') && ...
    strcmp(dLong.Decision,'sc_longer_than_baseline') && ...
    isequal(shortKept,scFixture));
% Per-path relative safety guard can reject a geometrically feasible SC.
flatGate=easy;flatGate.peaks=zeros(0,5);flatGate.baseHeight=0;
baseLong=[2 2 7;2 27 7;27 27 7];
scClose=[2 2 7;15 15 6;27 27 7];
[kept,~,decision]=mmra_guarded_select(baseLong,sta, ...
    scClose,sta,flatGate,gConfig);
assert(strcmp(decision.ChosenMode,'legacy') && ...
    strcmp(decision.Decision,'sc_clearance_loss_exceeds_guard') && ...
    isequal(kept,baseLong), 'Relative clearance guard was bypassed');
% Explicit failure if neither route meets independent fine safety check.
[none,failSt,infoFail]=mmra_guarded_select( ...
    shortUnsafe,sta,shortUnsafe,sta,under,gConfig);
assert(~failSt.success && isempty(none) && ...
    strcmp(infoFail.ChosenMode,'none'));
% Full pipeline: same-seed output may take SC only when no worse length
% and at most 0.25m lower sampled minimum clearance than fine-safe legacy.
gConfig.apfMode='guarded_sc';gConfig.prune=false;gConfig.smooth=false;
legacyGuardCfg=gConfig;legacyGuardCfg.apfMode='legacy';
seedGuard=2026;
rng(seedGuard,'twister');[legacyGuard,legacyStat]=mmra_plan_single( ...
    [2 2 7],[27 27 7],easy,legacyGuardCfg,true);
rng(seedGuard,'twister');[selectedGuard,guardSt]=mmra_plan_single( ...
    [2 2 7],[27 27 7],easy,gConfig,true);
assert(guardSt.guarded && guardSt.success && ...
    isfinite(guardSt.total_s) && guardSt.total_s>=0 && ...
    mmra_path_free(selectedGuard,easy,gConfig.guardFineResolution));
if legacyStat.success && mmra_path_free(legacyGuard,easy,gConfig.guardFineResolution)
    [baseMargin,~]=mmra_path_clearance(legacyGuard,easy,0.10);
    [selectedMargin,~]=mmra_path_clearance(selectedGuard,easy,0.10);
    assert(mmra_path_length(selectedGuard)<= ...
        mmra_path_length(legacyGuard)+gConfig.guardPathTolerance_m);
    assert(selectedMargin>=baseMargin-gConfig.guardMaxClearLoss_m-1e-9);
end
assert(guardSt.total_s>=guardSt.ChosenSearch_s, ...
    'Guarded runtime failed to count the extra search');
% Paired stochastic runs must not modify downstream RNG beyond baseline.
rng(seedGuard,'twister');mmra_plan_single( ...
    [2 2 7],[27 27 7],easy,legacyGuardCfg,true);
expectedRng=rng;
rng(seedGuard,'twister');mmra_plan_single( ...
    [2 2 7],[27 27 7],easy,gConfig,true);
actualRng=rng;
assert(isequal(expectedRng.State,actualRng.State), ...
    'Guarded mode unexpectedly modified the downstream random stream');

fprintf('MMRA tests: all assertions passed.\n');
end
