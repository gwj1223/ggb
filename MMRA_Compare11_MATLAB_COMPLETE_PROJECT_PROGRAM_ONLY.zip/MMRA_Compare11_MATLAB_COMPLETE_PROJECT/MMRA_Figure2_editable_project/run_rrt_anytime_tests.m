%RUN_RRT_ANYTIME_TESTS Independent tests for the opt-in planner.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'tests'));
mmra_rrt_anytime_tests();
mmra_rrt_multiobjective_tests();
mmra_rrt_threeobjective_tests();
