%REBUILD_SCHEDULER_REPAIR_REPORTS_FIXED Restore scheduling summary from saved CSV.
% This script does NOT run spatial planning or schedule any UAVs.
% Put it in the MMRA_Unified_MATLAB_v2_1_scheduler project ROOT and run:
%   run('rebuild_scheduler_repair_reports_fixed.m')
% It also works when placed directly inside the project's examples folder.
root=fileparts(mfilename('fullpath'));
if isfile(fullfile(root,'examples','mmra_sched_repair_spec.m'))
    % Root directory directly contains examples.
elseif isfile(fullfile(root,'mmra_sched_repair_spec.m')) && ...
       isfile(fullfile(fileparts(root),'examples','mmra_sched_repair_spec.m'))
    root=fileparts(root);
else
    error(['Place this file inside MMRA_Unified_MATLAB_v2_1_scheduler ', ...
       '(or its examples folder), next to the existing saved results.']);
end
addpath(fullfile(root,'examples'));
assert(isfolder(fullfile(root,'results_scheduler_repair_dev','checkpoints')), ...
    'Cannot find your saved CSV checkpoints under %s',root);
fprintf('Found scheduler project: %s\n',root);
fprintf('Rebuilding scheduling reports ONLY; no replanning or rescheduling.\n');
mmra_sched_repair_report_fixed(root);

function mmra_sched_repair_report_fixed(root)
%MMRA_SCHED_REPAIR_REPORT Rebuild reports exclusively from saved CSV parts.
% Never reruns spatial planning or any scheduling method.
s=mmra_sched_repair_spec();
outDir=fullfile(root,'results_scheduler_repair_dev');
partDir=fullfile(outDir,'checkpoints');
if ~exist(partDir,'dir')
    error('No scheduler checkpoints found at %s',partDir);
end
T=table(); countMissing=0;
for ie=1:numel(s.terrains)
 terrain=s.terrains{ie};
 for ni=1:numel(s.sizes)
  n=s.sizes(ni);
  for rep=1:s.nTrials
   seed=930000+10000*ie+100*n+rep;
   fname=fullfile(partDir,sprintf('part_%s_u%d_seed%d.csv',terrain,n,seed));
   if ~isfile(fname),countMissing=countMissing+1;continue;end
   a=readtable(fname);
   assert(height(a)==1 && ...
       all(strcmp(a.ProtocolID,s.protocolID)) && ...
       all(strcmp(a.Terrain,terrain)) && a.NumUAV(1)==n && a.Seed(1)==seed, ...
       'Report checkpoint invalid: %s',fname);
   if isempty(T),T=a;else,T=[T;a];end %#ok<AGROW>
  end
 end
end
if isempty(T)
    error('No saved scheduler comparisons; run the main driver first.');
end
writetable(T,fullfile(outDir,'scheduler_all_trials.csv'));

% Each method: end-to-end and conditional scheduling reliability separately.
methodNames={'Length','CA','Repair'};
methodLabels={'length_priority','conflict_aware','bottleneck_repair'};
summaryRows=struct([]);pairedRows=struct([]);gateRows=struct([]);
for ie=1:numel(s.terrains)
 for ni=1:numel(s.sizes)
  terrain=s.terrains{ie};n=s.sizes(ni);
  group=T(strcmp(T.Terrain,terrain) & T.NumUAV==n,:);
  if isempty(group),continue;end
  % CSV readtable may infer 0/1 status columns as DOUBLE, not LOGICAL.
  % Convert AND validate explicitly before using them as MATLAB indices.
  spatialOK=csvLogicalFlag(group.SpatialOK,'SpatialOK');
  lengthOK=csvLogicalFlag(group.LengthOK,'LengthOK');
  caOK=csvLogicalFlag(group.CAOK,'CAOK');
  repairOK=csvLogicalFlag(group.RepairOK,'RepairOK');
  assert(~any((lengthOK | caOK | repairOK) & ~spatialOK), ...
      'Invalid checkpoint: a scheduler succeeded without valid spatial paths.');
  assert(~any(lengthOK & ~caOK) && ~any(caOK & ~repairOK), ...
      'Invalid checkpoint: fallback feasibility invariant was violated.');
  spatial=sum(spatialOK);
  for m=1:numel(methodNames)
   name=methodNames{m};
   ok=csvLogicalFlag(group.([name 'OK']),[name 'OK']);
   makespan=group.([name 'Makespan_s']);
   walls=group.([name 'Wall_s']);
   minSep=group.([name 'MinSep_m']);
   maxDelay=group.([name 'MaxDelay_s']);
   [eLo,eHi]=wilsonCI(sum(ok),height(group));
   [sLo,sHi]=wilsonCI(sum(ok),spatial);
   row=struct('Terrain',terrain,'NumUAV',double(n), ...
       'Method',methodLabels{m},'Cases',height(group), ...
       'SpatialValidN',double(spatial), ...
       'EndToEndValidN',double(sum(ok)), ...
       'EndToEndValidRate',double(sum(ok)/height(group)), ...
       'EndToEndCI95_L',eLo,'EndToEndCI95_U',eHi, ...
       'SchedulerValidRateGivenSpatial',sum(ok)/max(1,spatial), ...
       'SchedulerCI95_L',sLo,'SchedulerCI95_U',sHi, ...
       'MeanMakespan_s',safeMean(makespan(ok)), ...
       'MeanWall_s',safeMean(walls(spatialOK)), ...
       'MeanMinSep_m',safeMean(minSep(ok)), ...
       'MeanMaxDelay_s',safeMean(maxDelay(ok)));
   if isempty(summaryRows),summaryRows=row;
   else,summaryRows(end+1,1)=row;end %#ok<AGROW>
  end
  % Paired CA -> repair comparisons use identical, validated planned paths.
  both=caOK & repairOK;
  gain=group.CAMakespan_s(both)-group.RepairMakespan_s(both);
  assert(all(gain>=-1e-8),'Repair made a CA-feasible schedule worse');
  gain(abs(gain)<1e-8)=0;
  [lo,hi]=bootMeanCI(gain,s.bootstrapB,s.bootstrapSeed+ie*10+n);
  extraSaved=sum(~caOK & repairOK);
  strict=sum(gain>1e-8);
  fraction=strict/max(1,numel(gain));
  cpu=group.RepairWall_s(spatialOK) ./ ...
      max(group.CAWall_s(spatialOK),eps);
  wallRatio=safeMean(cpu);
  pair=struct('Terrain',terrain,'NumUAV',double(n), ...
      'N',height(group),'SpatialValidN',double(spatial), ...
      'BothValidN',double(sum(both)), ...
      'CAFailureRepairSuccessN',double(extraSaved), ...
      'StrictMakespanImprovementN',double(strict), ...
      'StrictImprovementFraction',fraction, ...
      'MeanPairedMakespanGain_s',safeMean(gain), ...
      'GainCI95_L_s',lo,'GainCI95_U_s',hi, ...
      'MeanRepairToCAWallRatio',wallRatio, ...
      'MeanRepairCandidateCount',safeMean(group.RepairCandidates(spatialOK)), ...
      'MeanInitialConflicts',safeMean(group.InitialConflicts(spatialOK)));
  if isempty(pairedRows),pairedRows=pair;
  else,pairedRows(end+1,1)=pair;end %#ok<AGROW>
  reliabilityOK=~any(caOK & ~repairOK);
  makespanOK=all(gain>=-1e-8);
  improvementOK=fraction>=s.minImprovedFraction;
  costOK=isfinite(wallRatio) && wallRatio<=s.maxWallRatio;
  gate=struct('Terrain',terrain,'NumUAV',double(n), ...
      'ReliabilityNoninferior',logical(reliabilityOK), ...
      'MakespanNoninferior',logical(makespanOK), ...
      'ImprovementRateOK',logical(improvementOK), ...
      'ComputeCostOK',logical(costOK), ...
      'DevGatePass',logical(reliabilityOK && makespanOK && ...
          improvementOK && costOK));
  if isempty(gateRows),gateRows=gate;
  else,gateRows(end+1,1)=gate;end %#ok<AGROW>
 end
end
summary=struct2table(summaryRows);
paired=struct2table(pairedRows);
gates=struct2table(gateRows);
writetable(summary,fullfile(outDir,'scheduler_method_summary.csv'));
writetable(paired,fullfile(outDir,'scheduler_paired_bootstrap_ci95.csv'));
writetable(gates,fullfile(outDir,'scheduler_pilot_gates.csv'));

fprintf('\n=== Scheduler development comparison (same paths, hold/hold) ===\n');
disp(summary);
fprintf('\n=== Paired conflict-aware -> bounded repair comparisons ===\n');
disp(paired);
fprintf('\n=== Predeclared development gates ===\n');
disp(gates);
expected=numel(s.terrains)*numel(s.sizes)*s.nTrials;
fprintf('Saved %d/%d trial cases; %d missing.\n',height(T),expected,countMissing);
if countMissing==0
    stage='COMPLETE';
    fprintf('DEV GATES: %d/%d passed.\n',sum(gates.DevGatePass),height(gates));
else
    stage='PARTIAL';
    fprintf('WARNING: partial comparison; do not use as full-cohort result.\n');
end
f=fopen(fullfile(outDir,'RUN_STATUS.txt'),'w');assert(f>0);
fprintf(f,'%s: %d/%d scenarios; %d missing; %s\n', ...
    stage,height(T),expected,countMissing,s.protocolID);
fprintf(f,'This is development-stage, not independent holdout; no global optimum claim.\n');
fprintf(f,'Retained feasibility/makespan by fallback; improvement and runtime measured.\n');
fprintf(f,'Bootstrap 95%% CI applies to paired CA-feasible cases only.\n');
fclose(f);
end

function m=safeMean(x)
x=x(isfinite(x));
if isempty(x),m=NaN;else,m=mean(x);end
end

function [lo,hi]=bootMeanCI(x,B,seed)
% Bootstrap 95% percentile interval on paired *independent scenarios*.
x=x(isfinite(x));n=numel(x);
if n==0,lo=NaN;hi=NaN;return;end
if n==1,lo=x;hi=x;return;end
old=rng;
rng(seed,'twister');
samples=zeros(B,1);
for k=1:B
    picks=randi(n,n,1);
    samples(k)=mean(x(picks));
end
rng(old);
samples=sort(samples);
lo=samples(max(1,ceil(0.025*B)));
hi=samples(min(B,ceil(0.975*B)));
end

function [lo,hi]=wilsonCI(successes,n)
% 95% Wilson score interval, no Statistics Toolbox dependency.
if n==0,lo=NaN;hi=NaN;return;end
z=1.959963984540054;
p=successes/n;den=1+z^2/n;
ctr=(p+z^2/(2*n))/den;
half=z*sqrt(p*(1-p)/n+z^2/(4*n^2))/den;
lo=max(0,ctr-half);hi=min(1,ctr+half);
end

function flag=csvLogicalFlag(raw,label)
%CSVLOGICALFLAG Validate 0/1, logical, or text Boolean columns from CSV.
% MATLAB readtable may infer the same writetable logical column as numeric.
if islogical(raw)
    flag=raw(:);
elseif isnumeric(raw)
    assert(all(isfinite(raw(:)) & (raw(:)==0 | raw(:)==1)), ...
        'Unexpected status value in CSV column %s',label);
    flag=(raw(:)==1);
elseif iscell(raw) || ischar(raw) || isstring(raw) || iscategorical(raw)
    v=lower(strtrim(string(raw(:))));
    positive=(v=="true" | v=="1" | v=="t");
    negative=(v=="false" | v=="0" | v=="f");
    assert(all(positive | negative), ...
        'Unexpected text status in CSV column %s',label);
    flag=positive;
else
    error('Unsupported CSV type in status column %s',label);
end
flag=logical(flag(:));
end
