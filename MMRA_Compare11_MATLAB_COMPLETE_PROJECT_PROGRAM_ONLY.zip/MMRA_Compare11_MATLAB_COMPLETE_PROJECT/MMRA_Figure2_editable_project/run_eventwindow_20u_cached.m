%RUN_EVENTWINDOW_20U_CACHED Initial targeted 20-UAV development pilot.
% Uses earlier 60 cached 20-UAV path cases; NEVER reruns RRT*.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'tests'),fullfile(root,'examples'));
fprintf('=== MMRA v2.1 endpoint-aware window scheduler: 20-UAV pilot ===\n');
run(fullfile(root,'run_tests.m'));
mmra_rrt_threeobjective_tests();
mmra_sched_repair_tests();
mmra_sched_window_tests();
mmra_sched_event_driver(root,true);
