function mendeley_public_plot_case(caseId,mode,suite)
%MENDELEY_PUBLIC_PLOT_CASE 3D original+candidate paths and traffic margins.
% Usage: mendeley_public_plot_case('MEN_RRT_B_U02','proxy')
if nargin<1,caseId='MEN_RRT_B_U02';end
if nargin<2,mode='proxy';end
if nargin<3,suite='full';end
mode=lower(char(mode));
if strcmpi(suite,'incident2'),C=mendeley_public_load_incidents();
else,C=mendeley_public_load_cases();end
allIDs={C.id};index=find(strcmp(allIDs,char(caseId)),1);
assert(~isempty(index),'Unknown public replay case: %s',char(caseId));
base=fileparts(mfilename('fullpath'));
outDir=fullfile(base,'benchmark_results','Mendeley_Public3D');
if strcmpi(suite,'incident2'),prefix='MENDELEY3D_INCIDENT2_';
else,prefix='MENDELEY3D_';end
matfile=fullfile(outDir,[prefix upper(mode) '_trials.mat']);
assert(exist(matfile,'file')==2,'Run the matching benchmark first.');
S=load(matfile);
assert(index<=numel(S.trajectories), ...
    'That case was not included in the benchmark maxCases run.');
c=C(index);P=S.trajectories{index};
fig=figure('Visible','off','Color','w','Position',[100 100 1180 580]);
subplot(1,2,1);hold on;grid on;axis equal;
for j=1:numel(c.traffic)
    r=c.traffic{j};
    plot3(r(:,2),r(:,3),r(:,4),'-','Color',[.68 .72 .78], ...
        'LineWidth',.8);
end
r=c.reference_ego;
plot3(r(:,2),r(:,3),r(:,4),'b--','LineWidth',1.4);
if ~isempty(P)
    plot3(P(:,2),P(:,3),P(:,4),'r-','LineWidth',1.8);
end
scatter3(c.start_m(1),c.start_m(2),c.start_m(3),45,'g','filled');
scatter3(c.goal_m(1),c.goal_m(2),c.goal_m(3),45,'k','filled');
xlabel('X (m)');ylabel('Y (m)');zlabel('Z (m)');
title(sprintf('%s | logged vs MMRA %s',c.id,mode),'Interpreter','none');
view(42,24);
subplot(1,2,2);hold on;grid on;
T=linspace(0,c.horizon_s,450)';
refDist=minDistancesAtTimes(c.reference_ego,c.traffic,T);
plot(T,refDist,'b--','LineWidth',1.3);
if ~isempty(P)
    dist=minDistancesAtTimes(P,c.traffic,T);
    plot(T,dist,'r-','LineWidth',1.4);
end
plot([0,c.horizon_s],[c.inter_uav_spacing_m,c.inter_uav_spacing_m], ...
    'k:','LineWidth',1.3);
xlabel('t (s)');ylabel('Nearest fixed-traffic distance (m)');
title('Time-varying closest traffic separation');
legendEntries={'logged source','selected 10m threshold'};
if ~isempty(P),legendEntries={'logged source','MMRA result','selected 10m threshold'};end
legend(legendEntries,'Location','best');
if exist(outDir,'dir')~=7,mkdir(outDir);end
out=fullfile(outDir,[char(caseId) '_' upper(mode) '_replay.png']);
print(fig,out,'-dpng','-r150');
close(fig);
fprintf('Saved plot: %s\n',out);
end

function ds=minDistancesAtTimes(P,traffic,t)
Q=interp1(P(:,1),P(:,2:4),min(max(t,P(1,1)),P(end,1)),'linear');
ds=inf(size(t));
for j=1:numel(traffic)
    A=traffic{j};
    X=interp1(A(:,1),A(:,2:4),min(max(t,A(1,1)),A(end,1)),'linear');
    d=sqrt(sum((Q-X).^2,2));
    ds=min(ds,d);
end
end
