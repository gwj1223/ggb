#!/usr/bin/env python3
"""Independent source-data integrity audit; does NOT execute MATLAB planners.
Uses only numpy + Python stdlib, no mutation of source CSV logs.
"""
import csv, hashlib, math
from pathlib import Path
import numpy as np
BASE=Path(__file__).resolve().parent
DATA=BASE/'Mendeley_Public_3D_CSV'
SOURCE=list(csv.DictReader((DATA/'PUBLIC_SOURCE_MANIFEST.csv').open(encoding='utf-8')))

def minsep(A,B,H):
    tt=np.unique(np.concatenate(([0.],A[:,0],B[:,0],[H])))
    tt=tt[(tt>=0)&(tt<=H)]
    pa=np.column_stack([np.interp(tt,A[:,0],A[:,k]) for k in (1,2,3)])
    pb=np.column_stack([np.interp(tt,B[:,0],B[:,k]) for k in (1,2,3)])
    R=pa-pb
    dR=np.diff(R,axis=0)
    den=(dR*dR).sum(axis=1)
    frac=np.zeros(len(den))
    k=den>1e-18
    frac[k]=np.clip(-(R[:-1][k]*dR[k]).sum(axis=1)/den[k],0,1)
    diff=R[:-1]+frac[:,None]*dR
    D=np.linalg.norm(diff,axis=1)
    idx=int(D.argmin())
    return float(D[idx]),float(tt[idx]+frac[idx]*(tt[idx+1]-tt[idx]))

def make_direct(st,en,speed=120.,delay=0.):
    L=np.linalg.norm(en-st)
    t=delay+L/speed
    if delay:
        return np.array([[0,*st],[delay,*st],[t,*en]],dtype=float)
    return np.array([[0,*st],[t,*en]],dtype=float)

rows=[]; pairRows=[]; sample_check=[]
for src in SOURCE:
    fn=DATA/src['local_csv_filename']
    assert fn.stat().st_size==int(src['bytes'])
    assert hashlib.sha256(fn.read_bytes()).hexdigest()==src['sha256_original_bytes']
    groups={i:[] for i in range(1,11)}
    with fn.open(newline='',encoding='utf-8-sig') as f:
        for r in csv.DictReader(f):
            u=int(r['UAV_ID'])
            groups[u].append([float(r[k]) for k in ('Time','Pos_X','Pos_Y','Pos_Z')])
    tracks={i:np.array(arr,dtype=float) for i,arr in groups.items()}
    H=tracks[1][-1,0]
    assert H>100 and len(tracks)==10
    for u,T in tracks.items():
        assert len(T)>=2 and np.isfinite(T).all() and abs(T[0,0])<1e-8
        assert (np.diff(T[:,0])>0).all() and abs(T[-1,0]-H)<1e-6
    paird={}
    for a in range(1,11):
        for b in range(a+1,11):
            d,tt=minsep(tracks[a],tracks[b],H)
            paird[a,b]=d
            pairRows.append(dict(run_id=src['run_id'],uav_a=a,uav_b=b,
                                 minsep_m=f'{d:.10f}',at_t_s=f'{tt:.8f}',
                                 conflict10m=int(d<10-1e-7)))
    for i in range(1,11):
        closest=min((paird[min(i,j),max(i,j)],j) for j in range(1,11) if j!=i)
        e0=tracks[i][0,1:];e1=tracks[i][-1,1:]
        endpointsafe=all(np.linalg.norm(e0-tracks[j][0,1:])>=10-1e-7 and
                         np.linalg.norm(e1-tracks[j][-1,1:])>=10-1e-7
                         for j in range(1,11) if j!=i)
        direct=make_direct(e0,e1)
        ds=min(minsep(direct,tracks[j],H)[0] for j in range(1,11) if j!=i)
        feasible=[]
        for sp in (120,105,90,75,60,45):
            for delay in (0,1,2):
                time=delay+np.linalg.norm(e1-e0)/sp
                if time>H+1e-7:continue
                candidate=make_direct(e0,e1,sp,delay)
                dd=min(minsep(candidate,tracks[j],H)[0] for j in range(1,11) if j!=i)
                if dd>=10-1e-7:feasible.append((time,sp,delay))
        rows.append(dict(case_id=f'MEN_{src["run_id"]}_U{i:02d}',
                         source_run=src['run_id'],ego_id=i,horizon_s=H,
                         reference_minsep_m=round(closest[0],8),reference_nearest_other_id=closest[1],
                         reference_conflict_10m=int(closest[0]<10-1e-7),
                         endpoint_feasible=int(endpointsafe),
                         direct120_minsep_m=round(ds,8),
                         direct120_conflict_10m=int(ds<10-1e-7),
                         direct_timing_has_solution=int(bool(feasible))))
assert len(rows)==60 and len(pairRows)==270
for name,rs in [('Mendeley_Public3D_reference_manifest.csv',rows),('Mendeley_Public3D_270_pairs.csv',pairRows)]:
    with (DATA/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rs[0].keys()));w.writeheader();w.writerows(rs)
print('SHA256 integrity: 6/6 MATCH source copies')
print('Source tracks: 6 logs x 10 UAV = 60 ego-replay tasks, 270 unique pairs')
for name in [r['run_id'] for r in SOURCE]:
    rr=[r for r in rows if r['source_run']==name]
    pp=[r for r in pairRows if r['run_id']==name]
    print(f'{name:8s}: ref-conflict ego {sum(int(r["reference_conflict_10m"]) for r in rr)}/10; '
          f'conflict pairs {sum(int(p["conflict10m"]) for p in pp)}/45; '
          f'direct120 conflicts {sum(int(r["direct120_conflict_10m"]) for r in rr)}/10; '
          f'pure timing feasible {sum(int(r["direct_timing_has_solution"]) for r in rr)}/10')
print('TOTAL reference-conflict egos',sum(int(r['reference_conflict_10m']) for r in rows))
print('TOTAL direct120-conflict egos',sum(int(r['direct120_conflict_10m']) for r in rows))
print('TOTAL safe direct timing egos',sum(int(r['direct_timing_has_solution']) for r in rows))
print('TOTAL endpoint-feasible',sum(int(r['endpoint_feasible']) for r in rows))

# Optional PUBLIC-TRAJECTORY-DERIVED 'incident2' slice. The original source
# logs remain unchanged; this has its own derived benchmarking protocol.
inc=[]
def sample_xyz(T,t):
    return np.array([np.interp(t,T[:,0],T[:,k]) for k in (1,2,3)])
def shifted(T,t):
    ix=np.where(T[:,0]>t+1e-9)[0]
    return np.vstack(([0.,*sample_xyz(T,t)], np.column_stack((T[ix,0]-t,T[ix,1:]))))
for src in SOURCE:
    tracks={i:[] for i in range(1,11)}
    with (DATA/src['local_csv_filename']).open(newline='',encoding='utf-8') as f:
        for r in csv.DictReader(f):
            tracks[int(r['UAV_ID'])].append([float(r[x]) for x in ('Time','Pos_X','Pos_Y','Pos_Z')])
    tracks={i:np.array(a) for i,a in tracks.items()}
    H=tracks[1][-1,0]
    for ego in range(1,11):
        b=min((minsep(tracks[ego],tracks[j],H)[0],minsep(tracks[ego],tracks[j],H)[1],j)
              for j in range(1,11) if j!=ego)
        if b[0]>=10-1e-7:continue
        begin=max(0,b[1]-2)
        t2={i:shifted(tracks[i],begin) for i in range(1,11)}
        h2=H-begin
        d0=t2[ego][0,1:];goal=t2[ego][-1,1:]
        baseline=make_direct(d0,goal)
        dDirect=min(minsep(baseline,t2[j],h2)[0] for j in range(1,11) if j!=ego)
        dref=min(minsep(t2[ego],t2[j],h2)[0] for j in range(1,11) if j!=ego)
        ep=all(np.linalg.norm(d0-t2[j][0,1:])>=10-1e-7 and
               np.linalg.norm(goal-t2[j][-1,1:])>=10-1e-7 for j in range(1,11) if j!=ego)
        timing=False
        for sp in (120,105,90,75,60,45):
            for delay in (0,1,2):
                if delay+np.linalg.norm(goal-d0)/sp>h2+1e-7:continue
                candidate=make_direct(d0,goal,sp,delay)
                if all(minsep(candidate,t2[j],h2)[0]>=10-1e-7 for j in range(1,11) if j!=ego):
                    timing=True
        inc.append(dict(case_id=f'MEN_{src["run_id"]}_U{ego:02d}_SNAP2',
            source_run=src['run_id'],ego_id=ego,
            original_time_of_snapshot_s=round(begin,8),
            min_source_reference_sep_m=round(dref,8),
            direct120_minsep_m=round(dDirect,8),
            direct120_conflict_10m=int(dDirect<10-1e-7),
            pure_timing_solution_exists=int(timing),
            endpoint_feasible=int(ep)))
assert len(inc)==9
with (DATA/'Mendeley_Public3D_INCIDENT2_manifest.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(inc[0].keys()));w.writeheader();w.writerows(inc)
print('INCIDENT2: %d source-derived snapshots; %d direct120 conflicts; %d timing-solvable, %d endpoint-feasible' %
      (len(inc),sum(r['direct120_conflict_10m'] for r in inc),
       sum(r['pure_timing_solution_exists'] for r in inc),
       sum(r['endpoint_feasible'] for r in inc)))
