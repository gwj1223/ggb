function Result=run_urban500_jointrepair_fleet2()
%RUN_URBAN500_JOINTREPAIR_FLEET2 Replan & reschedule impacted two fleets.
% Trial indices 13 and 26 with seedOffset=100 are the EXACT saved failures.
% Re-runs 2 x 5 UAVs, MMRA ONLY; no ACO or 11-method comparison changed.
% Stores new results under a new audit directory, NEVER an old checkpoint.
C=mmra_compare11_cases('urban500');
o=mmra_fleet11_options('full');
o.seedOffset=100;
o.urban500JointRepairEnabled=true;
indices=[13 26];
F=cell(2,1); U=cell(2,1); Pairs=cell(2,1);
Paths=cell(2,1); Traj=cell(2,1); Infos=cell(2,1);
for k=1:2
    fprintf('\nV2 FLEET RECHECK: fleetSeedIndex=%d (MMRA only)\n',indices(k));
    [F{k},U{k},Pairs{k},Paths{k},Traj{k},Infos{k}]= ...
        mmra_fleet11_trial(C,'MMRA',indices(k),'full',o);
    fprintf('geometry %d/5, turn %d/5, timed %d, strict %d, status %s\n', ...
        F{k}.numGeometryUAV,F{k}.numTurnCertifiedUAV, ...
        F{k}.timedFleetSuccess,F{k}.strictFleetSuccess,F{k}.status);
    fprintf('min inter-UAV verified margin %.3f m, makespan %.3f s\n', ...
        F{k}.minInterUAVMargin_m,F{k}.makespan_s);
end
Result=struct('fleet',struct2table(vertcat(F{:})), ...
    'uav',struct2table(vertcat(U{:})), ...
    'fleetSeedIndices',indices,'strictBoth', ...
    all(cellfun(@(x)x.strictFleetSuccess,F)));
base=fileparts(mfilename('fullpath'));
outDir=fullfile(base,'benchmark_results','Fleet11','ResultAudit', ...
    'Urban500_JointRepair_V2');
if ~isfolder(outDir),mkdir(outDir);end
stamp=datestr(now,'yyyymmdd_HHMMSSFFF');
save(fullfile(outDir,['URBAN500_JOINT_FLEET2_' stamp '.mat']), ...
    'Result','F','U','Pairs','Paths','Traj','Infos','o','-v7.3');
writetable(Result.fleet,fullfile(outDir,[ ...
    'URBAN500_JOINT_FLEET2_' stamp '_fleet.csv']));
writetable(Result.uav,fullfile(outDir,[ ...
    'URBAN500_JOINT_FLEET2_' stamp '_uav.csv']));
if Result.strictBoth
    fprintf('BOTH IMPACTED FIVE-UAV FLEETS PASSED CURRENT STRICT PROTOCOL.\n');
else
    fprintf('At least one fleet did NOT pass. Inspect the new audit; do not claim 30/30.\n');
end
fprintf('Official 30-seed results and old checkpoints were not modified.\n');
end
