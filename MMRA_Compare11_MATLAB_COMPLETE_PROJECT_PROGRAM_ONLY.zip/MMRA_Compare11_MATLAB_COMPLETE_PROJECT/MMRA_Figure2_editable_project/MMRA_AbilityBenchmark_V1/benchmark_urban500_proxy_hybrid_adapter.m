function trajectories = benchmark_urban500_proxy_hybrid_adapter(testcase)
%BENCHMARK_URBAN500_PROXY_HYBRID_ADAPTER Experimental offline extension.
% V3.2/V3.3 scheduling + conflict-triggered temporary AABB proposals
% followed by the REAL uploaded RRT* and MMRA postprocessor.
% This extension is not the originally uploaded MMRA algorithm by itself,
% nor is it an online dynamic RRT*. Report its results separately.
trajectories = benchmark_mmra_urban_core(testcase,'proxy');
end
