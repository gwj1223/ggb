function [dMin, tMin] = benchmark_minsep_continuous(P, Q, horizon_s)
%BENCHMARK_MINSEP_CONTINUOUS Analytic min distance for timed polylines.
% All knots are partitioned into intervals on which both aircraft move
% linearly. This is a continuous-time calculation, not point sampling.
% Extrapolation rule: hover at first/last point outside given times.
assert(size(P,2)==4 && size(Q,2)==4, 'Timed paths need Nx4 arrays.');
assert(all(diff(P(:,1))>0) && all(diff(Q(:,1))>0), 'Times must increase.');
T = unique([0; P(:,1); Q(:,1); horizon_s]);
T = T(T >= 0 & T <= horizon_s);
dMin = inf; tMin = 0;
if numel(T)==1
    dMin=norm(benchmark_position(P,T(1))-benchmark_position(Q,T(1)));
    tMin=T(1);
    return;
end
for j = 1:numel(T)-1
    t0=T(j); t1=T(j+1);
    p0=benchmark_position(P,t0); p1=benchmark_position(P,t1);
    q0=benchmark_position(Q,t0); q1=benchmark_position(Q,t1);
    r0=p0-q0;
    dr=(p1-p0)-(q1-q0);
    den=dot(dr,dr);
    if den < 1e-15
        alpha=0;
    else
        alpha=max(0,min(1,-dot(r0,dr)/den));
    end
    d=norm(r0+alpha*dr);
    if d<dMin
        dMin=d;
        tMin=t0+alpha*(t1-t0);
    end
end
end
