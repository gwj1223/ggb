function trajectories = benchmark_straightline_baseline(testcase)
%BENCHMARK_STRAIGHTLINE_BASELINE Diagnostic only: NO collision avoidance.
% Every vehicle flies directly at maximum speed starting at t=0.
n=size(testcase.start_m,1);
trajectories=cell(n,1);
for i=1:n
    a=testcase.start_m(i,:); b=testcase.goal_m(i,:);
    duration=norm(b-a)/testcase.max_speed_mps;
    trajectories{i}=[0,a;duration,b];
end
end
