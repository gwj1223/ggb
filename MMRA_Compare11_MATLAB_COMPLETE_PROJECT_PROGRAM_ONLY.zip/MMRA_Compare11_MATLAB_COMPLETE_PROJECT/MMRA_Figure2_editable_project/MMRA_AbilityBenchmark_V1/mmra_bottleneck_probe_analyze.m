function R = mmra_bottleneck_probe_analyze(F, U)
%MMRA_BOTTLENECK_PROBE_ANALYZE Pair ACO/MMRA fleet trials by seed index.
%   F = one row per five-UAV fleet trial (from mmra_fleet11_trial).
%   U = one row per UAV within those same trials.
%   No failed trial is silently assigned an artificial path length/time.
%   Multiple co-critical UAVs are ALL marked (time tie: 1e-6 s).
assert(istable(F) && istable(U), 'Expected fleet and UAV tables.');
requireFields(F, {'algorithm','fleetSeedIndex','geometryAllSuccess', ...
    'timedFleetSuccess','strictFleetSuccess','makespan_s','totalPathLength_m'});
requireFields(U, {'algorithm','fleetSeedIndex','uavIndex','case_id', ...
    'arrival_s','pathLength_m','departureWait_s'});
assert(all(ismember({'ACO','MMRA'}, cellstr(string(F.algorithm)))), ...
    'Both ACO and MMRA fleet results are required.');
assert(numel(unique(F.fleetSeedIndex)) * 2 == height(F), ...
    'Expected exactly one ACO and one MMRA per fleet seed.');
flabels = cellstr(string(F.algorithm));
ulabels = cellstr(string(U.algorithm));
F.criticalUAVs = repmat({''}, height(F), 1);
F.criticalCount = zeros(height(F), 1);
F.criticalPathLength_m = nan(height(F), 1);
F.criticalDepartureWait_s = nan(height(F), 1);
for i = 1:5
    F.(sprintf('criticalU%02d',i)) = false(height(F),1);
end
for k = 1:height(F)
    mask = strcmp(ulabels,flabels{k}) & U.fleetSeedIndex==F.fleetSeedIndex(k);
    ui = U(mask,:);
    assert(height(ui)==5 && isequal(sort(ui.uavIndex(:)),(1:5)'), ...
        'One fleet trial must have exactly five unique UAV results.');
    if ~F.timedFleetSuccess(k)
        continue;
    end
    assert(all(isfinite(ui.arrival_s)), ...
        'Timed fleet has missing UAV arrival times.');
    mx = max(ui.arrival_s);
    assert(abs(mx-F.makespan_s(k)) < 1e-5, ...
        'Fleet makespan and individual arrivals disagree.');
    ties = find(abs(ui.arrival_s-mx) <= 1e-6);
    labels = cell(numel(ties),1);
    for j = 1:numel(ties)
        id = ui.uavIndex(ties(j));
        labels{j}=sprintf('U%02d',id);
        fld = sprintf('criticalU%02d',id);
        col=F.(fld); col(k)=true; F.(fld)=col;
    end
    F.criticalUAVs{k}=strjoin(labels,',');
    F.criticalCount(k)=numel(ties);
    if numel(ties)==1
        F.criticalPathLength_m(k)=ui.pathLength_m(ties);
        F.criticalDepartureWait_s(k)=ui.departureWait_s(ties);
    end
end
seeds=unique(F.fleetSeedIndex,'sorted');
p0=struct('fleetSeedIndex',0,'bothGeometry',false,'bothTimed',false, ...
    'bothStrict',false,'mmraGeometry',false,'acoGeometry',false, ...
    'mmraTimed',false,'acoTimed',false,'mmraStrict',false,'acoStrict',false, ...
    'mmraTotalLength_m',nan,'acoTotalLength_m',nan, ...
    'deltaLengthMMRA_minus_ACO_m',nan, ...
    'mmraMakespan_s',nan,'acoMakespan_s',nan, ...
    'deltaMakespanMMRA_minus_ACO_s',nan, ...
    'mmraCriticalUAVs','','acoCriticalUAVs','', ...
    'mmraU03Length_m',nan,'acoU03Length_m',nan, ...
    'deltaU03LengthMMRA_minus_ACO_m',nan, ...
    'nMMRAShorterUAVPaths',nan, ...
    'mmraLengthWin_butMakespanLoss',false);
pairs=repmat(p0,numel(seeds),1);
for q=1:numel(seeds)
    seed=seeds(q);
    im=find(F.fleetSeedIndex==seed & strcmp(flabels,'MMRA'));
    ia=find(F.fleetSeedIndex==seed & strcmp(flabels,'ACO'));
    assert(numel(im)==1 && numel(ia)==1, ...
        'Each seed requires one result for each algorithm.');
    p=p0;p.fleetSeedIndex=seed;
    p.mmraGeometry=logical(F.geometryAllSuccess(im));
    p.acoGeometry=logical(F.geometryAllSuccess(ia));
    p.mmraTimed=logical(F.timedFleetSuccess(im));
    p.acoTimed=logical(F.timedFleetSuccess(ia));
    p.mmraStrict=logical(F.strictFleetSuccess(im));
    p.acoStrict=logical(F.strictFleetSuccess(ia));
    p.bothGeometry=p.mmraGeometry && p.acoGeometry;
    p.bothTimed=p.mmraTimed && p.acoTimed;
    p.bothStrict=p.mmraStrict && p.acoStrict;
    p.mmraCriticalUAVs=F.criticalUAVs{im};
    p.acoCriticalUAVs=F.criticalUAVs{ia};
    p.mmraTotalLength_m=F.totalPathLength_m(im);
    p.acoTotalLength_m=F.totalPathLength_m(ia);
    if p.bothGeometry && isfinite(p.mmraTotalLength_m) && ...
            isfinite(p.acoTotalLength_m)
        p.deltaLengthMMRA_minus_ACO_m = ...
            p.mmraTotalLength_m-p.acoTotalLength_m;
    end
    p.mmraMakespan_s=F.makespan_s(im);
    p.acoMakespan_s=F.makespan_s(ia);
    if p.bothTimed && isfinite(p.mmraMakespan_s) && isfinite(p.acoMakespan_s)
        p.deltaMakespanMMRA_minus_ACO_s= ...
            p.mmraMakespan_s-p.acoMakespan_s;
    end
    ma=U.fleetSeedIndex==seed & strcmp(ulabels,'MMRA');
    aa=U.fleetSeedIndex==seed & strcmp(ulabels,'ACO');
    mm=sortrows(U(ma,:),'uavIndex');
    ac=sortrows(U(aa,:),'uavIndex');
    assert(height(mm)==5 && height(ac)==5);
    if isfinite(mm.pathLength_m(3)), p.mmraU03Length_m=mm.pathLength_m(3); end
    if isfinite(ac.pathLength_m(3)), p.acoU03Length_m=ac.pathLength_m(3); end
    if all(isfinite([p.mmraU03Length_m,p.acoU03Length_m]))
        p.deltaU03LengthMMRA_minus_ACO_m= ...
            p.mmraU03Length_m-p.acoU03Length_m;
    end
    if all(isfinite(mm.pathLength_m)) && all(isfinite(ac.pathLength_m))
        p.nMMRAShorterUAVPaths=sum(mm.pathLength_m < ac.pathLength_m-1e-6);
    end
    p.mmraLengthWin_butMakespanLoss= ...
        isfinite(p.deltaLengthMMRA_minus_ACO_m) && ...
        isfinite(p.deltaMakespanMMRA_minus_ACO_s) && ...
        p.deltaLengthMMRA_minus_ACO_m < -1e-6 && ...
        p.deltaMakespanMMRA_minus_ACO_s > 1e-6;
    pairs(q)=p;
end
P=struct2table(pairs);
methods={'ACO','MMRA'};
c0=struct('algorithm','','uavIndex',0,'nTimedFleet',0, ...
    'nTimesCritical',0,'criticalFrequency_pct',nan);
counts=repmat(c0,10,1);idx=0;
for m=1:2
    isMethod=strcmp(flabels,methods{m}) & F.timedFleetSuccess;
    denom=sum(isMethod);
    for i=1:5
        idx=idx+1;counts(idx)=c0;counts(idx).algorithm=methods{m};
        counts(idx).uavIndex=i;counts(idx).nTimedFleet=denom;
        fld=sprintf('criticalU%02d',i);
        counts(idx).nTimesCritical=sum(F.(fld) & isMethod);
        if denom>0
            counts(idx).criticalFrequency_pct= ...
                100*counts(idx).nTimesCritical/denom;
        end
    end
end
C=struct2table(counts);
validL=isfinite(P.deltaLengthMMRA_minus_ACO_m);
validT=isfinite(P.deltaMakespanMMRA_minus_ACO_s);
s=struct('nSeedPairs',height(P), ...
    'nBothGeometry',sum(P.bothGeometry), ...
    'nBothTimed',sum(P.bothTimed), ...
    'nMMRAStrict',sum(P.mmraStrict), ...
    'nACOStrict',sum(P.acoStrict), ...
    'nComparableLengths',sum(validL), ...
    'nComparableMakespans',sum(validT), ...
    'nMMRAShorterTotalLength',sum(P.deltaLengthMMRA_minus_ACO_m(validL)<-1e-6), ...
    'nMMRAFasterMakespan',sum(P.deltaMakespanMMRA_minus_ACO_s(validT)<-1e-6), ...
    'nLengthWinButSlower',sum(P.mmraLengthWin_butMakespanLoss), ...
    'meanLengthDelta_m',finiteMean(P.deltaLengthMMRA_minus_ACO_m), ...
    'medianLengthDelta_m',finiteMedian(P.deltaLengthMMRA_minus_ACO_m), ...
    'meanMakespanDelta_s',finiteMean(P.deltaMakespanMMRA_minus_ACO_s), ...
    'medianMakespanDelta_s',finiteMedian(P.deltaMakespanMMRA_minus_ACO_s));
R=struct('fleet',F,'uav',U,'paired',P,'critical',C,'summary',struct2table(s));
end
function requireFields(T,names)
assert(all(ismember(names,T.Properties.VariableNames)), ...
    'Required table fields missing.');
end
function y=finiteMean(x)
x=x(isfinite(x));y=nan;if ~isempty(x),y=mean(x);end
end
function y=finiteMedian(x)
x=x(isfinite(x));y=nan;if ~isempty(x),y=median(x);end
end
