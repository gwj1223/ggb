function R = run_mmra_fleet_repair_ablation(nSeeds, mode, firstSeed, runTag)
%RUN_MMRA_FLEET_REPAIR_ABLATION Matched FIVE-UAV Figure2 repair ON/OFF.
%  R = run_mmra_fleet_repair_ablation(1,'pilot',24,'SMOKE24');
%  R = run_mmra_fleet_repair_ablation(10,'pilot',16,'REPAIR_16_25');
%  R = run_mmra_fleet_repair_ablation(30,'full',26,'REPAIR_FULL_26_55');
%
% One paired seed is TWO five-UAV MMRA fleet trials (OFF / ON), with
% identical actual map, seeds, planning budgets and shared scheduler.
% Cached results live in a NEW folder, never in the existing Fleet11 logs.
% No baseline other than MMRA is involved; this is an INTERNAL ablation.
if nargin<1 || isempty(nSeeds),nSeeds=1;end
if nargin<2 || isempty(mode),mode='pilot';end
if nargin<3 || isempty(firstSeed),firstSeed=24;end
if nargin<4 || isempty(runTag)
    runTag=['REPAIR_' datestr(now,'yyyymmdd_HHMMSSFFF')];
end
mode=lower(char(mode));runTag=char(runTag);
assert(any(strcmp(mode,{'pilot','full'})),'mode must be pilot or full');
assert(isnumeric(nSeeds) && isscalar(nSeeds) && isfinite(nSeeds) && ...
    nSeeds==floor(nSeeds) && nSeeds>=1 && nSeeds<=2000, ...
    'nSeeds must be an integer in 1..2000');
assert(isnumeric(firstSeed) && isscalar(firstSeed) && ...
    isfinite(firstSeed) && firstSeed==floor(firstSeed) && firstSeed>=1, ...
    'firstSeed must be a positive integer');
assert(~isempty(runTag) && all(isstrprop(runTag,'alphanum') | ...
    runTag=='_' | runTag=='-'), ...
    'runTag: A-Z, a-z, 0-9, underscore and dash only');
assert(exist('mmra_fleet11_trial','file')==2 && ...
    exist('mmra_figure2_local_repair','file')==2, ...
    'Install the Figure2 generic repair and Fleet11 first.');
C=mmra_compare11_cases('figure2');
assert(numel(C)==5,'Expected the five original Figure2 tasks');
oBase=mmra_fleet11_options(mode);
base=fileparts(mfilename('fullpath'));
outDir=fullfile(base,'benchmark_results','Fleet11','RepairAblation');
if ~isfolder(outDir),mkdir(outDir);end
prefix=sprintf('F2_REPAIR_%s_%d_%d_%s',upper(mode), ...
    firstSeed,firstSeed+nSeeds-1,runTag);
checkpoint=fullfile(outDir,[prefix '_checkpoint.mat']);
methods={'OFF','ON'};
if isfile(checkpoint)
    q=load(checkpoint,'state');state=q.state;
    assert(state.version==1 && strcmp(state.mode,mode) && ...
        state.firstSeed==firstSeed && state.nSeeds==nSeeds && ...
        isequaln(state.options,oBase) && isequal(state.methods,methods), ...
        'Ablation checkpoint differs from requested settings; use new runTag.');
    fprintf('Resuming ablation checkpoint: %s\n',checkpoint);
else
    state=struct('version',1,'mode',mode,'firstSeed',firstSeed, ...
        'nSeeds',nSeeds,'options',oBase,'methods',{methods}, ...
        'fleet',{cell(nSeeds,2)},'uav',{cell(nSeeds,2)}, ...
        'pairs',{cell(nSeeds,2)},'paths',{cell(nSeeds,2)}, ...
        'trajectories',{cell(nSeeds,2)},'infos',{cell(nSeeds,2)});
end
fprintf('\nFIGURE2 FIVE-UAV REPAIR ABLATION (%s): fleet seeds %d..%d\n', ...
    mode,firstSeed,firstSeed+nSeeds-1);
fprintf('%d matched pairs = %d five-UAV fleet trials = %d solver calls\n', ...
    nSeeds,2*nSeeds,10*nSeeds);
for k=1:nSeeds
    seedIndex=firstSeed+k-1;
    for j=1:2
        if ~isempty(state.fleet{k,j})
            fprintf('SKIP cached: fleet seed=%d %s\n',seedIndex,methods{j});
            continue;
        end
        o=oBase;
        o.figure2LocalRepairEnabled=logical(j==2);
        [F,U,Pairs,Paths,Traj,Infos]=mmra_fleet11_trial( ...
            C,'MMRA',seedIndex,mode,o);
        F.repairMode=methods{j};
        F.numRepairAppliedUAV=0;
        for u=1:numel(U)
            U(u).repairMode=methods{j};
            U(u).repairApplied=false;
            U(u).repairMoves=0;
            if numel(Infos)>=u && isstruct(Infos{u})
                inf=Infos{u};
                if isfield(inf,'localRepairApplied')
                    U(u).repairApplied=logical(inf.localRepairApplied);
                end
                if isfield(inf,'localRepairMoves')
                    U(u).repairMoves=inf.localRepairMoves;
                end
            end
            F.numRepairAppliedUAV=F.numRepairAppliedUAV+ ...
                double(U(u).repairApplied);
        end
        % This is a fail-fast protocol check, not a numerical performance
        % assumption: disabled repair must NEVER claim repair was applied.
        if j==1
            assert(F.numRepairAppliedUAV==0, ...
                'OFF mode unexpectedly applied repair; option propagation failed.');
        end
        for p=1:numel(Pairs)
            Pairs(p).suite=F.suite;
            Pairs(p).algorithm='MMRA';
            Pairs(p).repairMode=methods{j};
            Pairs(p).fleetSeedIndex=seedIndex;
        end
        state.fleet{k,j}=F;state.uav{k,j}=U;
        state.pairs{k,j}=Pairs;state.paths{k,j}=Paths;
        state.trajectories{k,j}=Traj;state.infos{k,j}=Infos;
        save(checkpoint,'state','-v7.3');
        fprintf('fleet=%d %s | geom=%d/5 turn=%d/5 strict=%d', ...
            seedIndex,methods{j},F.numGeometryUAV, ...
            F.numTurnCertifiedUAV,F.strictFleetSuccess);
        fprintf(' | repaired=%d length=%.3f m makespan=%.3f s wall=%.3f s\n', ...
            F.numRepairAppliedUAV,F.totalPathLength_m, ...
            F.makespan_s,F.endToEndWall_s);
    end
end
R=localExport(state,outDir,prefix,checkpoint);
fprintf('\n=== REPAIR ABLATION SUMMARY ===\n');
disp(R.summary);
fprintf('\nPaired fleet changes (ON - OFF):\n');
disp(R.paired(:,{'fleetSeedIndex','strictOFF','strictON', ...
    'numRepairAppliedON','deltaLengthON_minus_OFF_m', ...
    'deltaMakespanON_minus_OFF_s','deltaWallON_minus_OFF_s'}));
fprintf('All results in: %s\n',outDir);
end

function R=localExport(state,outDir,prefix,checkpoint)
N=state.nSeeds;
frows=cell(N*2,1);urows=cell(N*2,1);prows=cell(N*2,1);
r=0;
for k=1:N
    for j=1:2
        r=r+1;
        frows{r}=state.fleet{k,j};
        urows{r}=state.uav{k,j};
        prows{r}=state.pairs{k,j};
    end
end
R=struct();
R.fleet=struct2table(vertcat(frows{:}));
R.uav=struct2table(vertcat(urows{:}));
nonempty=~cellfun(@isempty,prows);
if any(nonempty)
    R.pairs=struct2table(vertcat(prows{nonempty}));
else
    R.pairs=table();
end
R.paired=localPairs(state);
R.summary=localSummary(R.fleet,R.uav);
R.outDir=outDir;R.prefix=prefix;R.checkpoint=checkpoint;
writetable(R.fleet,fullfile(outDir,[prefix '_fleet_trials.csv']));
writetable(R.uav,fullfile(outDir,[prefix '_uav_trials.csv']));
if ~isempty(R.pairs)
    writetable(R.pairs,fullfile(outDir,[prefix '_pair_trials.csv']));
end
writetable(R.paired,fullfile(outDir,[prefix '_paired.csv']));
writetable(R.summary,fullfile(outDir,[prefix '_summary.csv']));
end

function T=localPairs(s)
N=s.nSeeds;
fleetSeedIndex=zeros(N,1);
strictOFF=false(N,1);strictON=false(N,1);
geometryOFF=false(N,1);geometryON=false(N,1);
timedOFF=false(N,1);timedON=false(N,1);
numRepairAppliedON=zeros(N,1);
totalLengthOFF_m=nan(N,1);totalLengthON_m=nan(N,1);
deltaLengthON_minus_OFF_m=nan(N,1);
makespanOFF_s=nan(N,1);makespanON_s=nan(N,1);
deltaMakespanON_minus_OFF_s=nan(N,1);
wallOFF_s=nan(N,1);wallON_s=nan(N,1);
deltaWallON_minus_OFF_s=nan(N,1);
minMarginOFF_m=nan(N,1);minMarginON_m=nan(N,1);
for k=1:N
    a=s.fleet{k,1};b=s.fleet{k,2};
    fleetSeedIndex(k)=s.firstSeed+k-1;
    strictOFF(k)=a.strictFleetSuccess;
    strictON(k)=b.strictFleetSuccess;
    geometryOFF(k)=a.geometryAllSuccess;
    geometryON(k)=b.geometryAllSuccess;
    timedOFF(k)=a.timedFleetSuccess;
    timedON(k)=b.timedFleetSuccess;
    numRepairAppliedON(k)=b.numRepairAppliedUAV;
    totalLengthOFF_m(k)=a.totalPathLength_m;
    totalLengthON_m(k)=b.totalPathLength_m;
    if a.geometryAllSuccess && b.geometryAllSuccess
        deltaLengthON_minus_OFF_m(k)= ...
            b.totalPathLength_m-a.totalPathLength_m;
    end
    makespanOFF_s(k)=a.makespan_s;
    makespanON_s(k)=b.makespan_s;
    if a.timedFleetSuccess && b.timedFleetSuccess
        deltaMakespanON_minus_OFF_s(k)=b.makespan_s-a.makespan_s;
    end
    wallOFF_s(k)=a.endToEndWall_s;
    wallON_s(k)=b.endToEndWall_s;
    deltaWallON_minus_OFF_s(k)=b.endToEndWall_s-a.endToEndWall_s;
    minMarginOFF_m(k)=a.minInterUAVMargin_m;
    minMarginON_m(k)=b.minInterUAVMargin_m;
end
T=table(fleetSeedIndex,strictOFF,strictON,geometryOFF,geometryON, ...
    timedOFF,timedON,numRepairAppliedON,totalLengthOFF_m, ...
    totalLengthON_m,deltaLengthON_minus_OFF_m, ...
    makespanOFF_s,makespanON_s,deltaMakespanON_minus_OFF_s, ...
    wallOFF_s,wallON_s,deltaWallON_minus_OFF_s, ...
    minMarginOFF_m,minMarginON_m);
end

function T=localSummary(F,U)
repairMode={'OFF';'ON'};
nFleetTrials=zeros(2,1);nGeometryFleet=zeros(2,1);
nTimedFleet=zeros(2,1);nStrictFleet=zeros(2,1);
nTurnCertifiedUAV=zeros(2,1);nRepairAppliedUAV=zeros(2,1);
meanTotalLength_m=nan(2,1);meanMakespan_s=nan(2,1);
meanPlanningWall_s=nan(2,1);meanEndToEndWall_s=nan(2,1);
meanMinInterUAVMargin_m=nan(2,1);
for j=1:2
    idx=strcmp(F.repairMode,repairMode{j});
    x=F(idx,:);nFleetTrials(j)=height(x);
    nGeometryFleet(j)=sum(x.geometryAllSuccess);
    nTimedFleet(j)=sum(x.timedFleetSuccess);
    nStrictFleet(j)=sum(x.strictFleetSuccess);
    nTurnCertifiedUAV(j)=sum(x.numTurnCertifiedUAV);
    nRepairAppliedUAV(j)=sum(x.numRepairAppliedUAV);
    meanTotalLength_m(j)=localFiniteMean(x.totalPathLength_m);
    meanMakespan_s(j)=localFiniteMean(x.makespan_s);
    meanPlanningWall_s(j)=localFiniteMean(x.planningWall_s);
    meanEndToEndWall_s(j)=localFiniteMean(x.endToEndWall_s);
    meanMinInterUAVMargin_m(j)=localFiniteMean(x.minInterUAVMargin_m);
end
T=table(repairMode,nFleetTrials,nGeometryFleet,nTimedFleet, ...
    nStrictFleet,nTurnCertifiedUAV,nRepairAppliedUAV, ...
    meanTotalLength_m,meanMakespan_s,meanPlanningWall_s, ...
    meanEndToEndWall_s,meanMinInterUAVMargin_m);
% Add fleet-level strict rates as an explicit denominator, not 5*N UAVs.
T.strictFleetRate_pct=100*T.nStrictFleet./T.nFleetTrials;
% U is kept as the source of per-aircraft records in a separate CSV.
assert(height(U)==5*sum(nFleetTrials), ...
    'Expected five UAV-level records per fleet trial.');
end

function y=localFiniteMean(x)
x=x(isfinite(x));
if isempty(x),y=nan;else,y=mean(x);end
end
