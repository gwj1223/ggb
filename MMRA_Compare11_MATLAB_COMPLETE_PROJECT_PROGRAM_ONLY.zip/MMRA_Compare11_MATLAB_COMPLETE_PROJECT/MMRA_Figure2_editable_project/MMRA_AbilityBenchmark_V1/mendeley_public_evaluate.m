function r = mendeley_public_evaluate(c,P)
%MENDELEY_PUBLIC_EVALUATE Independent whole-horizon safety check.
% Point-mass, piecewise-linear 3D trajectories. Fixed traffic follows
% unmodified public CSV tracks; traffic-to-traffic collisions not assessed.
% Checks start, goal, time ordering, speed, bounds, departure and 10m
% minimum separation. This is NOT acceleration/yaw/thrust certification.
r=struct('success',false,'status','INVALID_OUTPUT', ...
    'minSeparation_m',nan,'minMargin_m',nan,'pathLengthRatio',nan, ...
    'maxSpatialDeviation_m',nan,'startHold_s',nan,'arrival_s',nan, ...
    'pathPointCount',0);
if ~isnumeric(P) || ~ismatrix(P) || size(P,2)~=4 || ...
        size(P,1)<2 || any(~isfinite(P(:)))
    return;
end
r.pathPointCount=size(P,1);
if abs(P(1,1))>1e-7 || any(diff(P(:,1))<=0) || ...
        P(end,1)>c.horizon_s+1e-7
    r.status='INVALID_TIME';return;
end
if norm(P(1,2:4)-c.start_m)>1e-5 || ...
        norm(P(end,2:4)-c.goal_m)>1e-5
    r.status='WRONG_START_GOAL';return;
end
B=c.bounds_m;
if any(any(bsxfun(@lt,P(:,2:4),B(:,1)'-1e-7))) || ...
        any(any(bsxfun(@gt,P(:,2:4),B(:,2)'+1e-7)))
    r.status='OUT_OF_BOUNDS';return;
end
dxyz=diff(P(:,2:4));dt=diff(P(:,1));
seg=sqrt(sum(dxyz.^2,2));
if any(seg./dt>c.max_speed_mps+1e-6)
    r.status='SPEED_LIMIT_EXCEEDED';return;
end
firstMove=find(seg>1e-6,1,'first');
if isempty(firstMove),startWait=0;
else,startWait=P(firstMove,1);end
r.startHold_s=startWait;
if startWait>c.max_start_hold_s+1e-7
    r.status='START_HOLD_EXCEEDED';return;
end
r.arrival_s=P(end,1);
r.pathLengthRatio=sum(seg)/max(norm(c.goal_m-c.start_m),1e-12);
v=c.goal_m-c.start_m;
w=P(:,2:4)-repmat(c.start_m,size(P,1),1);
if dot(v,v)>1e-14
    a=max(0,min(1,(w*v')/dot(v,v)));
    p=repmat(c.start_m,size(P,1),1)+a*v;
    r.maxSpatialDeviation_m=max(sqrt(sum((P(:,2:4)-p).^2,2)));
else
    r.maxSpatialDeviation_m=max(sqrt(sum(w.^2,2)));
end
DM=inf;
for i=1:numel(c.traffic)
    d=mendeley_public_minsep(P,c.traffic{i},c.horizon_s);
    DM=min(DM,d);
end
r.minSeparation_m=DM;
r.minMargin_m=DM-c.inter_uav_spacing_m;
if r.minMargin_m < -1e-7
    r.status='INTER_UAV_CONFLICT';return;
end
r.success=true;r.status='PASS';
end
