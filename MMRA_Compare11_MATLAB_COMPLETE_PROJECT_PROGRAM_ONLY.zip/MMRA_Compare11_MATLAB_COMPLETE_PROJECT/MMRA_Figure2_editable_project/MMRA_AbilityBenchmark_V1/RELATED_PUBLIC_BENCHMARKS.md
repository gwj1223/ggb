# 外部公开基准（与本自建 450 例输入区别开）

本压缩包 `MMRA_AbilityBenchmark_450cases.mat` 是根据固定随机种子程序生成的抽象规划输入，**不是以下公开项目的原版数据或官方 benchmark，也未经这些项目认证**。

如果用于论文，请分别引用公开方法和明确披露本文随机压力测试协议：

1. SANDO (MIT ACL): https://github.com/mit-acl/sando
   - 动态障碍运动下的自主轨迹规划与多难度批量 benchmark，主要 ROS 2/C++ 环境；不能直接把其结果当 MATLAB/MMRA 的实测结果。
2. FlightBench (THU UAV): https://github.com/thu-uav/FlightBench
   - 四旋翼基于自机视觉的规划性能基准，有多难度测试与基线规划器，环境复杂，不是纯 MATLAB MAT 输入。
3. MATLAB multi-drone RRT* collision avoidance example:
   https://github.com/glopezferreira/multi-drone-rrtstar-collision-avoidance
   - MATLAB 多无人机路径、最小 snap 和 Monte Carlo 随机案例示例。该项目来源独立、未经本包复现，不代表标准权威 benchmark。

推荐完整论文评测分两层：
- A. 固定参数化批测（此包）用于比较 MMRA vs 原始 RRT*/消融配置的安全率、规划时间和可扩展性。
- B. 公开平台复现实验（SANDO 或 FlightBench 等），用于增强外部可比性。

不要把本文 450 个固定生成案例称作“公认标准测试集”，它们只是可再现的自建测试协议。
