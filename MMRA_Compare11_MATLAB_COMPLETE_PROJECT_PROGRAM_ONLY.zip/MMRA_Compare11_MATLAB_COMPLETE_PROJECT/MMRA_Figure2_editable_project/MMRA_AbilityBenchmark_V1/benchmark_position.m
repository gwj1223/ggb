function pos = benchmark_position(P, t)
%BENCHMARK_POSITION Piecewise-linear xyz trajectory with endpoint holding.
% P: Nx4 [time_s, x_m, y_m, z_m]. A vehicle remains at its last
% position until the benchmark horizon after its last timestamp.
if t <= P(1,1)
    pos = P(1,2:4);
    return;
end
if t >= P(end,1)
    pos = P(end,2:4);
    return;
end
j = find(P(:,1) <= t, 1, 'last');
if j >= size(P,1)
    pos = P(end,2:4);
    return;
end
w = (t-P(j,1)) / (P(j+1,1)-P(j,1));
pos = (1-w)*P(j,2:4) + w*P(j+1,2:4);
end
