function output = mmra_compare11_oracle(scene,operation,p,q)
%MMRA_COMPARE11_ORACLE Shared actual map collision oracle.
% 'points': boolean N-by-1, 'edge': scalar boolean, 'clearance': signed m.
if nargin<4,q=[];end
p=double(p);
lo=scene.bounds(:,1)';hi=scene.bounds(:,2)';
switch lower(char(operation))
    case 'points'
        in=all(bsxfun(@ge,p,lo),2) & all(bsxfun(@le,p,hi),2);
        switch scene.kind
            case 'figure2'
                output=in & mmra_is_free(p,scene.env);
            case 'urban500'
                output=in;
                for j=1:size(scene.boxes,1)
                    b=scene.boxes(j,:);
                    inside=p(:,1)>=b(1) & p(:,1)<=b(2) & ...
                        p(:,2)>=b(3) & p(:,2)<=b(4) & ...
                        p(:,3)>=b(5) & p(:,3)<=b(6);
                    output=output & ~inside;
                end
            case 'traffic_only'
                output=in;
            otherwise
                error('Unknown scene kind');
        end
    case 'edge'
        assert(size(p,1)==1 && numel(p)==3 && numel(q)==3);
        if ~all(mmra_compare11_oracle(scene,'points',[p;q]))
            output=false;return;
        end
        switch scene.kind
            case 'figure2'
                output=mmra_edge_free(p,q,scene.env,scene.edgeStep);
            case 'urban500'
                output=urban500_rrtstar_edge_free(p,q,scene.boxes);
            case 'traffic_only'
                output=true;
            otherwise
                error('Unknown scene kind');
        end
    case 'clearance'
        % A geometric signed-distance approximation for optimization only.
        % Final acceptance ALWAYS uses independent 'edge' oracle.
        c=min(bsxfun(@minus,p,lo),bsxfun(@minus,hi,p));
        output=min(c,[],2);
        switch scene.kind
            case 'figure2'
                h=mmra_terrain(p,scene.env);
                output=min(output,p(:,3)-h-scene.env.safetyMargin);
                env=scene.env;
                if isfield(env,'noFlyCylinders') && ~isempty(env.noFlyCylinders)
                    pad=0;
                    if isfield(env,'noFlyBuffer_m'),pad=env.noFlyBuffer_m;end
                    for k=1:size(env.noFlyCylinders,1)
                        b=env.noFlyCylinders(k,:);
                        radial=hypot(p(:,1)-b(1),p(:,2)-b(2))-(b(3)+pad);
                        vertical=max([b(4)-p(:,3),p(:,3)-b(5), ...
                            zeros(size(p,1),1)],[],2);
                        d=sqrt(max(radial,0).^2+vertical.^2);
                        inside=radial<0 & vertical==0;
                        d(inside)=radial(inside);
                        output=min(output,d);
                    end
                end
            case 'urban500'
                for k=1:size(scene.boxes,1)
                    b=scene.boxes(k,:);
                    a=b([1 3 5]);z=b([2 4 6]);
                    u=max(bsxfun(@minus,a,p),bsxfun(@minus,p,z));
                    d=sqrt(sum(max(u,0).^2,2))+min(max(u,[],2),0);
                    output=min(output,d);
                end
            case 'traffic_only'
                % No measured physical obstacles in this public CSV.
            otherwise
                error('Unknown scene kind');
        end
    otherwise
        error('Unknown oracle operation: %s',operation);
end
end
