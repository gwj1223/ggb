function [dmin,tmin] = mendeley_public_minsep(A,B,H)
%MENDELEY_PUBLIC_MINSEP Continuous-time minimum point-to-point distance.
% A,B are Kx4 [time_s,x_m,y_m,z_m], linearly interpolated between source
% samples; endpoint positions are held fixed outside each logged interval.
% This is NOT sampled-only distance and is NOT a dynamics certificate.
assert(isnumeric(A) && isnumeric(B) && size(A,2)==4 && size(B,2)==4);
assert(size(A,1)>=2 && size(B,1)>=2);
assert(all(isfinite(A(:))) && all(isfinite(B(:))));
assert(all(diff(A(:,1))>0) && all(diff(B(:,1))>0));
assert(isscalar(H) && isfinite(H) && H>0);
q=unique([0; A(:,1); B(:,1); H]);
q=q(q>=0 & q<=H);
pa=interp1(A(:,1),A(:,2:4),min(max(q,A(1,1)),A(end,1)),'linear');
pb=interp1(B(:,1),B(:,2:4),min(max(q,B(1,1)),B(end,1)),'linear');
r=pa-pb;
if numel(q)<2
    dmin=norm(r(1,:));tmin=q(1);return;
end
dr=diff(r,1,1);
den=sum(dr.^2,2);
tau=zeros(size(den));
ix=den>1e-18;
num=-sum(r(1:end-1,:).*dr,2);
tau(ix)=max(0,min(1,num(ix)./den(ix)));
p=r(1:end-1,:)+bsxfun(@times,dr,tau);
D=sqrt(sum(p.^2,2));
[dmin,at]=min(D);
tmin=q(at)+(q(at+1)-q(at))*tau(at);
end
