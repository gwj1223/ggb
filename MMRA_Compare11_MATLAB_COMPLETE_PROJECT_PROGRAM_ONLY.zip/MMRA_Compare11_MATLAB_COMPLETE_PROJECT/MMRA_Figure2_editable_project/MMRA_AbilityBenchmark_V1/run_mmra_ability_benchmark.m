function trialTable = run_mmra_ability_benchmark(plannerFn, maxCases, label, policy)
%RUN_MMRA_ABILITY_BENCHMARK Evaluate planner on deterministic 3D stress tests.
%
% Test evaluator itself, without claiming algorithm performance:
%   run_mmra_ability_benchmark(@benchmark_straightline_baseline, 30, 'baseline');
%
% After implementing your adapter:
%   run_mmra_ability_benchmark(@my_mmra_adapter, 450, 'MMRA');
%
% Result CSV is written in benchmark_results/. Analytic continuous-time
% safety checks are performed on OUTPUT polyline trajectories, not merely
% graphically interpolated lines.
if nargin<1 || isempty(plannerFn)
    error('Pass a planner function handle, e.g., @my_mmra_adapter.');
end
if nargin<2 || isempty(maxCases), maxCases=450; end
if nargin<3 || isempty(label), label='algorithm'; end
if nargin<4 || isempty(policy), policy='active'; end
assert(strcmp(policy,'active') || strcmp(policy,'schedule'), ...
    'policy must be active or schedule');
assert(isa(plannerFn,'function_handle'),'plannerFn must be function handle');
base=fileparts(mfilename('fullpath'));
S=load(fullfile(base,'MMRA_AbilityBenchmark_450cases.mat'));
C=S.cases;
maxCases=min(numel(C),max(1,round(maxCases)));
outdir=fullfile(base,'benchmark_results');
if ~exist(outdir,'dir'), mkdir(outdir); end
labels=regexprep([char(label) '_' char(policy)],'[^a-zA-Z0-9_-]','_');
rec=repmat(struct('case_id','','kind','','level',0,'stress',false, ...
    'n_uavs',0,'n_dynamic_obstacles',0,'success',false,'status','', ...
    'planning_s',nan,'minObstacleMargin_m',nan,'minInterUAVMargin_m',nan, ...
    'minMargin_m',nan,'pathLengthRatio',nan,'maxSpatialDeviation_m',nan, ...
    'totalArrival_s',nan,'totalStartHold_s',nan,'nSpatialReroutes',0),maxCases,1);
for k=1:maxCases
    c=C(k);
    if strcmp(policy,'schedule')
        c.max_start_hold_s=45;
    else
        c.max_start_hold_s=2;
    end
    rec(k).case_id=c.id; rec(k).kind=c.kind; rec(k).level=c.level;
    rec(k).stress=logical(c.stress); rec(k).n_uavs=size(c.start_m,1);
    rec(k).n_dynamic_obstacles=size(c.obstacles_m,1);
    ticID=tic;
    try
        trajectories=plannerFn(c);
        elapsed=toc(ticID);
        st=benchmark_evaluate(c,trajectories);
        rec(k).planning_s=elapsed;
        rec(k).success=st.success;
        rec(k).status=st.status;
        rec(k).minObstacleMargin_m=st.minObstacleMargin_m;
        rec(k).minInterUAVMargin_m=st.minInterUAVMargin_m;
        rec(k).minMargin_m=st.minMargin_m;
        rec(k).pathLengthRatio=st.pathLengthRatio;
        rec(k).maxSpatialDeviation_m=st.maxSpatialDeviation_m;
        rec(k).totalArrival_s=st.totalArrival_s;
        rec(k).totalStartHold_s=st.totalStartHold_s;
        rec(k).nSpatialReroutes=st.nSpatialReroutes;
    catch ME
        rec(k).planning_s=toc(ticID);
        rec(k).status=['PLANNER_ERROR: ' ME.identifier];
    end
    if mod(k,25)==0 || k==maxCases
        fprintf('Checked %d/%d, accepted %d\n',k,maxCases,sum([rec(1:k).success]));
    end
end
trialTable=struct2table(rec);
writetable(trialTable,fullfile(outdir,[labels '_trials.csv']));
save(fullfile(outdir,[labels '_trials.mat']),'trialTable');
benchmark_plot_summary(trialTable,labels,outdir);
fprintf('\nTEST: %s | %d cases | success %d/%d\n',labels,maxCases, ...
    sum(trialTable.success),maxCases);
kinds={'dynamic','interuav','combined'};
for i=1:numel(kinds)
    mask=strcmp(trialTable.kind,kinds{i});
    if ~any(mask),continue;end
    stress=mask & trialTable.stress;
    ctrl=mask & ~trialTable.stress;
    fprintf('%s: stress %d/%d success; controls %d/%d success\n',kinds{i}, ...
        sum(trialTable.success(stress)),sum(stress), ...
        sum(trialTable.success(ctrl)),sum(ctrl));
end
fprintf('CSV and PNG saved in %s\n',outdir);
end
