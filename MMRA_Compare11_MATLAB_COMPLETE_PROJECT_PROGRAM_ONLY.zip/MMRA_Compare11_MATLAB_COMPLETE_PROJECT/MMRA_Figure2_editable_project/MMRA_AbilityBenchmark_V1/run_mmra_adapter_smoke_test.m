function run_mmra_adapter_smoke_test()
%RUN_MMRA_ADAPTER_SMOKE_TEST Checks real-source wiring on safe controls.
root=fileparts(mfilename('fullpath'));
S=load(fullfile(root,'MMRA_AbilityBenchmark_450cases.mat'));
C=S.cases;
% The generator orders dynamic, interuav, combined; each first level has
% 20 stressed cases followed by 10 direct-safe controls.
idx=[21,171,321];
for k=idx
    c=C(k);
    P=my_mmra_adapter(c);
    st=benchmark_evaluate(c,P);
    assert(st.success, 'Real adapter failed a safe control case: %s',c.id);
    fprintf('%s: %s | travel ratio %.3f\n',c.id,st.status,st.pathLengthRatio);
end
fprintf('Real MMRA/Urban500 adapter smoke test PASSED.\n');
end
