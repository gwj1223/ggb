function T=mmra_fleet11_summary(F)
%MMRA_FLEET11_SUMMARY Aggregate FLEET trials (not pseudo-25 independent UAVs).
% Success rates always use ALL attempted fleet trials as denominator.
% Conditional lengths, makespans, and times report their non-NaN counts.
assert(istable(F) && all(ismember( ...
    {'algorithm','strictFleetSuccess','geometryAllSuccess', ...
     'timedFleetSuccess','fleetSeedIndex'},F.Properties.VariableNames)));
algorithmLabels=cellstr(string(F.algorithm));
names=unique(algorithmLabels,'stable');
model=struct('algorithm','','nFleetTrials',0,'nGeomFleet',0, ...
    'nTimedFleet',0,'nStrictFleet',0,'geometryRate_pct',nan, ...
    'timedRate_pct',nan,'strictRate_pct',nan, ...
    'strictCI95Lower_pct',nan,'strictCI95Upper_pct',nan, ...
    'meanTurnCertifiedUAV',nan,'nValidLengths',0, ...
    'meanTotalLength_m',nan,'stdTotalLength_m',nan, ...
    'lengthCI95Halfwidth_m',nan,'meanFleetDetour',nan, ...
    'nTimedMakespans',0,'meanMakespan_s',nan, ...
    'stdMakespan_s',nan,'makespanCI95Halfwidth_s',nan, ...
    'meanWait_s',nan,'meanPreConflictPairs',nan, ...
    'meanMinInterUAVMargin_m',nan, ...
    'meanPlanningWall_s',nan,'meanSchedulerWall_s',nan, ...
    'meanEndToEndWall_s',nan);
R=repmat(model,numel(names),1);
for j=1:numel(names)
    x=F(strcmp(algorithmLabels,names{j}),:);n=height(x);
    R(j)=model;R(j).algorithm=names{j};R(j).nFleetTrials=n;
    R(j).nGeomFleet=sum(x.geometryAllSuccess);
    R(j).nTimedFleet=sum(x.timedFleetSuccess);
    R(j).nStrictFleet=sum(x.strictFleetSuccess);
    R(j).geometryRate_pct=100*R(j).nGeomFleet/n;
    R(j).timedRate_pct=100*R(j).nTimedFleet/n;
    R(j).strictRate_pct=100*R(j).nStrictFleet/n;
    [lo,hi]=wilson(R(j).nStrictFleet,n);
    R(j).strictCI95Lower_pct=100*lo;
    R(j).strictCI95Upper_pct=100*hi;
    R(j).meanTurnCertifiedUAV=finiteMean(x.numTurnCertifiedUAV);
    vals=x.totalPathLength_m(isfinite(x.totalPathLength_m));
    R(j).nValidLengths=numel(vals);
    [R(j).meanTotalLength_m,R(j).stdTotalLength_m, ...
        R(j).lengthCI95Halfwidth_m]=describe(vals);
    R(j).meanFleetDetour=finiteMean(x.fleetDetourRatio);
    vals=x.makespan_s(isfinite(x.makespan_s));
    R(j).nTimedMakespans=numel(vals);
    [R(j).meanMakespan_s,R(j).stdMakespan_s, ...
        R(j).makespanCI95Halfwidth_s]=describe(vals);
    R(j).meanWait_s=finiteMean(x.totalDepartureWait_s);
    R(j).meanPreConflictPairs=finiteMean(x.preConflictPairs);
    R(j).meanMinInterUAVMargin_m=finiteMean( ...
        x.minInterUAVMargin_m);
    R(j).meanPlanningWall_s=finiteMean(x.planningWall_s);
    R(j).meanSchedulerWall_s=finiteMean(x.schedulerWall_s);
    R(j).meanEndToEndWall_s=finiteMean(x.endToEndWall_s);
end
T=struct2table(R);
end
function m=finiteMean(x)
y=x(isfinite(x));if isempty(y),m=nan;else,m=mean(y);end
end
function [mu,s,half]=describe(x)
mu=nan;s=nan;half=nan;
if isempty(x),return;end
mu=mean(x);
if numel(x)>1,s=std(x,0);half=1.96*s/sqrt(numel(x));end
end
function [lo,hi]=wilson(k,n)
% Wilson 95% binomial confidence interval; no external statistics toolbox.
z=1.959963984540054;
p=k/n;den=1+z*z/n;
c=(p+z*z/(2*n))/den;
h=z*sqrt(p*(1-p)/n+z*z/(4*n*n))/den;
lo=max(0,c-h);hi=min(1,c+h);
end
