function P=mmra_compare11_search(method,c,opts)
%MMRA_COMPARE11_SEARCH 3D A*, APF, RRT-Connect, and rewiring RRT*.
sc=c.scene;s=c.start(:)';g=c.goal(:)';
method=lower(char(method));
if mmra_compare11_oracle(sc,'edge',s,g)
    % Geometrically optimal direct-visibility fast path. This is logged in
    % the paper as a trivial geometric case; the Mendeley traffic check
    % is performed separately and may still reject this path.
    P=[s;g];return;
end
switch method
    case 'astar'
        P=astar3d(sc,s,g,opts);
    case 'apf'
        P=apf3d(sc,s,g,opts);
    case 'rrtconnect'
        P=rrtconnect3d(sc,s,g,opts);
    case {'rrtstar','informedrrtstar'}
        P=rrtstar3d(sc,s,g,opts,strcmp(method,'informedrrtstar'));
    otherwise
        error('Unknown search method');
end
end

function P=astar3d(sc,s,g,opts)
P=[];
b=sc.bounds;h=sc.gridStep;
xyz={};
for k=1:3
    n=max(2,ceil((b(k,2)-b(k,1))/h)+1);
    xyz{k}=linspace(b(k,1),b(k,2),n);
end
[X,Y,Z]=ndgrid(xyz{1},xyz{2},xyz{3});
nodes=[X(:),Y(:),Z(:)];
nxyz=size(X);N=size(nodes,1);
free=mmra_compare11_oracle(sc,'points',nodes);
parent=zeros(N,1);G=inf(N,1);closed=false(N,1);
open=false(N,1);
[~,order]=sort(sum((nodes-s).^2,2),'ascend');
connected=0;
for j=1:min(N,250)
    k=order(j);
    if free(k) && mmra_compare11_oracle(sc,'edge',s,nodes(k,:))
        G(k)=norm(nodes(k,:)-s);open(k)=true;
        connected=connected+1;
        if connected>=6,break;end
    end
end
if ~any(open),return;end
H=sqrt(sum((nodes-g).^2,2));
steps=0;bestIdx=0;bestGoal=inf;
while any(open) && steps<opts.astarExpansions
    ix=find(open);
    [~,j]=min(G(ix)+H(ix));u=ix(j);
    open(u)=false;
    if closed(u),continue;end
    closed(u)=true;steps=steps+1;
    if G(u)+H(u)>=bestGoal-1e-8,continue;end
    if H(u)<=3*sc.gridStep && ...
            mmra_compare11_oracle(sc,'edge',nodes(u,:),g)
        bestIdx=u;bestGoal=G(u)+H(u);break;
    end
    [a1,a2,a3]=ind2sub(nxyz,u);
    for dx=-1:1
        i=a1+dx;if i<1 || i>nxyz(1),continue;end
        for dy=-1:1
            j2=a2+dy;if j2<1 || j2>nxyz(2),continue;end
            for dz=-1:1
                k2=a3+dz;if k2<1 || k2>nxyz(3) || ...
                        (dx==0 && dy==0 && dz==0),continue;end
                v=sub2ind(nxyz,i,j2,k2);
                if ~free(v) || closed(v),continue;end
                alt=G(u)+norm(nodes(v,:)-nodes(u,:));
                if alt>=G(v)-1e-10,continue;end
                if ~mmra_compare11_oracle(sc,'edge',nodes(u,:),nodes(v,:))
                    continue;
                end
                G(v)=alt;parent(v)=u;open(v)=true;
            end
        end
    end
end
if bestIdx==0
    % Prefer a valid goal connector over treating an exhausted search as PASS.
    candidates=find(isfinite(G) & H<=4*sc.gridStep);
    if ~isempty(candidates)
        [~,q]=sort(G(candidates)+H(candidates));
        for k=1:numel(q)
            u=candidates(q(k));
            if mmra_compare11_oracle(sc,'edge',nodes(u,:),g)
                bestIdx=u;break;
            end
        end
    end
end
if bestIdx==0,return;end
route=bestIdx;
for it=1:N
    v=parent(route(1));
    if v==0,break;end
    route=[v;route]; %#ok<AGROW>
end
P=[s;nodes(route,:);g];
P=removeDuplicate(P);
end

function P=apf3d(sc,s,g,opts)
P=[];step=sc.rrtStep*0.8;
cur=s;route=s;stagnation=0;
for iter=1:opts.apfIterations
    if norm(g-cur)<=step && mmra_compare11_oracle(sc,'edge',cur,g)
        P=[route;g];return;
    end
    a=(g-cur)/max(norm(g-cur),eps);
    c=mmra_compare11_oracle(sc,'clearance',cur);
    rep=zeros(1,3);
    if c<2.8*step
        epsGrad=max(1,step/7);
        for d=1:3
            unit=zeros(1,3);unit(d)=epsGrad;
            l=mmra_compare11_oracle(sc,'clearance',cur+unit);
            r=mmra_compare11_oracle(sc,'clearance',cur-unit);
            rep(d)=(l-r)/(2*epsGrad);
        end
        if norm(rep)>1e-9
            rep=rep/norm(rep)*min(2.8, ...
                0.5*step/max(0.15*step,c+0.15*step));
        end
    end
    candidates=[a+rep; a; rep];
    for k=1:14
        noise=randn(1,3);noise=noise/max(norm(noise),eps);
        candidates(end+1,:)=a+1.5*noise; %#ok<AGROW>
    end
    best=[];bestScore=inf;
    for k=1:size(candidates,1)
        v=candidates(k,:);
        if norm(v)<1e-9,continue;end
        p=cur+step*v/norm(v);
        if ~all(mmra_compare11_oracle(sc,'points',p)) || ...
                ~mmra_compare11_oracle(sc,'edge',cur,p)
            continue;
        end
        cc=mmra_compare11_oracle(sc,'clearance',p);
        score=norm(g-p) + 0.15*step/max(cc/step+0.1,0.1);
        score=score+rand*step*min(1,stagnation/20)*0.5;
        if score<bestScore,bestScore=score;best=p;end
    end
    if isempty(best),return;end
    if norm(g-best)>=norm(g-cur)-0.05*step
        stagnation=stagnation+1;
    else
        stagnation=max(0,stagnation-1);
    end
    cur=best;route(end+1,:)=cur; %#ok<AGROW>
    if stagnation>80,return;end
end
end

function P=rrtconnect3d(sc,s,g,opts)
P=[];
Ta.xyz=s;Ta.parent=0;Tb.xyz=g;Tb.parent=0;
for it=1:opts.rrtIterations
    if mod(it,2)==1
        x=randPoint(sc,s,g,.15);
        [Ta,ia]=extend(Ta,x,sc,sc.rrtStep);
        if ia~=0
            [Tb,ib,hit]=connect(Tb,Ta.xyz(ia,:),sc,sc.rrtStep);
            if hit
                left=trace(Ta,ia);right=trace(Tb,ib);
                P=[left;flipud(right)];P=removeDuplicate(P);return;
            end
        end
    else
        x=randPoint(sc,s,g,.15);
        [Tb,ib]=extend(Tb,x,sc,sc.rrtStep);
        if ib~=0
            [Ta,ia,hit]=connect(Ta,Tb.xyz(ib,:),sc,sc.rrtStep);
            if hit
                left=trace(Ta,ia);right=trace(Tb,ib);
                P=[left;flipud(right)];P=removeDuplicate(P);return;
            end
        end
    end
end
end

function [T,idx]=extend(T,target,sc,step)
idx=0;diffs=bsxfun(@minus,T.xyz,target);
[~,q]=min(sum(diffs.^2,2));
v=target-T.xyz(q,:);d=norm(v);
if d<1e-9,idx=q;return;end
p=T.xyz(q,:)+min(step,d)*v/d;
if ~mmra_compare11_oracle(sc,'edge',T.xyz(q,:),p),return;end
T.xyz(end+1,:)=p;T.parent(end+1,1)=q;
idx=size(T.xyz,1);
end

function [T,idx,hit]=connect(T,target,sc,step)
idx=0;hit=false;
for j=1:120
    before=size(T.xyz,1);
    [T,idx]=extend(T,target,sc,step);
    if idx==0,return;end
    if norm(T.xyz(idx,:)-target)<1e-7,hit=true;return;end
    if size(T.xyz,1)==before,return;end
end
end

function P=rrtstar3d(sc,s,g,opts,informed)
P=[];
X=s;parent=0;cost=0;
best=inf;
for it=1:opts.rrtIterations
    if informed && isfinite(best) && rand>.15
        target=informedSample(sc,s,g,best);
    else
        target=randPoint(sc,s,g,.12);
    end
    if ~all(mmra_compare11_oracle(sc,'points',target)),continue;end
    D=sqrt(sum(bsxfun(@minus,X,target).^2,2));
    [d,nearest]=min(D);
    if d<1e-8,continue;end
    p=X(nearest,:)+min(d,sc.rrtStep)*(target-X(nearest,:))/d;
    if ~mmra_compare11_oracle(sc,'edge',X(nearest,:),p),continue;end
    ds=sqrt(sum(bsxfun(@minus,X,p).^2,2));
    radius=max(sc.rrtStep*1.8, ...
        min(sc.rrtStep*3.2,sc.rrtStep*5* ...
        (log(size(X,1)+2)/(size(X,1)+2))^(1/3)));
    neigh=find(ds<=radius);
    cp=cost(nearest)+norm(X(nearest,:)-p);par=nearest;
    for kk=1:numel(neigh)
        i=neigh(kk);
        alt=cost(i)+ds(i);
        if alt<cp && mmra_compare11_oracle(sc,'edge',X(i,:),p)
            cp=alt;par=i;
        end
    end
    X(end+1,:)=p;parent(end+1,1)=par;cost(end+1,1)=cp;
    new=size(X,1);
    for kk=1:numel(neigh)
        i=neigh(kk);
        alt=cost(new)+ds(i);
        if alt+1e-9<cost(i) && ...
                mmra_compare11_oracle(sc,'edge',p,X(i,:))
            delta=alt-cost(i);
            parent(i)=new;cost(i)=alt;
            queue=i;
            while ~isempty(queue)
                old=queue(1);queue(1)=[];
                ch=find(parent==old);
                cost(ch)=cost(ch)+delta;
                queue=[queue;ch(:)]; %#ok<AGROW>
            end
        end
    end
    if norm(p-g)<sc.rrtStep*3 && ...
            mmra_compare11_oracle(sc,'edge',p,g)
        best=min(best,cost(new)+norm(p-g));
    end
end
% Re-evaluate current tree costs and connectors after all rewirings.
dg=sqrt(sum(bsxfun(@minus,X,g).^2,2));
idx=find(dg<=max(sc.rrtStep*3,sc.gridStep));
if isempty(idx),return;end
[~,order]=sort(cost(idx)+dg(idx));
node=0;
for k=1:numel(order)
    i=idx(order(k));
    if mmra_compare11_oracle(sc,'edge',X(i,:),g)
        node=i;break;
    end
end
if node==0,return;end
P=[trace(struct('xyz',X,'parent',parent),node);g];
P=removeDuplicate(P);
end

function p=informedSample(sc,s,g,best)
minDist=norm(g-s);
if best<=minDist+1e-5
    p=randPoint(sc,s,g,0);return;
end
e1=(g-s)/minDist;
fallback=[0 0 1];
if abs(dot(e1,fallback))>0.9,fallback=[0 1 0];end
e2=cross(e1,fallback);e2=e2/norm(e2);
e3=cross(e1,e2);B=[e1(:),e2(:),e3(:)];
u=randn(3,1);u=u/max(norm(u),eps)*rand^(1/3);
radii=[best/2;sqrt(max(0,best^2-minDist^2))/2; ...
    sqrt(max(0,best^2-minDist^2))/2];
p=reshape((s+g)/2,3,1)+B*(radii.*u);
p=p(:)';
end

function p=randPoint(sc,s,g,bias)
if rand<bias,p=g;return;end
b=sc.bounds;
p=b(:,1)'+rand(1,3).*(b(:,2)'-b(:,1)');
end

function P=trace(T,idx)
ids=idx;
while T.parent(ids(1))>0
    ids=[T.parent(ids(1));ids]; %#ok<AGROW>
    if numel(ids)>size(T.xyz,1),error('Planner tree cycle');end
end
P=T.xyz(ids,:);
end

function P=removeDuplicate(P)
if isempty(P),return;end
keep=[true;sum(diff(P,1,1).^2,2)>1e-12];P=P(keep,:);
end
