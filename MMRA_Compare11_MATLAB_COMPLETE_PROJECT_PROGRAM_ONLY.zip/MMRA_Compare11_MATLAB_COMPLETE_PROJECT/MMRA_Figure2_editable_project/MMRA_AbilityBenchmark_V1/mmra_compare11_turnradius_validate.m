function cert = mmra_compare11_turnradius_validate(P,curveControls,minRadius_m,maxPitch_deg)
%MMRA_COMPARE11_TURNRADIUS_VALIDATE Independent 3-D curvature/G1 validator.
%   cert = mmra_compare11_turnradius_validate(P,controls,10,75)
%
% P is the actual Nx3 returned path. The Nx9 controls are the ORIGINAL
% quadratic Bezier triples [S C E] from the planner. This verifier checks
% that every stored control triple corresponds to consecutive, UNALTERED,
% uniformly sampled path points, before trusting its analytic radius.
%
% A nonzero angle between two straight pieces (or at a straight/curve
% junction) has zero instantaneous turning radius: that is not a flyable
% finite-curvature path. Inside a Bezier arc, polyline chord angles are
% intentionally NOT treated as physical corners. The physical flight
% reference is the continuous quadratic arc, not its drawing samples.
%
% 3-D osculating radius, not a horizontal-only bank/yaw radius. This is
% a geometric curvature + tangent/pitch certificate, NOT a certificate of
% acceleration, thrust, jerk, yaw-rate, timing, or dynamics feasibility.
if nargin<2 || isempty(curveControls),curveControls=zeros(0,9);end
if nargin<3 || isempty(minRadius_m),minRadius_m=10;end
if nargin<4 || isempty(maxPitch_deg),maxPitch_deg=75;end
cert=struct('certified',false,'status','INVALID_PATH', ...
    'requiredRadius_m',minRadius_m,'minCurveRadius_m',inf, ...
    'minPathTurnRadius_m',nan,'maxJunctionAngle_deg',nan, ...
    'numSharpJunctions',0,'worstJunctionIndex',0, ...
    'maxPathPitch_deg',nan,'numVerifiedCurves',0, ...
    'maxCurveReconstructionError_m',nan);
if ~isnumeric(P) || size(P,2)~=3 || size(P,1)<2 || ...
        any(~isfinite(P(:))) || ~isreal(P)
    return;
end
if ~isnumeric(curveControls) || size(curveControls,2)~=9 || ...
        any(~isfinite(curveControls(:))) || ~isreal(curveControls) || ...
        ~isscalar(minRadius_m) || ~isfinite(minRadius_m) || minRadius_m<=0 || ...
        ~isscalar(maxPitch_deg) || ~isfinite(maxPitch_deg) || ...
        maxPitch_deg<=0 || maxPitch_deg>90
    cert.status='INVALID_CERTIFICATE_INPUT';return;
end
P=double(P);curveControls=double(curveControls);
N=size(P,1);D=diff(P,1,1);
if any(sqrt(sum(D.^2,2))<1e-10)
    cert.status='DUPLICATE_PATH_POINTS';return;
end
% Tangents on the straight sections. Curved intervals will overwrite
% endpoint tangents and are excluded from artificial chord-corner tests.
Tbefore=zeros(N,3);Tafter=zeros(N,3);
Tbefore(2:end,:)=D;Tafter(1:end-1,:)=D;
insideCurve=false(N,1);usedEdge=false(N-1,1);
lastEnd=1;
maxReconstructionError=0;
maxCurvePitch=0;
numCurves=size(curveControls,1);
for j=1:numCurves
    S=curveControls(j,1:3);
    C=curveControls(j,4:6);
    E=curveControls(j,7:9);
    sHits=find(sum(bsxfun(@minus,P,S).^2,2)<(1e-5)^2 & ...
        (1:N)'>=lastEnd,1,'first');
    if isempty(sHits)
        cert.status='BEZIER_CONTROL_NOT_ON_PATH';return;
    end
    s=sHits;
    eHits=find(sum(bsxfun(@minus,P,E).^2,2)<(1e-5)^2 & ...
        (1:N)'>s,1,'first');
    if isempty(eHits)
        cert.status='BEZIER_CONTROL_NOT_ON_PATH';return;
    end
    e=eHits;
    if any(usedEdge(s:e-1))
        cert.status='OVERLAPPING_BEZIER_ARCS';return;
    end
    t=linspace(0,1,e-s+1)';
    expected=bsxfun(@times,(1-t).^2,S)+ ...
        bsxfun(@times,2*t.*(1-t),C)+bsxfun(@times,t.^2,E);
    err=max(sqrt(sum((P(s:e,:)-expected).^2,2)));
    maxReconstructionError=max(maxReconstructionError,err);
    if err>1e-5
        cert.status='BEZIER_SAMPLES_MISMATCH';return;
    end
    usedEdge(s:e-1)=true;
    if e-s>1,insideCurve(s+1:e-1)=true;end
    u=C-S;v=E-C;w=v-u;
    if norm(u)<1e-10 || norm(v)<1e-10
        cert.status='BEZIER_ZERO_TANGENT';return;
    end
    % Quadratic B'(t)=2*(u+t*w); B''(t)=2*w.
    % The exact maximum curvature occurs at the smallest tangent speed.
    den=dot(w,w);
    if den<1e-20
        tStar=0;
    else
        tStar=max(0,min(1,-dot(u,w)/den));
    end
    vMin=u+tStar*w;
    if norm(vMin)<1e-10*max(norm(u),norm(v))
        cert.minCurveRadius_m=0;
        cert.status='BEZIER_CUSP';return;
    end
    crossNorm=norm(cross(u,v));
    if crossNorm<1e-14
        radius=inf;
    else
        radius=2*norm(vMin)^3/crossNorm;
    end
    cert.minCurveRadius_m=min(cert.minCurveRadius_m,radius);
    maxCurvePitch=max(maxCurvePitch,quadraticMaxPitch(u,w));
    Tafter(s,:)=u;
    Tbefore(e,:)=v;
    lastEnd=e;
    cert.numVerifiedCurves=j;
end
cert.maxCurveReconstructionError_m=maxReconstructionError;
% Straight-edge pitch plus EXACT extremum of all continuous Bezier arcs.
if any(~usedEdge)
    linearD=D(~usedEdge,:);
    pitchStraight=max(atan2d(abs(linearD(:,3)), ...
        sqrt(sum(linearD(:,1:2).^2,2))));
else
    pitchStraight=0;
end
cert.maxPathPitch_deg=max(pitchStraight,maxCurvePitch);
cert.maxJunctionAngle_deg=0;
cert.worstJunctionIndex=0;
% Never interpret drawing chords *within* a continuous Bezier as kinks.
for k=2:N-1
    if insideCurve(k),continue;end
    vin=Tbefore(k,:);vout=Tafter(k,:);
    if norm(vin)<1e-10 || norm(vout)<1e-10
        cert.status='ZERO_JUNCTION_TANGENT';return;
    end
    angle=atan2d(norm(cross(vin,vout)),dot(vin,vout));
    if angle>cert.maxJunctionAngle_deg
        cert.maxJunctionAngle_deg=angle;
        cert.worstJunctionIndex=k;
    end
    % 0.001 deg is an explicit floating point G1 tolerance, not a
    % physically meaningful relaxed turn-radius limit.
    if angle>1e-3
        cert.numSharpJunctions=cert.numSharpJunctions+1;
    end
end
if cert.numSharpJunctions>0
    cert.minPathTurnRadius_m=0;
    cert.status='SHARP_JUNCTION';return;
end
cert.minPathTurnRadius_m=cert.minCurveRadius_m;
if cert.minCurveRadius_m+1e-8<minRadius_m
    cert.status='CURVE_RADIUS_BELOW_LIMIT';return;
end
if cert.maxPathPitch_deg>maxPitch_deg+1e-8
    cert.status='PATH_PITCH_ABOVE_LIMIT';return;
end
cert.certified=true;
cert.status='CERTIFIED_CURVATURE_G1_PITCH';
end

function pitch=quadraticMaxPitch(u,w)
% Exact max of absolute tangent pitch for v(t)=u+t*w, t in [0,1].
a=dot(u(1:2),u(1:2));
b=dot(u(1:2),w(1:2));
c=dot(w(1:2),w(1:2));
z=u(3);wz=w(3);
t=[0;1];den=wz*b-z*c;
if abs(den)>1e-15
    root=(z*b-wz*a)/den;
    if root>0 && root<1,t(end+1,1)=root;end
end
if c>1e-15
    root=-b/c;
    if root>0 && root<1,t(end+1,1)=root;end
end
V=bsxfun(@plus,u,bsxfun(@times,t,w));
pitch=max(atan2d(abs(V(:,3)),sqrt(sum(V(:,1:2).^2,2))));
end
