function R = run_mmra_bottleneck_probe(suite,nSeeds,mode,firstSeed)
%RUN_MMRA_BOTTLENECK_PROBE Explore critical UAV in matched ACO/MMRA fleets.
% Example: R=run_mmra_bottleneck_probe('figure2',10,'pilot',6);
% 10 seeds * 2 methods * 5 UAVs = 100 actual planner calls.
% Set mode='full' for a follow-up using the production planning budget.
% This is a diagnostic study, NOT a fully fair flight-feasibility comparison:
% ACO routes lack the same strict curve certification as MMRA.
if nargin<1 || isempty(suite),suite='figure2';end
if nargin<2 || isempty(nSeeds),nSeeds=10;end
if nargin<3 || isempty(mode),mode='pilot';end
if nargin<4 || isempty(firstSeed),firstSeed=6;end
suite=lower(char(suite));mode=lower(char(mode));
assert(ismember(suite,{'figure2','urban500'}), 'Unknown map.');
assert(ismember(mode,{'pilot','full'}), 'Mode must be pilot/full.');
assert(isnumeric(nSeeds) && isscalar(nSeeds) && isfinite(nSeeds) && ...
    nSeeds==fix(nSeeds) && nSeeds>=1 && nSeeds<=2000, ...
    'nSeeds must be an integer between 1 and 2000.');
assert(isnumeric(firstSeed) && isscalar(firstSeed) && isfinite(firstSeed) && ...
    firstSeed==fix(firstSeed) && firstSeed>=1, ...
    'firstSeed must be a positive integer.');
assert(exist('mmra_fleet11_trial','file')==2 && ...
    exist('mmra_compare11_cases','file')==2, ...
    'Fleet11 not installed. Add MMRA_AbilityBenchmark_V1 to MATLAB path.');
assert(exist('mmra_bottleneck_probe_analyze','file')==2, ...
    'Analyzer missing; install the whole probe package.');
C=mmra_compare11_cases(suite);
assert(numel(C)==5,'Expected five authentic map missions.');
o=mmra_fleet11_options(mode);
methods={'ACO','MMRA'};
root=fileparts(mfilename('fullpath'));
outDir=fullfile(root,'benchmark_results','Fleet11','BottleneckProbe');
if ~isfolder(outDir),mkdir(outDir);end
prefix=sprintf('BOTTLENECK_%s_%s_%d_%d',upper(suite), ...
    upper(mode),firstSeed,firstSeed+nSeeds-1);
checkpoint=fullfile(outDir,[prefix '_checkpoint.mat']);
if isfile(checkpoint)
    z=load(checkpoint,'state');state=z.state;
    assert(state.version==1 && strcmp(state.suite,suite) && ...
        strcmp(state.mode,mode) && state.firstSeed==firstSeed && ...
        state.nSeeds==nSeeds && isequaln(state.options,o) && ...
        isequal(state.methods,methods), ...
        'Checkpoint parameters changed. Change seed range/mode.');
    fprintf('Resuming existing probe checkpoint: %s\n',checkpoint);
else
    state=struct('version',1,'suite',suite,'mode',mode, ...
        'firstSeed',firstSeed,'nSeeds',nSeeds,'options',o, ...
        'methods',{methods},'fleet',{cell(nSeeds,2)}, ...
        'uav',{cell(nSeeds,2)},'paths',{cell(nSeeds,2)}, ...
        'trajectories',{cell(nSeeds,2)},'infos',{cell(nSeeds,2)});
end
fprintf('\nBottleneck probe: %s / %s / fleet seeds %d..%d\n', ...
    upper(suite),mode,firstSeed,firstSeed+nSeeds-1);
fprintf('%d fleet trials; %d five-UAV solves; 2 methods only (ACO/MMRA).\n', ...
    nSeeds*2,nSeeds*2*5);
for q=1:nSeeds
    seedIndex=firstSeed+q-1;
    for j=1:2
        if ~isempty(state.fleet{q,j})
            fprintf('SKIP cached: seed=%d %-5s\n',seedIndex,methods{j});
            continue;
        end
        [f,ur,~,paths,traj,infos]=mmra_fleet11_trial( ...
            C,methods{j},seedIndex,mode,o);
        state.fleet{q,j}=f;
        state.uav{q,j}=ur;
        state.paths{q,j}=paths;
        state.trajectories{q,j}=traj;
        state.infos{q,j}=infos;
        save(checkpoint,'state','-v7.3');
        fprintf('seed=%d %-5s | geometry=%d/5 | timed=%d | strict=%d', ...
            seedIndex,methods{j},f.numGeometryUAV, ...
            f.timedFleetSuccess,f.strictFleetSuccess);
        fprintf(' | length=%.2f m | makespan=%.2f s | %s\n', ...
            f.totalPathLength_m,f.makespan_s,f.status);
    end
end
fs=cell(nSeeds*2,1);us=cell(nSeeds*2,1);k=0;
for q=1:nSeeds
    for j=1:2
        k=k+1;fs{k}=state.fleet{q,j};us{k}=state.uav{q,j};
    end
end
F=struct2table(vertcat(fs{:}));
U=struct2table(vertcat(us{:}));
R=mmra_bottleneck_probe_analyze(F,U);
R.outDir=outDir;R.prefix=prefix;R.checkpoint=checkpoint;
writetable(R.fleet,fullfile(outDir,[prefix '_fleet_trials.csv']));
writetable(R.uav,fullfile(outDir,[prefix '_uav_trials.csv']));
writetable(R.paired,fullfile(outDir,[prefix '_paired.csv']));
writetable(R.critical,fullfile(outDir,[prefix '_critical_counts.csv']));
writetable(R.summary,fullfile(outDir,[prefix '_summary.csv']));
S=R.summary;
fprintf('\n=== BOTTLENECK PROBE SUMMARY ===\n');
fprintf('Matched fleet seeds: %d | Both timed: %d | Both geometrically valid: %d\n', ...
    S.nSeedPairs,S.nBothTimed,S.nBothGeometry);
fprintf('MMRA shorter total path: %d/%d comparable seeds\n', ...
    S.nMMRAShorterTotalLength,S.nComparableLengths);
fprintf('MMRA faster fleet finish: %d/%d comparable seeds\n', ...
    S.nMMRAFasterMakespan,S.nComparableMakespans);
fprintf('MMRA shorter total path BUT slower makespan: %d/%d both timed\n', ...
    S.nLengthWinButSlower,S.nBothTimed);
fprintf('Mean (MMRA-ACO) length: %.2f m; makespan: %.2f s\n', ...
    S.meanLengthDelta_m,S.meanMakespanDelta_s);
fprintf('Critical UAV distribution (each tied last UAV counts):\n');
disp(R.critical);
fprintf('Saved result tables in: %s\n',outDir);
fprintf('This probes bottlenecks only; ACO is NOT curvature-certified.\n');
end
