function [smoothed,stage,post] = urban500_mmra_postprocess(rawPath,inflatedBoxes,cfg)
%URBAN500_MMRA_POSTPROCESS Connect Urban500 RRT* to MMRA shared modules.
% Execution: raw RRT* -> MMRA visibility pruning -> MMRA adaptive Bezier
% -> independently verify each resulting chord against INFLATED AABBs.
% Crucially, the smooth curve itself is certified by recursive subdivision.
% No change to building geometry, RRT* search, dynamic spheres, or other
% MMRA experiments. No path is replaced with a guessed 'nice' arc.
root=fileparts(mfilename('fullpath'));
mmraSrc=fullfile(fileparts(fileparts(root)),'src');
assert(exist(fullfile(mmraSrc,'mmra_bezier.m'),'file')==2, ...
    ['Shared MMRA src folder missing. Keep the supplied full project ' ...
     'directory structure; do not copy only the Urban500 folder.']);
addpath(mmraSrc);

postCfg=struct();
postCfg.pruneMode='shortest_visibility';
postCfg.smoothMode='adaptive_safe';
postCfg.bezierSamples=8;
postCfg.smoothMinRadius_m=10;
postCfg.smoothMaxPitch_deg=75;
postCfg.smoothTrimFraction=0.44;
postCfg.smoothTerminalTrimFraction=0.96; % only last interior corner
postCfg.mmraTerminalRepair=true;      % backup: swap terminal waypoint
postCfg.mmraTerminalRepairMaxCandidates=40;
postCfg.mmraTerminalRepairMaxExtra_m=35;
% Verified local waypoint relocation for previously unroundable corners.
postCfg.mmraLocalRepair=true;
postCfg.mmraLocalRepairMaxExtra_m=55;
postCfg.mmraLocalRepairMaxPasses=2;
postCfg.mmraLocalRepairMaxCandidates=550;
postCfg.smoothMaxChord_m=2.5;
postCfg.smoothMaxSagitta_m=0.10;
postCfg.smoothMinAngle_deg=2;
postCfg.smoothMaxSamples=1000;
if isfield(cfg,'mmraPruneMode'), postCfg.pruneMode=cfg.mmraPruneMode; end
if isfield(cfg,'smoothMinRadius_m'), postCfg.smoothMinRadius_m=cfg.smoothMinRadius_m; end
if isfield(cfg,'smoothMaxPitch_deg'), postCfg.smoothMaxPitch_deg=cfg.smoothMaxPitch_deg; end
if isfield(cfg,'smoothTrimFraction'), postCfg.smoothTrimFraction=cfg.smoothTrimFraction; end
if isfield(cfg,'smoothTerminalTrimFraction'), postCfg.smoothTerminalTrimFraction=cfg.smoothTerminalTrimFraction; end
if isfield(cfg,'mmraTerminalRepair'), postCfg.mmraTerminalRepair=cfg.mmraTerminalRepair; end
if isfield(cfg,'mmraTerminalRepairMaxCandidates'), postCfg.mmraTerminalRepairMaxCandidates=cfg.mmraTerminalRepairMaxCandidates; end
if isfield(cfg,'mmraTerminalRepairMaxExtra_m'), postCfg.mmraTerminalRepairMaxExtra_m=cfg.mmraTerminalRepairMaxExtra_m; end
if isfield(cfg,'mmraLocalRepair'), postCfg.mmraLocalRepair=cfg.mmraLocalRepair; end
if isfield(cfg,'mmraLocalRepairMaxExtra_m'), postCfg.mmraLocalRepairMaxExtra_m=cfg.mmraLocalRepairMaxExtra_m; end
if isfield(cfg,'mmraLocalRepairMaxPasses'), postCfg.mmraLocalRepairMaxPasses=cfg.mmraLocalRepairMaxPasses; end
if isfield(cfg,'mmraLocalRepairMaxCandidates'), postCfg.mmraLocalRepairMaxCandidates=cfg.mmraLocalRepairMaxCandidates; end
if isfield(cfg,'smoothMaxChord_m'), postCfg.smoothMaxChord_m=cfg.smoothMaxChord_m; end
if isfield(cfg,'smoothMaxSagitta_m'), postCfg.smoothMaxSagitta_m=cfg.smoothMaxSagitta_m; end
if isfield(cfg,'smoothMinAngle_deg'), postCfg.smoothMinAngle_deg=cfg.smoothMinAngle_deg; end
if isfield(cfg,'smoothMaxSamples'), postCfg.smoothMaxSamples=cfg.smoothMaxSamples; end
% Function handles remain LOCAL and are deliberately not stored in cfg/MAT.
postCfg.edgeFreeFcn=@(a,b)urban500_rrtstar_edge_free(a,b,inflatedBoxes);
postCfg.curveFreeFcn=@(s,c,e)urban500_bezier_curve_free( ...
    s,c,e,inflatedBoxes,15);

stage=struct('raw',rawPath,'prunedInitial',[],'pruned',[],'smoothed',[]);
assert(mmra_postprocess_path_free(rawPath,[],postCfg), ...
    'The RRT* raw path is not collision-free. No postprocess permitted.');
assert(insideBounds(rawPath,cfg), 'RRT* raw path outside cfg.bounds_m.');

pruned=mmra_prune(rawPath,[],postCfg);
assert(mmra_postprocess_path_free(pruned,[],postCfg) && ...
    insideBounds(pruned,cfg), 'MMRA pruning failed independent checks.');
prunedInitial=pruned;
[smoothed,accepted,smoothStats]=mmra_bezier(pruned,[],postCfg);
% If the FINAL interior corner cannot reach the requested minimum turning
% radius, try other RRT* raw waypoints for that one local turn. Each option
% is independently collision-tested and the ENTIRE revised route is
% re-smoothed and certified. Fail closed: preserve original if none passes.
[pruned,smoothed,smoothStats,terminalRepair]= ...
    urban500_mmra_terminal_repair(rawPath,pruned,smoothed, ...
    smoothStats,postCfg,cfg);
% Repair only the remaining failed corners. Every proposed relocation must
% pass original inflated-box edge/curve checks AND independent G1/10m/pitch.
[pruned,smoothed,smoothStats,localRepair]= ...
    urban500_mmra_local_repair(pruned,smoothed,smoothStats,postCfg,cfg);
accepted=smoothStats.roundedCorners>0;
assert(mmra_postprocess_path_free(smoothed,[],postCfg) && ...
    insideBounds(smoothed,cfg), 'MMRA smoothed output failed final checks.');
assert(norm(smoothed(1,:)-rawPath(1,:))<1e-8 && ...
    norm(smoothed(end,:)-rawPath(end,:))<1e-8, ...
    'Postprocessing changed a mission start or goal.');

stage.prunedInitial=prunedInitial;
stage.pruned=pruned;
stage.smoothed=smoothed;
post=struct();
post.mode=['MMRA-' char(postCfg.pruneMode) '+adaptive-safe-Bezier'];
if localRepair.succeeded
    post.mode=[post.mode '+verified-local-repair'];
end
post.rawWaypoints=size(rawPath,1);
post.prunedWaypoints=size(pruned,1);
post.prunedInitialWaypoints=size(prunedInitial,1);
post.smoothWaypoints=size(smoothed,1);
post.rawLength_m=pathLength(rawPath);
post.prunedLength_m=pathLength(pruned);
post.smoothLength_m=pathLength(smoothed);
post.pruneSaved_m=post.rawLength_m-post.prunedLength_m;
post.maxAngleBefore_deg=maxTurn(pruned);
post.maxAngleAfter_deg=maxTurn(smoothed);
post.smoothAccepted=accepted;
post.roundedCorners=smoothStats.roundedCorners;
post.totalCorners=smoothStats.cornersConsidered;
post.allEligibleCornersSmoothed=smoothStats.fullySmoothed;
post.minAcceptedCurveRadius_m=smoothStats.minAcceptedRadius_m;
post.rejectedCollision=smoothStats.collisionRejected;
post.rejectedRadius=smoothStats.radiusRejected;
post.rejectedPitch=smoothStats.pitchRejected;
post.rejectedResolution=smoothStats.resolutionRejected;
post.curveControls=smoothStats.curveControls;
post.curveCornerIndices=smoothStats.curveCornerIndices;
post.curveRadii_m=smoothStats.curveRadii_m;
post.failedCornerIndices=smoothStats.failedCornerIndices;
post.failedCornerReasons=smoothStats.failedCornerReasons;
post.failedCornerMaxRadius_m=smoothStats.failedCornerMaxRadius_m;
post.failedCornerMaxTrim_m=smoothStats.failedCornerMaxTrim_m;
post.terminalRepair=terminalRepair;
post.localRepair=localRepair;
post.curveCertificate='quadratic convex-hull / de Casteljau / inflated AABB';
post.staticCollisionVerified=true;
post.minTurnRadiusSetting_m=postCfg.smoothMinRadius_m;
post.maxCurvePitchSetting_deg=postCfg.smoothMaxPitch_deg;
% Not a dynamics certificate: acceleration, speed, timing, and dynamic
% spheres are NOT considered, and tight fallback corners may remain.
if ~post.allEligibleCornersSmoothed
    warning('Urban500: %d/%d corners rounded; unsmoothed original kinks remain.', ...
        post.roundedCorners,post.totalCorners);
end
end

function t=insideBounds(P,cfg)
t=true;
if isfield(cfg,'bounds_m') && ~isempty(cfg.bounds_m)
    b=cfg.bounds_m;
    t=all(all(bsxfun(@ge,P,b(:,1)'-1e-8) & ...
        bsxfun(@le,P,b(:,2)'+1e-8)));
end
end

function len=pathLength(P)
len=sum(sqrt(sum(diff(P,1,1).^2,2)));
end
function a=maxTurn(P)
a=0;
D=diff(P,1,1);
for i=1:size(D,1)-1
    la=norm(D(i,:));lb=norm(D(i+1,:));
    if la>1e-9 && lb>1e-9
        a=max(a,acosd(max(-1,min(1,dot(D(i,:),D(i+1,:))/(la*lb)))));
    end
end
end
