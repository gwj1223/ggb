function [F,Us,Pairs,Paths,Traj,Infos] = mmra_fleet11_trial( ...
    cases,algorithm,repeatIndex,mode,o)
%MMRA_FLEET11_TRIAL One genuine FIVE-UAV, same-algorithm fleet task.
% Requires cases to be the 5 authentic tasks from one static scene.
% Each UAV has the exact preexisting Compare11 seed mapping. Planning is
% sequential; fleet planningWall_s is measured across all five planners.
% The common scheduler cannot modify spatial routes, only start delays.
assert(numel(cases)==5,'Fleet benchmark requires exactly five UAV cases.');
assert(all(strcmp({cases.suite},cases(1).suite)), ...
    'All UAVs must belong to one map.');
assert(repeatIndex>=1 && repeatIndex==floor(repeatIndex));
N=5;name=upper(char(algorithm));
F=struct('suite',cases(1).suite,'algorithm',name, ...
    'fleetSeedIndex',repeatIndex,'numUAV',N, ...
    'geometryAllSuccess',false,'turnAllCertified',false, ...
    'timedFleetSuccess',false,'strictFleetSuccess',false, ...
    'deadlineSatisfied',nan,'missionDeadline_s',o.missionDeadline_s, ...
    'status','NOT_RUN', ...
    'numGeometryUAV',0,'numTurnCertifiedUAV',0, ...
    'totalPathLength_m',nan,'meanPathLength_m',nan, ...
    'stdPathLength_m',nan,'fleetDetourRatio',nan, ...
    'minObstacleClearanceSampled_m',nan, ...
    'minTurnRadius_m',nan,'maxPathPitch_deg',nan, ...
    'makespan_s',nan,'meanArrival_s',nan, ...
    'totalDepartureWait_s',nan,'maxDepartureWait_s',nan, ...
    'preConflictPairs',nan,'postConflictPairs',nan, ...
    'minInterUAVPolyline_m',nan,'minInterUAVCertifiedLB_m',nan, ...
    'minInterUAVMargin_m',nan,'violationDuration_s',nan, ...
    'numPairsChecked',0,'planningWall_s',nan, ...
    'schedulerWall_s',nan,'verificationWall_s',nan, ...
    'endToEndWall_s',nan,'cruiseSpeed_mps',o.cruiseSpeed_mps, ...
    'requiredSeparation_m',o.requiredSeparation_m, ...
    'requiredTurnRadius_m',o.turnRadiusRequired_m, ...
    'maxPitchAllowed_deg',o.pitchLimit_deg, ...
    'maxDepartureDelay_s',o.maxDepartureDelay_s, ...
    'startPolicy',o.startPolicy,'endPolicy',o.endPolicy, ...
    'schedulerName',o.scheduler,'dynamicObstacleChecked',false, ...
    'energy_Wh',nan,'maxAcceleration_mps2',nan,'maxJerk_mps3',nan);
u0=struct('suite',cases(1).suite,'algorithm',name, ...
    'fleetSeedIndex',repeatIndex,'uavIndex',0, ...
    'case_id','','seed',0,'geometrySuccess',false, ...
    'turnCertified',false,'strictSuccess',false, ...
    'status','NOT_RUN','turnStatus','NOT_CHECKED', ...
    'pathLength_m',nan,'directDistance_m',nan, ...
    'detourRatio',nan,'minClearanceSampled_m',nan, ...
    'minTurnRadius_m',nan,'maxPitch_deg',nan, ...
    'curveErrorBound_m',nan,'curveBoundVerified',false, ...
    'curveBoundNote','NOT_CHECKED','planning_s',nan, ...
    'validation_s',nan,'departureWait_s',nan,'arrival_s',nan, ...
    'implementation_note','');
Us=repmat(u0,N,1);Paths=cell(N,1);Traj=cell(N,1);
Infos=cell(N,1);Pairs=[];
plannerOpts=mmra_compare11_options(mode);
% FLEET_REPAIR_ABLATION_PROPAGATION_V1
if isfield(o,'figure2LocalRepairEnabled')
    v=o.figure2LocalRepairEnabled;
    assert((isnumeric(v) || islogical(v)) && isscalar(v) && ...
        isfinite(double(v)) && any(double(v)==[0 1]), ...
        'figure2LocalRepairEnabled must be logical 0 or 1');
    plannerOpts.figure2LocalRepairEnabled=logical(v);
end
% END_FLEET_REPAIR_ABLATION_PROPAGATION_V1
clockAll=tic;len=nan(N,1);errors=nan(N,1);
for i=1:N
    c=cases(i);Us(i)=u0;
    Us(i).uavIndex=i;Us(i).case_id=c.id;
    seed=24001+1009*i+211*(repeatIndex+o.seedOffset);
    Us(i).seed=seed;
    Us(i).directDistance_m=norm(c.goal-c.start);
    planClk=tic;
    try
        [P,info]=mmra_compare11_solve(name,c,seed,plannerOpts);
        Us(i).planning_s=toc(planClk);
        info.minRadiusRequirement_m=o.turnRadiusRequired_m;
        info.maxPitchRequirement_deg=o.pitchLimit_deg;
        Paths{i}=P;Infos{i}=info;
        Us(i).implementation_note=info.note;
        validateClk=tic;
        v=mmra_compare11_validate(c,P,info);
        Us(i).validation_s=toc(validateClk);
        Us(i).geometrySuccess=logical(v.geometrySuccess);
        Us(i).turnCertified=logical(v.turnCertified);
        Us(i).strictSuccess=logical(v.strictSuccess);
        Us(i).status=v.status;Us(i).turnStatus=v.turnStatus;
        Us(i).pathLength_m=v.length_m;
        Us(i).minClearanceSampled_m=v.minClearance_m;
        Us(i).minTurnRadius_m=v.minPathTurnRadius_m;
        Us(i).maxPitch_deg=v.maxPathPitch_deg;
        if v.geometrySuccess && Us(i).directDistance_m>0
            Us(i).detourRatio=v.length_m/Us(i).directDistance_m;
        end
        [epsm,valid,reason]=mmra_fleet11_curve_bound(P,info);
        Us(i).curveErrorBound_m=epsm;
        Us(i).curveBoundVerified=valid;
        Us(i).curveBoundNote=reason;
        len(i)=v.length_m;errors(i)=epsm;
    catch ME
        if isnan(Us(i).planning_s),Us(i).planning_s=toc(planClk);end
        Us(i).status=['ERROR:' ME.identifier];
        Us(i).implementation_note=ME.message;
    end
end
F.planningWall_s=sum([Us.planning_s]);
verifyClk=tic;
F.numGeometryUAV=sum([Us.geometrySuccess]);
F.numTurnCertifiedUAV=sum([Us.turnCertified]);
F.geometryAllSuccess=all([Us.geometrySuccess]);
F.turnAllCertified=all([Us.turnCertified]);
if ~F.geometryAllSuccess
    F.status='FAILED_INDIVIDUAL_GEOMETRY';
    F.verificationWall_s=toc(verifyClk);
    F.endToEndWall_s=toc(clockAll);return;
end
F.totalPathLength_m=sum(len);
F.meanPathLength_m=mean(len);
F.stdPathLength_m=std(len,0);
F.fleetDetourRatio=sum(len)/sum([Us.directDistance_m]);
F.minObstacleClearanceSampled_m=min([Us.minClearanceSampled_m]);
F.minTurnRadius_m=min([Us.minTurnRadius_m]);
F.maxPathPitch_deg=max([Us.maxPitch_deg]);
if ~all([Us.curveBoundVerified]) || any(~isfinite(errors))
    F.status='UNVERIFIED_CURVE_TO_TIMED_PATH_BOUND';
    F.verificationWall_s=toc(verifyClk);
    F.endToEndWall_s=toc(clockAll);return;
end
% Incorporate a rigorous curve-vs-chord error margin into scheduling.
% For any pair, d_true >= d_polyline-eps_i-eps_j. One common *fleet*
% margin is deliberately applied to every pair and every method.
margin=0;
if o.enforceBezierSagittaMargin,margin=2*max(errors);end
sopt=struct('speed',o.cruiseSpeed_mps, ...
    'dSafe',o.requiredSeparation_m+margin, ...
    'tol',o.pairTolerance_m,'delayStep',o.delayStep_s, ...
    'maxDelay',o.maxDepartureDelay_s, ...
    'startPolicy',o.startPolicy,'endPolicy',o.endPolicy);
schedClk=tic;
try
    switch lower(char(o.scheduler))
        case 'conflict_aware'
            S=mmra_schedule_conflict_aware(Paths,sopt);
        case 'length_priority'
            S=mmra_schedule(Paths,sopt);
        otherwise
            error('MMRA_FLEET:Scheduler','Unknown shared scheduler %s',o.scheduler);
    end
catch ME
    F.schedulerWall_s=toc(schedClk);
    F.status=['SCHEDULER_ERROR:' ME.identifier];
    F.verificationWall_s=toc(verifyClk);
    F.endToEndWall_s=toc(clockAll);return;
end
F.schedulerWall_s=toc(schedClk);
delays=nan(N,1);
if isfield(S,'success') && S.success && ...
        numel(S.delays)==N && all(isfinite(S.delays))
    delays=S.delays(:);
end
try
    [Pairs,ps]=mmra_fleet11_pair_audit(Paths,delays,o,errors);
    F.preConflictPairs=ps.preConflictPairs;
    F.postConflictPairs=ps.postConflictPairs;
    F.numPairsChecked=ps.checkedPairs;
    F.minInterUAVPolyline_m=ps.minPolyline_m;
    F.minInterUAVCertifiedLB_m=ps.minCertifiedLB_m;
    F.minInterUAVMargin_m=ps.minMargin_m;
    F.violationDuration_s=ps.violationDuration_s;
    F.timedFleetSuccess=logical(S.success && ps.safe);
catch ME
    F.status=['PAIR_AUDIT_ERROR:' ME.identifier];
    F.verificationWall_s=toc(verifyClk);
    F.endToEndWall_s=toc(clockAll);return;
end
if F.timedFleetSuccess
    arr=delays+len/o.cruiseSpeed_mps;
    F.makespan_s=max(arr);
    F.meanArrival_s=mean(arr);
    F.totalDepartureWait_s=sum(delays);
    F.maxDepartureWait_s=max(delays);
    for i=1:N
        Us(i).departureWait_s=delays(i);
        Us(i).arrival_s=arr(i);
        [Q,Cum,~]=mmra_arc(Paths{i});
        times=delays(i)+Cum/o.cruiseSpeed_mps;
        if delays(i)>0
            times=[0;times];Q=[Q(1,:);Q];
        end
        Traj{i}=struct('times_s',times,'positions_m',Q, ...
            'departure_s',delays(i),'arrival_s',arr(i));
    end
    F.strictFleetSuccess=F.turnAllCertified;
    if isfinite(o.missionDeadline_s)
        F.deadlineSatisfied=double(F.makespan_s<=o.missionDeadline_s);
        F.strictFleetSuccess=F.strictFleetSuccess && ...
            logical(F.deadlineSatisfied);
    end
    if F.strictFleetSuccess
        F.status='PASS_FLEET_GEOMETRY_TIMING_TURN';
    elseif ~F.turnAllCertified
        F.status='PASS_FLEET_TIMED_BUT_TURN_UNCERTIFIED';
    else
        F.status='FLEET_DEADLINE_EXCEEDED';
    end
else
    F.status=['NO_VERIFIED_JOINT_SCHEDULE:' S.reason];
end
F.verificationWall_s=max(0,toc(verifyClk)-F.schedulerWall_s);
F.endToEndWall_s=toc(clockAll);
end
