function run_mmra_fleet11_selftest()
%RUN_MMRA_FLEET11_SELFTEST Tool-free deterministic mathematical unit tests.
% Run this before first authentic-map pilot. Does not require 11 planners.
o=mmra_fleet11_options('pilot');
o.cruiseSpeed_mps=1;o.requiredSeparation_m=2;
o.delayStep_s=1;o.maxDepartureDelay_s=10;
A=[-5 0 0;5 0 0];B=[0 -5 0;0 5 0];
[Pairs,summary]=mmra_fleet11_pair_audit({A,B},[0;0],o,[0;0]);
assert(summary.preConflictPairs==1 && summary.postConflictPairs==1);
assert(~summary.safe && summary.minCertifiedLB_m<1e-10);
assert(abs(summary.violationDuration_s-2*sqrt(2))<1e-8, ...
    'Moving-line crossing violation duration is incorrect');
[Pairs,summary]=mmra_fleet11_pair_audit({A,B},[0;3],o,[0;0]);
assert(summary.preConflictPairs==1 && summary.postConflictPairs==0);
assert(summary.safe && summary.checkedPairs==1);
assert(summary.minCertifiedLB_m>2);
[~,margin]=mmra_fleet11_pair_audit({A,B},[0;3],o,[0.1;0.1]);
assert(~margin.safe,'The Bezier margin must fail closed at near encounters');
% Five UAVs, ten pairwise relations and a feasible all-zero schedule.
Ps=cell(5,1);
for i=1:5
    Ps{i}=[0 20*i 5; 10 20*i 5];
end
os=struct('speed',o.cruiseSpeed_mps,'dSafe',o.requiredSeparation_m, ...
    'tol',o.pairTolerance_m,'delayStep',o.delayStep_s, ...
    'maxDelay',o.maxDepartureDelay_s, ...
    'startPolicy',o.startPolicy,'endPolicy',o.endPolicy);
S=mmra_schedule(Ps,os);
assert(S.success && all(S.delays==0),'Separated fleet must be schedulable');
[Pr,r]=mmra_fleet11_pair_audit(Ps,S.delays,o,zeros(5,1));
assert(numel(Pr)==10 && r.checkedPairs==10 && r.safe);
% Certified analytic chord-error bound: S(0,0),C(1,1),E(2,0).
t=linspace(0,1,11)';
P=[2*t,2*t.*(1-t),zeros(size(t))];
info=struct('curveControls',[0 0 0 1 1 0 2 0 0]);
[epsm,verified,reason]=mmra_fleet11_curve_bound(P,info);
assert(verified && abs(epsm-0.005)<1e-12,reason);
% Detect altered spline sample -- must not silently trust metadata.
P(5,2)=P(5,2)+.03;
[~,verified]=mmra_fleet11_curve_bound(P,info);
assert(~verified,'Curve metadata reconstruction mismatch must fail closed');
% Aggregation: 5 UAV reports must count as ONE fleet trial.
F=struct('algorithm','MMRA','fleetSeedIndex',1, ...
    'strictFleetSuccess',true,'geometryAllSuccess',true, ...
    'timedFleetSuccess',true,'numTurnCertifiedUAV',5, ...
    'totalPathLength_m',50,'fleetDetourRatio',1.1, ...
    'makespan_s',20,'totalDepartureWait_s',0,'preConflictPairs',0, ...
    'minInterUAVMargin_m',15,'planningWall_s',1, ...
    'schedulerWall_s',.1,'endToEndWall_s',1.3);
T=mmra_fleet11_summary(struct2table(F));
assert(T.nFleetTrials==1 && T.strictRate_pct==100 && ...
    T.nStrictFleet==1 && T.nValidLengths==1);

% Regression: algorithm may be a single char row, string, cellstr, or
% multiple algorithms; summary and paired comparison must not use {} on char.
Fs=struct2table(F);
Fs.algorithm=string('MMRA');
Ts=mmra_fleet11_summary(Fs);
assert(height(Ts)==1 && Ts.nFleetTrials==1 && Ts.strictRate_pct==100);
Fc=struct2table(F);
Fc.algorithm={'MMRA'};
Tc=mmra_fleet11_summary(Fc);
assert(height(Tc)==1 && Tc.strictRate_pct==100);
F2=F;
F2.algorithm='ASTAR';
F2.totalPathLength_m=60;
F2.makespan_s=22;
F2.strictFleetSuccess=false;
Fm=struct2table([F;F2]);
Tm=mmra_fleet11_summary(Fm);
labels=cellstr(string(Tm.algorithm));
assert(height(Tm)==2 && isequal(labels,{'MMRA';'ASTAR'}) && ...
    all(Tm.nFleetTrials==1) && Tm.strictRate_pct(2)==0);
% Some callers store algorithm names as padded char matrices.
Fm.algorithm=char('MMRA','ASTAR');
Tchar=mmra_fleet11_summary(Fm);
assert(height(Tchar)==2 && all(Tchar.nFleetTrials==1));
Fm.algorithm={'MMRA';'ASTAR'};
Tp=mmra_fleet11_paired(Fm);
assert(height(Tp)==1 && Tp.nCommonFleetSeeds==1 && ...
    Tp.nGeomLengthPairs==1 && Tp.nMakespanPairs==1 && ...
    abs(Tp.meanLengthMMRA_minusBaseline_m+10)<1e-12 && ...
    abs(Tp.meanMakespanMMRA_minusBaseline_s+2)<1e-12);

fprintf('FLEET11 SELFTEST PASSED (crossing, timing, margins, 10 pairs, metadata, stats, mixed text types).\n');
end
