function trajectories = my_mmra_adapter(testcase)
%MY_MMRA_ADAPTER Real uploaded RRT* + MMRA + V3.2/V3.3 temporal coordination.
% The benchmark scene contains no static buildings; hence spatial planning
% typically returns a straight path. No NEW proxy geometry is inserted.
trajectories = benchmark_mmra_urban_core(testcase,'temporal');
end
