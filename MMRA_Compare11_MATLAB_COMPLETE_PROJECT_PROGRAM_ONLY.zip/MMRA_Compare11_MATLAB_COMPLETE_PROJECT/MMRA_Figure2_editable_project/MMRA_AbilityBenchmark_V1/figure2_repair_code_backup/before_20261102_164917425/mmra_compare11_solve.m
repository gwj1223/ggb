function [P,info] = mmra_compare11_solve(algorithm,c,seed,opts)
%MMRA_COMPARE11_SOLVE Eleven distinct MATLAB planning code paths.
% This is a preliminary reproducible ENGINEERING comparison, not a
% paper-validated reimplementation of all published algorithm variants.
P=[];
algorithm=upper(char(algorithm));
info=struct('note','','algorithm',algorithm,'allCornersSmoothed',false, ...
    'curveControls',zeros(0,9),'curveMetadataAvailable',false, ...
    'minRadiusRequirement_m',10,'maxPitchRequirement_deg',75, ...
    'roundedCornersReported',nan, ...
    'failedCornerIndices',zeros(0,1), ...
    'failedCornerReasons',{{}}, ...
    'localRepairApplied',false,'localRepairMoves',0);
rng(seed,'twister');
sc=c.scene;
switch algorithm
    case 'MMRA'
        switch sc.kind
            case 'figure2'
                cfg=c.nativeCfg;
                cfg.prune=true;cfg.smooth=true;
                cfg.maxIter=opts.rrtIterations;
                cfg.smoothMode='adaptive_safe';
                cfg.smoothMinRadius_m=10;
                cfg.smoothMaxPitch_deg=75;
                cfg.smoothTrimFraction=.44;
                cfg.smoothTerminalTrimFraction=.96;
                cfg.smoothMaxChord_m=2.5;
                cfg.smoothMaxSagitta_m=.10;
                cfg.smoothMaxSamples=1000;
                [P,st]=mmra_plan_single(c.start,c.goal,sc.env,cfg,true);
                info.note='native_Figure2_MMRA_APF_RRT_and_Bezier';
                if isfield(st,'smoothingStats') && ...
                        isfield(st.smoothingStats,'fullySmoothed')
                    info.allCornersSmoothed=logical(st.smoothingStats.fullySmoothed);
                    if isfield(st.smoothingStats,'failedCornerIndices')
                        info.failedCornerIndices=st.smoothingStats.failedCornerIndices;
                        info.failedCornerReasons=st.smoothingStats.failedCornerReasons;
                    end
                    if isfield(st.smoothingStats,'roundedCorners')
                        info.roundedCornersReported=st.smoothingStats.roundedCorners;
                    end
                    if isfield(st.smoothingStats,'curveControls')
                        info.curveControls=st.smoothingStats.curveControls;
                        info.curveMetadataAvailable=true;
                    end
                end
            case 'urban500'
                cfg=urbanCfg(sc,opts);
                [raw,~]=urban500_rrtstar_plan( ...
                    c.start,c.goal,sc.boxes,cfg,seed);
                if ~isempty(raw)
                    [P,~,post]=urban500_mmra_postprocess(raw,sc.boxes,cfg);
                    info.allCornersSmoothed=logical(post.allEligibleCornersSmoothed);
                    info.curveControls=post.curveControls;
                    info.curveMetadataAvailable=true;
                    info.roundedCornersReported=post.roundedCorners;
                    info.failedCornerIndices=post.failedCornerIndices;
                    info.failedCornerReasons=post.failedCornerReasons;
                end
                info.note='native_Urban500_RRTstar_plus_shared_MMRA';
                if ~isempty(raw) && isfield(post,'localRepair') && ...
                        post.localRepair.succeeded
                    info.note='native_Urban500_RRTstar_MMRA_verified_local_waypoint_repair';
                    info.localRepairApplied=true;
                    info.localRepairMoves=numel(post.localRepair.cornersRelocated);
                end
            case 'traffic_only'
                [tr,meta]=mendeley_public_plan(c.dataset,'geometry');
                P=tr(:,2:4);
                info.note='native_Urban500_MMRA_geometry_only_common_timing';
                info.allCornersSmoothed=logical(meta.allCornersSmoothed);
                if isfield(meta,'curveControls')
                    info.curveControls=meta.curveControls;
                    info.curveMetadataAvailable=true;
                    if isfield(meta,'roundedCornersReported')
                        info.roundedCornersReported=meta.roundedCornersReported;
                    end
                end
        end
    case 'RRTSTAR'
        switch sc.kind
            case 'figure2'
                cfg=c.nativeCfg;
                cfg.prune=false;cfg.smooth=false;
                cfg.maxIter=opts.rrtIterations;
                [P,~]=mmra_plan_single(c.start,c.goal,sc.env,cfg,false);
                info.note='native_Figure2_RRTstar_without_APF_and_smoothing';
            case 'urban500'
                cfg=urbanCfg(sc,opts);
                [P,~]=urban500_rrtstar_plan( ...
                    c.start,c.goal,sc.boxes,cfg,seed);
                info.note='native_Urban500_RRTstar';
            case 'traffic_only'
                P=mmra_compare11_search('rrtstar',c,opts);
                info.note='generic_RRTstar_free_space';
        end
    case 'ASTAR'
        P=mmra_compare11_search('astar',c,opts);
        info.note='3D_26_neighbor_voxel_Astar';
    case 'APF'
        P=mmra_compare11_search('apf',c,opts);
        info.note='3D_attractive_repulsive_APF_with_bounded_escape';
    case 'RRTCONNECT'
        P=mmra_compare11_search('rrtconnect',c,opts);
        info.note='bidirectional_extend_connect';
    case 'INFORMEDRRTSTAR'
        P=mmra_compare11_search('informedrrtstar',c,opts);
        info.note='informed_ellipsoid_sampling_with_parent_rewiring';
    case {'GA','PSO','ACO','DE','GWO'}
        [P,detail]=mmra_compare11_evolution(algorithm,c,opts);
        info.note=detail;
    otherwise
        error('MMRA_COMPARE:UnknownAlgorithm','Unknown %s',algorithm);
end
end

function cfg=urbanCfg(sc,opts)
% Use the actual Urban500 geometry and a fixed shared search configuration.
cfg=struct();
cfg.bounds_m=sc.bounds;
cfg.maxIterations=opts.rrtIterations;
cfg.maxIterationsAfterFirstSolution=min(400, ...
    max(80,round(opts.rrtIterations/4)));
cfg.maxStep_m=24;
cfg.goalConnectRadius_m=36;
cfg.goalBias=.12;
cfg.highAltitudeBias=.30;
roofs=max(sc.boxes(:,6));
cfg.highAltitudeRange_m=[min(sc.bounds(3,2)-8,roofs+7),sc.bounds(3,2)-6];
cfg.neighborGamma_m=170;
cfg.neighborRadiusMin_m=22;
cfg.neighborRadiusMax_m=55;
cfg.mmraPruneMode='shortest_visibility';
cfg.smoothMinRadius_m=10;
cfg.smoothMaxPitch_deg=75;
cfg.smoothTrimFraction=.44;
cfg.smoothTerminalTrimFraction=.96;
cfg.mmraTerminalRepair=true;
cfg.mmraTerminalRepairMaxCandidates=30;
cfg.mmraTerminalRepairMaxExtra_m=35;
cfg.smoothMaxChord_m=2.5;
cfg.smoothMaxSagitta_m=.1;
cfg.smoothMinAngle_deg=2;
cfg.smoothMaxSamples=1000;
end
