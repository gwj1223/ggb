function [path,st] = mmra_plan_single(startPos,goalPos,env,cfg,guided)
%MMRA_PLAN_SINGLE Spatial search + separately-timed post-processing.
if nargin<5, guided=true; end
% Opt-in phase-1 study. Do not alter the frozen mmra_rrtstar.m baseline:
% cfg without rrtStopMode uses the exact original first-feasible search.
rrtStopMode='first_feasible';
if isfield(cfg,'rrtStopMode') && ~isempty(cfg.rrtStopMode)
    rrtStopMode=lower(char(cfg.rrtStopMode));
end
assert(any(strcmp(rrtStopMode,{'first_feasible','anytime','terrain_adaptive'})), ...
    'cfg.rrtStopMode must be first_feasible, anytime or terrain_adaptive');
% v1.7: robust dual-planner selection; its two-planner audit is separate
% from this anytime experiment and is not silently combined with it.
if guided && isfield(cfg,'apfMode') && strcmpi(cfg.apfMode,'guarded_sc')
    assert(strcmp(rrtStopMode,'first_feasible'), ...
        'Advanced RRT* modes are not supported with guarded_sc APF');
    [path,st]=mmra_guarded_plan_single(startPos,goalPos,env,cfg);
    return;
end
if strcmp(rrtStopMode,'anytime')
    [raw,core]=mmra_rrtstar_anytime(startPos,goalPos,env,cfg,guided);
elseif strcmp(rrtStopMode,'terrain_adaptive')
    [raw,core]=mmra_rrtstar_terrain_adaptive( ...
        startPos,goalPos,env,cfg,guided);
else
    [raw,core]=mmra_rrtstar(startPos,goalPos,env,cfg,guided);
end
st=core;
st.search_s=core.elapsed_s;
st.post_s=0;
st.total_s=core.elapsed_s;
st.rawLength=core.pathLength;
st.smoothAccepted=false;
% Raw RRT* tree objective fields remain in st.pathObjective_m.
st.finalRiskIntegral_m=NaN;
st.finalAscent_m=NaN;
st.finalObjective_m=NaN;
path=[];
if ~core.success, return; end
postStart=tic; path=raw;
if cfg.prune, path=mmra_prune(path,env,cfg); end
if cfg.smooth
    % Explicit opt-in: expose detailed arc acceptance / radius telemetry
    % for the upgraded module. Legacy experiments retain their old fields
    % and exactly the same historical smoothing behavior by default.
    if isfield(cfg,'smoothMode') && ...
            strcmpi(char(cfg.smoothMode),'adaptive_safe')
        [path,st.smoothAccepted,st.smoothingStats]= ...
            mmra_bezier(path,env,cfg);
    else
        [path,st.smoothAccepted]=mmra_bezier(path,env,cfg);
    end
end
st.post_s=toc(postStart);
st.total_s=st.search_s+st.post_s;
if ~mmra_path_free(path,env,cfg.edgeResolution)
    st.success=false; st.reason='postprocessing_failed_collision_check';
    path=[]; st.pathLength=NaN; return;
end
st.pathLength=mmra_path_length(path);
st.finalAscent_m=mmra_path_ascent(path);
% Postprocessing may change route length/risk/ascent. Never label the raw RRT*
% objective as the final postprocessed route objective.
if isfield(cfg,'riskCostBand_m') && isfield(cfg,'riskCostResolution_m')
    st.finalRiskIntegral_m=mmra_path_risk(path,env, ...
        cfg.riskCostBand_m,cfg.riskCostResolution_m);
    [rw,aw]=mmra_cost_weights(cfg);
    st.finalObjective_m=st.pathLength+rw*st.finalRiskIntegral_m+ ...
        aw*st.finalAscent_m;
end
end
