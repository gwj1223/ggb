function T=run_mmra_turnradius_audit(suite,maxCases,nSeeds)
%RUN_MMRA_TURNRADIUS_AUDIT Re-run ONLY MMRA for independent 10m audit.
%   run_mmra_turnradius_selftest
%   run_mmra_turnradius_audit('urban500',5,5)
%   run_mmra_turnradius_audit('figure2',5,5)
% No 11-algorithm rerun is required. The original comparison CSV/MAT files
% are NEVER overwritten. This routine saves the analytic Bezier controls
% alongside each new route so future audits need no re-planning.
if nargin<1 || isempty(suite),suite='urban500';end
suite=lower(char(suite));
assert(any(strcmp(suite,{'urban500','figure2'})), ...
    'Only the two actual static-map suites are supported.');
C=mmra_compare11_cases(suite);
if nargin<2 || isempty(maxCases),maxCases=numel(C);end
if nargin<3 || isempty(nSeeds),nSeeds=5;end
maxCases=max(1,min(numel(C),floor(maxCases)));
nSeeds=max(1,floor(nSeeds));
opts=mmra_compare11_options('full');
outDir=fullfile(fileparts(mfilename('fullpath')), ...
    'benchmark_results','Comparison11');
if ~isfolder(outDir),mkdir(outDir);end
key=[upper(suite) '_FULL'];
priorCsv=fullfile(outDir,[key '_trials.csv']);
priorMat=fullfile(outDir,[key '_trajectories.mat']);
priorT=table();priorPaths={};
if isfile(priorCsv) && isfile(priorMat)
    priorT=readtable(priorCsv);
    old=load(priorMat,'paths');
    if isfield(old,'paths'),priorPaths=old.paths;end
end
record=struct('suite',suite,'case_id','','seed',0, ...
    'geometrySuccess',false,'turnCertified',false, ...
    'strictSuccess',false,'status','', ...
    'turnStatus','','allCornersSmoothed',false, ...
    'length_m',nan,'requiredTurnRadius_m',10, ...
    'minCurveRadius_m',nan,'minPathTurnRadius_m',nan, ...
    'maxJunctionAngle_deg',nan,'maxPathPitch_deg',nan, ...
    'numSharpJunctions',nan,'numVerifiedCurves',0, ...
    'failedCornerCount',0,'failedCornerIndices','', ...
    'failedCornerReasons','', ...
    'oldPathMaxDeviation_m',nan,'oldPathMatched',nan);
K=maxCases*nSeeds;R=repmat(record,K,1);
paths=cell(K,1);certificates=cell(K,1);
row=0;
fprintf('\nMMRA 10m continuous turn audit: %s, %d cases x %d seeds\n', ...
    suite,maxCases,nSeeds);
for j=1:maxCases
    for rep=1:nSeeds
        row=row+1;
        seed=24001+1009*j+211*rep;
        R(row)=record;R(row).case_id=C(j).id;R(row).seed=seed;
        try
            [P,info]=mmra_compare11_solve('MMRA',C(j),seed,opts);
            val=mmra_compare11_validate(C(j),P,info);
            R(row).geometrySuccess=val.geometrySuccess;
            R(row).turnCertified=val.turnCertified;
            R(row).strictSuccess=val.strictSuccess;
            R(row).status=val.status;
            R(row).turnStatus=val.turnStatus;
            R(row).allCornersSmoothed=info.allCornersSmoothed;
            R(row).length_m=val.length_m;
            R(row).requiredTurnRadius_m=val.requiredTurnRadius_m;
            R(row).minCurveRadius_m=val.minCurveRadius_m;
            R(row).minPathTurnRadius_m=val.minPathTurnRadius_m;
            R(row).maxJunctionAngle_deg=val.maxJunctionAngle_deg;
            R(row).maxPathPitch_deg=val.maxPathPitch_deg;
            R(row).numSharpJunctions=val.numSharpJunctions;
            R(row).numVerifiedCurves=val.numVerifiedCurves;
            if isfield(info,'failedCornerIndices')
                v=info.failedCornerIndices(:)';
                R(row).failedCornerCount=numel(v);
                R(row).failedCornerIndices=strtrim(sprintf('%d ',v));
                if isfield(info,'failedCornerReasons') && ...
                        ~isempty(info.failedCornerReasons)
                    R(row).failedCornerReasons=...
                        strjoin(info.failedCornerReasons(:)',';');
                end
            end
            paths{row}=P;
            certificates{row}=info; % Exact original quadratic controls.
            if ~isempty(priorPaths) && ~isempty(priorT)
                idx=find(strcmp(string(priorT.case_id),C(j).id) & ...
                    strcmp(string(priorT.algorithm),'MMRA') & ...
                    priorT.seed==seed,1,'first');
                if ~isempty(idx) && idx<=numel(priorPaths)
                    oldP=priorPaths{idx};
                    if isequal(size(P),size(oldP)) && ~isempty(P)
                        deviation=max(sqrt(sum((P-oldP).^2,2)));
                    else
                        deviation=inf;
                    end
                    R(row).oldPathMaxDeviation_m=deviation;
                    R(row).oldPathMatched=double(deviation<=1e-5);
                end
            end
        catch ME
            R(row).status=['ERROR:' ME.identifier];
            R(row).turnStatus=ME.message;
        end
        fprintf('%s seed=%d | geometry=%d | turn=%d | radius=%.3f m | %s\n', ...
            C(j).id,seed,R(row).geometrySuccess,R(row).turnCertified, ...
            R(row).minPathTurnRadius_m,R(row).turnStatus);
    end
    T=struct2table(R(1:row));
    writetable(T,fullfile(outDir,['MMRA_TURN_AUDIT_' key '.csv']));
    save(fullfile(outDir,['MMRA_TURN_AUDIT_' key '.mat']), ...
        'paths','certificates','row','suite','opts','-v7');
end
fprintf('MMRA curvature audit: geometry %d/%d, certified %d/%d.\n', ...
    sum(T.geometrySuccess),height(T),sum(T.strictSuccess),height(T));
if any(~isnan(T.oldPathMatched))
    known=~isnan(T.oldPathMatched);
    fprintf('Compared to prior saved routes: %d/%d reproduced exactly.\n', ...
        sum(T.oldPathMatched(known)),sum(known));
    if any(T.oldPathMatched(known)==0)
        warning(['Some routes differ from the prior benchmark! Do not ' ...
                 'retroactively attribute the audit to old trials.']);
    end
end
fprintf('New audit files saved in %s (old results retained).\n',outDir);
end
