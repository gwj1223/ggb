function r=mmra_compare11_validate(c,P,info)
%MMRA_COMPARE11_VALIDATE Geometry, analytic curvature, and optional timing.
% The legacy "success" column is collision/timing success. StrictSuccess
% additionally requires a continuously interpretable G1 path with 3-D
% minimum osculating radius >=10m and tangent pitch <=75 deg. This is NOT
% acceleration/jerk/thrust or physical flight-dynamics certification.
if nargin<3 || isempty(info),info=struct();end
r=struct('success',false,'status','NO_PATH','length_m',nan, ...
    'minClearance_m',nan,'maxTurn_deg',nan,'pathPoints',0, ...
    'startHold_s',nan,'minTrafficSep_m',nan,'trajectory',[], ...
    'geometrySuccess',false,'turnCertified',false, ...
    'strictSuccess',false,'turnStatus','NOT_CHECKED', ...
    'requiredTurnRadius_m',10,'minCurveRadius_m',nan, ...
    'minPathTurnRadius_m',nan,'maxJunctionAngle_deg',nan, ...
    'maxPathPitch_deg',nan,'numSharpJunctions',nan, ...
    'numVerifiedCurves',0);
if ~isnumeric(P) || isempty(P) || size(P,2)~=3 || ...
        size(P,1)<2 || any(~isfinite(P(:)))
    return;
end
P=double(P);
r.pathPoints=size(P,1);
if norm(P(1,:)-c.start)>1e-5 || norm(P(end,:)-c.goal)>1e-5
    r.status='WRONG_ENDPOINTS';return;
end
if ~all(mmra_compare11_oracle(c.scene,'points',P))
    r.status='INVALID_WAYPOINT';return;
end
r.length_m=sum(sqrt(sum(diff(P,1,1).^2,2)));
D=diff(P,1,1);
validD=sqrt(sum(D.^2,2))>1e-8;
if ~all(validD)
    r.status='DUPLICATED_POINTS';return;
end
r.maxTurn_deg=0;
for k=1:size(D,1)-1
    a=D(k,:);b=D(k+1,:);
    co=dot(a,b)/(norm(a)*norm(b));
    r.maxTurn_deg=max(r.maxTurn_deg,acosd(max(-1,min(1,co))));
end
% Independent full segment checks, including no-fly cylinders/terrain.
for j=1:size(P,1)-1
    if ~mmra_compare11_oracle(c.scene,'edge',P(j,:),P(j+1,:))
        r.status='STATIC_COLLISION';return;
    end
end
% Minimum clearance uses sampled points; collisions are checked separately
% with the map's authoritative segment checker.
step=max(2,c.scene.edgeStep);
clearMin=inf;
for j=1:size(P,1)-1
    n=max(2,ceil(norm(P(j+1,:)-P(j,:))/step)+1);
    t=linspace(0,1,n)';
    q=repmat(P(j,:),n,1)+t*(P(j+1,:)-P(j,:));
    clearMin=min(clearMin,min(mmra_compare11_oracle( ...
        c.scene,'clearance',q)));
end
r.minClearance_m=clearMin;
r.geometrySuccess=true;
controls=zeros(0,9);
if isfield(info,'curveControls'),controls=info.curveControls;end
radiusRequirement=10;pitchRequirement=75;
if isfield(info,'minRadiusRequirement_m')
    radiusRequirement=info.minRadiusRequirement_m;
end
if isfield(info,'maxPitchRequirement_deg')
    pitchRequirement=info.maxPitchRequirement_deg;
end
turn=mmra_compare11_turnradius_validate( ...
    P,controls,radiusRequirement,pitchRequirement);
r.requiredTurnRadius_m=radiusRequirement;
r.minCurveRadius_m=turn.minCurveRadius_m;
r.minPathTurnRadius_m=turn.minPathTurnRadius_m;
r.maxJunctionAngle_deg=turn.maxJunctionAngle_deg;
r.maxPathPitch_deg=turn.maxPathPitch_deg;
r.numSharpJunctions=turn.numSharpJunctions;
r.numVerifiedCurves=turn.numVerifiedCurves;
r.turnCertified=turn.certified;
r.turnStatus=turn.status;
% Fail closed if the MMRA smoother did not provide its analytic geometry,
% or itself declared that any eligible corner was left sharp.
if isfield(info,'algorithm') && strcmpi(info.algorithm,'MMRA')
    if ~isfield(info,'curveMetadataAvailable') || ...
            ~info.curveMetadataAvailable
        r.turnCertified=false;
        r.turnStatus='MISSING_MMRA_CURVE_METADATA';
    elseif ~isfield(info,'roundedCornersReported') || ...
            ~isfinite(info.roundedCornersReported) || ...
            info.roundedCornersReported~=size(controls,1)
        r.turnCertified=false;
        r.turnStatus='MMRA_CURVE_COUNT_MISMATCH';
    elseif ~isfield(info,'allCornersSmoothed') || ...
            ~info.allCornersSmoothed
        r.turnCertified=false;
        r.turnStatus='UNSMOOTHED_MMRA_CORNER';
        r.minPathTurnRadius_m=0;
    end
end
if ~strcmp(c.scene.kind,'traffic_only')
    r.success=true;
    r.strictSuccess=r.turnCertified;
    if r.turnCertified
        r.status='PASS_GEOMETRIC_TURN_CERTIFIED';
    else
        r.status='PASS_GEOMETRIC_TURN_UNCERTIFIED';
    end
    return;
end
% Every method gets the SAME departure/speed choices and the SAME public
% fixed-traffic evaluator. No algorithm can modify the nine source tracks.
d=c.dataset;
speeds=unique(min(d.max_speed_mps,[120,105,90,75,60,45]),'stable');
delays=0:1:d.max_start_hold_s;
choices=zeros(numel(speeds)*numel(delays),3);N=0;
for i=1:numel(speeds)
    v=speeds(i);
    if v<=0,continue;end
    for hold=delays
        finish=hold+r.length_m/v;
        if finish>d.horizon_s+1e-7,continue;end
        N=N+1;choices(N,:)=[finish,hold,v];
    end
end
if N==0,r.status='ARRIVAL_AFTER_HORIZON';return;end
choices=sortrows(choices(1:N,:),[1 2]);
for j=1:size(choices,1)
    hold=choices(j,2);v=choices(j,3);
    dt=sqrt(sum(diff(P,1,1).^2,2))/v;
    times=hold+[0;cumsum(dt)];
    xyz=P;
    if hold>1e-9
        xyz=[P(1,:);P];times=[0;times];
    end
    tr=[times,xyz];
    e=mendeley_public_evaluate(d,tr);
    if e.success
        r.success=true;r.strictSuccess=r.turnCertified;
        if r.turnCertified
            r.status='PASS_TRAFFIC_TIMING_TURN_CERTIFIED';
        else
            r.status='PASS_TRAFFIC_TIMING_TURN_UNCERTIFIED';
        end
        r.startHold_s=hold;r.minTrafficSep_m=e.minSeparation_m;
        r.trajectory=tr;return;
    end
end
r.status='NO_VERIFIED_TIMING';
end
