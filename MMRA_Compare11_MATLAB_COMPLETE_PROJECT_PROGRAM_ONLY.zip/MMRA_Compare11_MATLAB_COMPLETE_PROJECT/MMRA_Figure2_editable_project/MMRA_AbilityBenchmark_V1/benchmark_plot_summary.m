function benchmark_plot_summary(T, label, outdir)
%BENCHMARK_PLOT_SUMMARY Performance-vs-load curves, no arbitrary scene images.
kinds={'dynamic','interuav','combined'};
fig=figure('Visible','off','Color','w','Position',[200 100 1050 420]);
for i=1:3
    subplot(1,3,i);
    fraction=nan(1,5);
    for level=1:5
        mask=strcmp(T.kind,kinds{i}) & T.level==level & T.stress;
        if any(mask)
            fraction(level)=100*mean(T.success(mask));
        end
    end
    plot(1:5,fraction,'-o','LineWidth',1.8,'MarkerSize',6);
    xlim([.8 5.2]);ylim([0 105]); grid on;
    set(gca,'XTick',1:5);
    xlabel('Load level');ylabel('Stress success rate (%)');
    title(strrep(kinds{i},'_',' '));
end
try
    exportgraphics(fig,fullfile(outdir,[label '_success_vs_load.png']),'Resolution',160);
catch
    saveas(fig,fullfile(outdir,[label '_success_vs_load.png']));
end
close(fig);
end
