function run_mmra_integrated_ability_tests(maxCases,policy)
%RUN_MMRA_INTEGRATED_ABILITY_TESTS Distinct algorithm modes, same cases.
% Run 30 cases first; increase to 450 only after MATLAB smoke tests pass.
if nargin<1 || isempty(maxCases),maxCases=30;end
if nargin<2 || isempty(policy),policy='active';end
run_mmra_benchmark_selftest;
run_mmra_adapter_smoke_test;
run_mmra_ability_benchmark( ...
    @benchmark_mmra_geometry_adapter,maxCases,'RRTMMRA_GEOM',policy);
run_mmra_ability_benchmark( ...
    @my_mmra_adapter,maxCases,'URBAN500_TEMPORAL',policy);
run_mmra_ability_benchmark( ...
    @benchmark_urban500_proxy_hybrid_adapter,maxCases, ...
    'URBAN500_PROXY_EXPERIMENT',policy);
end
