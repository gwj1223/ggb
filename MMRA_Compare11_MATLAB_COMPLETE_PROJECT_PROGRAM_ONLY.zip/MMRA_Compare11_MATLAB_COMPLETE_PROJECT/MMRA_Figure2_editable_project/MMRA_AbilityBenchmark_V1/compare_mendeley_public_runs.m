function compare_mendeley_public_runs(suite)
%COMPARE_MENDELEY_PUBLIC_RUNS Compare matching CSV-derived replay tasks.
% Run straight + temporal + proxy first, optionally on 'incident2'.
if nargin<1,suite='full';end
suite=lower(char(suite));
base=fileparts(mfilename('fullpath'));
folder=fullfile(base,'benchmark_results','Mendeley_Public3D');
if strcmp(suite,'full'),prefix='MENDELEY3D_';
elseif strcmp(suite,'incident2'),prefix='MENDELEY3D_INCIDENT2_';
else,error('Unknown suite');end
modes={'STRAIGHT','TEMPORAL','PROXY'};
R=cell(3,1);
for i=1:3
    path=fullfile(folder,[prefix modes{i} '_trials.csv']);
    assert(exist(path,'file')==2, ...
        'Missing %s: please run %s on same suite first.',path,modes{i});
    R{i}=readtable(path);
end
assert(isequal(R{1}.case_id,R{2}.case_id) && ...
       isequal(R{2}.case_id,R{3}.case_id), ...
       'Cannot compare mismatched tasks/order. Use equal maxCases.');
ref=logical(R{1}.reference_conflict_10m);
for i=1:3
    M=R{i};
    fprintf('%-8s %2d/%2d total | ref-conflict %d/%d | no ref-conflict %d/%d | spatial changes (>1m) %d\n', ...
        modes{i},sum(M.success),height(M),sum(M.success & ref),sum(ref), ...
        sum(M.success & ~ref),sum(~ref), ...
        sum(M.success & M.max_spatial_deviation_m>1));
end
fprintf('This is 1-ego vs 9 fixed public tracks; no agent-agent joint coordination.\n');
end
