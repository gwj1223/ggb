function comparison = compare_benchmark_runs(baselineCSV, candidateCSV)
%COMPARE_BENCHMARK_RUNS Paired comparison on identical benchmark case IDs.
% Example:
%   compare_benchmark_runs('benchmark_results/RRTSTAR_trials.csv', ...
%                          'benchmark_results/MMRA_trials.csv');
A=readtable(baselineCSV);
B=readtable(candidateCSV);
assert(numel(unique(A.case_id))==height(A),'Duplicate case in baseline');
assert(numel(unique(B.case_id))==height(B),'Duplicate case in candidate');
[found,indices]=ismember(A.case_id,B.case_id);
A=A(found,:);
B=B(indices(found),:);
if height(A)==0,error('No matching benchmark case IDs');end
comparison=table();
comparison.kind=cell(3,1);
comparison.stressSuccessA=zeros(3,1);
comparison.stressSuccessB=zeros(3,1);
comparison.successDelta_pp=zeros(3,1);
comparison.planningTimeMeanA_s=zeros(3,1);
comparison.planningTimeMeanB_s=zeros(3,1);
kindNames={'dynamic','interuav','combined'};
for i=1:3
    mask=strcmp(A.kind,kindNames{i}) & A.stress;
    comparison.kind{i}=kindNames{i};
    if ~any(mask)
        comparison.stressSuccessA(i)=nan;comparison.stressSuccessB(i)=nan;
        comparison.successDelta_pp(i)=nan;
        comparison.planningTimeMeanA_s(i)=nan;
        comparison.planningTimeMeanB_s(i)=nan;
        continue;
    end
    sA=A.success(mask);sB=B.success(mask);
    comparison.stressSuccessA(i)=100*mean(sA);
    comparison.stressSuccessB(i)=100*mean(sB);
    comparison.successDelta_pp(i)=100*(mean(sB)-mean(sA));
    comparison.planningTimeMeanA_s(i)=mean(A.planning_s(mask));
    comparison.planningTimeMeanB_s(i)=mean(B.planning_s(mask));
end
disp(comparison);
end
