# MMRA 3D Ability Benchmark v1.0 — MATLAB 算法能力批测

## 这是怎样的数据包？

这是 **程序生成的三维时空能力测试集**，并非 SPATIO，也不是已发表的权威公共基准，更不是已经测试过你的 MMRA 算法的结果。没有特定城市地图或固定建筑，而是在标准化坐标范围内生成**一组组可复现的动态障碍物与多无人机避碰任务**。这里的“测试案例”指抽象规划输入，不是专门设计的某张图。

- 一共 **450** 个固定输入案例，随机种子 `20261102`，使用 `generate_dataset.py` 可再生。
- 3 类任务 × 5 个负载等级 × 30 次复测 = 450。
- 每类每级包含 20 个“直飞将发生冲突”的压力测试、10 个“直飞本来安全”的对照：**300 压力 + 150 对照**。
- `dynamic`：1 机与 2/5/10/20/30 个移动球体。
- `interuav`：2/3/5/8/10 机之间的时间相关避碰，不额外放动态球体。
- `combined`：2/3/5/8/10 机 + 2/5/10/20/30 个移动球体。
- 所有输入在 `MMRA_AbilityBenchmark_450cases.mat`，案例清单在 `benchmark_manifest.csv`。

注意：这里的 5 级表示 **测试负载规模**，没有声称等级越高一定几何求解越难。生成器特意放入直线路径冲突，避免“大量随机却几乎全是无须避障的简单题”。对照组用于识别算法过度绕行和无谓调度。

## 运行（MATLAB）

解压 ZIP，在 MATLAB 中进入压缩包解压出的 `MMRA_AbilityBenchmark_V1` 目录：

```matlab
% 1. 检查测试数据与连续时间碰撞检测
run_mmra_benchmark_selftest;

% 2. 检查评测程序能否工作：直接飞行基线，不代表 MMRA！
run_mmra_ability_benchmark(@benchmark_straightline_baseline, 30, 'STRAIGHT', 'active');

% 3. 把自己的规划器接入 my_mmra_adapter.m 后，才正式跑：
% run_mmra_ability_benchmark(@my_mmra_adapter, 450, 'MMRA', 'active');
% run_mmra_ability_benchmark(@my_mmra_adapter, 450, 'MMRA', 'schedule');
```

其中 `my_mmra_adapter_TEMPLATE.m` 是**接口模板**，故意抛出 `Adapter not connected`。因为没有你的 Urban500/MMRA 源码，我们不能伪称它已接好。你需要将其复制为 `my_mmra_adapter.m` 并接入实际函数。空模板绝不会输出虚假的成功率。

### 你的算法接收什么？

```matlab
function trajectories = my_mmra_adapter(testcase)
% testcase.start_m       N×3 起点；testcase.goal_m N×3 终点
% testcase.obstacles_m   K×7，每行为 [x0 y0 z0 vx vy vz radius]
% testcase.horizon_s     60，秒；testcase.max_speed_mps=12
% testcase.max_start_hold_s  'active'模式2秒；'schedule'模式45秒
% testcase.inter_uav_spacing_m = 10 m
% testcase.uav_obstacle_clearance_m = 5 m（相对球体表面）
% testcase.bounds_m      3×2，XYZ 各自的允许边界
%
% 调用你自己的 RRT*/MMRA/多机规划程序，生成含绝对时间的轨迹。
% N 个元胞；每个 trajectories{i} = [time_s x_m y_m z_m]，至少两行。
% 所有 UAV 在 t=0 位于 start，t=60 之前到 goal。
% 计划前后保持在起终点，碰撞检查覆盖整个 0–60 秒。
end
```

可以使用延迟起飞、变速、原地等待、主动空间绕行或它们的组合；但不能只返回 Nx3 空间点，这不代表动态避障。

### 自动统计哪些指标？

- `success`：所有飞机抵达目标，同时满足最大段速度、空间边界、连续时间动态球体避碰和连续时间机间避碰。
- `minObstacleMargin_m`：飞行轨迹到所有移动球体表面的距离，减去 5 m 安全净距。负数为违规。
- `minInterUAVMargin_m`：任何两架飞机的三维中心最近距离，减去 10 m。负数为违规。
- `planning_s`：适配器调用耗时（**含 MATLAB 函数调用，不能等同真实在线控制周期**）。
- `pathLengthRatio`：总飞行路径长度 / 总直线起终点距离。
- `maxSpatialDeviation_m`：轨迹偏离对应直连线段的最大几何距离（超过 1 m 视为空间绕行）；不能区分所有类型的非恒速控制。
- `totalStartHold_s`：所有飞机开始移动前累计等待时长。
- **双测试协议**：`active` 最多允许等待起飞 2 秒，优先考察飞行中的避让；`schedule` 最多允许等待 45 秒，考察离线协同起飞调度。两套结果不应混为一个成功率。
- 每负载等级的压力测试成功率曲线。

结果存到 `benchmark_results/<label>_<policy>_trials.csv`、同名 `.mat` 和 `<label>_<policy>_success_vs_load.png`。如分别跑 RRT* 和 MMRA，可使用 `compare_benchmark_runs` 对相同 `case_id` 做配对比较。

## 公平比较要求

1. **同一批输入**：所有算法必须在相同案例 ID 和相同固定随机种子下运行。算法内部有随机性时，再对每组输入重复不同算法种子。
2. **同一约束**：无人机运动上限、安全半径、障碍未来信息、最大规划时间和成功判定都必须一致。规划器不可读 `stress` 标签选择作弊策略。
3. **独立评判**：规划器可以自行声称成功，但成功率由 `benchmark_evaluate` 对输出轨迹计算。
4. **分开报告**：仅推迟起飞、飞行中改变速度或悬停、真正改变空间航迹是三类不同能力。请根据轨迹和记录分别披露，不要把时间规避称为主动三维绕行。
5. **不可达案例**：本包没有通过全局最优性/可行性求解器为每例出具必然有解证明，因此“未成功”不等价于数学上无可行轨迹；只作为相对算法表现。
6. **混合实验**：`combined` 同时检查两类约束；单机成功率和多机整个任务成功率不能混算。

## 目前不能验证的内容

- 不包含静态建筑；本包专测动态障碍和机间避碰，不证明复杂静态建筑通行能力。
- 仅为移动球体，假定已知其整个 0–60 s 的匀速真实轨迹；**不测试未知障碍预测与传感器误差**。复杂几何形状请先用外接球做保守检查，或升级为真实几何检查。
- 评测器对**分段线性时间化轨迹**做连续时间解析最近距离，不是离散采样；但它没有对连续 Bézier 原曲线做严格几何证明（需要更专门的曲线证书）。
- 只校验速度上限，不校验加速度、jerk、转弯曲率、姿态动力学和执行误差；不能凭本测试宣称真实无人机动态可飞行。
- 没有接入你之前的 `urban500_rrtstar_plan`、`urban500_mmra_postprocess` 等源文件，因此没有真正运行你的 MMRA，也没有任何算法成功率的实测结论。
- 此环境没有 MATLAB，`.m` 源码需要在你本机运行自检。数据生成中的解析几何标签通过额外独立的 Python 0.05s 时序采样交叉核对（450/450 一致）；尚无 MATLAB 实测结果。

## 文件清单

- `MMRA_AbilityBenchmark_450cases.mat` MATLAB 输入数据
- `benchmark_manifest.csv` 所有案例元数据与直飞基线风险标签
- `generate_dataset.py` 可再现输入的 Python 生成器；**运行已交付数据不需要 Python**
- `audit_dataset.py` 使用不同的 0.05s 采样算法，复核冲突标签（不能替代连续时间解析判定）
- `benchmark_evaluate.m` 每个案例的独立安全、几何、时长评价
- `benchmark_minsep_continuous.m` 两条时间化折线连续最小距离
- `benchmark_position.m` 路径时间插值与首尾悬停
- `benchmark_straightline_baseline.m` 无避障诊断基线
- `run_mmra_benchmark_selftest.m` 基准算法自检
- `run_mmra_ability_benchmark.m` MATLAB 450 例批量入口
- `benchmark_plot_summary.m` 自动能力曲线
- `compare_benchmark_runs.m` 同案例多算法比较
- `my_mmra_adapter_TEMPLATE.m` 对接你的 MMRA 的模板（当前未接入）
