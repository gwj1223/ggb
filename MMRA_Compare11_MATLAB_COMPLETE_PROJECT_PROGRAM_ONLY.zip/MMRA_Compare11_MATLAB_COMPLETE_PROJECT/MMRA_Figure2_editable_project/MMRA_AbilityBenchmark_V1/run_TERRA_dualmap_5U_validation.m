function R = run_TERRA_dualmap_5U_validation(source, figure2Seed, urbanSeed, budget)
%RUN_TERRA_DUALMAP_5U_VALIDATION Genuine five-UAV validation on original maps.
%
% Place THIS FILE in the existing MMRA_AbilityBenchmark_V1 directory.
% Display-only: DOES NOT call save, saveas, writetable, print, exportgraphics.
% It does not modify the 30-run official results or the source solver.
%
% Replay ACTUAL frozen 30-run outputs (no optimization rerun):
%   R = run_TERRA_dualmap_5U_validation;
%   R = run_TERRA_dualmap_5U_validation('replay',25,10);
%
% Run NEW five-UAV trials on BOTH original maps (no output files):
%   R = run_TERRA_dualmap_5U_validation('live',31,31,'pilot');
%   R = run_TERRA_dualmap_5U_validation('live',31,31,'full');
%
% Figure 2: exact stored 5-km mountain/NFZ scene, five original tasks.
% Urban500: exact V3 static high-rise scene, five original tasks.
% The original source method identifier 'MMRA' is displayed as 'TERRA'.
%
% IMPORTANT: Urban500's original preview can depict moving objects; the
% fleet11 validation tests STATIC obstacle geometry only. Thus the urban
% map is rendered without untested dynamic-obstacle overlays.
%
% Replay pair bounds and strict certification are from the original
% analytic continuous-time validation, NOT a time-grid approximation.

if nargin < 1 || isempty(source), source = 'replay'; end
source = lower(char(source));
assert(any(strcmp(source, {'replay','live'})), ...
    'source must be replay or live.');
if nargin < 2 || isempty(figure2Seed)
    if strcmp(source,'replay'), figure2Seed=25; else, figure2Seed=31; end
end
if nargin < 3 || isempty(urbanSeed)
    if strcmp(source,'replay'), urbanSeed=10; else, urbanSeed=31; end
end
if nargin < 4 || isempty(budget), budget='pilot'; end
budget=lower(char(budget));
assert(any(strcmp(budget,{'pilot','full'})));
validateattributes(figure2Seed,{'numeric'}, ...
    {'scalar','integer','positive','finite'});
validateattributes(urbanSeed,{'numeric'}, ...
    {'scalar','integer','positive','finite'});
if strcmp(source,'replay')
    assert(figure2Seed<=30 && urbanSeed<=30, ...
        'Frozen data contain only fleetSeedIndex 1..30.');
end

base=fileparts(mfilename('fullpath'));
assert(isfile(fullfile(base,'mmra_compare11_cases.m')) && ...
    isfile(fullfile(base,'mmra_fleet11_trial.m')), ...
    ['Copy this file into your ORIGINAL MMRA_AbilityBenchmark_V1 ' ...
     'directory before running. Do not copy the source solver.']);
addpath(base);

names={'figure2','urban500'};
seeds=[figure2Seed,urbanSeed];
labels={'Figure 2: mountain and no-fly zones', ...
        'Urban500: static high-rise buildings'};
C0=struct('suite','','seedIndex',0,'fleet',table(), ...
    'uav',table(),'pairs',table(),'paths',{{}},'trajectories',{{}}, ...
    'mapFigure',[]);
R=repmat(C0,2,1);

for k=1:2
    suite=names{k}; seed=seeds(k);
    C=mmra_compare11_cases(suite); % Loads the EXACT project maps/tasks.
    assert(numel(C)==5, 'The authentic map must have five original tasks.');

    if strcmp(source,'replay')
        [F,U,P,paths,trajectories]=loadFrozen(base,suite,seed);
    else
        o=mmra_fleet11_options(budget);
        [fs,us,ps,paths,trajectories,~] = ...
            mmra_fleet11_trial(C,'MMRA',seed,budget,o);
        F=struct2table(fs);
        U=struct2table(us);
        if isempty(ps), P=table(); else, P=struct2table(ps); end
    end

    R(k).suite=suite;
    R(k).seedIndex=seed;
    R(k).fleet=F;
    R(k).uav=U;
    R(k).pairs=P;
    R(k).paths=paths;
    R(k).trajectories=trajectories;

    R(k).mapFigure=showOriginalMap(C,paths,U,suite,labels{k},seed);
    fprintf('\n--- TERRA / %s / %s / seed index %d ---\n', ...
        upper(suite),upper(source),seed);
    showFleetNumbers(F,U,P);
end

showPairAndTiming(R,source);
if strcmp(source,'replay')
    fprintf('\nOfficial 30-run strict fleet success (frozen):\n');
    for k=1:2
        [frozen,~]=frozenPaths(base,names{k});
        FT=readtable([frozen '_fleet_trials.csv']);
        mask=strcmp(string(FT.algorithm),'MMRA');
        T=FT(mask,:);
        fprintf('  %s: %d/%d fully certified five-UAV missions (%.2f%%)\n', ...
            upper(names{k}), sum(T.strictFleetSuccess==1),height(T), ...
            100*mean(T.strictFleetSuccess==1));
    end
end
fprintf(['\nDISPLAY ONLY: no images or experiment files were saved.\n' ...
    'Pairwise lower bounds are the certification evidence; curves are visual aids.\n']);
end

function [F,U,P,paths,trajectories]=loadFrozen(base,suite,seed)
[prefix,~]=frozenPaths(base,suite);
fleetFile=[prefix '_fleet_trials.csv'];
uavFile=[prefix '_uav_trials.csv'];
pairFile=[prefix '_pair_trials.csv'];
matFile=[prefix '_all_trajectories.mat'];
assert(isfile(fleetFile) && isfile(uavFile) && ...
    isfile(pairFile) && isfile(matFile), ...
    ['Frozen Fleet11 outputs not found. Ensure the full original project ' ...
     'is installed, including benchmark_results/Fleet11/']);
F0=readtable(fleetFile);
U0=readtable(uavFile);
P0=readtable(pairFile);
maskF=strcmp(string(F0.algorithm),'MMRA') & F0.fleetSeedIndex==seed;
maskU=strcmp(string(U0.algorithm),'MMRA') & U0.fleetSeedIndex==seed;
maskP=strcmp(string(P0.algorithm),'MMRA') & P0.fleetSeedIndex==seed;
F=F0(maskF,:); U=U0(maskU,:); P=P0(maskP,:);
assert(height(F)==1 && height(U)==5 && height(P)==10, ...
    'Stored MMRA fleet/UAV/pair records are incomplete.');
U=sortrows(U,'uavIndex');
P=sortrows(P,{'uavA','uavB'});
% The saved Fleet11 file has eleven methods in fixed order, MMRA last.
% k indexes the genuine five-UAV trial for this specific seed, NOT an
% independently invented route or a numerical-optimization trace.
z=load(matFile,'paths','trajectories');
methodNames={'ASTAR','APF','RRTSTAR','RRTCONNECT', ...
    'INFORMEDRRTSTAR','GA','PSO','ACO','DE','GWO','MMRA'};
assert(numel(methodNames)==11 && strcmp(methodNames{end},'MMRA'));
idx=(seed-1)*numel(methodNames)+numel(methodNames);
assert(idx<=numel(z.paths) && idx<=numel(z.trajectories) && ...
    strcmp(string(F0.algorithm(idx)),'MMRA') && ...
    F0.fleetSeedIndex(idx)==seed, ...
    'Frozen trial ordering is different; refusing to guess a trajectory.');
paths=z.paths{idx};
trajectories=z.trajectories{idx};
assert(iscell(paths) && numel(paths)==5, ...
    'Stored five-UAV path set is unavailable.');
end

function [prefix,baseName]=frozenPaths(base,suite)
results=fullfile(base,'benchmark_results','Fleet11');
switch lower(suite)
    case 'figure2'
        baseName='FLEET11_FIGURE2_FULL_FINAL_NATIVE_F2_101_130';
    case 'urban500'
        baseName='FLEET11_URBAN500_FULL_FINAL_NATIVE_U5_101_130';
    otherwise
        error('Unknown map');
end
prefix=fullfile(results,baseName);
end

function fig=showOriginalMap(C,paths,U,suite,label,seed)
starts=vertcat(C.start);
goals=vertcat(C.goal);
if strcmp(suite,'figure2')
    fig=mmra_plot_single_main_map(C(1).scene.env,starts,goals,false);
    ax=findobj(fig,'Type','axes');
    assert(~isempty(ax),'Figure2 renderer returned no axes.');
    ax=ax(1);
    scale=1000; % Original Figure2 renderer uses km.
else
    scene=urban500_scene();
    % Do not display moving hazards that are NOT part of the static
    % Fleet11 validity check. Buildings and coordinates are unchanged.
    if isfield(scene,'dynamic'), scene.dynamic=scene.dynamic([]); end
    [fig,ax]=urban500_draw(scene,0,'ShowMotionLines',false);
    scale=1; % Original urban renderer uses metres.
end
set(fig,'Name',sprintf('TERRA | %s | five UAVs | seed %d', ...
    upper(suite),seed),'NumberTitle','off','Color','white');
if strcmp(suite,'figure2')
    set(fig,'Units','pixels','Position',[80 70 1280 850]);
end
hold(ax,'on');
colors=[190 30 45;0 102 161;39 150 91;135 80 160;215 130 32]/255;
h=gobjects(5,1);
for i=1:5
    if ~isempty(paths{i}) && size(paths{i},2)==3
        Q=paths{i};
        if logical(U.strictSuccess(i)), style='-'; else, style='--'; end
        h(i)=plot3(ax,Q(:,1)/scale,Q(:,2)/scale, ...
            Q(:,3)/scale,style,'Color',colors(i,:), ...
            'LineWidth',2.7,'DisplayName',sprintf('UAV %d',i));
    else
        h(i)=plot3(ax,NaN,NaN,NaN,'--','Color',colors(i,:), ...
            'DisplayName',sprintf('UAV %d (no path)',i));
    end
    plot3(ax,starts(i,1)/scale,starts(i,2)/scale, ...
        starts(i,3)/scale,'o','MarkerSize',6, ...
        'MarkerFaceColor',colors(i,:),'MarkerEdgeColor','k', ...
        'HandleVisibility','off');
    plot3(ax,goals(i,1)/scale,goals(i,2)/scale, ...
        goals(i,3)/scale,'s','MarkerSize',7, ...
        'MarkerFaceColor',colors(i,:),'MarkerEdgeColor','k', ...
        'HandleVisibility','off');
    % Show route identities without overlapping all map markers.
    text(ax,starts(i,1)/scale,starts(i,2)/scale, ...
        starts(i,3)/scale,sprintf('  S%d',i), ...
        'FontSize',9,'FontWeight','bold','Color',colors(i,:), ...
        'HandleVisibility','off');
end
legend(ax,h,cellstr(compose('UAV %d',1:5)), ...
    'Location','northeastoutside');
title(ax,sprintf('TERRA | %s | 5-UAV routes | seed %d',label,seed), ...
    'Interpreter','none','FontWeight','normal');
ax.TickLength=[0 0];
drawnow;
end

function showFleetNumbers(F,U,P)
keys={'geometryAllSuccess','timedFleetSuccess','strictFleetSuccess', ...
    'numTurnCertifiedUAV','totalPathLength_m','makespan_s', ...
    'preConflictPairs','postConflictPairs', ...
    'minInterUAVCertifiedLB_m','requiredSeparation_m', ...
    'totalDepartureWait_s','endToEndWall_s'};
fprintf('Metric                         Actual\n');
for i=1:numel(keys)
    v=F.(keys{i});
    fprintf('  %-29s %g\n',keys{i},v);
end
fprintf('  %-29s %s\n','status',char(string(F.status(1))));
if height(U)==5
    disp(U(:,{'uavIndex','pathLength_m','departureWait_s', ...
        'arrival_s','turnCertified'}));
end
if ~isempty(P) && ismember('afterConflict',P.Properties.VariableNames)
    fprintf('  Pairwise after-conflicts     %d/%d\n', ...
        sum(P.afterConflict==1),height(P));
end
end

function showPairAndTiming(R,source)
fig=figure('Name','TERRA | two-map fleet safety and timing', ...
    'NumberTitle','off','Color','white','Position',[120 80 1480 870]);
layout=tiledlayout(fig,2,2,'Padding','compact','TileSpacing','loose');
for j=1:2
    Q=R(j); P=Q.pairs; U=Q.uav; F=Q.fleet;
    nexttile(layout,j); hold on;
    if ~isempty(P) && all(ismember( ...
            {'beforeCertifiedLowerBound_m','afterMinCertifiedLowerBound_m'}, ...
            P.Properties.VariableNames))
        x=1:height(P);
        b=P.beforeCertifiedLowerBound_m;
        a=P.afterMinCertifiedLowerBound_m;
        % Display is in metres, actual certified lower bounds; no guesses.
        semilogy(x,max(b,eps),'o--','Color',[.72 .31 .22], ...
            'LineWidth',1.3,'MarkerSize',5);
        semilogy(x,max(a,eps),'s-','Color',[.11 .40 .72], ...
            'LineWidth',2.1,'MarkerSize',5);
        yline(10,'k:','10 m safety limit','LineWidth',1.4);
        xticks(x);
        xticklabels(cellstr(compose('%d-%d',P.uavA,P.uavB)));
        xlabel('UAV pair');
        ylabel('Certified separation lower bound (m, log)');
        grid on;
        legend({'Before coordination','After coordination', ...
            '10 m safety limit'},'Location','northeast');
    else
        text(.1,.5,'No valid pairwise certificate available.');
    end
    title(sprintf('%s | pre-conflicts %g / post-conflicts %g', ...
        upper(Q.suite),F.preConflictPairs,F.postConflictPairs), ...
        'Interpreter','none');
    set(gca,'TickLength',[0 0]);

    nexttile(layout,2+j); hold on;
    if height(U)==5 && all(isfinite(U.departureWait_s)) && ...
            all(isfinite(U.arrival_s))
        wait=U.departureWait_s;
        flight=U.arrival_s-U.departureWait_s;
        bar(1:5,[wait,flight],'stacked');
        xticks(1:5); xticklabels({'U1','U2','U3','U4','U5'});
        ylabel('Time (s)');
        xlabel('UAV');
        grid on;
        legend({'Departure delay','Flight time'}, ...
            'Location','northwest');
        title(sprintf('%s | five-UAV makespan %.2f s', ...
            upper(Q.suite),F.makespan_s));
    else
        text(.1,.5,'Fleet timing invalid: do not claim mission success.');
        title(sprintf('%s | no verified schedule',upper(Q.suite)));
    end
    set(gca,'TickLength',[0 0]);
end
title(layout,sprintf( ...
    'TERRA five-UAV time coordination | %s | original maps',upper(source)), ...
    'FontWeight','bold');
drawnow;
end
