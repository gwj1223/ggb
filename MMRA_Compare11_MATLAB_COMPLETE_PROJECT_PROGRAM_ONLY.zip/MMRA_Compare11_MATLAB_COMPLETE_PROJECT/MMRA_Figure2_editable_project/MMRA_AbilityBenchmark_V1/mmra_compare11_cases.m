function cases = mmra_compare11_cases(suite)
%MMRA_COMPARE11_CASES Ground all tasks in the user's ACTUAL saved maps/CSV.
% figure2: saved 5-km mountain/NFZ mission; urban500: actual V3 city.
% mendeley: derived 9 traffic incidents; mendeley_full: 60 ego tasks.
suite = lower(char(suite));
base = fileparts(mfilename('fullpath'));
root = fileparts(base);
src = fullfile(root,'src');
city = fullfile(root,'Urban500_V3_HighRise_Download', ...
    'Urban_Complex_500m_V3_HighRise');
assert(exist(src,'dir')==7 && exist(city,'dir')==7, ...
    'Install patch in the original full MMRA_Figure2_editable_project tree.');
addpath(src,city,base);
empty = struct('suite','','id','','start',[],'goal',[], ...
    'scene',[],'nativeCfg',[],'dataset',[], 'seedTag',0);
switch suite
    case 'figure2'
        f=fullfile(root,'results_static_obstacles_dev', ...
            'Figure2_static_obstacle_rrt_5u.mat');
        assert(isfile(f),'Cannot find saved Figure2 5-UAV mission: %s',f);
        z=load(f,'env','cfg','starts','goals');
        assert(isfield(z,'env') && isfield(z,'cfg'));
        sc=struct('kind','figure2','bounds',[z.env.boundsLo(:), ...
            z.env.boundsHi(:)],'env',z.env,'boxes',zeros(0,6), ...
            'edgeStep',5,'gridStep',250,'rrtStep',175, ...
            'name','Figure2_5km_saved_mountain_NFZ');
        starts=z.starts;goals=z.goals;
        cases=repmat(empty,size(starts,1),1);
        for j=1:numel(cases)
            cases(j)=empty;cases(j).suite=suite;
            cases(j).id=sprintf('FIGURE2_U%02d',j);
            cases(j).start=starts(j,:);cases(j).goal=goals(j,:);
            cases(j).scene=sc;cases(j).nativeCfg=z.cfg;
            cases(j).seedTag=j;
        end
    case 'urban500'
        z=urban500_scene();
        inflated=z.buildings_m;
        pad=z.uavSafetyRadius_m+2;
        inflated(:,[1 3 5])=inflated(:,[1 3 5])-pad;
        inflated(:,[2 4 6])=inflated(:,[2 4 6])+pad;
        sc=struct('kind','urban500','bounds',[5 495;5 495;5 195], ...
            'env',[],'boxes',inflated,'edgeStep',2, ...
            'gridStep',25,'rrtStep',24,'name','Urban500_V3_HighRise');
        cases=repmat(empty,size(z.starts_m,1),1);
        for j=1:numel(cases)
            cases(j)=empty;cases(j).suite=suite;
            cases(j).id=sprintf('URBAN500_U%02d',j);
            cases(j).start=z.starts_m(j,:);
            cases(j).goal=z.goals_m(j,:);
            cases(j).scene=sc;cases(j).seedTag=j;
        end
    case {'mendeley','mendeley_full'}
        assert(exist('mendeley_public_load_cases','file')==2, ...
            'Install the previously supplied Mendeley public CSV module first.');
        if strcmp(suite,'mendeley')
            source=mendeley_public_load_incidents();
        else
            source=mendeley_public_load_cases();
        end
        cases=repmat(empty,numel(source),1);
        for j=1:numel(source)
            d=source(j);
            b=d.bounds_m;
            sc=struct('kind','traffic_only','bounds',b, ...
                'env',[],'boxes',zeros(0,6), ...
                'edgeStep',10,'gridStep',max(20,norm(b(:,2)-b(:,1))/18), ...
                'rrtStep',max(20,norm(d.goal_m-d.start_m)/20), ...
                'name','Mendeley_public_3D_CSV');
            cases(j)=empty;cases(j).suite=suite;
            cases(j).id=d.id;cases(j).start=d.start_m;
            cases(j).goal=d.goal_m;cases(j).scene=sc;
            cases(j).dataset=d;cases(j).seedTag=j;
        end
    otherwise
        error('Unknown suite: %s',suite);
end
for j=1:numel(cases)
    c=cases(j);
    assert(all(mmra_compare11_oracle(c.scene,'points', ...
        [c.start;c.goal])), 'Invalid map endpoint %s',c.id);
end
end
