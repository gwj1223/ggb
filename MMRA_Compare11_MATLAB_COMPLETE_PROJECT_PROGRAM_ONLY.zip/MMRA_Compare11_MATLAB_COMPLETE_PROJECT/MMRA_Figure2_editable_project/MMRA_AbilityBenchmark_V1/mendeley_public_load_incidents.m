function C = mendeley_public_load_incidents()
%MENDELEY_PUBLIC_LOAD_INCIDENTS 9 public-trajectory-derived snapshots.
% An additional, explicitly DERIVED scenario suite: select only reference
% ego logs whose exact piecewise-linear closest approach is below 10m,
% then restart planning 2s before the reference closest-approach time.
% All source positions/timestamps beyond restart are kept, only a common
% time-origin shift and one interpolated initial position are introduced.
% This is NOT an official dataset split or an online replanning demo.
X=mendeley_public_load_cases();
C=X([X.reference_conflict]);
for k=1:numel(C)
    c=C(k);
    Tstart=max(0,c.reference_nearest_time_s-2);
    C(k).id=[c.id '_SNAP2'];
    C(k).snapshot_original_time_s=Tstart;
    C(k).snapshot_offset_s=2;
    C(k).reference_ego=clipAndShift(c.reference_ego,Tstart);
    C(k).start_m=C(k).reference_ego(1,2:4);
    C(k).horizon_s=c.horizon_s-Tstart;
    for j=1:numel(c.traffic)
        C(k).traffic{j}=clipAndShift(c.traffic{j},Tstart);
    end
    dist=inf;at=nan;nearest=nan;safe=true;
    for j=1:numel(C(k).traffic)
        A=C(k).traffic{j};
        [d,t]=mendeley_public_minsep( ...
            C(k).reference_ego,A,C(k).horizon_s);
        if d<dist,dist=d;at=t;nearest=C(k).traffic_ids(j);end
        if norm(C(k).start_m-A(1,2:4))<10-1e-7 || ...
                norm(C(k).goal_m-A(end,2:4))<10-1e-7
            safe=false;
        end
    end
    C(k).reference_minsep_m=dist;
    C(k).reference_nearest_other_id=nearest;
    C(k).reference_nearest_time_s=at;
    C(k).reference_conflict=(dist<10-1e-7);
    C(k).endpoint_feasible=safe;
end
end

function X=clipAndShift(P,t)
assert(t>=0 && t<P(end,1));
p=mendeley_public_position(P,t);
idx=find(P(:,1)>t+1e-9);
X=[[0,p]; [P(idx,1)-t, P(idx,2:4)]];
assert(all(diff(X(:,1))>0));
end
