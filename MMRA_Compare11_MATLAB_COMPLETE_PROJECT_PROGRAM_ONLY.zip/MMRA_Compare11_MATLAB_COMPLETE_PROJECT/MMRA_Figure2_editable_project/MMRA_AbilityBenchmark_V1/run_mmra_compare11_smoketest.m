function run_mmra_compare11_smoketest()
%RUN_MMRA_COMPARE11_SMOKETEST Verify shared geometry, 2 real maps, CSV.
base=fileparts(mfilename('fullpath'));
addpath(base);
sc=struct('kind','urban500','bounds',[0 60;0 60;0 60], ...
    'env',[],'boxes',[20 40 20 40 0 50], ...
    'edgeStep',2,'gridStep',10,'rrtStep',10,'name','selftest');
s=[5 30 10];g=[55 30 10];
assert(~mmra_compare11_oracle(sc,'edge',s,g));
assert(mmra_compare11_oracle(sc,'edge',[5 5 55],[55 5 55]));
c=struct('scene',sc,'start',s,'goal',g);
opts=mmra_compare11_options('pilot');
opts.astarExpansions=25000;
path=mmra_compare11_search('astar',c,opts);
assert(~isempty(path),'A* self-test found no path around a box.');
assert(norm(path(1,:)-s)<1e-7 && norm(path(end,:)-g)<1e-7);
for j=1:size(path,1)-1
    assert(mmra_compare11_oracle(sc,'edge',path(j,:),path(j+1,:)));
end
assert(numel(mmra_compare11_cases('figure2'))==5);
assert(numel(mmra_compare11_cases('urban500'))==5);
assert(numel(mmra_compare11_cases('mendeley'))==9);
assert(numel(mmra_compare11_cases('mendeley_full'))==60);
fprintf('11-method MATLAB interface smoke test PASSED.\n');
fprintf('Two authentic maps and 9+60 Mendeley cases discovered.\n');
end
