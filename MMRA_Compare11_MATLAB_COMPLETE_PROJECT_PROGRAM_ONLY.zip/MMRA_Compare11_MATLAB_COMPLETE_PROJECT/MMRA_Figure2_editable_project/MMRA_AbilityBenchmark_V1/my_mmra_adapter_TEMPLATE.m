function trajectories = my_mmra_adapter_TEMPLATE(testcase)
%MY_MMRA_ADAPTER_TEMPLATE Replace with actual RRT* + MMRA calls.
%
% Input testcase fields:
%   .start_m                 N x 3 [x,y,z], metres
%   .goal_m                  N x 3
%   .obstacles_m             K x 7 [x0,y0,z0,vx,vy,vz,r]
%   .max_speed_mps           scalar
%   .horizon_s               scalar
%   .uav_obstacle_clearance_m (5 metres)
%   .inter_uav_spacing_m     (10 metres)
%   .max_start_hold_s        2s in active mode; 45s in schedule mode
%   .bounds_m                3 x 2 [min,max] per coordinate
%
% Output trajectories is N x 1 cell. trajectories{i} is M x 4:
%   [absolute_time_seconds, x_metres, y_metres, z_metres]
%   Must begin at t=0 and the assigned start, end at its goal, arrive
%   within testcase.horizon_s, and respect <=max_speed_mps each segment.
%
% The evaluator treats drones as holding position after arrival and tests
% against moving obstacles and other drones over the full horizon.
%
% DO NOT return raw xyz paths without time. That would not demonstrate
% any dynamic obstacle avoidance or inter-UAV deconfliction ability.
error('Adapter not connected. Call your own RRT* + MMRA planner and return timed trajectories.');
trajectories={}; %#ok<UNRCH>
end
