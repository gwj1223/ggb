function S=mmra_compare11_report(T)
%MMRA_COMPARE11_REPORT Aggregate only ACTUAL executed cases (no fill-in).
names=unique(cellstr(string(T.algorithm)),'stable');
n=numel(names);
algorithm=cell(n,1);successCount=zeros(n,1);totalCount=zeros(n,1);
successPct=zeros(n,1);meanPlan_s=nan(n,1);
meanEndToEnd_s=nan(n,1);
meanSuccessLength_m=nan(n,1);
for j=1:n
    idx=strcmp(T.algorithm,names{j});
    algorithm{j}=names{j};
    totalCount(j)=sum(idx);
    successCount(j)=sum(T.success(idx));
    successPct(j)=100*successCount(j)/max(totalCount(j),1);
    meanPlan_s(j)=mean(T.planning_s(idx),'omitnan');
    meanEndToEnd_s(j)=mean(T.end_to_end_s(idx),'omitnan');
    good=idx & T.success;
    if any(good),meanSuccessLength_m(j)=mean(T.length_m(good));end
end
S=table(algorithm,successCount,totalCount,successPct, ...
    meanPlan_s,meanEndToEnd_s,meanSuccessLength_m);
fprintf('\n%-18s %8s %11s %14s %14s\n', ...
    'ALGORITHM','SUCCESS','RATE_%','PLAN_S','END_TO_END_S');
for j=1:n
    fprintf('%-18s %3d/%-4d %10.1f%% %14.3f %14.3f\n', ...
        algorithm{j},successCount(j),totalCount(j), ...
        successPct(j),meanPlan_s(j),meanEndToEnd_s(j));
end
end
