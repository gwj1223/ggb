function r=mmra_compare11_validate(c,P)
%MMRA_COMPARE11_VALIDATE Independent geometry + optional Mendeley timing.
% Success is COLLISION/BASIC-KINEMATICS ONLY, not dynamics certification.
r=struct('success',false,'status','NO_PATH','length_m',nan, ...
    'minClearance_m',nan,'maxTurn_deg',nan,'pathPoints',0, ...
    'startHold_s',nan,'minTrafficSep_m',nan,'trajectory',[]);
if ~isnumeric(P) || isempty(P) || size(P,2)~=3 || ...
        size(P,1)<2 || any(~isfinite(P(:)))
    return;
end
P=double(P);
r.pathPoints=size(P,1);
if norm(P(1,:)-c.start)>1e-5 || norm(P(end,:)-c.goal)>1e-5
    r.status='WRONG_ENDPOINTS';return;
end
if ~all(mmra_compare11_oracle(c.scene,'points',P))
    r.status='INVALID_WAYPOINT';return;
end
r.length_m=sum(sqrt(sum(diff(P,1,1).^2,2)));
D=diff(P,1,1);
validD=sqrt(sum(D.^2,2))>1e-8;
if ~all(validD)
    r.status='DUPLICATED_POINTS';return;
end
r.maxTurn_deg=0;
for k=1:size(D,1)-1
    a=D(k,:);b=D(k+1,:);
    co=dot(a,b)/(norm(a)*norm(b));
    r.maxTurn_deg=max(r.maxTurn_deg,acosd(max(-1,min(1,co))));
end
% Independent full segment checks, including no-fly cylinders/terrain.
for j=1:size(P,1)-1
    if ~mmra_compare11_oracle(c.scene,'edge',P(j,:),P(j+1,:))
        r.status='STATIC_COLLISION';return;
    end
end
% Minimum clearance uses sampled points; collisions are checked separately
% with the map's authoritative segment checker.
step=max(2,c.scene.edgeStep);
clearMin=inf;
for j=1:size(P,1)-1
    n=max(2,ceil(norm(P(j+1,:)-P(j,:))/step)+1);
    t=linspace(0,1,n)';
    q=repmat(P(j,:),n,1)+t*(P(j+1,:)-P(j,:));
    clearMin=min(clearMin,min(mmra_compare11_oracle( ...
        c.scene,'clearance',q)));
end
r.minClearance_m=clearMin;
if ~strcmp(c.scene.kind,'traffic_only')
    r.success=true;r.status='PASS_GEOMETRIC_ONLY';return;
end
% Every method gets the SAME departure/speed choices and the SAME public
% fixed-traffic evaluator. No algorithm can modify the nine source tracks.
d=c.dataset;
speeds=unique(min(d.max_speed_mps,[120,105,90,75,60,45]),'stable');
delays=0:1:d.max_start_hold_s;
choices=zeros(numel(speeds)*numel(delays),3);N=0;
for i=1:numel(speeds)
    v=speeds(i);
    if v<=0,continue;end
    for hold=delays
        finish=hold+r.length_m/v;
        if finish>d.horizon_s+1e-7,continue;end
        N=N+1;choices(N,:)=[finish,hold,v];
    end
end
if N==0,r.status='ARRIVAL_AFTER_HORIZON';return;end
choices=sortrows(choices(1:N,:),[1 2]);
for j=1:size(choices,1)
    hold=choices(j,2);v=choices(j,3);
    dt=sqrt(sum(diff(P,1,1).^2,2))/v;
    times=hold+[0;cumsum(dt)];
    xyz=P;
    if hold>1e-9
        xyz=[P(1,:);P];times=[0;times];
    end
    tr=[times,xyz];
    e=mendeley_public_evaluate(d,tr);
    if e.success
        r.success=true;r.status='PASS_TRAFFIC_TIMING';
        r.startHold_s=hold;r.minTrafficSep_m=e.minSeparation_m;
        r.trajectory=tr;return;
    end
end
r.status='NO_VERIFIED_TIMING';
end
