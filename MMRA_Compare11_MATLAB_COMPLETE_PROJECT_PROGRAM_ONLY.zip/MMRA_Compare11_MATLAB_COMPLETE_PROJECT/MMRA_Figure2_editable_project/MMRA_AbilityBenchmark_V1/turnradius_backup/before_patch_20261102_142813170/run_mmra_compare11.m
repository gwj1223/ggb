function T=run_mmra_compare11(suite,maxCases,nSeeds,mode)
%RUN_MMRA_COMPARE11 10 MATLAB baselines + real source MMRA across 3 suites.
%   run_mmra_compare11('figure2',1,1,'pilot')
%   run_mmra_compare11('urban500',1,1,'pilot')
%   run_mmra_compare11('mendeley',9,1,'pilot')
%   run_mmra_compare11('figure2',5,5,'full')
%   run_mmra_compare11('urban500',5,5,'full')
%   run_mmra_compare11('mendeley_full',60,5,'full')
% All experiments are fresh; no fabricated historical planner results.
% Physical feasibility (acceleration, jerk, yaw) is NOT yet certified.
if nargin<1 || isempty(suite),suite='figure2';end
if nargin<4 || isempty(mode),mode='pilot';end
suite=lower(char(suite));mode=lower(char(mode));
C=mmra_compare11_cases(suite);
if nargin<2 || isempty(maxCases),maxCases=numel(C);end
if nargin<3 || isempty(nSeeds),nSeeds=1;end
maxCases=max(1,min(numel(C),floor(maxCases)));
nSeeds=max(1,floor(nSeeds));
assert(any(strcmp(mode,{'pilot','full'})), ...
    'mode must be pilot or full');
opts=mmra_compare11_options(mode);
names={'ASTAR','APF','RRTSTAR','RRTCONNECT','INFORMEDRRTSTAR', ...
    'GA','PSO','ACO','DE','GWO','MMRA'};
base=fileparts(mfilename('fullpath'));
outDir=fullfile(base,'benchmark_results','Comparison11');
if ~isfolder(outDir),mkdir(outDir);end
key=[upper(suite) '_' upper(mode)];
model=struct('suite','','case_id','','algorithm','','seed',0, ...
    'success',false,'status','','planning_s',nan, ...
    'timing_eval_s',nan,'end_to_end_s',nan,'length_m',nan, ...
    'minClearance_m',nan,'maxTurn_deg',nan,'pathPoints',0, ...
    'startHold_s',nan,'minTrafficSep_m',nan, ...
    'allCornersSmoothed',false,'implementation_note','');
K=maxCases*numel(names)*nSeeds;
R=repmat(model,K,1);paths=cell(K,1);trajectories=cell(K,1);
row=0;
fprintf('\n=== 11-ALGORITHM MATLAB COMPARISON: %s (%s) ===\n',suite,mode);
fprintf('Cases=%d; seeds=%d; methods=%d; total planner calls=%d\n', ...
    maxCases,nSeeds,numel(names),K);
for j=1:maxCases
    c=C(j);
    fprintf('\nTASK %d/%d : %s\n',j,maxCases,c.id);
    for r=1:nSeeds
        % Shared seed value for equivalent stochastic runs of each method.
        seed=24001+1009*j+211*r;
        for a=1:numel(names)
            name=names{a};row=row+1;
            R(row)=model;
            R(row).suite=suite;R(row).case_id=c.id;
            R(row).algorithm=name;R(row).seed=seed;
            clk=tic;planClock=tic;
            try
                [P,info]=mmra_compare11_solve(name,c,seed,opts);
                R(row).planning_s=toc(planClock);
                evalClock=tic;
                val=mmra_compare11_validate(c,P);
                R(row).timing_eval_s=toc(evalClock);
                R(row).success=val.success;
                R(row).status=val.status;
                R(row).length_m=val.length_m;
                R(row).minClearance_m=val.minClearance_m;
                R(row).maxTurn_deg=val.maxTurn_deg;
                R(row).pathPoints=val.pathPoints;
                R(row).startHold_s=val.startHold_s;
                R(row).minTrafficSep_m=val.minTrafficSep_m;
                R(row).allCornersSmoothed=info.allCornersSmoothed;
                R(row).implementation_note=info.note;
                paths{row}=P;trajectories{row}=val.trajectory;
            catch ME
                if isnan(R(row).planning_s)
                    R(row).planning_s=toc(planClock);
                end
                R(row).status=['ERROR:' ME.identifier];
                R(row).implementation_note=ME.message;
                paths{row}=[];trajectories{row}=[];
            end
            R(row).end_to_end_s=toc(clk);
            fprintf('%-18s %s | len=%8.2f | total=%7.3f s\n', ...
                name,R(row).status,R(row).length_m,R(row).end_to_end_s);
        end
    end
    partial=struct2table(R(1:row));
    writetable(partial,fullfile(outDir,[key '_trials.csv']));
    save(fullfile(outDir,[key '_trajectories.mat']), ...
        'paths','trajectories','row','suite','mode','opts','-v7');
end
T=struct2table(R(1:row));
summary=mmra_compare11_report(T); %#ok<NASGU>
try
    writetable(summary,fullfile(outDir,[key '_summary.csv']));
catch
end
fprintf('\nFinished: %d planner calls; files at %s\n',row,outDir);
end
