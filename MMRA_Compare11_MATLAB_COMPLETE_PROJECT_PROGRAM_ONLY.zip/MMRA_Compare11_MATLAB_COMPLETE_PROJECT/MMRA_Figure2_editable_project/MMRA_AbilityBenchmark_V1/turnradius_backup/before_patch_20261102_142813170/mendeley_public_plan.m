function [trajectory,info] = mendeley_public_plan(c,mode)
%MENDELEY_PUBLIC_PLAN Use REAL uploaded Urban500 RRT* / MMRA code.
% One ego plans against nine unaltered 3D CSV tracks, treated as known,
% moving point obstacles. This is offline replay, NOT online replanning.
% Modes:
%   'straight' : direct flight at common speed cap, no avoidance
%   'geometry' : Urban500 3D RRT* + shared MMRA, no traffic adaptation
%   'temporal' : geometry + bounded departure/cruise-speed search
%   'proxy'    : temporal, then EXPERIMENTAL spatial proxy-box detours
% Important: this is NOT the standalone mmra_plan_single/APF main solver.
if nargin<2,mode='temporal';end
mode=lower(char(mode));
assert(any(strcmp(mode,{'straight','geometry','temporal','proxy'})), ...
    'Invalid mode.');
trajectory=[];
info=struct('plannerMethod','','proxyAttempts',0, ...
    'allCornersSmoothed',true,'rawPathPoints',nan, ...
    'proposedPathPoints',nan);
if ~c.endpoint_feasible
    error('MENDELEY:EndpointConflict', ...
        'An observed start or end is already within required separation.');
end
start=double(c.start_m(:)');goal=double(c.goal_m(:)');
if strcmp(mode,'straight')
    trajectory=makeTimed([start;goal],0,c.max_speed_mps,c.horizon_s);
    info.plannerMethod='direct_constant_speed';return;
end
[city,src]=getRealSourcePaths();
addpath(city,src);
cfg=makeConfig(c);
seed=deterministicSeed(c.id);
[pathRaw,~]=urban500_rrtstar_plan(start,goal,zeros(0,6),cfg,seed);
assert(~isempty(pathRaw),'Static geometry RRT* returned empty.');
[path0,~,post0]=urban500_mmra_postprocess(pathRaw,zeros(0,6),cfg);
assert(post0.staticCollisionVerified);
info.rawPathPoints=size(pathRaw,1);
info.proposedPathPoints=size(path0,1);
info.allCornersSmoothed=logical(post0.allEligibleCornersSmoothed);
if strcmp(mode,'geometry')
    trajectory=makeTimed(path0,0,c.max_speed_mps,c.horizon_s);
    info.plannerMethod='rrt_mmra_geometry';return;
end
[trajectory,ok]=findTiming(path0,c);
if ok
    info.plannerMethod='rrt_mmra_timing';return;
end
if strcmp(mode,'temporal')
    error('MENDELEY:NoVerifiedTiming', ...
        'No safe delay/cruise-speed option under the frozen replay protocol.');
end
% EXPERIMENTAL fallback: only new spatial proposals come from REAL Urban500
% 3D RRT* and shared MMRA prune/Bezier. Proxy boxes are centered on the
% nearest logged traffic conflict points; the *original unmodified* public
% 3D traffic trajectories are rechecked continuously after every proposal.
[hazards,clearances]=collectHazards(path0,c);
if isempty(hazards)
    error('MENDELEY:NoSpatialHazards', ...
        'Temporal search failed but no hazard proxies were generated.');
end
maxTargets=min(numel(hazards),3);
scales=[1,1.5,2.0];
attempts=0;
for hi=1:maxTargets
    for sc=scales
        attempts=attempts+1;
        box=makeBox(hazards(hi).xyz,sc*hazards(hi).proxyRadius);
        if ~urban500_rrtstar_edge_free(start,start,box) || ...
                ~urban500_rrtstar_edge_free(goal,goal,box)
            continue;
        end
        [raw,~]=urban500_rrtstar_plan(start,goal,box,cfg,seed+1000+attempts);
        if isempty(raw),continue;end
        try
            [smooth,~,post]=urban500_mmra_postprocess(raw,box,cfg);
        catch
            continue;
        end
        % Important: refuse an accepted proxy with non-rounded eligible
        % corners (collision-only acceptance would overstate flyability).
        if ~post.staticCollisionVerified || ~post.allEligibleCornersSmoothed
            continue;
        end
        [trial,ok]=findTiming(smooth,c);
        if ok
            trajectory=trial;
            info.plannerMethod='proxy_rrt_mmra_reroute';
            info.proxyAttempts=attempts;
            info.allCornersSmoothed=true;
            info.rawPathPoints=size(raw,1);
            info.proposedPathPoints=size(smooth,1);
            return;
        end
    end
end
% Also test a joint static proposal for the two worst conflict regions.
if numel(hazards)>=2
    for sc=[1,1.5]
        attempts=attempts+1;
        box=[makeBox(hazards(1).xyz,sc*hazards(1).proxyRadius); ...
             makeBox(hazards(2).xyz,sc*hazards(2).proxyRadius)];
        if ~urban500_rrtstar_edge_free(start,start,box) || ...
                ~urban500_rrtstar_edge_free(goal,goal,box)
            continue;
        end
        [raw,~]=urban500_rrtstar_plan(start,goal,box,cfg,seed+1000+attempts);
        if isempty(raw),continue;end
        try
            [smooth,~,post]=urban500_mmra_postprocess(raw,box,cfg);
        catch
            continue;
        end
        if ~post.staticCollisionVerified || ~post.allEligibleCornersSmoothed
            continue;
        end
        [trial,ok]=findTiming(smooth,c);
        if ok
            trajectory=trial;
            info.plannerMethod='proxy_rrt_mmra_joint2';
            info.proxyAttempts=attempts;
            info.allCornersSmoothed=true;
            info.rawPathPoints=size(raw,1);
            info.proposedPathPoints=size(smooth,1);
            return;
        end
    end
end
info.proxyAttempts=attempts;
error('MENDELEY:NoVerifiedProxy', ...
    'Proxy search exhausted %d proposals. Closest direct margin %.2fm.', ...
    attempts,min(clearances));
end

function [city,src]=getRealSourcePaths()
base=fileparts(mfilename('fullpath'));
root=fileparts(base);
city=fullfile(root,'Urban500_V3_HighRise_Download', ...
    'Urban_Complex_500m_V3_HighRise');
src=fullfile(root,'src');
need={fullfile(city,'urban500_rrtstar_plan.m'), ...
      fullfile(city,'urban500_mmra_postprocess.m'), ...
      fullfile(city,'urban500_rrtstar_edge_free.m'), ...
      fullfile(src,'mmra_bezier.m'), ...
      fullfile(src,'mmra_prune.m')};
for j=1:numel(need)
    assert(exist(need{j},'file')==2, ...
        'Real Urban500/MMRA source not found: %s. Install patch in the original project.',need{j});
end
end

function cfg=makeConfig(c)
b=c.bounds_m;
cfg=struct();cfg.bounds_m=b;
% RRT* step scale is explicitly adapted from Urban500 (500m scene) to the
% ~5000m public source scene. This is an EXPERIMENTAL external benchmark
% setting, not a published Mendeley parameter.
cfg.maxIterations=1800;
cfg.maxIterationsAfterFirstSolution=180;
cfg.maxStep_m=155;
cfg.goalConnectRadius_m=230;
cfg.goalBias=.30;
cfg.highAltitudeBias=.05;
cfg.highAltitudeRange_m=[max(b(3,1)+10,b(3,2)-65),b(3,2)-3];
cfg.neighborGamma_m=550;
cfg.neighborRadiusMin_m=90;
cfg.neighborRadiusMax_m=245;
cfg.mmraPruneMode='shortest_visibility';
cfg.smoothMinRadius_m=10;
cfg.smoothMaxPitch_deg=75;
cfg.smoothTrimFraction=.44;
cfg.smoothTerminalTrimFraction=.96;
cfg.mmraTerminalRepair=true;
cfg.mmraTerminalRepairMaxCandidates=20;
cfg.mmraTerminalRepairMaxExtra_m=35;
cfg.smoothMaxChord_m=2.5;
cfg.smoothMaxSagitta_m=.10;
cfg.smoothMinAngle_deg=2;
cfg.smoothMaxSamples=1000;
end

function [chosen,ok]=findTiming(spatial,c)
chosen=[];ok=false;
xyz=double(spatial);
len=sum(sqrt(sum(diff(xyz,1,1).^2,2)));
speeds=unique(min(c.max_speed_mps,[120,105,90,75,60,45]),'stable');
delays=0:1:c.max_start_hold_s;
options=zeros(numel(speeds)*numel(delays),3);
n=0;
for j=1:numel(speeds)
    s=speeds(j);
    if s<=0,continue;end
    for d=delays
        if d+len/s>c.horizon_s+1e-7,continue;end
        n=n+1;options(n,:)=[d+len/s,d,s];
    end
end
if n==0,return;end
options=sortrows(options(1:n,:),[1,2]);
for i=1:n
    d=options(i,2);s=options(i,3);
    trial=makeTimed(xyz,d,s,c.horizon_s);
    r=mendeley_public_evaluate(c,trial);
    if r.success,chosen=trial;ok=true;return;end
end
end

function P=makeTimed(xyz,delay,speed,H)
xyz=double(xyz);
keep=[true;sum(diff(xyz,1,1).^2,2)>1e-14];
xyz=xyz(keep,:);
assert(size(xyz,1)>=2,'No nonzero path length.');
segment=sqrt(sum(diff(xyz,1,1).^2,2));
t=delay+[0;cumsum(segment)/speed];
assert(t(end)<=H+1e-7,'Path cannot finish before horizon.');
if delay>1e-12
    xyz=[xyz(1,:);xyz];t=[0;t];
end
P=[t,xyz];
end

function [hazards,margins]=collectHazards(xyz,c)
hazards=repmat(struct('margin',inf,'xyz',zeros(1,3), ...
    'proxyRadius',0,'traffic_id',0,'time_s',0),0,1);
margins=[];
% Search closest approach under several deterministic straight-flight
% timings, rather than using a single arbitrary snapshot.
for j=1:numel(c.traffic)
    best=inf;bestT=nan;
    for speed=[120,105,90,75,60,45]
        len=sum(sqrt(sum(diff(xyz,1,1).^2,2)));
        if len/speed>c.horizon_s,continue;end
        p=makeTimed(xyz,0,speed,c.horizon_s);
        [dist,t]=mendeley_public_minsep(p,c.traffic{j},c.horizon_s);
        if dist<best,best=dist;bestT=t;end
    end
    margin=best-c.inter_uav_spacing_m;
    margins(end+1,1)=margin; %#ok<AGROW>
    if margin<25
        h=struct('margin',margin, ...
            'xyz',mendeley_public_position(c.traffic{j},bestT), ...
            'proxyRadius',c.inter_uav_spacing_m+10, ...
            'traffic_id',c.traffic_ids(j),'time_s',bestT);
        hazards(end+1,1)=h; %#ok<AGROW>
    end
end
if ~isempty(hazards)
    [~,idx]=sort([hazards.margin]);hazards=hazards(idx);
end
end

function box=makeBox(center,r)
box=[center(1)-r,center(1)+r,center(2)-r,center(2)+r, ...
    center(3)-r,center(3)+r];
end

function seed=deterministicSeed(id)
a=double(char(id));
seed=mod(sum(a.*(1:numel(a))),double(intmax('int32'))-10000)+210927;
end
