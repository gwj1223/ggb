function o = mmra_fleet11_options(mode)
%MMRA_FLEET11_OPTIONS Explicit, COMMON five-UAV test assumptions.
% Change values BEFORE a run and report them in the paper; neither the
% 10 m separation nor 15 m/s speed is asserted to be the user's hardware.
if nargin<1 || isempty(mode),mode='pilot';end
assert(any(strcmpi(mode,{'pilot','full'})), 'mode must be pilot or full');
o=struct();
o.cruiseSpeed_mps=15;
o.requiredSeparation_m=10; % INTER-AIRCRAFT gap; not the turn radius.
o.delayStep_s=1;
o.maxDepartureDelay_s=120;
o.startPolicy='hold'; % aircraft occupy real launch pads while waiting.
o.endPolicy='hold';   % aircraft remain at landing locations after arrival.
o.pairTolerance_m=1e-8;
o.scheduler='conflict_aware'; % same coordinator for ALL 11 methods.
o.turnRadiusRequired_m=10;
o.pitchLimit_deg=75;
o.missionDeadline_s=inf; % Inf = NO deadline defined; no fictitious pass.
o.enforceBezierSagittaMargin=true;
o.seedOffset=0; % original 1..5 seeds agree with compare11 historical runs.
o.notes='Static maps only; no dynamic obstacles or formation control in this benchmark';
end
