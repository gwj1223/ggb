function run_mmra_turnradius_selftest()
%RUN_MMRA_TURNRADIUS_SELFTEST Fast regression for missing turn-radius gate.
% Runs without any saved mission data or proprietary toolboxes.
base=fileparts(mfilename('fullpath'));
root=fileparts(base);
city=fullfile(root,'Urban500_V3_HighRise_Download', ...
    'Urban_Complex_500m_V3_HighRise');
addpath(base,city);
% A hard 90-degree polyline is geometrically collision-free but its
% instantaneous turn radius is zero. It MUST fail strict certification.
sharp=[0 0 0;20 0 0;20 20 0];
f=mmra_compare11_turnradius_validate(sharp,zeros(0,9),10,75);
assert(~f.certified && strcmp(f.status,'SHARP_JUNCTION') && ...
    f.minPathTurnRadius_m==0);
% Even a 0.57-degree unrounded kink must be detected: the source smoother
% may deliberately skip turns under a 2-degree rounding threshold.
tiny=[0 0 0;20 0 0;40 0.2 0];
f=mmra_compare11_turnradius_validate(tiny,zeros(0,9),10,75);
assert(~f.certified && f.numSharpJunctions==1);
% 90 degree quadratic with 16 m tangent trims has EXACT minimum 3-D
% radius 16/sqrt(2) = 11.3137 m: it must pass a 10 m requirement.
S=[4 0 0]; C=[20 0 0]; E=[20 16 0];
t=linspace(0,1,33)';
Q=bsxfun(@times,(1-t).^2,S)+ ...
    bsxfun(@times,2*t.*(1-t),C)+bsxfun(@times,t.^2,E);
P=[[0 0 0];Q;[20 40 0]];
controls=[S C E];
f=mmra_compare11_turnradius_validate(P,controls,10,75);
assert(f.certified && f.numVerifiedCurves==1 && ...
    abs(f.minCurveRadius_m-16/sqrt(2))<1e-7 && ...
    f.numSharpJunctions==0);
% The independent validator must incorporate the certificate in the
% result, without hiding the geometric success rate.
sc=struct('kind','urban500','bounds',[-100 100;-100 100;-100 100], ...
    'env',[],'boxes',zeros(0,6),'edgeStep',2);
c=struct('start',[0 0 0],'goal',[20 40 0],'scene',sc);
info=struct('algorithm','MMRA','allCornersSmoothed',true, ...
    'curveMetadataAvailable',true,'curveControls',controls, ...
    'minRadiusRequirement_m',10,'maxPitchRequirement_deg',75, ...
    'roundedCornersReported',1);
v=mmra_compare11_validate(c,P,info);
assert(v.geometrySuccess && v.success && v.turnCertified && ...
    v.strictSuccess && strcmp(v.status,'PASS_GEOMETRIC_TURN_CERTIFIED'));
% Same geometric path, but falsely claiming all corners were smoothed:
% the direct smoother failure flag takes precedence over accepted arcs.
info.allCornersSmoothed=false;
v=mmra_compare11_validate(c,P,info);
assert(v.success && ~v.strictSuccess && ~v.turnCertified && ...
    strcmp(v.turnStatus,'UNSMOOTHED_MMRA_CORNER'));
info.allCornersSmoothed=true;
info.curveMetadataAvailable=false;
v=mmra_compare11_validate(c,P,info);
assert(v.success && ~v.strictSuccess && ...
    strcmp(v.turnStatus,'MISSING_MMRA_CURVE_METADATA'));
info.curveMetadataAvailable=true;
info.roundedCornersReported=0;
v=mmra_compare11_validate(c,P,info);
assert(v.success && ~v.strictSuccess && ...
    strcmp(v.turnStatus,'MMRA_CURVE_COUNT_MISMATCH'));
info.roundedCornersReported=1;
% A metadata falsification or untracked point must fail closed.
corrupt=P;corrupt(12,2)=corrupt(12,2)+0.10;
f=mmra_compare11_turnradius_validate(corrupt,controls,10,75);
assert(~f.certified && strcmp(f.status,'BEZIER_SAMPLES_MISMATCH'));
% A too-tight 8 m 90-degree quadratic has radius 5.657 m.
S=[12 0 0];C=[20 0 0];E=[20 8 0];
Q=bsxfun(@times,(1-t).^2,S)+ ...
    bsxfun(@times,2*t.*(1-t),C)+bsxfun(@times,t.^2,E);
P2=[[0 0 0];Q;[20 40 0]];
f=mmra_compare11_turnradius_validate(P2,[S C E],10,75);
assert(~f.certified && strcmp(f.status,'CURVE_RADIUS_BELOW_LIMIT') ...
    && abs(f.minCurveRadius_m-8/sqrt(2))<1e-7);
info.curveControls=[S C E];
info.curveMetadataAvailable=true;
c2=c;
v2=mmra_compare11_validate(c2,P2,info);
assert(v2.success && v2.geometrySuccess && ~v2.turnCertified && ...
    ~v2.strictSuccess && strcmp(v2.turnStatus,'CURVE_RADIUS_BELOW_LIMIT'));
% A truly straight path, with no Bezier controls, has infinite radius.
f=mmra_compare11_turnradius_validate([0 0 0;20 0 0],[],10,75);
assert(f.certified && isinf(f.minPathTurnRadius_m));
fprintf('MMRA turn-radius selftest PASSED (9 regression scenarios).\n');
end
