function trajectories = benchmark_mmra_geometry_adapter(testcase)
%BENCHMARK_MMRA_GEOMETRY_ADAPTER Real static RRT* + MMRA baseline.
% No new dynamic obstacle avoidance or joint scheduling is performed.
trajectories = benchmark_mmra_urban_core(testcase,'geometry');
end
