function [P,note]=mmra_compare11_evolution(method,c,opts)
%MMRA_COMPARE11_EVOLUTION GA/PSO/DE/GWO 3D waypoint search and ACO graph.
% All are explicit MATLAB IMPLEMENTATIONS. They are not claimed to be the
% authors' official implementations of any particular named paper.
method=upper(char(method));sc=c.scene;
% Common A* feasible-path initializer, counted in EACH optimizer runtime.
% Final incumbent is A* unless the evolutionary optimizer proves better.
guide=mmra_compare11_search('astar',c,opts);
if isempty(guide),guide=[c.start;c.goal];end
if strcmp(method,'ACO')
    [P,changed]=acoGraph(c,guide,opts);
else
    [P,changed]=waypointPopulation(method,c,guide,opts);
end
if changed
    note=[method '_Astar_initialized_accepted_improvement'];
else
    note=[method '_Astar_initialized_no_verified_improvement'];
end
end

function [P,changed]=waypointPopulation(method,c,guide,opts)
sc=c.scene;nCP=opts.numWaypoints;
base=samplePath(guide,nCP+2);x0=reshape(base(2:end-1,:)',1,[]);
lo=repmat(sc.bounds(:,1)',1,nCP);
hi=repmat(sc.bounds(:,2)',1,nCP);
span=repmat((sc.bounds(:,2)-sc.bounds(:,1))',1,nCP);
D=numel(x0);N=opts.population;G=opts.generations;
X=repmat(x0,N,1)+randn(N,D).*repmat(0.055*span,N,1);
X(1,:)=x0;X=clip(X,lo,hi);
fitness=inf(N,1);
for i=1:N,fitness(i)=score(X(i,:),c,nCP);end
[globalFit,bi]=min(fitness);best=X(bi,:);
switch method
    case 'GA'
        for gen=1:G
            [fitness,order]=sort(fitness,'ascend');
            X=X(order,:);
            elite=max(2,ceil(N*0.15));Y=X(1:elite,:);
            while size(Y,1)<N
                pa=tourney(fitness);pb=tourney(fitness);
                t=rand;child=t*X(pa,:)+(1-t)*X(pb,:);
                mask=rand(1,D)<0.22;
                child(mask)=child(mask)+randn(1,nnz(mask)).* ...
                    (0.04*(1-gen/(G+1))*span(mask));
                Y(end+1,:)=clip(child,lo,hi); %#ok<AGROW>
            end
            X=Y;
            for i=1:N,fitness(i)=score(X(i,:),c,nCP);end
            [v,i]=min(fitness);
            if v<globalFit,globalFit=v;best=X(i,:);end
        end
    case 'PSO'
        V=zeros(N,D);pbest=X;pfit=fitness;
        for gen=1:G
            w=0.82-0.35*gen/max(1,G);
            V=w*V+1.5*rand(N,D).*(pbest-X)+ ...
                1.5*rand(N,D).*(repmat(best,N,1)-X);
            V=clip(V,-0.12*span,0.12*span);
            X=clip(X+V,lo,hi);
            for i=1:N
                v=score(X(i,:),c,nCP);
                if v<pfit(i),pfit(i)=v;pbest(i,:)=X(i,:);end
                if v<globalFit,globalFit=v;best=X(i,:);end
            end
        end
    case 'DE'
        for gen=1:G
            for i=1:N
                ix=randperm(N,4);ix(ix==i)=[];
                if numel(ix)<3
                    ix=setdiff(1:N,i);ix=ix(randperm(numel(ix),3));
                end
                donor=X(ix(1),:)+0.65*(X(ix(2),:)-X(ix(3),:));
                donor=clip(donor,lo,hi);
                mask=rand(1,D)<0.8;
                mask(randi(D))=true;
                child=X(i,:);child(mask)=donor(mask);
                v=score(child,c,nCP);
                if v<fitness(i)
                    X(i,:)=child;fitness(i)=v;
                    if v<globalFit,globalFit=v;best=child;end
                end
            end
        end
    case 'GWO'
        for gen=1:G
            [~,idx]=sort(fitness);
            leaders=X(idx(1:3),:);
            a=2*(1-gen/max(G,1));Y=zeros(size(X));
            for i=1:N
                candidates=zeros(3,D);
                for k=1:3
                    A=2*a*rand(1,D)-a;
                    C=2*rand(1,D);
                    candidates(k,:)=leaders(k,:)- ...
                        A.*abs(C.*leaders(k,:)-X(i,:));
                end
                Y(i,:)=mean(candidates,1);
            end
            X=clip(Y,lo,hi);
            for i=1:N,fitness(i)=score(X(i,:),c,nCP);end
            [v,i]=min(fitness);
            if v<globalFit,globalFit=v;best=X(i,:);end
        end
    otherwise
        error('Unimplemented population algorithm: %s',method);
end
P=guide;changed=false;
Q=pathFrom(best,c,nCP);
if validRoute(Q,sc) && pathLength(Q)+1e-6<pathLength(P)
    P=Q;changed=true;
end
end

function idx=tourney(f)
ix=randi(numel(f),1,3);
[~,k]=min(f(ix));idx=ix(k);
end

function f=score(x,c,nCP)
P=pathFrom(x,c,nCP);sc=c.scene;
L=pathLength(P);
% Sample optimizer's penalty cheaply; final geometry certification is
% NEVER inferred from this sampled fitness computation.
step=max(8,sc.gridStep/5);
pts=[];
for j=1:size(P,1)-1
    n=max(2,min(90,ceil(norm(P(j+1,:)-P(j,:))/step)+1));
    t=linspace(0,1,n)';
    pts=[pts;repmat(P(j,:),n,1)+t*(P(j+1,:)-P(j,:))]; %#ok<AGROW>
end
clearance=mmra_compare11_oracle(sc,'clearance',pts);
pen=sum(max(0,0.3*sc.gridStep-clearance).^2);
D=diff(P,1,1);bend=0;
for j=1:size(D,1)-1
    a=D(j,:);b=D(j+1,:);
    if norm(a)<1e-7 || norm(b)<1e-7
        bend=bend+1;
    else
        bend=bend+(1-dot(a,b)/(norm(a)*norm(b)))^2;
    end
end
f=L + 0.04*L*bend + 200*pen/max(1,size(pts,1));
end

function P=pathFrom(x,c,nCP)
P=[c.start;reshape(x,3,nCP)';c.goal];
end

function X=clip(X,lo,hi)
X=min(bsxfun(@max,X,lo),hi);
end

function R=samplePath(P,n)
seg=sqrt(sum(diff(P,1,1).^2,2));
s=[0;cumsum(seg)];
keep=[true;diff(s)>1e-9];
P=P(keep,:);s=s(keep);
if numel(s)<2
    R=repmat(P(1,:),n,1);return;
end
R=interp1(s,P,linspace(0,s(end),n)','linear');
R(1,:)=P(1,:);R(end,:)=P(end,:);
end

function tf=validRoute(P,sc)
tf=size(P,1)>=2 && all(mmra_compare11_oracle(sc,'points',P));
if ~tf,return;end
for k=1:size(P,1)-1
    if ~mmra_compare11_oracle(sc,'edge',P(k,:),P(k+1,:))
        tf=false;return;
    end
end
end

function L=pathLength(P)
L=sum(sqrt(sum(diff(P,1,1).^2,2)));
end

function [P,changed]=acoGraph(c,guide,opts)
sc=c.scene;P=guide;changed=false;
% Probabilistic ACO on a collision-certified, undirected 3D visibility graph.
% The A* route is included as a common feasible incumbent/graph backbone.
nodes=[c.start;guide(2:end-1,:);c.goal];
for j=1:opts.acoRandomNodes
    p=sc.bounds(:,1)'+rand(1,3).*(sc.bounds(:,2)'-sc.bounds(:,1)');
    if mmra_compare11_oracle(sc,'points',p)
        nodes(end+1,:)=p; %#ok<AGROW>
    end
end
n=size(nodes,1);goalIdx=size(guide,1);
W=inf(n);W(1:n+1:end)=0;
maxLink=max(sc.rrtStep*4,sc.gridStep*3);
for i=1:n-1
    d=sqrt(sum(bsxfun(@minus,nodes(i+1:end,:),nodes(i,:)).^2,2));
    js=find(d<maxLink)+i;
    for k=1:numel(js)
        j=js(k);
        if mmra_compare11_oracle(sc,'edge',nodes(i,:),nodes(j,:))
            W(i,j)=norm(nodes(i,:)-nodes(j,:));
            W(j,i)=W(i,j);
        end
    end
end
% Guarantee the connected A* backbone when its edges are free.
for i=1:goalIdx-1
    if mmra_compare11_oracle(sc,'edge',nodes(i,:),nodes(i+1,:))
        W(i,i+1)=norm(nodes(i,:)-nodes(i+1,:));
        W(i+1,i)=W(i,i+1);
    end
end
T=ones(n);T(~isfinite(W))=0;
eta=1./max(1,sqrt(sum(bsxfun(@minus,nodes,nodes(goalIdx,:)).^2,2)));
incumbent=pathLength(P);
for gen=1:opts.generations
    deposits=zeros(n);
    for a=1:opts.acoAnts
        route=1;visited=false(1,n);visited(1)=true;
        for step=1:min(n,80)
            u=route(end);
            if u==goalIdx,break;end
            neigh=find(isfinite(W(u,:)) & W(u,:)>0 & ~visited);
            if isempty(neigh),break;end
            weight=(T(u,neigh).^1.1).*(eta(neigh)'.^2.4);
            if sum(weight)<=0,break;end
            cum=cumsum(weight)/sum(weight);
            j=neigh(find(rand<=cum,1,'first'));
            route(end+1)=j;visited(j)=true; %#ok<AGROW>
        end
        if route(end)==goalIdx
            Q=nodes(route,:);L=pathLength(Q);
            if L<incumbent-1e-6 && validRoute(Q,sc)
                incumbent=L;P=Q;changed=true;
            end
            for k=1:numel(route)-1
                i=route(k);j=route(k+1);
                deposits(i,j)=deposits(i,j)+max(0.01, ...
                    pathLength(guide)/L);
                deposits(j,i)=deposits(i,j);
            end
        end
    end
    T=0.70*T+deposits;
    T(~isfinite(W))=0;
    T(isfinite(W))=max(T(isfinite(W)),0.02);
end
end
