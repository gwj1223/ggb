function [eps_m,verified,reason] = mmra_fleet11_curve_bound(P,info)
%MMRA_FLEET11_CURVE_BOUND Bound true Bezier-vs-timed-chord positions.
% Assumption: within each sampled quadratic segment the commanded curve
% parameter t is affine in the corresponding POLYLINE segment time.
% For a quadratic Bezier with uniform samples t=k/n, maximum deviation
% from chord interpolation at identical parameter t is exactly bounded by
% norm(S-2*C+E)/(4*n^2). No bound is asserted for a missing/mismatched arc.
% This does not bound flight-controller tracking error or curve arc speed.
eps_m=nan;verified=false;reason='INVALID_PATH';
if ~isnumeric(P) || size(P,2)~=3 || size(P,1)<2 || any(~isfinite(P(:)))
    return;
end
if ~isstruct(info) || ~isfield(info,'curveControls')
    eps_m=0;
    verified=true;
    reason='NO_RECORDED_CURVES_PIECEWISE_LINEAR';
    return;
end
controls=info.curveControls;
if isempty(controls)
    eps_m=0;verified=true;reason='NO_RECORDED_CURVES_PIECEWISE_LINEAR';
    return;
end
if ~isnumeric(controls) || size(controls,2)~=9 || ...
        any(~isfinite(controls(:)))
    reason='INVALID_CURVE_CONTROLS';return;
end
lastEnd=1;eps_m=0;
N=size(P,1);
for j=1:size(controls,1)
    S=controls(j,1:3);C=controls(j,4:6);E=controls(j,7:9);
    sHits=find(sum(bsxfun(@minus,P,S).^2,2)<1e-10 & ...
        (1:N)'>=lastEnd,1,'first');
    if isempty(sHits),eps_m=nan;reason='MISSING_BEZIER_START';return;end
    eHits=find(sum(bsxfun(@minus,P,E).^2,2)<1e-10 & ...
        (1:N)'>sHits,1,'first');
    if isempty(eHits),eps_m=nan;reason='MISSING_BEZIER_END';return;end
    n=eHits-sHits;
    t=linspace(0,1,n+1)';
    predicted=bsxfun(@times,(1-t).^2,S)+ ...
        bsxfun(@times,2*t.*(1-t),C)+bsxfun(@times,t.^2,E);
    if max(sqrt(sum((predicted-P(sHits:eHits,:)).^2,2)))>1e-5
        eps_m=nan;reason='BEZIER_SAMPLE_MISMATCH';return;
    end
    eps_m=max(eps_m,norm(S-2*C+E)/(4*n^2));
    lastEnd=eHits;
end
verified=true;reason='BEZIER_CHORD_DEVIATION_BOUND';
end
