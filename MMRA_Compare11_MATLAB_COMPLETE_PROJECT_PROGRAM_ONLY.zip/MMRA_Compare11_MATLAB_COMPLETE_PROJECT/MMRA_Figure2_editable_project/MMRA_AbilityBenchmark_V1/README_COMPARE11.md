# MMRA 11-algorithm MATLAB comparison: pilot implementation

## Research protocol

### Authentic task sources

- `figure2`: `results_static_obstacles_dev/Figure2_static_obstacle_rrt_5u.mat`; 5 actual saved 5-km mountain mission pairs; preserves its terrain, finite-height NFZs, and clearance constraints.
- `urban500`: `urban500_scene.m`; 5 actual high-rise city mission pairs; uses 5-m inflation of the official building AABBs.
- `mendeley`: the existing `mendeley_public_load_incidents()` interface; 9 **derived** traffic-close-approach snapshots from the original public CSV; other 9 UAV tracks are FIXED.
- `mendeley_full`: the 60 original-CSV-derived ego-conditioned replanning tasks. Not 60 independent joint missions.

### Algorithms

11 MATLAB labels:

1. ASTAR: 26-connected grid A* on three-dimensional collision-checked voxels.
2. APF: attractive/repulsive field with bounded random local escape; **heuristic variant**.
3. RRTSTAR: actual native Figure2 RRT* or Urban500 RRT* (no MMRA smoothing).
4. RRTCONNECT: two expanding trees, greedy connect.
5. INFORMEDRRTSTAR: rewiring RRT* with informed prolate-ellipsoid sampling after a first feasible route.
6. GA: genetic algorithm; A*-initialized 3D waypoint encoding, tournament, crossover, mutation.
7. PSO: particle swarm optimizer on the same A*-initialized 3D waypoint encoding.
8. ACO: pheromone/heuristic-guided ants over a 3D visibility graph, with A* backbone.
9. DE: differential evolution, A*-initialized 3D waypoint encoding.
10. GWO: grey wolf optimizer, A*-initialized 3D waypoint encoding.
11. MMRA: actual source `mmra_plan_single` on Figure2; actual Urban500 RRT* + shared MMRA postprocess in Urban500/Mendeley geometry.

The five evolutionary/swarm methods are **self-contained MATLAB engineering implementations**, NOT official reference ports or validated reproduction of specific publications. Their A* initialization is explicitly part of their algorithms and included in measured run time; baseline A* is also separately measured. Optimizers retain the A* route when no independently verified improvement is found; inspect the `implementation_note` column. Do not claim improvements from a mislabeled A* fallback.

**Important:** The source project's Figure2 `MMRA` and Urban500 `MMRA` are distinct adapters. The latter is NOT the exact same standalone guided-RRT*+APF solver as the former.

### Test order

From `MMRA_Figure2_editable_project/MMRA_AbilityBenchmark_V1`:

```matlab
run_mmra_compare11_smoketest
T1=run_mmra_compare11('figure2',1,1,'pilot');
T2=run_mmra_compare11('urban500',1,1,'pilot');
T3=run_mmra_compare11('mendeley',9,1,'pilot');

% Only after the pilot passes, the two actual maps first:
T4=run_mmra_compare11('figure2',5,5,'full');
T5=run_mmra_compare11('urban500',5,5,'full');

% Then one public dataset (both suites are from the SAME dataset):
T6=run_mmra_compare11('mendeley',9,5,'full');
T7=run_mmra_compare11('mendeley_full',60,5,'full');

plot_mmra_compare11('figure2','full',1,1);
plot_mmra_compare11('urban500','full',1,1);
```

Results are written under `benchmark_results/Comparison11/` with a CSV per run and MATLAB path data. The driver checkpoints after each task; names include suite and pilot/full mode to avoid overwriting other experimental series.

### What the results CAN and CANNOT establish

- The two maps are currently **static-geometry comparisons**. Moving obstacles/multi-UAV scheduling native to Figure2 and Urban500 are **not** exercised in those map suites. No hidden time coordination is attributed to A*, GA or other pure geometric planners.
- Mendeley cases are traffic-only. All eleven methods use the **same offline known-track delay/speed grid** and the **same independent public trajectory evaluator**; source trajectories remain unchanged. The original incident replay is weak, often soluble by waiting 1 second. This dataset cannot distinguish geometric planners if each finds a direct route.
- `success` means static segment collision validity (maps) or valid timed known-traffic separation (Mendeley). It does **NOT** guarantee minimum turn radius, aircraft acceleration, jerk, yaw-rate, or physical trackability. `maxTurn_deg` is an un-smoothed polyline turn diagnostic, not a curvature certificate.
- Timing: `planning_s` measures the geometry solver only; `timing_eval_s` includes common Mendeley scheduling and independent evaluation; `end_to_end_s` measures both. Do not compare `planning_s` as a full dynamic replanning latency.
- Current MATLAB version has no hard **uniform CPU-time cap** on the native planners; counts of sampling iterations and optimization generations are not equivalent compute budgets. For journal publication, enforce and document a fair time-limited protocol, verify each implementation against reference cases, and study hyperparameter sensitivity.
- The saved Figure2 mission's `env`/`cfg` is loaded directly so the map is the genuine user-saved one, not a generic mountain approximation. If the user changed the live map after saving the mission MAT, recreate the mission MAT before comparing.
- Urban500 uses 5 m inflated boxes, matching the original project (3 m UAV radius + 2 m extra clearance).
- Each `success` and path is evaluated independently of the planner's own success flag. Failed calls are kept as failed rows; nothing is replaced with an invented trajectory.
- Repeated deterministic A* runs under different random seeds are expected to be identical; other stochastic algorithms use the same seed values, but may consume RNG differently.

### Installation

Merge the folder `MMRA_AbilityBenchmark_V1` into the same folder in your **existing Mendeley-enabled full project**. Do not overwrite original maps, sources, or benchmark output. Only new `mmra_compare11_*` and `run_mmra_compare11*` and plotting files are included.

### Why not call this a formal comparison yet?

No MATLAB runtime was available in the artifact-building environment. The code has undergone static checks and Python inspection of real map fixture metadata, but all eleven planners still require your on-machine MATLAB smoke test and validation. External algorithm equivalence has NOT been certified. Treat initial outputs as a pilot for preparing a formal experiment rather than publication-ready evidence.
