function result = run_mmra_fleet11(suite,nSeeds,mode,runTag,o)
%RUN_MMRA_FLEET11 True 5-UAV fleet-level 11-method MATLAB comparison.
%  R = run_mmra_fleet11('urban500',1,'pilot');  % smoke run, 55 solves
%  R = run_mmra_fleet11('figure2',30,'full','FLEET30_F2');
%  R = run_mmra_fleet11('urban500',30,'full','FLEET30_U5');
% Re-run the same tag + parameters to RESUME from the last checkpoint.
% 1 trial means five simultaneous-mission UAV paths, NOT one UAV.
% Input maps are the authentic Figure2/Urban500 five-UAV cases.
% Not supported here: Mendeley 10-UAV data, moving obstacles, formation.
if nargin<1 || isempty(suite),suite='urban500';end
if nargin<2 || isempty(nSeeds),nSeeds=1;end
if nargin<3 || isempty(mode),mode='pilot';end
if nargin<4 || isempty(runTag)
    runTag=datestr(now,'yyyymmdd_HHMMSSFFF');
end
if nargin<5 || isempty(o),o=mmra_fleet11_options(mode);end
suite=lower(char(suite));mode=lower(char(mode));
assert(ismember(suite,{'figure2','urban500'}), ...
    'This is a synchronized FIVE-UAV static-map fleet benchmark only.');
assert(ismember(mode,{'pilot','full'}));
assert(isscalar(nSeeds) && isnumeric(nSeeds) && isfinite(nSeeds) && ...
    nSeeds>=1 && nSeeds==floor(nSeeds),'nSeeds must be a positive integer');
assert(nSeeds<=2000,'Set nSeeds<=2000 per named experiment');
assert(ischar(runTag) || isstring(runTag));
runTag=char(runTag);
assert(~isempty(runTag) && all(isstrprop(runTag,'alphanum') | ...
    runTag=='_' | runTag=='-'), ...
    'Run tag may contain only A-Z, 0-9, underscore and dash');
assert(isfield(o,'missionDeadline_s') && ...
    isscalar(o.missionDeadline_s) && o.missionDeadline_s>0, ...
    'missionDeadline_s must be positive or Inf');
assert(isfield(o,'seedOffset') && isscalar(o.seedOffset) && ...
    isfinite(o.seedOffset) && o.seedOffset==floor(o.seedOffset), ...
    'seedOffset must be a finite integer');
assert(o.cruiseSpeed_mps>0 && o.requiredSeparation_m>0 && ...
    o.delayStep_s>0 && o.maxDepartureDelay_s>=0 && ...
    o.turnRadiusRequired_m>0 && o.pitchLimit_deg>0);
assert(strcmpi(o.startPolicy,'hold') || strcmpi(o.startPolicy,'inactive'));
assert(strcmpi(o.endPolicy,'hold') || strcmpi(o.endPolicy,'inactive'));
assert(o.enforceBezierSagittaMargin, ...
    'Conservative Bezier margin cannot be disabled in the strict fleet protocol.');
C=mmra_compare11_cases(suite);
assert(numel(C)==5,'Expected exactly five UAV missions in the actual map');
names={'ASTAR','APF','RRTSTAR','RRTCONNECT', ...
    'INFORMEDRRTSTAR','GA','PSO','ACO','DE','GWO','MMRA'};
base=fileparts(mfilename('fullpath'));
outDir=fullfile(base,'benchmark_results','Fleet11');
if ~isfolder(outDir),mkdir(outDir);end
prefix=['FLEET11_' upper(suite) '_' upper(mode) '_' runTag];
stateFile=fullfile(outDir,[prefix '_checkpoint.mat']);
K=nSeeds*numel(names);
if isfile(stateFile)
    z=load(stateFile,'state');
    state=z.state;
    assert(state.version==1 && strcmp(state.suite,suite) && ...
        state.nSeeds==nSeeds && strcmp(state.mode,mode) && ...
        isequaln(state.options,o) && isequal(state.methods,names), ...
        'Checkpoint parameters differ; choose a NEW runTag.');
    fprintf('Resuming %s from %d/%d completed fleet trials\n', ...
        prefix,state.nDone,K);
else
    state=struct('version',1,'suite',suite,'mode',mode, ...
        'nSeeds',nSeeds,'options',o,'methods',{names}, ...
        'nDone',0,'fleetRows',{cell(K,1)},'uavRows',{cell(K,1)}, ...
        'pairRows',{cell(K,1)},'paths',{cell(K,1)}, ...
        'trajectories',{cell(K,1)},'plannerInfos',{cell(K,1)});
end
fprintf('\n=== FIVE-UAV FLEET11: %s (%s) ===\n',suite,mode);
fprintf('%d fleet seeds, %d methods, %d fleet trials = %d planner calls\n', ...
    nSeeds,numel(names),K,5*K);
fprintf('Shared speed %.3f m/s; separation %.3f m; delay cap %.1f s\n', ...
    o.cruiseSpeed_mps,o.requiredSeparation_m,o.maxDepartureDelay_s);
fprintf('Start/end policy: %s/%s; scheduler: %s\n', ...
    o.startPolicy,o.endPolicy,o.scheduler);
for k=state.nDone+1:K
    s=floor((k-1)/numel(names))+1;
    a=mod(k-1,numel(names))+1;
    name=names{a};
    fprintf('\nFLEET %d/%d | seed index %d | %-18s\n',k,K,s,name);
    % A method-level unexpected exception is an explicit failed run.
    % Do not silently substitute straight paths or pretend it succeeded.
    try
        [F,Ur,Pr,Pa,Tr,In]=mmra_fleet11_trial(C,name,s,mode,o);
    catch ME
        error('MMRA_FLEET:UnhandledTrial', ...
            'Trial %d %s failed before checkpoint: %s',k,name,ME.message);
    end
    state.fleetRows{k}=F;state.uavRows{k}=Ur;
    state.pairRows{k}=Pr;state.paths{k}=Pa;
    state.trajectories{k}=Tr;state.plannerInfos{k}=In;
    state.nDone=k;
    % Save each method so a lengthy 30-seed run can resume safely.
    save(stateFile,'state','-v7.3');
    exportData(state,outDir,prefix,false);
    fprintf('  geometry=%d/5  turn=%d/5  scheduled=%d  strict=%d', ...
        F.numGeometryUAV,F.numTurnCertifiedUAV, ...
        F.timedFleetSuccess,F.strictFleetSuccess);
    fprintf('  totalLength=%.1f m  makespan=%.1f s  %s\n', ...
        F.totalPathLength_m,F.makespan_s,F.status);
end
result=exportData(state,outDir,prefix,true);
fprintf('\nCompleted %d/%d fleet trials (%d UAV solver calls)\n', ...
    state.nDone,K,5*state.nDone);
fprintf('Results: %s\n',outDir);
end

function result=exportData(state,outDir,prefix,finalize)
n=state.nDone;
result=struct('fleet',table(),'uav',table(),'pairs',table(), ...
    'summary',table(),'outDir',outDir,'prefix',prefix, ...
    'completedFleetTrials',n);
if n==0,return;end
Fs=vertcat(state.fleetRows{1:n});
Us=vertcat(state.uavRows{1:n});
result.fleet=struct2table(Fs);
result.uav=struct2table(Us);
writetable(result.fleet,fullfile(outDir,[prefix '_fleet_trials.csv']));
writetable(result.uav,fullfile(outDir,[prefix '_uav_trials.csv']));
blocks=state.pairRows(1:n);
blocks=blocks(~cellfun(@isempty,blocks));
Pr=[];
if ~isempty(blocks),Pr=vertcat(blocks{:});end
if ~isempty(Pr)
    % Join the fleet identity into each ten-pair block, including failures.
    M=numel(Pr);P=Pr;
    % pairRows may be empty when a method fails basic geometry.
    % Pair identity is restored from original block index (not guessed).
    idx=0;
    for k=1:n
        block=state.pairRows{k};
        for j=1:numel(block)
            idx=idx+1;
            P(idx).suite=state.fleetRows{k}.suite;
            P(idx).algorithm=state.fleetRows{k}.algorithm;
            P(idx).fleetSeedIndex=state.fleetRows{k}.fleetSeedIndex;
        end
    end
    assert(idx==M);
    result.pairs=struct2table(P);
    writetable(result.pairs,fullfile(outDir,[prefix '_pair_trials.csv']));
end
if finalize
    result.summary=mmra_fleet11_summary(result.fleet);
    writetable(result.summary,fullfile(outDir,[prefix '_summary.csv']));
    if any(strcmp(result.fleet.algorithm,'MMRA'))
        paired=mmra_fleet11_paired(result.fleet); %#ok<NASGU>
        writetable(paired,fullfile(outDir,[prefix '_paired_vs_MMRA.csv']));
    end
    % Store the real paths, analytic controls, and time laws for replay.
    paths=state.paths(1:n); %#ok<NASGU>
    trajectories=state.trajectories(1:n); %#ok<NASGU>
    plannerInfos=state.plannerInfos(1:n); %#ok<NASGU>
    save(fullfile(outDir,[prefix '_all_trajectories.mat']), ...
        'paths','trajectories','plannerInfos','-v7.3');
end
end
