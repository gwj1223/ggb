# Real Urban500 / MMRA integration for the 450-case ability benchmark

## 1. What has actually been connected?

This patch uses functions from your uploaded `MMRA_Figure2_editable_project.zip`:

- `urban500_rrtstar_plan.m` (real 3-D RRT* code)
- `urban500_mmra_postprocess.m` (real shared `mmra_prune.m` and `mmra_bezier.m`)
- `urban500_dynamic_schedule.m` and its continuous-time moving-solid checks
- `urban500_interuav_coordinate.m` and its continuous-time aircraft-pair checks
- `benchmark_evaluate.m` (the independent, full-horizon benchmark evaluator)

IMPORTANT: this adapter uses the Urban500 RRT* planner together with the SHARED MMRA pruning / smoothing modules; it does **not** invoke the separate main entry `mmra_plan_single.m` or its APF-guided search. Do not report its numbers as performance of the full standalone MMRA main planner.

It does NOT fake results, read `stress` labels for planning decisions, or modify the 450 fixed input cases. Every accepted result must also pass the original benchmark evaluator. No actual MATLAB run of the new adapter was performed in the packaging environment.

## 2. Interpret the three distinct modes correctly

- `benchmark_mmra_geometry_adapter`: **actual** Urban500 RRT* and MMRA pruning / Bezier smoothing but NO new dynamic planning. This benchmark has NO static buildings, so RRT* typically produces a straight-line shortest path. This is a useful control and **is not a dynamic obstacle avoidance method**.
- `my_mmra_adapter`: actual Urban500 RRT* / MMRA, then the **uploaded** V3.2 independent time scheduling and V3.3 inter-UAV offline coordinator. A bounded priority-aware temporal search is used as fallback. It tests departure time and constant cruise speed; waypoint holds are disabled in this integration. It does not synthesize new spatial obstacles. Label its results `URBAN500_TEMPORAL`, not `MMRA purely spatial`.
- `benchmark_urban500_proxy_hybrid_adapter`: **EXPERIMENTAL NEW code** proposed in this patch. When time scheduling fails, it constructs a temporary STATIC box around a predicted conflict and calls the real Urban500 RRT* + MMRA to propose a spatial detour. It rechecks the route against original time-dependent obstacles and other UAVs. This is offline known-future trajectory planning with snapshot proxy obstacles, NOT true online/real-time 4-D RRT* or the original MMRA alone. Label its results `URBAN500_PROXY_EXPERIMENT`.

The same `benchmark_evaluate` enforces the full 0-60 s horizon; it checks start/goal holding, max segment speed, 3-D bounds, continuous time separation of moving spheres, and inter-UAV separation. This benchmark DOES NOT check vehicle acceleration, jerk, yaw / attitude, actual flight dynamics, or a rigorous curve-geometry certificate for the continuous Bezier between generated samples.

## 3. Installation

Your project root should contain these folders:

```
MMRA_Figure2_editable_project/
  src/
  Urban500_V3_HighRise_Download/
    Urban_Complex_500m_V3_HighRise/
  MMRA_AbilityBenchmark_V1/
    MMRA_AbilityBenchmark_450cases.mat
    benchmark_evaluate.m
    run_mmra_ability_benchmark.m
    (copy patch .m files here)
```

Extract the patch at the **parent directory of `MMRA_Figure2_editable_project`** if you want the directory tree to be merged automatically. If you download the FULL project ZIP, simply extract it to a new directory and use that copy.

Do NOT run directly inside a compressed folder. Do NOT overwrite your original experiment results. Result CSV and PNG outputs go into `MMRA_AbilityBenchmark_V1/benchmark_results`.

## 4. MATLAB commands

Open MATLAB, `cd` into the project `MMRA_AbilityBenchmark_V1` directory, then run:

```matlab
% Existing dataset and evaluator self-test
run_mmra_benchmark_selftest;

% NEW: confirms source functions can be called on three safe controls
run_mmra_adapter_smoke_test;

% First quick check on the same first 30 cases (dynamic L1)
run_mmra_ability_benchmark(@benchmark_mmra_geometry_adapter,30,'RRTMMRA_GEOM','active');
run_mmra_ability_benchmark(@my_mmra_adapter,30,'URBAN500_TEMPORAL','active');
run_mmra_ability_benchmark(@benchmark_urban500_proxy_hybrid_adapter,30,'URBAN500_PROXY_EXPERIMENT','active');

% Full 450 fixed inputs, only AFTER the smoke test passes
run_mmra_ability_benchmark(@my_mmra_adapter,450,'URBAN500_TEMPORAL','active');
run_mmra_ability_benchmark(@benchmark_urban500_proxy_hybrid_adapter,450,'URBAN500_PROXY_EXPERIMENT','active');

% Optional offline schedule study, report SEPARATELY from active
run_mmra_ability_benchmark(@my_mmra_adapter,450,'URBAN500_TEMPORAL','schedule');
```

Or run `run_mmra_integrated_ability_tests(30,'active')` to test all three modes sequentially. The default single-file `my_mmra_adapter` is the **temporal** method; hybrid proxy detours require a separate, explicit handle.

## 5. Fair comparison and caveats

- `active` means **starting delay limited to 2 seconds**; it does NOT establish online perception, reactive control, or active mid-flight replanning. Flight speed can still be adjusted before mission start.
- `schedule` allows up to 45 seconds of starting delay and must be reported separately.
- The data generator makes 300 direct-flight conflict tasks and 150 direct-safe controls; not every conflict case was proven to admit a feasible alternate route. A solver failure is not proof of mathematical infeasibility.
- Moving obstacle motion is assumed known perfectly over the full horizon, and moving obstacles are spheres only. Urban500's original 67 high-rises and mixed moving solids are NOT imported into this independent ability benchmark.
- The proxy-hybrid planner adds new heuristic logic. **Do not cite proxy-hybrid success as the capability of the originally uploaded MMRA algorithm in isolation.** Present it as an ablation / extended algorithm.
- The benchmark runner catches exceptions and writes `PLANNER_ERROR` statuses; these count as unsuccessful cases. Never count `PLANNER_ERROR` as a safe success.
- The original evaluator field `nSpatialReroutes` is actually a count of UAV paths deviating more than 1 m from the straight-line route; it is NOT a measured count of calls to RRT* or online replans.
- This delivered patch has been checked for file wiring and basic static structure, but **has not been executed in MATLAB or Octave here**. Use the smoke test before interpreting any results.

## 6. What the patch changes

Only new files are added under `MMRA_AbilityBenchmark_V1/`. No existing `src/` or Urban500 source file is changed. The uploaded STRAIGHT baseline results are preserved in the full-project version. The original test data stays byte-identical.
