function run_mendeley_public_smoketest()
% Basic MATLAB preflight + independent-vs-legacy minsep cross-check.
% No PASS is asserted for algorithm performance; failure cases are real.
base=fileparts(mfilename('fullpath'));
assert(exist(fullfile(base,'Mendeley_Public_3D_CSV', ...
    'RRTConnect_Baseline.csv'),'file')==2);
C=mendeley_public_load_cases();
assert(numel(C)==60);
assert(numel(unique({C.id}))==60);
assert(all([C.horizon_s]>100));
assert(all([C.max_speed_mps]==120));
assert(all([C.inter_uav_spacing_m]==10));
% Validate vectorized continuous-time evaluator vs the benchmark's earlier
% independent analytic implementation on diverse positive/negative pairs.
assert(exist('benchmark_minsep_continuous','file')==2, ...
    'Existing MMRA_AbilityBenchmark_V1 evaluator not in MATLAB path.');
checkCases=[1 2 4 10 12 14 22 45 60];
for k=checkCases
    c=C(k);i=1;
    [a,~]=mendeley_public_minsep( ...
        c.reference_ego,c.traffic{i},c.horizon_s);
    [b,~]=benchmark_minsep_continuous( ...
        c.reference_ego,c.traffic{i},c.horizon_s);
    assert(abs(a-b)<=1e-6, ...
        'Analytic minimum-separation cross-check failed at %s.',c.id);
end
fprintf('Mendeley CSV import: 6 source logs, 60 ego-conditioned tasks OK.\n');
fprintf('Reference 10m conflict-positive ego tasks: %d/60.\n', ...
    sum([C.reference_conflict]));
fprintf('Endpoint-valid ego tasks: %d/60.\n', ...
    sum([C.endpoint_feasible]));
fprintf('Independent analytic minsep cross-check PASSED.\n');
% Deterministic first four straight cases to check output file handling.
R=run_mendeley_public_benchmark('straight',4);
assert(height(R)==4 && all(isfinite(R.planning_s)));
fprintf('Mendeley public 3D smoke test COMPLETED.\n');
end
