#!/usr/bin/env python3
"""Fixed-seed synthetic 3D UAV ability-test set, no named map/location.
Not a published benchmark; all cases are reproducible, stratified for stress and controls.
"""
import csv
from pathlib import Path
import numpy as np
from scipy.io import savemat

SEED = 20261102
OUT = Path(__file__).resolve().parent
RNG = np.random.default_rng(SEED)
TMAX = 60.0
VMAX = 12.0
UAVR_SAFE = 5.0
PAIR_SAFE = 10.0
LEVEL_NS = [2,3,5,8,10]
LEVEL_OBS = [2,5,10,20,30]
BOUNDS = np.array([[-180.,180.],[-180.,180.],[15.,130.]])
SCHEMA_FIELDS = [
    ('id','O'),('kind','O'),('level','O'),('stress','O'),
    ('start_m','O'),('goal_m','O'),('obstacles_m','O'),
    ('max_speed_mps','O'),('horizon_s','O'),('uav_obstacle_clearance_m','O'),
    ('inter_uav_spacing_m','O'),('max_start_hold_s','O'),('bounds_m','O'),('seed','O'),
]

def norm(x):return float(np.linalg.norm(x))
def direct_traj(a,b):
    d=norm(b-a)
    return np.array([[0,*a],[d/VMAX,*b]], dtype=float)

def moving_dist(P, p0, v):
    dmin = np.inf
    for i in range(len(P)-1):
        t0,t1 = P[i,0],P[i+1,0]
        a = P[i,1:]-p0-v*t0
        b = (P[i+1,1:]-P[i,1:])-v*(t1-t0)
        s = np.clip(-a.dot(b)/b.dot(b),0,1) if b.dot(b)>1e-18 else 0
        dmin = min(dmin,norm(a+s*b))
    # after arrival: hold at goal for remaining horizon
    if P[-1,0] < TMAX:
        a = P[-1,1:]-p0-v*P[-1,0]
        b = -v*(TMAX-P[-1,0]); s = np.clip(-a.dot(b)/b.dot(b),0,1) if b.dot(b)>1e-18 else 0
        dmin = min(dmin,norm(a+s*b))
    return dmin

def interp(P,t):
    if t <= P[0,0]: return P[0,1:]
    if t >= P[-1,0]: return P[-1,1:]
    i=np.searchsorted(P[:,0],t,side='right')-1
    a=(t-P[i,0])/(P[i+1,0]-P[i,0]); return P[i,1:]*(1-a)+P[i+1,1:]*a

def pair_dist(P,Q):
    knots=np.unique(np.r_[0,P[:,0],Q[:,0],TMAX]); dmin=np.inf
    for t0,t1 in zip(knots[:-1],knots[1:]):
        r0=interp(P,t0)-interp(Q,t0)
        dr=interp(P,t1)-interp(P,t0)-interp(Q,t1)+interp(Q,t0)
        s=np.clip(-r0.dot(dr)/dr.dot(dr),0,1) if dr.dot(dr)>1e-18 else 0
        dmin=min(dmin,norm(r0+s*dr))
    return dmin

def baseline_margin(start,goal,obs):
    paths=[direct_traj(a,b) for a,b in zip(start,goal)]
    margin=np.inf; dmin_ob=np.inf; dmin_pair=np.inf
    for P in paths:
        for o in obs:
            d=moving_dist(P,o[:3],o[3:6])-o[6]-UAVR_SAFE
            dmin_ob=min(dmin_ob,d)
            margin=min(margin,d)
    for i in range(len(paths)):
        for j in range(i+1,len(paths)):
            d=pair_dist(paths[i],paths[j])-PAIR_SAFE
            dmin_pair=min(dmin_pair,d)
            margin=min(margin,d)
    return margin,dmin_ob,dmin_pair

def build_agents(kind,lev,stress):
    n=1 if kind=='dynamic' else LEVEL_NS[lev-1]
    radius=RNG.uniform(78,102)
    z=RNG.uniform(55,90)
    phase=RNG.uniform(0,2*np.pi)
    start=np.zeros((n,3)); goal=np.zeros((n,3))
    if stress:
        for j in range(n):
            theta=phase+2*np.pi*j/n
            v=np.array([np.cos(theta),np.sin(theta)])
            start[j]=np.array([*list(radius*v),z])
            goal[j]=np.array([*list(-radius*v),z])
    else:
        # parallel non-colliding lanes, the shortest path is safe
        ys=np.linspace(-120,120,n) if n>1 else np.array([RNG.uniform(-40,40)])
        for j,y in enumerate(ys):
            start[j]=[-radius,y,z]
            goal[j]=[radius,y,z]
    return start,goal

def rand_unit_xy():
    a=RNG.uniform(0,2*np.pi); return np.array([np.cos(a),np.sin(a),0.])

def make_obstacles(start,goal,kind,lev,stress):
    nobs=0 if kind=='interuav' else LEVEL_OBS[lev-1]
    if not nobs:return np.zeros((0,7),dtype=float)
    obs=np.zeros((nobs,7))
    max_speed=[2.5,3.5,5,7,9][lev-1]
    for k in range(nobs):
        r=RNG.uniform(3.0,6.5)
        if not stress:
            # control: far above routes, no speed in z
            p0=np.array([RNG.uniform(-155,155),RNG.uniform(-155,155),126])
            v=rand_unit_xy()*RNG.uniform(.5,max_speed)
        elif k==0:
            # Guaranteed collision with the direct, constant-speed baseline at t=flight_midpoint
            j=int(RNG.integers(0,len(start)))
            t=norm(goal[j]-start[j])/VMAX*RNG.uniform(.35,.65)
            target=start[j]+(goal[j]-start[j])*t/(norm(goal[j]-start[j])/VMAX)
            direction=goal[j]-start[j]; direction/=norm(direction)
            v=np.array([-direction[1],direction[0],0.]) * RNG.uniform(1.5,max_speed)
            p0=target-v*t
        else:
            j=int(RNG.integers(0,len(start)))
            t=norm(goal[j]-start[j])/VMAX*RNG.uniform(.25,.8)
            target=start[j]+(goal[j]-start[j])*t/(norm(goal[j]-start[j])/VMAX)
            offset=rand_unit_xy()*RNG.uniform(12,65)
            offset[2]=RNG.uniform(-18,18)
            v=rand_unit_xy()*RNG.uniform(0.5,max_speed)
            p0=target+offset-v*t
        obs[k]=np.r_[p0,v,r]
    return obs

def build_cases():
    cases=[]; manifest=[]
    for kind in ['dynamic','interuav','combined']:
        for lev in range(1,6):
            for rep in range(1,31):
                stress=(rep<=20)
                attempts=0
                while True:
                    attempts+=1
                    start,goal=build_agents(kind,lev,stress)
                    obs=make_obstacles(start,goal,kind,lev,stress)
                    margin,mod,mpair=baseline_margin(start,goal,obs)
                    label=(margin < -1e-8)
                    # Stress tasks intentionally create a baseline conflict;
                    # control tasks must be collision-free along straight-line paths.
                    if label==stress:break
                    if attempts>100: raise RuntimeError(f'Failed generation for {kind} level {lev} rep {rep}')
                ident=f'{kind.upper()}_L{lev}_{rep:03d}'
                case={'id':ident,'kind':kind,'level':float(lev),'stress':float(stress),
                      'start_m':start,'goal_m':goal,'obstacles_m':obs,
                      'max_speed_mps':VMAX,'horizon_s':TMAX,
                      'uav_obstacle_clearance_m':UAVR_SAFE,
                      'inter_uav_spacing_m':PAIR_SAFE,'max_start_hold_s':2.0,'bounds_m':BOUNDS,
                      'seed':float(SEED)}
                cases.append(case)
                manifest.append([ident,kind,lev,int(stress),len(start),len(obs),
                                 round(float(margin),5),round(float(mod),5) if np.isfinite(mod) else '',
                                 round(float(mpair),5) if np.isfinite(mpair) else '',attempts])
    return cases,manifest

def main():
    cases,manifest=build_cases()
    rec=np.empty((1,len(cases)), dtype=SCHEMA_FIELDS)
    for i,c in enumerate(cases):
        for field,_ in SCHEMA_FIELDS:
            rec[0,i][field]=c[field]
    savemat(OUT/'MMRA_AbilityBenchmark_450cases.mat',{'cases':rec,'benchmarkVersion':'1.0.0', 'generatorSeed':float(SEED)},do_compression=True,long_field_names=True)
    with (OUT/'benchmark_manifest.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f)
        w.writerow(['case_id','kind','load_level','baseline_conflict','n_uavs','n_dynamic_obstacles','baseline_min_margin_m','baseline_dynamic_margin_m','baseline_interuav_margin_m','generation_attempts'])
        w.writerows(manifest)
    print('Created',len(cases),'cases, stress/control',sum(c['stress'] for c in cases), len(cases)-sum(c['stress'] for c in cases))
    print('MAT size', (OUT/'MMRA_AbilityBenchmark_450cases.mat').stat().st_size)
    from scipy.io import loadmat
    rec2=loadmat(OUT/'MMRA_AbilityBenchmark_450cases.mat',simplify_cells=True)['cases']
    assert len(rec2)==len(cases)
    assert rec2[0]['kind']=='dynamic' and np.size(rec2[0]['start_m'])==3
    print('Roundtrip okay; first margin:',manifest[0][6],'; last margin:',manifest[-1][6])

if __name__=='__main__':main()
