function run_mmra_benchmark_selftest()
%RUN_MMRA_BENCHMARK_SELFTEST Validate generated labels and safety oracle.
root=fileparts(mfilename('fullpath'));
S=load(fullfile(root,'MMRA_AbilityBenchmark_450cases.mat'));
C=S.cases;
idx=[1 21 31 51 61 81 151 171 181 201 301 321];
for k=idx
    c=C(k);
    st=benchmark_evaluate(c,benchmark_straightline_baseline(c));
    assert(st.success==~logical(c.stress), ...
        sprintf('Unexpected stress/control label: %s',c.id));
end
% Two crossed, simultaneous motion segments must report exact zero distance.
a=[0,-10,0,50;10,10,0,50];
b=[0,0,-10,50;10,0,10,50];
[d,t]=benchmark_minsep_continuous(a,b,10);
assert(abs(d)<1e-9 && abs(t-5)<1e-9,'Crossing collision regression failed.');
% Different altitudes must be separated correctly.
b(:,4)=b(:,4)+12;
[d,~]=benchmark_minsep_continuous(a,b,10);
assert(abs(d-12)<1e-9,'3-D separation regression failed.');
fprintf('MMRA ability benchmark self-test PASSED (%d sampled cases)\n',numel(idx));
end
