#!/usr/bin/env python3
"""Independent sampled check of the *input labels*, not a planner test.
This is intentionally distinct from the analytic distance formulas used
in generate_dataset.py. Sampling cannot certify every near miss; all
cases were already classified by an exact piecewise-linear check.
"""
from scipy.io import loadmat
from pathlib import Path
import numpy as np

folder=Path(__file__).resolve().parent
C=loadmat(folder/'MMRA_AbilityBenchmark_450cases.mat',simplify_cells=True)['cases']
t=np.arange(0,60.0001,0.05)
counts={'dynamic':0,'interuav':0,'combined':0}
for k,c in enumerate(C):
    S=np.atleast_2d(c['start_m']); G=np.atleast_2d(c['goal_m']); n=len(S)
    obs=np.asarray(c['obstacles_m']).reshape(-1,7)
    poses=[]
    for s,g in zip(S,G):
        D=np.linalg.norm(g-s); tt=np.clip(t/(D/12),0,1)
        poses.append(s[None,:]+tt[:,None]*(g-s)[None,:])
    margin=np.inf
    for P in poses:
        for o in obs:
            centers=o[:3][None,:]+t[:,None]*o[3:6][None,:]
            dist=np.linalg.norm(P-centers,axis=1).min()-o[6]-5
            margin=min(margin,dist)
    for i in range(n):
        for j in range(i+1,n):
            dist=np.linalg.norm(poses[i]-poses[j],axis=1).min()-10
            margin=min(margin,dist)
    is_conflict=margin<0
    if is_conflict!=bool(c['stress']):
        raise AssertionError(f'Label mismatch in {c["id"]} with sampled margin {margin}')
    counts[c['kind']]+=1
    if k%100==0:
        print('Audited',k+1,'/',len(C))
print('Sampled 0.05s audit PASSED:',counts)
