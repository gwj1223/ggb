function C = mendeley_public_load_cases()
%MENDELEY_PUBLIC_LOAD_CASES 60 single-ego tests: 6 logs x 10 ego UAVs.
% Source trajectories are NOT moved, rescaled, re-timed or synthesized.
% One ego must replan from its observed initial to final point, avoiding
% nine *fixed logged* 3D trajectories treated as moving point obstacles.
% This is NOT a 10-agent joint replanning test. No real moving-object logs
% are available from the Mendeley CSV files.
base=fileparts(mfilename('fullpath'));
dirCSV=fullfile(base,'Mendeley_Public_3D_CSV');
names={'RRTConnect_Baseline.csv','RRTConnect_Improved.csv', ...
       'D3QN_Baseline.csv','D3QN_Improved.csv', ...
       'SACDQN_Baseline.csv','SACDQN_Improved.csv'};
keys={'RRT_B','RRT_I','D3QN_B','D3QN_I','SAC_B','SAC_I'};
C=repmat(struct('id','','run_id','','source_csv','', ...
    'ego_id',0,'start_m',zeros(1,3),'goal_m',zeros(1,3), ...
    'traffic',{{}},'traffic_ids',[],'reference_ego',[], ...
    'horizon_s',0,'bounds_m',zeros(3,2), ...
    'max_speed_mps',120,'max_start_hold_s',2, ...
    'inter_uav_spacing_m',10,'reference_minsep_m',nan, ...
    'reference_nearest_other_id',nan,'reference_nearest_time_s',nan, ...
    'reference_conflict',false,'endpoint_feasible',false),60,1);
k=0;
for fileNo=1:numel(names)
    path=fullfile(dirCSV,names{fileNo});
    assert(exist(path,'file')==2,'Missing public CSV file: %s',path);
    TT=readtable(path);
    required={'UAV_ID','Time','Pos_X','Pos_Y','Pos_Z'};
    assert(all(ismember(required,TT.Properties.VariableNames)), ...
        'Source CSV missing required fields: %s',names{fileNo});
    ids=double(TT.UAV_ID);
    assert(all(isfinite(ids)) && isequal(unique(ids(:))',(1:10)), ...
        'Expected 10 integer UAV IDs [1..10].');
    paths=cell(10,1);
    for i=1:10
        mask=(ids==i);
        T=double([TT.Time(mask),TT.Pos_X(mask),TT.Pos_Y(mask),TT.Pos_Z(mask)]);
        T=sortrows(T,1);
        assert(size(T,1)>=2 && all(isfinite(T(:))) && ...
            all(diff(T(:,1))>0) && abs(T(1,1))<1e-9, ...
            'Non-monotone or corrupt source track in %s UAV %d.',names{fileNo},i);
        paths{i}=T;
    end
    H=paths{1}(end,1);
    assert(all(cellfun(@(p)abs(p(end,1)-H)<1e-6,paths)), ...
        'Ten source tracks have inconsistent horizons.');
    coords=vertcat(paths{:}); coords=coords(:,2:4);
    lower=min(coords,[],1);upper=max(coords,[],1);
    % Extra virtual free space is a documented *benchmark assumption*.
    B=[max(-1e5,lower(1)-100),min(1e5,upper(1)+100); ...
       max(-1e5,lower(2)-100),min(1e5,upper(2)+100); ...
       max(0,lower(3)-5),max(300,upper(3)+40)];
    for ego=1:10
        k=k+1;
        idsFixed=setdiff(1:10,ego,'stable');
        fixed=paths(idsFixed);
        C(k).id=sprintf('MEN_%s_U%02d',keys{fileNo},ego);
        C(k).run_id=keys{fileNo};
        C(k).source_csv=names{fileNo};
        C(k).ego_id=ego;
        C(k).start_m=paths{ego}(1,2:4);
        C(k).goal_m=paths{ego}(end,2:4);
        C(k).reference_ego=paths{ego};
        C(k).traffic=fixed;
        C(k).traffic_ids=idsFixed;
        C(k).horizon_s=H;
        C(k).bounds_m=B;
        % COMMON protocol parameters, NOT parameters prescribed by Mendeley.
        C(k).max_speed_mps=120;
        C(k).max_start_hold_s=2;
        C(k).inter_uav_spacing_m=10;
        dm=inf;tt=nan;other=nan;
        ep=true;
        for j=1:numel(fixed)
            [di,ti]=mendeley_public_minsep(paths{ego},fixed{j},H);
            if di<dm,dm=di;tt=ti;other=idsFixed(j);end
            if norm(C(k).start_m-fixed{j}(1,2:4)) < 10-1e-7 || ...
                    norm(C(k).goal_m-fixed{j}(end,2:4)) < 10-1e-7
                ep=false;
            end
        end
        C(k).reference_minsep_m=dm;
        C(k).reference_nearest_other_id=other;
        C(k).reference_nearest_time_s=tt;
        C(k).reference_conflict=(dm<10-1e-7);
        C(k).endpoint_feasible=ep;
    end
end
assert(k==60);
end
