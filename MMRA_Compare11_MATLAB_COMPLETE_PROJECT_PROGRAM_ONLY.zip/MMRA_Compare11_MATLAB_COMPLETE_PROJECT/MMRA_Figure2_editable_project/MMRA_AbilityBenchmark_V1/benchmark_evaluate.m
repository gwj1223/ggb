function r = benchmark_evaluate(c, trajectories)
%BENCHMARK_EVALUATE Independent continuous-time, point-mass safety check.
% Moving obstacles: fixed-radius spheres with p(t)=p0+v*t.
% Aircraft: piecewise-linear timed paths [t,x,y,z], endpoint holding.
% This does NOT certify acceleration, jerk, thrust, or vehicle attitude.
r=struct('success',false,'status','INVALID_OUTPUT', ...
    'minObstacleMargin_m',nan,'minInterUAVMargin_m',nan, ...
    'minMargin_m',nan,'pathLengthRatio',nan, ...
    'maxSpatialDeviation_m',nan,'totalArrival_s',nan, ...
    'totalStartHold_s',nan,'nSpatialReroutes',0);
n=size(c.start_m,1);
if ~iscell(trajectories) || numel(trajectories)~=n
    r.status='WRONG_NUMBER_OF_TRAJECTORIES';return;
end
lengthSum=0; directSum=0; maxDev=0; arrival=0; waitSum=0; nReroutes=0;
for i=1:n
    P=trajectories{i};
    if ~isnumeric(P) || size(P,2)~=4 || size(P,1)<2 || any(~isfinite(P(:)))
        r.status='INVALID_TIMED_TRAJECTORY';return;
    end
    if abs(P(1,1))>1e-7 || any(diff(P(:,1))<=0) || P(end,1)>c.horizon_s+1e-7
        r.status='INVALID_TIME';return;
    end
    s=c.start_m(i,:); g=c.goal_m(i,:);
    if norm(P(1,2:4)-s)>1e-5 || norm(P(end,2:4)-g)>1e-5
        r.status='WRONG_START_OR_GOAL';return;
    end
    lowerViolation=P(:,2:4)<repmat(c.bounds_m(:,1)',size(P,1),1)-1e-7;
    upperViolation=P(:,2:4)>repmat(c.bounds_m(:,2)',size(P,1),1)+1e-7;
    if any(lowerViolation(:)) || any(upperViolation(:))
        r.status='OUT_OF_BOUNDS';return;
    end
    dv=diff(P(:,2:4),1,1); dt=diff(P(:,1));
    distance=sqrt(sum(dv.^2,2));
    if any(distance./dt > c.max_speed_mps+1e-7)
        r.status='SPEED_LIMIT_EXCEEDED';return;
    end
    lengthSum=lengthSum+sum(distance);
    directSum=directSum+norm(g-s);
    arrival=max(arrival,P(end,1));
    firstMove=find(distance>1e-6,1,'first');
    if isempty(firstMove), holdTime=0; else, holdTime=P(firstMove,1); end
    waitSum=waitSum+holdTime;
    if isfield(c,'max_start_hold_s') && holdTime>c.max_start_hold_s+1e-7
        r.status='START_DELAY_EXCEEDED';return;
    end
    u=g-s; u2=dot(u,u);
    if u2<1e-14
        deviations=sqrt(sum((P(:,2:4)-s).^2,2));
    else
        A=P(:,2:4)-repmat(s,size(P,1),1);
        alpha=max(0,min(1,(A*u')/u2));
        projection=repmat(s,size(P,1),1)+alpha*u;
        deviations=sqrt(sum((P(:,2:4)-projection).^2,2));
    end
    pathDev=max(deviations);
    maxDev=max(maxDev,pathDev);
    nReroutes=nReroutes+(pathDev>1.0);
end
r.pathLengthRatio=lengthSum/max(directSum,1e-12);
r.maxSpatialDeviation_m=maxDev;
r.totalArrival_s=arrival;
r.totalStartHold_s=waitSum;
r.nSpatialReroutes=nReroutes;
minOb=inf; minPair=inf;
for i=1:n
    P=trajectories{i};
    for j=1:size(c.obstacles_m,1)
        ob=c.obstacles_m(j,:);
        q0=ob(1:3); vel=ob(4:6);
        Q=[0,q0;c.horizon_s,q0+vel*c.horizon_s];
        d=benchmark_minsep_continuous(P,Q,c.horizon_s);
        margin=d-ob(7)-c.uav_obstacle_clearance_m;
        minOb=min(minOb,margin);
    end
end
for i=1:n
    for j=i+1:n
        d=benchmark_minsep_continuous(trajectories{i},trajectories{j},c.horizon_s);
        minPair=min(minPair,d-c.inter_uav_spacing_m);
    end
end
r.minObstacleMargin_m=minOb;
r.minInterUAVMargin_m=minPair;
r.minMargin_m=min(minOb,minPair);
if minOb<-1e-7
    r.status='DYNAMIC_OBSTACLE_COLLISION';return;
end
if minPair<-1e-7
    r.status='INTER_UAV_COLLISION';return;
end
r.status='PASS';r.success=true;
end
