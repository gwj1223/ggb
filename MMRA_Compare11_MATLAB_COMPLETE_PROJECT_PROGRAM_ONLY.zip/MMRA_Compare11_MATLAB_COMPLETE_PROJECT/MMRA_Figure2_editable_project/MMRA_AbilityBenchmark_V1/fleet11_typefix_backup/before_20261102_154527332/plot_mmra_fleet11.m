function fig=plot_mmra_fleet11(result)
%PLOT_MMRA_FLEET11 Four transparent descriptive plots, no toolbox needed.
% result = output of run_mmra_fleet11(...) or a fleet_trials CSV path.
if istable(result)
    F=result;outDir=pwd;prefix='FLEET11_PLOT';
elseif ischar(result) || isstring(result)
    path=char(result);F=readtable(path);
    outDir=fileparts(path);prefix='FLEET11_PLOT';
else
    F=result.fleet;outDir=result.outDir;prefix=result.prefix;
end
S=mmra_fleet11_summary(F);
names=S.algorithm;
fig=figure('Color','w','Name','5-UAV fleet / 11 algorithms', ...
    'Position',[80 80 1200 800]);
layout=tiledlayout(2,2,'Padding','compact','TileSpacing','compact');
nexttile;bar(S.strictRate_pct);
ylim([0 105]);ylabel('Strict fleet success (%)');
title('Five UAVs all certified + synchronized safe');
set(gca,'XTick',1:numel(names),'XTickLabel',names,'XTickLabelRotation',40);
nexttile;bar(S.timedRate_pct);
ylim([0 105]);ylabel('Timed-safe fleet success (%)');
title('Geometry + shared scheduler (before turn gate)');
set(gca,'XTick',1:numel(names),'XTickLabel',names,'XTickLabelRotation',40);
nexttile;hold on;
for a=1:numel(names)
    x=F(strcmp(F.algorithm,names{a}),:);
    v=x.totalPathLength_m(isfinite(x.totalPathLength_m));
    plot(a+zeros(numel(v),1),v,'.','MarkerSize',10);
end
plot(1:numel(names),S.meanTotalLength_m,'ko','MarkerFaceColor','k');
xlim([.5 numel(names)+.5]);ylabel('Five-UAV total route length (m)');
title('All geometrically valid fleets; dots=trials');
set(gca,'XTick',1:numel(names),'XTickLabel',names,'XTickLabelRotation',40);
nexttile;hold on;
for a=1:numel(names)
    x=F(strcmp(F.algorithm,names{a}),:);
    v=x.makespan_s(isfinite(x.makespan_s));
    plot(a+zeros(numel(v),1),v,'.','MarkerSize',10);
end
plot(1:numel(names),S.meanMakespan_s,'ko','MarkerFaceColor','k');
xlim([.5 numel(names)+.5]);ylabel('Joint makespan (s)');
title('Feasible synchronized fleets only; dots=trials');
set(gca,'XTick',1:numel(names),'XTickLabel',names,'XTickLabelRotation',40);
title(layout,'Same five-UAV tasks; 11 planners; common pairwise coordinator');
if ~isfolder(outDir),mkdir(outDir);end
saveas(fig,fullfile(outDir,[prefix '_fleet_overview.png']));
end
