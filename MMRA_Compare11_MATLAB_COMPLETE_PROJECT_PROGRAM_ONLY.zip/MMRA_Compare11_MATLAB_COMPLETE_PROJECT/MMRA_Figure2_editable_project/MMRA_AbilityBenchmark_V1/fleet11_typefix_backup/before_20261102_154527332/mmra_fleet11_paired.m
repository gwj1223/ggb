function T=mmra_fleet11_paired(F)
%MMRA_FLEET11_PAIRED Paired by fleet seed index (MMRA minus baseline).
% Neither a route length nor a makespan is treated as a failed-run value.
% Report the sample count for BOTH-VALID paired comparisons, not just mean.
assert(istable(F));
names=unique(F.algorithm,'stable');
assert(any(strcmp(names,'MMRA')),'No MMRA rows in fleet trials table');
mm=F(strcmp(F.algorithm,'MMRA'),:);
model=struct('algorithm','','nCommonFleetSeeds',0, ...
    'nGeomLengthPairs',0,'meanLengthMMRA_minusBaseline_m',nan, ...
    'lengthDeltaCI95Halfwidth_m',nan,'nMakespanPairs',0, ...
    'meanMakespanMMRA_minusBaseline_s',nan, ...
    'makespanDeltaCI95Halfwidth_s',nan);
R=repmat(model,numel(names)-1,1);ix=0;
for j=1:numel(names)
    if strcmp(names{j},'MMRA'),continue;end
    ix=ix+1;R(ix)=model;R(ix).algorithm=names{j};
    base=F(strcmp(F.algorithm,names{j}),:);
    [common,ia,ib]=intersect(mm.fleetSeedIndex,base.fleetSeedIndex);
    R(ix).nCommonFleetSeeds=numel(common);
    delta=mm.totalPathLength_m(ia)-base.totalPathLength_m(ib);
    delta=delta(isfinite(delta));
    R(ix).nGeomLengthPairs=numel(delta);
    [R(ix).meanLengthMMRA_minusBaseline_m, ...
        R(ix).lengthDeltaCI95Halfwidth_m]=estimate(delta);
    delta=mm.makespan_s(ia)-base.makespan_s(ib);
    delta=delta(isfinite(delta));
    R(ix).nMakespanPairs=numel(delta);
    [R(ix).meanMakespanMMRA_minusBaseline_s, ...
        R(ix).makespanDeltaCI95Halfwidth_s]=estimate(delta);
end
T=struct2table(R);
end
function [m,half]=estimate(x)
m=nan;half=nan;
if isempty(x),return;end
m=mean(x);
if numel(x)>1,half=1.96*std(x,0)/sqrt(numel(x));end
end
