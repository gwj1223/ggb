function p = mendeley_public_position(T,t)
%MENDELEY_PUBLIC_POSITION XYZ at a time (linear between logged knots).
% Outside logging time, position stays fixed.
assert(size(T,2)==4 && size(T,1)>=2);
t=max(T(1,1),min(T(end,1),t));
p=interp1(T(:,1),T(:,2:4),t,'linear');
end
