function plot_mmra_compare11(suite,mode,caseNumber,seedNumber)
%PLOT_MMRA_COMPARE11 Render actual saved paths and method scoreboards.
if nargin<2 || isempty(mode),mode='pilot';end
if nargin<3 || isempty(caseNumber),caseNumber=1;end
if nargin<4 || isempty(seedNumber),seedNumber=1;end
base=fileparts(mfilename('fullpath'));
out=fullfile(base,'benchmark_results','Comparison11');
key=[upper(char(suite)) '_' upper(char(mode))];
a=load(fullfile(out,[key '_trajectories.mat']));
T=readtable(fullfile(out,[key '_trials.csv']));
C=mmra_compare11_cases(suite);
assert(caseNumber<=numel(C));
c=C(caseNumber);
ids=find(strcmp(T.case_id,c.id));
seeds=unique(T.seed(ids),'stable');
assert(seedNumber<=numel(seeds));
ids=ids(T.seed(ids)==seeds(seedNumber));
f=figure('Color','w','Visible','off','Position',[60 60 1150 690]);
ax=axes('Parent',f);hold(ax,'on');
if strcmp(c.scene.kind,'urban500')
    z=urban500_scene();
    B=z.buildings_m;
    for j=1:size(B,1)
        b=B(j,:);
        x=[b(1) b(2) b(2) b(1) b(1)];
        y=[b(3) b(3) b(4) b(4) b(3)];
        plot3(ax,x,y,b(6)*ones(size(x)),'Color',[.65 .65 .65]);
        plot3(ax,[b(1) b(1)],[b(3) b(3)],[0 b(6)], ...
            'Color',[.8 .8 .8]);
    end
elseif strcmp(c.scene.kind,'figure2')
    env=c.scene.env;
    v=linspace(0,5000,75);[xx,yy]=meshgrid(v,v);
    zz=reshape(mmra_terrain([xx(:) yy(:)],env),size(xx));
    surf(ax,xx,yy,zz,'EdgeColor','none', ...
        'FaceColor',[.76 .81 .73],'FaceAlpha',0.55);
end
if strcmp(c.scene.kind,'traffic_only')
    for q=1:numel(c.dataset.traffic)
        tr=c.dataset.traffic{q};
        plot3(ax,tr(:,2),tr(:,3),tr(:,4),'-', ...
            'Color',[.80 .80 .80],'HandleVisibility','off');
    end
end
colors=lines(numel(ids));legendNames={};legendHandles=[];
for j=1:numel(ids)
    k=ids(j);
    if k>numel(a.paths),continue;end
    P=a.paths{k};
    if isempty(P) || ~T.success(k),continue;end
    h=plot3(ax,P(:,1),P(:,2),P(:,3),'-','LineWidth',2, ...
        'Color',colors(j,:));
    legendHandles=[legendHandles;h]; %#ok<AGROW>
    labelCells=cellstr(string(T.algorithm));
    legendNames{end+1}=labelCells{k}; %#ok<AGROW>
end
hs=plot3(ax,c.start(1),c.start(2),c.start(3),'ko', ...
    'MarkerFaceColor','g','MarkerSize',9);
hg=plot3(ax,c.goal(1),c.goal(2),c.goal(3),'ks', ...
    'MarkerFaceColor','r','MarkerSize',9);
legendNames=[legendNames,{'START','GOAL'}];
legendHandles=[legendHandles;hs;hg];
legend(ax,legendHandles,legendNames,'Location','eastoutside');
xlabel(ax,'X [m]');ylabel(ax,'Y [m]');zlabel(ax,'Z [m]');
title(ax,sprintf('11 algorithm paths | %s | seed %d',c.id,seeds(seedNumber)), ...
    'Interpreter','none');
grid(ax,'on');axis(ax,'tight');view(ax,38,24);
saveas(f,fullfile(out,[key '_' c.id '_routes.png']));close(f);
S=mmra_compare11_report(T);
f=figure('Color','w','Visible','off','Position',[50 50 1100 550]);
bar([S.successPct,S.strictPct],'grouped');
ylabel('Verified success [%]');ylim([0 100]);
legend({'Geometry / traffic','Curvature + timing'}, ...
    'Location','southoutside','Orientation','horizontal');
set(gca,'XTick',1:height(S),'XTickLabel',S.algorithm);
xtickangle(35);grid on;
title(sprintf('%s - actual executed runs',key),'Interpreter','none');
saveas(f,fullfile(out,[key '_success.png']));close(f);
fprintf('Saved actual route and scoreboard PNGs to %s\n',out);
end
