function trialTable = run_mendeley_public_benchmark(mode,maxCases,suite)
%RUN_MENDELEY_PUBLIC_BENCHMARK Replan against PUBLIC 3D CSV traffic.
% USAGE (from MMRA_AbilityBenchmark_V1 folder):
%   run_mendeley_public_benchmark('straight',60)
%   run_mendeley_public_benchmark('geometry',60)
%   run_mendeley_public_benchmark('temporal',60)
%   run_mendeley_public_benchmark('proxy',60)
%   run_mendeley_public_benchmark('straight',9,'incident2')
%   run_mendeley_public_benchmark('proxy',9,'incident2')
%
% 60 EGO-CENTRIC TASKS, NOT 60 INDEPENDENT 10-UAV JOINT MISSIONS.
% Each source run contains ten prerecorded tracks. For every ego UAV,
% the other NINE source tracks are kept FIXED as time-varying obstacles.
% Only the ego is replanned. Source traffic paths/timestamps are untouched.
% See README for constraints, limitations and fair reporting.
if nargin<1 || isempty(mode),mode='temporal';end
mode=lower(char(mode));
assert(any(strcmp(mode,{'straight','geometry','temporal','proxy'})), ...
    'mode must be straight, geometry, temporal or proxy');
if nargin<3 || isempty(suite),suite='full';end
suite=lower(char(suite));
if strcmp(suite,'full')
    C=mendeley_public_load_cases();
elseif strcmp(suite,'incident2')
    C=mendeley_public_load_incidents();
else
    error('suite must be full or incident2');
end
if nargin<2 || isempty(maxCases),maxCases=numel(C);end
maxCases=max(1,min(numel(C),floor(double(maxCases))));
base=fileparts(mfilename('fullpath'));
outDir=fullfile(base,'benchmark_results','Mendeley_Public3D');
if exist(outDir,'dir')~=7,mkdir(outDir);end
resultTemplate=struct('case_id','','source_run','','ego_id',0, ...
    'n_fixed_traffic',9,'horizon_s',nan,'max_speed_mps',120, ...
    'min_separation_required_m',10,'max_start_hold_s',2, ...
    'reference_minsep_m',nan,'reference_conflict_10m',false, ...
    'reference_nearest_id',nan,'endpoint_feasible',false, ...
    'success',false,'status','','planning_s',nan, ...
    'min_separation_m',nan,'min_margin_m',nan, ...
    'path_length_ratio',nan,'max_spatial_deviation_m',nan, ...
    'start_hold_s',nan,'arrival_s',nan,'path_points',nan, ...
    'planner_method','','proxy_attempts',nan, ...
    'mmra_all_corners_smoothed',false);
record=repmat(resultTemplate,maxCases,1);
trajectories=cell(maxCases,1);
for k=1:maxCases
    c=C(k);
    record(k).case_id=c.id;
    record(k).source_run=c.run_id;
    record(k).ego_id=c.ego_id;
    record(k).horizon_s=c.horizon_s;
    record(k).max_speed_mps=c.max_speed_mps;
    record(k).min_separation_required_m=c.inter_uav_spacing_m;
    record(k).max_start_hold_s=c.max_start_hold_s;
    record(k).reference_minsep_m=c.reference_minsep_m;
    record(k).reference_conflict_10m=c.reference_conflict;
    record(k).reference_nearest_id=c.reference_nearest_other_id;
    record(k).endpoint_feasible=c.endpoint_feasible;
    t0=tic;
    try
        [P,info]=mendeley_public_plan(c,mode);
        elapsed=toc(t0);
        st=mendeley_public_evaluate(c,P);
        record(k).planning_s=elapsed;
        record(k).success=st.success;
        record(k).status=st.status;
        record(k).min_separation_m=st.minSeparation_m;
        record(k).min_margin_m=st.minMargin_m;
        record(k).path_length_ratio=st.pathLengthRatio;
        record(k).max_spatial_deviation_m=st.maxSpatialDeviation_m;
        record(k).start_hold_s=st.startHold_s;
        record(k).arrival_s=st.arrival_s;
        record(k).path_points=st.pathPointCount;
        record(k).planner_method=info.plannerMethod;
        record(k).proxy_attempts=info.proxyAttempts;
        record(k).mmra_all_corners_smoothed=info.allCornersSmoothed;
        trajectories{k}=P;
    catch ME
        record(k).planning_s=toc(t0);
        record(k).status=['PLANNER_ERROR: ' ME.identifier];
        trajectories{k}=[];
    end
    if mod(k,5)==0 || k==maxCases
        fprintf('Mendeley %s: %d/%d, accepted %d\n', ...
            mode,k,maxCases,sum([record(1:k).success]));
    end
end
trialTable=struct2table(record);
if strcmp(suite,'full'),prefix=['MENDELEY3D_' upper(mode)];
else,prefix=['MENDELEY3D_INCIDENT2_' upper(mode)];end
writetable(trialTable,fullfile(outDir,[prefix '_trials.csv']));
save(fullfile(outDir,[prefix '_trials.mat']), ...
    'trialTable','trajectories','mode');
% Save all input case metadata in a *separate* original-reference manifest.
manifest=struct2table(record);
manifest=manifest(:,{'case_id','source_run','ego_id', ...
    'horizon_s','reference_minsep_m','reference_conflict_10m', ...
    'reference_nearest_id','endpoint_feasible'});
writetable(manifest,fullfile(outDir,['Mendeley_Public3D_' suite '_manifest.csv']));
fprintf('\nRUN %s: success %d/%d; reference-conflict tasks %d; ', ...
    mode,sum(trialTable.success),height(trialTable), ...
    sum(trialTable.reference_conflict_10m));
fprintf('solved reference-conflict tasks %d/%d\n', ...
    sum(trialTable.success & trialTable.reference_conflict_10m), ...
    sum(trialTable.reference_conflict_10m));
fprintf('Successful spatial deviations >1m: %d\n', ...
    sum(trialTable.success & trialTable.max_spatial_deviation_m>1));
if maxCases==60 && strcmp(suite,'full')
    for runIdx=1:6
        k=(runIdx-1)*10+1:runIdx*10;
        fprintf('%-7s %2d/%2d success; ref conflicts %d; solved ref conflicts %d\n', ...
            C(k(1)).run_id,sum(trialTable.success(k)),10, ...
            sum(trialTable.reference_conflict_10m(k)), ...
            sum(trialTable.success(k) & trialTable.reference_conflict_10m(k)));
    end
end
fprintf('CSV/MAT output: %s\n',outDir);
end
