function [pairs,summary] = mmra_fleet11_pair_audit(paths,delays,o,eps_m)
%MMRA_FLEET11_PAIR_AUDIT All 10 synchronized pairs (five UAVs).
% Minimum polyline distance calls project's continuous-time analytical
% mmra_pair_minsep, NOT a time-grid nearest-neighbor approximation.
% Safe lower bound on actual Bezier points = polyline distance - eps_i-eps_j
% for the explicit piecewise-affine parameter time law; see curve_bound.
% Violation duration is analytic for the same occupancy/time model.
U=numel(paths);
assert(U>=2 && numel(delays)==U && numel(eps_m)==U);
sopt=struct('speed',o.cruiseSpeed_mps,'dSafe',o.requiredSeparation_m, ...
    'tol',o.pairTolerance_m,'delayStep',o.delayStep_s, ...
    'maxDelay',o.maxDepartureDelay_s,'startPolicy',o.startPolicy, ...
    'endPolicy',o.endPolicy);
model=struct('uavA',0,'uavB',0,'beforeMinDistance_m',nan, ...
    'beforeCertifiedLowerBound_m',nan,'afterMinPolyline_m',nan, ...
    'afterMinCertifiedLowerBound_m',nan,'requiredSeparation_m', ...
    o.requiredSeparation_m,'afterSafetyMargin_m',nan, ...
    'closestTime_s',nan,'violationDuration_s',nan, ...
    'beforeConflict',false,'afterConflict',false);
pairs=repmat(model,U*(U-1)/2,1);
summary=struct('preConflictPairs',0,'postConflictPairs',nan, ...
    'minPolyline_m',nan,'minCertifiedLB_m',nan, ...
    'minMargin_m',nan,'violationDuration_s',nan, ...
    'safe',false,'checkedPairs',0);
afterReady=all(isfinite(delays(:)));
if afterReady
    summary.postConflictPairs=0;
    summary.minPolyline_m=inf;
    summary.minCertifiedLB_m=inf;
    summary.minMargin_m=inf;
    summary.violationDuration_s=0;
end
p=0;
for i=1:U-1
    for j=i+1:U
        p=p+1;pairs(p)=model;
        pairs(p).uavA=i;pairs(p).uavB=j;
        [before,~,~]=mmra_pair_minsep(paths{i},paths{j},0,0,sopt);
        pairs(p).beforeMinDistance_m=before;
        pairs(p).beforeCertifiedLowerBound_m=before-eps_m(i)-eps_m(j);
        pairs(p).beforeConflict= ...
            pairs(p).beforeCertifiedLowerBound_m < ...
            o.requiredSeparation_m-o.pairTolerance_m;
        summary.preConflictPairs=summary.preConflictPairs+ ...
            double(pairs(p).beforeConflict);
        if ~afterReady,continue;end
        [d,t,~]=mmra_pair_minsep(paths{i},paths{j}, ...
            delays(i),delays(j),sopt);
        lower=d-eps_m(i)-eps_m(j);
        pairs(p).afterMinPolyline_m=d;
        pairs(p).afterMinCertifiedLowerBound_m=lower;
        pairs(p).afterSafetyMargin_m=lower-o.requiredSeparation_m;
        pairs(p).closestTime_s=t;
        pairs(p).afterConflict=lower<o.requiredSeparation_m-o.pairTolerance_m;
        pairs(p).violationDuration_s=violationSeconds(paths{i},paths{j}, ...
            delays(i),delays(j),sopt, ...
            o.requiredSeparation_m+eps_m(i)+eps_m(j));
        summary.postConflictPairs=summary.postConflictPairs+ ...
            double(pairs(p).afterConflict);
        summary.minPolyline_m=min(summary.minPolyline_m,d);
        summary.minCertifiedLB_m=min(summary.minCertifiedLB_m,lower);
        summary.minMargin_m=min(summary.minMargin_m, ...
            lower-o.requiredSeparation_m);
        summary.violationDuration_s=summary.violationDuration_s+ ...
            pairs(p).violationDuration_s;
        summary.checkedPairs=summary.checkedPairs+1;
    end
end
summary.safe=afterReady && summary.checkedPairs==numel(pairs) && ...
    summary.postConflictPairs==0 && summary.violationDuration_s<1e-8;
end

function dur=violationSeconds(A,B,delayA,delayB,opt,dSafe)
% Relative position affine on each merged time interval; integrate exactly
% the subset satisfying squaredDistance(t) < dSafe^2.
[PA,CA,LA]=mmra_arc(A);[PB,CB,LB]=mmra_arc(B);
TA=delayA+CA/opt.speed;TB=delayB+CB/opt.speed;
fin=max(TA(end),TB(end));
events=unique(sort([0;TA(:);TB(:);fin+1]));
dur=0;
for k=1:numel(events)-1
    a=events(k);b=events(k+1);span=b-a;
    if span<1e-10,continue;end
    mid=(a+b)/2;
    if ~isActive(mid,delayA,TA(end),opt) || ...
            ~isActive(mid,delayB,TB(end),opt)
        continue;
    end
    a0=posAtTime(a,PA,CA,LA,delayA,opt.speed);
    a1=posAtTime(b,PA,CA,LA,delayA,opt.speed);
    b0=posAtTime(a,PB,CB,LB,delayB,opt.speed);
    b1=posAtTime(b,PB,CB,LB,delayB,opt.speed);
    r=a0-b0;v=(a1-a0)-(b1-b0);
    aa=dot(v,v);bb=2*dot(r,v);cc=dot(r,r)-dSafe^2;
    if aa<1e-22
        if cc<0,dur=dur+span;end
        continue;
    end
    discr=bb*bb-4*aa*cc;
    if discr<=0
        if cc<0,dur=dur+span;end
        continue;
    end
    root1=(-bb-sqrt(discr))/(2*aa);
    root2=(-bb+sqrt(discr))/(2*aa);
    dur=dur+max(0,min(1,root2)-max(0,root1))*span;
end
end

function a=isActive(t,delay,finish,opt)
if t<delay
    a=strcmpi(opt.startPolicy,'hold');
elseif t>finish
    a=strcmpi(opt.endPolicy,'hold');
else
    a=true;
end
end

function p=posAtTime(t,P,C,L,delay,v)
if t<=delay,p=P(1,:);return;end
if t>=delay+L/v,p=P(end,:);return;end
s=min(L,max(0,(t-delay)*v));
k=find(C<=s,1,'last');
if k>=size(P,1),p=P(end,:);return;end
frac=(s-C(k))/(C(k+1)-C(k));
p=P(k,:)+frac*(P(k+1,:)-P(k,:));
end
