function T=run_mmra_localrepair_audit(maxCases,nSeeds)
%RUN_MMRA_LOCALREPAIR_AUDIT Re-run only MMRA with automatic old-audit backup.
% Leaves 11-algorithm comparison trial CSV/MAT completely untouched.
% Historical pre-repair audit files are saved/restored; repaired results are
% copied to MMRA_LOCALREPAIR_AUDIT_URBAN500_FULL.*
if nargin<1 || isempty(maxCases),maxCases=5;end
if nargin<2 || isempty(nSeeds),nSeeds=5;end
base=fileparts(mfilename('fullpath'));
outDir=fullfile(base,'benchmark_results','Comparison11');
if ~isfolder(outDir),mkdir(outDir);end
filenames={'MMRA_TURN_AUDIT_URBAN500_FULL.csv', ...
    'MMRA_TURN_AUDIT_URBAN500_FULL.mat'};
ts=datestr(now,'yyyymmdd_HHMMSSFFF');
backup=fullfile(outDir,'localrepair_audit_backup',['before_' ts]);
if ~isfolder(backup),mkdir(backup);end
for k=1:numel(filenames)
    f=fullfile(outDir,filenames{k});
    if isfile(f),copyfile(f,fullfile(backup,filenames{k}));end
end
% Restore prior audit even if MATLAB raises an exception mid-run.
restore=onCleanup(@()restoreOld(outDir,backup,filenames)); %#ok<NASGU>
T=run_mmra_turnradius_audit('urban500',maxCases,nSeeds);
for k=1:numel(filenames)
    f=fullfile(outDir,filenames{k});
    ext='.csv';if k==2,ext='.mat';end
    assert(isfile(f),'Expected fresh localrepair audit not found.');
    copyfile(f,fullfile(outDir, ...
        ['MMRA_LOCALREPAIR_AUDIT_URBAN500_FULL' ext]));
end
fprintf('Repaired strict successes: %d/%d\n',sum(T.strictSuccess),height(T));
fprintf('Old audit backed up at %s\n',backup);
fprintf('Repaired audit: MMRA_LOCALREPAIR_AUDIT_URBAN500_FULL.csv/.mat\n');
end

function restoreOld(outDir,backup,files)
for i=1:numel(files)
    from=fullfile(backup,files{i});
    if isfile(from),copyfile(from,fullfile(outDir,files{i}));end
end
end
