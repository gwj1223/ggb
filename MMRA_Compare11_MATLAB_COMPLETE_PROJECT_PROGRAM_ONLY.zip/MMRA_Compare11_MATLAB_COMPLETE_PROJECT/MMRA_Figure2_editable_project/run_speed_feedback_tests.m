%RUN_SPEED_FEEDBACK_TESTS Focused v2.2 regression without planning 60 cases.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'tests'));
mmra_speed_feedback_tests();
