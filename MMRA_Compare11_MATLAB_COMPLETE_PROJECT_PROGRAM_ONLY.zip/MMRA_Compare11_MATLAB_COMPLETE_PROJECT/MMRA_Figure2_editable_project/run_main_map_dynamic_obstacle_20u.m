%RUN_MAIN_MAP_DYNAMIC_OBSTACLE_20U Same Figure 2, SAME cached RRT* paths.
% Development A/B test: identical 20 original polylines, with and without
% ONE synthetic moving obstacle crossing a real UAV flight path. No new
% terrain map is created and no RRT* rerun is performed by this script.
% IMPORTANT: Run run_main_map_20u_pilot.m first if checkpoint is missing.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
[env,~,opt]=mmra_defaults('mountain_cluster_figure2_custom_5km');
folder=fullfile(root,'results_5km_dev');
D=dir(fullfile(folder, ...
    'paths_mountain_cluster_figure2_custom_5km_cross_center_u20_seed24002*.mat'));
assert(~isempty(D), ['No existing Figure 2 20-UAV path checkpoint found. ' ...
    'Run run_main_map_20u_pilot.m first.']);
[~,order]=sort([D.datenum],'descend');
found=false;
for q=reshape(order,1,[])
    candidate=fullfile(D(q).folder,D(q).name);
    loaded=load(candidate,'checkpointData');
    if ~isfield(loaded,'checkpointData'),continue;end
    c=loaded.checkpointData;
    if isfield(c,'env') && isequal(c.env,env) && ...
            isfield(c,'spatialOK') && all(c.spatialOK) && ...
            isfield(c,'paths') && numel(c.paths)==20
        found=true;checkpoint=candidate;break;
    end
end
assert(found,['Found 20-UAV checkpoints, but none match the CURRENT ' ...
    'user-saved Figure 2 terrain. Rerun run_main_map_20u_pilot.m.']);
P=c.paths;
% Identical baseline on this exact geometry, with NO moving obstacle.
if isfield(opt,'speedFeedbackDynamicObstacles')
    opt=rmfield(opt,'speedFeedbackDynamicObstacles');
end
base=mmra_schedule_speed_feedback(P,opt);
assert(base.success && base.validation.safe, ...
    'The base 20-UAV speed schedule must complete before obstacle A/B.');

% Place a synthetic moving obstacle at a point that the recorded nominal
% UAV path ACTUALLY traverses, timed to create a real unprotected conflict.
% Choose a terrain-valid transverse crossing, never an arbitrary picture.
obstacle=[];target=NaN;timeCross=NaN;
for i=1:20
    [pts,cum,L]=mmra_arc(P{i});
    g=struct('points',pts,'cumulative',cum,'length',L);
    for f=[0.45 0.50 0.55 0.35 0.65]
        sCross=f*L;
        pCross=mmra_speed_arc_position(g,sCross);
        a=mmra_speed_arc_position(g,max(0,sCross-20));
        b=mmra_speed_arc_position(g,min(L,sCross+20));
        direction=b-a;
        perp=[-direction(2) direction(1) 0];
        if norm(perp)<1e-7,continue;end
        perp=perp/norm(perp);
        ix=find(base.trace.progress_m(:,i)>=sCross,1,'first');
        if isempty(ix) || ix<=1,continue;end
        p0=base.trace.progress_m(ix-1,i);
        p1=base.trace.progress_m(ix,i);
        if p1<=p0+1e-8,continue;end
        frac=(sCross-p0)/(p1-p0);
        crossingTime=base.trace.time_s(ix-1)+frac* ...
            (base.trace.time_s(ix)-base.trace.time_s(ix-1));
        if crossingTime<=10,continue;end
        for width=[80 60 40 25]
            pathObs=bsxfun(@plus,pCross, ...
                linspace(-width,width,81)'*perp);
            if ~all(mmra_is_free(pathObs,env)),continue;end
            candidate=struct('name','transverse_airborne_obstacle', ...
                'time_s',[0;crossingTime-8;crossingTime+8], ...
                'position_m',[pCross-width*perp; ...
                              pCross-width*perp; ...
                              pCross+width*perp], ...
                'radius_m',12);
            % Independently establish that the baseline trajectory is
            % genuinely unsafe against the NEW obstacle.
            a0=mmra_verify_dynamic_obstacles(P,base.trace,opt,candidate);
            if ~a0.safe && a0.minClearance_m<0
                obstacle=candidate;
                target=i;
                timeCross=crossingTime;
                baselineAudit=a0;
                break;
            end
        end
        if ~isempty(obstacle),break;end
    end
    if ~isempty(obstacle),break;end
end
assert(~isempty(obstacle), ...
    ['Could not create a terrain-valid moving obstacle that intersects ' ...
    'the nominal mission. Edit the test generator or choose another seed.']);

newOpt=opt;
newOpt.speedFeedbackDynamicObstacles=obstacle;
newOpt.speedFeedbackDroneRadius_m=1.0;
newOpt.speedFeedbackObstacleGuard_m=2.0;
controlled=mmra_schedule_speed_feedback(P,newOpt);
% Only claim success if BOTH UAV-UAV and UAV-obstacle audits pass.
assert(isfield(controlled.validation,'dynamicObstacles'));
assert(controlled.validation.safe && ...
    controlled.validation.dynamicObstacles.safe, ...
    'The controller emitted an unverified unsafe executed interval.');

fprintf('\n=== FIGURE 2: 20-UAV MOVING-OBSTACLE DEV COMPARISON ===\n');
fprintf('Same path checkpoint: %s\n',checkpoint);
fprintf('Synthetic moving obstacle crossing UAV %d at t=%.2f s\n', ...
    target,timeCross);
fprintf('Unprotected trajectory clearance: %.3f m (negative=collision)\n', ...
    baselineAudit.minClearance_m);
fprintf('Protected: success=%d, reason=%s\n', ...
    controlled.success,controlled.reason);
fprintf('Protected min obstacle clearance=%.3f m; UAV-UAV minsep=%.3f m\n', ...
    controlled.obstacleMinClearance_m,controlled.minSeparation);
fprintf('Dynamic obstacle yield ticks=%d, shield actions=%d\n', ...
    controlled.obstacleYieldSteps,controlled.obstacleShieldAdjustments);
fprintf('Makespan: nominal %.2f s, protected %.2f s\n', ...
    base.makespan,controlled.makespan);

outDir=fullfile(root,'results_dynamic_obstacles_dev');
if ~exist(outDir,'dir'),mkdir(outDir);end
prefix=['Figure2_20u_moving_obstacle_' datestr(now,'yyyymmdd_HHMMSS')];
save(fullfile(outDir,[prefix '.mat']), ...
    'checkpoint','base','baselineAudit','controlled','obstacle', ...
    'target','timeCross','newOpt','-v7');
summary=table(target,timeCross,baselineAudit.minClearance_m, ...
    controlled.obstacleMinClearance_m,controlled.minSeparation, ...
    controlled.obstacleYieldSteps, ...
    controlled.obstacleShieldAdjustments,controlled.success, ...
    {controlled.reason},base.makespan,controlled.makespan, ...
    'VariableNames',{'TargetUAV','ObstacleCrossingTime_s', ...
    'UnprotectedObstacleClearance_m','ProtectedObstacleClearance_m', ...
    'ProtectedUavMinSeparation_m','ObstacleYieldSteps', ...
    'ObstacleShieldActions','ProtectedScheduleSuccess','Reason', ...
    'NominalMakespan_s','ProtectedMakespan_s'});
writetable(summary,fullfile(outDir,[prefix '.csv']));
% Save simple speed/time/clearance telemetry without producing ANOTHER map.
T=controlled.trace.time_s;
ob=mmra_dynamic_obstacles_prepare(obstacle);
xyz=mmra_dynamic_obstacle_position(ob,T);
uav=squeeze(controlled.trace.position_m(:,:,target));
clearance=sqrt(sum((uav-xyz).^2,2))-(ob.radius_m+ ...
    newOpt.speedFeedbackDroneRadius_m+newOpt.speedFeedbackObstacleGuard_m);
speed_mps=[controlled.trace.speed_mps(:,target);0];
telemetry=table(T,speed_mps,clearance, ...
    'VariableNames',{'Time_s','UAVSpeed_mps','ObstacleClearanceAtTick_m'});
writetable(telemetry,fullfile(outDir,[prefix '_telemetry.csv']));
fprintf('Saved independent comparison and telemetry: %s\n',outDir);
