%REBUILD_V21_HOLDOUT_REPORTS Rebuild from saved trials; do NOT replan.
root = fileparts(mfilename('fullpath'));
assert(isfile(fullfile(root,'src','mmra_rrtstar.m')), ...
    'Could not resolve v2.1 project root.');
addpath(fullfile(root,'examples'));
mmra_v21_holdout_report(root);
