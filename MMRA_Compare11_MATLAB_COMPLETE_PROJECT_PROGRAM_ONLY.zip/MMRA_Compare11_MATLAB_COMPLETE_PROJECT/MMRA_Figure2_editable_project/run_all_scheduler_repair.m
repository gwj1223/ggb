%RUN_ALL_SCHEDULER_REPAIR One command: regression + development e2e pilot.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
addpath(fullfile(root,'tests'));
addpath(fullfile(root,'examples'));
fprintf('=== MMRA v2.1 bottleneck-repair scheduling development pilot ===\n');
run(fullfile(root,'run_tests.m'));
mmra_rrt_threeobjective_tests();
mmra_sched_repair_tests();
mmra_sched_repair_driver(root);
