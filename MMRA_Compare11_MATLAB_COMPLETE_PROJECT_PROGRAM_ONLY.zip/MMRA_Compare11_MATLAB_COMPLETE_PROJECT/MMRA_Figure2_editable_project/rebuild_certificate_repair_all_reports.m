%REBUILD_CERTIFICATE_REPAIR_ALL_REPORTS Read saved 180-case CSV ONLY.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'examples'));
mmra_certificate_repair_report(root,false);
