%REBUILD_SCHEDULER_REPAIR_REPORTS Rebuild CSVs from existing checkpoints.
% Does not execute any spatial planning or scheduler calls.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'examples'));
mmra_sched_repair_report(root);
