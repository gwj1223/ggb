%RUN_PLOT_FIGURE2_CORNER_ORIGIN
% Render the ACTUAL cached five-UAV mission in the user-selected LOCAL XY.
% Does not alter any world-space planning/obstacle data or saved settings.
%
%     local X = world Y - 200 m
%     local Y = 4766.67 m - world X
%     local Z = world Z (absolute terrain elevation)
%
% Both local axes point mostly into the current 5x5-km map. This is a
% proper 90-degree XY rotation (preserves physical distance and handedness).
% If a matching V3 simulation exists, draw its chosen routes. Otherwise
% draw the certified RRT* routes. Moving spheres are previewed at 120 s.

root = fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));

cacheFile = fullfile(root,'results_static_obstacles_dev', ...
    'Figure2_static_obstacle_rrt_5u.mat');
assert(isfile(cacheFile), ...
    'Missing route cache. Run run_static_obstacle_figure2_5u_local_origin.m.');
C = load(cacheFile,'env','starts','goals','paths','missionInfo');
assert(isfield(C,'missionInfo') && ...
       strcmp(C.missionInfo.name,'corner_base_local_origin_5u'), ...
       'Current route cache is NOT the new local-origin five-UAV mission.');
assert(isequal(size(C.starts),[5 3]) && ...
       isequal(size(C.goals),[5 3]) && iscell(C.paths) && ...
       numel(C.paths)==5);
env = C.env;
% A height edit changes real collision geometry. Never show a stale
% cached 5-UAV path on a newly saved terrain as if it were revalidated.
[currentTerrainEnv,~,~] = mmra_defaults( ...
    'mountain_cluster_figure2_custom_5km');
terrainFields = {'peaks','terrainRidges','terrainErosionGullies', ...
    'terrainMicroWaves','baseHeight'};
for kk=1:numel(terrainFields)
    f = terrainFields{kk};
    assert(isfield(env,f) && isfield(currentTerrainEnv,f) && ...
        isequaln(env.(f),currentTerrainEnv.(f)), ...
        ['Saved Figure 2 terrain heights changed since planning. ', ...
         'Run run_static_obstacle_figure2_5u_local_origin.m, ', ...
         'then run_static_dynamic_figure2_5u.m, then plot again.']);
end
baseXY = C.missionInfo.originWorldXY_m;
assert(norm(baseXY-[4766.67 200.00])<1e-6, ...
    'The cached coordinate origin does not match the selected point.');

% Never mistake an old simulation for the newly planned mission.
pathsToPlot = C.paths;
routeLabel = 'Obstacle-aware RRT* paths (new task)';
resultFile = fullfile(root,'results_static_dynamic_dev', ...
    'Figure2_static_dynamic_5u_v3.mat');
matchedDynamicRun = false;
if isfile(resultFile)
    R = load(resultFile,'chosenPaths','env');
    if isfield(R,'chosenPaths') && iscell(R.chosenPaths) && ...
            numel(R.chosenPaths)==5 && isfield(R,'env') && ...
            isequal(R.env,env)
        matchedDynamicRun = true;
        for i=1:5
            p = R.chosenPaths{i};
            if ~isnumeric(p) || isempty(p) || size(p,2)~=3 || ...
                  norm(p(1,:)-C.starts(i,:))>=1 || ...
                  norm(p(end,:)-C.goals(i,:))>=1
                matchedDynamicRun = false;
                break;
            end
        end
        if matchedDynamicRun
            pathsToPlot = R.chosenPaths;
            routeLabel = 'V3 selected flight routes (matching task)';
        end
    end
    if ~matchedDynamicRun
        fprintf(['Old/different dynamic results were ignored. ' ...
            'Run run_static_dynamic_figure2_5u.m to update V3.\n']);
    end
end

% All terrain geometry is queried in ORIGINAL global coordinates.
xWorld = linspace(env.boundsLo(1),env.boundsHi(1),151);
yWorld = linspace(env.boundsLo(2),env.boundsHi(2),151);
[Xworld,Yworld] = meshgrid(xWorld,yWorld);
Hworld = reshape(mmra_terrain([Xworld(:),Yworld(:)],env),size(Xworld));
XlocalKm = (Yworld-baseXY(2))/1000;
YlocalKm = (baseXY(1)-Xworld)/1000;

fig = figure('Color','w','Name','Figure 2 - corner-base local origin', ...
    'NumberTitle','off','Position',[70 70 1370 850]);
ax = axes('Parent',fig);
hold(ax,'on');
hTerrain = surf(ax,XlocalKm,YlocalKm,Hworld/1000, ...
    'EdgeColor','none','FaceAlpha',0.94,'DisplayName','Terrain');
shading(ax,'interp');
colormap(ax,parula(128));
cb = colorbar(ax);
ylabel(cb,'Terrain elevation (km)');

% Draw finite-height red cylinders using the SAME world-space NFZ data.
hNFZ = [];
if isfield(env,'noFlyCylinders') && ~isempty(env.noFlyCylinders)
    theta = linspace(0,2*pi,73);
    for k=1:size(env.noFlyCylinders,1)
        c = env.noFlyCylinders(k,:);
        ringWorldX = c(1)+c(3)*cos(theta);
        ringWorldY = c(2)+c(3)*sin(theta);
        ringLocalXKm = (ringWorldY-baseXY(2))/1000;
        ringLocalYKm = (baseXY(1)-ringWorldX)/1000;
        h = surf(ax,[ringLocalXKm;ringLocalXKm], ...
            [ringLocalYKm;ringLocalYKm], ...
            [c(4)*ones(1,numel(theta));c(5)*ones(1,numel(theta))]/1000, ...
            'FaceColor',[0.89 0.16 0.20],'FaceAlpha',0.17, ...
            'EdgeColor','none','HandleVisibility','off');
        if isempty(hNFZ),hNFZ = h; end
        plot3(ax,ringLocalXKm,ringLocalYKm, ...
            c(5)/1000*ones(size(theta)), '-', ...
            'Color',[0.70 0.13 0.16],'LineWidth',0.65, ...
            'HandleVisibility','off');
    end
end

% Optional static boxes, if they remain enabled in the active environment.
hBox = [];
if isfield(env,'staticBoxes') && ~isempty(env.staticBoxes)
    faces = [1 2 3 4;5 6 7 8;1 2 6 5;2 3 7 6; ...
             3 4 8 7;4 1 5 8];
    for k=1:size(env.staticBoxes,1)
        b = env.staticBoxes(k,:);
        W = [b(1) b(3) b(5);b(2) b(3) b(5); ...
             b(2) b(4) b(5);b(1) b(4) b(5); ...
             b(1) b(3) b(6);b(2) b(3) b(6); ...
             b(2) b(4) b(6);b(1) b(4) b(6)];
        L = [(W(:,2)-baseXY(2)),(baseXY(1)-W(:,1)),W(:,3)]/1000;
        h = patch(ax,'Vertices',L,'Faces',faces, ...
            'FaceColor',[0.38 0.29 0.27],'FaceAlpha',0.42, ...
            'EdgeColor',[0.35 0.24 0.23], ...
            'LineWidth',0.5,'HandleVisibility','off');
        if isempty(hBox),hBox=h;end
    end
end

% Planned or V3-selected five-UAV routes, transformed ONLY for drawing.
% Five requested UAV route colors (MATLAB RGB, values in [0,1]).
% UAV1 = green, UAV2 = yellow, UAV3 = red,
% UAV4 = purple, UAV5 = orange. Terrain remains parula.
routeColors = [ ...
    0.14 0.93 0.19; ...  % UAV1
    1.00 0.95 0.15; ...  % UAV2
    1.00 0.17 0.17; ...  % UAV3
    0.89 0.45 0.98; ...  % UAV4
    0.84 0.56 0.00  ...  % UAV5
];
hPath = [];
for i=1:5
    p = pathsToPlot{i};
    assert(isnumeric(p) && ~isempty(p) && size(p,2)==3, ...
        'Missing path for UAV%d.',i);
    localPathKm = [(p(:,2)-baseXY(2)),(baseXY(1)-p(:,1)),p(:,3)]/1000;
    h = plot3(ax,localPathKm(:,1),localPathKm(:,2), ...
        localPathKm(:,3),'-','Color',routeColors(i,:), ...
        'LineWidth',2.1,'HandleVisibility','off');
    if isempty(hPath),hPath=h;end
end

% Show three saved dynamic spherical obstacles at a fixed instant.
% Visual sphere radius 2x is ONLY for appearance: V3 uses real radius_m.
previewTime_s = 120;
[obstacles,obstacleInfo] = mmra_figure2_dynamic_obstacles(env);
[sx,sy,sz] = sphere(24);
faceColor = [1.00 0.73 0.36];
edgeColor = [0.47 0.25 0.12];
trajectoryColors = [0.69 0.19 0.77;0.20 0.54 0.83;0.98 0.53 0.11];
visualScale = 2.0;
% Keep Figure 2's own terrain Z exaggeration, while compensating the
% spheres only so they render ROUND in orthographic view.
dataAspectRatio = [1 1 0.55];
hSphere = [];
for k=1:numel(obstacles)
    ob = obstacles(k);
    c = trajectoryColors(mod(k-1,size(trajectoryColors,1))+1,:);
    q = ob.position_m;
    localTrailKm = [(q(:,2)-baseXY(2)),(baseXY(1)-q(:,1)),q(:,3)]/1000;
    plot3(ax,localTrailKm(:,1),localTrailKm(:,2), ...
        localTrailKm(:,3),'--','Color',c,'LineWidth',1.3, ...
        'HandleVisibility','off');
    centerWorld = mmra_dynamic_obstacle_position(ob,previewTime_s);
    centerLocalKm = [(centerWorld(2)-baseXY(2)), ...
                     (baseXY(1)-centerWorld(1)),centerWorld(3)]/1000;
    r = visualScale*ob.radius_m/1000;
    h = surf(ax,centerLocalKm(1)+r*sx, ...
        centerLocalKm(2)+r*sy, ...
        centerLocalKm(3)+r*dataAspectRatio(3)*sz, ...
        'FaceColor',faceColor,'EdgeColor',edgeColor, ...
        'FaceAlpha',1,'EdgeAlpha',1,'LineWidth',0.32, ...
        'FaceLighting','none','HandleVisibility','off');
    if isempty(hSphere),hSphere=h;end

end

% Real start/goal markers, independent of SHOW UAV POINTS; no S/G/D text labels.
startL = [(C.starts(:,2)-baseXY(2)), ...
          (baseXY(1)-C.starts(:,1)),C.starts(:,3)]/1000;
goalL = [(C.goals(:,2)-baseXY(2)), ...
         (baseXY(1)-C.goals(:,1)),C.goals(:,3)]/1000;
hStarts = plot3(ax,startL(:,1),startL(:,2),startL(:,3), ...
    'o','LineStyle','none','MarkerSize',7, ...
    'MarkerFaceColor',[0.12 0.68 0.27], ...
    'MarkerEdgeColor',[0.02 0.25 0.07],'LineWidth',1);
% The five actual launch positions remain visible (no text labels).
hGoals = plot3(ax,goalL(:,1),goalL(:,2),goalL(:,3), ...
    's','LineStyle','none','MarkerSize',9, ...
    'MarkerFaceColor',[1.00 0.48 0.10], ...
    'MarkerEdgeColor',[0.32 0.16 0.04]);

xlabel(ax,'Local X (km)');
ylabel(ax,'Local Y (km)');
zlabel(ax,'Altitude (km, global datum)');
xlim(ax,[(env.boundsLo(2)-baseXY(2)), ...
         (env.boundsHi(2)-baseXY(2))]/1000);
ylim(ax,[(baseXY(1)-env.boundsHi(1)), ...
         (baseXY(1)-env.boundsLo(1))]/1000);
zlim(ax,[env.boundsLo(3) env.boundsHi(3)]/1000);
daspect(ax,dataAspectRatio);
grid(ax,'off');
set(ax,'TickLength',[0 0]);
set(ax,'Projection','orthographic'); % R2023b property; not CameraProjection.

% If user captured a viewpoint from original global-XY Figure 2, rotate
% camera azimuth by -90 degrees, because the local frame is rotated -90.
viewFile = fullfile(root,'results_common_base_origin_dev', ...
    'Figure2_preferred_global_view.mat');
originalGlobalView = [42 29];
if isfile(viewFile)
    V = load(viewFile,'viewGlobalAzEl');
    if isfield(V,'viewGlobalAzEl') && ...
       numel(V.viewGlobalAzEl)==2 && all(isfinite(V.viewGlobalAzEl))
        originalGlobalView = V.viewGlobalAzEl;
    end
end
view(ax,originalGlobalView(1)-90,originalGlobalView(2));

if matchedDynamicRun
    taskLabel = 'matching V3 chosen routes';
else
    taskLabel = 'certified RRT* paths (V3 not yet matched)';
end
title(ax,sprintf('Figure 2 | five UAVs | %s | spheres t=%g s', ...
    taskLabel,previewTime_s));

legH = [hTerrain hPath hStarts hGoals];
legS = {'Terrain','UAV routes','Airborne starts','Goals'};
if ~isempty(hNFZ)
    legH = [legH hNFZ]; legS{end+1}='No-fly cylinders';
end
if ~isempty(hBox)
    legH = [legH hBox]; legS{end+1}='Static boxes';
end
if ~isempty(hSphere)
    legH = [legH hSphere]; legS{end+1}='Moving spheres (2x visual)';
end
for k=1:numel(legH), set(legH(k),'HandleVisibility','on');end
legend(ax,legH,legS,'Location','northeastoutside');

axes(ax);  % Main 3-D terrain axes stay active for mouse rotation.

% Avoid including the axes toolbar in paper-image exports.
try
    if isprop(ax,'Toolbar')
        ax.Toolbar.Visible = 'off';
    end
catch
end
outDir = fullfile(root,'results_common_base_origin_dev');
if ~exist(outDir,'dir'),mkdir(outDir);end
outPng = fullfile(outDir,'Figure2_local_origin_5u_with_obstacles.png');
exportgraphics(fig,outPng,'Resolution',220);
fprintf('\nLOCAL Figure 2 plotted: %s\n',outPng);
fprintf('Global selected point [4766.67,200]m = local [0,0]m.\n');
fprintf('Local X=global Y-200; Local Y=4766.67-global X (metres).\n');
fprintf('Routes used: %s. Moving spheres source: %s.\n', ...
    routeLabel,obstacleInfo.source);
fprintf('IMPORTANT: all planning and collision checks retain GLOBAL XYZ.\n');
