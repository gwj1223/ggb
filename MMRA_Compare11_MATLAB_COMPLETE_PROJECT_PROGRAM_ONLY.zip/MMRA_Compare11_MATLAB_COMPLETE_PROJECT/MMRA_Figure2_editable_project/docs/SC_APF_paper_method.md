# Candidate manuscript insertion: safety-clearance-aware smooth potential

**Method.** For a differentiable Gaussian-mixture terrain field H(x,y) and a required vertical terrain clearance delta_safe, define c(q)=z-H(x,y)-delta_safe and a(q)=max(0,b-c(q)), where b is the safety activation band. The revised terrain repulsive potential is

U_rep^SC(q) = k_s * ell * log cosh(a(q)/ell),

and its analytical gradient is

grad U_rep^SC(q) = -k_s * tanh(a(q)/ell) * (-H_x(q),-H_y(q),1)^T.

Here k_s>=0 and ell>0 control repulsive strength and smoothness. The repulsive gradient vanishes for c>=b and joins continuously at c=b. In contrast to the reciprocal clearance potential, its scalar derivative magnitude is bounded by k_s even for terrain-infeasible random samples. Note that the spatial gradient norm also depends on the local terrain slope, so the statement is about bounded scalar sensitivity, not a global uniform bound over arbitrary terrain models.

The original attractive quadratic potential is retained. The combined gradient modifies only the non-goal sample in the existing gradient-guided RRT* scheme. Nearest-neighbor selection, steering, rewiring, and segment collision checking remain unchanged. The safety margin is an environment constraint; repulsive guidance itself is not a collision certificate. The proposed method is C1 for a smooth GMM elevation field but does not in itself establish the asymptotic optimality of an early-stopping RRT* implementation.

**Proposed ablation.** Compare (i) unguided RRT*, (ii) original reciprocal-repulsion guided RRT*, and (iii) SC-APF guided RRT* using paired seeds, matched budgets and collision checking, and no postprocessing. Measure first-solution runtime, iterations, solution rate, collision-rejection fraction, geometric path length, and sampled clearance. If available, add published, closely related APF-RRT* baselines. Use the end-to-end pipeline only after the isolated mechanism is validated.

**Interpretation.** SC-APF is a potentially more numerically regular, safety-margin-aligned terrain guidance mechanism. It is an incremental design hypothesis, not a novel general APF theorem. Draw performance conclusions only from actual repeated experiments. The new parameter values and example paths are not results.
