%RUN_UAV_POINTS_DISPLAY_TESTS Test saved display preference and renderer.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'tests'));
mmra_figure2_uav_display_tests();
