%RUN_DYNAMIC_MAP_TESTS Round-trip and geometric tests. No user MAT writes.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'),fullfile(root,'tests'));
mmra_figure2_dynamic_map_tests();
