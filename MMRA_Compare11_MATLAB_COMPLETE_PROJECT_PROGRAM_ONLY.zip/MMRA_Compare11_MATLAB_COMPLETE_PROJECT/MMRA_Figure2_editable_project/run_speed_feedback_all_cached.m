%RUN_SPEED_FEEDBACK_ALL_CACHED Compare 5/10/20-UAV on existing DEV paths.
root=fileparts(mfilename('fullpath'));
pathCasesFolder='';
repairedPathsFolder='';
seeds=1:30;
addpath(fullfile(root,'src'),fullfile(root,'examples'));
mmra_speed_feedback_cached_driver(root,[5 10 20], ...
    pathCasesFolder,repairedPathsFolder,seeds);
