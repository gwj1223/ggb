%RUN_DYNAMIC_ADAPTIVE_FIGURE2_5U Third innovation, SAME user-saved Figure 2.
% Use the existing five RRT* route checkpoint. No new terrain map is drawn
% or saved. This is a controlled pre-flight comparison under one predicted
% moving-sphere crossing, not a claim of autonomous online re-planning.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'src'));
[env,cfg,opt]=mmra_defaults('mountain_cluster_figure2_custom_5km');
checkpointDir=fullfile(root,'results_5km_dev');
files=dir(fullfile(checkpointDir, ...
    'paths_mountain_cluster_figure2_custom_5km_cross_center_u5_seed24001_*.mat'));
assert(~isempty(files),'No 5-UAV Figure 2 checkpoint was found.');
[~,order]=sort([files.datenum],'descend');
matched=false;
for h=reshape(order,1,[])
    file=fullfile(files(h).folder,files(h).name);
    data=load(file,'checkpointData');
    if ~isfield(data,'checkpointData'),continue;end
    c=data.checkpointData;
    if isfield(c,'env') && isequal(c.env,env) && ...
            isfield(c,'paths') && numel(c.paths)==5 && ...
            isfield(c,'spatialOK') && all(c.spatialOK)
        paths=c.paths;
        checkpoint=file;
        matched=true;
        break;
    end
end
assert(matched,'Cached paths do not match the current saved Figure 2 map.');
noObstacle=opt;
if isfield(noObstacle,'speedFeedbackDynamicObstacles')
    noObstacle=rmfield(noObstacle,'speedFeedbackDynamicObstacles');
end
nominal=mmra_schedule_speed_feedback(paths,noObstacle);
assert(nominal.success && nominal.validation.safe && ...
    nominal.validation.complete,'Nominal five-aircraft schedule must be valid.');

% Generate one DEM-valid moving obstacle from the REAL nominal flight and
% independently prove that without avoidance it would cause a conflict.
obstacle=[];target=NaN;encounterTime=NaN;
fractions=[.50 .45 .55 .40 .60];widths=[80 60 40 25];
for i=1:numel(paths)
    [p,cum,L]=mmra_arc(paths{i});
    g=struct('points',p,'cumulative',cum,'length',L);
    for f=fractions
        at=f*L;
        center=mmra_speed_arc_position(g,at);
        earlier=mmra_speed_arc_position(g,max(0,at-20));
        later=mmra_speed_arc_position(g,min(L,at+20));
        tangent=later-earlier;
        transverse=[-tangent(2),tangent(1),0];
        if norm(transverse)<1e-8,continue;end
        transverse=transverse/norm(transverse);
        ix=find(nominal.trace.progress_m(:,i)>=at,1,'first');
        if isempty(ix) || ix<=1,continue;end
        s0=nominal.trace.progress_m(ix-1,i);
        s1=nominal.trace.progress_m(ix,i);
        if s1<=s0+1e-8,continue;end
        crossing=nominal.trace.time_s(ix-1)+ ...
            (at-s0)/(s1-s0)*(nominal.trace.time_s(ix)-nominal.trace.time_s(ix-1));
        if crossing<=10,continue;end
        for width=widths
            samples=bsxfun(@plus,center, ...
                linspace(-width,width,61)'*transverse);
            if ~all(mmra_is_free(samples,env)),continue;end
            ob=struct('name','Figure2_predicted_transverse_obstacle', ...
                'time_s',[0;crossing-8;crossing+8], ...
                'position_m',[center-width*transverse; ...
                              center-width*transverse; ...
                              center+width*transverse], ...
                'radius_m',12);
            audit=mmra_verify_dynamic_obstacles( ...
                paths,nominal.trace,opt,ob);
            if ~audit.safe && audit.minClearance_m<0
                obstacle=ob;target=i;encounterTime=crossing;
                unprotectedAudit=audit;
                break;
            end
        end
        if ~isempty(obstacle),break;end
    end
    if ~isempty(obstacle),break;end
end
assert(~isempty(obstacle), ...
    'Could not generate a terrain-valid nominal collision on these paths.');
withObstacle=opt;
withObstacle.speedFeedbackDynamicObstacles=obstacle;
withObstacle.dynamicAdaptiveMaxCandidates=10;
withObstacle.dynamicAdaptiveProbeDelay_s=2;
withObstacle.dynamicAdaptiveProbeYield_s=2;
withObstacle.dynamicAdaptivePredictionBound_m=0;
withObstacle.dynamicAdaptiveTryLocalRRT=false;

speedOnly=mmra_schedule_speed_feedback(paths,withObstacle);
% Keep the previously validated, makespan+length-only hybrid as a baseline.
legacyOpt=withObstacle;
legacyOpt.hybridWaitTrigger_s=2;
legacyOpt.hybridMaxCandidates=10;
legacyOpt.hybridTryLocalRRT=false;
[legacyHybrid,legacyPaths,legacyDecision]= ...
    mmra_hybrid_dynamic_obstacle_schedule(paths,env,cfg,legacyOpt);
[adaptive,adaptivePaths,decision]= ...
    mmra_dynamic_adaptive_hybrid_schedule(paths,env,cfg,withObstacle);
% Ablation of the explicit prediction reserve. 2 m is illustrative ONLY;
% its validity as a true bound requires a sensor/estimator error analysis.
robustOpt=withObstacle;
robustOpt.dynamicAdaptivePredictionBound_m=2;
[robust,robustPaths,robustDecision]= ...
    mmra_dynamic_adaptive_hybrid_schedule(paths,env,cfg,robustOpt);

fprintf('\n=== FIGURE 2 / 5-UAV ADAPTIVE DYNAMIC OBSTACLE V3 ===\n');
fprintf('Checkpoint: %s\n',checkpoint);
fprintf('Synthetic transverse obstacle: crosses UAV %d at t=%.2f s\n', ...
    target,encounterTime);
fprintf('Unprotected nominal clearance: %.3f m (negative=violation)\n', ...
    unprotectedAudit.minClearance_m);
fprintf('Strategy           Success  Makespan  MinObsClear  MinUAVSep   YieldTicks\n');
localPrint('speed_only',speedOnly);
localPrint('legacy_hybrid',legacyHybrid);
localPrint(decision.strategy,adaptive);
localPrint('adaptive_bound_2m',robust);
fprintf(['Adaptive decisions: reason=%s; proposed=%d, simulated=%d, ' ...
    'completed=%d.\n'],decision.decisionReason,decision.candidateProposals, ...
    decision.simulatedCandidates,decision.completedCandidates);
fprintf(['Selected route delta: L=%+.2f m, R=%+.2f m, climb=%+.2f m, ' ...
    'J=%+.2f m; score=%.3f s.\n'], ...
    decision.selectedExtraLength_m,decision.selectedDeltaRisk_m, ...
    decision.selectedDeltaAscent_m,decision.selectedDeltaPathObjective_m, ...
    decision.selectedScore_s);
fprintf(['Error-bound version: %.1f m, reason=%s, ' ...
    'nominal-radius clearance=%.2f m.\n'], ...
    robustDecision.predictionBound_m,robustDecision.decisionReason, ...
    robustDecision.chosenNominalRadiusClearance_m);
if speedOnly.success
    assert(speedOnly.validation.safe && speedOnly.validation.complete && ...
        speedOnly.validation.dynamicObstacles.safe, ...
        'Speed-only claimed success without independent verification.');
end
if legacyHybrid.success
    assert(legacyHybrid.validation.safe && legacyHybrid.validation.complete && ...
        legacyHybrid.validation.dynamicObstacles.safe, ...
        'Legacy hybrid claimed success without independent verification.');
end
if adaptive.success
    assert(adaptive.validation.safe && adaptive.validation.complete && ...
        adaptive.validation.dynamicObstacles.safe && ...
        adaptive.obstacleMinClearance_m>=-withObstacle.tol && ...
        adaptive.minSeparation>=withObstacle.dSafe-withObstacle.tol, ...
        'Adaptive claimed success without independent verification.');
end
if robust.success
    assert(robust.validation.safe && robust.validation.complete && ...
        robust.validation.dynamicObstacles.safe && ...
        robustDecision.chosenNominalRadiusClearance_m>=2-robustOpt.tol-1e-7, ...
        'Bounded-error version did not retain its inflation margin.');
end
outDir=fullfile(root,'results_dynamic_adaptive_dev');
if ~exist(outDir,'dir'),mkdir(outDir);end
save(fullfile(outDir,'Figure2_5u_dynamic_adaptive_v3.mat'), ...
    'checkpoint','obstacle','target','encounterTime', ...
    'unprotectedAudit','speedOnly','legacyHybrid','legacyPaths', ...
    'legacyDecision','adaptive','adaptivePaths', ...
    'decision','robust','robustPaths','robustDecision','withObstacle','-v7');
fprintf('Independent output: %s\n',outDir);
fprintf(['Limit: prediction and ideal speed commands; ' ...
    'NO online sensor tracking or real-flight guarantee.\n']);

function localPrint(name,res)
    if res.success,finish=res.makespan;else,finish=NaN;end
    fprintf('%-18s   %d      %8.2f     %8.3f     %8.3f       %d\n', ...
        name,res.success,finish,res.obstacleMinClearance_m, ...
        res.minSeparation,res.obstacleYieldSteps);
end
